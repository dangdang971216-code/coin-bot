#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Auto-flattened v1181 active dependency graph; historical unreachable definitions removed.

from __future__ import annotations

import json, os, time, math, traceback, urllib.request, gzip, hashlib, copy, threading, fcntl
from functools import lru_cache

from pathlib import Path

from typing import Any, Dict, List, Tuple, Optional

import re

from collections import Counter, OrderedDict

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))

def now_ts() -> float: return time.time()

def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))

def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default

def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists():
            return default
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            return json.load(f)
    except (OSError, ValueError, TypeError):
        return default

def save_json(path: Path, obj: Any) -> None:
    """Durable atomic JSON writer for canonical state and ledgers."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{time.time_ns()}")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, separators=(",", ":"), default=str)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError as exc:
            append_error(ERROR, "strategy_json_tmp_cleanup_v1008", exc)

_RUNTIME_JSON_IDENTITY_CACHE: Dict[str,Dict[str,Any]] = {}

def save_runtime_json(path: Path, obj: Any, owner: str='runtime') -> None:
    """Atomic no-fsync writer for regenerable runtime/status artifacts only."""
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.runtime.{os.getpid()}.{time.time_ns()}")
    try:
        with tmp.open("w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, separators=(",", ":"), default=str)
            f.flush()
        os.replace(tmp, path)
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass

def load_json_identity_cached(path: Path, default: Any=None) -> Any:
    """Read a runtime JSON file once per exact inode/mtime/size identity."""
    key = str(path)
    try:
        st = path.stat()
        identity = (int(st.st_mtime_ns), int(st.st_size), int(st.st_ino))
    except OSError:
        return default
    cached = _RUNTIME_JSON_IDENTITY_CACHE.get(key)
    if isinstance(cached, dict) and cached.get("identity") == identity:
        return copy.deepcopy(cached.get("value"))
    value = load_json(path, default)
    _RUNTIME_JSON_IDENTITY_CACHE[key] = {"identity": identity, "value": copy.deepcopy(value)}
    return value

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass

@lru_cache(maxsize=4096)
def _ticker_norm_cached_v1210(raw: str) -> str:
    t = raw.strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3:
        t=t[:-3]
    return t.strip().upper()


def ticker_norm(x: Any) -> str:
    return _ticker_norm_cached_v1210(str(x or ""))

def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0

def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

def feature_rows(obj: Any) -> List[Dict[str, Any]]:
    """feature_worker cache를 한 본선으로 읽는다.
    rows/list/cache/dict 형태를 모두 map_rows로 표준화한다.
    전략 조건 수치는 변경하지 않는다.
    """
    return list(map_rows(obj).values())

INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))

ERROR=BASE_DIR/"clean_strategy_worker_error.log"

STATUS=BASE_DIR/"clean_strategy_worker_status.json"

_STATUS_WRITE_LOCK_V1022 = threading.RLock()

_STATUS_LAST_OBJ_V1022: Dict[str, Any] = {}

_STATUS_LAST_WRITE_TS_V1022 = 0.0

_STATUS_HEARTBEAT_COUNT_V1022 = 0

_STATUS_HEARTBEAT_THREAD_V1022: Optional[threading.Thread] = None

_STATUS_HEARTBEAT_STOP_V1022 = threading.Event()

STATUS_HEARTBEAT_SEC_V1022 = max(2.0, float(os.getenv("STRATEGY_STATUS_HEARTBEAT_SEC", "10")))

STRATEGY_CPU_PROFILE_V1027 = BASE_DIR / "clean_strategy_cpu_profile_v1027.json"

_LIVE_PHASE_LOCK_V1028 = threading.RLock()

_LIVE_PHASE_NAME_V1028 = "boot_v1028"

_LIVE_PHASE_STARTED_MONO_V1028 = time.monotonic()

_LIVE_PHASE_STARTED_TS_V1028 = now_ts()

_LIVE_PHASE_SEQUENCE_V1028 = 0

_LIVE_PHASE_LAST_COMPLETED_V1028 = "-"

_LIVE_PHASE_LAST_COMPLETED_WALL_V1028 = 0.0

_LIVE_PHASE_LAST_COMPLETED_CPU_V1028 = 0.0

_LIVE_PHASE_LAST_COMPLETED_TS_V1028 = 0.0

_LIVE_CYCLE_STARTED_TS_V1028 = 0.0

def _v1028_live_phase_enter(profile: Dict[str, Any], name: str) -> Tuple[float, float]:
    global _LIVE_PHASE_NAME_V1028, _LIVE_PHASE_STARTED_MONO_V1028, _LIVE_PHASE_STARTED_TS_V1028
    global _LIVE_PHASE_SEQUENCE_V1028, _LIVE_CYCLE_STARTED_TS_V1028
    token = _v1027_phase_start()
    nowv = now_ts()
    with _LIVE_PHASE_LOCK_V1028:
        _LIVE_PHASE_NAME_V1028 = str(name or "unknown")
        _LIVE_PHASE_STARTED_MONO_V1028 = time.monotonic()
        _LIVE_PHASE_STARTED_TS_V1028 = nowv
        _LIVE_PHASE_SEQUENCE_V1028 += 1
        if _LIVE_CYCLE_STARTED_TS_V1028 <= 0 or _LIVE_PHASE_NAME_V1028 == "status_start":
            _LIVE_CYCLE_STARTED_TS_V1028 = float(profile.get("cycle_started_ts") or nowv) if isinstance(profile, dict) else nowv
    if isinstance(profile, dict):
        profile['live_phase_sequence_v1028'] = _LIVE_PHASE_SEQUENCE_V1028
    return token

def _v1028_live_phase_idle(name: str = "sleep_wait_v1028") -> None:
    global _LIVE_PHASE_NAME_V1028, _LIVE_PHASE_STARTED_MONO_V1028, _LIVE_PHASE_STARTED_TS_V1028
    global _LIVE_CYCLE_STARTED_TS_V1028
    with _LIVE_PHASE_LOCK_V1028:
        _LIVE_PHASE_NAME_V1028 = str(name or "idle_v1028")
        _LIVE_PHASE_STARTED_MONO_V1028 = time.monotonic()
        _LIVE_PHASE_STARTED_TS_V1028 = now_ts()
        _LIVE_CYCLE_STARTED_TS_V1028 = 0.0

def _v1028_live_phase_snapshot() -> Dict[str, Any]:
    with _LIVE_PHASE_LOCK_V1028:
        elapsed = max(0.0, time.monotonic() - _LIVE_PHASE_STARTED_MONO_V1028)
        cycle_age = max(0.0, now_ts() - _LIVE_CYCLE_STARTED_TS_V1028) if _LIVE_CYCLE_STARTED_TS_V1028 > 0 else 0.0
        return {
            'strategy_live_phase_v1028': _LIVE_PHASE_NAME_V1028,
            'strategy_live_phase_started_ts_v1028': _LIVE_PHASE_STARTED_TS_V1028,
            'strategy_live_phase_started_text_v1028': now_text(_LIVE_PHASE_STARTED_TS_V1028),
            'strategy_live_phase_elapsed_sec_v1028': round(elapsed, 3),
            'strategy_live_phase_sequence_v1028': _LIVE_PHASE_SEQUENCE_V1028,
            'strategy_live_cycle_started_ts_v1028': (_LIVE_CYCLE_STARTED_TS_V1028 or None),
            'strategy_live_cycle_age_sec_v1028': round(cycle_age, 3),
            'strategy_live_last_completed_phase_v1028': _LIVE_PHASE_LAST_COMPLETED_V1028,
            'strategy_live_last_completed_wall_sec_v1028': round(_LIVE_PHASE_LAST_COMPLETED_WALL_V1028, 6),
            'strategy_live_last_completed_cpu_sec_v1028': round(_LIVE_PHASE_LAST_COMPLETED_CPU_V1028, 6),
            'strategy_live_last_completed_ts_v1028': (_LIVE_PHASE_LAST_COMPLETED_TS_V1028 or None),
            'strategy_live_phase_owner_v1028': 'strategy_worker live memory -> existing v1022 heartbeat writer',
            'strategy_live_phase_extra_writer_v1028': False,
        }

def _v1027_new_cpu_profile(cycle_ts: float) -> Dict[str, Any]:
    return {
        'schema': 'strategy_cpu_profile_v1027',
        'version': VERSION if 'VERSION' in globals() else 'strategy_worker',
        'build': BUILD_LABEL if 'BUILD_LABEL' in globals() else 'v1027',
        'cycle_started_ts': cycle_ts,
        'cycle_started_text': now_text(cycle_ts),
        'pid': os.getpid(),
        'phases': {},
        'call_count_total': 0,
        'row_observation_total': 0,
        'measurement_only': True,
        'strategy_conditions_changed': False,
    }

def _v1027_phase_start() -> Tuple[float, float]:
    return time.monotonic(), time.process_time()

def _v1027_phase_stop(profile: Dict[str, Any], name: str, token: Tuple[float, float], *, calls: int = 1, rows: int = 0) -> None:
    if not isinstance(profile, dict):
        return
    wall = max(0.0, time.monotonic() - float(token[0]))
    cpu = max(0.0, time.process_time() - float(token[1]))
    phases = profile.setdefault('phases', {})
    prev = phases.get(name) if isinstance(phases.get(name), dict) else {}
    phases[name] = {
        'wall_sec': round(float(prev.get('wall_sec') or 0.0) + wall, 6),
        'cpu_sec': round(float(prev.get('cpu_sec') or 0.0) + cpu, 6),
        'calls': int(prev.get('calls') or 0) + max(0, int(calls)),
        'rows': int(prev.get('rows') or 0) + max(0, int(rows)),
    }
    profile['call_count_total'] = int(profile.get('call_count_total') or 0) + max(0, int(calls))
    profile['row_observation_total'] = int(profile.get('row_observation_total') or 0) + max(0, int(rows))
    global _LIVE_PHASE_LAST_COMPLETED_V1028, _LIVE_PHASE_LAST_COMPLETED_WALL_V1028
    global _LIVE_PHASE_LAST_COMPLETED_CPU_V1028, _LIVE_PHASE_LAST_COMPLETED_TS_V1028
    with _LIVE_PHASE_LOCK_V1028:
        if _LIVE_PHASE_NAME_V1028 == str(name):
            _LIVE_PHASE_LAST_COMPLETED_V1028 = str(name)
            _LIVE_PHASE_LAST_COMPLETED_WALL_V1028 = wall
            _LIVE_PHASE_LAST_COMPLETED_CPU_V1028 = cpu
            _LIVE_PHASE_LAST_COMPLETED_TS_V1028 = now_ts()

def _v1113_phase_group_totals(profile: Dict[str, Any]) -> Dict[str, Any]:
    """Build non-overlapping wall-time groups for the completed Strategy cycle.

    The old top-phase view could point at a 3s leaf while a 40s cycle was spread
    across many smaller leaves.  This groups only direct, non-overlapping leaves
    and exposes the residual wall gap without changing candidate calculations.
    """
    phases = profile.get('phases') if isinstance(profile.get('phases'), dict) else {}
    groups = {
        'input_restore_and_overlay': (
            'status_start','feature_read_and_input_restore','candle_cache_map_load',
            'candle_cache_row_overlay','scanner_hot_feature_overlay','orderflow_cache_read',
        ),
        'candidate_build_and_coverage': (
            'candidate_base_spike_merge','coverage_build_and_merge','quality_summary_and_requests',
        ),
        'publish_prepare_and_gate': (
            'publish_prepare_canonical_rows','publish_recheck_lanes','publish_entry_plan_chain',
            'publish_structure_freshness','publish_s2_lifecycle','publish_priority_requests',
            'publish_promotion_reseal','quality_priority_requests',
            'swing_entry_gate','publish_candle_urgent_after_final_gate_v1049',
            'seal_exact_keys',
        ),
        'post_handoff_observation': (
            'smart_structure_shadow','structure_lab','hot_watch_timing_v1148',
            'good_s2_lifecycle_v1148','key_spine_status_after_handoff_v1166',
        ),
        'execution_handoff_prepare': (
            's1_hold_commit_v1148','row_aggregation_and_promotion_stats',
        ),
        'candidate_writer': (
            'candidate_writer_full_row_audit','candidate_writer_lite_snapshot',
            'candidate_writer_compact_single_pass','candidate_writer_json_encode_and_ceiling',
            'candidate_writer_tmp_write_fsync','candidate_writer_atomic_replace',
            'candidate_writer_status_commit',
        ),
        'post_commit_and_display': (
            'post_commit_handoff_and_priority','display_cache_and_final_status',
        ),
    }
    rows=[]
    total_wall=0.0
    total_cpu=0.0
    consumed=[]
    for group, names in groups.items():
        wall=sum(float((phases.get(name) or {}).get('wall_sec') or 0.0) for name in names)
        cpu=sum(float((phases.get(name) or {}).get('cpu_sec') or 0.0) for name in names)
        present=[name for name in names if isinstance(phases.get(name),dict)]
        rows.append({'group':group,'wall_sec':round(wall,6),'cpu_sec':round(cpu,6),'phases':present})
        total_wall += wall
        total_cpu += cpu
        consumed.extend(present)
    rows.sort(key=lambda row:(float(row.get('wall_sec') or 0.0),float(row.get('cpu_sec') or 0.0)),reverse=True)
    return {
        'schema':'strategy_phase_group_totals_v1113',
        'groups':rows,
        'grouped_wall_sec':round(total_wall,6),
        'grouped_cpu_sec':round(total_cpu,6),
        'consumed_phase_count':len(set(consumed)),
        'excluded_aggregate_phases':['cycle_total','publish_total','candidate_compact_atomic_commit','quality_gate_and_exact_keys'],
        'policy':'measurement only; direct non-overlapping leaf groups; no gate/rank/trigger/target/OPEN change',
    }

def _v1027_finalize_cpu_profile(profile: Dict[str, Any], result: Any = None) -> Dict[str, Any]:
    nowv = now_ts()
    phases = profile.get('phases') if isinstance(profile.get('phases'), dict) else {}
    ranked_all = sorted(
        ({'phase': str(k), **dict(v)} for k, v in phases.items() if isinstance(v, dict)),
        key=lambda x: (float(x.get('cpu_sec') or 0.0), float(x.get('wall_sec') or 0.0)),
        reverse=True,
    )
    aggregate_phases = {'cycle_total', 'publish_total'}
    if any(str(k).startswith('candidate_writer_') for k in phases):
        aggregate_phases.add('candidate_compact_atomic_commit')
    ranked = [x for x in ranked_all if x.get('phase') not in aggregate_phases]
    cycle_wall = max(0.0, nowv - float(profile.get('cycle_started_ts') or nowv))
    cycle_cpu = float((phases.get('cycle_total') or {}).get('cpu_sec') or 0.0)
    accounted_cpu = sum(float(x.get('cpu_sec') or 0.0) for x in ranked)
    writer = load_json(PAPER_LATEST_WRITER_STATUS_V861, {}) if 'PAPER_LATEST_WRITER_STATUS_V861' in globals() else {}
    writer = writer if isinstance(writer, dict) else {}
    total = writer.get('candidate_total_commit_count_v1026')
    process_count = int(fnum(writer.get('candidate_process_commit_count_v1026'), default=0.0))
    total_num = int(fnum(total, default=0.0)) if total is not None else 0
    prior_total = max(0, total_num - process_count) if total is not None else None
    last_commit_pid = _v1026_nonnegative_int(writer.get('candidate_last_commit_pid_v1028')) if '_v1026_nonnegative_int' in globals() else None
    pid_match = bool(last_commit_pid is not None and last_commit_pid == os.getpid())
    candidate_commit_elapsed = float(profile.get('candidate_commit_elapsed_sec_v1031') or 0.0)
    post_commit_elapsed = max(0.0, cycle_wall - candidate_commit_elapsed) if candidate_commit_elapsed > 0 else 0.0
    unaccounted_cpu = max(0.0, cycle_cpu - accounted_cpu)
    phase_groups_v1113 = _v1113_phase_group_totals(profile)
    grouped_wall_v1113 = float(phase_groups_v1113.get('grouped_wall_sec') or 0.0)
    grouped_cpu_v1113 = float(phase_groups_v1113.get('grouped_cpu_sec') or 0.0)
    unaccounted_wall_v1113 = max(0.0, cycle_wall - grouped_wall_v1113)
    phase_groups_v1113['cycle_wall_sec'] = round(cycle_wall,6)
    phase_groups_v1113['cycle_cpu_sec'] = round(cycle_cpu,6)
    phase_groups_v1113['unaccounted_wall_sec'] = round(unaccounted_wall_v1113,6)
    phase_groups_v1113['unaccounted_wall_pct'] = round((unaccounted_wall_v1113 / cycle_wall * 100.0) if cycle_wall > 0 else 0.0,2)
    phase_groups_v1113['grouped_cpu_pct'] = round((grouped_cpu_v1113 / cycle_cpu * 100.0) if cycle_cpu > 0 else 0.0,2)
    profile.update({
        'schema': 'strategy_cpu_profile_v1031_cycle_scoped',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'cycle_wall_sec': round(cycle_wall, 6),
        'cycle_cpu_sec': round(cycle_cpu, 6),
        'candidate_commit_elapsed_sec_v1031': round(candidate_commit_elapsed, 6),
        'post_commit_elapsed_sec_v1031': round(post_commit_elapsed, 6),
        'full_cycle_elapsed_sec_v1031': round(cycle_wall, 6),
        'cycle_timing_scope_v1031': 'run_once_start_to_return',
        'status_last_sec_scope_v1031': 'last_completed_full_cycle',
        'profile_reset_scope_v1031': 'new profile object at every run_once start; one final snapshot at return/error',
        'accounted_phase_cpu_sec': round(accounted_cpu, 6),
        'unaccounted_cycle_cpu_sec_v1031': round(unaccounted_cpu, 6),
        'phase_cpu_accounting_pct_v1031': round((accounted_cpu / cycle_cpu * 100.0) if cycle_cpu > 0 else 0.0, 2),
        'measured_cpu_busy_pct_of_cycle': round((cycle_cpu / cycle_wall * 100.0) if cycle_wall > 0 else 0.0, 2),
        'phase_count': len(ranked),
        'top_phases': ranked[:12],
        'all_phases_by_wall_v1113': sorted(ranked, key=lambda row:float(row.get('wall_sec') or 0.0), reverse=True)[:32],
        'phase_group_totals_v1113': phase_groups_v1113,
        'candidate_rows': _v1165_count_value((result or {}).get('paper_latest_count'), (result or {}).get('s_count'), field='cpu_profile.candidate_rows') if isinstance(result, dict) else 0,
        'candidate_commit_restart_check_v1027': {
            'total_commit_count': total_num if total is not None else None,
            'current_process_commit_count': process_count,
            'prior_process_total': prior_total,
            'writer_pid_matches_current': pid_match,
            'restart_persistence_proven': bool(total is not None and prior_total is not None and prior_total >= 1 and process_count >= 1 and pid_match),
            'basis': 'v1026 total minus current-process count after v1027 strategy restart and first real commit',
        },
        'live_phase_v1028': _v1028_live_phase_snapshot(),
        'policy': 'measurement only: completed profile + live heartbeat phase; no S1/S2/S3, trigger, invalid, target, paper OPEN or ledger change',
    })
    save_json(STRATEGY_CPU_PROFILE_V1027, profile)
    return profile

CANDLE=BASE_DIR/"clean_candle_cache.json"

CANDLE_DELTA_V1014=BASE_DIR/"clean_candle_delta_v1014.jsonl"

FEATURE=BASE_DIR/"clean_feature_cache.json"

ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"

RISK=BASE_DIR/"clean_risk_filter_cache.json"

HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"

MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"

PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"

PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"

SCANNER_HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"

SCANNER_POOL=BASE_DIR/"clean_scanner_candidate_pool.json"

SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"

TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"

WS_TARGETS=BASE_DIR/"clean_ws_targets.json"

CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))

ENTRY_PLAN_STATE=BASE_DIR/"clean_strategy_entry_plan_state.json"

STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}

V597_OFFICIAL_STRUCTURE_KEYS = (
    "official_candle_source", "official_candle_age", "official_candle_intervals", "official_candle_cache_schema", "official_structure_source",
    "swing_high_price", "swing_low_price", "box_high_price", "box_low_price", "recent_high_price", "recent_low_price",
    "support_touch_count", "resistance_touch_count", "upper_wick_pct", "lower_wick_pct",
    "vwap_gap_pct", "ema5_gap_pct", "ema10_gap_pct", "ema20_gap_pct",
    "volume_ratio", "volume_expansion_pct", "breakout_hint", "sweep_reclaim_hint", "box_breakout_hint",
    "support_reclaim_hint", "resistance_reject_hint", "pullback_volume_contract", "reclaim_volume_expand",
    "long_upper_wick", "volume_expanding", "close_near_high",
    "structure_source_hydration_v913", "structure_source_hydrated_v913",
    "structure_source_hydrated_frames_v913", "structure_source_role_fields_v913",
)

def _v597_overlay_candle_cache(src: Dict[str, Any], candle_map: Dict[str, Dict[str, Any]], nowv: Optional[float] = None) -> Dict[str, Any]:
    if not isinstance(src, dict):
        return src
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    c = candle_map.get(t, {}) if t else {}
    add = _v597_candle_official_fields(c, nowv)
    if not add:
        return dict(src)
    rr = dict(src)
    for k, v in add.items():
        if rr.get(k) in (None, "", 0, 0.0) or k.startswith("official_"):
            rr[k] = v
    return rr

MAIN_DEPLOY_VERSION = "v2.13.764"

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

_V655_RISK_CACHE_MTIME: float = -1.0

_V655_RISK_CACHE_OBJ: Dict[str, Any] = {}

_V655_RISK_OPEN_SET: set = set()

def _v655_risk_cache() -> Dict[str, Any]:
    global _V655_RISK_CACHE_MTIME, _V655_RISK_CACHE_OBJ, _V655_RISK_OPEN_SET
    try:
        mt = RISK.stat().st_mtime if RISK.exists() else 0.0
    except Exception:
        mt = 0.0
    if mt != _V655_RISK_CACHE_MTIME:
        obj = load_json(RISK, {}) or {}
        _V655_RISK_CACHE_OBJ = obj if isinstance(obj, dict) else {}
        _V655_RISK_OPEN_SET = set(str(x).upper() for x in (_V655_RISK_CACHE_OBJ.get("open_tickers") or []))
        _V655_RISK_CACHE_MTIME = mt
    return _V655_RISK_CACHE_OBJ

def risk_bad(t:str)->List[str]:
    r=_v655_risk_cache(); cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in _V655_RISK_OPEN_SET: out.append("이미OPEN중")
    return out

def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]

def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)

def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)

def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)

def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)

def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)

def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)

def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }

def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"

VERSION = "strategy_worker_v0.801"

MAIN_VERSION = "v2.13.764"

MAIN_DEPLOY_VERSION = "v2.13.764"

CANDLE_URGENT_TARGETS = BASE_DIR / "clean_candle_urgent_targets.json"

CANDLE_URGENT_RESULT = BASE_DIR / "clean_candle_urgent_result.json"

CANONICAL_STRATEGY_SUMMARY = BASE_DIR / "clean_strategy_canonical_summary.json"

_STAGE_ORDER = {"S1": 3, "S2": 2, "S3": 1}

def _v510_num(*vals: Any, default: float = 0.0) -> float:
    return fnum(*vals, default=default)

def _v510_stage(row: Dict[str, Any]) -> str:
    st = str(row.get("s_stage") or row.get("candidate_grade") or row.get("stage") or row.get("grade") or "S3").upper()
    return st if st in ("S1", "S2", "S3") else "S3"

def _v510_uniq(xs: List[Any], maxn: int = 12) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in xs or []:
        s = str(x or "").strip()
        if not s or s in seen:
            continue
        seen.add(s); out.append(s)
        if len(out) >= maxn:
            break
    return out

def _v510_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

def _v521_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime)
    except Exception:
        return 999999.0

def _v521_row_age(row: Dict[str, Any], cache_age: float, *ts_keys: str) -> float:
    # 999999 means "age field missing", not "really stale".
    for k in ("age_sec", "cache_age_sec", "row_age_sec", "updated_age_sec"):
        a = _v510_num(row.get(k), default=-1.0)
        if 0 <= a < 999998:
            return a
    for k in ts_keys or ("updated_ts", "ts", "timestamp", "created_at", "event_ts"):
        ts = _v510_num(row.get(k), default=0.0)
        if ts > 1_000_000_000:
            return max(0.0, now_ts() - ts)
    return cache_age

def _v521_load_map_with_cache_age(path: Path, cache_name: str) -> Dict[str, Dict[str, Any]]:
    obj = load_json(path, {}) or {}
    c_age = _v521_file_age(path)
    out = map_rows(obj)
    top_ts = _v510_num(obj.get("updated_ts") if isinstance(obj, dict) else 0.0, default=0.0)
    top_age = max(0.0, now_ts() - top_ts) if top_ts > 1_000_000_000 else c_age
    for t, r in list(out.items()):
        rr = dict(r)
        rr.setdefault("_cache_name", cache_name)
        rr.setdefault("_cache_age_sec", min(c_age, top_age))
        rr.setdefault("_cache_updated_ts", top_ts or now_ts() - c_age)
        out[t] = rr
    return out

def _v521_hot_map() -> Dict[str, Dict[str, Any]]:
    """Normalize Scanner hot rows in place after the owner map made its one copy."""
    out = _v521_load_map_with_cache_age(SCANNER_HOT, "scanner_hot")
    c_age = _v521_file_age(SCANNER_HOT)
    for r in out.values():
        if not isinstance(r, dict):
            continue
        if "scanner_change_1m_pct" in r and "change_1m" not in r:
            r["change_1m"] = r.get("scanner_change_1m_pct")
        if "scanner_change_3m_pct" in r and "change_3m" not in r:
            r["change_3m"] = r.get("scanner_change_3m_pct")
        r.setdefault("hot_signal_age_sec", _v521_row_age(r, c_age, "updated_ts", "ts", "timestamp"))
        r.setdefault("hot_fresh", c_age <= 10)
        r.setdefault("scanner_hot_fresh", c_age <= 10)
    return out

def _v521_overlay_feature(src: Dict[str, Any], hot: Dict[str, Any]) -> Dict[str, Any]:
    if not hot:
        return dict(src)
    merged = dict(src)
    for k in ("scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m", "hot_signal_age_sec", "hot_fresh", "scanner_hot_fresh"):
        if merged.get(k) in (None, "", 0, 0.0, 999999, 999999.0):
            merged[k] = hot.get(k)
    if merged.get("change_1m") in (None, "", 0, 0.0) and hot.get("change_1m") is not None:
        merged["change_1m"] = hot.get("change_1m")
    if merged.get("change_3m") in (None, "", 0, 0.0) and hot.get("change_3m") is not None:
        merged["change_3m"] = hot.get("change_3m")
    merged["_scanner_hot_cache_age_sec"] = hot.get("_cache_age_sec", _v521_file_age(SCANNER_HOT))
    return merged

def _v521_age_from_sources(primary: Dict[str, Any], secondary: Dict[str, Any], cache_key: str, keys: Tuple[str, ...], default_cache_age: float = 999999.0) -> float:
    for row in (primary, secondary):
        for k in keys:
            a = _v510_num(row.get(k), default=-1.0)
            if 0 <= a < 999998:
                return a
    for row in (primary, secondary):
        c = _v510_num(row.get(cache_key), row.get("_cache_age_sec"), default=-1.0)
        if 0 <= c < 999998:
            return c
    return default_cache_age

def _v521_value_present(row: Dict[str, Any], *keys: str) -> bool:
    for k in keys:
        v = row.get(k)
        if v in (None, "", [], {}):
            continue
        try:
            if float(str(v).replace(",", "").replace("%", "")) != 0:
                return True
        except Exception:
            return True
    return False

def _v522_parse_age_item(item: Any) -> Tuple[str, float]:
    s = str(item or "").strip()
    m = re.search(r'(hot|micro|orderflow|price|quote|paper)\s+([0-9]+(?:\.[0-9]+)?)s', s)
    if not m:
        return s, 999999.0
    return m.group(1), _v510_num(m.group(2), default=999999.0)

def _v522_filter_stale_items(items: List[Any], strict: bool = True) -> List[str]:
    # A stale reason is valid only when the component is actually over TTL.
    ttl = {
        "hot": 35.0 if strict else 60.0,
        "micro": 20.0,
        "orderflow": 20.0,
        "price": 30.0,
        "quote": 20.0,
        "paper": 45.0,
    }
    out: List[str] = []
    for raw in items or []:
        comp, a = _v522_parse_age_item(raw)
        if comp in ttl:
            if a >= ttl[comp]:
                out.append(f"{comp} {a:.1f}s")
            continue
        s = str(raw or "").strip()
        if s:
            out.append(s)
    return _v510_uniq(out, 8)

def _v522_strip_freshness_text(raw: List[Any]) -> List[str]:
    # Old route may still pass "신선도재확인:hot 0.8s" as an existing reason.
    # Remove all freshness strings here; the single gate will re-add only real stale items.
    out: List[str] = []
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if "신선" in s or "final_entry_gate" in s:
            continue
        out.append(s)
    return out

def _v520_age_ok(age_val: float, limit: float) -> bool:
    return age_val < 999998 and age_val <= limit

def _v520_fresh_stale_items(src: Dict[str, Any], of: Dict[str, Any], hot_age: float, micro_age: float, order_age: float, price_age: float, quote_age: float, sealed_price: float, strict: bool = True) -> List[str]:
    """v522 single freshness gate.
    Age under TTL is fresh. Value/cache presence is a bonus, not a second stale route.
    """
    hot_cache_age = _v510_num(src.get("_scanner_hot_cache_age_sec"), src.get("_cache_age_sec"), default=999999.0)
    of_cache_age = _v510_num(of.get("_cache_age_sec"), default=999999.0)

    ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), src.get("scanner_change_1m_pct"), default=0.0)
    ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), src.get("scanner_change_3m_pct"), default=0.0)
    hot_present = max(abs(ch1), abs(ch3)) > 0 or _v521_value_present(src, "scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m")
    micro_present = _v521_value_present(of, "buy_ratio", "micro_trade_buy_ratio_30", "trade_buy_ratio", "spread_pct", "best_bid", "best_ask")
    order_present = micro_present or _v521_value_present(of, "orderflow_score", "sell_wall_ratio", "trade_count", "buy_count", "sell_count")
    quote_present = sealed_price > 0 or _v521_value_present(of, "quote_price", "current_price", "mid_price", "best_bid", "best_ask")
    price_present = sealed_price > 0 or _v521_value_present(src, "current_price", "price", "trade_price", "close", "last_price")

    # Missing embedded age uses cache age. If either age is fresh or value exists with fresh cache, it is fresh.
    hot_ok = bool(src.get("hot_fresh") or src.get("scanner_hot_fresh")) or _v520_age_ok(hot_age, 35) or (hot_cache_age <= 12 and hot_present)
    micro_ok = bool(of.get("micro_fresh")) or _v520_age_ok(micro_age, 20) or (of_cache_age <= 12 and micro_present)
    order_ok = bool(of.get("orderflow_fresh") or of.get("trade_fresh")) or _v520_age_ok(order_age, 20) or (of_cache_age <= 12 and order_present)
    quote_ok = bool(of.get("quote_fresh") or of.get("ws_fresh") or src.get("quote_fresh") or src.get("ws_fresh")) or _v520_age_ok(quote_age, 20) or (of_cache_age <= 12 and quote_present)
    price_ok = bool(src.get("price_reaction_fresh") or src.get("feature_fresh")) or _v520_age_ok(price_age, 30) or price_present

    stale: List[str] = []
    if strict and not hot_ok:
        stale.append(f"hot {hot_age:.1f}s")
    if not quote_ok:
        stale.append(f"quote {quote_age:.1f}s")
    if not micro_ok:
        stale.append(f"micro {micro_age:.1f}s")
    if strict and not order_ok:
        stale.append(f"orderflow {order_age:.1f}s")
    if not price_ok:
        stale.append(f"price {price_age:.1f}s")
    return _v522_filter_stale_items(stale, strict=strict)[:5]

def _v520_split_reasons(raw: List[Any], stale: List[str]) -> Tuple[List[str], List[str]]:
    decision: List[str] = []
    structure: List[str] = []
    raw = _v522_strip_freshness_text(raw)
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if s.startswith("구조:"):
            structure.append(s.replace("구조:", "", 1).strip())
            continue
        if "fresh urgent" in s or "급등 확인" in s:
            decision.append("급등확인")
            continue
        decision.append(s)
    stale = _v522_filter_stale_items(stale, strict=True)
    if stale:
        decision.append("신선도재확인:" + "/".join(stale[:3]))
    return _v510_uniq(decision, 12), _v510_uniq(structure, 8)

def _v520_normalize_reason_row(r: Dict[str, Any]) -> Dict[str, Any]:
    stale = _v522_filter_stale_items([str(x).strip() for x in (r.get("stale_reasons") or []) if str(x).strip()], strict=True)
    reasons, structures = _v520_split_reasons(list(r.get("s_stage_reasons") or []) + list(r.get("block_reasons") or []), stale)
    base_structures = r.get("structure_tags") if isinstance(r.get("structure_tags"), list) else []
    r["structure_tags"] = _v510_uniq(list(base_structures) + structures, 10)
    r["s_stage_reasons"] = reasons
    r["reason"] = " / ".join(reasons)
    r["freshness_status"] = "recheck" if stale else "fresh"
    if stale:
        r["stale_reasons"] = stale
    else:
        r["stale_reasons"] = []
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["structure_tags"] = r["structure_tags"]
    ctx["reasons"] = reasons
    ctx["freshness_status"] = r["freshness_status"]
    ctx["stale_reasons"] = r["stale_reasons"]
    r["entry_context"] = ctx
    return r

def _v510_price_reaction(row: Dict[str, Any], of: Dict[str, Any]) -> float:
    return _v510_num(of.get("price_reaction_pct"), of.get("reaction_pct"), row.get("price_reaction_pct"), row.get("change_1m"), row.get("price_change_1m"), default=0.0)

def _v510_spread(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("spread_pct"), row.get("spread_pct"), default=99.0)

def _v510_buy(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=0.0)

def _v524_sustain_detail(of: Dict[str, Any], row: Dict[str, Any]) -> Tuple[float, str, bool]:
    real_keys = (
        "buy_sustain_1m", "buy_sustain_60s", "buy_persist_1m",
        "buy_flow_1m", "buy_pressure_1m", "micro_buy_sustain_1m",
    )
    for k in real_keys:
        v = _v510_num(of.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    for k in real_keys:
        v = _v510_num(row.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    fb = _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=_v510_buy(of, row))
    return fb, "buy_ratio_fallback", False

def _v510_structure_tags(row: Dict[str, Any]) -> List[str]:
    tags: List[str] = []
    if row.get("sweep_reclaim_hint"): tags += ["저점유동성쓸림", "쓸림후빠른회복"]
    if row.get("breakout_hint"): tags += ["저항돌파후재테스트"]
    if _v510_num(row.get("vwap_gap_pct"), default=-9.0) >= -0.05: tags.append("VWAP방어")
    if _v510_num(row.get("ema5_gap_pct"), row.get("ma5_gap_pct"), default=-9.0) >= -0.10: tags.append("EMA방어")
    if row.get("volume_expanding"): tags.append("거래량확장")
    if _v510_num(row.get("change_3m"), default=0.0) >= 0.35: tags.append("돈흐름재유입")
    return _v510_uniq(tags, 8)

def _v510_risk_tags(row: Dict[str, Any], of: Dict[str, Any], hard: List[str]) -> List[str]:
    tags: List[str] = []
    spread = _v510_spread(of, row)
    buy = _v510_buy(of, row)
    if spread >= 0.35: tags.append("스프레드부담")
    if spread >= 0.35: tags.append("미끄러짐부담")
    if buy and buy < 0.58: tags.append("매수체결약함")
    if row.get("long_upper_wick"): tags.append("윗꼬리위험")
    if _v510_num(row.get("day_pos_pct"), default=50.0) > 94 and _v510_num(row.get("change_1m"), default=0.0) <= 0.05:
        tags.append("되돌림위험")
    for h in hard or []:
        if "매도" in h: tags.append("매도압력부담")
        if "스프레드" in h: tags.append("스프레드부담")
    return _v510_uniq(tags, 8)

def _v510_event_id(ticker: str, skey: str, lane: str, nowv: float) -> str:
    return f"{ticker}:{lane}:{skey}:{int(nowv // 10)}"

def _v545_guard_text(row: Dict[str, Any], labels: List[Any], keys: List[Any], risks: List[Any], structures: List[Any]) -> str:
    return " ".join(str(x) for x in ([
        row.get("strategy_label"), row.get("strategy"), row.get("strategy_key"), row.get("paper_strategy_key")
    ] + list(labels or []) + list(keys or []) + list(risks or []) + list(structures or []))).lower()

def _v545_has_any(hay: str, words: Tuple[str, ...]) -> bool:
    return any(str(w).lower() in hay for w in words)

def _v545_strategy_recheck_reasons(row: Dict[str, Any], react: float, buy: float, sustain: float, sustain20: float, spread: float, slippage: float, chg30: float, chg60: float, risks: List[Any], structures: List[Any], labels: List[Any], keys: List[Any]) -> Tuple[List[str], List[str]]:
    """v545 multi-strategy S1 quality guard.

    This reflects v543 win/loss analysis, but never blocks by itself.
    Compound loss-like S1 rows are moved to S2 recheck; very weak low-confidence rows
    may be marked as S3 observe. Global S1/S2/S3 thresholds and exit rules are unchanged.
    """
    hay = _v545_guard_text(row, labels, keys, risks, structures)
    risk_txt = " ".join(str(x) for x in (risks or []))
    struct_txt = " ".join(str(x) for x in (structures or []))
    spread_bad = spread >= 0.45 or slippage >= 0.45 or "스프레드부담" in risk_txt or "미끄러짐부담" in risk_txt
    spread_severe = spread >= 0.65 or slippage >= 0.65
    sustain_weak = sustain < 0.70 or sustain20 < 0.55
    buy_weak = buy < 0.70
    chase_like = react >= 0.30 or chg30 >= 0.45 or chg60 >= 1.20
    vwap_ema = ("VWAP" in struct_txt or "EMA" in struct_txt)
    money_structure = ("돈흐름" in struct_txt or "거래량" in struct_txt)

    recheck: List[str] = []
    observe: List[str] = []

    # 1) hot-rank 급등 재확인: v543에서 손실군은 추격성 가격반응 + 약한 지속 + 나쁜 스프레드/미끄러짐이 반복됨.
    if _v545_has_any(hay, ("hot-rank", "hot_rank", "hot rank", "급등 재확인")):
        if spread_bad and sustain_weak and chase_like:
            recheck.append("재확인: hot-rank 추격+스프레드/지속약함")
        if spread_severe and (buy_weak or sustain_weak):
            recheck.append("재확인: hot-rank 높은 미끄러짐+체결확인 부족")

    # 2) 주도흐름 유동보유: 단순 체결/스프레드 차이는 작았고, 손실군은 고점권/되돌림/채널상단 위험이 반복됨.
    if _v545_has_any(hay, ("leader_flow_adaptive_hold", "주도흐름 유동보유")):
        overheat_hits = sum(1 for w in ("고점권가격반응약함", "되돌림위험", "채널상단과열", "윗꼬리위험") if w in risk_txt or w in struct_txt)
        if overheat_hits >= 2:
            recheck.append("재확인: 주도흐름 고점권/되돌림 위험")
        elif overheat_hits >= 1 and chase_like and sustain_weak:
            recheck.append("재확인: 주도흐름 추격+지속 약화")

    # 3) 돈흐름 재가속: 성과는 손실우세이나 단순 평균값 차이는 애매함.
    #    그래서 최근반복손실/하드손실/윗꼬리 같은 명시 위험이 있고 확인값이 충분치 않을 때만 재확인.
    if _v545_has_any(hay, ("money_reaccel", "pullback_reaccel", "돈흐름 재가속")):
        loss_like = _v545_has_any(risk_txt, ("최근반복손실", "하드손실", "윗꼬리위험", "매도압력"))
        structure_ok = bool(vwap_ema and money_structure and buy >= 0.85 and sustain >= 0.75)
        if loss_like and not structure_ok:
            recheck.append("재확인: 돈흐름 손실유사 위험+확인부족")
        elif ("윗꼬리위험" in risk_txt or "매도압력" in risk_txt) and (buy < 0.80 or sustain < 0.75):
            recheck.append("재확인: 돈흐름 윗꼬리/매도압력")

    # 4) 돌파 초입: 표본은 작지만 손실군에 거래량없는돌파가 보임. 스프레드/미끄러짐과 같이 있을 때만 재확인.
    if _v545_has_any(hay, ("breakout_early", "돌파 초입")):
        no_volume_break = "거래량없는돌파" in risk_txt or "거래량없는돌파" in struct_txt
        if no_volume_break and (spread_bad or sustain_weak):
            recheck.append("재확인: 돌파 초입 거래량없는돌파+위험부담")

    # 5) 저점 VWAP 회복: 표본은 작지만 손익비가 나빴고, 손실군은 스프레드/미끄러짐+체결 약함이 반복됨.
    #    아주 약한 조합은 paper 즉시진입보다 S3 관찰로 내린다.
    if _v545_has_any(hay, ("sweep_vwap", "저점 vwap", "저점 VWAP")):
        if spread_bad and (buy < 0.75 or sustain < 0.70):
            observe.append("관찰: 저점 VWAP 스프레드/체결약함")

    return _v510_uniq(recheck, 5), _v510_uniq(observe, 3)

def _v532_build_canonical_entry_decision__L1136(row: Dict[str, Any]) -> Dict[str, Any]:
    """v535 canonical S1 판단 원천.
    normal_common은 기존 안정형 기준을 유지하고, 급등형은 별도 entry_profile로 paper-test한다.
    """
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), default=0.0)
    sustain20 = _v510_num(row.get("buy_sustain_20s"), row.get("buy_ratio_20s"), default=sustain)
    buy10 = _v510_num(row.get("buy_ratio_10s"), default=buy)
    spread = _v510_num(row.get("spread_pct"), default=99.0)
    slippage = _v510_num(row.get("slippage_pct"), default=spread)
    chg10 = _v510_num(row.get("price_chg_10s"), default=0.0)
    chg20 = _v510_num(row.get("price_chg_20s"), default=0.0)
    chg30 = _v510_num(row.get("price_chg_30s"), default=0.0)
    chg60 = _v510_num(row.get("price_chg_60s"), row.get("change_1m_pct"), default=0.0)
    accel10 = _v510_num(row.get("price_accel_10s"), default=0.0)
    accel20 = _v510_num(row.get("price_accel_20s"), default=0.0)
    spread_widen = _v510_num(row.get("spread_widening_10s"), default=0.0)
    sustain_real = bool(row.get("buy_sustain_1m_real"))
    stale = row.get("stale_reasons") if isinstance(row.get("stale_reasons"), list) else []
    risks = row.get("risk_tags") if isinstance(row.get("risk_tags"), list) else []
    structures = row.get("structure_tags") if isinstance(row.get("structure_tags"), list) else []
    hard_like = [str(x) for x in risks if any(w in str(x) for w in ("매도압력", "스프레드부담", "미끄러짐부담"))]
    upper_wick = any("윗꼬리" in str(x) for x in risks)
    sell_pressure = any("매도압력" in str(x) for x in risks)
    vwap_ema_ok = any(("VWAP" in str(x) or "EMA" in str(x)) for x in structures)
    money_ok = any(("돈흐름" in str(x) or "거래량" in str(x)) for x in structures)
    matched_labels = row.get("matched_strategy_labels") if isinstance(row.get("matched_strategy_labels"), list) else []
    matched_keys = row.get("matched_strategy_keys") if isinstance(row.get("matched_strategy_keys"), list) else []
    strategy_label = row.get("strategy_label") or row.get("strategy") or row.get("strategy_key") or "-"

    def ok_missing(checks: List[Dict[str, Any]]) -> Tuple[bool, List[Dict[str, Any]], List[str]]:
        missing = [c for c in checks if not c.get("ok")]
        return (len(missing) == 0), missing, [str(c.get("reason")) for c in missing if str(c.get("reason") or "").strip()]

    normal_checks = [
        {"name": "전략태그", "ok": True, "value": matched_labels or strategy_label, "need": "tag only", "reason": "태그", "weight": 0},
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "가격반응", "ok": react >= 0.35, "value": round(react,4), "need": ">=0.35", "reason": f"가격반응 {react:+.2f}% < +0.35%", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.70, "value": round(buy,4), "need": ">=0.70", "reason": f"매수체결 {buy:.2f} < 0.70", "weight": 1},
        {"name": "1분지속", "ok": bool(sustain_real and sustain >= 0.70), "value": round(sustain,4), "need": "real >=0.70", "reason": ("1분지속 실측없음" if not sustain_real else f"1분지속 {sustain:.2f} < 0.70"), "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.18, "value": round(spread,4), "need": "<=0.18", "reason": f"스프레드 {spread:.2f}% > 0.18%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.20, "value": round(slippage,4), "need": "<=0.20", "reason": f"미끄러짐 {slippage:.2f}% > 0.20%", "weight": 1},
        {"name": "강한위험", "ok": not bool(hard_like), "value": hard_like[:3], "need": "none", "reason": "위험부담:" + "/".join(hard_like[:3]) if hard_like else "통과", "weight": 1},
    ]
    normal_ok, normal_missing, normal_reasons = ok_missing(normal_checks)

    spike_signal = bool(chg20 >= 0.30 or chg30 >= 0.45 or react >= 0.70 or accel10 >= 0.18 or accel20 >= 0.22)
    late_chase = bool((chg60 >= 2.50 and (buy10 < 0.55 or spread > 0.85 or spread_widen > 0.35)) or upper_wick or (spread > 1.10) or (slippage > 1.20))
    spike_fast_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "급등초입", "ok": spike_signal, "value": {"chg20": round(chg20,3), "chg30": round(chg30,3), "react": round(react,3), "accel10": round(accel10,3)}, "need": "20s>=0.30 or 30s>=0.45 or react>=0.70", "reason": "급등초입 신호 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.55, "value": round(buy,4), "need": ">=0.55", "reason": f"급등형 매수체결 {buy:.2f} < 0.55", "weight": 1},
        {"name": "짧은매수", "ok": (sustain20 >= 0.55 or buy10 >= 0.65), "value": {"buy10": round(buy10,3), "sustain20": round(sustain20,3)}, "need": "20s>=0.55 or 10s>=0.65", "reason": f"짧은 매수세 부족 10s {buy10:.2f} / 20s {sustain20:.2f}", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.85, "value": round(spread,4), "need": "<=0.85", "reason": f"급등형 스프레드 {spread:.2f}% > 0.85%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.85, "value": round(slippage,4), "need": "<=0.85", "reason": f"급등형 미끄러짐 {slippage:.2f}% > 0.85%", "weight": 1},
        {"name": "최소체결", "ok": buy >= 0.40 and sustain20 >= 0.35, "value": {"buy": round(buy,3), "sustain20": round(sustain20,3)}, "need": "buy>=0.40 & 20s>=0.35", "reason": "급등형 최소 체결/지속 미달", "weight": 2},
        {"name": "늦은추격", "ok": not late_chase, "value": {"chg60": round(chg60,3), "spread_widen": round(spread_widen,3)}, "need": "not late chase", "reason": "늦은추격 위험", "weight": 2},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "급등형 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_fast_ok, spike_fast_missing, spike_fast_reasons = ok_missing(spike_fast_checks)

    runner_signal = bool(react >= 0.80 or chg60 >= 1.20 or chg30 >= 0.90)
    spike_runner_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "runner신호", "ok": runner_signal, "value": {"react": round(react,3), "chg60": round(chg60,3)}, "need": "react>=0.80 or 60s>=1.20", "reason": "runner 가격힘 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.68, "value": round(buy,4), "need": ">=0.68", "reason": f"runner 매수체결 {buy:.2f} < 0.68", "weight": 1},
        {"name": "지속", "ok": sustain20 >= 0.65 and sustain >= 0.60, "value": {"20s": round(sustain20,3), "1m": round(sustain,3)}, "need": "20s>=0.65 and 1m>=0.60", "reason": "runner 매수지속 부족", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.55, "value": round(spread,4), "need": "<=0.55", "reason": f"runner 스프레드 {spread:.2f}% > 0.55%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.65, "value": round(slippage,4), "need": "<=0.65", "reason": f"runner 미끄러짐 {slippage:.2f}% > 0.65%", "weight": 1},
        {"name": "구조", "ok": bool(vwap_ema_ok and money_ok), "value": structures[:4], "need": "VWAP/EMA + money", "reason": "runner 구조 부족", "weight": 1},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "runner 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_runner_ok, spike_runner_missing, spike_runner_reasons = ok_missing(spike_runner_checks)

    spike_ok = bool(spike_fast_ok or spike_runner_ok)
    spike_watch = bool(spike_signal or runner_signal)
    spike_missing = spike_runner_missing if spike_runner_ok else spike_fast_missing
    spike_reasons = spike_runner_reasons if spike_runner_ok else spike_fast_reasons
    spike_checks = spike_runner_checks if spike_runner_ok else spike_fast_checks

    if normal_ok:
        entry_profile = "normal_common"
        exit_profile = "normal_exit"
        active_checks = normal_checks
        active_missing = normal_missing
        active_reasons = normal_reasons
    elif spike_ok:
        # v536: 급등형 진입은 spike 하나로만 기록한다. fast/runner 세부분류는 exit_reason/성과에서 본다.
        entry_profile = "spike"
        exit_profile = "spike_trailing"
        active_checks = spike_checks
        active_missing = spike_missing
        active_reasons = spike_reasons
    else:
        entry_profile = "watch"
        exit_profile = "watch_exit"
        active_checks = spike_fast_checks if spike_watch else normal_checks
        active_missing = spike_fast_missing if spike_watch else normal_missing
        active_reasons = spike_fast_reasons if spike_watch else normal_reasons

    raw_s1_allowed = bool(normal_ok or spike_ok)
    if raw_s1_allowed:
        recheck_guard_reasons, observe_guard_reasons = _v545_strategy_recheck_reasons(row, react, buy, sustain, sustain20, spread, slippage, chg30, chg60, risks, structures, matched_labels, matched_keys)
    else:
        recheck_guard_reasons, observe_guard_reasons = [], []
    # v547 surgery: S2 재확인은 출력부에서 꾸미지 않고, canonical decision에서 stage로 봉인한다.
    # - raw S1 손실유사 조합은 S2 재확인/S3 관찰로 분리한다.
    # - raw S3라도 구조/확인값이 살아 있고 부족값이 회복 가능한 경우는 S2 재확인으로 남긴다.
    block_score_pre = sum(int(c.get("weight", 1)) for c in active_missing)
    structure_present = bool(matched_labels or matched_keys or structures)
    strong_confirm = bool(buy >= 0.70 and sustain >= 0.70)
    partial_confirm = bool(buy >= 0.55 and sustain >= 0.55)
    severe_risk = bool(spread >= 1.20 or slippage >= 1.20 or (buy < 0.40 and sustain < 0.40))
    recoverable_recheck_reasons: List[str] = []
    if (not observe_guard_reasons) and (not severe_risk) and structure_present:
        if stale and (partial_confirm or react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 신선도 갱신 대기")
        if (spread > 0.18 or slippage > 0.20) and (strong_confirm or (react >= 0.30 and partial_confirm)):
            recoverable_recheck_reasons.append("재확인: 스프레드/미끄러짐 회복 대기")
        if (buy < 0.70 or sustain < 0.70) and (buy >= 0.55 or sustain >= 0.55) and (react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 체결/1분지속 회복 대기")
        if react < 0.35 and strong_confirm and (spread <= 0.85 and slippage <= 0.85):
            recoverable_recheck_reasons.append("재확인: 가격반응 확인 대기")
    recoverable_recheck_reasons = _v510_uniq(recoverable_recheck_reasons, 4)
    # v732: 전략에 억지로 맞추는 구조가 아니라, 공통 상승포착을 본선으로 둔다.
    # 전략명은 왜 오를 수 있는지 설명하는 라벨이고, S2→S1 승급 집계는 S2 row만 본다.
    promo_hay = " ".join(str(x) for x in ([strategy_label] + list(matched_labels or []) + list(matched_keys or []) + list(structures or []))).lower()
    if any(w in promo_hay for w in ("주도흐름", "leader_flow", "leader", "유동보유")):
        promo_family_v732 = "주도흐름"
    elif any(w in promo_hay for w in ("돈흐름", "money_flow", "flow_reaccel", "재가속")):
        promo_family_v732 = "돈흐름"
    elif any(w in promo_hay for w in ("저점", "vwap", "sweep_vwap", "vwap 회복", "vwap회복")):
        promo_family_v732 = "저점VWAP"
    elif any(w in promo_hay for w in ("돌파", "breakout")):
        promo_family_v732 = "돌파"
    elif any(w in promo_hay for w in ("hot-rank", "hot_rank", "급등", "spike")):
        promo_family_v732 = "급등감지"
    else:
        promo_family_v732 = "기타"

    s2_to_s1_promotion_reasons_v732: List[str] = []
    blocked_from_promotion_v732: List[str] = []  # v795: 진짜 hard-block만 남기기 위한 호환 필드. 전략별 부족은 차단문으로 쓰지 않는다.
    promotion_recheck_notes_v795: List[str] = []
    common_uprising_reasons_v732: List[str] = []
    common_uprising_blocked_v732: List[str] = []
    observe_row_only = bool(row.get("s3_observe_v732") or row.get("s3_observe_v729") or row.get("s3_observe_v728") or row.get("s3_observe_v727") or str(row.get("strategy_key") or "").startswith("coin_quality_s3_observe"))

    safe_risk_for_promotion = bool(
        not stale
        and not hard_like
        and not sell_pressure
        and not upper_wick
        and spread <= 0.18
        and slippage <= 0.20
        and sustain_real
        and not observe_row_only
    )
    structure_hint_for_common = bool(structure_present or vwap_ema_ok or money_ok or matched_labels or matched_keys)

    common_uprising_pass_v732 = bool(
        safe_risk_for_promotion
        and structure_hint_for_common
        and (
            (react >= 0.30 and buy >= 0.65 and sustain >= 0.70)
            or (0.22 <= react < 0.35 and buy >= 0.78 and sustain >= 0.75)
            or (react >= 0.45 and buy >= 0.70 and sustain >= 0.58)
        )
    )
    if common_uprising_pass_v732:
        common_uprising_reasons_v732.append("공통 상승포착: 가격반응+체결+지속+위험낮음")
        s2_to_s1_promotion_reasons_v732.append("공통 상승포착 S2→S1: 전략라벨 무관 상승조건 통과")
    else:
        if observe_row_only:
            common_uprising_blocked_v732.append("S3 관찰 row는 상승포착 OPEN 제외")
        if stale:
            common_uprising_blocked_v732.append("신선도 부족")
        if hard_like or sell_pressure or upper_wick:
            common_uprising_blocked_v732.append("위험태그/매도압력 우세")
        if spread > 0.18 or slippage > 0.20:
            common_uprising_blocked_v732.append("스프레드/미끄러짐 부담")
        if not sustain_real:
            common_uprising_blocked_v732.append("1분지속 실측없음")
        if not structure_hint_for_common:
            common_uprising_blocked_v732.append("구조 힌트 부족")
        if react < 0.22:
            common_uprising_blocked_v732.append("가격반응 부족")
        if buy < 0.65:
            common_uprising_blocked_v732.append("매수체결 부족")
        if sustain < 0.58:
            common_uprising_blocked_v732.append("1분지속 부족")

    # v795: 전략/구조 라벨은 단타 후보를 나누는 벽이 아니라 설명·재확인·복기 태그다.
    # 공통 상승포착을 통과하지 못한 이유는 promotion_recheck_notes_v795에 남기되,
    # s2_to_s1_promotion_blocked_v732에는 넣지 않는다. 그래야 전략별 부족문구가 S1 보류문으로 작동하지 않는다.
    if not common_uprising_pass_v732:
        if observe_row_only:
            promotion_recheck_notes_v795.append("S3 관찰/복기 row: 상승포착 심사 제외")
        elif not safe_risk_for_promotion:
            if stale:
                promotion_recheck_notes_v795.append(f"{promo_family_v732} 신선도 부족: 재확인 미충족")
            if hard_like or sell_pressure or upper_wick:
                promotion_recheck_notes_v795.append(f"{promo_family_v732} 위험태그 우세: 하드위험 보류")
            if spread > 0.18 or slippage > 0.20:
                promotion_recheck_notes_v795.append(f"{promo_family_v732} 스프레드/미끄러짐 부담: 실행위험 재확인")
            if not sustain_real:
                promotion_recheck_notes_v795.append(f"{promo_family_v732} 1분지속 실측없음: source 재확인")
        if promo_family_v732 == "급등감지":
            if buy < 0.55 or sustain20 < 0.55 or sustain < 0.55:
                promotion_recheck_notes_v795.append("급등감지 체결/짧은지속 부족: 재확인 미충족")
        elif promo_family_v732 == "주도흐름":
            if sustain < 0.58:
                promotion_recheck_notes_v795.append("주도흐름 1분지속 부족: 재확인 미충족")
            elif buy < 0.65:
                promotion_recheck_notes_v795.append("주도흐름 매수체결 부족: 재확인 미충족")
            elif react < 0.22:
                promotion_recheck_notes_v795.append("주도흐름 가격반응 부족: 재확인 미충족")
        elif promo_family_v732 == "돈흐름":
            if buy < 0.65 or sustain < 0.58:
                promotion_recheck_notes_v795.append("돈흐름 체결지속 부족: 재확인 미충족")
        elif promo_family_v732 == "저점VWAP":
            if not vwap_ema_ok:
                promotion_recheck_notes_v795.append("저점VWAP 회복근거 부족: 선반응 재확인")
            elif buy < 0.65 or sustain < 0.58:
                promotion_recheck_notes_v795.append("저점VWAP 체결지속 부족: 재확인 미충족")
        elif promo_family_v732 == "돌파":
            if react < 0.35:
                promotion_recheck_notes_v795.append("돌파 가격반응 부족: 재확인 미충족")
            elif sustain20 < 0.60 or sustain < 0.58:
                promotion_recheck_notes_v795.append("돌파 짧은지속 부족: 재확인 미충족")

    common_uprising_reasons_v732 = _v510_uniq(common_uprising_reasons_v732, 3)
    common_uprising_blocked_v732 = _v510_uniq(common_uprising_blocked_v732, 5)
    blocked_from_promotion_v732 = _v510_uniq(blocked_from_promotion_v732, 5)
    promotion_recheck_notes_v795 = _v510_uniq(promotion_recheck_notes_v795, 5)
    s2_to_s1_promotion_reasons_v732 = _v510_uniq(s2_to_s1_promotion_reasons_v732, 3)
    s2_to_s1_promoted_v732 = bool(s2_to_s1_promotion_reasons_v732 and not blocked_from_promotion_v732)
    if s2_to_s1_promoted_v732:
        recoverable_recheck_reasons = [r for r in recoverable_recheck_reasons if all(w not in str(r) for w in ("가격반응", "체결/1분지속", "스프레드/미끄러짐"))]
        active_missing = [c for c in active_missing if str(c.get("name") or "") not in ("가격반응", "매수체결", "1분지속", "스프레드", "미끄러짐", "S2재확인", "S3관찰")]
        active_reasons = [r for r in active_reasons if all(w not in str(r) for w in ("가격반응", "매수체결", "1분지속", "스프레드", "미끄러짐"))]
        active_checks = list(active_checks) + [{"name": "공통상승포착", "ok": True, "value": common_uprising_reasons_v732, "need": "rising coin capture", "reason": "통과", "weight": 0}]
        entry_profile = "normal_common"
        exit_profile = "normal_exit"

    recheck_all_reasons = _v510_uniq(list(recheck_guard_reasons) + list(recoverable_recheck_reasons), 6)
    if s2_to_s1_promoted_v732:
        recheck_all_reasons = [r for r in recheck_all_reasons if "가격반응" not in str(r)]
        observe_guard_reasons = []
    guard_reasons = list(recheck_all_reasons) + list(observe_guard_reasons)
    s1_allowed = bool((raw_s1_allowed and not guard_reasons) or s2_to_s1_promoted_v732)
    if guard_reasons:
        active_missing = list(active_missing) + [
            {"name": "S2재확인" if str(reason).startswith("재확인") else "S3관찰", "ok": False, "value": reason, "need": "recheck/observe", "reason": reason, "weight": 1}
            for reason in guard_reasons
        ]
        active_reasons = list(active_reasons) + guard_reasons
    block_score = sum(int(c.get("weight", 1)) for c in active_missing)
    s2_recheck = bool((recheck_all_reasons and not observe_guard_reasons) or ((not guard_reasons) and (not severe_risk) and structure_present and block_score <= 6 and ((react >= 0.15 and buy >= 0.55) or spike_signal or runner_signal or strong_confirm)))
    near = bool(block_score <= 3 or bool(recoverable_recheck_reasons))
    passed = [str(c.get("name")) for c in active_checks if c.get("ok")]
    raw_entry_profile = entry_profile
    if guard_reasons:
        entry_profile = "watch"
        exit_profile = "watch_exit"
    return {
        "schema": "canonical_entry_decision_v732_promotion_stage_spine",
        "version": VERSION,
        "strategy_role": "tag",
        "entry_profile": entry_profile,
        "exit_profile": exit_profile,
        "profile_family": "spike" if entry_profile == "spike" else ("normal" if entry_profile == "normal_common" else "watch"),
        "matched_strategy_keys": matched_keys,
        "matched_strategy_labels": matched_labels or [str(strategy_label)],
        "gate_pass": s1_allowed,
        "raw_s1_allowed": raw_s1_allowed,
        "s1_allowed": s1_allowed,
        "s2_to_s1_promoted_v732": bool(s2_to_s1_promoted_v732),
        "s2_to_s1_promotion_reasons_v732": s2_to_s1_promotion_reasons_v732,
        "s2_to_s1_promotion_blocked_v732": blocked_from_promotion_v732,
        "s2_to_s1_promotion_recheck_notes_v795": promotion_recheck_notes_v795,
        "s2_to_s1_promotion_family_v732": promo_family_v732,
        "common_uprising_pass_v732": bool(common_uprising_pass_v732),
        "common_uprising_reasons_v732": common_uprising_reasons_v732,
        "common_uprising_blocked_v732": common_uprising_blocked_v732,
        "s1_recheck_guard": bool(guard_reasons),
        "s1_recheck_guard_reasons": guard_reasons,
        "s1_recheck_reasons": recheck_all_reasons,
        "s2_recheck_reasons": recheck_all_reasons,
        "s1_observe_reasons": observe_guard_reasons,
        "s1_recheck_basis": "v547 surgery: recheck reasons are sealed as visible S2 in canonical stage spine, not patched in output",
        "s2_recheck": bool(s2_recheck and not s1_allowed),
        "recoverable_recheck_reasons": recoverable_recheck_reasons,
        "action": "paper_open_candidate" if s1_allowed else ("recheck" if s2_recheck else "observe"),
        "freshness_ok": not bool(stale),
        "stale_reasons": list(stale),
        "checks": active_checks,
        "passed_conditions": passed,
        "missing_conditions": active_reasons,
        "missing_names": [str(c.get("name")) for c in active_missing],
        "block_count": len(active_missing),
        "block_score": block_score,
        "s1_distance": block_score,
        "s1_near_miss": near,
        "s1_near_miss_level": "near" if near else ("mid" if block_score <= 5 else "far"),
        "display_reasons": active_reasons,
        "profile_decisions": {
            "normal_common": {"pass": normal_ok, "missing": normal_reasons[:6]},
            "spike": {"pass": spike_ok, "missing": spike_reasons[:6], "fast_pass": spike_fast_ok, "runner_pass": spike_runner_ok},
            "watch": {"pass": False, "missing": active_reasons[:6]},
            "raw_entry_profile": raw_entry_profile,
        },
        "metrics": {
            "price_reaction_pct": react,
            "price_chg_10s": chg10,
            "price_chg_20s": chg20,
            "price_chg_30s": chg30,
            "price_chg_60s": chg60,
            "price_accel_10s": accel10,
            "price_accel_20s": accel20,
            "buy_ratio": buy,
            "buy_ratio_10s": buy10,
            "buy_sustain_20s": sustain20,
            "buy_sustain_1m": sustain,
            "buy_sustain_1m_real": sustain_real,
            "spread_pct": spread,
            "slippage_pct": slippage,
            "spread_widening_10s": spread_widen,
        },
        "policy": "v732: common uprising pass is resealed to actual S1 before publish; strategy family remains label/diagnostic.",
    }

def _v532_apply_canonical_entry_decision__L1469(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    dec = _v532_build_canonical_entry_decision(row)
    row["canonical_entry_decision"] = dec
    row["common_entry_decision"] = dec
    row["common_entry_pass"] = bool(dec.get("s1_allowed"))
    row["common_entry_schema"] = dec.get("schema")
    row["strategy_role"] = "tag"
    row["entry_profile"] = dec.get("entry_profile")
    row["exit_profile"] = dec.get("exit_profile")
    row["profile_family"] = dec.get("profile_family")
    row["profile_decisions"] = dec.get("profile_decisions", {})
    row["s1_checklist"] = dec.get("checks", [])
    row["s1_passed_conditions"] = dec.get("passed_conditions", [])
    row["s1_missing_conditions"] = dec.get("missing_conditions", [])
    row["s1_missing_names"] = dec.get("missing_names", [])
    row["s1_block_count"] = dec.get("block_count", 0)
    row["s1_block_score"] = dec.get("block_score", 0)
    row["s1_distance"] = dec.get("s1_distance", 0)
    row["s1_near_miss"] = bool(dec.get("s1_near_miss"))
    row["s1_near_miss_level"] = dec.get("s1_near_miss_level")
    row["s1_short_reason"] = " / ".join(str(x) for x in (dec.get("display_reasons") or [])[:4]) if dec.get("display_reasons") else "S1 조건 통과"
    row["s2_to_s1_promoted_v732"] = bool(dec.get("s2_to_s1_promoted_v732"))
    row["s2_to_s1_promotion_reasons_v732"] = dec.get("s2_to_s1_promotion_reasons_v732") or []
    row["s2_to_s1_promotion_blocked_v732"] = dec.get("s2_to_s1_promotion_blocked_v732") or []
    row["s2_to_s1_promotion_recheck_notes_v795"] = dec.get("s2_to_s1_promotion_recheck_notes_v795") or []
    row["s2_to_s1_promotion_family_v732"] = dec.get("s2_to_s1_promotion_family_v732") or "-"
    row["common_uprising_pass_v732"] = bool(dec.get("common_uprising_pass_v732"))
    row["common_uprising_reasons_v732"] = dec.get("common_uprising_reasons_v732") or []
    row["common_uprising_blocked_v732"] = dec.get("common_uprising_blocked_v732") or []
    observe_row_only_v732 = bool(row.get("s3_observe_v732") or row.get("s3_observe_v729") or row.get("s3_observe_v728") or row.get("s3_observe_v727") or str(row.get("strategy_key") or "").startswith("coin_quality_s3_observe"))
    if bool(dec.get("s1_allowed")) and not observe_row_only_v732:
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S1"
        row["open_eligible"] = True
        row["paper_bot_open"] = True
        row["trade_ready"] = True
    elif observe_row_only_v732:
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S3"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
        row["recheck_state"] = "S3 관찰/복기"
    elif bool(dec.get("s2_recheck") or dec.get("action") == "recheck"):
        # v547: 재확인 사유가 있으면 출력 보정이 아니라 canonical stage를 S2로 봉인한다.
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S2"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
        row["recheck_state"] = "S2 재확인"
        row["s2_recheck_reasons"] = dec.get("s2_recheck_reasons") or dec.get("s1_recheck_reasons") or []
    elif _v510_stage(row) == "S1":
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S3"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
    else:
        st = _v510_stage(row)
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = st
        if st != "S1":
            row["open_eligible"] = False
            row["paper_bot_open"] = False
            row["trade_ready"] = False
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k in (
        "canonical_entry_decision", "common_entry_decision", "common_entry_pass", "common_entry_schema", "strategy_role",
        "entry_profile", "exit_profile", "profile_family", "profile_decisions",
        "s1_checklist", "s1_passed_conditions", "s1_missing_conditions", "s1_missing_names",
        "s1_block_count", "s1_block_score", "s1_distance", "s1_near_miss", "s1_near_miss_level", "s1_short_reason", "s2_recheck_reasons", "recheck_state", "s2_to_s1_promoted_v732", "s2_to_s1_promotion_reasons_v732", "s2_to_s1_promotion_blocked_v732", "s2_to_s1_promotion_family_v732", "common_uprising_pass_v732", "common_uprising_reasons_v732", "common_uprising_blocked_v732",
    ):
        ctx[k] = row.get(k)
    row["entry_context"] = ctx
    return row

def _v553_as_list(v: Any) -> List[str]:
    if v in (None, "", [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        if isinstance(x, dict):
            txt = str(x.get("reason") or x.get("name") or x.get("value") or "").strip()
        else:
            txt = str(x).strip()
        if txt and txt not in out:
            out.append(txt)
    return out

def _v553_has(txt: str, words: Tuple[str, ...]) -> bool:
    low = str(txt or "").lower()
    return any(str(w).lower() in low for w in words)

def _v553_bucket_reason(txt: str) -> str:
    t = str(txt or "").strip()
    if not t:
        return "other"
    if t.startswith("구조:") or _v553_has(t, ("저점", "쓸림", "VWAP", "EMA", "거래량확장", "돈흐름", "돌파", "재돌파", "주도", "상대강도", "눌림")):
        # 부족/위험 문장에 VWAP 같은 단어가 섞일 수 있으니 위험/부족을 먼저 제외한다.
        if _v553_has(t, ("부족", "미확인", "실패", "위험", "과다", "약함", "대기", "재확인", "차단", "손실", "고점끝물")):
            pass
        else:
            return "structure"
    if t.startswith("재확인") or _v553_has(t, ("갱신 대기", "회복 대기", "확인 대기", "hot-rank 급등 재확인", "신선도 재확인")):
        return "recheck"
    if _v553_has(t, ("스프레드", "미끄러짐", "매도", "윗꼬리", "되돌림", "늦은추격", "추격", "하드손실", "반복손실", "고점끝물", "거래대금부족", "대형주는시장참고")):
        return "risk"
    if _v553_has(t, ("micro", "시세정보", "정보보강", "신선도", "오래됨", "stale", "quote", "ws")):
        return "freshness"
    if _v553_has(t, ("부족", "미달", "약함", "미확인", "과다", "<", ">")):
        return "block"
    return "other"

def _v553_confirm_signals(row: Dict[str, Any], dec: Dict[str, Any]) -> List[str]:
    sig: List[str] = []
    passed = _v553_as_list(dec.get("passed_conditions") or row.get("s1_passed_conditions"))
    metrics = dec.get("metrics") if isinstance(dec.get("metrics"), dict) else {}
    react = _v510_num(metrics.get("price_reaction_pct"), row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(metrics.get("buy_ratio"), row.get("buy_ratio"), default=-1.0)
    sustain = _v510_num(metrics.get("buy_sustain_1m"), row.get("buy_sustain_1m"), default=-1.0)
    spread = _v510_num(metrics.get("spread_pct"), row.get("spread_pct"), default=99.0)
    slip = _v510_num(metrics.get("slippage_pct"), row.get("slippage_pct"), default=spread)
    if "신선도" in passed or dec.get("freshness_ok"):
        sig.append("신선도 통과")
    if react >= 0.35:
        sig.append(f"가격반응 통과 {react:+.2f}%")
    if buy >= 0.70:
        sig.append(f"매수체결 통과 {buy:.2f}")
    if sustain >= 0.70:
        sig.append(f"1분지속 통과 {sustain:.2f}")
    if spread <= 0.18:
        sig.append(f"스프레드 정상 {spread:.2f}%")
    if slip <= 0.20:
        sig.append(f"미끄러짐 정상 {slip:.2f}%")
    for p in passed:
        if p in {"급등초입", "짧은매수", "runner신호", "구조"} and p not in sig:
            sig.append(str(p) + " 통과")
    return _v510_uniq(sig, 10)

def _v553_apply_reason_taxonomy__L1619(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    raw_reasons = _v553_as_list(row.get("s_stage_reasons") or row.get("reason"))
    structures = _v510_uniq(_v553_as_list(row.get("structure_tags")) + _v553_as_list(row.get("matched_strategy_labels")), 12)
    risk_tags = _v510_uniq(_v553_as_list(row.get("risk_tags")), 12)
    freshness = _v510_uniq(_v553_as_list(row.get("stale_reasons")), 10)
    rechecks = _v510_uniq(_v553_as_list(dec.get("s2_recheck_reasons")) + _v553_as_list(row.get("s2_recheck_reasons")), 10)
    blocks = _v510_uniq(_v553_as_list(dec.get("missing_conditions")) + _v553_as_list(row.get("s1_missing_conditions")), 12)

    # 기존 s_stage_reasons/reason에 섞인 텍스트를 의미별로 분리한다.
    for txt in raw_reasons:
        b = _v553_bucket_reason(txt)
        clean = txt.replace("구조:", "").strip()
        if b == "structure":
            structures.append(clean)
        elif b == "risk":
            risk_tags.append(clean)
        elif b == "freshness":
            freshness.append(clean)
        elif b == "recheck":
            rechecks.append(clean)
        elif b == "block":
            blocks.append(clean)

    structures = _v510_uniq(structures, 12)
    risk_tags = _v510_uniq(risk_tags, 12)
    freshness = _v510_uniq(freshness, 10)
    rechecks = _v510_uniq(rechecks, 10)
    blocks = _v510_uniq(blocks, 12)
    confirm = _v553_confirm_signals(row, dec)

    # 진입근거는 좋은 구조 + 실제 확인 통과만 넣는다. 위험/부족/재확인은 절대 섞지 않는다.
    entry_reasons = _v510_uniq(structures[:5] + confirm[:5], 10)
    if not entry_reasons and bool(dec.get("s1_allowed")):
        entry_reasons = ["최종확인 통과"]

    row["reason_taxonomy_schema"] = "v553_entry_structure_confirm_risk_split"
    row["entry_structure_tags"] = structures
    row["confirm_signals"] = confirm
    row["execution_risk_tags"] = risk_tags
    row["freshness_flags"] = freshness
    row["recheck_reasons"] = rechecks
    row["block_reasons"] = blocks
    row["entry_reasons"] = entry_reasons
    row["final_entry_reasons"] = entry_reasons
    row["trade_ready_reasons"] = entry_reasons if bool(row.get("trade_ready") or row.get("open_eligible") or _v510_stage(row) == "S1") else []
    row["risk_tags"] = risk_tags
    row["structure_risk_tags"] = risk_tags
    row["missing_info"] = _v510_uniq(rechecks + blocks + freshness, 12)
    row["entry_reason_policy"] = "v553: 진입근거는 구조/확인만, 위험·재확인·부족은 별도 필드로 분리"

    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k in (
        "reason_taxonomy_schema", "entry_structure_tags", "confirm_signals", "execution_risk_tags",
        "freshness_flags", "recheck_reasons", "block_reasons", "entry_reasons", "final_entry_reasons",
        "trade_ready_reasons", "risk_tags", "structure_risk_tags", "missing_info", "entry_reason_policy",
    ):
        ctx[k] = row.get(k)
    row["entry_context"] = ctx
    return row

def _v554_price_from_gap(price: float, gap_pct: float) -> float:
    try:
        if price <= 0:
            return 0.0
        denom = 1.0 + (float(gap_pct) / 100.0)
        if abs(denom) < 0.0001:
            return 0.0
        return price / denom
    except Exception:
        return 0.0

def _v554_pct_to_price(price: float, pctv: float) -> float:
    try:
        return price * (1.0 + float(pctv) / 100.0) if price > 0 else 0.0
    except Exception:
        return 0.0

def _v554_pct_between(a: float, b: float) -> float:
    return ((a - b) / b * 100.0) if b else 0.0

def _v554_round_price(x: float) -> float:
    if not x or x <= 0:
        return 0.0
    if x >= 100000:
        return round(x, -2)
    if x >= 10000:
        return round(x, -1)
    if x >= 1000:
        return round(x, 0)
    if x >= 100:
        return round(x, 1)
    if x >= 10:
        return round(x, 2)
    if x >= 1:
        return round(x, 3)
    return round(x, 5)

def _v554_strategy_family(row: Dict[str, Any]) -> str:
    sk = str(row.get("strategy_key") or row.get("paper_strategy_key") or "").lower()
    labels = " ".join(str(x) for x in (row.get("matched_strategy_labels") or [])) + " " + str(row.get("strategy_label") or row.get("strategy") or "")
    hay = (sk + " " + labels).lower()
    if "money_reaccel" in hay or "돈흐름 재가속" in labels:
        return "money_reaccel"
    if "sweep_vwap" in hay or "저점 vwap" in hay or "저점 VWAP" in labels:
        return "sweep_vwap"
    if "leader_flow" in hay or "주도흐름 유동보유" in labels:
        return "leader_flow"
    if "leader_momentum" in hay or "주도추세 지속" in labels:
        return "leader_momentum"
    if "breakout" in hay or "돌파 초입" in labels:
        return "breakout"
    if "surge_rebreak" in hay or "급등 후 재돌파" in labels:
        return "surge_rebreak"
    if "hot_rank" in hay or "hot-rank" in hay:
        return "hot_rank"
    return "common"

def _v554_build_structure_levels__L1754(row: Dict[str, Any]) -> Dict[str, Any]:
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("price"), default=0.0)
    if price <= 0:
        return {"schema": "structure_levels_v554", "available": False, "reason": "price_missing"}
    fam = _v554_strategy_family(row)
    vwap_gap = _v510_num(row.get("vwap_gap_pct"), row.get("vwap_pos_pct"), row.get("vwap_position_pct"), default=0.0)
    ema_gap = _v510_num(row.get("ema5_gap_pct"), row.get("ema5_pos_pct"), row.get("ma5_gap_pct"), default=0.0)
    high_gap = _v510_num(row.get("recent_high_gap_pct"), row.get("below_high_pct"), row.get("high_gap_pct"), default=0.0)
    low_rebound = _v510_num(row.get("recent_low_rebound_pct"), row.get("low_rebound_pct"), default=0.0)
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    ch1 = _v510_num(row.get("change_1m_pct"), row.get("change_1m"), default=0.0)
    ch3 = _v510_num(row.get("change_3m_pct"), row.get("change_3m"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)

    vwap_price = _v554_price_from_gap(price, vwap_gap)
    ema_price = _v554_price_from_gap(price, ema_gap)
    recent_high = _v554_price_from_gap(price, high_gap) if abs(high_gap) > 0.0001 else 0.0
    recent_low = _v554_price_from_gap(price, low_rebound) if low_rebound > 0.0001 else 0.0

    supports = [x for x in (vwap_price, ema_price, recent_low, _v554_pct_to_price(price, -0.45)) if x and x < price * 1.003]
    resistances = [x for x in (recent_high, _v554_pct_to_price(price, 0.30 + min(max(react, 0.0), 1.2) * 0.15)) if x and x > price * 0.997]
    support = max([x for x in supports if x < price] or [_v554_pct_to_price(price, -0.45)])
    resistance = min([x for x in resistances if x > price] or [_v554_pct_to_price(price, 0.60)])

    # Strategy-specific structure line interpretation. These are plan/reference levels,
    # not new entry/exit thresholds.
    if fam == "money_reaccel":
        trigger = max(resistance, _v554_pct_to_price(price, 0.18))
        invalid = min(support, _v554_pct_to_price(price, -0.35))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.65))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.20))
        plan_type = "눌림후 재가속 방아쇠"
        reason = "눌림 고점/직전 저항 재돌파 + 돈흐름 유지"
    elif fam == "sweep_vwap":
        trigger = max(vwap_price or price, _v554_pct_to_price(price, 0.10))
        invalid = min(recent_low or support, _v554_pct_to_price(price, -0.40))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.70))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.25))
        plan_type = "저점쓸림 후 VWAP 회복 방아쇠"
        reason = "VWAP 재회복 + 저점 재이탈 없음"
    elif fam == "leader_flow":
        trigger = max(resistance, _v554_pct_to_price(price, 0.16))
        invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.45))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.55))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.10))
        plan_type = "주도흐름 눌림회복 방아쇠"
        reason = "VWAP/EMA 방어 후 직전 고점 재접근"
    elif fam == "leader_momentum":
        trigger = max(resistance, _v554_pct_to_price(price, 0.20))
        invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.50))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.70))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.35))
        plan_type = "주도추세 지속 돌파 방아쇠"
        reason = "주도성 유지 + 저항 재돌파"
    elif fam in {"breakout", "surge_rebreak", "hot_rank"}:
        trigger = max(resistance, _v554_pct_to_price(price, 0.25))
        invalid = min(support, _v554_pct_to_price(price, -0.50))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.55))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.05))
        plan_type = "돌파/재돌파 방아쇠"
        reason = "저항 돌파 + 돌파선 위 유지"
    else:
        trigger = max(resistance, _v554_pct_to_price(price, 0.20))
        invalid = min(support, _v554_pct_to_price(price, -0.45))
        target1 = max(resistance, _v554_pct_to_price(trigger, 0.65))
        target2 = max(target1, _v554_pct_to_price(trigger, 1.15))
        plan_type = "공통 구조 방아쇠"
        reason = "구조선 도달 + 확인신호 통과"

    expected_up = _v554_pct_between(target1, price)
    expected_down = abs(_v554_pct_between(invalid, price))
    rr = (expected_up / expected_down) if expected_down > 0 else 0.0
    late_chase = bool((ch1 >= 1.80 or ch3 >= 3.20 or react >= 1.80) and fam in {"leader_flow", "leader_momentum", "breakout", "hot_rank", "surge_rebreak"})
    if spread >= 0.60:
        late_chase = True
    status = "triggered" if price >= trigger * 0.999 else "waiting"
    return {
        "schema": "structure_levels_v554_all_strategy",
        "available": True,
        "strategy_family": fam,
        "current_price": _v554_round_price(price),
        "support_price": _v554_round_price(support),
        "resistance_price": _v554_round_price(resistance),
        "trigger_price": _v554_round_price(trigger),
        "invalid_price": _v554_round_price(invalid),
        "target1_price": _v554_round_price(target1),
        "target2_price": _v554_round_price(target2),
        # v914: preserve pre-round structure prices for low-price role validation only.
        # Existing rounded trigger/invalid/target values and trigger formula remain unchanged.
        "trigger_price_raw_v914": round(float(trigger), 12),
        "invalid_price_raw_v914": round(float(invalid), 12),
        "target1_price_raw_v914": round(float(target1), 12),
        "target2_price_raw_v914": round(float(target2), 12),
        "structure_price_precision_source_v914": "raw_pre_round_context_only_existing_trigger_unchanged",
        "distance_to_trigger_pct": round(_v554_pct_between(trigger, price), 3),
        "distance_to_invalid_pct": round(_v554_pct_between(invalid, price), 3),
        "expected_upside_pct": round(expected_up, 3),
        "expected_downside_pct": round(-abs(expected_down), 3),
        "expected_downside_abs_pct": round(abs(expected_down), 3),
        "rr_ratio": round(rr, 2),
        "plan_type": plan_type,
        "trigger_reason": reason,
        "target_reason": "다음 저항/구조 목표 우선, 기존 고정 청산은 유지",
        "stop_reason": "구조 무효화 가격. 실제 paper 손절조건은 변경 없음",
        "late_chase_flag": late_chase,
        "late_chase_basis": {"change_1m": round(ch1, 3), "change_3m": round(ch3, 3), "reaction": round(react, 3), "spread": round(spread, 3)},
        "late_chase_reason": ("가격반응/단기상승/스프레드 기준 늦은추격" if late_chase else ""),
        "status": status,
    }

def _v554_apply_entry_plan(row: Dict[str, Any], state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    out = dict(row)
    t = ticker_norm(out.get("ticker") or out.get("market") or out.get("symbol"))
    sk = str(out.get("strategy_key") or out.get("paper_strategy_key") or "-")
    fam = _v554_strategy_family(out)
    # v556: state key는 매 cycle마다 바뀔 수 있는 세부 strategy_key보다
    # ticker + strategy family를 우선한다. 기존 v554/v555 key도 migrate해서
    # first_seen/S2/S1 생애주기가 끊기지 않게 한다.
    key = f"{t}:{fam}" if t else fam
    legacy_keys = [f"{t}:{sk}" if t else sk, str(t or ""), f"{t}:common" if t else "common"]
    price = _v510_num(out.get("current_price"), out.get("entry_price"), out.get("price"), default=0.0)
    prev = state.get(key) if isinstance(state.get(key), dict) else {}
    if not prev:
        for lk in legacy_keys:
            if lk and isinstance(state.get(lk), dict):
                prev = dict(state.get(lk) or {})
                break
    event_key_v750 = str(out.get("event_key") or out.get("event_id") or "")
    event_ts_v750 = _v510_num(out.get("candidate_created_at"), out.get("source_created_at"), out.get("event_ts"), out.get("detected_ts"), out.get("created_at"), default=nowv)
    prev_last_seen_v750 = _v510_num(prev.get("last_seen_ts"), default=0.0)
    prev_first_v750 = _v510_num(prev.get("first_seen_ts"), default=0.0)
    prev_event_key_v752 = str(prev.get("event_key") or "") if isinstance(prev, dict) else ""
    stage_pre_v752 = _v510_stage(out)
    source_age_v752 = max(0.0, nowv - event_ts_v750) if event_ts_v750 else 999999.0
    # v752: S1/S2 이상 fresh source는 구 first_seen/S2_seen을 계속 끌고 가지 않는다.
    # 오래된 후보를 차단하는 게 아니라, 새 source row 기준으로 생애주기를 다시 시작해 paper가 최신 row를 판단하게 한다.
    reset_lifecycle_v750 = False
    reset_reason_v750 = ""
    if prev and prev_last_seen_v750 and nowv - prev_last_seen_v750 > 300:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"last_seen_gap {nowv - prev_last_seen_v750:.0f}s > 300s"
    if prev and stage_pre_v752 in {"S1", "S2"} and source_age_v752 <= 120 and prev_first_v750 and nowv - prev_first_v750 > 300:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"fresh {stage_pre_v752} source resets legacy first_seen {nowv - prev_first_v750:.0f}s"
    if prev and stage_pre_v752 == "S1" and source_age_v752 <= 120 and prev_event_key_v752 and event_key_v750 and prev_event_key_v752 != event_key_v750:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"new S1 event_key {event_key_v750} resets prev {prev_event_key_v752}"
    if prev and prev_first_v750 and nowv - prev_first_v750 > 7200 and event_ts_v750 and nowv - event_ts_v750 <= 120:
        reset_lifecycle_v750 = True
        reset_reason_v750 = f"legacy first_seen {nowv - prev_first_v750:.0f}s with fresh source"
    if reset_lifecycle_v750:
        out["entry_timing_reset_v750"] = True
        out["entry_timing_reset_reason_v750"] = reset_reason_v750
        prev = {}
    first_ts = _v510_num(prev.get("first_seen_ts"), default=0.0) or event_ts_v750 or nowv
    first_price = _v510_num(prev.get("first_seen_price"), default=0.0) or price
    structure_ts = _v510_num(prev.get("structure_seen_ts"), default=0.0) or event_ts_v750 or nowv
    structure_price = _v510_num(prev.get("structure_seen_price"), default=0.0) or price
    stage = _v510_stage(out)
    if stage == "S2":
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0) or nowv
        s2_price = _v510_num(prev.get("s2_price"), default=0.0) or price
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0)
        s1_price = _v510_num(prev.get("s1_price"), default=0.0)
    elif stage == "S1":
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0) or nowv
        s2_price = _v510_num(prev.get("s2_price"), default=0.0) or price
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0) or nowv
        s1_price = _v510_num(prev.get("s1_price"), default=0.0) or price
    else:
        s2_ts = _v510_num(prev.get("s2_seen_ts"), default=0.0)
        s2_price = _v510_num(prev.get("s2_price"), default=0.0)
        s1_ts = _v510_num(prev.get("s1_seen_ts"), default=0.0)
        s1_price = _v510_num(prev.get("s1_price"), default=0.0)

    levels = _v554_build_structure_levels(out)
    entry_plan = {
        "schema": "entry_plan_v554_s2_trigger_waiting",
        "role": "S2=진입계획 대기 / S1=방아쇠+확인통과 / S3=구조관찰",
        "plan_type": levels.get("plan_type") or "구조선 대기",
        "trigger_price": levels.get("trigger_price"),
        "trigger_reason": levels.get("trigger_reason"),
        "invalid_price": levels.get("invalid_price"),
        "target1_price": levels.get("target1_price"),
        "target2_price": levels.get("target2_price"),
        "required_confirm": ["신선도", "가격반응", "매수체결", "1분지속", "스프레드/미끄러짐 정상"],
        "cancel_conditions": ["무효화 가격 이탈", "강한 매도압력", "스프레드/미끄러짐 과다", "늦은추격 위험"],
        "timeout_sec": 180 if stage != "S1" else 70,
        "status": "paper_open_ready" if stage == "S1" else ("entry_plan_wait" if stage == "S2" else "structure_observe"),
    }
    timing = {
        "schema": "entry_timing_spine_v554",
        "first_seen_ts": first_ts,
        "first_seen_price": _v554_round_price(first_price),
        "structure_seen_ts": structure_ts,
        "structure_seen_price": _v554_round_price(structure_price),
        "s2_seen_ts": s2_ts,
        "s2_price": _v554_round_price(s2_price),
        "s1_seen_ts": s1_ts,
        "s1_price": _v554_round_price(s1_price),
        "first_to_s1_delay_sec": round(max(0.0, s1_ts - first_ts), 1) if s1_ts else None,
        "s2_to_s1_delay_sec": round(max(0.0, s1_ts - s2_ts), 1) if s1_ts and s2_ts else None,
        "first_to_now_delay_sec": round(max(0.0, nowv - first_ts), 1),
        "s2_to_now_delay_sec": round(max(0.0, nowv - s2_ts), 1) if s2_ts else None,
        "first_to_current_delay_sec": round(max(0.0, nowv - first_ts), 1),
        "s2_to_current_delay_sec": round(max(0.0, nowv - s2_ts), 1) if s2_ts else None,
        "first_to_now_return_pct": round(_v554_pct_between(price, first_price), 3) if first_price else 0.0,
        "s2_to_now_return_pct": round(_v554_pct_between(price, s2_price), 3) if s2_price else 0.0,
        "first_to_current_return_pct": round(_v554_pct_between(price, first_price), 3) if first_price else 0.0,
        "s2_to_current_return_pct": round(_v554_pct_between(price, s2_price), 3) if s2_price else 0.0,
        "s1_to_now_return_pct": round(_v554_pct_between(price, s1_price), 3) if s1_price else 0.0,
        "late_chase_flag": bool(levels.get("late_chase_flag")),
        "late_chase_reason": levels.get("late_chase_reason") or "",
        "state_key": key,
        "event_key_v750": event_key_v750,
        "event_key_v752": event_key_v750,
        "source_event_age_sec_v750": round(max(0.0, nowv - event_ts_v750), 1) if event_ts_v750 else None,
        "source_event_age_sec_v752": round(source_age_v752, 1) if source_age_v752 < 999999 else None,
        "lifecycle_reset_v750": bool(out.get("entry_timing_reset_v750")),
        "lifecycle_reset_reason_v750": out.get("entry_timing_reset_reason_v750") or "",
    }
    rr = {
        "schema": "risk_reward_v556_structure_target",
        "expected_upside_pct": levels.get("expected_upside_pct"),
        "expected_downside_pct": levels.get("expected_downside_pct"),
        "expected_downside_abs_pct": levels.get("expected_downside_abs_pct"),
        "rr_ratio": levels.get("rr_ratio"),
        "target_reason": levels.get("target_reason"),
        "stop_reason": levels.get("stop_reason"),
    }
    out["structure_levels"] = levels
    out["entry_plan"] = entry_plan
    out["risk_reward"] = rr
    out["entry_timing_spine"] = timing
    out["late_chase_flag"] = bool(levels.get("late_chase_flag"))
    out["late_chase_basis"] = levels.get("late_chase_basis")
    if bool(out.get("late_chase_flag")):
        risks = out.get("risk_tags") if isinstance(out.get("risk_tags"), list) else []
        out["risk_tags"] = _v510_uniq(list(risks) + ["늦은추격위험"], 12)
        out["execution_risk_tags"] = out["risk_tags"]
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx.update({"structure_levels": levels, "entry_plan": entry_plan, "risk_reward": rr, "entry_timing_spine": timing, "late_chase_flag": out.get("late_chase_flag"), "late_chase_basis": out.get("late_chase_basis"), "late_chase_reason": levels.get("late_chase_reason")})
    out["entry_context"] = ctx
    # v806: S2→S1 재확인 freshness trace.
    # This is trace-only. It does not alter stage, trigger, RR, entry/exit, or auto-buy logic.
    prev_metrics_v806 = prev.get("last_metrics_v806") if isinstance(prev.get("last_metrics_v806"), dict) else {}
    curr_metrics_v806 = {
        "price": _v554_round_price(price),
        "price_reaction_pct": round(_v510_num(out.get("price_reaction_pct"), default=0.0), 4),
        "buy_ratio": round(_v510_num(out.get("buy_ratio"), default=0.0), 4),
        "buy_sustain_1m": round(_v510_num(out.get("buy_sustain_1m"), out.get("buy_sustain_60s"), default=0.0), 4),
        "spread_pct": round(_v510_num(out.get("spread_pct"), default=99.0), 4),
        "slippage_pct": round(_v510_num(out.get("slippage_pct"), out.get("spread_pct"), default=99.0), 4),
        "trigger_gap_pct": round(_v510_num(levels.get("trigger_gap_pct"), out.get("trigger_gap_pct"), default=0.0), 4),
    }
    metric_delta_v806: Dict[str, float] = {}
    value_changed_count_v806 = 0
    for mk, mv in curr_metrics_v806.items():
        try:
            oldv = float(prev_metrics_v806.get(mk)) if prev_metrics_v806 and prev_metrics_v806.get(mk) not in (None, '') else None
            if oldv is None:
                continue
            dv = round(float(mv) - oldv, 4)
            metric_delta_v806[mk] = dv
            threshold = 0.0001 if mk == "price" else (0.015 if mk in ("buy_ratio", "buy_sustain_1m") else 0.03)
            if abs(dv) >= threshold:
                value_changed_count_v806 += 1
        except Exception:
            continue
    stale_reasons_v806 = _v553_as_list(out.get("stale_reasons")) + _v553_as_list(out.get("freshness_flags"))
    source_age_num_v806 = source_age_v752 if source_age_v752 < 999999 else _v510_num(out.get("source_event_age_sec_v752"), out.get("source_event_age_sec_v750"), default=999999.0)
    seen_count_v806 = int(_v510_num(prev.get("seen_count"), default=0.0)) + 1
    prev_stale_repeat_v806 = int(_v510_num(prev.get("stale_repeat_count_v806"), default=0.0))
    stale_now_v806 = bool(source_age_num_v806 > 60 or stale_reasons_v806)
    stale_repeat_count_v806 = prev_stale_repeat_v806 + 1 if stale_now_v806 else 0
    if source_age_num_v806 > 60 or stale_reasons_v806:
        fresh_status_v806 = "stale_repeat" if stale_repeat_count_v806 >= 2 else "stale_or_wait"
    elif seen_count_v806 >= 2 and value_changed_count_v806 <= 0:
        fresh_status_v806 = "fresh_but_no_value_change"
    else:
        fresh_status_v806 = "fresh_update"
    recheck_trace_v806 = {
        "schema": "recheck_freshness_trace_v806",
        "seen_count": seen_count_v806,
        "recheck_count": max(0, seen_count_v806 - 1),
        "fresh_status": fresh_status_v806,
        "source_event_age_sec": round(source_age_num_v806, 1) if source_age_num_v806 < 999999 else None,
        "first_seen_age_sec": round(max(0.0, nowv - first_ts), 1) if first_ts else None,
        "s2_age_sec": round(max(0.0, nowv - s2_ts), 1) if s2_ts else None,
        "value_changed_count": value_changed_count_v806,
        "metric_delta": metric_delta_v806,
        "metrics": curr_metrics_v806,
        "stale_reasons": _v510_uniq([str(x) for x in stale_reasons_v806 if x], 8),
        "stale_repeat_count": stale_repeat_count_v806,
        "basis": "trace only; no grade/entry/exit logic changed",
    }
    out["recheck_freshness_trace_v806"] = recheck_trace_v806
    ctx2 = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx2 = dict(ctx2)
    ctx2["recheck_freshness_trace_v806"] = recheck_trace_v806
    out["entry_context"] = ctx2

    state[key] = {
        "ticker": t,
        "strategy_key": sk,
        "first_seen_ts": first_ts,
        "first_seen_price": first_price,
        "structure_seen_ts": structure_ts,
        "structure_seen_price": structure_price,
        "s2_seen_ts": s2_ts,
        "s2_price": s2_price,
        "s1_seen_ts": s1_ts,
        "s1_price": s1_price,
        "last_seen_ts": nowv,
        "last_seen_price": price,
        "last_metrics_v806": curr_metrics_v806,
        "stale_repeat_count_v806": stale_repeat_count_v806,
        "last_recheck_fresh_status_v806": fresh_status_v806,
        "last_stage": stage,
        "event_key": event_key_v750,
        "event_ts": event_ts_v750,
        "strategy_family": fam,
        "state_key": key,
        "seen_count": int(_v510_num(prev.get("seen_count"), default=0.0)) + 1,
    }
    return out

def _v554_apply_entry_plan_state__L2086(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    obj = load_json(ENTRY_PLAN_STATE, {}) or {}
    state = obj.get("items") if isinstance(obj, dict) and isinstance(obj.get("items"), dict) else (obj if isinstance(obj, dict) else {})
    # old/no-longer-seen state is short-lived; it is only for timing/plan continuity.
    for k in list(state.keys()):
        try:
            if nowv - float(state.get(k, {}).get("last_seen_ts") or 0.0) > 1800:
                state.pop(k, None)
        except Exception:
            state.pop(k, None)
    out = [_v554_apply_entry_plan(r, state, nowv) for r in rows if isinstance(r, dict)]
    save_json(ENTRY_PLAN_STATE, {"schema": "entry_plan_state_v556_lifecycle", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "count": len(state), "items": state})
    return out

V1098_FEATURE_QUALITY_FIELDS = (
    'relative_strength_pct',
    'relative_strength_source_v1095',
    'relative_strength_rank_pct_v1095',
    'turnover_24h_for_quality_v1095',
    'turnover_rank_pct_v1095',
    'volume_flow_signal_v1095',
    'volume_flow_rank_pct_v1095',
    'short_flow_signal_v1095',
    'short_flow_rank_pct_v1095',
    'money_flow_score',
    'money_flow_source_v1095',
    'money_flow_source_missing_v1095',
    'feature_quality_owner_v1095',
)

def _v1098_copy_feature_quality_fields(row: Dict[str, Any], feature_row: Dict[str, Any], source_label: str) -> Dict[str, Any]:
    out = dict(row or {})
    src = feature_row if isinstance(feature_row, dict) else {}
    copied: List[str] = []
    for key in V1098_FEATURE_QUALITY_FIELDS:
        value = src.get(key)
        if value in (None, ''):
            continue
        if out.get(key) not in (None, ''):
            continue
        out[key] = value
        copied.append(key)
    previous = out.get('feature_quality_transport_v1098') if isinstance(out.get('feature_quality_transport_v1098'), dict) else {}
    previous_copied = previous.get('copied_fields') if isinstance(previous.get('copied_fields'), list) else []
    numeric_missing = [key for key in ('relative_strength_pct','relative_strength_rank_pct_v1095','money_flow_score') if src.get(key) in (None, '')]
    out['feature_quality_transport_v1098'] = {
        'schema': 'feature_quality_transport_v1098',
        'source': source_label,
        'value_owner': src.get('feature_quality_owner_v1095') or 'feature_worker',
        'transport_owner': 'strategy_worker.canonical_candidate_spine',
        'feature_row_matched': bool(src),
        'copied_fields': sorted(set(str(x) for x in previous_copied + copied)),
        'numeric_missing_at_source': numeric_missing,
        'recomputed': False,
    }
    return out

def _v510_make_row__L2100(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    react = _v510_price_reaction(src, of)
    spread = _v510_spread(of, src)
    buy = _v510_buy(of, src)
    sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
    # v519: paper_bot OPEN 필수 가격값을 strategy canonical row에서 봉인한다.
    sealed_price = _v510_num(
        src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
        of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
        of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
        default=0.0,
    )
    hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
    micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
    price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
    quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    stale_items = _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price, strict=True)
    decision_reasons, reason_structure_tags = _v520_split_reasons(reasons, stale_items)
    row = {
        "schema": "paper_candidate_v520_reason_spine_row",
        "version": VERSION,
        "ticker": t,
        "market": f"KRW-{t}" if t else src.get("market"),
        "symbol": f"{t}_KRW" if t else src.get("symbol"),
        "event_id": _v510_event_id(t, skey, lane, nowv),
        "event_key": _v510_event_id(t, skey, lane, nowv),
        "created_at": nowv,
        "candidate_created_at": nowv,
        "source_created_at": nowv,
        "detected_ts": nowv,
        "event_ts": nowv,
        "created_at_text": now_text(nowv),
        "updated_ts": nowv,
        "expires_at": nowv + (70 if stage == "S1" else 180),
        "strategy_key": skey,
        "paper_strategy_key": skey,
        "strategy_label": label,
        "strategy": label,
        "matched_strategy_keys": list(src.get("_matched_strategy_keys") or [skey]),
        "matched_strategy_labels": list(src.get("_matched_strategy_labels") or [label]),
        "canonical_lane": lane,
        "s_stage": stage,
        "candidate_stage": stage,
        "candidate_grade": stage,
        "stage": stage,
        "grade": stage,
        "score": round(score, 3),
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "trade_price": sealed_price,
        "price_source": "strategy_v522_sealed",
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_reaction_pct": round(react, 4),
        "spread_pct": round(spread, 4),
        "slippage_pct": round(spread, 4),
        "buy_ratio": round(buy, 4),
        "buy_sustain_1m": round(sustain, 4),
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "sustain_source": sustain_source,
        "change_1m_pct": _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0),
        "change_3m_pct": _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0),
        "change_5m_pct": _v510_num(src.get("change_5m"), src.get("price_change_5m"), default=0.0),
        "price_chg_5s": _v510_num(of.get("price_chg_5s"), src.get("price_chg_5s"), default=0.0),
        "price_chg_10s": _v510_num(of.get("price_chg_10s"), src.get("price_chg_10s"), default=0.0),
        "price_chg_20s": _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0),
        "price_chg_30s": _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0),
        "price_chg_60s": _v510_num(of.get("price_chg_60s"), src.get("price_chg_60s"), default=0.0),
        "price_accel_10s": _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0),
        "price_accel_20s": _v510_num(of.get("price_accel_20s"), src.get("price_accel_20s"), default=0.0),
        "buy_ratio_5s": _v510_num(of.get("buy_ratio_5s"), src.get("buy_ratio_5s"), default=buy),
        "buy_ratio_10s": _v510_num(of.get("buy_ratio_10s"), src.get("buy_ratio_10s"), default=buy),
        "buy_sustain_20s": _v510_num(of.get("buy_sustain_20s"), src.get("buy_sustain_20s"), default=sustain),
        "trade_burst_10s": _v510_num(of.get("trade_burst_10s"), src.get("trade_burst_10s"), default=0.0),
        "spread_widening_10s": _v510_num(of.get("spread_widening_10s"), src.get("spread_widening_10s"), default=0.0),
        "spike_fast_ready": bool(of.get("spike_fast_ready") or src.get("spike_fast_ready")),
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "structure_tags": _v510_uniq(_v510_structure_tags(src) + reason_structure_tags, 10),
        "risk_tags": _v510_risk_tags(src, of, hard or []),
        "stale_reasons": stale_items,
        "freshness_status": "recheck" if stale_items else "fresh",
        "official_structure_inputs_raw": {},
        "reason": " / ".join(decision_reasons),
        "s_stage_reasons": decision_reasons,
    }
    # v597: preserve official candle/structure inputs from feature/candle source row.
    # These are evidence fields, not new strategy conditions. Missing stays missing; no 0 fallback.
    _official_pack = {}
    for _ok in V597_OFFICIAL_STRUCTURE_KEYS:
        _ov = src.get(_ok)
        if _ov not in (None, ""):
            row[_ok] = _ov
            _official_pack[_ok] = _ov
    if _official_pack:
        row["official_structure_inputs_raw"] = _official_pack

    # v1098: Feature owns relative-strength and money-flow values; Strategy only transports them.
    row = _v1098_copy_feature_quality_fields(row, src, 'feature_input_candidate_build_v1098')

    row["entry_context"] = {
        "strategy_key": skey,
        "strategy_label": label,
        "canonical_lane": lane,
        "structure_tags": row["structure_tags"],
        "risk_tags": row["risk_tags"],
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "freshness_status": "recheck" if stale_items else "fresh",
        "stale_reasons": stale_items,
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_source": "strategy_v522_sealed",
        "price_reaction_pct": react,
        "buy_ratio": buy,
        "buy_sustain_1m": sustain,
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "spread_pct": spread,
        "price_chg_20s": row.get("price_chg_20s"),
        "price_chg_30s": row.get("price_chg_30s"),
        "price_chg_60s": row.get("price_chg_60s"),
        "price_accel_10s": row.get("price_accel_10s"),
        "buy_ratio_10s": row.get("buy_ratio_10s"),
        "buy_sustain_20s": row.get("buy_sustain_20s"),
        "spread_widening_10s": row.get("spread_widening_10s"),
        "reasons": row["s_stage_reasons"],
    }
    row = _v532_apply_canonical_entry_decision(row)
    row = _v553_apply_reason_taxonomy(row)
    return row

def _v510_final_gate(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    stage = _v510_stage(r)
    skey = str(r.get("strategy_key") or "")
    is_spike = skey in {"spike_momentum_ride", "spike_pullback_reaccel"}
    hot = _v510_num(r.get("hot_signal_age_sec"), default=999999.0)
    micro = _v510_num(r.get("micro_age_sec"), default=999999.0)
    order = _v510_num(r.get("orderflow_age_sec"), default=micro)
    price = _v510_num(r.get("price_reaction_age_sec"), default=999999.0)
    quote = _v510_num(r.get("quote_age_sec"), default=999999.0)
    paper_delay = max(0.0, nowv - _event_created_ts(r))
    sealed_price = _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0)
    stale: List[str] = _v520_fresh_stale_items(r, r, hot, micro, order, price, quote, sealed_price, strict=is_spike)
    if is_spike and paper_delay > 20:
        stale.append(f"paper {paper_delay:.1f}s")
    elif (not is_spike) and paper_delay > 45:
        stale.append(f"paper {paper_delay:.1f}s")
    stale = _v522_filter_stale_items(_v510_uniq(stale, 6), strict=is_spike)
    allowed = not stale
    if stage == "S1" and not allowed:
        r["v510_downgraded_from_s1"] = True
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S2"
        rr = list(r.get("s_stage_reasons") or []) + ["final_entry_gate 신선도 재확인: " + " / ".join(stale[:5])]
        r["s_stage_reasons"] = _v510_uniq(rr, 12)
    r["stale_reasons"] = stale
    r = _v520_normalize_reason_row(r)
    r["fresh_gate_ok"] = bool(allowed)
    r = _v532_apply_canonical_entry_decision(r)
    decision = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    final_allowed = bool(decision.get("s1_allowed") and allowed)
    if not final_allowed and _v510_stage(r) == "S1":
        r["v510_downgraded_from_s1"] = True
        target_stage = "S2" if (stale or decision.get("s2_recheck") or decision.get("action") == "recheck") else "S3"
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = target_stage
    r["open_eligible"] = bool(final_allowed)
    r["paper_bot_open"] = bool(final_allowed)
    r["trade_ready"] = bool(final_allowed)
    r["v510_final_entry_gate"] = {
        "schema": "final_entry_gate_v536_profile_simplified",
        "version": VERSION,
        "checked_ts": nowv,
        "age_values": {"hot": hot, "micro": micro, "orderflow": order, "price": price, "quote": quote, "paper": paper_delay},
        "stale_reasons": stale,
        "s1_allowed": bool(final_allowed),
        "policy": "v536: canonical_entry_decision with simplified entry_profile; paper_candidates_latest.jsonl is canonical",
    }
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx); ctx["v510_final_entry_gate"] = r["v510_final_entry_gate"]
    r["entry_context"] = ctx
    dec = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    if isinstance(dec, dict):
        dec = dict(dec)
        dec["v510_final_entry_gate"] = r["v510_final_entry_gate"]
        dec["s1_allowed"] = bool(final_allowed)
        dec["gate_pass"] = bool(final_allowed)
        dec["action"] = "paper_open_candidate" if final_allowed else ("recheck" if dec.get("s2_recheck") else "observe")
        r["canonical_entry_decision"] = dec
        r["common_entry_decision"] = dec
        r["entry_context"]["canonical_entry_decision"] = dec
        r["entry_context"]["common_entry_decision"] = dec
    r = _v553_apply_reason_taxonomy(r)
    return r

_V1210_EVALS = (
    ("leader_flow_adaptive_hold_s", eval_adaptive_hold),
    ("money_reaccel_s", eval_money),
    ("leader_momentum_s", eval_leader),
    ("breakout_early_s", eval_breakout),
    ("sweep_vwap_recovery_s", eval_sweep),
    ("surge_rebreak_s", eval_surge),
)


def _v1210_shared_candidate_eval(feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    """Compute fields used by both base and spike lanes once per ticker.

    This is a pure calculation cache scoped to one Strategy cycle.  It is never
    persisted or reused across cycles, so no stale candidate value can enter the
    next generation.
    """
    out: Dict[str, Dict[str, Any]] = {}
    for src in feature_list or []:
        if not isinstance(src, dict):
            continue
        ticker = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not ticker:
            continue
        of = ofmap.get(ticker, {}) or {}
        core_hits: List[Tuple[str, List[str]]] = []
        core_fail: List[str] = []
        for skey, fn in _V1210_EVALS:
            ok, why, no = fn(src, of)
            if ok:
                core_hits.append((skey, why))
            else:
                core_fail += [f"{STRATEGIES.get(skey, skey)}:{x}" for x in no[:2]]
        sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        out[ticker] = {
            "ticker": ticker,
            "of": of,
            "hard": common_hard(src, of),
            "core_hits": core_hits,
            "core_fail": core_fail,
            "react": _v510_price_reaction(src, of),
            "buy": _v510_buy(of, src),
            "sustain": sustain,
            "sustain_source": sustain_source,
            "sustain_real": sustain_real,
            "spread": _v510_spread(of, src),
        }
    return out


def _v510_base_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], shared_eval: Optional[Dict[str, Dict[str, Any]]]=None) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    rows: List[Dict[str, Any]] = []
    rejects: List[Dict[str, Any]] = []
    requests: List[Dict[str, Any]] = []
    shared_eval = shared_eval if isinstance(shared_eval, dict) else _v1210_shared_candidate_eval(feature_list, ofmap)
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        shared = shared_eval.get(t) or {}
        of = shared.get("of") if isinstance(shared.get("of"), dict) else (ofmap.get(t, {}) or {})
        hard = list(shared.get("hard") or [])
        core_hits = list(shared.get("core_hits") or [])
        core_fail = list(shared.get("core_fail") or [])
        need_info, cheap_bucket = _cheap_gate(src, core_hits, hard)
        info_bad = orderflow_info_bad(of) if need_info else []
        react = _v510_num(shared.get("react"), default=0.0)
        buy = _v510_num(shared.get("buy"), default=0.0)
        sustain = _v510_num(shared.get("sustain"), default=0.0)
        sustain_source = str(shared.get("sustain_source") or "")
        sustain_real = bool(shared.get("sustain_real"))
        spread = _v510_num(shared.get("spread"), default=999.0)
        score = _priority_score(src, core_hits, info_bad, hard)
        reasons: List[str] = []
        skey = core_hits[0][0] if core_hits else "leader_flow_adaptive_hold_s"
        label = STRATEGIES.get(skey, skey).replace(" S", "")
        if core_hits:
            reasons += [f"구조:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
        reasons += hard[:4] + info_bad[:3]
        if react < 0.05: reasons.append("가격반응 기준근접(+0.00%→+0.05%)")
        if react < 0.35: reasons.append("가격반응 약함(+0.05%→+0.35%)")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        elif spread > 0.18: reasons.append(f"스프레드 경계값({spread:.2f}%)→재확인")
        stage = ""
        common_s2 = (not hard and react >= 0.15 and buy >= 0.55 and spread <= 0.35)
        if core_hits or common_s2 or (need_info and cheap_bucket in {"core_hit", "high_cheap"}) or score >= 88:
            # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
            stage = "S2" if (core_hits or react >= 0.25 or score >= 105 or common_s2) else "S3"
        elif cheap_bucket == "high_cheap":
            stage = "S3"
        if not stage:
            rejects.append({"ticker": t, "score": score, "reasons": _v510_uniq(reasons + core_fail, 8), "updated_ts": nowv})
            continue
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "base", score, reasons or ["구조관찰"], nowv, hard)
        rows.append(row)
        need = []
        if not _v510_bool(of.get("quote_fresh") or of.get("ws_fresh")): need.append("quote")
        if not _v510_bool(of.get("micro_fresh")): need.append("micro")
        requests.append(_make_priority_request(t, src, "s_candidate" if stage == "S1" else "recheck_candidate", 100 + score + _STAGE_ORDER.get(stage,1)*20, need or ["micro"], core_hits, row.get("s_stage_reasons") or []))
    return rows, rejects, requests

def _v510_spike_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], shared_eval: Optional[Dict[str, Dict[str, Any]]]=None) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    shared_eval = shared_eval if isinstance(shared_eval, dict) else _v1210_shared_candidate_eval(feature_list, ofmap)
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        shared = shared_eval.get(t) or {}
        of = shared.get("of") if isinstance(shared.get("of"), dict) else (ofmap.get(t, {}) or {})
        ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0)
        ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0)
        react = _v510_num(shared.get("react"), default=0.0)
        short20 = _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0)
        short30 = _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0)
        accel10 = _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0)
        # Wide prefilter only. It does not cap candidates.
        if max(ch1, ch3, react, short20, short30, accel10) < 0.30:
            continue
        spread = _v510_num(shared.get("spread"), default=999.0)
        buy = _v510_num(shared.get("buy"), default=0.0)
        sustain = _v510_num(shared.get("sustain"), default=0.0)
        sustain_source = str(shared.get("sustain_source") or "")
        sustain_real = bool(shared.get("sustain_real"))
        hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
        micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
        price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
        quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        sealed_price_probe = _v510_num(
            src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
            of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
            of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
            default=0.0,
        )
        fresh = not _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price_probe, strict=True)
        core_hits = list(shared.get("core_hits") or [])
        # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
        strong = (react >= 0.80 or ch1 >= 0.70 or ch3 >= 1.20) and buy >= 0.78 and sustain >= 0.78 and spread <= 0.18
        late_risk = (buy < 0.70 or sustain < 0.70 or spread > 0.35 or row_bool(src, "long_upper_wick"))
        stage = "S2" if (fresh and (react >= 0.35 or strong) and spread <= 0.50) else "S3"
        if core_hits:
            skey = core_hits[0][0]
            label = STRATEGIES.get(skey, skey).replace(" S", "")
        else:
            skey = "hot_rank_recheck"
            label = "hot-rank 급등 재확인"
        reasons: List[str] = []
        if stage == "S1":
            reasons.append("fresh urgent 급등 확인")
        elif core_hits:
            reasons.append("급등확인 재확인")
        else:
            reasons.append("hot-rank 급등 재확인")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        score = 100 + max(0.0, react)*10 + max(0.0, ch1)*4 + max(0.0, ch3)*3 + max(0.0, buy)*2 + max(0.0, short20)*5 + max(0.0, accel10)*4
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "spike", score, reasons, nowv, [])
        rows.append(_v520_normalize_reason_row(row))
    return rows

def row_bool(row: Dict[str, Any], key: str) -> bool:
    try:
        return _v510_bool(row.get(key))
    except Exception:
        return False

def _v510_merge_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        if not isinstance(r, dict): continue
        r = _v510_final_gate(r, nowv)
        t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t: continue
        key = t
        prev = merged.get(key)
        if prev is None:
            merged[key] = r; continue
        merged_keys = _v510_uniq(list(prev.get("matched_strategy_keys") or []) + list(r.get("matched_strategy_keys") or []), 8)
        merged_labels = _v510_uniq(list(prev.get("matched_strategy_labels") or []) + list(r.get("matched_strategy_labels") or []), 8)
        a = (_STAGE_ORDER.get(_v510_stage(r), 0), 1 if str(r.get("canonical_lane")) == "base" else 0, _v510_num(r.get("score"), default=0.0), _event_created_ts(r))
        b = (_STAGE_ORDER.get(_v510_stage(prev), 0), 1 if str(prev.get("canonical_lane")) == "base" else 0, _v510_num(prev.get("score"), default=0.0), _event_created_ts(prev))
        chosen = r if a >= b else prev
        chosen["matched_strategy_keys"] = merged_keys
        chosen["matched_strategy_labels"] = merged_labels
        merged[key] = chosen
    out = sorted(merged.values(), key=lambda x: (_STAGE_ORDER.get(_v510_stage(x),0), _v510_num(x.get("score"), default=0.0), _event_created_ts(x)), reverse=True)
    return out

def _v510_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v510_stage(r)
        c[st] = c.get(st, 0) + 1
    return c

def _v510_reason_top(rows: List[Dict[str, Any]], maxn: int = 20) -> List[Dict[str, Any]]:
    ctr: Dict[str, int] = {}
    for r in rows:
        if _v510_stage(r) == "S1": continue
        for reason in (r.get("s_stage_reasons") or r.get("block_reasons") or [])[:6]:
            s = str(reason or "").strip()
            if not s: continue
            # Collapse numeric variants lightly for panel readability.
            if "스프레드" in s: s = "스프레드"
            elif "미끄러짐" in s: s = "미끄러짐"
            elif "매수체결" in s: s = "매수체결"
            elif "1분" in s: s = "1분지속"
            elif "가격반응" in s: s = "가격반응"
            elif "신선" in s: s = "신선도재확인"
            ctr[s] = ctr.get(s, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(ctr.items(), key=lambda kv: kv[1], reverse=True)[:maxn]]

def _v512_info_quality(feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    """상태판이 읽는 정보품질 숫자를 single-pass canonical 기준으로 채운다.

    v510은 final_rows는 정상 생산했지만 /health 상단 정보요약이 0/전체로 표시됐다.
    이유는 예전 status/summary reader가 기대하던 quote_ready_count/micro_ready_count/full_info_ready_count
    계열 필드를 publish하지 않았기 때문이다. 여기서는 후보 조건을 바꾸지 않고, 같은 입력 feature/orderflow에서
    정보품질 숫자만 확정한다.
    """
    evaluated = len(feature_list)
    quote_ready = 0
    micro_ready = 0
    both_ready = 0
    orderflow_attached = 0
    price_ready = 0
    for row in feature_list:
        t = ticker_norm(row.get("ticker"))
        of = ofmap.get(t, {}) if t else {}
        has_price = _v510_num(row.get("current_price"), row.get("price"), of.get("quote_price"), of.get("current_price"), default=0.0) > 0
        quote = bool(of.get("quote_fresh") or of.get("ws_fresh") or has_price)
        micro = bool(of.get("micro_fresh") or of.get("orderflow_fresh") or of.get("buy_ratio") is not None or of.get("spread_pct") is not None)
        attached = bool(of)
        if has_price:
            price_ready += 1
        if attached:
            orderflow_attached += 1
        if quote:
            quote_ready += 1
        if micro:
            micro_ready += 1
        if quote and micro:
            both_ready += 1
    return {
        "price_ready_count": price_ready,
        "quote_ready_count": quote_ready,
        "market_price_ready_count": price_ready,
        "micro_ready_count": micro_ready,
        "full_info_ready_count": both_ready,
        "both_ready_count": both_ready,
        "orderflow_attached_count": orderflow_attached,
    }

def _v608_candle_age_index(candle_map: Dict[str,Dict[str,Any]]) -> Dict[str, float]:
    """Read candle ages from the canonical map already loaded by run_once.

    The retired path parsed the full Candle checkpoint again inside the publish
    phase and ignored the incremental delta already merged by `_v1014_load_candle_map`.
    """
    if not isinstance(candle_map,dict):
        raise RuntimeError('canonical candle_map is required for candle urgent age index')
    nowv = now_ts(); out: Dict[str, float] = {}
    for key,r in candle_map.items():
        if not isinstance(r,dict):
            continue
        t=ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market') or key)
        ts=_v510_num(r.get('candle_ts'),default=0.0)
        if t:
            out[t]=999999.0 if ts<=0 else max(0.0,nowv-ts)
    return out

def _v608_row_text(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ('final_trade_state','final_decision','final_trade_label','final_trade_reasons','v575_urgent_action_state','v574_fresh_urgent_reason','s2_promotion_lifecycle','s_stage_reasons','missing_info','risk_tags'):
        v = row.get(k)
        if isinstance(v, list): vals += [str(x) for x in v]
        elif isinstance(v, dict): vals.append(json.dumps(v, ensure_ascii=False, default=str))
        elif v not in (None, ''): vals.append(str(v))
    cm = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    if isinstance(cm, dict):
        for k in ('final_trade_state','final_decision','final_trade_reasons','decision_reference'):
            v = cm.get(k)
            if isinstance(v, list): vals += [str(x) for x in v]
            elif v not in (None, ''): vals.append(str(v))
    return ' '.join(vals).lower()

def _v608_is_hard_risk_for_candle(row: Dict[str, Any]) -> bool:
    txt = _v608_row_text(row)
    # 캔들 긴급갱신 우선순위에서만 낮춘다. 후보 등급/조건 차단이 아니다.
    hard_words = (
        '가짜돌파', '방어실패', '구조위험', '늦은추격', '매도압력', '매도벽',
        '손실군', '위험우세', '상단저항', '윗꼬리', '실행위험 재확인'
    )
    return any(w in txt for w in hard_words)

def _v608_structure_good_for_candle(row: Dict[str, Any]) -> bool:
    vals: List[str] = []
    for k in ('entry_structure_tags','structure_tags','matched_strategy_labels','strategy_tags','entry_reasons','entry_basis','strategy','strategy_label'):
        v = row.get(k)
        if isinstance(v, list): vals += [str(x) for x in v]
        elif v not in (None, '', [], {}): vals.append(str(v))
    txt = ' '.join(vals) + ' ' + _v608_row_text(row)
    good_words = (
        'VWAP방어', 'EMA방어', '돈흐름재유입', '돈흐름', '눌림회복', '재가속',
        '주도흐름', '유동보유', '지지전환', '돌파', '회복', '방아쇠', 'recheck', 'trigger'
    )
    return any(w.lower() in txt.lower() for w in good_words)

def _v608_trigger_gap_for_candle(row: Dict[str, Any]) -> float:
    # 이미 row에 봉인된 gap이 있으면 먼저 사용한다.
    vals = [row.get('trigger_gap_pct'), row.get('s2_trigger_gap_pct'), row.get('gap_pct')]
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    vals += [plan.get('trigger_gap_pct'), levels.get('trigger_gap_pct')]
    for v in vals:
        try:
            if v not in (None, ''):
                return abs(float(str(v).replace('%','')))
        except Exception:
            pass
    price = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    trigger = _v510_num(plan.get('trigger_price'), levels.get('trigger_price'), default=0.0)
    if price and trigger:
        try:
            return abs((trigger - price) / price * 100.0)
        except Exception:
            return 999.0
    return 999.0

def _v608_publish_candle_urgent_targets(rows: List[Dict[str, Any]], nowv: float, candle_map: Dict[str,Dict[str,Any]]) -> Dict[str, Any]:
    """v610 본선.
    v609는 S3까지 urgent에 올렸지만 모두 같은 무게로 처리해 candle_worker 처리량이 밀렸다.
    v610은 후보를 줄이지 않고 정보 투입량을 3단계로 나눈다.
    - core: OPEN/S1/S2/fresh_wait. 1m/3m/5m 전부.
    - near: near-S2/방아쇠근처 S3. 1m/3m 우선.
    - watch: 구조 좋은 S3/hot 구조 후보. 1m 최소 정보.
    조건/S등급/청산/장부는 변경하지 않는다.
    """
    age_map = _v608_candle_age_index(candle_map)
    targets: List[Dict[str, Any]] = []
    seen=set()
    bucket_counter: Counter = Counter()
    lane_counter: Counter = Counter()

    lane_rank = {'core': 3000, 'near': 2000, 'watch': 1000}
    profile_by_lane = {'core': 'full_1m3m5m', 'near': 'mid_1m3m', 'watch': 'light_1m'}

    def add_target(row: Dict[str, Any], bucket: str, priority: int, target_age: int, reason: List[str], lane: str, profile: Optional[str] = None) -> None:
        t = ticker_norm(row.get('ticker') or row.get('symbol') or row.get('market'))
        if not t or t in seen:
            return
        lane = lane if lane in lane_rank else 'watch'
        age = age_map.get(t, 999999.0)
        targets.append({
            'ticker': t,
            'stage': _v510_stage(row),
            'bucket': bucket,
            'lane': lane,
            'profile': profile or profile_by_lane.get(lane, 'light_1m'),
            'priority': int(lane_rank[lane] + priority),
            'raw_priority': priority,
            'required_age_sec': target_age,
            'current_age_sec': round(age, 1) if age < 999998 else None,
            'reason': ' / '.join(dict.fromkeys([str(x) for x in reason if x])),
            'retry_until_fresh': True,
            'requested_ts': nowv,
            'requested_text': now_text(nowv),
            'source': 'strategy_worker_v610_info_tier_candle_lane',
        })
        bucket_counter[bucket] += 1
        lane_counter[lane] += 1
        seen.add(t)

    for r in rows:
        if not isinstance(r, dict):
            continue
        st = _v510_stage(r)
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t or t in seen:
            continue
        txt = _v608_row_text(r)
        age = age_map.get(t, 999999.0)
        reason: List[str] = []
        _levels_v913 = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
        _ctx_v913 = _levels_v913.get('structure_context_v871') if isinstance(_levels_v913.get('structure_context_v871'), dict) else (r.get('structure_context_v871') if isinstance(r.get('structure_context_v871'), dict) else {})
        _source_missing_v913 = bool(_ctx_v913.get('source_missing') or r.get('structure_context_source_missing_v871'))
        _integrity_block_v1048 = bool(r.get('structure_integrity_block_v1049') or r.get('structure_integrity_block_v1048') or _ctx_v913.get('structure_integrity_block_v1049') or _ctx_v913.get('structure_integrity_block_v1048'))
        if _integrity_block_v1048:
            add_target(r, 'core_structure_integrity_refresh_v1048', 1200, 60, ['structure integrity quarantine', 'full HTF/MTF/LTF candle refresh before new plan'], 'core', 'structure_full_htf_mtf_ltf')
            if t in seen:
                continue
        if _source_missing_v913:
            # Missing major/setup material is a pipeline refresh request, not a strategy gate.
            # Keep all eligible rows; target_router/candle_worker decides TTL/time-budget order.
            if st in ('S1','S2'):
                add_target(r, 'core_structure_source_missing_v914', 990 if st == 'S1' else 950, 120, ['major/setup source missing', 'v914 full HTF/MTF/LTF refresh'], 'core', 'structure_full_htf_mtf_ltf')
            elif st == 'S3':
                add_target(r, 'near_structure_source_missing_v914', 880, 180, ['major/setup source missing', 'v914 full HTF/MTF/LTF refresh'], 'near', 'structure_full_htf_mtf_ltf')
            if t in seen:
                continue

        if st == 'S1':
            if age > 75:
                add_target(r, 'core_S1_candle_fresh_lock', 1000, 90, ['S1 candle age >75s'], 'core')
            continue

        if st == 'S2':
            needs = False
            if bool(r.get('v574_fresh_urgent_request')):
                needs = True; reason.append('S2 fresh urgent')
            if any(w in txt for w in ('fresh_wait','신선','정보','공식 캔들','공식캔들','candle')):
                needs = True; reason.append('S2 candle/fresh wait')
            if age > 120 and ('s2_recheck' in txt or 'trigger_wait' in txt or 'fresh_wait' in txt):
                needs = True; reason.append('S2 stale while waiting')
            # S2는 fresh_wait 문구가 없어도 core lane에서 신선도 유지가 필요하다.
            if age > 180:
                needs = True; reason.append('S2 stale protection')
            if needs:
                add_target(r, 'core_S2_candle_fresh_lock', 940, 120, reason, 'core')
            continue

        if st != 'S3':
            continue
        if age <= 120:
            continue
        hard_risk = _v608_is_hard_risk_for_candle(r)
        structure_good = _v608_structure_good_for_candle(r)
        gap = _v608_trigger_gap_for_candle(r)
        s1_near = bool(r.get('s1_near_miss')) or str(r.get('s1_near_miss_level') or '').lower() in ('near','mid') or 'near_s1' in txt or 'would_be_s1' in txt
        hot_like = any(w in txt for w in ('hot', 'spike', '급등', '재확인', 'recheck'))
        fresh_text = any(w in txt for w in ('fresh_wait','신선','정보','공식 캔들','공식캔들','candle'))

        if s1_near and not hard_risk:
            add_target(r, 'near_S2_structure_candle', 860, 150, ['S3 near-S2 structure', f'age {round(age,1)}s'], 'near')
        elif gap <= 0.80 and not hard_risk:
            add_target(r, 'near_S3_trigger_candle', 820, 150, [f'trigger_gap {gap:.2f}%', f'age {round(age,1)}s'], 'near')
        elif structure_good and fresh_text and not hard_risk:
            add_target(r, 'near_S3_structure_good_fresh_wait', 780, 180, ['structure good + candle/fresh wait', f'age {round(age,1)}s'], 'near')
        elif hot_like and structure_good and age > 180 and not hard_risk:
            add_target(r, 'watch_S3_hot_structure_candle', 720, 240, ['hot/recheck + structure', f'age {round(age,1)}s'], 'watch')
        elif structure_good and age > 300 and not hard_risk:
            add_target(r, 'watch_S3_structure_refresh', 640, 300, ['structure watch stale refresh', f'age {round(age,1)}s'], 'watch')

    # v610: 고정 개수 제한 금지. 대상은 전부 유지하고, candle_worker가 처리순서/정보깊이만 차등 적용한다.
    targets = sorted(targets, key=lambda x: int(x.get('priority') or 0), reverse=True)
    obj = {
        'schema': 'candle_urgent_targets_v610_info_tier',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'request_count': len(targets),
        'targets': [x.get('ticker') for x in targets],
        'bucket_counts': dict(bucket_counter),
        'lane_counts': dict(lane_counter),
        'structure_integrity_refresh_requests_v1048': int(bucket_counter.get('core_structure_integrity_refresh_v1048', 0)),
        'rows': targets,
        'candle_age_source_v1147':'run_once canonical candle_map with merged delta',
        'direct_full_candle_reload_retired_v1147':True,
        'policy': 'v1147: urgent queue reads the already-loaded canonical Candle map; only actual-plan-overlap integrity rows and source_missing rows request structure_full_htf_mtf_ltf; no numeric strategy thresholds changed.',
    }
    save_runtime_json(CANDLE_URGENT_TARGETS, obj, 'candle_urgent_targets')
    result = load_json_identity_cached(CANDLE_URGENT_RESULT, {}) or {}
    lane_result = result.get('lane_result') if isinstance(result, dict) and isinstance(result.get('lane_result'), dict) else {}
    return {
        'schema': 'strategy_candle_urgent_lock_summary_v610_info_tier',
        'version': VERSION,
        'request_count': len(targets),
        'targets': obj.get('targets'),
        'bucket_counts': obj.get('bucket_counts'),
        'lane_counts': obj.get('lane_counts'),
        'structure_integrity_refresh_requests_v1048': obj.get('structure_integrity_refresh_requests_v1048'),
        'result_schema': result.get('schema') if isinstance(result, dict) else None,
        'result_requested': result.get('requested_count') if isinstance(result, dict) else None,
        'result_refreshed': result.get('refreshed_count') if isinstance(result, dict) else None,
        'result_under_target': result.get('under_target_age_count') if isinstance(result, dict) else None,
        'result_miss': result.get('miss_count') if isinstance(result, dict) else None,
        'lane_result': lane_result,
        'result_rows': (result.get('rows') or [])[:12] if isinstance(result, dict) else [],
        'policy': obj.get('policy'),
    }

V655_STRATEGY_BUILD = "strategy_worker_v0.150_v655_strategy_cpu_recheck_lane"

def _v655_metric(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    return _v510_num(*[row.get(k) for k in keys], default=default)

def _v655_text_blob(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ("strategy_label","strategy","strategy_key","s_stage_reasons","block_reasons","risk_tags","structure_tags","s1_missing_conditions","condition_roles"):
        v = row.get(k)
        if isinstance(v, dict):
            vals += [str(x) for arr in v.values() if isinstance(arr, list) for x in arr]
        elif isinstance(v, list):
            vals += [str(x) for x in v]
        else:
            vals.append(str(v or ""))
    return " ".join(vals)

def _v655_recheck_classify(row: Dict[str, Any]) -> Tuple[str, List[str]]:
    st = _v510_stage(row)
    blob = _v655_text_blob(row)
    react = _v655_metric(row, "price_reaction_pct", "change_1m_pct", "price_chg_60s")
    buy = _v655_metric(row, "buy_ratio")
    sustain = _v655_metric(row, "buy_sustain_1m", "buy_sustain_20s", "buy_ratio_20s")
    spread = _v655_metric(row, "spread_pct", default=99.0)
    slip = _v655_metric(row, "slippage_pct", "spread_pct", default=spread)
    ch30 = _v655_metric(row, "price_chg_30s")
    ch60 = _v655_metric(row, "price_chg_60s", "change_1m_pct")
    stale = row.get("stale_reasons") if isinstance(row.get("stale_reasons"), list) else []
    hard_words = ("매도벽/매도체결압력", "강한 매도압력", "가짜돌파", "늦은추격 위험", "급등형 매도압력", "거래정지", "비정상")
    severe_risk = bool(spread >= 0.65 or slip >= 0.65 or any(w in blob for w in hard_words))
    hot_chase_bad = bool(("hot-rank" in blob or "급등" in blob) and (spread > 0.85 or buy < 0.45 or sustain < 0.45))
    structure_good = any(w in blob for w in ("VWAP", "EMA", "돈흐름", "주도흐름", "상대강도", "눌림", "재돌파", "저점유동성쓸림", "돌파"))
    confirm_near = bool(react >= 0.20 or ch30 >= 0.25 or ch60 >= 0.35 or buy >= 0.58 or sustain >= 0.58)
    exec_okish = bool(spread <= 0.35 and slip <= 0.35 and buy >= 0.50)
    reasons: List[str] = []
    if stale and (confirm_near or structure_good): reasons.append("정보 오래됨→긴급 재수집")
    if structure_good and confirm_near: reasons.append("구조+확인신호 근접")
    if exec_okish: reasons.append("실행위험 재확인 가능")
    if severe_risk or hot_chase_bad:
        return "risk_observe", ["실행위험/추격위험 우선"]
    if st == "S2":
        return "s2_keepalive", reasons or ["S2 신선도 유지"]
    if st == "S3" and structure_good and confirm_near and exec_okish:
        return "s3_to_s2_recheck", reasons or ["S3→S2 재확인 승격"]
    if st == "S3" and stale and (structure_good or react >= 0.05):
        return "s3_info_urgent", reasons or ["정보오래됨 우선갱신"]
    return "observe", reasons or ["관찰"]

def _v655_apply_strategy_recheck_lanes__L2924(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    counts: Dict[str, int] = {}
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        lane, reasons = _v655_recheck_classify(rr)
        counts[lane] = counts.get(lane, 0) + 1
        rr["v655_strategy_lane"] = lane
        rr["v655_strategy_lane_reasons"] = reasons[:5]
        rr["strategy_cpu_recheck_build"] = V655_STRATEGY_BUILD
        if lane == "s3_to_s2_recheck" and _v510_stage(rr) == "S3":
            rr["s_stage"] = rr["candidate_stage"] = rr["candidate_grade"] = rr["stage"] = rr["grade"] = "S2"
            rr["recheck_state"] = "S2 재확인"
            prev = rr.get("s2_recheck_reasons") if isinstance(rr.get("s2_recheck_reasons"), list) else []
            rr["s2_recheck_reasons"] = _v510_uniq(list(prev) + ["v655:S3 구조/확인근접 재확인"] + reasons, 8)
            br = rr.get("block_reasons") if isinstance(rr.get("block_reasons"), list) else []
            rr["block_reasons"] = _v510_uniq(list(br) + ["재확인: 구조/확인신호 근접 S2 승격"], 12)
            rr["open_eligible"] = False; rr["paper_bot_open"] = False; rr["trade_ready"] = False
        out.append(rr)
    return out, {"schema":"strategy_recheck_lane_summary_v655", "version":VERSION, "updated_ts":nowv, "counts":counts, "policy":"S1/청산/자동매수 변경 없음. S3 중 실행위험 낮고 구조+확인신호가 근접한 후보만 S2 재확인으로 올려 정보배관 우선순위를 높임."}

def _v732_reseal_common_uprising_promotions__L2948(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """공통 상승포착 승급판과 실제 stage/paper handoff를 같은 spine으로 맞춘다.

    - S3 관찰/복기 row는 어떤 구경로가 다시 S2로 올려도 S3로 재봉인한다.
    - common_uprising_pass + s2_to_s1_promoted row는 현재 cycle의 승급 이벤트로 보고
      created/event timestamp를 now로 재봉인해 final_entry_gate의 old paper age 착시를 제거한다.
    - summary count는 실제 S1/open_eligible row 기준으로 다시 세운다.
    """
    out: List[Dict[str, Any]] = []
    effective = 0
    blocked = Counter()
    family = Counter()
    family_effective = Counter()
    family_blocked = Counter()
    forced_s3 = 0
    mismatch_before = 0

    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = dict(src)
        fam = str(r.get("s2_to_s1_promotion_family_v732") or "-")
        observe_only = bool(
            r.get("s3_observe_v732") or r.get("s3_observe_v730") or r.get("s3_observe_v729") or r.get("s3_observe_v728") or r.get("s3_observe_v727")
            or str(r.get("strategy_key") or "").startswith("coin_quality_s3_observe")
        )

        if observe_only:
            if _v510_stage(r) != "S3":
                forced_s3 += 1
            r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S3"
            r["open_eligible"] = False
            r["paper_bot_open"] = False
            r["trade_ready"] = False
            r["v732_stage_resealed"] = "S3_observe_only"
            r["s2_to_s1_promoted_v732"] = False
            r["common_uprising_pass_v732"] = False
            out.append(r)
            continue

        promo = bool(r.get("s2_to_s1_promoted_v732") and r.get("common_uprising_pass_v732"))
        if fam and fam != "-":
            family[fam] += 1

        if promo and _v510_stage(r) != "S1":
            mismatch_before += 1
        if promo:
            # 승급은 현재 cycle에서 새로 발생한 entry candidate이므로 timestamp를 현재로 봉인한다.
            for k in ("created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "updated_ts"):
                r[k] = nowv
            r["expires_at"] = nowv + max(60.0, float(CANDIDATE_TTL_SEC or 90))
            r["promoted_at_v732"] = nowv
            r["promoted_at_text_v732"] = now_text(nowv)
            r["promotion_spine_v732"] = "common_uprising_to_s1_resealed"
            r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S1"
            r["open_eligible"] = True
            r["paper_bot_open"] = True
            r["trade_ready"] = True
            r["v732_stage_resealed"] = "S1_common_uprising"
            stale = [x for x in (r.get("stale_reasons") or []) if not str(x).startswith("paper ")]
            r["stale_reasons"] = stale
            ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
            ctx = dict(ctx)
            ctx.update({
                "promotion_spine_v732": "common_uprising_to_s1_resealed",
                "promoted_at_v732": nowv,
                "stage_after_promotion_v732": "S1",
                "open_eligible": True,
            })
            r["entry_context"] = ctx
            effective += 1
            if fam and fam != "-":
                family_effective[fam] += 1
        else:
            # S2 대상에서 승급 안 된 row만 blocked로 집계한다.
            stage_now = _v510_stage(r)
            is_target = bool(stage_now == "S2")
            if is_target:
                br = list(r.get("s2_to_s1_promotion_blocked_v732") or r.get("common_uprising_blocked_v732") or [])
                if not br:
                    br = ["공통 상승포착 미통과"]
                for b in br[:5]:
                    blocked[str(b)] += 1
                if fam and fam != "-":
                    family_blocked[fam] += 1
        out.append(r)

    counts_after = _v510_counts(out)
    return out, {
        "schema": "promotion_stage_spine_v732",
        "version": VERSION,
        "updated_ts": nowv,
        "effective_s1_promotions": effective,
        "mismatch_before_reseal": mismatch_before,
        "forced_s3_observe_rows": forced_s3,
        "s1_count_after_reseal": int(counts_after.get("S1", 0)),
        "s2_count_after_reseal": int(counts_after.get("S2", 0)),
        "s3_count_after_reseal": int(counts_after.get("S3", 0)),
        "blocked_top": dict(blocked.most_common(8)),
        "family_target": dict(family.most_common(8)),
        "family_effective": dict(family_effective.most_common(8)),
        "family_blocked": dict(family_blocked.most_common(8)),
        "policy": "common_uprising pass rows are resealed to actual S1 before publish/summary/paper handoff; S3 observe rows remain S3.",
    }

def _v732_age_value_for_hold(row: Dict[str, Any], keys: Tuple[str, ...], default: float = 0.0) -> float:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    for src in (row, ctx, row.get("canonical_metric_row") if isinstance(row.get("canonical_metric_row"), dict) else {}):
        if not isinstance(src, dict):
            continue
        for k in keys:
            try:
                v = src.get(k)
                if v not in (None, "", [], {}):
                    return _v510_num(v, default=default)
            except Exception:
                pass
    return default

def _v732_trigger_state_for_hold(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    trigger = _v510_num(row.get("trigger_price"), ctx.get("trigger_price"), row.get("entry_trigger_price"), default=0.0)
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("live_price"), row.get("price"), default=0.0)
    reached = True
    gap = 0.0
    if trigger > 0 and price > 0:
        reached = price >= trigger
        gap = ((price - trigger) / trigger) * 100.0
    return {
        "trigger_price": trigger,
        "entry_price": price,
        "trigger_reached": bool(reached),
        "trigger_gap_pct": round(gap, 4),
        "reason": "방아쇠 도달" if reached else "방아쇠 미도달",
    }

V928_LEGACY_HOLD_JSONL = BASE_DIR / "paper_s1_hold_cache.jsonl"

_V928_LEGACY_HOLD_ARCHIVE_RESULT: Dict[str, Any] = {}

def _v928_file_bytes(path: Path) -> int:
    try:
        return int(path.stat().st_size) if path.exists() and path.is_file() else 0
    except Exception:
        return 0

def _v928_bound_value(value: Any, depth: int = 0, *, max_depth: int = 4) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value[:600] if isinstance(value, str) else value
    if depth >= max_depth:
        if isinstance(value, dict):
            return {"_trimmed": True, "key_count": len(value)}
        if isinstance(value, (list, tuple)):
            return list(value[:6])
        return str(value)[:300]
    if isinstance(value, (list, tuple)):
        return [_v928_bound_value(x, depth + 1, max_depth=max_depth) for x in list(value)[:24]]
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for k, v in list(value.items())[:90]:
            key = str(k)
            if key.lower() in {
                'raw_candles','candles','ohlcv','orderbook','orderbook_raw','trades_raw',
                'all_rows','source_rows','debug_rows','history_rows','raw_payload','raw_materials',
            }:
                continue
            out[key] = _v928_bound_value(v, depth + 1, max_depth=max_depth)
        return out
    return str(value)[:300]

def _v928_compact_runtime_row(row: Dict[str, Any]) -> Dict[str, Any]:
    src = row if isinstance(row, dict) else {}
    try:
        base = _v861_compact_row_for_latest(src) if '_v861_compact_row_for_latest' in globals() else _v821_compact_candidate_row(src)
    except Exception:
        base = {}
    out: Dict[str, Any] = dict(base) if isinstance(base, dict) else {}
    # Keep every scalar needed by paper/open/review without copying large nested debug payloads.
    for k, v in src.items():
        if isinstance(v, (str, int, float, bool)) or v is None:
            out[k] = v[:600] if isinstance(v, str) else v
        elif isinstance(v, (list, tuple)) and k in {
            'block_reasons','s_stage_reasons','risk_tags','warning_tags','structure_tags',
            'paper_entry_hold_reasons','paper_final_block_reasons','final_trade_reasons',
            'final_entry_reasons','stale_reasons','extreme_quality_risk_tags_v925',
        }:
            out[k] = _v928_bound_value(v)
    for k in (
        'minimal_entry_gate_v925','structure_plan_provenance_v925','quality_observation_v925',
        'canonical_entry_decision','common_entry_decision','entry_context','entry_plan','structure_levels',
        'trigger_gate_v790','trigger_gate_v738','trigger_gate_v732','candidate_input_coverage_v908',
        'worker_cache_overlay_status_v908','execution_cost_reference_v917','paper_execution_cost_v917',
    ):
        if isinstance(src.get(k), dict):
            out[k] = _v928_bound_value(src.get(k), max_depth=5)
    out['runtime_compact_v928'] = True
    return out

def _v928_archive_legacy_hold_jsonl() -> Dict[str, Any]:
    global _V928_LEGACY_HOLD_ARCHIVE_RESULT
    if _V928_LEGACY_HOLD_ARCHIVE_RESULT:
        return dict(_V928_LEGACY_HOLD_ARCHIVE_RESULT)
    path = V928_LEGACY_HOLD_JSONL
    result: Dict[str, Any] = {
        'state': 'not_present', 'source': str(path), 'bytes_before': _v928_file_bytes(path),
        'archive': None, 'removed': False, 'error': None,
    }
    if not path.exists() or not path.is_file():
        _V928_LEGACY_HOLD_ARCHIVE_RESULT = result
        return dict(result)
    try:
        archive_dir = BASE_DIR / 'archive'
        archive_dir.mkdir(parents=True, exist_ok=True)
        stamp = time.strftime('%Y%m%d_%H%M%S', time.localtime())
        archive = archive_dir / f'paper_s1_hold_cache_jsonl_retired_v928_{stamp}.jsonl.gz'
        with path.open('rb') as src, gzip.open(archive, 'wb', compresslevel=6) as dst:
            while True:
                chunk = src.read(1024 * 1024)
                if not chunk:
                    break
                dst.write(chunk)
        if not archive.exists() or archive.stat().st_size <= 0:
            raise IOError('legacy hold archive verification failed')
        path.unlink()
        result.update({'state': 'archived_removed', 'archive': str(archive), 'archive_bytes': _v928_file_bytes(archive), 'removed': True})
    except Exception as exc:
        result.update({'state': 'error', 'error': f'{exc.__class__.__name__}: {exc}'})
        try: append_error(ERROR, 'v928_archive_legacy_hold_jsonl', exc)
        except Exception: pass
    _V928_LEGACY_HOLD_ARCHIVE_RESULT = result
    return dict(result)

def _v931_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8')

def _v931_small_mapping(value: Any, depth: int = 0, max_depth: int = 2, max_keys: int = 56) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value[:800] if isinstance(value, str) else value
    if isinstance(value, (list, tuple)):
        out=[]
        for x in list(value)[:20]:
            if isinstance(x, (str, int, float, bool)) or x is None:
                out.append(x[:500] if isinstance(x, str) else x)
            elif depth < max_depth and isinstance(x, dict):
                out.append(_v931_small_mapping(x, depth+1, max_depth=max_depth, max_keys=24))
        return out
    if not isinstance(value, dict):
        return str(value)[:500]
    if depth >= max_depth:
        out={}
        for k,v in list(value.items())[:max_keys]:
            if isinstance(v, (str,int,float,bool)) or v is None:
                out[str(k)] = v[:500] if isinstance(v,str) else v
        return out
    blocked = {
        'raw','raw_payload','raw_materials','raw_candles','candles','ohlcv','orderbook','orderbook_raw',
        'trades_raw','all_rows','source_rows','debug_rows','history_rows','candidate_row','source_event',
        'source_row','_source_row','canonical_metric_row','entry_snapshot',
    }
    out={}
    for k,v in list(value.items())[:max_keys]:
        key=str(k)
        if key in blocked:
            continue
        if isinstance(v,(str,int,float,bool)) or v is None:
            out[key]=v[:800] if isinstance(v,str) else v
        elif isinstance(v,(list,tuple)):
            out[key]=_v931_small_mapping(v, depth+1, max_depth=max_depth, max_keys=24)
        elif isinstance(v,dict):
            out[key]=_v931_small_mapping(v, depth+1, max_depth=max_depth, max_keys=32)
    return out

def _v931_compact_plan(plan: Any) -> Dict[str, Any]:
    src=plan if isinstance(plan,dict) else {}
    out={}
    for k in ('schema','state_key','frozen_ts','first_seen_ts','last_seen_ts','source_plan_move_detected',
              'frozen_plan_held','trigger_reached','current_confirmation_price','distance_pct','policy'):
        if src.get(k) not in (None,'',[],{}):
            out[k]=src.get(k)
    for k in ('trigger','invalid','target','move_pct'):
        if isinstance(src.get(k),dict):
            out[k]=_v931_small_mapping(src.get(k), max_depth=2, max_keys=28)
    if isinstance(src.get('trigger_occurrence'),dict):
        out['trigger_occurrence']=_v931_small_mapping(src.get('trigger_occurrence'),max_depth=2,max_keys=28)
    return out

def _v931_compact_gate(gate: Any) -> Dict[str, Any]:
    src=gate if isinstance(gate,dict) else {}
    out={}
    scalar_keys=(
        'schema','version','build','updated_ts','decision_key','state_key','hard_pass','stage','final_trade_state',
        'structure_ready','source_fresh','invalid_price','target_price','target_room_pct','risk_reward','spread_pct',
        'spread_limit_pct','confirmed_slippage_pct','confirmed_slippage_source','entry_slippage_est_pct','entry_slippage_source','entry_slippage_ts','entry_slippage_age_sec','entry_slippage_confirmed','entry_slippage_basis','entry_slippage_order_amount_krw','entry_slippage_order_amount_state','entry_slippage_owner','minimum_risk_reward',
        'minimum_target_room_pct','quality_observation_only','auto_buy','exit_changed','execution_fresh_ok_v1039','quality_price_reaction_state_v1039','quality_final_hard_block_v1039','swing_quality_rank','swing_quality_rank_score','quality_rank_owner','trigger_occurrence_owner_state_v1128','trigger_occurrence_owner_reason_v1128',
    )
    for k in scalar_keys:
        if src.get(k) not in (None,'',[],{}):
            out[k]=src.get(k)
    for k in ('hard_block_reasons','extreme_quality_risk_tags'):
        if isinstance(src.get(k),list):
            out[k]=[str(x)[:300] for x in src.get(k)[:20]]
    if isinstance(src.get('execution_freshness_v1039'),dict):
        out['execution_freshness_v1039']=_v931_small_mapping(src.get('execution_freshness_v1039'),max_depth=2,max_keys=24)
    if isinstance(src.get('swing_quality_gate'),dict):
        out['swing_quality_gate']=_v931_small_mapping(src.get('swing_quality_gate'),max_depth=2,max_keys=28)
    if isinstance(src.get('trigger_occurrence'),dict):
        out['trigger_occurrence']=_v931_small_mapping(src.get('trigger_occurrence'),max_depth=2,max_keys=28)
    plan=src.get('structure_plan') if isinstance(src.get('structure_plan'),dict) else src.get('trigger')
    if isinstance(plan,dict):
        compact_plan=_v931_compact_plan(plan)
        out['structure_plan']=compact_plan
        # Compatibility key remains small and points to the same frozen values, not the old full duplicate.
        out['trigger']={k:v for k,v in compact_plan.items() if k in {'schema','state_key','frozen_ts','trigger','invalid','target','source_plan_move_detected','frozen_plan_held','trigger_reached','current_confirmation_price','distance_pct'}}
    return out

def _v931_compact_decision(decision: Any) -> Dict[str, Any]:
    src=decision if isinstance(decision,dict) else {}
    out={}
    for k,v in src.items():
        if k in {'metrics','minimal_entry_gate_v925','structure_plan','trigger'}:
            continue
        if isinstance(v,(str,int,float,bool)) or v is None:
            out[k]=v[:800] if isinstance(v,str) else v
        elif isinstance(v,list):
            out[k]=[str(x)[:300] for x in v[:20]]
        elif isinstance(v,dict) and k in {'quality_observation_only'}:
            out[k]=_v931_small_mapping(v,max_depth=1,max_keys=24)
    metrics=src.get('metrics') if isinstance(src.get('metrics'),dict) else {}
    if metrics:
        out['metrics']={k:metrics.get(k) for k in ('decision_key','hard_pass','stage','final_trade_state','target_room_pct','risk_reward','spread_pct','source_fresh') if metrics.get(k) not in (None,'',[],{})}
    return out

V932_HOLD_ROW_MAX_BYTES = int(os.getenv('S1_HOLD_ROW_MAX_BYTES_V932', str(24 * 1024)))

_V932_HOLD_CORE_SCALARS = {
    'schema','version','build','ticker','market','symbol','event_id','event_key','trace_id','handoff_id','candidate_uid','id',
    'entry_build_key','swing_gate_decision_key_v977','paper_decision_key_v926','candidate_pipeline_cycle_id_v1150','candidate_pipeline_cycle_started_ts_v1152','good_s2_state_key_v923','good_s2_occurrence_key_v923','good_s2_started_ts_v923','good_s2_last_good_ts_v923','good_s2_lifecycle_transition_v923','stable_event_key_v894','stable_event_key_v895','stable_event_key_v896',
    'candidate_follow_key_v894','candidate_follow_key_v895','candidate_follow_key_v896','scan_id','source_scan_id','strategy_scan_id','hold_key',
    's_stage','candidate_stage','stage','candidate_grade','grade','final_trade_state','final_trade_label','final_trade_allowed',
    'open_eligible','paper_bot_open','trade_ready','fresh_gate_ok','source_fresh','freshness_status','execution_fresh_ok_v1039','quality_price_reaction_state_v1039','quality_final_hard_block_v1039',
    's1_hold_v732','s1_hold_v734','s1_hold_v735','s1_hold_v736','s1_hold_v737','s1_hold_v738','s1_hold_v790',
    's1_hold_status_v732','s1_hold_status_v734','s1_hold_status_v735','s1_hold_status_v736','s1_hold_status_v737','s1_hold_status_v738','s1_hold_status_v790',
    's1_hold_open_ready_v732','s1_hold_open_ready_v734','s1_hold_open_ready_v735','s1_hold_open_ready_v736','s1_hold_open_ready_v737','s1_hold_open_ready_v738','s1_hold_open_ready_v790',
    'hold_created_at','s1_hold_created_at_v1153','trigger_event_at_v1153','quality_evaluated_at_v1153','quality_pass_at_v1153','paper_received_at_v1153','execution_data_ready_at_v1153','selector_decided_at_v1153','open_committed_at_v1153','terminal_blocked_at_v1153','hold_expires_at','hold_updated_ts_v929','created_at','candidate_created_at','source_created_at','detected_ts','event_ts','updated_ts','expires_at','timestamp','ts',
    'live_price','current_price','price','trade_price','close','last_price','entry_price','detected_price','trigger_price','trigger_price_rounded_v925','trigger_reached','trigger_gap_pct',
    'invalid_price','swing_invalid_price_v977','stop_loss_price','stop_price','target_price','swing_target_price_v977','target1_price','target_room_pct','risk_reward','risk_reward_ratio','rr_ratio',
    'spread_pct','micro_spread_pct','orderbook_spread_pct','entry_slippage_est_pct','entry_slippage_source','entry_slippage_ts','entry_slippage_age_sec','entry_slippage_confirmed','entry_slippage_basis','entry_slippage_order_amount_krw','entry_slippage_order_amount_state','entry_slippage_owner','slippage_pct','slippage_pct_confirmed','slippage_pct_source','slippage_pct_source_v903','slippage_source','slippage_derived_from_spread_v903',
    'price_age_sec','price_reaction_age_sec','micro_age_sec','orderflow_age_sec','trade_age_sec','quote_age_sec','ws_age_sec','source_age','candidate_age_sec',
    'micro_fresh','micro_row_status','ws_fresh','ws_row_status','hot_signal_age_sec','scanner_hot_age_sec','scanner_hot_fresh','hot_fresh',
    'score','leader_score','candidate_quality_score','swing_quality_rank','swing_quality_rank_score','quality_rank_owner','quality_source_missing','strategy_key','strategy_label','strategy','route','entry_profile','exit_profile','profile_family',
    'strategy_mode','strategy_mode_v977','paper_source_v732','paper_source_v790','final_entry_action','final_entry_label','paper_handoff_ts','strategy_worker_version','main_version','deploy_version','patch_version',
    's1_hold_canonical_resealed_v738','s1_hold_canonical_resealed_v790','same_key_sealed_v895','same_key_sealed_v896',
}

_V932_HOLD_LIST_KEYS = {
    'stale_reasons','hard_block_reasons','final_trade_reasons','final_entry_reasons','paper_entry_hold_reasons','paper_final_block_reasons',
    's_stage_reasons','block_reasons','risk_tags','warning_tags','structure_tags','confirm_signals','extreme_quality_risk_tags_v925','matched_strategies','entry_reasons',
}

_V932_HOLD_OPTIONAL_SUFFIX = ('_ts','_age_sec','_pct','_price','_key','_id','_status','_state','_ok','_ready','_fresh','_source','_tf','_version','_build')

def _v932_scalar(v: Any) -> Any:
    if isinstance(v, str): return v[:360]
    return v

def _v932_compact_entry_context(src: Any) -> Dict[str, Any]:
    ctx=src if isinstance(src,dict) else {}
    keys={
        'ticker','market','symbol','current_price','live_price','price','entry_price','trigger_price','micro_age_sec','orderflow_age_sec','trade_age_sec','quote_age_sec','ws_age_sec',
        'micro_fresh','micro_row_status','ws_fresh','ws_row_status','spread_pct','entry_slippage_est_pct','entry_slippage_source','entry_slippage_ts','entry_slippage_age_sec','entry_slippage_confirmed','entry_slippage_basis','entry_slippage_order_amount_krw','entry_slippage_order_amount_state','entry_slippage_owner','slippage_pct','slippage_pct_confirmed','slippage_pct_source','slippage_pct_source_v903',
        'entry_profile','exit_profile','profile_family','final_trade_state','final_trade_allowed','final_trade_label',
        's1_hold_v738','s1_hold_v790','s1_hold_status_v738','s1_hold_status_v790','s1_hold_open_ready_v738','s1_hold_open_ready_v790',
    }
    out={k:_v932_scalar(ctx.get(k)) for k in keys if ctx.get(k) not in (None,'',[],{}) and isinstance(ctx.get(k),(str,int,float,bool))}
    fr=ctx.get('s1_hold_freshness_v790') if isinstance(ctx.get('s1_hold_freshness_v790'),dict) else ctx.get('s1_hold_freshness_v738')
    if isinstance(fr,dict): out['s1_hold_freshness_v790']=_v931_small_mapping(fr,max_depth=1,max_keys=12)
    tg=ctx.get('trigger_gate_v790') if isinstance(ctx.get('trigger_gate_v790'),dict) else ctx.get('trigger_gate_v738')
    if isinstance(tg,dict): out['trigger_gate_v738']=_v931_small_mapping(tg,max_depth=1,max_keys=20)
    return out

def _v932_compact_s1_hold_row(row: Dict[str, Any]) -> Dict[str, Any]:
    src=row if isinstance(row,dict) else {}
    out: Dict[str,Any]={}
    for k in _V932_HOLD_CORE_SCALARS:
        v=src.get(k)
        if isinstance(v,(str,int,float,bool)) or v is None:
            if v not in (None,''): out[k]=_v932_scalar(v)
    for k in _V932_HOLD_LIST_KEYS:
        v=src.get(k)
        if isinstance(v,list) and v: out[k]=[str(x)[:180] for x in v[:12]]
    gate=_v931_compact_gate(src.get('swing_entry_gate_v977'))
    if gate: out['swing_entry_gate_v977']=gate
    plan=_v931_compact_plan(src.get('swing_structure_plan_v977'))
    if plan: out['swing_structure_plan_v977']=plan
    tg=src.get('trigger_gate_v738') if isinstance(src.get('trigger_gate_v738'),dict) else src.get('trigger_gate_v790')
    if isinstance(tg,dict): out['trigger_gate_v738']=_v931_small_mapping(tg,max_depth=1,max_keys=24)
    ctx=_v932_compact_entry_context(src.get('entry_context'))
    if ctx: out['entry_context']=ctx
    dec=_v931_compact_decision(src.get('canonical_entry_decision'))
    if dec: out['canonical_entry_decision']=dec
    for k in ('quality_observation_v925','execution_cost_reference_v917','paper_execution_cost_v917'):
        if isinstance(src.get(k),dict): out[k]=_v931_small_mapping(src.get(k),max_depth=1,max_keys=20)
    if isinstance(src.get('candidate_path_timestamps_v1153'),dict):
        out['candidate_path_timestamps_v1153']=_v931_small_mapping(src.get('candidate_path_timestamps_v1153'),max_depth=1,max_keys=24)
    # Optional scalar compatibility fields are admitted only while under the hard ceiling.
    optional=[]
    for k,v in src.items():
        if k in out or k in _V932_HOLD_CORE_SCALARS: continue
        if not isinstance(v,(str,int,float,bool)) or v in (None,''): continue
        if k.endswith(_V932_HOLD_OPTIONAL_SUFFIX) or k.startswith(('paper_','entry_','trigger_','source_','freshness_')):
            optional.append((k,_v932_scalar(v)))
    for k,v in sorted(optional):
        out[k]=v
        if len(_v931_json_bytes(out)) > V932_HOLD_ROW_MAX_BYTES:
            out.pop(k,None)
            break
    out['runtime_compact_v928']=True
    out['s1_hold_compact_v931']=True
    out['s1_hold_compact_v932']=True
    out['s1_hold_source_bytes_v932']=len(_v931_json_bytes(src))
    out['s1_hold_compact_bytes_v932']=len(_v931_json_bytes(out))
    return out

STRATEGY_PIPELINE_COMMIT_V1150 = BASE_DIR / 'strategy_candidate_pipeline_commit_v1150.json'

STRATEGY_PAPER_HANDOFF_DIR_V1158 = BASE_DIR / 'runtime' / 'strategy_paper_handoff_generations_v1158'


# v1317: immutable full candidate generation for Review/Paper single-source readers.
# paper_candidates_latest.jsonl remains the active rolling latest file; this file is
# a bounded, generation-addressable proof so async consumers do not chase a later cycle.
STRATEGY_CANDIDATE_GENERATION_DIR_V1317 = BASE_DIR / 'runtime' / 'strategy_candidate_generations_v1317'

def _v1317_jsonl_digest_rows(rows: list[dict]) -> str:
    h = hashlib.sha256()
    for row in rows or []:
        blob = json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode('utf-8')
        h.update(blob); h.update(b'\n')
    return h.hexdigest()

def _v1317_publish_candidate_generation_file(cycle_id: str, commit_id: str, rows: list[dict]) -> dict:
    cycle = str(cycle_id or '').strip(); commit = str(commit_id or '').strip()
    obj = {'schema':'strategy_candidate_generation_file_v1317','version':VERSION,'build':BUILD_LABEL,
           'cycle_id':cycle or None,'candidate_commit_id':commit or None,'rows':len(rows or []),
           'state':'SKIP','path':None,'sha256':None,'auto_buy':False,
           'policy':'immutable full candidate snapshot for Review/Paper async readers; no formula/trigger/RR/exit change'}
    if not cycle or not commit:
        obj['reason']='missing_cycle_or_commit'; return obj
    STRATEGY_CANDIDATE_GENERATION_DIR_V1317.mkdir(parents=True, exist_ok=True)
    safe = hashlib.sha256(f'{cycle}|{commit}'.encode('utf-8')).hexdigest()[:20]
    path = STRATEGY_CANDIDATE_GENERATION_DIR_V1317 / f'candidates-{safe}.jsonl'
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    with tmp.open('wb') as f:
        for row in rows or []:
            blob = json.dumps(row, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str).encode('utf-8')
            f.write(blob); f.write(b'\n')
        f.flush(); os.fsync(f.fileno())
    os.replace(tmp, path)
    digest = _v1317_jsonl_digest_rows(rows or [])
    obj.update({'state':'NORMAL','path':str(path),'sha256':digest,'bytes':path.stat().st_size,
                'written_ts':now_ts(),'written_text':now_text()})
    # Bound transient generation proof files; never touches trading ledgers.
    try:
        files = sorted(STRATEGY_CANDIDATE_GENERATION_DIR_V1317.glob('candidates-*.jsonl'), key=lambda x: x.stat().st_mtime, reverse=True)
        removed=[]
        for old in files[8:]:
            try:
                removed.append(old.name); old.unlink()
            except Exception:
                pass
        obj['retention_keep']=8; obj['retired_old_files']=removed[:20]
    except Exception as exc:
        obj['retention_error']=f'{type(exc).__name__}: {exc}'
    return obj

def _v1158_commit_paper_handoff(cycle_id: str, candidate_commit_id: str, hold_summary: Dict[str, Any],
                                  candidate_rows: int, priority_request_count: int, target_count: int,
                                  completed_ts: Optional[float]=None, *,
                                  s1_hold_completed_ts: Optional[float]=None,
                                  candidate_snapshot_completed_ts: Optional[float]=None,
                                  priority_requests_completed_ts: Optional[float]=None) -> Dict[str, Any]:
    """Write one immutable completed generation for Paper consumption.

    A generation-specific file avoids the two-file promotion race: while the next
    generation is being written, the previous completed file remains addressable by
    `last_complete_cycle_v1152`.
    """
    cycle=str(cycle_id or '').strip(); commit_id=str(candidate_commit_id or '').strip()
    hold=hold_summary if isinstance(hold_summary,dict) else {}
    hold_cycle=str(hold.get('candidate_pipeline_cycle_id_v1150') or '').strip()
    rows=hold.get('rows') if isinstance(hold.get('rows'),list) else []
    if not cycle or hold_cycle != cycle:
        raise RuntimeError(f'v1158 committed handoff cycle mismatch expected={cycle} hold={hold_cycle}')
    if not commit_id:
        raise RuntimeError('v1158 committed handoff candidate_commit_id missing')
    ts=float(completed_ts or now_ts())
    # v1166: seal the exact transport-stage timestamps into the immutable rows.
    # These are runtime evidence only.  They let Paper distinguish strategic waiting
    # (trigger/quality/S1 conditions) from actual file/generation transport time.
    s1_done=float(s1_hold_completed_ts or 0.0)
    candidate_done=float(candidate_snapshot_completed_ts or 0.0)
    priority_done=float(priority_requests_completed_ts or 0.0)
    sealed_rows=[]
    for source_row in rows:
        if not isinstance(source_row,dict):
            continue
        sealed=dict(source_row)
        path_ts=dict(sealed.get('candidate_path_timestamps_v1153') or {}) if isinstance(sealed.get('candidate_path_timestamps_v1153'),dict) else {'schema':'candidate_path_timestamps_v1153'}
        if s1_done>0: path_ts['s1_hold_file_committed_at_v1166']=s1_done
        if candidate_done>0: path_ts['candidate_snapshot_committed_at_v1166']=candidate_done
        if priority_done>0: path_ts['priority_requests_committed_at_v1166']=priority_done
        path_ts['completed_generation_committed_at_v1166']=ts
        path_ts['transport_cycle_id_v1166']=cycle
        path_ts['transport_candidate_commit_id_v1166']=commit_id
        sealed['candidate_path_timestamps_v1153']=path_ts
        sealed['s1_hold_file_committed_at_v1166']=s1_done or None
        sealed['candidate_snapshot_committed_at_v1166']=candidate_done or None
        sealed['priority_requests_committed_at_v1166']=priority_done or None
        sealed['completed_generation_committed_at_v1166']=ts
        sealed_rows.append(sealed)
    rows=sealed_rows
    digest_source={
        'cycle_id':cycle,'candidate_commit_id':commit_id,'s1_rows':rows,
        'candidate_rows':int(candidate_rows),'priority_request_count':int(priority_request_count),
        'target_count':int(target_count),
    }
    digest=hashlib.sha256(json.dumps(digest_source,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')).hexdigest()
    handoff_id=f'handoff-{digest[:20]}'
    path=STRATEGY_PAPER_HANDOFF_DIR_V1158 / f'{handoff_id}.json'
    payload={
        'schema':'strategy_paper_handoff_committed_v1158','version':VERSION,'build':BUILD_LABEL,
        'handoff_id_v1158':handoff_id,'digest_v1158':digest,'handoff_file_v1158':str(path),
        'cycle_id':cycle,'candidate_commit_id':commit_id,
        'completed_ts':ts,'completed_text':now_text(ts),
        's1_hold_completed_ts_v1166':s1_done or None,
        'candidate_snapshot_completed_ts_v1166':candidate_done or None,
        'priority_requests_completed_ts_v1166':priority_done or None,
        'completed_generation_committed_at_v1166':ts,
        'transport_stage_owner_v1166':'Strategy exact file/generation commit clock',
        'all_required_commits_v1158':True,
        's1_hold_count':len(rows),'s1_rows':rows,
        'candidate_rows':int(candidate_rows),'priority_request_count':int(priority_request_count),
        'target_count':int(target_count),
        'source_s1_hold_updated_ts':hold.get('updated_ts'),'source_s1_hold_schema':hold.get('schema'),
        'owner':'strategy_worker immutable completed-generation handoff writer',
        'paper_consume_policy':'Paper reads exact file named by current/last complete generation; live S1 inventory is observation only',
        'strategy_formula_changed':False,'entry_contract_changed':False,'auto_buy':False,
    }
    save_json(path,payload)
    return payload

def _v1158_cleanup_handoff_generations(keep: int=4) -> Dict[str, Any]:
    """Bound transient generation files; never touches trading ledgers."""
    try:
        files=sorted(STRATEGY_PAPER_HANDOFF_DIR_V1158.glob('handoff-*.json'),key=lambda x:x.stat().st_mtime,reverse=True)
    except Exception:
        files=[]
    removed=0
    for path in files[max(2,int(keep)):]:
        try: path.unlink(missing_ok=True); removed+=1
        except OSError: pass
    return {'kept':min(len(files),max(2,int(keep))),'removed':removed,'policy':'runtime handoff generations only; ledgers untouched'}

def _v1150_write_pipeline_status(cycle_id: str, state: str, **extra: Any) -> Dict[str, Any]:
    """Write current progress while preserving the last fully completed cycle.

    v1152 truth rule:
    - current in-progress state must never erase the previous NORMAL proof;
    - current progress and last complete proof are separate fields;
    - only NORMAL becomes the new last-complete proof.
    This is status evidence only and does not change candidate selection.
    """
    nowv = now_ts()
    state_u = str(state or 'CHECK').upper()
    cycle = str(cycle_id or '')
    previous = load_json(STRATEGY_PIPELINE_COMMIT_V1150, {}) or {}
    same_cycle = str(previous.get('cycle_id') or '') == cycle
    carried: Dict[str, Any] = {}
    if same_cycle:
        for key in (
            'cycle_started_ts','cycle_started_text','s1_hold_count','s1_hold_updated_ts',
            's1_hold_completed_ts_v1152','candidate_rows','candidate_commit_id',
            'candidate_snapshot_completed_ts_v1152','priority_request_count','target_count',
            'priority_requests_completed_ts_v1152','completed_ts_v1152',
            'committed_handoff_id_v1158','committed_handoff_digest_v1158',
            'committed_handoff_file_v1158','committed_handoff_completed_ts_v1158',
        ):
            if previous.get(key) not in (None, '', [], {}):
                carried[key] = previous.get(key)
    last_complete = previous.get('last_complete_cycle_v1152') if isinstance(previous.get('last_complete_cycle_v1152'), dict) else None
    if previous.get('state') == 'NORMAL' and previous.get('complete') is True:
        last_complete = {
            'cycle_id': previous.get('cycle_id'),
            'candidate_commit_id': previous.get('candidate_commit_id'),
            'completed_ts': previous.get('completed_ts_v1152') or previous.get('updated_ts'),
            's1_hold_count': previous.get('s1_hold_count'),
            'candidate_rows': previous.get('candidate_rows'),
            'priority_request_count': previous.get('priority_request_count'),
            'all_required_commits': previous.get('all_required_commits_v1150'),
            'committed_handoff_id_v1158': previous.get('committed_handoff_id_v1158'),
            'committed_handoff_digest_v1158': previous.get('committed_handoff_digest_v1158'),
            'committed_handoff_file_v1158': previous.get('committed_handoff_file_v1158'),
            'committed_handoff_completed_ts_v1158': previous.get('committed_handoff_completed_ts_v1158'),
            'state': 'NORMAL',
        }
    payload: Dict[str, Any] = {
        'schema': 'strategy_candidate_pipeline_commit_v1150',
        'version': VERSION,
        'build': BUILD_LABEL,
        'cycle_id': cycle,
        'state': state_u,
        'complete': state_u == 'NORMAL',
        'progress_state_v1152': ('COMPLETE' if state_u == 'NORMAL' else ('FAILED' if state_u == 'FAIL' else 'IN_PROGRESS')),
        'current_cycle_in_progress_v1152': state_u not in ('NORMAL','FAIL'),
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'owner': 'strategy_worker.run_once candidate pipeline',
        'required_steps': ['S1_HOLD', 'CANDIDATE_SNAPSHOT', 'PRIORITY_REQUESTS'],
        'strategy_formula_changed': False,
        'entry_contract_changed': False,
        'auto_buy': False,
    }
    payload.update(carried)
    payload.update(extra)
    if state_u == 'NORMAL':
        payload['completed_ts_v1152'] = float(payload.get('completed_ts_v1152') or nowv)
        payload['progress_state_v1152'] = 'COMPLETE'
        payload['current_cycle_in_progress_v1152'] = False
        last_complete = {
            'cycle_id': cycle,
            'candidate_commit_id': payload.get('candidate_commit_id'),
            'completed_ts': payload.get('completed_ts_v1152'),
            's1_hold_count': payload.get('s1_hold_count'),
            'candidate_rows': payload.get('candidate_rows'),
            'priority_request_count': payload.get('priority_request_count'),
            'all_required_commits': payload.get('all_required_commits_v1150'),
            'committed_handoff_id_v1158': payload.get('committed_handoff_id_v1158'),
            'committed_handoff_digest_v1158': payload.get('committed_handoff_digest_v1158'),
            'committed_handoff_file_v1158': payload.get('committed_handoff_file_v1158'),
            'committed_handoff_completed_ts_v1158': payload.get('committed_handoff_completed_ts_v1158'),
            'state': 'NORMAL',
        }
    if isinstance(last_complete, dict):
        payload['last_complete_cycle_v1152'] = last_complete
    save_json(STRATEGY_PIPELINE_COMMIT_V1150, payload)
    return payload

def _v1149_s1_hold_count(summary: Any) -> int:
    """Return the current hold-row count without coercing the row list itself."""
    if not isinstance(summary, dict):
        return 0
    count = summary.get('count')
    if isinstance(count, (int, float)) and not isinstance(count, bool):
        return max(0, int(count))
    rows = summary.get('rows')
    return len(rows) if isinstance(rows, list) else 0

def write_s1_hold_cache(rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """Write the paper S1 hold cache from the current sealed S1 rows only.

    v790 fix:
    - The old writer merged previous hold rows for TTL 60s and used a 10-second bucket key.
      That allowed `paper_s1_hold_cache.json` to show S1 hold rows after the current
      canonical candidate rows had already dropped to S1=0, and it could duplicate the
      same ticker several times (e.g. BFC/BFC/BFC).
    - This writer rebuilds the hold cache from the current canonical rows each cycle and
      deduplicates by ticker. It does not loosen any S1/trigger/exit condition.
    """
    hold_path = BASE_DIR / "paper_s1_hold_cache.json"
    ttl = 60.0
    old_obj = load_json(hold_path, {}) or {}
    old_rows = old_obj.get("rows") if isinstance(old_obj, dict) and isinstance(old_obj.get("rows"), list) else []
    old_count = len([x for x in old_rows if isinstance(x, dict)])
    old_by_decision: Dict[str, Dict[str, Any]] = {}
    old_by_ticker: Dict[str, Dict[str, Any]] = {}
    for old_row in old_rows:
        if not isinstance(old_row, dict):
            continue
        old_key = str(old_row.get("swing_gate_decision_key_v977") or "").strip()
        old_ticker = _v661_row_ticker(old_row)
        if old_key:
            old_by_decision[old_key] = old_row
        if old_ticker:
            old_by_ticker[old_ticker] = old_row

    current_s1_by_ticker: Dict[str, Dict[str, Any]] = {}
    source_s1_count = 0
    duplicate_current = 0
    observation_only_skipped_v988 = 0

    for src in rows or []:
        if not isinstance(src, dict):
            continue
        if _v988_is_s3_observation_only(src):
            observation_only_skipped_v988 += 1
            continue
        if _v510_stage(src) != "S1" or not bool(src.get("open_eligible")) or not bool(src.get("paper_bot_open")):
            continue
        source_s1_count += 1
        r = dict(src)
        t = _v661_row_ticker(r)
        if not t:
            continue
        prev = current_s1_by_ticker.get(t)
        if prev is not None:
            duplicate_current += 1
            prev_score = _v510_num(prev.get("score"), prev.get("candidate_quality_score"), default=0.0)
            new_score = _v510_num(r.get("score"), r.get("candidate_quality_score"), default=0.0)
            prev_ts = _v510_num(prev.get("updated_ts"), prev.get("created_at"), default=0.0)
            new_ts = _v510_num(r.get("updated_ts"), r.get("created_at"), default=0.0)
            if (new_ts, new_score) <= (prev_ts, prev_score):
                continue
        current_s1_by_ticker[t] = r

    fresh_count = stale_count = trigger_wait = open_ready_count = 0
    rows_out: List[Dict[str, Any]] = []

    for t, src in current_s1_by_ticker.items():
        r = dict(src)
        # Stable per-ticker key: one live hold row per ticker, no 10-second bucket duplicates.
        key = f"{t}:S1"
        price_age = _v732_age_value_for_hold(r, ("price_reaction_age_sec", "price_age_sec", "quote_age_sec", "price_source_age_sec"), 0.0)
        micro_age = _v732_age_value_for_hold(r, ("micro_age_sec", "trade_age_sec", "quote_age_sec"), 0.0)
        order_age = _v732_age_value_for_hold(r, ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), 0.0)
        source_age = _v732_age_value_for_hold(r, ("source_age", "fresh_age", "age", "candidate_age_sec"), 0.0)
        stale_reasons = list(r.get("stale_reasons") or [])
        if price_age > 60:
            stale_reasons.append(f"price_age {price_age:.0f}s")
        if micro_age > 35:
            stale_reasons.append(f"micro_age {micro_age:.0f}s")
        if order_age > 35:
            stale_reasons.append(f"orderflow_age {order_age:.0f}s")
        if source_age > 120:
            stale_reasons.append(f"source_age {source_age:.0f}s")
        trigger = _v732_trigger_state_for_hold(r)
        is_stale = bool(stale_reasons)
        is_trigger_wait = not bool(trigger.get("trigger_reached"))
        open_ready = bool((not is_stale) and (not is_trigger_wait))
        if open_ready:
            open_ready_count += 1
            status = "fresh_open_ready"
        elif is_stale:
            stale_count += 1
            status = "stale_hold"
        else:
            trigger_wait += 1
            status = "trigger_wait"

        swing_decision_key = str(r.get("swing_gate_decision_key_v977") or "").strip()
        old_hold = old_by_decision.get(swing_decision_key) if swing_decision_key else old_by_ticker.get(t)
        old_hold = old_hold if isinstance(old_hold, dict) else {}
        origin_ts = _v510_num(r.get("candidate_created_at"), r.get("source_created_at"), r.get("detected_ts"), r.get("event_ts"), r.get("created_at"), default=nowv)
        hold_created_ts = _v510_num(old_hold.get("hold_created_at"), default=0.0) if (not swing_decision_key or str(old_hold.get("swing_gate_decision_key_v977") or "").strip() == swing_decision_key) else 0.0
        if hold_created_ts <= 0:
            hold_created_ts = nowv
        s1_first_ts_v1153 = hold_created_ts
        path_ts_v1153 = dict(r.get('candidate_path_timestamps_v1153') or {}) if isinstance(r.get('candidate_path_timestamps_v1153'),dict) else {'schema':'candidate_path_timestamps_v1153','owner':'strategy_worker'}
        path_ts_v1153['s1_hold_created_at']=s1_first_ts_v1153
        ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
        ctx = dict(ctx)
        hold_reasons_v738 = ["S1 hold 통과", str(trigger.get("reason") or "방아쇠 도달")]
        hold_decision_v738 = {
            "schema": "canonical_entry_decision_v979_swing_hold",
            "decision_key": swing_decision_key or None,
            "strategy_mode": "ALT_SWING_V977",
            "entry_gate_contract": "swing_entry_gate_v977_single_owner",
            "gate_pass": True,
            "s1_allowed": True,
            "action": "paper_open_candidate",
            "final_entry_action": "paper_open_candidate",
            "display_reasons": hold_reasons_v738,
            "entry_profile": r.get("entry_profile") or ctx.get("entry_profile") or "normal_common",
            "exit_profile": r.get("exit_profile") or ctx.get("exit_profile") or "normal_exit",
            "profile_family": r.get("profile_family") or ctx.get("profile_family") or "s1_hold",
            "source": "strategy_worker_swing_hold_v979",
            "rechecked_after_hold": False,
            "paper_open_allowed_by_hold": True,
        }
        ctx.update({
            "s1_hold_v732": True,
            "s1_hold_v738": True,
            "s1_hold_v790": True,
            "s1_hold_status_v732": status,
            "s1_hold_status_v738": status,
            "s1_hold_status_v790": status,
            "s1_hold_open_ready_v732": open_ready,
            "s1_hold_open_ready_v738": open_ready,
            "s1_hold_open_ready_v790": open_ready,
            "s1_hold_freshness_v732": {"price_age": price_age, "micro_age": micro_age, "orderflow_age": order_age, "source_age": source_age, "stale_reasons": _v510_uniq(stale_reasons, 8)},
            "s1_hold_freshness_v738": {"price_age": price_age, "micro_age": micro_age, "orderflow_age": order_age, "source_age": source_age, "stale_reasons": _v510_uniq(stale_reasons, 8)},
            "s1_hold_freshness_v790": {"price_age": price_age, "micro_age": micro_age, "orderflow_age": order_age, "source_age": source_age, "stale_reasons": _v510_uniq(stale_reasons, 8)},
            "trigger_gate_v732": trigger,
            "trigger_gate_v738": trigger,
            "trigger_gate_v790": trigger,
            "canonical_entry_decision": hold_decision_v738,
            "common_entry_decision": hold_decision_v738,
            "swing_entry_gate_v977": r.get("swing_entry_gate_v977") if isinstance(r.get("swing_entry_gate_v977"), dict) else {},
            "swing_gate_decision_key_v977": swing_decision_key or None,
            "strategy_mode": "ALT_SWING_V977",
            "strategy_mode_v977": "ALT_SWING_V977",
            "final_trade_state": "S1_PASS",
            "final_trade_allowed": True,
            "final_trade_label": "S1 hold canonical resealed current-row-only",
        })
        r.update({
            "schema": "paper_s1_hold_row_v979_swing_contract",
            "swing_entry_gate_v977": r.get("swing_entry_gate_v977") if isinstance(r.get("swing_entry_gate_v977"), dict) else {},
            "swing_gate_decision_key_v977": swing_decision_key or None,
            "strategy_mode": "ALT_SWING_V977",
            "strategy_mode_v977": "ALT_SWING_V977",
            "s1_hold_v732": True,
            "s1_hold_v738": True,
            "s1_hold_v790": True,
            "hold_key": key,
            "hold_created_at": hold_created_ts,
            "s1_hold_created_at_v1153": s1_first_ts_v1153,
            "candidate_path_timestamps_v1153": path_ts_v1153,
            "hold_expires_at": nowv + ttl,
            "created_at": _v510_num(r.get("created_at"), default=origin_ts) or origin_ts,
            "candidate_created_at": _v510_num(r.get("candidate_created_at"), default=origin_ts) or origin_ts,
            "source_created_at": _v510_num(r.get("source_created_at"), default=origin_ts) or origin_ts,
            "detected_ts": _v510_num(r.get("detected_ts"), default=origin_ts) or origin_ts,
            "event_ts": _v510_num(r.get("event_ts"), default=origin_ts) or origin_ts,
            "updated_ts": nowv,
            "hold_updated_ts_v929": nowv,
            "expires_at": nowv + ttl,
            "s1_hold_status_v732": status,
            "s1_hold_status_v738": status,
            "s1_hold_status_v790": status,
            "s1_hold_open_ready_v732": open_ready,
            "s1_hold_open_ready_v738": open_ready,
            "s1_hold_open_ready_v790": open_ready,
            "freshness_status": "fresh" if not is_stale else "stale",
            "stale_reasons": _v510_uniq(stale_reasons, 8),
            "price_age_sec": price_age,
            "micro_age_sec": micro_age,
            "orderflow_age_sec": order_age,
            "source_age": source_age,
            "trigger_price": trigger.get("trigger_price"),
            "trigger_reached": trigger.get("trigger_reached"),
            "trigger_gap_pct": trigger.get("trigger_gap_pct"),
            "trigger_gate_v732": trigger,
            "trigger_gate_v738": trigger,
            "trigger_gate_v790": trigger,
            "canonical_entry_decision": hold_decision_v738,
            "common_entry_decision": hold_decision_v738,
            "entry_context": ctx,
            "final_entry_action": "paper_open_candidate",
            "final_entry_label": "S1 hold canonical resealed current-row-only",
            "final_trade_state": "S1_PASS",
            "final_trade_label": "S1 hold canonical resealed current-row-only",
            "final_trade_allowed": True,
            "s1_hold_canonical_resealed_v738": True,
            "s1_hold_canonical_resealed_v790": True,
            "paper_bot_open": True,
            "open_eligible": True,
            "trade_ready": True,
            "paper_source_v732": "s1_hold_cache_only",
            "paper_source_v790": "current_s1_row_only",
            "paper_source_v979": "swing_gate_current_s1_only",
            "candidate_grade": "S1",
            "s_stage": "S1",
            "stage": "S1",
            "grade": "S1",
            "s_stage_reasons": _v510_uniq(["S1 hold bridge current row only"] + list(r.get("s_stage_reasons") or []), 10),
        })
        compact_r = _v932_compact_s1_hold_row(r)
        rows_out.append(compact_r)
        if not is_stale:
            fresh_count += 1

    full_row_bytes_before_v928 = sum(_v861_json_bytes(x) if '_v861_json_bytes' in globals() else len(json.dumps(x, ensure_ascii=False, default=str).encode('utf-8')) for x in current_s1_by_ticker.values())
    compact_row_bytes_after_v928 = sum(_v861_json_bytes(x) if '_v861_json_bytes' in globals() else len(json.dumps(x, ensure_ascii=False, default=str).encode('utf-8')) for x in rows_out)
    rows_out = sorted(rows_out, key=lambda x: _v510_num(x.get("updated_ts"), x.get("hold_created_at"), default=0.0), reverse=True)[:80]
    status_counter = Counter(str(x.get("s1_hold_status_v732") or "-") for x in rows_out)
    pruned_old_count = max(0, old_count - len(rows_out))
    source_pipeline_cycle_ids = sorted({str(x.get('candidate_pipeline_cycle_id_v1150') or '').strip() for x in (rows or []) if isinstance(x,dict) and str(x.get('candidate_pipeline_cycle_id_v1150') or '').strip()})
    hold_pipeline_cycle_ids = sorted({str(x.get('candidate_pipeline_cycle_id_v1150') or '').strip() for x in rows_out if str(x.get('candidate_pipeline_cycle_id_v1150') or '').strip()})
    pipeline_cycle_ids = hold_pipeline_cycle_ids or source_pipeline_cycle_ids
    pipeline_cycle_id = pipeline_cycle_ids[0] if len(pipeline_cycle_ids) == 1 else ''
    obj = {
        "schema": "paper_s1_hold_cache_v979_swing_contract",
        "version": VERSION,
        "candidate_pipeline_cycle_id_v1150": pipeline_cycle_id,
        "candidate_pipeline_cycle_consistent_v1150": len(pipeline_cycle_ids) <= 1,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "hold_ttl_sec": ttl,
        "count": len(rows_out),
        "source_s1_count": source_s1_count,
        "deduped_ticker_count": len(current_s1_by_ticker),
        "duplicate_current_pruned_count": duplicate_current,
        "observation_only_skipped_v988": observation_only_skipped_v988,
        "old_hold_pruned_count_v790": pruned_old_count,
        "fresh_count": fresh_count,
        "stale_count": stale_count,
        "trigger_wait_count": trigger_wait,
        "open_ready_count": open_ready_count,
        "expired_pruned_count": pruned_old_count,
        "status_counts": dict(status_counter),
        "rows": rows_out,
        "compact_rows_v928": len(rows_out),
        "full_row_bytes_before_v928": int(full_row_bytes_before_v928),
        "compact_row_bytes_after_v928": int(compact_row_bytes_after_v928),
        "jsonl_mirror_retired_v928": True,
        "swing_gate_rows_preserved_v979": sum(1 for x in rows_out if isinstance(x.get("swing_entry_gate_v977"), dict) and x.get("swing_entry_gate_v977")),
        "swing_decision_key_rows_v979": sum(1 for x in rows_out if str(x.get("swing_gate_decision_key_v977") or "").strip()),
        "obsolete_minimal_gate_rows_written_v979": sum(1 for x in rows_out if "minimal_entry_gate_v925" in x or "minimal_gate_decision_key_v925" in x),
        "policy": "v979: current ALT_SWING S1 rows preserve only swing gate/mode/decision contract into paper_s1_hold_cache.json; old minimal gate is not written.",
    }
    save_json(hold_path, obj)
    obj["legacy_jsonl_archive_v928"] = _v928_archive_legacy_hold_jsonl()
    return obj

def _v929_prepare_publish_rows(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float,
                               info_quality: Optional[Dict[str, Any]] = None) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    """Single strategy publish spine.

    It preserves the old v908 overlay, v819 structure aliases, v813 recheck requests,
    and v671 diagnostics, but executes the structure-board calculation only once.
    """
    iq: Dict[str, Any] = dict(info_quality or {})
    source_rows = rows if isinstance(rows, list) else []
    try:
        source_rows, overlay = _v908_overlay_rows_for_publish(source_rows)
        if isinstance(overlay, dict):
            iq.update({k: v for k, v in overlay.items() if k.endswith('_v908') or k.startswith('candidate_input_') or k.startswith('worker_cache_') or k == 'policy_v908'})
    except Exception as exc:
        append_error(ERROR, 'v929_candidate_overlay', exc)

    sealed: List[Dict[str, Any]] = []
    counts: Counter = Counter(); setups: Counter = Counter(); roles: Counter = Counter(); missing = 0
    samples: List[Dict[str, Any]] = []
    for row in source_rows:
        if not isinstance(row, dict):
            continue
        try:
            r = _v819_force_structure_board_aliases(row, nowv)
        except Exception as exc:
            append_error(ERROR, 'v929_single_structure_seal', exc)
            r = dict(row)
        board = r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else (r.get('structure_board') if isinstance(r.get('structure_board'), dict) else {})
        if not board:
            missing += 1
        stage = _v510_stage(r)
        counts[stage] += 1
        setups[str(board.get('setup_type') or '-')] += 1
        roles[str(board.get('role') or '-')] += 1
        if len(samples) < 12 and stage in ('S1','S2'):
            samples.append({'ticker': ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')), 'stage': stage,
                            'setup': board.get('setup_type'), 'role': board.get('role'),
                            'reason': ' / '.join(str(x) for x in (board.get('stage_reasons') or [])[:3])})
        sealed.append(r)

    reqs = priority_requests if isinstance(priority_requests, list) else []
    try:
        reqs, req_summary = _v813_structure_recheck_requests(sealed, reqs, nowv)
    except Exception as exc:
        append_error(ERROR, 'v929_structure_recheck_requests', exc)
        req_summary = {'structure_recheck_s2_req_count_v813': 0}

    fast = globals().get('_V671_LAST_FAST_SUMMARY')
    if isinstance(fast, dict) and fast:
        brief = {k: fast.get(k) for k in ('schema','accepted_count','reject_reason_top','field_owner')}
        iq['fast_quality_paper_v669'] = brief
        iq['fast_quality_paper_v671'] = brief

    status = {
        'schema':'structure_board_publish_status_v929_single_spine','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':nowv,'updated_text':now_text(nowv),'rows':len(sealed),
        'missing_structure_board_rows':missing,'stage_counts':dict(counts),
        'setup_type_top':dict(setups.most_common(10)),'role_top':dict(roles.most_common(10)),
        'samples':samples,'source':'strategy_worker_v929_single_publish_spine',
        'structure_board_calculation_per_row':1,
        'policy':'v929: v908 overlay -> one structure seal -> v813 recheck requests -> canonical publish; writer never recalculates structure board',
    }
    try:
        save_json(STRUCTURE_BOARD_STATUS, status)
    except Exception as exc:
        append_error(ERROR, 'v929_structure_status_save', exc)
    iq.update({
        'structure_board_publish_owner_v929': True,
        'structure_board_rows_v929': len(sealed),
        'structure_board_missing_v929': missing,
        'structure_board_calculation_per_row_v929': 1,
        'structure_recheck_s2_req_count_v813': int(req_summary.get('structure_recheck_s2_req_count_v813') or 0),
        'structure_board_summary': status,
        'structure_board_summary_v812': status,
        'structure_board_summary_v929': status,
        'old_publish_wrappers_removed_v929': ['v669_early','v813','v818','v819','v908_tail'],
    })
    return sealed, reqs, iq

def _v1194_summary_sample_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """Tiny human-readable sample; never used for selection or Paper execution."""
    src = row if isinstance(row, dict) else {}
    board = src.get('structure_board_v812') if isinstance(src.get('structure_board_v812'), dict) else {}
    reasons = src.get('s_stage_reasons') if isinstance(src.get('s_stage_reasons'), list) else board.get('stage_reasons') if isinstance(board.get('stage_reasons'), list) else []
    return {
        'ticker': ticker_norm(src.get('ticker') or src.get('market') or src.get('symbol')),
        'stage': _v510_stage(src),
        'lane': str(src.get('canonical_lane') or ''),
        'setup': board.get('setup_type'),
        'role': board.get('role'),
        'reason': ' / '.join(str(x) for x in reasons[:3]),
    }

def _v1194_summary_top_candidate_row(row: Dict[str, Any]) -> Dict[str, Any]:
    """Bounded summary pointer to the canonical candidate file, not a duplicated raw candidate."""
    src = row if isinstance(row, dict) else {}
    gate = src.get('swing_entry_gate_v977') if isinstance(src.get('swing_entry_gate_v977'), dict) else {}
    board = src.get('structure_board_v812') if isinstance(src.get('structure_board_v812'), dict) else {}
    return {
        'ticker': ticker_norm(src.get('ticker') or src.get('market') or src.get('symbol')),
        'stage': _v510_stage(src),
        'canonical_lane': src.get('canonical_lane'),
        'strategy_key': src.get('strategy_key') or src.get('paper_strategy_key'),
        'decision_key': src.get('swing_gate_decision_key_v977') or gate.get('decision_key'),
        'current_price': src.get('current_price') or src.get('price'),
        'trigger_price': src.get('swing_trigger_price_v977') or gate.get('trigger_price') or src.get('trigger_price'),
        'invalid_price': src.get('swing_invalid_price_v977') or gate.get('invalid_price') or src.get('invalid_price'),
        'target_price': src.get('swing_target_price_v977') or gate.get('target_price') or src.get('target_price'),
        'risk_reward_ratio': src.get('risk_reward_ratio') or gate.get('risk_reward'),
        'target_room_pct': src.get('target_room_pct') or gate.get('target_room_pct'),
        'setup': board.get('setup_type'),
        'role': board.get('role'),
        'canonical_candidate_source': str(PAPER_LATEST),
    }

def _v510_publish(rows: List[Dict[str, Any]], rejects: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], evaluated: int, cycle_ts: float, info_quality: Optional[Dict[str, int]] = None, candle_map_v1032: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    info_quality = info_quality if isinstance(info_quality, dict) else {}
    _v1027_profile = info_quality.get('strategy_cpu_profile_v1027') if isinstance(info_quality.get('strategy_cpu_profile_v1027'), dict) else _v1027_new_cpu_profile(cycle_ts)
    info_quality['strategy_cpu_profile_v1027'] = _v1027_profile
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'publish_prepare_canonical_rows')
    rows, priority_requests, info_quality = _v929_prepare_publish_rows(rows, priority_requests, nowv, info_quality)
    _v1027_phase_stop(_v1027_profile, 'publish_prepare_canonical_rows', _v1027_tok, calls=1, rows=len(rows))
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'publish_recheck_lanes')
    rows, v655_recheck_lane_summary = _v655_apply_strategy_recheck_lanes(rows, nowv)
    _v1027_phase_stop(_v1027_profile, 'publish_recheck_lanes', _v1027_tok, calls=1, rows=len(rows))
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'publish_entry_plan_core_v1180')
    rows = _v1180_apply_execution_entry_plan_core(rows, nowv)
    _v1027_phase_stop(_v1027_profile, 'publish_entry_plan_core_v1180', _v1027_tok, calls=1, rows=len(rows))
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'publish_structure_freshness')
    rows = _v583_attach_structure_freshness(rows, nowv)
    _v1027_phase_stop(_v1027_profile, 'publish_structure_freshness', _v1027_tok, calls=1, rows=len(rows))
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'publish_s2_lifecycle')
    rows, s2_promotion_trace = _v563_attach_s2_promotion_lifecycle(rows, nowv)
    _v1027_phase_stop(_v1027_profile, 'publish_s2_lifecycle', _v1027_tok, calls=1, rows=len(rows))
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'publish_priority_requests')
    priority_requests, v574_fresh_urgent_summary = _v574_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    _v1027_phase_stop(_v1027_profile, 'publish_priority_requests', _v1027_tok, calls=1, rows=len(rows))
    # v1049: defer candle urgent publication until the final swing gate has
    # attached structure-integrity classification to each canonical row.
    v608_candle_urgent_summary = {'schema':'deferred_until_after_swing_gate_v1049','request_count':0}
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'publish_promotion_reseal')
    rows, v732_promotion_spine_summary = _v732_reseal_common_uprising_promotions(rows, nowv)
    _v1027_phase_stop(_v1027_profile, 'publish_promotion_reseal', _v1027_tok, calls=1, rows=len(rows))
    v810_quality_router_summary = {}
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'quality_priority_requests')
    try:
        try:
            priority_requests, v810_quality_router_summary = _v810_attach_quality_priority_requests(rows, priority_requests, nowv)
        except Exception as exc:
            try: append_error(ERROR, 'v810_quality_priority_requests', exc)
            except Exception: pass
    finally:
        _v1027_phase_stop(_v1027_profile, 'quality_priority_requests', _v1027_tok, calls=1, rows=len(rows))
    # v925: one final coherent actual-structure entry-decision owner. Legacy quality/score paths above remain
    # audit inputs only; they cannot decide S1/paper OPEN after this point.
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'swing_entry_gate')
    try:
        rows, v925_minimal_gate_summary = apply_swing_entry_gate(rows, nowv)
    finally:
        _v1027_phase_stop(_v1027_profile, 'swing_entry_gate', _v1027_tok, calls=1, rows=len(rows))
    info_quality = info_quality or {}
    info_quality.update(v925_minimal_gate_summary)
    _v1027_tok_urgent_v1049 = _v1028_live_phase_enter(_v1027_profile, 'publish_candle_urgent_after_final_gate_v1049')
    try:
        if not isinstance(candle_map_v1032,dict):
            raise RuntimeError('v1147 canonical candle_map missing before urgent publish')
        v608_candle_urgent_summary = _v608_publish_candle_urgent_targets(rows, nowv, candle_map_v1032)
    finally:
        _v1027_phase_stop(_v1027_profile, 'publish_candle_urgent_after_final_gate_v1049', _v1027_tok_urgent_v1049, calls=1, rows=len(rows))
    # v943 key spine: seal exact candidate identity, then attach good-S2 occurrence,
    # then write S1 hold from the same canonical rows. Key string formulas are unchanged.
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'seal_exact_keys')
    try:
        rows, key_status = seal_canonical_candidate_keys(rows)
    finally:
        _v1027_phase_stop(_v1027_profile, 'seal_exact_keys', _v1027_tok, calls=1, rows=len(rows))
    info_quality.update(key_status)
    # v1179: execution handoff must not wait for observation/review work.
    # smart-structure, structure-lab, hot-watch and good-S2 remain observation-only
    # and run only after the immutable Paper generation is committed.
    _v1150_pipeline_cycle_id = f"strategy-{os.getpid()}-{int(cycle_ts * 1000)}"
    for _v1150_row in rows:
        if isinstance(_v1150_row, dict):
            _v1150_row['candidate_pipeline_cycle_id_v1150'] = _v1150_pipeline_cycle_id
            _v1150_row['candidate_pipeline_cycle_started_ts_v1152'] = cycle_ts
    for _v1150_req in priority_requests:
        if isinstance(_v1150_req, dict):
            _v1150_req['candidate_pipeline_cycle_id_v1150'] = _v1150_pipeline_cycle_id
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 's1_hold_commit_v1148')
    try:
        v732_s1_hold_summary = write_s1_hold_cache(rows, nowv)
    finally:
        _v1027_phase_stop(_v1027_profile, 's1_hold_commit_v1148', _v1027_tok, calls=1, rows=len(rows))
    _v1148_s1_hold_commit_ts = now_ts()
    _v1027_profile['s1_hold_commit_completed_ts_v1148'] = _v1148_s1_hold_commit_ts
    _v1027_profile['s1_hold_commit_elapsed_sec_v1148'] = round(max(0.0, _v1148_s1_hold_commit_ts - cycle_ts), 6)
    # v1149 runtime fix: `rows` is the actual hold-row list, not a numeric count.
    # v1148 attempted int(summary['rows']) and aborted every non-empty S1 cycle
    # immediately after the S1 cache write, before candidate/priority commit.
    _v1149_hold_count_value = _v1149_s1_hold_count(v732_s1_hold_summary)
    _v1027_profile['s1_hold_commit_rows_v1148'] = _v1149_hold_count_value
    _v1027_profile['s1_hold_commit_count_fix_v1149'] = True
    _v1027_profile['post_s1_candidate_commit_path_restored_v1149'] = True
    _v1150_hold_cycle = str(v732_s1_hold_summary.get('candidate_pipeline_cycle_id_v1150') or '') if isinstance(v732_s1_hold_summary, dict) else ''
    if _v1150_hold_cycle != _v1150_pipeline_cycle_id:
        _v1150_write_pipeline_status(
            _v1150_pipeline_cycle_id, 'FAIL', last_completed_step='S1_HOLD_WRITE', failed_step='S1_HOLD_CYCLE_ID_MISMATCH',
            s1_hold_cycle_id=_v1150_hold_cycle, s1_hold_count=_v1149_hold_count_value,
        )
        raise RuntimeError(f'v1150 S1 hold cycle mismatch expected={_v1150_pipeline_cycle_id} actual={_v1150_hold_cycle}')
    _v1027_profile['s1_handoff_measurement_policy_v1148'] = 'v1179 execution handoff precedes observation-only phases'

    # v1166: the key-spine status is observability-only.  It must not delay the
    # required S1 -> candidate snapshot -> priority -> completed-generation path.
    # The exact same status writer runs immediately after the handoff is sealed.
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'row_aggregation_and_promotion_stats')
    counts = _v510_counts(rows)
    lane_counts: Dict[str, int] = {}
    for r in rows:
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    _v1027_phase_stop(_v1027_profile, 'row_aggregation_and_promotion_stats', _v1027_tok, calls=4, rows=len(rows))
    _v1027_tok = _v1027_phase_start()
    _v1150_writer_status = _v1021_publish_candidate_snapshot(PAPER_LATEST, rows, _v1027_profile)
    _v1027_phase_stop(_v1027_profile, 'candidate_compact_atomic_commit', _v1027_tok, calls=1, rows=len(rows))
    _v1150_candidate_commit_id = str(_V1026_LAST_COMMIT_ID or '')
    _v1150_writer_status = _v1150_writer_status if isinstance(_v1150_writer_status, dict) else {}
    _v1150_writer_scope = _v1150_writer_status.get('candidate_snapshot_scope') if isinstance(_v1150_writer_status.get('candidate_snapshot_scope'), dict) else {}
    _v1150_writer_cycle = str(_v1150_writer_scope.get('pipeline_cycle_id_v1150') or '')
    _v1150_writer_rows = _v1165_count_value(_v1150_writer_scope.get('rows_written'), default=-1, field='candidate_writer.rows_written')
    if _v1150_writer_cycle != _v1150_pipeline_cycle_id or _v1150_writer_rows != len(rows):
        _v1150_write_pipeline_status(
            _v1150_pipeline_cycle_id, 'FAIL', last_completed_step='CANDIDATE_SNAPSHOT_WRITE', failed_step='CANDIDATE_SCOPE_MISMATCH',
            candidate_scope_cycle_id=_v1150_writer_cycle, candidate_scope_rows=_v1150_writer_rows, expected_rows=len(rows),
        )
        raise RuntimeError(f'v1150 candidate scope mismatch cycle={_v1150_writer_cycle} rows={_v1150_writer_rows}')
    if not _v1150_candidate_commit_id:
        _v1150_write_pipeline_status(
            _v1150_pipeline_cycle_id, 'FAIL', last_completed_step='CANDIDATE_SNAPSHOT_WRITE', failed_step='CANDIDATE_COMMIT_ID_MISSING',
            s1_hold_count=_v1149_hold_count_value, candidate_rows=len(rows),
        )
        raise RuntimeError('v1150 candidate commit id missing after atomic writer')
    _v1031_candidate_commit_ts = now_ts()
    _v1031_candidate_commit_sec = max(0.0, _v1031_candidate_commit_ts - cycle_ts)
    _v1027_profile['candidate_commit_completed_ts_v1031'] = _v1031_candidate_commit_ts
    _v1027_profile['candidate_commit_elapsed_sec_v1031'] = round(_v1031_candidate_commit_sec, 6)
    _v1027_profile['cycle_timing_scope_v1031'] = 'run_once_start_to_return'
    _v1027_tok = _v1028_live_phase_enter(_v1027_profile, 'post_commit_handoff_and_priority')
    # v1022: seal the canonical status immediately after the candidate file commit.
    # Heavy display/review cache work below may take much longer, but liveness and
    # the last completed candidate metrics must already be visible.
    write_status(
        "running", phase="candidate_committed_v1022",
        phase_note="candidate snapshot committed; post-publish display work may continue",
        strategy_worker_version=VERSION, main_version=MAIN_VERSION, deploy_version=MAIN_DEPLOY_VERSION,
        evaluated=evaluated, row_count=evaluated, s_count=len(rows), paper_latest_count=len(rows),
        s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0),
        target_count=len(priority_requests), priority_request_count=len(priority_requests),
        current_cycle_candidate_commit_sec_v1031=round(_v1031_candidate_commit_sec,3),
        current_cycle_post_commit_in_progress_v1031=True,
        last_sec_scope_v1031="previous completed full cycle while current post-commit work continues",
        status_route_schema="strategy_status_v1031_candidate_commit_progress",
        candidate_commit_status_v1022=True,
    )
    # v782: publish the canonical candidate spine immediately after latest rows are sealed.
    # Heavy display caches can finish later; paper/main should not wait 60~80s to see S2 recheck rows.
    try:
        _v782_now = now_ts()
        _v782_price_ready = sum(1 for _r in rows if _v510_num(_r.get('current_price'), _r.get('entry_price'), _r.get('price'), default=0.0) > 0)
        save_runtime_json(HANDOFF, {
            'schema': 'paper_handoff_status_v782_fast_after_latest',
            'version': VERSION,
            'updated_ts': _v782_now,
            'updated_text': now_text(_v782_now),
            'latest_count': len(rows),
            'stage_counts': counts,
            'lane_counts': lane_counts,
            'price_ready_count': _v782_price_ready,
            'source': 'paper_candidates_latest',
            'source_policy': 'v782: strategy seals candidate rows first; display summary is throttled separately. No condition/exit change.',
        }, 'paper_handoff_fast_v1124')
        write_status(
            'running',
            phase='latest_published_v782',
            phase_note='candidate rows sealed before display-cache build',
            strategy_worker_version=VERSION,
            main_version=MAIN_VERSION,
            deploy_version=MAIN_DEPLOY_VERSION,
            evaluated=evaluated,
            row_count=evaluated,
            s_count=len(rows),
            paper_latest_count=len(rows),
            s1_count=counts.get('S1',0),
            s2_count=counts.get('S2',0),
            s3_count=counts.get('S3',0),
            target_count=len(priority_requests),
            priority_request_count=len(priority_requests),
            current_cycle_candidate_commit_sec_v1031=round(_v1031_candidate_commit_sec,3),
            current_cycle_post_commit_in_progress_v1031=True,
            last_sec_scope_v1031='previous completed full cycle while current post-commit work continues',
            status_route_schema='strategy_status_v1051_compact_intermediate_progress',
            intermediate_full_status_payload_removed_v1051=True,
            final_full_status_payload_owner_v1051='cycle_done_status_only'
        )
    except Exception as exc:
        append_error(ERROR, 'v782_fast_publish', exc)
    # Runtime OPEN does not append to archive. Archive/trade log stays paper-owned/history-only.
    priority_requests = sorted(priority_requests, key=lambda x: _v510_num(x.get("priority"), default=0.0), reverse=True)
    targets = list(dict.fromkeys([ticker_norm(r.get("ticker")) for r in priority_requests if ticker_norm(r.get("ticker"))]))
    pr_obj = {"schema": "strategy_priority_requests_v512", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "request_count": len(priority_requests), "targets": targets, "requests": priority_requests, "buckets": {}, "candidate_pipeline_cycle_id_v1150": _v1150_pipeline_cycle_id, "candidate_commit_id_v1150": _v1150_candidate_commit_id}
    for pr in priority_requests:
        b = str(pr.get("bucket") or "-"); pr_obj["buckets"][b] = pr_obj["buckets"].get(b, 0) + 1
    save_runtime_json(PRIORITY_REQ, pr_obj, 'strategy_priority_requests_v1124')
    _v1166_priority_commit_ts = now_ts()
    _v1158_handoff_completed_ts = now_ts()
    _v1158_committed_handoff = _v1158_commit_paper_handoff(
        _v1150_pipeline_cycle_id, _v1150_candidate_commit_id, v732_s1_hold_summary,
        len(rows), len(priority_requests), len(targets), _v1158_handoff_completed_ts,
        s1_hold_completed_ts=_v1148_s1_hold_commit_ts,
        candidate_snapshot_completed_ts=_v1031_candidate_commit_ts,
        priority_requests_completed_ts=_v1166_priority_commit_ts,
    )
    _v1150_pipeline_final = _v1150_write_pipeline_status(
        _v1150_pipeline_cycle_id, 'NORMAL', last_completed_step='COMMITTED_PAPER_HANDOFF', failed_step=None,
        candidate_commit_id=_v1150_candidate_commit_id, candidate_rows=len(rows), s1_hold_count=_v1149_hold_count_value,
        priority_request_count=len(priority_requests), target_count=len(targets),
        committed_handoff_id_v1158=_v1158_committed_handoff.get('handoff_id_v1158'),
        committed_handoff_digest_v1158=_v1158_committed_handoff.get('digest_v1158'),
        committed_handoff_file_v1158=_v1158_committed_handoff.get('handoff_file_v1158'),
        committed_handoff_completed_ts_v1158=_v1158_handoff_completed_ts,
        s1_hold_file=str(BASE_DIR/'paper_s1_hold_cache.json'),
        committed_candidate_file_v1317=_v1150_writer_status.get('committed_candidate_file_v1317'),
        committed_candidate_file_sha256_v1317=_v1150_writer_status.get('committed_candidate_file_sha256_v1317'),
        committed_candidate_file_rows_v1317=_v1150_writer_status.get('committed_candidate_file_rows_v1317'),
        candidate_file=str(PAPER_LATEST), priority_file=str(PRIORITY_REQ),
        s1_hold_file_mtime=(BASE_DIR/'paper_s1_hold_cache.json').stat().st_mtime if (BASE_DIR/'paper_s1_hold_cache.json').exists() else None,
        candidate_file_mtime=PAPER_LATEST.stat().st_mtime if PAPER_LATEST.exists() else None,
        priority_file_mtime=PRIORITY_REQ.stat().st_mtime if PRIORITY_REQ.exists() else None,
        row_count_match_v1150=bool(_v1150_writer_rows == len(rows)),
        priority_requests_completed_ts_v1152=_v1166_priority_commit_ts,
        completed_generation_committed_at_v1166=_v1158_handoff_completed_ts,
        completed_ts_v1152=now_ts(),
        cycle_id_consistent_v1150=True, all_required_commits_v1150=True,
    )
    info_quality['candidate_pipeline_commit_v1150'] = _v1150_pipeline_final
    info_quality['completed_handoff_cleanup_v1158'] = _v1158_cleanup_handoff_generations(keep=4)
    _v1027_phase_stop(_v1027_profile, 'post_commit_handoff_and_priority', _v1027_tok, calls=4, rows=len(priority_requests))
    _v1179_execution_handoff_completed_ts = now_ts()
    _v1179_execution_handoff_elapsed_sec = max(0.0, _v1179_execution_handoff_completed_ts - cycle_ts)
    _v1027_profile['execution_handoff_completed_ts_v1179'] = _v1179_execution_handoff_completed_ts
    _v1027_profile['execution_handoff_elapsed_sec_v1179'] = round(_v1179_execution_handoff_elapsed_sec, 6)
    info_quality['execution_handoff_completed_ts_v1179'] = _v1179_execution_handoff_completed_ts
    info_quality['execution_handoff_elapsed_sec_v1179'] = round(_v1179_execution_handoff_elapsed_sec, 6)
    info_quality['execution_handoff_before_observation_v1179'] = True
    # v1181: immutable execution generation is complete.  Strategy stops here.
    # Observation / structure-lab / hot-watch / good-S2 review are Review-owned.
    _v1181_review_request_ts = now_ts()
    _v1181_review_request = {
        'schema': 'strategy_review_observation_request_v1181',
        'version': VERSION,
        'build': BUILD_LABEL,
        'strategy_mode': 'ALT_SWING',
        'auto_buy': False,
        'created_ts': _v1181_review_request_ts,
        'created_text': now_text(_v1181_review_request_ts),
        'pipeline_cycle_id': _v1150_pipeline_cycle_id,
        'candidate_commit_id': _v1150_candidate_commit_id,
        'committed_handoff_id': _v1158_committed_handoff.get('handoff_id_v1158'),
        'committed_handoff_digest': _v1158_committed_handoff.get('digest_v1158'),
        'committed_handoff_completed_ts': _v1158_handoff_completed_ts,
        'execution_handoff_elapsed_sec': round(_v1179_execution_handoff_elapsed_sec, 6),
        'committed_candidate_file_v1317': _v1150_writer_status.get('committed_candidate_file_v1317'),
        'committed_candidate_file_sha256_v1317': _v1150_writer_status.get('committed_candidate_file_sha256_v1317'),
        'committed_candidate_file_rows_v1317': _v1150_writer_status.get('committed_candidate_file_rows_v1317'),
        'candidate_generation_owner_v1317': 'strategy_worker immutable full candidate file; async Review/Paper must prefer this over rolling latest',
        'candidate_file': str(PAPER_LATEST),
        'priority_file': str(PRIORITY_REQ),
        's1_hold_file': str(BASE_DIR / 'paper_s1_hold_cache.json'),
        'candidate_rows': len(rows),
        's1_count': counts.get('S1', 0),
        's2_count': counts.get('S2', 0),
        's3_count': counts.get('S3', 0),
        'priority_request_count': len(priority_requests),
        'target_count': len(targets),
        'owner': 'review_worker_v1.012',
        'strategy_post_handoff_observation_retired': True,
        'live_ledger_write': False,
    }
    save_runtime_json(
        BASE_DIR / 'review_observation_request_v1181.json',
        _v1181_review_request,
        'strategy_review_request_v1181',
    )

    # One compact final Strategy summary.  No display-cache rebuild and no
    # post-handoff candidate mutation are allowed after the committed handoff.
    _v1181_done_ts = now_ts()
    _v1181_full_sec = max(0.0, _v1181_done_ts - cycle_ts)
    _v1181_post_handoff_sec = max(0.0, _v1181_full_sec - _v1179_execution_handoff_elapsed_sec)
    reason_top = _v510_reason_top(rows)
    _v1181_sample = [_v1194_summary_sample_row(x) for x in rows[:8]]
    _v1181_top_candidates = [_v1194_summary_top_candidate_row(x) for x in rows[:8]]
    summary = {
        'schema': 'strategy_canonical_summary_v1181_handoff_only',
        'version': VERSION,
        'build': BUILD_LABEL,
        'main_version': MAIN_VERSION,
        'updated_ts': _v1181_done_ts,
        'updated_text': now_text(_v1181_done_ts),
        'strategy_mode': 'ALT_SWING',
        'auto_buy': False,
        'pipeline_cycle_id': _v1150_pipeline_cycle_id,
        'candidate_commit_id': _v1150_candidate_commit_id,
        'evaluated': evaluated,
        'paper_latest_count': len(rows),
        's_count': len(rows),
        's_stage_counts': counts,
        'stage_counts': counts,
        's1_count': counts.get('S1', 0),
        's2_count': counts.get('S2', 0),
        's3_count': counts.get('S3', 0),
        'lane_counts': lane_counts,
        'reason_top': reason_top,
        'target_count': len(targets),
        'priority_request_count': len(priority_requests),
        'sample': _v1181_sample,
        'top_candidates': _v1181_top_candidates,
        'summary_candidate_payload_policy_v1194': 'small display sample + bounded canonical pointer rows; full candidates stay only in paper_candidates_latest.jsonl',
        'execution_handoff_sec_v1181': round(_v1179_execution_handoff_elapsed_sec, 6),
        'full_cycle_sec_v1181': round(_v1181_full_sec, 6),
        'post_handoff_sec_v1181': round(_v1181_post_handoff_sec, 6),
        'post_handoff_observation_owner_v1181': 'review_worker',
        'post_handoff_candidate_mutation_v1181': False,
        'review_request_file_v1181': str(BASE_DIR / 'review_observation_request_v1181.json'),
        'policy': 'v1181: Strategy seals one immutable execution generation and returns; Review owns all observation.',
    }
    summary.update(info_quality)
    summary['post_handoff_observation_sec_v1179'] = 0.0
    summary['observation_owner_transition_v1179'] = 'DONE_REVIEW_OWNER_V1181'
    save_runtime_json(SUMMARY, summary, 'strategy_summary_v1181_handoff_only')
    _v1015_bounded_snapshot_write(
        CANONICAL_STRATEGY_SUMMARY,
        {
            'schema': 'strategy_canonical_summary_v1181_handoff_only',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_ts': _v1181_done_ts,
            'pipeline_cycle_id': _v1150_pipeline_cycle_id,
            'candidate_commit_id': _v1150_candidate_commit_id,
            's_stage_counts': counts,
            'paper_latest_count': len(rows),
            'priority_request_count': len(priority_requests),
            'execution_handoff_sec_v1181': round(_v1179_execution_handoff_elapsed_sec, 6),
            'full_cycle_sec_v1181': round(_v1181_full_sec, 6),
            'review_owner_v1181': True,
            'auto_buy': False,
        },
        heartbeat_sec=0.0,
    )
    save_runtime_json(
        HANDOFF,
        {
            'schema': 'paper_handoff_status_v1181',
            'version': VERSION,
            'updated_ts': _v1181_done_ts,
            'latest_count': len(rows),
            'stage_counts': counts,
            'lane_counts': lane_counts,
            'priority_request_count': len(priority_requests),
            'target_count': len(targets),
            'pipeline_cycle_id': _v1150_pipeline_cycle_id,
            'candidate_commit_id': _v1150_candidate_commit_id,
            'committed_handoff_id': _v1158_committed_handoff.get('handoff_id_v1158'),
            'source': 'paper_candidates_latest',
            'strategy_post_handoff_observation_retired': True,
            'auto_buy': False,
        },
        'paper_handoff_final_v1181',
    )
    write_status(
        'running',
        phase='cycle_done_v1181',
        phase_note='immutable candidate generation committed; observation delegated to Review',
        phase_started_ts=cycle_ts,
        strategy_worker_version=VERSION,
        main_version=MAIN_VERSION,
        deploy_version=MAIN_DEPLOY_VERSION,
        evaluated=evaluated,
        row_count=evaluated,
        s_count=len(rows),
        paper_latest_count=len(rows),
        s1_count=counts.get('S1', 0),
        s2_count=counts.get('S2', 0),
        s3_count=counts.get('S3', 0),
        target_count=len(targets),
        priority_request_count=len(priority_requests),
        last_sec=round(_v1181_full_sec, 3),
        candidate_commit_sec_v1031=round(_v1031_candidate_commit_sec, 3),
        execution_handoff_sec_v1181=round(_v1179_execution_handoff_elapsed_sec, 6),
        full_cycle_sec_v1181=round(_v1181_full_sec, 6),
        post_handoff_sec_v1181=round(_v1181_post_handoff_sec, 6),
        post_handoff_observation_sec_v1179=0.0,
        post_handoff_observation_owner_v1181='review_worker',
        strategy_post_handoff_observation_retired_v1181=True,
        current_cycle_post_commit_in_progress_v1031=False,
        last_sec_scope_v1031='last completed immutable execution generation',
        status_route_schema='strategy_status_v1181_handoff_only',
        auto_buy=False,
        **info_quality,
    )
    return summary

def _v660_load_scanner_pool_map() -> Dict[str, Dict[str, Any]]:
    try:
        return map_rows(load_json(SCANNER_POOL, {}) or {})
    except Exception:
        return {}

def _v660_price_from_any(row: Dict[str, Any]) -> float:
    return _v510_num(
        row.get('current_price'), row.get('trade_price'), row.get('price'), row.get('close'),
        row.get('last_price'), row.get('detected_price'), default=0.0
    )

def _v660_widen_strategy_input(raw_feature_list: List[Dict[str, Any]], cycle_ts: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    fmap: Dict[str, Dict[str, Any]] = {}
    for r in raw_feature_list or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market'))
        if not t:
            continue
        rr = dict(r)
        rr.setdefault('ticker', t)
        rr.setdefault('strategy_input_source', rr.get('source') or 'feature_worker')
        rr.setdefault('feature_present_for_strategy', True)
        fmap[t] = rr

    scanner_map = _v660_load_scanner_pool_map()
    added: List[str] = []
    for t, src in scanner_map.items():
        if not t or t in fmap or not isinstance(src, dict):
            continue
        price = _v660_price_from_any(src)
        rr = dict(src)
        rr['ticker'] = t
        if price:
            rr.setdefault('current_price', price)
            rr.setdefault('price', price)
            rr.setdefault('detected_price', price)
        rr['strategy_input_source'] = 'scanner_pool_feature_missing_v660'
        rr['feature_present_for_strategy'] = False
        rr['feature_missing_for_strategy'] = True
        rr['v660_input_restore_reason'] = 'feature_worker row missing at strategy cycle; scanner pool row preserved for stale/missing diagnosis'
        stale = rr.get('stale_reasons') if isinstance(rr.get('stale_reasons'), list) else []
        rr['stale_reasons'] = _v510_uniq(list(stale) + ['feature_missing_v660'], 10)
        br = rr.get('block_reasons') if isinstance(rr.get('block_reasons'), list) else []
        rr['block_reasons'] = _v510_uniq(list(br) + ['정보오래됨: feature row missing'], 12)
        fmap[t] = rr
        added.append(t)

    out = list(fmap.values())
    scanner_count = len(scanner_map)
    feature_count = len(raw_feature_list or [])
    restored_count = len(added)
    ratio = round((len(out) / scanner_count * 100.0), 1) if scanner_count else 0.0
    summary = {
        'schema': 'strategy_input_restore_v660',
        'version': VERSION,
        'feature_input_count': feature_count,
        'scanner_pool_count': scanner_count,
        'restored_from_scanner_count': restored_count,
        'strategy_input_count': len(out),
        'strategy_input_vs_scanner_pct': ratio,
        'restored_sample': added[:20],
        'policy': '후보 판단 rows를 줄이지 않는다. feature 누락 티커는 S1 통과가 아니라 missing/stale reason 봉인용으로 strategy input에 보존한다.',
    }
    return out, summary

def _v661_row_ticker(row: Dict[str, Any]) -> str:
    try:
        return ticker_norm(row.get('ticker') or row.get('symbol') or row.get('market'))
    except Exception:
        return ''

def _v661_build_coverage_rows(feature_list: List[Dict[str, Any]], final_rows: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], nowv: float, shared_eval: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """v732: coverage/참고 row와 S3 관찰 row를 분리한다.

    원칙:
    - 급등초입 기준 미통과는 급등초입 전략의 미충족일 뿐, 공통 차단 사유가 아니다.
    - S3는 paper OPEN 대상이 아니라 관찰/놓친후보 복기 대상이다.
    - S3 관찰 기준은 고정 개수 제한이 아니라 가격반응/체결/지속/스프레드/구조 힌트 기반으로 판정한다.
    """
    existing = {_v661_row_ticker(r) for r in (final_rows or []) if isinstance(r, dict)}
    existing.discard('')
    rows: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    common_counter: Counter = Counter()
    strategy_counter: Counter = Counter()
    stale_counter: Counter = Counter()
    observe_counter: Counter = Counter()
    leak_count = 0

    for src in feature_list or []:
        if not isinstance(src, dict):
            continue
        t = _v661_row_ticker(src)
        if not t or t in existing:
            continue
        shared = shared_eval.get(t, {}) if isinstance(shared_eval, dict) else {}
        of = shared.get('of') if isinstance(shared.get('of'), dict) else (ofmap.get(t, {}) or {})
        if shared:
            react = _v510_num(shared.get('react'), default=0.0)
            buy = _v510_num(shared.get('buy'), default=0.0)
            sustain = _v510_num(shared.get('sustain'), default=0.0)
            sustain_source = shared.get('sustain_source')
            sustain_real = bool(shared.get('sustain_real'))
            spread = _v510_num(shared.get('spread'), default=999.0)
        else:
            react = _v510_price_reaction(src, of)
            buy = _v510_buy(of, src)
            sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
            spread = _v510_spread(of, src)
        price = _v510_num(src.get('current_price'), src.get('price'), src.get('trade_price'), src.get('close'), of.get('quote_price'), of.get('current_price'), default=0.0)
        chg1 = _v510_num(src.get('change_1m'), src.get('price_change_1m'), default=0.0)
        chg3 = _v510_num(src.get('change_3m'), src.get('price_change_3m'), default=0.0)
        chg5 = _v510_num(src.get('change_5m'), src.get('price_change_5m'), default=0.0)
        short20 = _v510_num(of.get('price_chg_20s'), src.get('price_chg_20s'), default=0.0)
        short30 = _v510_num(of.get('price_chg_30s'), src.get('price_chg_30s'), default=0.0)
        accel10 = _v510_num(of.get('price_accel_10s'), src.get('price_accel_10s'), default=0.0)
        spike_probe_ok = max(chg1, chg3, react, short20, short30, accel10) >= 0.30

        structures = _v510_uniq(_v510_structure_tags(src), 10)
        struct_txt = " ".join(str(x) for x in structures)

        common_reasons: List[str] = ['전체시장 참고: 아직 후보 기준 전 단계']
        strategy_specific_misses: List[str] = []
        observe_reasons: List[str] = []

        if bool(src.get('feature_missing_for_strategy')):
            common_reasons.append('정보오래됨: feature row missing')
        if react < 0.35:
            common_reasons.append(f'가격반응 {react:+.2f}%<+0.35%')
        if buy < 0.55:
            common_reasons.append(f'매수체결 {buy:.2f}<0.55')
        if sustain < 0.70:
            common_reasons.append(f'1분지속 {sustain:.2f}<0.70')
        if spread > 0.35:
            common_reasons.append(f'스프레드 {spread:.2f}%>0.35%')

        if not spike_probe_ok:
            strategy_specific_misses.append('급등초입전략: 급등 초입 기준 미통과')
        strategy_specific_misses.append('기타전략: 구조/확인신호 부족으로 관찰 유지')

        # S3 관찰 기준: OPEN이 아니라 놓친 후보 복기용이다.
        # 너무 좁게 잠기지 않도록 가격/체결/지속/스프레드/구조 힌트 중 일부만 있어도 S3 관찰로 봉인한다.
        if react >= 0.10 or chg1 >= 0.10 or chg3 >= 0.30 or short20 >= 0.20 or short30 >= 0.20:
            observe_reasons.append('가격반응 관찰가치')
        if buy >= 0.55 or sustain >= 0.55:
            observe_reasons.append('체결/지속 관찰가치')
        if spread <= 0.18 and (react >= 0.00 or buy >= 0.45 or sustain >= 0.45):
            observe_reasons.append('스프레드 양호 관찰가치')
        if any(w in struct_txt for w in ('VWAP', 'EMA', '돌파', '박스', '지지', '저항', '돈흐름', '구조')):
            observe_reasons.append('차트구조 관찰가치')

        stale: List[str] = []
        candle_age = _v510_num(src.get('official_candle_age'), src.get('candle_age_sec'), src.get('candle_age'), default=-1.0)
        micro_age = _v510_num(of.get('micro_age_sec'), of.get('trade_age_sec'), of.get('_cache_age_sec'), default=-1.0)
        order_age = _v510_num(of.get('orderflow_age_sec'), of.get('trade_age_sec'), of.get('_cache_age_sec'), default=-1.0)
        if candle_age > 120:
            stale.append(f'candle {candle_age:.0f}s'); stale_counter['candle'] += 1
        if micro_age > 20:
            stale.append(f'micro {micro_age:.0f}s'); stale_counter['micro'] += 1
        if order_age > 20:
            stale.append(f'orderflow {order_age:.0f}s'); stale_counter['orderflow'] += 1

        severe_stale = (candle_age > 300) or (micro_age > 90) or (order_age > 90)
        observe_stage = bool(observe_reasons) and spread <= 0.50 and not severe_stale

        for rr in common_reasons[:8]:
            reason_counter[str(rr)] += 1; common_counter[str(rr)] += 1
            if '급등초입전략' in str(rr) or 'spike' in str(rr).lower():
                leak_count += 1
        for rr in strategy_specific_misses[:8]:
            strategy_counter[str(rr)] += 1
        for rr in observe_reasons[:8]:
            observe_counter[str(rr)] += 1

        score = _v510_num(src.get('score'), default=0.0) + max(0.0, react) * 8.0 + max(0.0, chg3) * 3.0 + min(10.0, max(0.0, buy) * 5.0) + min(10.0, max(0.0, sustain) * 5.0)

        lane = 's3_observe' if observe_stage else 'coverage'
        stage = 'S3' if observe_stage else '비후보'
        strategy_key = 'coin_quality_s3_observe' if observe_stage else 'coin_quality_coverage'
        strategy_label = 'S3 관찰/복기 후보' if observe_stage else '코인품질 전체커버'
        row_reasons = _v510_uniq((observe_reasons if observe_stage else common_reasons), 12)
        block_reasons = _v510_uniq((observe_reasons + common_reasons) if observe_stage else common_reasons, 12)
        risk_tags = _v510_uniq((['S3 관찰/복기 전용'] if observe_stage else ['coverage 관찰']) + ([f'스프레드부담 {spread:.2f}'] if spread > 0.35 else []), 8)

        row = {
            'schema': 'strategy_coverage_light_row_v732_s3_observe',
            'version': VERSION,
            'ticker': t,
            'market': f'KRW-{t}' if t else src.get('market'),
            'symbol': f'{t}_KRW' if t else src.get('symbol'),
            'event_id': _v510_event_id(t, strategy_key, lane, nowv),
            'event_key': _v510_event_id(t, strategy_key, lane, nowv),
            'created_at': nowv,
            'candidate_created_at': nowv,
            'source_created_at': nowv,
            'detected_ts': nowv,
            'event_ts': nowv,
            'created_at_text': now_text(nowv),
            'updated_ts': nowv,
            'expires_at': nowv + 180,
            'strategy_key': strategy_key,
            'paper_strategy_key': strategy_key,
            'strategy_label': strategy_label,
            'strategy': strategy_label,
            'matched_strategy_keys': [strategy_key],
            'matched_strategy_labels': [strategy_label],
            'canonical_lane': lane,
            'gate_scope_v732': 's3_observe_or_coverage_reference',
            's_stage': stage, 'candidate_stage': stage, 'candidate_grade': stage, 'stage': stage, 'grade': stage,
            'score': round(score, 3),
            'current_price': price, 'entry_price': price, 'detected_price': price, 'live_price': price, 'price': price, 'trade_price': price,
            'price_source': 'strategy_v732_s3_observe' if observe_stage else 'strategy_v732_coverage_light',
            'price_ready': bool(price and price > 0),
            'price_reaction_pct': round(react, 4),
            'change_1m_pct': chg1, 'change_3m_pct': chg3, 'change_5m_pct': chg5,
            'spread_pct': round(spread, 4), 'slippage_pct': round(spread, 4),
            'buy_ratio': round(buy, 4), 'buy_sustain_1m': round(sustain, 4),
            'buy_sustain_1m_source': sustain_source, 'buy_sustain_1m_real': bool(sustain_real),
            'structure_tags': structures,
            'risk_tags': risk_tags,
            'stale_reasons': stale,
            'freshness_status': 'recheck' if stale else 'fresh',
            'reason': ' / '.join(row_reasons),
            's_stage_reasons': row_reasons,
            'block_reasons': block_reasons,
            'strategy_specific_misses': _v510_uniq(strategy_specific_misses, 12),
            's3_observe_v732': bool(observe_stage),
            'coverage_only_v661': not observe_stage,
            'coverage_light_v662': True,
            'coverage_light_v732': not observe_stage,
            'trade_candidate_row_v661': bool(observe_stage),
            'open_eligible': False,
            'paper_bot_open': False,
            'paper_experiment_open': False,
            'paper_experiment_handoff_ready_v674': False,
            'trade_ready': False,
            'v661_coverage_reason': '전략별 gate 미충족 row를 삭제하지 않고 coverage/비후보 또는 S3 관찰로 봉인',
            'v732_policy': 'S3는 paper OPEN이 아니라 놓친후보 복기용 관찰 후보다.',
            'canonical_entry_decision': {'schema':'coverage_light_v732_s3_observe', 's1_allowed': False, 'action': 'observe' if observe_stage else 'coverage', 'reasons': block_reasons, 'strategy_specific_misses': _v510_uniq(strategy_specific_misses, 12)},
            'entry_context': {'strategy_key': strategy_key, 'canonical_lane': lane, 'current_price': price, 'stale_reasons': stale, 'reasons': block_reasons, 'strategy_specific_misses': _v510_uniq(strategy_specific_misses, 12), 's3_observe_v732': bool(observe_stage)},
        }
        for _ok in V597_OFFICIAL_STRUCTURE_KEYS:
            _ov = src.get(_ok)
            if _ov not in (None, ''):
                row[_ok] = _ov
        rows.append(row)

    summary = {
        'schema': 'strategy_coverage_rows_v732_s3_observe',
        'version': VERSION,
        'feature_input_count': len(feature_list or []),
        'final_before_coverage_count': len(final_rows or []),
        'coverage_added_count': len(rows),
        's3_observe_added_count_v732': sum(1 for r in rows if r.get('s3_observe_v732')),
        'coverage_light_count_v732': sum(1 for r in rows if not r.get('s3_observe_v732')),
        'coverage_reason_top': dict(reason_counter.most_common(10)),
        'common_gate_reason_top_v732': dict(common_counter.most_common(10)),
        'strategy_gate_reason_top_v732': dict(strategy_counter.most_common(10)),
        's3_observe_reason_top_v732': dict(observe_counter.most_common(10)),
        'coverage_stale_top_v732': dict(stale_counter.most_common(8)),
        'gate_scope_check_v732': {'common_gate_spike_leak_count': leak_count, 'policy_ok': leak_count == 0, 'spike_gate_scope': 'breakout/spike strategy only'},
        'policy': 'S3 관찰 후보는 OPEN하지 않고 놓친후보 복기용으로 봉인한다. 급등초입 미충족은 공통 차단이 아니라 전략별 미충족으로 분리한다.',
    }
    return rows, summary


def _v1211_overlay_candle_scanner_once(src: Dict[str, Any], candle_map: Dict[str, Dict[str, Any]], hotmap: Dict[str, Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    """Apply Candle then Scanner fields with one output-row allocation."""
    merged = _v597_overlay_candle_cache(src, candle_map, nowv)
    ticker = ticker_norm(merged.get("ticker") or merged.get("market") or merged.get("symbol"))
    hot = hotmap.get(ticker, {}) if ticker else {}
    if not isinstance(hot, dict) or not hot:
        return merged
    for key in ("scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m", "hot_signal_age_sec", "hot_fresh", "scanner_hot_fresh"):
        if merged.get(key) in (None, "", 0, 0.0, 999999, 999999.0):
            merged[key] = hot.get(key)
    if merged.get("change_1m") in (None, "", 0, 0.0) and hot.get("change_1m") is not None:
        merged["change_1m"] = hot.get("change_1m")
    if merged.get("change_3m") in (None, "", 0, 0.0) and hot.get("change_3m") is not None:
        merged["change_3m"] = hot.get("change_3m")
    merged["_scanner_hot_cache_age_sec"] = hot.get("_cache_age_sec", _v521_file_age(SCANNER_HOT))
    return merged

def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    _v1027_profile = _v1027_new_cpu_profile(cycle_ts)
    _v1027_cycle_token = _v1027_phase_start()
    try:
        _tok = _v1028_live_phase_enter(_v1027_profile, 'status_start')
        write_status("running", phase="evaluating_v544", phase_note="v1027 direct phase measurement active", strategy_worker_version=VERSION)
        _v1027_phase_stop(_v1027_profile, 'status_start', _tok, calls=1)

        _tok = _v1028_live_phase_enter(_v1027_profile, 'feature_read_and_input_restore')
        fobj = load_json(FEATURE, {}) or {}
        raw_feature_list = feature_rows(fobj)
        raw_feature_list, v660_input_restore_summary = _v660_widen_strategy_input(raw_feature_list, cycle_ts)
        _v1027_phase_stop(_v1027_profile, 'feature_read_and_input_restore', _tok, calls=3, rows=len(raw_feature_list))

        _tok = _v1028_live_phase_enter(_v1027_profile, 'candle_cache_map_load')
        candle_map = _v1014_load_candle_map()
        _v1027_phase_stop(_v1027_profile, 'candle_cache_map_load', _tok, calls=1, rows=len(candle_map))
        _tok = _v1028_live_phase_enter(_v1027_profile, 'candle_and_scanner_overlay_v1210')
        hotmap = _v521_hot_map()
        feature_list = [
            _v1211_overlay_candle_scanner_once(src, candle_map, hotmap, cycle_ts)
            for src in raw_feature_list
        ]
        _v1027_phase_stop(_v1027_profile, 'candle_and_scanner_overlay_v1210', _tok, calls=1 + len(feature_list), rows=len(feature_list))

        _tok = _v1028_live_phase_enter(_v1027_profile, 'orderflow_cache_read')
        ofmap = _v521_load_map_with_cache_age(ORDERFLOW, "orderflow")
        _v1027_phase_stop(_v1027_profile, 'orderflow_cache_read', _tok, calls=1, rows=len(ofmap))

        _tok = _v1028_live_phase_enter(_v1027_profile, 'candidate_base_spike_merge')
        shared_eval_v1210 = _v1210_shared_candidate_eval(feature_list, ofmap)
        base_rows, rejects, reqs = _v510_base_lane(cycle_ts, feature_list, ofmap, shared_eval_v1210)
        spike_rows = _v510_spike_lane(cycle_ts, feature_list, ofmap, shared_eval_v1210)
        final_rows = _v510_merge_rows(base_rows + spike_rows, cycle_ts)
        _v1027_profile['shared_candidate_eval_rows_v1210'] = len(shared_eval_v1210)
        _v1027_profile['duplicate_strategy_eval_calls_avoided_v1210'] = len(shared_eval_v1210) * len(_V1210_EVALS)
        _v1027_profile['coverage_metric_calls_avoided_v1211'] = len(shared_eval_v1210) * 4
        _v1027_profile['scanner_overlay_second_copy_removed_v1211'] = len(feature_list)
        _v1027_phase_stop(_v1027_profile, 'candidate_base_spike_merge', _tok, calls=4, rows=len(feature_list) + len(base_rows) + len(spike_rows))

        _tok = _v1028_live_phase_enter(_v1027_profile, 'coverage_build_and_merge')
        coverage_rows_v661, v661_coverage_summary = _v661_build_coverage_rows(feature_list, final_rows, ofmap, cycle_ts, shared_eval_v1210)
        if coverage_rows_v661:
            _merged_by_ticker = {_v661_row_ticker(r): r for r in final_rows if isinstance(r, dict) and _v661_row_ticker(r)}
            for _cr in coverage_rows_v661:
                _ct = _v661_row_ticker(_cr)
                if _ct and _ct not in _merged_by_ticker:
                    _merged_by_ticker[_ct] = _cr
            final_rows = sorted(_merged_by_ticker.values(), key=lambda x: (_STAGE_ORDER.get(_v510_stage(x),0), _v510_num(x.get('score'), default=0.0), _event_created_ts(x)), reverse=True)
        _v1027_phase_stop(_v1027_profile, 'coverage_build_and_merge', _tok, calls=1 + len(coverage_rows_v661), rows=len(final_rows))

        _tok = _v1028_live_phase_enter(_v1027_profile, 'quality_summary_and_requests')
        info_quality = _v512_info_quality(feature_list, ofmap)
        if not isinstance(info_quality, dict):
            info_quality = {}
        info_quality['strategy_cpu_profile_v1027'] = _v1027_profile
        info_quality['v660_input_restore_summary'] = v660_input_restore_summary
        info_quality['strategy_input_count_v660'] = v660_input_restore_summary.get('strategy_input_count')
        info_quality['strategy_input_restored_v660'] = v660_input_restore_summary.get('restored_from_scanner_count')
        info_quality['v661_coverage_summary'] = v661_coverage_summary
        info_quality['coverage_rows_v661'] = v661_coverage_summary.get('coverage_added_count')
        info_quality['strategy_coverage_rows_v661'] = len(final_rows)
        info_quality['trade_candidate_rows_v661'] = max(0, len(final_rows) - _v1165_count_value(v661_coverage_summary.get('coverage_added_count'), field='info_quality.coverage_added_count'))
        info_quality['candle_overlay_cache_v1032'] = _v1032_candle_cache_status()
        info_quality['canonical_candle_map_rows_v1032'] = len(candle_map)
        info_quality['canonical_candle_map_owner_v1032'] = 'run_once._v1014_load_candle_map'
        for r in final_rows:
            t = ticker_norm(r.get("ticker"))
            if not t:
                continue
            bucket = "s1_candidate" if _v510_stage(r)=="S1" else ("spike_recheck" if str(r.get("canonical_lane"))=="spike" else "recheck_candidate")
            pri = 180 if _v510_stage(r)=="S1" else (130 if _v510_stage(r)=="S2" else 90)
            reqs.append({"ticker": t, "bucket": bucket, "priority": pri + _v510_num(r.get("score"), default=0.0), "need": ["quote", "micro"], "source": "strategy_worker_v529", "strategy_key": r.get("strategy_key"), "stage": _v510_stage(r), "reasons": r.get("s_stage_reasons", [])[:6], "updated_ts": cycle_ts})
        _v1027_phase_stop(_v1027_profile, 'quality_summary_and_requests', _tok, calls=1 + len(final_rows), rows=len(final_rows))

        _tok = _v1028_live_phase_enter(_v1027_profile, 'publish_total')
        result = _v510_publish(final_rows, rejects, reqs, len(feature_list), cycle_ts, info_quality, candle_map_v1032=candle_map)
        _v1027_phase_stop(_v1027_profile, 'publish_total', _tok, calls=1, rows=len(final_rows))
        _v1027_phase_stop(_v1027_profile, 'cycle_total', _v1027_cycle_token, calls=1, rows=len(feature_list))
        _v1027_finalize_cpu_profile(_v1027_profile, result)
        return result
    except Exception as exc:
        try:
            _v1027_phase_stop(_v1027_profile, 'cycle_total', _v1027_cycle_token, calls=1)
            _v1027_profile['error'] = f"{exc.__class__.__name__}: {exc}"
            _v1027_finalize_cpu_profile(_v1027_profile, {})
        except Exception:
            pass
        _v1165_trace = traceback.format_exc()
        append_error(ERROR, "v1027_run_once", exc)
        write_status(
            "error",
            error=f"{exc.__class__.__name__}: {exc}",
            error_owner_v1165="strategy_worker.run_once_after_candidate_commit",
            error_traceback_tail_v1165=_v1165_trace[-1800:],
            strategy_worker_version=VERSION,
        )
        raise

S2_PROMOTION_TRACE = BASE_DIR / "clean_s2_promotion_lifecycle_trace.json"

def _v563_has_text(row: Dict[str, Any], needles: Tuple[str, ...]) -> bool:
    vals: List[str] = []
    for k in ("recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons", "risk_tags", "execution_risk_tags", "structure_risk_tags", "s1_missing_names", "s_stage_reasons", "reasons"):
        v = row.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
        elif v not in (None, "", [], {}):
            vals.append(str(v))
    hay = " ".join(vals)
    return any(n in hay for n in needles)

def _v563_bool_ok(row: Dict[str, Any], metric: float, bad_words: Tuple[str, ...], min_value: Optional[float] = None, max_value: Optional[float] = None) -> bool:
    if _v563_has_text(row, bad_words):
        return False
    if min_value is not None and metric < min_value:
        return False
    if max_value is not None and metric > max_value:
        return False
    return True

def _v563_s2_promotion_record__L6490(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    st = _v510_stage(row)
    levels = row.get("structure_levels") if isinstance(row.get("structure_levels"), dict) else {}
    timing = row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {}
    plan = row.get("entry_plan") if isinstance(row.get("entry_plan"), dict) else {}
    t = ticker_norm(row.get("ticker") or row.get("symbol") or row.get("market"))
    price = _v510_num(row.get("current_price"), row.get("entry_price"), row.get("price"), default=0.0)
    trigger = _v510_num(levels.get("trigger_price"), plan.get("trigger_price"), default=0.0)
    trigger_gap = round(_v554_pct_between(trigger, price), 3) if price and trigger else None
    trigger_reached = bool(st == "S1" or (price and trigger and price >= trigger * 0.999) or str(levels.get("status") or "") == "triggered")
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), row.get("buy_ratio"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)
    slip = _v510_num(row.get("slippage_pct"), row.get("expected_slippage_pct"), row.get("spread_pct"), default=0.0)
    freshness_age = _v510_num(row.get("micro_age_sec"), row.get("orderflow_age_sec"), row.get("price_reaction_age_sec"), row.get("cache_age_sec"), default=0.0)
    freshness_ok = not _v563_has_text(row, ("신선도", "정보부족", "정보 부족", "갱신 대기", "stale"))
    price_reaction_ok = _v563_bool_ok(row, react, ("가격반응", "반응 약함"), min_value=0.35)
    buy_persist_ok = _v563_bool_ok(row, sustain, ("1분", "지속 부족"), min_value=0.60)
    buy_ratio_ok = _v563_bool_ok(row, buy, ("매수체결", "체결약함"), min_value=0.60)
    spread_ok = _v563_bool_ok(row, spread, ("스프레드",), max_value=0.50)
    slippage_ok = _v563_bool_ok(row, slip, ("미끄러짐", "슬리피지"), max_value=0.50)
    failed: List[str] = []
    if not trigger_reached:
        failed.append("방아쇠 미도달")
    if not freshness_ok:
        failed.append("정보/신선도 지연")
    if not price_reaction_ok:
        failed.append("가격반응 부족")
    if not buy_persist_ok:
        failed.append("1분 매수지속 부족")
    if not buy_ratio_ok:
        failed.append("매수체결 부족")
    if not spread_ok:
        failed.append("스프레드 회복 대기")
    if not slippage_ok:
        failed.append("미끄러짐 회복 대기")
    if row.get("late_chase_flag"):
        failed.append("늦은추격 위험")
    if st == "S1":
        promote_state = "promoted_s1"
    elif not trigger_reached:
        promote_state = "waiting_trigger"
    elif not freshness_ok:
        promote_state = "blocked_by_freshness_delay"
    elif not spread_ok or not slippage_ok:
        promote_state = "blocked_by_execution_risk"
    elif failed:
        promote_state = "blocked_by_confirm_signal"
    else:
        promote_state = "near_s1_needs_final_gate"
    would = []
    if not trigger_reached: would.append("방아쇠 가격 도달")
    if not freshness_ok: would.append("신선정보 갱신")
    if not price_reaction_ok: would.append("가격반응 회복")
    if not buy_persist_ok: would.append("1분 매수지속 회복")
    if not buy_ratio_ok: would.append("매수체결 회복")
    if not spread_ok: would.append("스프레드 회복")
    if not slippage_ok: would.append("미끄러짐 회복")
    rec = {
        "schema": "s2_promotion_lifecycle_row_v563",
        "ticker": t,
        "strategy": row.get("strategy_label") or row.get("strategy") or row.get("strategy_key"),
        "strategy_key": row.get("strategy_key") or row.get("paper_strategy_key"),
        "stage": st,
        "s2_seen_ts": timing.get("s2_seen_ts"),
        "s2_age_sec": timing.get("s2_to_now_delay_sec", timing.get("s2_to_current_delay_sec")),
        "first_seen_ts": timing.get("first_seen_ts"),
        "first_age_sec": timing.get("first_to_now_delay_sec", timing.get("first_to_current_delay_sec")),
        "current_price": price,
        "trigger_price": trigger,
        "trigger_reached": trigger_reached,
        "trigger_gap_pct": trigger_gap,
        "freshness_ok": freshness_ok,
        "freshness_age_sec": freshness_age,
        "spread_ok": spread_ok,
        "spread_pct": spread,
        "slippage_ok": slippage_ok,
        "slippage_pct": slip,
        "price_reaction_ok": price_reaction_ok,
        "price_reaction_pct": react,
        "buy_persist_ok": buy_persist_ok,
        "buy_sustain_1m": sustain,
        "buy_ratio_ok": buy_ratio_ok,
        "buy_ratio": buy,
        "promote_state": promote_state,
        "promote_block_reason": failed[:8],
        "failed_confirm": failed[:8],
        "would_be_s1_if": would[:8],
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
    }
    return rec

def _v563_attach_s2_promotion_lifecycle(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    records: List[Dict[str, Any]] = []
    state_counter: Counter = Counter()
    block_counter: Counter = Counter()
    for r in rows:
        rr = dict(r)
        st = _v510_stage(rr)
        rec = _v563_s2_promotion_record(rr, nowv)
        if st in ("S1", "S2"):
            records.append(rec)
            state_counter[rec.get("promote_state") or "-"] += 1
            for x in rec.get("promote_block_reason") or []:
                block_counter[str(x)] += 1
        rr["s2_promotion_lifecycle"] = rec
        rr["promotion_trace"] = rec
        rr["trigger_reached"] = rec.get("trigger_reached")
        rr["trigger_gap_pct"] = rec.get("trigger_gap_pct")
        rr["promote_state"] = rec.get("promote_state")
        rr["promote_block_reason"] = rec.get("promote_block_reason")
        rr["would_be_s1_if"] = rec.get("would_be_s1_if")
        ctx = rr.get("entry_context") if isinstance(rr.get("entry_context"), dict) else {}
        ctx = dict(ctx)
        ctx["s2_promotion_lifecycle"] = rec
        rr["entry_context"] = ctx
        out.append(rr)
    trace = {
        "schema": "s2_promotion_lifecycle_trace_v563",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "candidate_count": len(records),
        "state_counts": dict(state_counter),
        "block_top": [{"reason": k, "count": v} for k, v in block_counter.most_common(8)],
        "rows": records[:160],
        "policy": "조건/S등급/청산 변경 없이 S2->S1 승격 실패 원인만 기록",
    }
    save_json(S2_PROMOTION_TRACE, trace)
    return out, trace

_V573_AGE_KEYS = (
    "micro_age_sec", "orderflow_age_sec", "trade_age_sec", "quote_age_sec", "ws_age_sec",
    "price_reaction_age_sec", "feature_age_sec", "hot_signal_age_sec", "scanner_hot_age_sec", "cache_age_sec",
)

def _v573_text_blob(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ("stale_reasons", "freshness_flags", "recheck_reasons", "s2_recheck_reasons", "missing_info", "block_reasons", "risk_tags", "execution_risk_tags", "s1_missing_conditions"):
        v = row.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
        elif v not in (None, "", [], {}):
            vals.append(str(v))
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    for k in ("stale_reasons", "display_reasons", "s1_recheck_reasons", "s2_recheck_reasons", "missing_conditions"):
        v = dec.get(k)
        if isinstance(v, list):
            vals.extend(str(x or "") for x in v)
    return " ".join(vals)

def _v573_age_value(row: Dict[str, Any], key: str) -> Optional[float]:
    v = row.get(key)
    if v is None and isinstance(row.get("entry_context"), dict):
        v = row.get("entry_context", {}).get(key)
    try:
        if v in (None, "", [], {}):
            return None
        f = float(str(v).replace(",", "").replace("%", ""))
        if f < 0:
            return None
        return f
    except Exception:
        return None

def _v573_freshness_numeric_profile(row: Dict[str, Any]) -> Dict[str, Any]:
    blob = _v573_text_blob(row)
    has_fresh_text = any(w in blob for w in ("신선", "정보", "fresh", "stale", "갱신 대기", "오래됨"))
    ages: Dict[str, float] = {}
    for k in _V573_AGE_KEYS:
        v = _v573_age_value(row, k)
        if v is not None:
            ages[k] = round(v, 3)
    # 핵심값 기준. 없는 값은 통과가 아니라 숫자근거 부족으로 둔다.
    core_keys = ("micro_age_sec", "orderflow_age_sec", "trade_age_sec", "quote_age_sec", "ws_age_sec", "price_reaction_age_sec", "feature_age_sec")
    core_ages = {k: ages[k] for k in core_keys if k in ages}
    numeric_present = bool(core_ages)
    worst_core_age = max(core_ages.values()) if core_ages else None
    numeric_stale = bool(worst_core_age is not None and worst_core_age > 25.0)
    text_without_numeric = bool(has_fresh_text and not numeric_present)
    numeric_ok = bool(numeric_present and not numeric_stale and not text_without_numeric)
    if text_without_numeric:
        state = "text_only_no_numeric"
    elif numeric_stale:
        state = "numeric_age_stale"
    elif numeric_ok:
        state = "numeric_fresh"
    elif has_fresh_text:
        state = "freshness_text_unclear"
    else:
        state = "no_freshness_warning"
    return {
        "schema": "freshness_numeric_profile_v573",
        "state": state,
        "has_freshness_text": has_fresh_text,
        "numeric_present": numeric_present,
        "text_without_numeric": text_without_numeric,
        "numeric_stale": numeric_stale,
        "numeric_ok": numeric_ok,
        "worst_core_age_sec": worst_core_age,
        "ages": ages,
        "policy": "신선도 문구만 있고 숫자근거 없으면 S1 직행 금지/S2 재확인",
    }

def _v573_refined_late_chase_profile(row: Dict[str, Any]) -> Dict[str, Any]:
    levels = row.get("structure_levels") if isinstance(row.get("structure_levels"), dict) else {}
    timing = row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {}
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    spread = _v510_num(row.get("spread_pct"), default=0.0)
    slip = _v510_num(row.get("slippage_pct"), row.get("expected_slippage_pct"), default=spread)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), row.get("buy_ratio"), default=0.0)
    ch1 = _v510_num(row.get("change_1m_pct"), row.get("change_1m"), default=0.0)
    ch3 = _v510_num(row.get("change_3m_pct"), row.get("change_3m"), default=0.0)
    first_ret = _v510_num(timing.get("first_to_now_return_pct"), timing.get("first_to_current_return_pct"), default=0.0)
    s2_ret = _v510_num(timing.get("s2_to_now_return_pct"), timing.get("s2_to_current_return_pct"), default=0.0)
    base_late = bool(row.get("late_chase_flag") or levels.get("late_chase_flag") or timing.get("late_chase_flag"))
    fast_move = bool(first_ret >= 1.20 or s2_ret >= 0.80 or ch1 >= 1.80 or ch3 >= 3.20 or react >= 1.80)
    weak_confirm = bool(buy < 0.70 or sustain < 0.70)
    exec_risk = bool(spread > 0.35 or slip > 0.35)
    wick_or_sell = _v563_has_text(row, ("윗꼬리", "매도압력", "되돌림위험", "고점권"))
    freshness = _v573_freshness_numeric_profile(row)
    freshness_risk = bool(freshness.get("text_without_numeric") or freshness.get("numeric_stale"))
    hard_late = bool(base_late and fast_move and (weak_confirm or exec_risk or wick_or_sell or freshness_risk))
    broad_only = bool(base_late and not hard_late)
    if hard_late:
        state = "hard_late_chase"
    elif broad_only:
        state = "broad_late_label_only"
    else:
        state = "not_late_chase"
    reasons: List[str] = []
    if fast_move: reasons.append("가격이 이미 많이 움직임")
    if freshness_risk: reasons.append("신선도 숫자근거 부족/지연")
    if weak_confirm: reasons.append("확인신호 약함")
    if exec_risk: reasons.append("스프레드/미끄러짐 부담")
    if wick_or_sell: reasons.append("되돌림/매도압력 위험")
    return {
        "schema": "refined_late_chase_profile_v573",
        "state": state,
        "base_late_chase_flag": base_late,
        "hard_late_chase": hard_late,
        "broad_late_label_only": broad_only,
        "fast_move": fast_move,
        "weak_confirm": weak_confirm,
        "execution_risk": exec_risk,
        "freshness_risk": freshness_risk,
        "basis": {"first_ret": round(first_ret,3), "s2_ret": round(s2_ret,3), "chg1": round(ch1,3), "chg3": round(ch3,3), "reaction": round(react,3), "spread": round(spread,3), "slippage": round(slip,3), "buy": round(buy,3), "sustain": round(sustain,3)},
        "reasons": reasons[:6],
    }

def _v554_build_structure_levels__L6828(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v573_base_build_structure_levels(row)
    if not isinstance(levels, dict):
        return levels
    # base late flag는 남기되, S1 판단용 late flag는 refined hard late만 사용한다.
    temp = dict(row)
    temp["structure_levels"] = levels
    refined = _v573_refined_late_chase_profile(temp)
    base_flag = bool(levels.get("late_chase_flag"))
    levels["base_late_chase_flag"] = base_flag
    levels["late_chase_flag"] = bool(refined.get("hard_late_chase"))
    levels["refined_late_chase_profile"] = refined
    levels["late_chase_reason"] = " / ".join(refined.get("reasons") or []) if refined.get("hard_late_chase") else ("넓은 늦은추격 라벨만 있음" if refined.get("broad_late_label_only") else "")
    levels["schema"] = "structure_levels_v573_refined_late_chase"
    return levels

def _v532_build_canonical_entry_decision__L6846(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    dec = _v573_base_build_entry_decision(row)
    if not isinstance(dec, dict):
        return dec
    fresh = _v573_freshness_numeric_profile(row)
    late = _v573_refined_late_chase_profile(row)
    guard: List[str] = []
    if fresh.get("text_without_numeric"):
        guard.append("재확인: 신선도 숫자근거 확인 대기")
    # 숫자로도 오래된 신선도 + 진짜 늦은추격 조합은 S1 직행 금지. 단순 늦은추격 라벨만으로는 막지 않는다.
    if fresh.get("numeric_stale") and late.get("hard_late_chase"):
        guard.append("재확인: 신선도지연+진짜늦은추격")
    if guard:
        prev_guard = list(dec.get("s1_recheck_guard_reasons") or [])
        prev_recheck = list(dec.get("s1_recheck_reasons") or dec.get("s2_recheck_reasons") or [])
        merged = _v510_uniq(prev_guard + guard, 8)
        rechecks = _v510_uniq(prev_recheck + guard, 8)
        missing = list(dec.get("missing_conditions") or []) + guard
        checks = list(dec.get("checks") or [])
        for g in guard:
            checks.append({"name": "신선도근거" if "신선도" in g else "늦은추격정교화", "ok": False, "value": fresh.get("state"), "need": "numeric proof before S1", "reason": g, "weight": 2})
        dec.update({
            "schema": "canonical_entry_decision_v573_fresh_late_refined",
            "gate_pass": False,
            "s1_allowed": False,
            "s1_recheck_guard": True,
            "s1_recheck_guard_reasons": merged,
            "s1_recheck_reasons": rechecks,
            "s2_recheck_reasons": rechecks,
            "s2_recheck": True,
            "action": "recheck",
            "entry_profile": "watch",
            "exit_profile": "watch_exit",
            "profile_family": "watch",
            "missing_conditions": missing,
            "display_reasons": list(dec.get("display_reasons") or []) + guard,
            "checks": checks,
            "block_count": int(dec.get("block_count") or 0) + len(guard),
            "block_score": int(dec.get("block_score") or 0) + 2 * len(guard),
            "s1_distance": int(dec.get("s1_distance") or 0) + 2 * len(guard),
            "s1_near_miss": True,
            "s1_near_miss_level": "near",
        })
    dec["freshness_numeric_profile"] = fresh
    dec["refined_late_chase_profile"] = late
    dec["v573_policy"] = "신선도 숫자근거 없음은 S1 직행 금지, 늦은추격은 hard/broad로 분리"
    return dec

def _v532_apply_canonical_entry_decision__L6896(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v573_base_apply_entry_decision(row)
    if not isinstance(out, dict):
        return out
    dec = out.get("canonical_entry_decision") if isinstance(out.get("canonical_entry_decision"), dict) else {}
    fresh = dec.get("freshness_numeric_profile") if isinstance(dec.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(out)
    late = dec.get("refined_late_chase_profile") if isinstance(dec.get("refined_late_chase_profile"), dict) else _v573_refined_late_chase_profile(out)
    out["freshness_numeric_profile"] = fresh
    out["freshness_numeric_state"] = fresh.get("state")
    out["freshness_text_without_numeric"] = bool(fresh.get("text_without_numeric"))
    out["freshness_numeric_stale"] = bool(fresh.get("numeric_stale"))
    out["refined_late_chase_profile"] = late
    out["late_chase_refined_state"] = late.get("state")
    out["hard_late_chase_flag"] = bool(late.get("hard_late_chase"))
    out["broad_late_label_only"] = bool(late.get("broad_late_label_only"))
    ctx = out.get("entry_context") if isinstance(out.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["freshness_numeric_profile"] = fresh
    ctx["refined_late_chase_profile"] = late
    out["entry_context"] = ctx
    return out

def _v563_s2_promotion_record__L6920(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    rec = _v573_base_s2_promotion_record(row, nowv)
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    late = row.get("refined_late_chase_profile") if isinstance(row.get("refined_late_chase_profile"), dict) else _v573_refined_late_chase_profile(row)
    failed = list(rec.get("promote_block_reason") or [])
    would = list(rec.get("would_be_s1_if") or [])
    if fresh.get("text_without_numeric"):
        failed.append("신선도 숫자근거 없음")
        would.append("신선도 숫자근거 확보")
    if fresh.get("numeric_stale") and late.get("hard_late_chase"):
        failed.append("신선도지연+진짜늦은추격")
        would.append("긴급 신선정보 갱신 후 재판정")
    failed = _v510_uniq(failed, 10)
    would = _v510_uniq(would, 10)
    rec.update({
        "schema": "s2_promotion_lifecycle_row_v573_fresh_late_refined",
        "freshness_numeric_profile": fresh,
        "refined_late_chase_profile": late,
        "freshness_numeric_state": fresh.get("state"),
        "late_chase_refined_state": late.get("state"),
        "promote_block_reason": failed,
        "failed_confirm": failed,
        "would_be_s1_if": would,
    })
    if fresh.get("text_without_numeric"):
        rec["promote_state"] = "blocked_by_freshness_numeric_missing"
    elif fresh.get("numeric_stale") and late.get("hard_late_chase"):
        rec["promote_state"] = "blocked_by_freshness_late_chase"
    return rec

def _v574_is_s2_fresh_urgent_candidate(row: Dict[str, Any]) -> Tuple[bool, List[str], float]:
    if _v510_stage(row) != "S2":
        return False, [], 999.0
    promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    reasons = []
    gap = _v510_num(promo.get("trigger_gap_pct"), default=999.0)
    trigger_near = bool((gap <= 0.65) or bool(row.get("s1_near_miss")) or "방아쇠" in " ".join(str(x) for x in (promo.get("would_be_s1_if") or [])))
    stale_numeric = bool(fresh.get("numeric_stale") or fresh.get("text_without_numeric"))
    stale_text = bool(_v563_has_text(row, ("신선정보 갱신", "신선도", "정보/신선도 지연", "fresh")))
    if trigger_near:
        reasons.append("S2 방아쇠 근접")
    if stale_numeric:
        reasons.append("신선정보 숫자 오래됨/부족")
    elif stale_text:
        reasons.append("신선정보 갱신 필요")
    if bool(dec.get("s1_near_miss")):
        reasons.append("S1 근접")
    ok = bool(trigger_near and (stale_numeric or stale_text or bool(dec.get("s1_near_miss"))))
    return ok, _v510_uniq(reasons, 6), gap

def _v574_attach_s2_fresh_urgent_requests__L7022(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs = list(priority_requests or [])
    urgent_rows: List[Dict[str, Any]] = []
    seen = set()
    for row in rows:
        ok, reasons, gap = _v574_is_s2_fresh_urgent_candidate(row)
        if not ok:
            row["v574_fresh_urgent_request"] = False
            continue
        t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        if not t:
            continue
        fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
        promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
        pri = 760.0
        if gap <= 0.35:
            pri += 60.0
        elif gap <= 0.65:
            pri += 35.0
        if str(fresh.get("state")) == "numeric_age_stale":
            pri += 25.0
        if bool(row.get("s1_near_miss")):
            pri += 20.0
        req = {
            "ticker": t,
            "bucket": "near_s_info_wait",
            "priority": round(pri + min(40.0, _v510_num(row.get("score"), default=0.0)), 3),
            "need": ["quote", "ws", "micro"],
            "source": "strategy_worker_v574_s2_fresh_urgent",
            "stage": "S2",
            "strategy_key": row.get("strategy_key"),
            "trigger_gap_pct": gap if gap < 900 else None,
            "freshness_numeric_state": fresh.get("state"),
            "freshness_worst_age_sec": fresh.get("worst_core_age_sec"),
            "promote_state": promo.get("promote_state"),
            "reasons": reasons,
            "micro_urgent": True,
            "updated_ts": nowv,
            "policy": "S2 근접+fresh 부족은 S1 직행이 아니라 urgent refresh 후 재판정",
        }
        row["v574_fresh_urgent_request"] = True
        row["v574_fresh_urgent_reason"] = reasons
        row["v574_fresh_urgent_priority"] = req["priority"]
        row["v574_fresh_urgent_bucket"] = "near_s_info_wait"
        row["v574_fresh_urgent_requested_ts"] = nowv
        if t not in seen:
            out_reqs.append(req)
            urgent_rows.append(req)
            seen.add(t)
    return out_reqs, {
        "schema": "strategy_s2_fresh_urgent_summary_v574",
        "version": VERSION,
        "updated_ts": nowv,
        "request_count": len(urgent_rows),
        "targets": [r.get("ticker") for r in urgent_rows],
        "rows": urgent_rows[:60],
        "policy": "S2 근접 후보의 신선정보 갱신 필요를 최종 막힘으로 남기지 않고 target_router urgent refresh로 보낸다.",
    }

def _v575_text_has_any(vals: Any, words: Tuple[str, ...]) -> bool:
    try:
        if isinstance(vals, dict):
            vals = list(vals.values())
        if not isinstance(vals, list):
            vals = [vals]
        blob = " / ".join(str(x) for x in vals if x is not None)
    except Exception:
        blob = str(vals or "")
    return any(w in blob for w in words)

def _v575_fresh_ok(row: Dict[str, Any]) -> bool:
    fresh = row.get("freshness_numeric_profile") if isinstance(row.get("freshness_numeric_profile"), dict) else _v573_freshness_numeric_profile(row)
    st = str(fresh.get("state") or "")
    if bool(fresh.get("text_without_numeric") or fresh.get("numeric_stale")):
        return False
    return st in {"numeric_fresh", "no_freshness_warning"}

def _v575_block_bucket(row: Dict[str, Any]) -> str:
    promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
    failed = list(promo.get("failed_confirm") or promo.get("promote_block_reason") or [])
    would = list(promo.get("would_be_s1_if") or [])
    reasons = list(row.get("s_stage_reasons") or []) + list(row.get("s2_recheck_reasons") or []) + failed + would
    if not _v575_fresh_ok(row):
        return "fresh_wait"
    if _v575_text_has_any(reasons, ("스프레드", "미끄러짐")):
        return "exec_risk_wait"
    if _v575_text_has_any(reasons, ("방아쇠", "trigger")):
        return "trigger_wait"
    if _v575_text_has_any(reasons, ("1분", "매수체결", "체결", "가격반응")):
        return "confirm_wait"
    if _v510_stage(row) == "S1":
        return "promoted_s1"
    return "s2_other_wait"

def _v575_attach_urgent_action_result(rows: List[Dict[str, Any]], summary: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    counts: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    for row in rows:
        requested = bool(row.get("v574_fresh_urgent_request"))
        if not requested:
            row["v575_urgent_action_state"] = "not_requested"
            continue
        bucket = _v575_block_bucket(row)
        fresh_ok = _v575_fresh_ok(row)
        counts[bucket] += 1
        row["v575_urgent_action_state"] = bucket
        row["v575_urgent_fresh_recovered"] = bool(fresh_ok)
        row["v575_urgent_result_policy"] = "urgent 갱신 후 fresh 회복이면 남은 실행/방아쇠/확인 사유로 S1 또는 S2 유지"
        if len(samples) < 12:
            promo = row.get("s2_promotion_lifecycle") if isinstance(row.get("s2_promotion_lifecycle"), dict) else {}
            samples.append({
                "ticker": ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol")),
                "stage": _v510_stage(row),
                "action_state": bucket,
                "fresh_recovered": bool(fresh_ok),
                "trigger_gap_pct": promo.get("trigger_gap_pct"),
                "spread_pct": row.get("spread_pct"),
                "slippage_pct": row.get("slippage_pct"),
                "buy_ratio": row.get("buy_ratio"),
                "buy_sustain_1m": row.get("buy_sustain_1m"),
            })
    total = sum(counts.values())
    recovered = int(counts.get("exec_risk_wait",0)+counts.get("trigger_wait",0)+counts.get("confirm_wait",0)+counts.get("promoted_s1",0)+counts.get("s2_other_wait",0))
    result = {
        "schema": "s2_urgent_fresh_action_result_v575",
        "version": VERSION,
        "updated_ts": nowv,
        "request_count": total,
        "fresh_recovered_count": recovered,
        "s1_promoted_count": int(counts.get("promoted_s1",0)),
        "s2_keep_count": int(total - counts.get("promoted_s1",0)),
        "state_counts": dict(counts),
        "sample": samples,
        "policy": "S2 근접 fresh 부족은 urgent refresh를 태운 뒤 결과에 따라 S1 또는 S2 유지. 조건 수치 변경 없음.",
    }
    return result

def _v575_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v575_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    action = _v575_attach_urgent_action_result(rows, base_summary if isinstance(base_summary, dict) else {}, nowv)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary["v575_action_result"] = action
    base_summary["schema"] = "strategy_s2_fresh_urgent_summary_v575_action"
    base_summary["policy"] = "urgent 요청 생성+현재 cycle 결과 분류를 함께 저장한다. 요청만 세지 않고 S1/S2 결과까지 본다."
    return out_reqs, base_summary

def _v603_has_candle_wait(row: Dict[str, Any]) -> Tuple[bool, float, List[str]]:
    reasons = _v602_list(row.get('final_trade_reasons'), row.get('s_stage_reasons'), row.get('s2_recheck_reasons'), limit=16)
    blob = ' / '.join(str(x) for x in reasons)
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    struct = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
    official = struct.get('official_structure_inputs') if isinstance(struct.get('official_structure_inputs'), dict) else _v596_official_structure_inputs(row)
    age = _v510_num(official.get('official_candle_age'), row.get('official_candle_age'), row.get('candle_age_sec'), default=-1.0) if isinstance(official, dict) else -1.0
    present = _v510_num(official.get('present_count'), default=-1.0) if isinstance(official, dict) else -1.0
    text_wait = any(w in blob for w in ('공식 캔들 오래됨', '공식캔들 stale', '공식 구조재료 부족', '캔들 오래됨'))
    age_wait = bool(age > 45)
    missing_wait = bool(0 <= present < 6)
    return bool(text_wait or age_wait or missing_wait), age, reasons

def _v603_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v603_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    added: List[Dict[str, Any]] = []
    seen = {ticker_norm(r.get('ticker')) for r in out_reqs if isinstance(r, dict) and ticker_norm(r.get('ticker'))}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        state = str(row.get('final_trade_state') or '')
        stage = _v510_stage(row)
        if state not in {'S2_RECHECK', 'S1_PASS'} and stage not in {'S1', 'S2'}:
            row['v603_candle_fresh_request'] = False
            continue
        need, age, reasons = _v603_has_candle_wait(row)
        if not need:
            row['v603_candle_fresh_request'] = False
            continue
        t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        if not t:
            continue
        pri = 900.0 if stage == 'S1' or state == 'S1_PASS' else 850.0
        if age > 300:
            pri += 70.0
        elif age > 120:
            pri += 40.0
        req = {
            'ticker': t,
            'bucket': 's2_candle_fresh_wait' if stage == 'S2' else 's1_candle_preopen',
            'priority': round(pri + min(40.0, _v510_num(row.get('score'), default=0.0)), 3),
            'need': ['candle'],
            'source': 'strategy_worker_v603_final_trade_state_candle_wait',
            'stage': stage,
            'final_trade_state': state,
            'official_candle_age': age if age >= 0 else None,
            'reasons': reasons[:6] or ['공식 캔들 최신화 필요'],
            'updated_ts': nowv,
            'policy': '캔들이 오래돼 S1_PASS가 막힌 후보는 candle_worker가 먼저 갱신한다. 조건/S등급/청산 변경 없음.',
        }
        row['v603_candle_fresh_request'] = True
        row['v603_candle_fresh_age'] = age if age >= 0 else None
        row['v603_candle_fresh_bucket'] = req['bucket']
        if t not in seen:
            out_reqs.append(req)
            added.append(req)
            seen.add(t)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v603_candle_fresh_summary'] = {
        'schema': 'strategy_candle_fresh_priority_summary_v603',
        'version': VERSION,
        'request_count': len(added),
        'targets': [r.get('ticker') for r in added],
        'rows': added[:40],
        'policy': 'final_trade_state에서 공식 캔들 오래됨으로 막힌 S1/S2 후보를 candle_worker 우선순위로 보낸다.',
    }
    return out_reqs, base_summary

INFO_OWNER_TABLE_V584 = {
    'scanner': {'owner': 'scanner_worker', 'produces': ['ticker','hot_rank','volume','change_1m/3m/5m'], 'cache': 'scanner/feature input'},
    'feature': {'owner': 'feature_worker', 'produces': ['price','VWAP','EMA','relative_strength','price_reaction'], 'cache': 'feature cache'},
    'orderflow': {'owner': 'orderflow_worker+micro_ws', 'produces': ['quote','trade','spread','slippage','buy_ratio','sell_pressure'], 'cache': 'orderflow/micro cache'},
    'strategy': {'owner': 'strategy_worker', 'produces': ['structure','freshness_map','S1/S2/S3','entry_plan','risk_reward','block_reasons'], 'cache': 'canonical row + handoff'},
    'paper': {'owner': 'paper_bot', 'produces': ['OPEN','CLOSED','entry_reaction','score_cache','review_cache'], 'cache': 'paper status/trace/score/review'},
    'main': {'owner': 'main_bot', 'produces': ['display only'], 'cache': 'reads existing cache only'},
}

def _v584_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = [row.get(k) for k in keys]
    return _v510_num(*vals, default=default)

def _v584_structure_state(row: Dict[str, Any]) -> Tuple[str, List[str]]:
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    timing = row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {}
    tags = [str(x) for x in (row.get('structure_tags') or [])]
    risks = [str(x) for x in (row.get('risk_tags') or [])]
    price = _v584_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    first_price = _v510_num(timing.get('first_seen_price'), timing.get('structure_seen_price'), default=0.0)
    s2_price = _v510_num(timing.get('s2_seen_price'), default=0.0)
    first_ret = round(((price - first_price) / first_price * 100.0), 3) if price and first_price else _v510_num(timing.get('first_to_now_return'), timing.get('first_to_now_return_pct'), default=0.0)
    s2_ret = round(((price - s2_price) / s2_price * 100.0), 3) if price and s2_price else _v510_num(timing.get('s2_to_now_return'), timing.get('s2_to_now_return_pct'), default=0.0)
    trigger_gap = _v510_num(row.get('trigger_gap_pct'), levels.get('distance_to_trigger_pct'), default=999999.0)
    defense_fail = any(('방어실패' in x or '이탈' in x or '윗꼬리' in x or '가짜돌파' in x) for x in tags + risks)
    recovery = any(('VWAP' in x or 'EMA' in x or '눌림' in x or '회복' in x or '방어' in x) for x in tags)
    late = bool(row.get('late_chase_flag') or (first_ret >= 1.4) or (s2_ret >= 0.8) or any('늦은추격' in x for x in risks))
    if defense_fail:
        state = '방어실패/가짜돌파위험'
    elif late:
        state = '늦은추격주의'
    elif recovery:
        state = '눌림회복/방어구조'
    elif trigger_gap < 0.35:
        state = '방아쇠근접'
    else:
        state = '구조관찰'
    basis = [f'first→now {first_ret:+.2f}%', f'S2→now {s2_ret:+.2f}%', f'trigger_gap {trigger_gap if trigger_gap < 900000 else 0:.3f}%']
    if tags:
        basis.append('tags:' + ','.join(tags[:3]))
    if risks:
        basis.append('risk:' + ','.join(risks[:3]))
    return state, basis[:8]

def _v584_execution_risk(row: Dict[str, Any]) -> Dict[str, Any]:
    spread = _v584_num(row, 'spread_pct', default=0.0)
    slippage = _v584_num(row, 'slippage_pct', 'spread_pct', default=spread)
    buy = _v584_num(row, 'buy_ratio', default=0.0)
    sustain = _v584_num(row, 'buy_sustain_1m', default=0.0)
    tags = [str(x) for x in (row.get('risk_tags') or [])]
    obs: List[str] = []
    if spread > 0.18: obs.append('스프레드부담')
    if slippage > 0.18: obs.append('미끄러짐부담')
    if buy < 0.70: obs.append('매수체결약함')
    if sustain < 0.70: obs.append('1분지속약함')
    for x in tags:
        if x not in obs: obs.append(x)
    level = 'risk_high' if any(x in obs for x in ['스프레드부담','미끄러짐부담','매도압력부담','매도벽/매도체결압력']) else ('risk_watch' if obs else 'risk_ok')
    return {'schema': 'execution_risk_v584', 'state': level, 'tags': obs[:10], 'spread_pct': round(spread,4), 'slippage_pct': round(slippage,4), 'buy_ratio': round(buy,4), 'buy_sustain_1m': round(sustain,4)}

def _v584_timing_spine(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    old = row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {}
    price = _v584_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    first_ts = _v510_num(old.get('first_seen_ts'), row.get('first_seen_ts'), row.get('created_at'), default=0.0)
    s2_ts = _v510_num(old.get('s2_seen_ts'), row.get('s2_seen_ts'), default=0.0)
    s1_ts = _v510_num(old.get('s1_seen_ts'), row.get('s1_seen_ts'), default=0.0)
    first_price = _v510_num(old.get('first_seen_price'), row.get('first_seen_price'), row.get('detected_price'), price, default=0.0)
    s2_price = _v510_num(old.get('s2_seen_price'), row.get('s2_seen_price'), price if _v510_stage(row) == 'S2' else 0.0, default=0.0)
    s1_price = _v510_num(old.get('s1_seen_price'), row.get('s1_seen_price'), price if _v510_stage(row) == 'S1' else 0.0, default=0.0)
    first_to_now = round(((price-first_price)/first_price*100.0),3) if price and first_price else 0.0
    s2_to_now = round(((price-s2_price)/s2_price*100.0),3) if price and s2_price else 0.0
    return {'schema': 'entry_timing_spine_v584', 'first_seen_ts': first_ts or _event_created_ts(row), 's2_seen_ts': s2_ts, 's1_seen_ts': s1_ts, 'now_ts': nowv, 'first_seen_price': first_price, 's2_seen_price': s2_price, 's1_seen_price': s1_price, 'current_price': price, 'first_to_now_return_pct': first_to_now, 's2_to_now_return_pct': s2_to_now, 'first_to_s1_delay_sec': round(max(0.0, (s1_ts-first_ts)),3) if first_ts and s1_ts else None, 'late_chase_flag': bool(row.get('late_chase_flag') or first_to_now >= 1.4 or s2_to_now >= 0.8)}

def _v584_canonical_decision(structure_state: str, freshness: Dict[str, Any], execution: Dict[str, Any]) -> str:
    if freshness.get('overall') != 'fresh_ok':
        return '구조판단 fresh 재확인'
    if structure_state in {'늦은추격주의','방어실패/가짜돌파위험'}:
        return '구조위험 재확인'
    if execution.get('state') != 'risk_ok':
        return '실행위험 재확인'
    return '구조+fresh 관찰양호'

def _v584_build_canonical_metric_row__L7563(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    structure_state, basis = _v584_structure_state(row)
    freshness = _v584_build_freshness_map(row, nowv)
    execution = _v584_execution_risk(row)
    timing = _v584_timing_spine(row, nowv)
    decision = _v584_canonical_decision(structure_state, freshness, execution)
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    rr = row.get('risk_reward') if isinstance(row.get('risk_reward'), dict) else {}
    return {
        'schema': 'strategy_canonical_metric_row_v584',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'owner_policy': INFO_OWNER_TABLE_V584,
        'symbol': row.get('symbol') or row.get('ticker'),
        'ticker': row.get('ticker'),
        'strategy_key': row.get('strategy_key'),
        'strategy_label': row.get('strategy_label') or row.get('strategy'),
        'grade': _v510_stage(row),
        'metrics': {
            'price_reaction_pct': _v584_num(row, 'price_reaction_pct', default=0.0),
            'buy_ratio': _v584_num(row, 'buy_ratio', default=0.0),
            'buy_sustain_1m': _v584_num(row, 'buy_sustain_1m', default=0.0),
            'spread_pct': _v584_num(row, 'spread_pct', default=0.0),
            'slippage_pct': _v584_num(row, 'slippage_pct', 'spread_pct', default=0.0),
        },
        'freshness_map': freshness,
        'structure': {'state': structure_state, 'tags': list(row.get('structure_tags') or []), 'levels': levels, 'basis': basis},
        'entry_plan': plan,
        'risk_reward': rr,
        'execution_risk': execution,
        'timing_spine': timing,
        'block_reasons': list(row.get('block_reasons') or row.get('s_stage_reasons') or []),
        'entry_reasons': list(row.get('entry_reasons') or row.get('s_stage_reasons') or []),
        'source_snapshot': {'scanner': row.get('hot_signal_age_sec'), 'feature': row.get('price_reaction_age_sec'), 'orderflow': row.get('orderflow_age_sec'), 'micro': row.get('micro_age_sec'), 'quote': row.get('quote_age_sec')},
        'decision_reference': decision,
        'policy': '기능 유지. strategy_worker가 판단값을 봉인하고 paper/main은 읽기만 한다. 조건/S등급/청산 변경 없음.',
    }

def _v584_attach_canonical_metric_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        canon = _v584_build_canonical_metric_row(rr, nowv)
        sf = {
            'schema': 'structure_freshness_spine_v584_alias',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'structure_state': canon['structure']['state'],
            'structure_basis': canon['structure']['basis'],
            'freshness_state': canon['freshness_map']['overall'],
            'age_values': {k: v.get('age_sec') for k, v in canon['freshness_map']['items'].items()},
            'max_core_age_sec': canon['freshness_map']['max_core_age_sec'],
            'stale_fields': canon['freshness_map']['stale_fields'],
            'execution_risk_observed': canon['execution_risk']['state'] != 'risk_ok',
            'decision_reference': canon['decision_reference'],
            'policy': canon['policy'],
        }
        rr['canonical_metric_row'] = canon
        rr['canonical_row_schema'] = canon['schema']
        rr['freshness_map'] = canon['freshness_map']
        rr['execution_risk'] = canon['execution_risk']
        rr['timing_spine_v584'] = canon['timing_spine']
        rr['structure_freshness'] = sf
        rr['structure_state_v584'] = sf['structure_state']
        rr['structure_freshness_state'] = sf['freshness_state']
        rr['structure_fresh_decision'] = sf['decision_reference']
        # v602: strategy canonical row 안에서 최종 매수 가능/대기/관찰/차단을 한 번 더 봉인한다.
        rr = _v602_seal_final_trade_state(rr, canon)
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else canon
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['canonical_metric_row'] = canon
        ctx['freshness_map'] = canon['freshness_map']
        ctx['execution_risk'] = canon['execution_risk']
        ctx['timing_spine_v584'] = canon['timing_spine']
        ctx['structure_freshness'] = sf
        ctx['final_trade_state'] = rr.get('final_trade_state')
        ctx['final_trade_allowed'] = rr.get('final_trade_allowed')
        ctx['final_trade_label'] = rr.get('final_trade_label')
        ctx['final_trade_reasons'] = rr.get('final_trade_reasons')
        rr['entry_context'] = ctx
        out.append(rr)
    return out

def _v602_first_dict(*items: Any) -> Dict[str, Any]:
    for x in items:
        if isinstance(x, dict) and x:
            return x
    return {}

def _v602_list(*items: Any, limit: int = 12) -> List[str]:
    out: List[str] = []
    for item in items:
        if isinstance(item, list):
            src = item
        elif item in (None, "", {}, []):
            src = []
        else:
            src = [item]
        for v in src:
            sv = str(v or "").strip()
            if sv and sv not in out:
                out.append(sv)
            if len(out) >= limit:
                return out
    return out

def _v602_stage_for_state(state: str) -> str:
    if state == "S1_PASS":
        return "S1"
    if state == "S2_RECHECK":
        return "S2"
    return "S3"

def _v602_state_label(state: str) -> str:
    return {
        "S1_PASS": "✅ 매수 가능",
        "S2_RECHECK": "⚠️ 대기: 확인 더 필요",
        "S3_WATCH": "❔ 관찰만",
        "BLOCKED": "❌ 매수 금지: 위험",
    }.get(str(state or ""), "❔ 확인중")

def _v620_price_fmt(v: Any) -> str:
    try:
        f = float(str(v).replace(',', ''))
        if f >= 1000:
            return f"{f:,.0f}"
        if f >= 10:
            return f"{f:,.2f}".rstrip('0').rstrip('.')
        return f"{f:,.4f}".rstrip('0').rstrip('.')
    except Exception:
        return '-'

def _v620_trigger_gate(row: Dict[str, Any], canon: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    canon = canon if isinstance(canon, dict) else {}
    structure = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
    levels = structure.get('levels') if isinstance(structure.get('levels'), dict) else (row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {})
    plan = canon.get('entry_plan') if isinstance(canon.get('entry_plan'), dict) else (row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {})
    timing = canon.get('timing_spine') if isinstance(canon.get('timing_spine'), dict) else (row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else {})
    price = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), timing.get('current_price'), default=0.0)
    trigger = _v510_num(levels.get('trigger_price'), plan.get('trigger_price'), row.get('trigger_price'), default=0.0)
    tolerance = 0.999
    reached = bool(price and trigger and price >= trigger * tolerance)
    # 표시용 gap은 trigger 기준. 음수면 방아쇠 아래다.
    gap = None
    try:
        if price and trigger:
            gap = round((price - trigger) / trigger * 100.0, 3)
    except Exception:
        gap = None
    status = 'trigger_reached' if reached else ('trigger_missing' if not trigger else 'trigger_wait')
    reason = '방아쇠 도달 확인' if reached else ('방아쇠 가격 없음' if not trigger else f"방아쇠 미도달: 현재 {_v620_price_fmt(price)} < 방아쇠 {_v620_price_fmt(trigger)}")
    return {
        'schema': 'trigger_gate_v620',
        'current_price': round(price, 8) if price else None,
        'trigger_price': round(trigger, 8) if trigger else None,
        'trigger_reached': reached,
        'trigger_gap_pct': gap,
        'status': status,
        'reason': reason,
        'tolerance': tolerance,
        'policy': 'S1_PASS 전 trigger_reached를 확인한다. 방아쇠 미도달이면 S2_RECHECK.',
    }

def _v602_final_trade_decision(row: Dict[str, Any], canon: Dict[str, Any]) -> Dict[str, Any]:
    stage = _v510_stage(row)
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    dec = _v602_first_dict(row.get("canonical_entry_decision"), ctx.get("canonical_entry_decision"), row.get("common_entry_decision"), ctx.get("common_entry_decision"))
    freshness = canon.get("freshness_map") if isinstance(canon.get("freshness_map"), dict) else {}
    execution = canon.get("execution_risk") if isinstance(canon.get("execution_risk"), dict) else {}
    structure = canon.get("structure") if isinstance(canon.get("structure"), dict) else {}
    structure_state = str(structure.get("state") or row.get("structure_state_v584") or "")
    plan = canon.get("entry_plan") if isinstance(canon.get("entry_plan"), dict) else (row.get("entry_plan") if isinstance(row.get("entry_plan"), dict) else {})
    rr = canon.get("risk_reward") if isinstance(canon.get("risk_reward"), dict) else (row.get("risk_reward") if isinstance(row.get("risk_reward"), dict) else {})
    timing = canon.get("timing_spine") if isinstance(canon.get("timing_spine"), dict) else (row.get("entry_timing_spine") if isinstance(row.get("entry_timing_spine"), dict) else {})
    line_ev = structure.get("line_evidence") if isinstance(structure.get("line_evidence"), dict) else {}
    official = structure.get("official_structure_inputs") if isinstance(structure.get("official_structure_inputs"), dict) else _v596_official_structure_inputs(row) if "_v596_official_structure_inputs" in globals() else {}

    hard: List[str] = []
    wait: List[str] = []
    watch: List[str] = []

    if stage != "S1":
        if stage == "S2":
            wait.append("아직 S1이 아니라 재확인 대기")
        else:
            watch.append("S1 후보가 아니라 관찰")

    if not bool(dec.get("s1_allowed") or dec.get("gate_pass")):
        rs = dec.get("display_reasons") if isinstance(dec.get("display_reasons"), list) else (dec.get("s1_recheck_reasons") if isinstance(dec.get("s1_recheck_reasons"), list) else [])
        wait.append("전략 조건 최종통과 아님" + ((": " + " / ".join(str(x) for x in rs[:3])) if rs else ""))

    if row.get("fresh_gate_ok") is False:
        wait.append("정보가 오래돼 재확인 필요")
    if row.get("paper_bot_open") is False or row.get("open_eligible") is False or row.get("trade_ready") is False:
        wait.append("기존 OPEN 허용값이 꺼져 있음")

    if freshness.get("overall") != "fresh_ok":
        stale = freshness.get("stale_fields") if isinstance(freshness.get("stale_fields"), list) else []
        wait.append("최신정보 재확인 필요" + ((": " + " / ".join(str(x) for x in stale[:3])) if stale else ""))

    official_age = _v510_num(official.get("official_candle_age"), row.get("official_candle_age"), row.get("candle_age_sec"), default=-1.0) if isinstance(official, dict) else -1.0
    if official_age > 45:
        wait.append(f"공식 캔들 오래됨 {official_age:.0f}s")
    present = _v510_num(official.get("present_count"), default=-1.0) if isinstance(official, dict) else -1.0
    if 0 <= present < 6:
        wait.append("공식 구조재료 부족")

    line_risks = _v602_list(line_ev.get("line_risk_tags") if isinstance(line_ev, dict) else [], row.get("risk_tags"), execution.get("tags"), limit=12)
    if structure_state in {"늦은추격주의", "방어실패/가짜돌파위험"}:
        hard.append("차트 모양 위험: " + structure_state)
    if any(("가짜돌파" in x or "방어실패" in x or "윗꼬리" in x or "늦은추격" in x) for x in line_risks):
        hard.append("차트 위험태그: " + " / ".join(line_risks[:3]))

    exec_state = str(execution.get("state") or "")
    if exec_state == "risk_high":
        hard.append("진입 직전 거래위험 큼: " + " / ".join(line_risks[:4]))
    elif exec_state and exec_state != "risk_ok":
        wait.append("체결·스프레드 재확인 필요: " + exec_state)

    rr_ratio = _v510_num(rr.get("rr_ratio"), default=0.0) if isinstance(rr, dict) else 0.0
    if rr_ratio > 0 and rr_ratio < 1.0:
        wait.append(f"손익비 부족 {rr_ratio:.2f}")

    plan_status = str(plan.get("status") or "") if isinstance(plan, dict) else ""
    if plan_status and plan_status != "paper_open_ready":
        wait.append("진입계획 아직 대기: " + plan_status)

    trigger_gate = canon.get("trigger_gate") if isinstance(canon.get("trigger_gate"), dict) else _v620_trigger_gate(row, canon)
    # v620: stage가 S1이어도 price가 trigger 아래면 S1_PASS 금지. TON처럼 표시 trigger와 실행 가격이 갈라지는 경로를 차단한다.
    if trigger_gate.get("trigger_price") and trigger_gate.get("current_price") and not bool(trigger_gate.get("trigger_reached")):
        wait.append(str(trigger_gate.get("reason") or "방아쇠 미도달"))

    if bool(timing.get("late_chase_flag")):
        hard.append("늦은 진입 위험")

    if hard:
        state = "BLOCKED"
    elif wait:
        state = "S2_RECHECK"
    elif watch:
        state = "S3_WATCH"
    else:
        state = "S1_PASS"

    reasons = _v602_list(hard, wait, watch, canon.get("decision_reference"), limit=10)
    if state == "S1_PASS" and not reasons:
        reasons = ["전략공장 최종 매수 가능"]
    return {
        "state": state,
        "allowed": state == "S1_PASS",
        "stage": _v602_stage_for_state(state),
        "label": _v602_state_label(state),
        "reasons": reasons,
        "decision_reference": canon.get("decision_reference"),
        "schema": "final_trade_state_v603_strategy_single_source",
    }

def _v602_seal_final_trade_state(row: Dict[str, Any], canon: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    rr = dict(row)
    canon = canon if isinstance(canon, dict) else (rr.get("canonical_metric_row") if isinstance(rr.get("canonical_metric_row"), dict) else {})
    if not isinstance(canon, dict):
        canon = {}
    canon = dict(canon)
    trigger_gate = _v620_trigger_gate(rr, canon)
    canon["trigger_gate"] = trigger_gate
    canon["trigger_reached"] = bool(trigger_gate.get("trigger_reached"))
    canon["trigger_gap_pct"] = trigger_gate.get("trigger_gap_pct")
    rr["trigger_gate"] = trigger_gate
    rr["trigger_reached"] = bool(trigger_gate.get("trigger_reached"))
    rr["trigger_gap_pct"] = trigger_gate.get("trigger_gap_pct")
    final = _v602_final_trade_decision(rr, canon)
    state = str(final.get("state") or "")
    allowed = bool(final.get("allowed"))
    final_stage = str(final.get("stage") or _v602_stage_for_state(state))

    canon["schema"] = "strategy_canonical_metric_row_v620_trigger_gate_final_trade_state"
    canon["final_trade_state"] = state
    canon["final_trade_allowed"] = allowed
    canon["final_trade_label"] = final.get("label")
    canon["final_trade_reasons"] = final.get("reasons") or []
    canon["final_decision"] = final.get("label")
    canon["final_decision_schema"] = final.get("schema")
    canon["paper_open_policy"] = "paper OPEN은 final_trade_state == S1_PASS 한 가지만 본다"

    rr["canonical_metric_row"] = canon
    rr["final_trade_state"] = state
    rr["final_trade_allowed"] = allowed
    rr["final_trade_label"] = final.get("label")
    rr["final_trade_reasons"] = final.get("reasons") or []
    rr["final_decision"] = final.get("label")
    rr["final_decision_schema"] = final.get("schema")
    rr["final_trade_state_source"] = "strategy_worker_canonical_metric_row_v603"
    rr["s_stage"] = rr["candidate_stage"] = rr["candidate_grade"] = rr["stage"] = rr["grade"] = final_stage
    rr["open_eligible"] = allowed
    rr["paper_bot_open"] = allowed
    rr["trade_ready"] = allowed
    rr["trade_ready_label"] = final.get("label")
    rr["final_entry_action"] = "paper_open" if allowed else "hold"
    rr["final_entry_label"] = final.get("label")
    rr["final_entry_reasons"] = final.get("reasons") or []
    rr["s1_short_reason"] = " / ".join((final.get("reasons") or [])[:3]) if not allowed else "최종 매수 가능"

    dec = rr.get("canonical_entry_decision") if isinstance(rr.get("canonical_entry_decision"), dict) else {}
    if dec:
        dec = dict(dec)
        dec["raw_s1_allowed_before_final_trade_state"] = bool(dec.get("s1_allowed") or dec.get("gate_pass"))
        dec["final_trade_state"] = state
        dec["final_trade_allowed"] = allowed
        dec["final_trade_label"] = final.get("label")
        dec["final_trade_reasons"] = final.get("reasons") or []
        dec["s1_allowed"] = allowed
        dec["gate_pass"] = allowed
        dec["action"] = "paper_open_candidate" if allowed else ("recheck" if final_stage == "S2" else "observe")
        rr["canonical_entry_decision"] = dec
        rr["common_entry_decision"] = dec
        rr["common_entry_pass"] = allowed

    sf = rr.get("structure_freshness") if isinstance(rr.get("structure_freshness"), dict) else {}
    if sf:
        sf = dict(sf)
        sf["final_trade_state"] = state
        sf["final_trade_label"] = final.get("label")
        sf["final_trade_reasons"] = final.get("reasons") or []
        rr["structure_freshness"] = sf

    ctx = rr.get("entry_context") if isinstance(rr.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["canonical_metric_row"] = canon
    ctx["final_trade_state"] = state
    ctx["final_trade_allowed"] = allowed
    ctx["final_trade_label"] = final.get("label")
    ctx["final_trade_reasons"] = final.get("reasons") or []
    ctx["final_decision"] = final.get("label")
    ctx["final_decision_schema"] = final.get("schema")
    ctx["trigger_gate"] = trigger_gate
    ctx["trigger_reached"] = bool(trigger_gate.get("trigger_reached"))
    ctx["trigger_gap_pct"] = trigger_gate.get("trigger_gap_pct")
    if dec:
        ctx["canonical_entry_decision"] = dec
        ctx["common_entry_decision"] = dec
    rr["entry_context"] = ctx
    return rr

def _v595_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ""):
                return float(str(row.get(k)).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return default

def _v595_has_any(row: Dict[str, Any], *keys: str) -> bool:
    return any(isinstance(row, dict) and row.get(k) not in (None, "", 0, 0.0) for k in keys)

def _v595_list(row: Dict[str, Any], *keys: str) -> List[str]:
    out: List[str] = []
    for k in keys:
        v = row.get(k) if isinstance(row, dict) else None
        if isinstance(v, list):
            out += [str(x) for x in v if x]
        elif v not in (None, ""):
            out.append(str(v))
    return out

def _v595_clip_conf(x: float) -> int:
    try:
        return max(0, min(100, int(round(float(x)))))
    except Exception:
        return 0

def _v595_structure_line_evidence__L8034(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    """실제 차트 반응 기반 구조선 근거를 만든다. 없는 값을 0으로 신뢰하지 않는다."""
    price = _v595_num(row, 'current_price', 'entry_price', 'price', default=0.0)
    fam = str(levels.get('strategy_family') or _v554_strategy_family(row))
    tags = _v595_list(row, 'structure_tags', 'matched_strategy_labels', 'entry_structure_tags')
    risks = _v595_list(row, 'risk_tags', 'execution_risk_tags', 'structure_risk_tags')
    react = _v595_num(row, 'price_reaction_pct', default=0.0)
    buy = _v595_num(row, 'buy_ratio', default=0.0)
    sustain = _v595_num(row, 'buy_sustain_1m', default=0.0)
    spread = _v595_num(row, 'spread_pct', default=0.0)
    slip = _v595_num(row, 'slippage_pct', 'spread_pct', default=spread)
    ch1 = _v595_num(row, 'change_1m_pct', 'change_1m', default=0.0)
    ch3 = _v595_num(row, 'change_3m_pct', 'change_3m', default=0.0)
    high_gap = _v595_num(row, 'recent_high_gap_pct', 'below_high_pct', 'high_gap_pct', default=0.0)
    low_rebound = _v595_num(row, 'recent_low_rebound_pct', 'low_rebound_pct', default=0.0)
    vwap_gap = _v595_num(row, 'vwap_gap_pct', 'vwap_pos_pct', 'vwap_position_pct', default=999999.0)
    ema_gap = _v595_num(row, 'ema5_gap_pct', 'ema5_pos_pct', 'ma5_gap_pct', default=999999.0)
    upper_wick = _v595_num(row, 'upper_wick_pct', 'upper_shadow_pct', 'long_upper_wick_pct', default=0.0)
    lower_wick = _v595_num(row, 'lower_wick_pct', 'lower_shadow_pct', 'long_lower_wick_pct', default=0.0)
    vol_exp = _v595_num(row, 'volume_expansion_pct', 'volume_change_pct', 'trade_value_change_pct', default=0.0)
    sell_wall = any(('매도벽' in x or '매도압력' in x) for x in risks)
    fake_or_fail = any(('가짜돌파' in x or '방어실패' in x or '재이탈' in x or '윗꼬리' in x) for x in risks + tags)
    late = bool(row.get('late_chase_flag') or ch1 >= 1.8 or ch3 >= 3.2 or react >= 1.8 or any('늦은추격' in x for x in risks))

    support_reasons: List[str] = []
    resistance_reasons: List[str] = []
    trigger_reasons: List[str] = []
    invalid_reasons: List[str] = []
    risk_tags: List[str] = []
    missing: List[str] = []

    support_conf = 0.0
    resistance_conf = 0.0

    if low_rebound > 0.12 or _v595_has_any(row, 'recent_low_price', 'swing_low_price', 'box_low_price'):
        support_conf += 30; support_reasons.append('최근 저점/박스하단 반응')
    else:
        missing.append('swing_low')
    if abs(vwap_gap) <= 0.35 or abs(ema_gap) <= 0.35:
        support_conf += 25; support_reasons.append('VWAP/EMA 근접 겹침')
    elif vwap_gap < -0.20 and ema_gap < -0.20:
        risk_tags.append('VWAP/EMA 하단 구조')
    if lower_wick >= 0.20 or any('쓸림' in x or '저점' in x for x in tags):
        support_conf += 15; support_reasons.append('아랫꼬리/쓸림 후 회복 근거')
    if react > 0.20 and buy >= 0.65:
        support_conf += 15; support_reasons.append('반응+매수체결 동반')
    if spread <= 0.18 and slip <= 0.18:
        support_conf += 10; support_reasons.append('실행위험 정상권')

    if high_gap < -0.05 or _v595_has_any(row, 'recent_high_price', 'swing_high_price', 'box_high_price'):
        resistance_conf += 35; resistance_reasons.append('직전 고점/박스상단 근거')
    else:
        missing.append('swing_high')
    if upper_wick >= 0.20:
        resistance_conf += 15; resistance_reasons.append('윗꼬리 저항 흔적')
        risk_tags.append('윗꼬리 저항 주의')
    if sell_wall:
        resistance_conf += 15; resistance_reasons.append('매도벽/매도압력 구간')
    if vol_exp > 0.0:
        resistance_conf += 10; resistance_reasons.append('거래량/거래대금 반응')

    # 방아쇠는 저항선 근거 + 진입 확인신호가 같이 있어야 신뢰한다.
    trigger_conf = resistance_conf * 0.55
    if react >= 0.35:
        trigger_conf += 15; trigger_reasons.append(f'가격반응 {react:+.2f}%')
    if buy >= 0.70:
        trigger_conf += 12; trigger_reasons.append(f'매수체결 {buy:.2f}')
    if sustain >= 0.70:
        trigger_conf += 12; trigger_reasons.append(f'1분지속 {sustain:.2f}')
    if spread <= 0.18 and slip <= 0.18:
        trigger_conf += 10; trigger_reasons.append(f'스프레드/미끄러짐 정상 {spread:.2f}/{slip:.2f}%')
    if fake_or_fail:
        trigger_conf -= 30; risk_tags.append('가짜돌파/방어실패 위험')
    if late:
        trigger_conf -= 25; risk_tags.append('늦은추격 구조위험')
    if fam == 'hot_rank':
        trigger_conf -= 10; risk_tags.append('hot-rank는 발견신호')
    if fam == 'sweep_vwap' and support_conf < 55:
        trigger_conf -= 15; risk_tags.append('저점 VWAP 회복 지지근거 약함')

    invalid_conf = support_conf * 0.75
    if support_conf >= 55:
        invalid_reasons.append('지지선 재이탈 기준')
    if vwap_gap > -0.10 or ema_gap > -0.10:
        invalid_reasons.append('VWAP/EMA 방어 실패 기준')
    if not invalid_reasons:
        invalid_reasons.append('구조 무효 근거 부족')
        risk_tags.append('무효선 계산선 의심')

    support_conf_i = _v595_clip_conf(support_conf)
    resistance_conf_i = _v595_clip_conf(resistance_conf)
    trigger_conf_i = _v595_clip_conf(trigger_conf)
    invalid_conf_i = _v595_clip_conf(invalid_conf)

    if trigger_conf_i >= 70 and support_conf_i >= 55 and not fake_or_fail:
        quality = 'reactive_line_confirmed'
    elif trigger_conf_i >= 50 and support_conf_i >= 40:
        quality = 'reactive_line_watch'
    else:
        quality = 'calculated_line_recheck'
        risk_tags.append('구조선 근거 재확인')

    return {
        'schema': 'structure_line_evidence_v595',
        'quality': quality,
        'support_confidence': support_conf_i,
        'resistance_confidence': resistance_conf_i,
        'trigger_confidence': trigger_conf_i,
        'invalid_confidence': invalid_conf_i,
        'support_reason': ' / '.join(support_reasons[:5]) or '실제 반응선 근거 부족',
        'resistance_reason': ' / '.join(resistance_reasons[:5]) or '실제 저항 근거 부족',
        'trigger_reason': ' / '.join(trigger_reasons[:6]) or '방아쇠 확인신호 부족',
        'invalid_reason': ' / '.join(invalid_reasons[:4]),
        'line_risk_tags': _v510_uniq(risk_tags, 8),
        'missing_structure_inputs': _v510_uniq(missing, 6),
        'basis': {'family': fam, 'price': price, 'react': round(react,3), 'buy': round(buy,3), 'sustain': round(sustain,3), 'spread': round(spread,3), 'slippage': round(slip,3), 'vwap_gap': round(vwap_gap if vwap_gap < 900000 else 0,3), 'ema_gap': round(ema_gap if ema_gap < 900000 else 0,3), 'high_gap': round(high_gap,3), 'low_rebound': round(low_rebound,3), 'late_chase': late},
    }

def _v554_build_structure_levels__L8155(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v595_base_build_structure_levels(row)
    if not isinstance(levels, dict) or not levels.get('available'):
        return levels
    ev = _v595_structure_line_evidence(row, levels)
    levels = dict(levels)
    levels['schema'] = 'structure_levels_v595_reactive_lines'
    levels['line_policy'] = '실제 차트 반응선 우선. 계산선은 recheck로 표시하고 기능/청산은 변경하지 않는다.'
    levels['structure_line_evidence'] = ev
    levels['structure_line_quality'] = ev['quality']
    levels['support_reason'] = ev['support_reason']
    levels['resistance_reason'] = ev['resistance_reason']
    levels['trigger_reason'] = ev['trigger_reason'] if ev['trigger_reason'] != '방아쇠 확인신호 부족' else levels.get('trigger_reason') or ev['trigger_reason']
    levels['invalid_reason'] = ev['invalid_reason']
    levels['support_confidence'] = ev['support_confidence']
    levels['resistance_confidence'] = ev['resistance_confidence']
    levels['trigger_confidence'] = ev['trigger_confidence']
    levels['invalid_confidence'] = ev['invalid_confidence']
    levels['line_risk_tags'] = ev['line_risk_tags']
    levels['missing_structure_inputs'] = ev['missing_structure_inputs']
    # 목표/손익비 수치는 기존 값 유지. 단, 근거 문자열만 실제 반응선 근거로 보강한다.
    levels['target_reason'] = (levels.get('target_reason') or '') + ' / v595: 저항선·방아쇠 신뢰도 참고'
    return levels

def _v595_apply_structure_line_gate(row: Dict[str, Any]) -> Dict[str, Any]:
    r = dict(row)
    levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
    ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
    quality = str(levels.get('structure_line_quality') or ev.get('quality') or '')
    trig_conf = _v510_num(levels.get('trigger_confidence'), ev.get('trigger_confidence'), default=0.0)
    support_conf = _v510_num(levels.get('support_confidence'), ev.get('support_confidence'), default=0.0)
    line_risks = [str(x) for x in (levels.get('line_risk_tags') or ev.get('line_risk_tags') or [])]
    severe = any(('가짜돌파' in x or '방어실패' in x or '늦은추격' in x or '지지근거 약함' in x) for x in line_risks)
    needs_recheck = quality == 'calculated_line_recheck' or trig_conf < 45 or support_conf < 35 or severe
    r['structure_line_quality'] = quality
    r['structure_line_confidence'] = {'trigger': trig_conf, 'support': support_conf, 'quality': quality}
    r['structure_line_risk_tags'] = line_risks
    if line_risks:
        r['structure_risk_tags'] = _v510_uniq(list(r.get('structure_risk_tags') or []) + line_risks, 12)
        r['risk_tags'] = _v510_uniq(list(r.get('risk_tags') or []) + line_risks, 12)
    if _v510_stage(r) == 'S1' and needs_recheck:
        r['v595_downgraded_from_s1_structure_line'] = True
        r['s_stage'] = r['candidate_stage'] = r['candidate_grade'] = r['stage'] = r['grade'] = 'S2'
        r['open_eligible'] = False
        r['paper_bot_open'] = False
        r['trade_ready'] = False
        reason = f"구조선 재확인: {quality or 'unknown'} / trigger_conf {trig_conf:.0f} / support_conf {support_conf:.0f}"
        r['s_stage_reasons'] = _v510_uniq(list(r.get('s_stage_reasons') or []) + [reason], 14)
        r['s2_recheck_reasons'] = _v510_uniq(list(r.get('s2_recheck_reasons') or []) + [reason], 12)
    return r

def _v595_attach_reactive_structure_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    gated = [_v595_apply_structure_line_gate(r) for r in (rows or []) if isinstance(r, dict)]
    out = _v595_base_attach_canonical_metric_rows(gated, nowv)
    for rr in out:
        levels = rr.get('structure_levels') if isinstance(rr.get('structure_levels'), dict) else {}
        ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else {}
        if isinstance(canon, dict):
            canon['schema'] = 'strategy_canonical_metric_row_v595_reactive_structure_lines'
            struct = canon.get('structure') if isinstance(canon.get('structure'), dict) else {}
            struct['levels'] = levels
            struct['line_evidence'] = ev
            struct['line_quality'] = levels.get('structure_line_quality')
            struct['line_risk_tags'] = levels.get('line_risk_tags') or []
            canon['structure'] = struct
            canon['policy'] = 'v595: 구조선은 실제 반응선 reason/confidence로 봉인. paper/main은 읽기만. 청산/자동매수/장부 변경 없음.'
            rr['canonical_metric_row'] = canon
            ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
            ctx = dict(ctx); ctx['canonical_metric_row'] = canon; rr['entry_context'] = ctx
    return out

def _v596_num_known(row: Dict[str, Any], *keys: str) -> Tuple[Optional[float], bool]:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ""):
                return float(str(row.get(k)).replace(',', '').replace('%', '')), True
        except Exception:
            continue
    return None, False

def _v596_official_structure_inputs__L8312(row: Dict[str, Any]) -> Dict[str, Any]:
    """feature_worker가 공식 캔들 API 기반으로 넘긴 구조선 재료를 표준화한다."""
    keys = [
        'official_candle_source','official_candle_age','official_candle_intervals',
        'swing_high_price','swing_low_price','box_high_price','box_low_price',
        'recent_high_price','recent_low_price','support_touch_count','resistance_touch_count',
        'upper_wick_pct','lower_wick_pct','vwap_gap_pct','ema5_gap_pct','ema10_gap_pct','ema20_gap_pct',
        'volume_ratio','volume_expansion_pct','breakout_hint','sweep_reclaim_hint','box_breakout_hint',
        'support_reclaim_hint','resistance_reject_hint','pullback_volume_contract','reclaim_volume_expand'
    ]
    out={k:row.get(k) for k in keys if isinstance(row,dict) and row.get(k) not in (None,'')}
    present=[k for k in keys if isinstance(row,dict) and row.get(k) not in (None,'')]
    missing=[]
    for k in ('swing_high_price','swing_low_price','box_high_price','box_low_price','upper_wick_pct','lower_wick_pct','vwap_gap_pct','ema5_gap_pct','volume_ratio'):
        if k not in present:
            missing.append(k)
    out['present_count']=len(present)
    out['missing_core']=missing[:12]
    out['source_policy']='v596: 공식 API OHLCV 구조 재료는 feature_worker 생산, strategy_worker 봉인만 수행'
    return out

def _v595_structure_line_evidence__L8336(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    ev = _v596_prev_structure_line_evidence(row, levels)
    if not isinstance(ev, dict):
        ev={}
    official = _v596_official_structure_inputs(row)
    risk_tags=list(ev.get('line_risk_tags') or [])
    missing=list(ev.get('missing_structure_inputs') or [])
    support_reason=str(ev.get('support_reason') or '')
    resistance_reason=str(ev.get('resistance_reason') or '')
    trigger_reason=str(ev.get('trigger_reason') or '')
    support_conf=float(ev.get('support_confidence') or 0)
    resistance_conf=float(ev.get('resistance_confidence') or 0)
    trigger_conf=float(ev.get('trigger_confidence') or 0)

    support_touch, support_touch_ok = _v596_num_known(row,'support_touch_count')
    resist_touch, resist_touch_ok = _v596_num_known(row,'resistance_touch_count')
    swing_low, swing_low_ok = _v596_num_known(row,'swing_low_price','recent_low_price','box_low_price')
    swing_high, swing_high_ok = _v596_num_known(row,'swing_high_price','recent_high_price','box_high_price')
    vwap_gap, vwap_ok = _v596_num_known(row,'vwap_gap_pct')
    ema5_gap, ema5_ok = _v596_num_known(row,'ema5_gap_pct')
    upper, upper_ok = _v596_num_known(row,'upper_wick_pct')
    lower, lower_ok = _v596_num_known(row,'lower_wick_pct')
    vol_ratio, vol_ok = _v596_num_known(row,'volume_ratio')
    official_age, official_age_ok = _v596_num_known(row,'official_candle_age','candle_age_sec')

    add_support=[]; add_resist=[]; add_trigger=[]
    if support_touch_ok and support_touch >= 2:
        support_conf += 18; add_support.append(f'공식캔들 지지반응 {int(support_touch)}회')
    if swing_low_ok:
        support_conf += 10; add_support.append('공식 swing low/box low 존재')
    if vwap_ok and abs(vwap_gap or 0) <= 0.35:
        support_conf += 10; add_support.append('공식 VWAP 근접')
    if ema5_ok and abs(ema5_gap or 0) <= 0.35:
        support_conf += 8; add_support.append('공식 EMA5 근접')
    if lower_ok and lower >= 35:
        support_conf += 10; add_support.append('공식 아랫꼬리 회복')
    if bool(row.get('support_reclaim_hint') or row.get('sweep_reclaim_hint')):
        support_conf += 12; add_support.append('쓸림/지지 회복 힌트')

    if resist_touch_ok and resist_touch >= 2:
        resistance_conf += 18; add_resist.append(f'공식캔들 저항반응 {int(resist_touch)}회')
    if swing_high_ok:
        resistance_conf += 10; add_resist.append('공식 swing high/box high 존재')
    if upper_ok and upper >= 35:
        resistance_conf += 8; add_resist.append('공식 윗꼬리 저항')
    if bool(row.get('resistance_reject_hint')):
        resistance_conf += 10; add_resist.append('저항 거절 힌트')
    if vol_ok and vol_ratio >= 1.15:
        resistance_conf += 7; add_resist.append(f'공식 거래량반응 {vol_ratio:.2f}x')

    if bool(row.get('box_breakout_hint') or row.get('breakout_hint')) and swing_high_ok:
        trigger_conf += 15; add_trigger.append('공식 박스/직전고점 돌파 힌트')
    if bool(row.get('reclaim_volume_expand')):
        trigger_conf += 10; add_trigger.append('회복 거래량 재증가')
    if official_age_ok and official_age > 45:
        risk_tags.append(f'공식캔들 stale {official_age:.0f}s')
    if official.get('present_count',0) < 6:
        risk_tags.append('공식구조재료 부족')
    for m in official.get('missing_core') or []:
        if m not in missing:
            missing.append(m)

    support_conf_i=_v595_clip_conf(support_conf)
    resistance_conf_i=_v595_clip_conf(resistance_conf)
    trigger_conf_i=_v595_clip_conf(trigger_conf)
    severe = any(('가짜돌파' in x or '방어실패' in x or '늦은추격' in x or 'stale' in x) for x in risk_tags)
    if trigger_conf_i >= 72 and support_conf_i >= 60 and not severe:
        quality='official_reactive_line_confirmed'
    elif trigger_conf_i >= 52 and support_conf_i >= 42:
        quality='official_reactive_line_watch'
    else:
        quality=ev.get('quality') or 'calculated_line_recheck'

    ev.update({
        'schema':'structure_line_evidence_v596_official_api_inputs',
        'quality':quality,
        'support_confidence':support_conf_i,
        'resistance_confidence':resistance_conf_i,
        'trigger_confidence':trigger_conf_i,
        'support_reason':' / '.join([x for x in [support_reason]+add_support if x and x!='실제 반응선 근거 부족'][:7]) or '실제 반응선 근거 부족',
        'resistance_reason':' / '.join([x for x in [resistance_reason]+add_resist if x and x!='실제 저항 근거 부족'][:7]) or '실제 저항 근거 부족',
        'trigger_reason':' / '.join([x for x in [trigger_reason]+add_trigger if x and x!='방아쇠 확인신호 부족'][:8]) or '방아쇠 확인신호 부족',
        'line_risk_tags':_v510_uniq(risk_tags,10),
        'missing_structure_inputs':_v510_uniq(missing,12),
        'official_structure_inputs':official,
    })
    basis=ev.get('basis') if isinstance(ev.get('basis'),dict) else {}
    basis.update({'official_present':official.get('present_count'), 'official_age':official.get('official_candle_age'), 'support_touch':support_touch if support_touch_ok else None, 'resistance_touch':resist_touch if resist_touch_ok else None})
    ev['basis']=basis
    return ev

def _v596_attach_official_structure_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    out = _v596_prev_attach_reactive_structure_rows(rows, nowv)
    # v603: 공식 candle/구조선 evidence를 붙인 뒤 final_trade_state를 다시 봉인하고,
    #       그 결과를 반드시 out[index]에 되돌려 넣는다.
    #       v602는 rr 로컬 변수만 재할당될 수 있어 paper row가 공식 candle 반영 전 판정으로 남을 수 있었다.
    for idx, rr0 in enumerate(out):
        if not isinstance(rr0, dict):
            continue
        rr = dict(rr0)
        levels=rr.get('structure_levels') if isinstance(rr.get('structure_levels'),dict) else {}
        ev=levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'),dict) else {}
        canon=rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'),dict) else {}
        if isinstance(canon,dict):
            canon=dict(canon)
            canon['schema']='strategy_canonical_metric_row_v603_official_structure_final_trade_state'
            struct=canon.get('structure') if isinstance(canon.get('structure'),dict) else {}
            struct=dict(struct)
            struct['official_structure_inputs']=ev.get('official_structure_inputs') or _v596_official_structure_inputs(rr)
            struct['line_evidence']=ev
            struct['line_quality']=levels.get('structure_line_quality') or ev.get('quality')
            canon['structure']=struct
            canon['policy']='v603: 공식 API 구조재료 반영 후 final_trade_state를 다시 봉인하고 paper/main은 그 값만 읽는다.'
            rr['canonical_metric_row']=canon
            rr = _v602_seal_final_trade_state(rr, canon)
            canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else canon
            ctx=rr.get('entry_context') if isinstance(rr.get('entry_context'),dict) else {}
            ctx=dict(ctx); ctx['canonical_metric_row']=canon; ctx['final_trade_state']=rr.get('final_trade_state'); ctx['final_trade_label']=rr.get('final_trade_label'); ctx['final_trade_reasons']=rr.get('final_trade_reasons'); ctx['final_trade_allowed']=rr.get('final_trade_allowed'); rr['entry_context']=ctx
            rr['v603_official_final_state_resealed'] = True
            out[idx] = rr
    return out

def main() -> None:  # type: ignore[override]
    try:
        _v1026_write_candidate_counter_boot_status()
    except Exception as exc:
        append_error(ERROR, "candidate_counter_boot_status_v1026", exc)
    _v1022_start_status_heartbeat()
    _v1028_live_phase_idle("boot_v1028")
    write_status("running", phase="boot_v1028", evaluated=0, s_count=0, target_count=0, last_sec=0, strategy_worker_version=VERSION)
    while True:
        try:
            run_once()
            _v1028_live_phase_idle("sleep_wait_v1028")
        except KeyboardInterrupt:
            _STATUS_HEARTBEAT_STOP_V1022.set()
            write_status("stopping", strategy_worker_version=VERSION)
            raise
        except Exception as exc:
            _v1028_live_phase_idle("error_v1028")
            _v1165_loop_trace = traceback.format_exc()
            append_error(ERROR, "loop_v512", exc)
            write_status(
                "error",
                error=f"{exc.__class__.__name__}: {exc}",
                error_owner_v1165="strategy_worker.main_loop",
                error_traceback_tail_v1165=_v1165_loop_trace[-1800:],
                strategy_worker_version=VERSION,
            )
        time.sleep(max(0.5, INTERVAL_SEC))

def _v612_nested(d: Dict[str, Any], *keys: str, default: Any=None) -> Any:
    cur: Any = d
    for k in keys:
        if not isinstance(cur, dict):
            return default
        cur = cur.get(k)
    return cur if cur is not None else default

def _v612_age_item_state(items: Dict[str, Any], key: str) -> Tuple[str, float, float]:
    it = items.get(key) if isinstance(items, dict) else None
    if not isinstance(it, dict):
        return ('missing', 999999.0, 0.0)
    return (str(it.get('state') or 'missing'), _v510_num(it.get('age_sec'), default=999999.0), _v510_num(it.get('ttl_sec'), default=0.0))

def _v612_is_fresh_wait_row(row: Dict[str, Any]) -> bool:
    stage = _v510_stage(row)
    if stage not in ('S1','S2'):
        return False
    texts: List[str] = []
    for k in ('v575_urgent_action_state','v574_fresh_urgent_reason','final_decision','final_trade_label','final_trade_state','block_reason','s1_block_reason'):
        v = row.get(k)
        if v is not None:
            texts.append(str(v))
    for k in ('final_trade_reasons','s_stage_reasons','missing_info','stale_reasons','risk_tags'):
        v = row.get(k)
        if isinstance(v, list):
            texts.extend(str(x) for x in v[:8])
    fm = _v612_nested(row, 'canonical_metric_row', 'freshness_map', default={})
    if isinstance(fm, dict) and fm.get('overall') not in (None, '', 'fresh_ok'):
        return True
    low = ' '.join(texts).lower()
    return any(x in low for x in ('fresh_wait','fresh','신선','최신정보','오래됨','stale','정보'))

def _v612_fresh_cause_for_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    fm = canon.get('freshness_map') if isinstance(canon.get('freshness_map'), dict) else (row.get('freshness_map') if isinstance(row.get('freshness_map'), dict) else {})
    items = fm.get('items') if isinstance(fm.get('items'), dict) else {}
    causes: List[str] = []
    detail: List[str] = []

    # 1) 공식 캔들/구조재료 freshness
    official_age = _v510_num(
        _v612_nested(canon, 'structure', 'official_structure_inputs', 'official_candle_age'),
        row.get('official_candle_age'), row.get('candle_age_sec'), default=-1.0)
    if official_age >= 0 and official_age > 120:
        causes.append('candle')
        detail.append(f'캔들 {official_age:.0f}s')

    # 2) feature freshness: 가격반응/VWAP/EMA/1분지속 계열
    st, agev, ttl = _v612_age_item_state(items, 'price_reaction')
    feature_age = _v510_num(row.get('feature_age_sec'), row.get('price_reaction_age_sec'), default=agev)
    if st != 'fresh' or feature_age > max(ttl or 30.0, 30.0):
        causes.append('feature')
        detail.append(f'feature {feature_age:.0f}s')

    # 3) orderflow freshness: 매수체결/매도압력 계열
    st, agev, ttl = _v612_age_item_state(items, 'orderflow')
    order_age = _v510_num(row.get('orderflow_age_sec'), default=agev)
    if st != 'fresh' or order_age > max(ttl or 20.0, 20.0):
        causes.append('orderflow')
        detail.append(f'체결 {order_age:.0f}s')

    # 4) micro freshness: 스프레드/미끄러짐/시세 계열
    micro_bad = False
    st, agev, ttl = _v612_age_item_state(items, 'micro')
    micro_age = _v510_num(row.get('micro_age_sec'), default=agev)
    if st != 'fresh' or micro_age > max(ttl or 20.0, 20.0):
        micro_bad = True
    stq, ageq, ttlq = _v612_age_item_state(items, 'quote')
    quote_age = _v510_num(row.get('quote_age_sec'), default=ageq)
    if stq != 'fresh' or quote_age > max(ttlq or 20.0, 20.0):
        micro_bad = True
    if micro_bad:
        causes.append('micro')
        detail.append(f'micro {micro_age:.0f}s/시세 {quote_age:.0f}s')

    # 5) strategy row freshness: strategy가 봉인한 row 자체가 오래됨
    st, agev, ttl = _v612_age_item_state(items, 'paper_row')
    row_age = _v510_num(row.get('paper_row_age_sec'), default=agev)
    if st != 'fresh' or row_age > max(ttl or 45.0, 45.0):
        causes.append('strategy_row')
        detail.append(f'판단row {row_age:.0f}s')

    if not causes:
        stale = fm.get('stale_fields') if isinstance(fm.get('stale_fields'), list) else []
        if stale:
            causes.append('other')
            detail.extend(str(x) for x in stale[:3])
        elif fm.get('overall') not in (None, '', 'fresh_ok'):
            causes.append('unknown')
            detail.append(str(fm.get('overall')))

    return {'ticker': t, 'stage': _v510_stage(row), 'causes': causes or ['none'], 'detail': detail[:5], 'freshness_overall': fm.get('overall') if isinstance(fm, dict) else '-'}

ORDERFLOW_MICRO_URGENT_TARGETS = BASE_DIR / "clean_orderflow_micro_urgent_targets.json"

ORDERFLOW_MICRO_URGENT_RESULT = BASE_DIR / "clean_orderflow_micro_urgent_result.json"

ORDERFLOW_MICRO_URGENT_ACK = BASE_DIR / "clean_orderflow_micro_urgent_ack.json"

TARGET_ROUTER_STATE = BASE_DIR / "clean_s2_urgent_refresh_state.json"

TARGET_ROUTER_QUEUE = BASE_DIR / "clean_target_router_queue.json"

def _v613_of_rows_map() -> Dict[str, Dict[str, Any]]:
    return _v521_load_map_with_cache_age(ORDERFLOW, "orderflow")

def _v613_list_targets(obj: Any, key: str = 'targets') -> List[str]:
    try:
        vals = obj.get(key) if isinstance(obj, dict) else []
        if not isinstance(vals, list):
            return []
        return [ticker_norm(x) for x in vals if ticker_norm(x)]
    except Exception:
        return []

def _v613_reasoned_of_micro_state(targets: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    req_targets = [ticker_norm(x.get('ticker')) for x in targets if isinstance(x, dict) and ticker_norm(x.get('ticker'))]
    req_set = set(req_targets)
    ofmap = _v613_of_rows_map()
    micro_urgent = load_json(MICRO_URGENT, {}) or {}
    micro_targets = set(_v613_list_targets(micro_urgent))
    ws_obj = load_json(WS_TARGETS, {}) or {}
    ws_targets = set(_v613_list_targets(ws_obj))
    router_state = load_json(TARGET_ROUTER_STATE, {}) or {}
    router_targets = set(_v613_list_targets(router_state)) | set(_v613_list_targets(router_state, 'micro_targets'))
    router_queue = load_json(TARGET_ROUTER_QUEUE, {}) or {}
    queue_targets = set(_v613_list_targets(router_queue)) | set(_v613_list_targets(router_queue, 'urgent_targets'))
    # v614: target_router가 봉인한 ACK를 우선 읽는다. strategy가 요청 직후 같은 cycle의
    # clean_micro_urgent_targets를 직접 판정하면 router 반영 전 상태를 not_in_micro_urgent로 오판할 수 있다.
    router_ack = load_json(ORDERFLOW_MICRO_URGENT_ACK, {}) or {}
    ack_ts = _v510_num(router_ack.get('updated_ts'), default=0.0) if isinstance(router_ack, dict) else 0.0
    ack_recent = bool(ack_ts > 0 and nowv - ack_ts <= 35.0)
    ack_targets = set(_v613_list_targets(router_ack))
    ack_active_targets = set(_v613_list_targets(router_ack, 'active_targets'))
    ack_micro_targets = set(_v613_list_targets(router_ack, 'micro_targets'))
    ack_micro_urgent_targets = set(_v613_list_targets(router_ack, 'micro_urgent_targets'))
    ack_row_map: Dict[str, Dict[str, Any]] = {}
    if isinstance(router_ack, dict) and isinstance(router_ack.get('rows'), list):
        for ar in router_ack.get('rows') or []:
            if not isinstance(ar, dict):
                continue
            at = ticker_norm(ar.get('ticker'))
            if at:
                ack_row_map[at] = ar
    rows: List[Dict[str, Any]] = []
    reason_counter: Counter = Counter()
    fresh_count = micro_fresh_count = order_fresh_count = quote_fresh_count = 0
    selected_count = 0
    req_ts_map = {ticker_norm(x.get('ticker')): _v510_num(x.get('requested_ts'), x.get('updated_ts'), default=0.0) for x in targets if isinstance(x, dict) and ticker_norm(x.get('ticker'))}
    for t in req_targets:
        of = ofmap.get(t, {}) or {}
        req_ts = req_ts_map.get(t, 0.0)
        ack_row = ack_row_map.get(t, {})
        ack_row_ts = _v510_num(ack_row.get('ack_ts'), ack_row.get('updated_ts'), ack_ts, default=0.0) if isinstance(ack_row, dict) else ack_ts
        ack_req_ts = _v510_num(ack_row.get('request_ts'), default=0.0) if isinstance(ack_row, dict) else 0.0
        ack_has_ticker = bool(t in ack_targets or t in ack_active_targets or t in ack_micro_targets or t in ack_micro_urgent_targets or ack_row)
        # v615: ACK는 전체 최신 여부가 아니라 ticker별 요청을 반영했는지로 본다.
        # 이전에는 다른 ticker의 최신 ACK가 있으면 새 요청 ticker가 not_in_micro_urgent로 오판됐다.
        ack_covers_request = bool(ack_has_ticker and ack_row_ts > 0 and (req_ts <= 0 or ack_row_ts + 0.001 >= req_ts) and (ack_req_ts <= 0 or req_ts <= 0 or ack_req_ts + 0.001 >= req_ts))
        in_router = t in router_targets or t in queue_targets or (ack_covers_request and (t in ack_targets or t in ack_active_targets or bool(ack_row.get('in_active_targets') if isinstance(ack_row, dict) else False)))
        in_micro = t in micro_targets or (ack_covers_request and (t in ack_micro_targets or t in ack_micro_urgent_targets or bool(ack_row.get('in_micro_targets') if isinstance(ack_row, dict) else False) or bool(ack_row.get('in_micro_urgent_targets') if isinstance(ack_row, dict) else False)))
        in_ws = t in ws_targets or (ack_covers_request and (t in ack_active_targets or bool(ack_row.get('in_active_targets') if isinstance(ack_row, dict) else False)))
        ack_pending = bool((not ack_covers_request) or ((not in_router or not in_micro) and (not ack_recent)))
        order_age = _v510_num(of.get('orderflow_age_sec'), of.get('trade_age_sec'), of.get('micro_age_sec'), default=999999.0)
        micro_age = _v510_num(of.get('micro_age_sec'), of.get('trade_age_sec'), default=999999.0)
        quote_age = _v510_num(of.get('quote_age_sec'), of.get('price_age_sec'), default=999999.0)
        order_ok = bool(of.get('orderflow_fresh') or of.get('trade_fresh')) or order_age <= 20.0
        micro_ok = bool(of.get('micro_fresh')) or micro_age <= 20.0
        quote_ok = bool(of.get('quote_fresh') or of.get('ws_fresh')) or quote_age <= 20.0
        if in_router or in_micro or in_ws:
            selected_count += 1
        if order_ok: order_fresh_count += 1
        if micro_ok: micro_fresh_count += 1
        if quote_ok: quote_fresh_count += 1
        fresh_ok = bool(order_ok and micro_ok and quote_ok)
        if fresh_ok:
            fresh_count += 1
            reason = 'ok_fresh'
        elif ack_pending:
            reason = 'router_ack_pending'
        elif not in_router:
            reason = 'not_in_target_router'
        elif not in_micro:
            reason = 'not_in_micro_urgent'
        elif not in_ws:
            reason = 'not_in_ws_targets'
        elif not of:
            reason = 'orderflow_row_missing'
        elif not quote_ok:
            reason = 'quote_stale_or_missing'
        elif not micro_ok:
            reason = 'micro_stale_or_missing'
        elif not order_ok:
            reason = 'orderflow_stale_or_missing'
        else:
            reason = 'unknown_not_fresh'
        reason_counter[reason] += 1
        rows.append({
            'ticker': t,
            'in_router': in_router,
            'in_micro_urgent': in_micro,
            'in_ws_targets': in_ws,
            'orderflow_fresh': order_ok,
            'micro_fresh': micro_ok,
            'quote_fresh': quote_ok,
            'fresh_ok': fresh_ok,
            'orderflow_age_sec': None if order_age >= 999998 else round(order_age, 1),
            'micro_age_sec': None if micro_age >= 999998 else round(micro_age, 1),
            'quote_age_sec': None if quote_age >= 999998 else round(quote_age, 1),
            'reason': reason,
            'router_ack_recent': ack_recent,
            'router_ack_age_sec': None if ack_ts <= 0 else round(max(0.0, nowv - ack_ts), 1),
            'request_ts': req_ts,
            'router_ack_covers_request': ack_covers_request,
            'router_ack_row_age_sec': None if ack_row_ts <= 0 else round(max(0.0, nowv - ack_row_ts), 1),
        })
    obj = {
        'schema': 'orderflow_micro_urgent_result_v619_normal_keepalive_aware',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'requested_count': len(req_targets),
        'selected_count': selected_count,
        'micro_urgent_count': sum(1 for t in req_targets if t in micro_targets),
        'ws_target_count': sum(1 for t in req_targets if t in ws_targets),
        'orderflow_fresh_count': order_fresh_count,
        'micro_fresh_count': micro_fresh_count,
        'quote_fresh_count': quote_fresh_count,
        'fresh_ok_count': fresh_count,
        'miss_count': max(0, len(req_targets) - fresh_count),
        'reason_counts': dict(reason_counter.most_common()),
        'rows': rows[:80],
        'policy': 'v619: ticker별 ACK + micro urgent 우선 + normal keepalive 기준으로 판정한다. 조건/S등급/청산 변경 없음.',
    }
    save_json(ORDERFLOW_MICRO_URGENT_RESULT, obj)
    return obj

def _v613_build_orderflow_micro_urgent_targets(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    targets: List[Dict[str, Any]] = []
    seen = set()
    cause_counter: Counter = Counter()
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        if _v510_stage(row) not in ('S1', 'S2'):
            continue
        if not _v612_is_fresh_wait_row(row):
            continue
        d = _v612_fresh_cause_for_row(row, nowv)
        causes = set(str(x) for x in (d.get('causes') or []))
        if not ({'orderflow', 'micro'} & causes):
            continue
        t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
        if not t or t in seen:
            continue
        seen.add(t)
        for c in causes:
            cause_counter[c] += 1
        stage = _v510_stage(row)
        pri = 990.0 if stage == 'S1' else 960.0
        if 'micro' in causes: pri += 15.0
        if 'orderflow' in causes: pri += 15.0
        pri += min(30.0, _v510_num(row.get('score'), default=0.0))
        detail = d.get('detail') if isinstance(d.get('detail'), list) else []
        targets.append({
            'ticker': t,
            'stage': stage,
            'bucket': 'near_s_info_wait',
            'sub_bucket': 'core_S2_orderflow_micro_fresh_lock',
            'priority': round(pri, 3),
            'need': ['quote', 'ws', 'micro'],
            'need_orderflow': True,
            'need_micro': True,
            'source': 'strategy_worker_v613_orderflow_micro_urgent',
            'causes': sorted(list(causes & {'orderflow','micro'})),
            'detail': detail[:5],
            'final_trade_state': row.get('final_trade_state'),
            'final_decision': row.get('final_decision'),
            'requested_ts': nowv,
            'requested_text': now_text(nowv),
            'policy': 'S2 fresh_wait 원인이 체결/호가면 target_router/micro/WS 최우선 보강 후 strategy가 재판정한다.',
        })
    targets = sorted(targets, key=lambda x: _v510_num(x.get('priority'), default=0.0), reverse=True)
    obj = {
        'schema': 'orderflow_micro_urgent_targets_v613',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'request_count': len(targets),
        'targets': [x.get('ticker') for x in targets],
        'cause_counts': dict(cause_counter.most_common()),
        'rows': targets,
        'policy': 'No fixed ticker cap. All eligible S1/S2 fresh_wait rows caused by orderflow/micro remain in the queue; target_router/sidecar budgets handle server protection.',
    }
    save_json(ORDERFLOW_MICRO_URGENT_TARGETS, obj)
    result = _v613_reasoned_of_micro_state(targets, nowv)
    return targets, {
        'schema': 'strategy_orderflow_micro_urgent_summary_v613',
        'version': VERSION,
        'request_count': len(targets),
        'targets': obj.get('targets'),
        'cause_counts': obj.get('cause_counts'),
        'result': result,
        'policy': obj.get('policy'),
    }

def _v613_attach_s2_fresh_urgent_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out_reqs, base_summary = _v613_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    targets, summary = _v613_build_orderflow_micro_urgent_targets(rows, nowv)
    for req in targets:
        # target_router가 이미 쓰는 near_s_info_wait 본선을 사용한다.
        # 새 조건이 아니라 정보 보강 요청이다.
        out_reqs.append(dict(req))
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v613_orderflow_micro_urgent_summary'] = summary
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v619_orderflow_micro_normal_keepalive'
    return out_reqs, base_summary

_V635_1M_PREV_KEYS = ('price_1m_ago','price_60s_ago','one_min_ago_price','prev_1m_price','price_before_60s','price_1m_before')

_V635_1M_CHG_KEYS = ('change_1m_pct','change_1m','price_change_1m','scanner_change_1m_pct','price_chg_60s')

def _v635_first_present(src: Dict[str, Any], of: Dict[str, Any], keys: Tuple[str, ...]) -> Tuple[Any, str]:
    for owner, obj in (('feature/scanner', src), ('orderflow', of)):
        if isinstance(obj, dict):
            for k in keys:
                if obj.get(k) not in (None, '', [], {}):
                    return obj.get(k), f'{owner}.{k}'
    return None, ''

def _v635_build_price_1m_material(src: Dict[str, Any], of: Dict[str, Any], current_price: float) -> Dict[str, Any]:
    prev_raw, prev_source = _v635_first_present(src, of, _V635_1M_PREV_KEYS)
    chg_raw, chg_source = _v635_first_present(src, of, _V635_1M_CHG_KEYS)
    prev = _v510_num(prev_raw, default=0.0)
    chg_present = chg_raw not in (None, '', [], {})
    chg = _v510_num(chg_raw, default=0.0)
    ready = False
    source = 'missing'
    derived = False
    if current_price > 0 and prev > 0:
        ready = True
        source = prev_source or 'explicit_price_1m_ago'
        try:
            chg = ((current_price / prev) - 1.0) * 100.0
        except Exception:
            pass
    elif current_price > 0 and chg_present:
        ready = True
        source = chg_source or 'change_1m_pct'
        derived = True
        try:
            prev = current_price / (1.0 + chg / 100.0) if abs(1.0 + chg / 100.0) > 1e-9 else 0.0
        except Exception:
            prev = 0.0
    return {
        'schema': 'price_1m_material_v635',
        'ready': bool(ready),
        'current_price': round(current_price, 8) if current_price else None,
        'price_1m_ago': round(prev, 8) if prev else None,
        'change_1m_pct': round(chg, 4) if ready else None,
        'source': source,
        'derived_from_change_pct': bool(derived),
        'missing_reason': '' if ready else '1분 가격 없음',
        'policy': 'strategy_worker canonical row에 1분 가격 재료 상태만 봉인. 조건값 변경 없음.',
    }

def _v510_make_row__L9296(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:  # type: ignore[override]
    row = _v635_prev_make_row(src, of, stage, skey, label, lane, score, reasons, nowv, hard)
    try:
        cur = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
        mat = _v635_build_price_1m_material(src if isinstance(src, dict) else {}, of if isinstance(of, dict) else {}, cur)
        row['price_1m_material'] = mat
        row['price_1m_ready'] = bool(mat.get('ready'))
        row['price_1m_source'] = mat.get('source')
        if mat.get('price_1m_ago') is not None:
            row['price_1m_ago'] = mat.get('price_1m_ago')
        if mat.get('change_1m_pct') is not None:
            row['change_1m_pct'] = mat.get('change_1m_pct')
            row['price_chg_60s'] = mat.get('change_1m_pct') if _v510_num(row.get('price_chg_60s'), default=0.0) == 0.0 else row.get('price_chg_60s')
        if not mat.get('ready'):
            miss = row.get('missing_info') if isinstance(row.get('missing_info'), list) else []
            if '1분 가격 없음' not in [str(x) for x in miss]:
                row['missing_info'] = list(miss) + ['1분 가격 없음']
    except Exception as exc:
        try: log_error('v635_make_row_price_1m_material', exc)
        except Exception: pass
    return row

def _v584_build_canonical_metric_row__L9320(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    canon = _v635_prev_build_canonical_metric_row(row, nowv)
    try:
        mat = row.get('price_1m_material') if isinstance(row.get('price_1m_material'), dict) else {}
        metrics = canon.get('metrics') if isinstance(canon.get('metrics'), dict) else {}
        metrics['price_1m_ready'] = bool(mat.get('ready'))
        metrics['price_1m_ago'] = mat.get('price_1m_ago')
        metrics['change_1m_pct'] = mat.get('change_1m_pct') if mat.get('change_1m_pct') is not None else _v510_num(row.get('change_1m_pct'), row.get('change_1m'), default=0.0)
        metrics['price_1m_source'] = mat.get('source') or row.get('price_1m_source') or 'missing'
        canon['metrics'] = metrics
        canon['price_1m_material'] = mat or {'ready': False, 'missing_reason': '1분 가격 없음'}
        src = canon.get('source_snapshot') if isinstance(canon.get('source_snapshot'), dict) else {}
        src['price_1m_source'] = metrics.get('price_1m_source')
        canon['source_snapshot'] = src
        if not metrics.get('price_1m_ready'):
            br = canon.get('block_reasons') if isinstance(canon.get('block_reasons'), list) else []
            if '1분 가격 없음' not in [str(x) for x in br]:
                canon['block_reasons'] = list(br) + ['1분 가격 없음']
    except Exception as exc:
        try: log_error('v635_canonical_metric_price_1m_material', exc)
        except Exception: pass
    return canon

_V646_ROLE_KEYS = ('hard_block', 'execution_gate', 'recheck', 'strategy_structure', 'confirm_signal', 'display_only')

_V646_ROLE_KO = {
    'hard_block': '진짜 차단',
    'execution_gate': '진입 대기',
    'recheck': '재확인 필요',
    'strategy_structure': '구조/가점 재료',
    'confirm_signal': '확인 통과',
    'display_only': '참고 태그',
}

def _v646_text(v: Any) -> str:
    if isinstance(v, dict):
        return str(v.get('reason') or v.get('name') or v.get('value') or '').strip()
    return str(v or '').strip()

def _v646_list(v: Any, limit: int = 20) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        s = _v646_text(x)
        if s and s not in out:
            out.append(s)
        if len(out) >= limit:
            break
    return out

def _v646_has(txt: str, words: Tuple[str, ...]) -> bool:
    low = str(txt or '').lower()
    return any(str(w).lower() in low for w in words)

def _v646_strategy_family(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ('strategy_label', 'strategy', 'strategy_key', 'paper_strategy_key'):
        if row.get(k) not in (None, '', [], {}):
            vals.append(str(row.get(k)))
    vals += _v646_list(row.get('matched_strategy_labels'), 6)
    vals += _v646_list(row.get('matched_strategy_keys'), 6)
    s = ' '.join(vals)
    low = s.lower()
    if '저점' in s or '쓸림' in s or 'sweep' in low or 'vwap recovery' in low or 'vwap 회복' in s:
        return '저점 쓸림/VWAP 회복'
    if '돈흐름' in s or '재가속' in s or 'reaccel' in low or 'pullback' in low:
        return '돈흐름 재가속'
    if '돌파' in s or 'breakout' in low:
        return '돌파 초입'
    if '주도' in s or '유동보유' in s or 'leader' in low or 'momentum' in low or '추세' in s:
        return '주도흐름 유동보유'
    if 'hot-rank' in low or 'hot_rank' in low or '급등' in s:
        return 'hot-rank 발견/재확인'
    return str(row.get('strategy_label') or row.get('strategy') or row.get('strategy_key') or '기타')

_V646_STRATEGY_GUIDE = {
    '저점 쓸림/VWAP 회복': {
        'structure': ['저점유동성쓸림', '쓸림후빠른회복', 'VWAP 재회복', '저점 재이탈 없음'],
        'confirm': ['매수체결 회복', '1분 지속 회복', '저점 재이탈 없음'],
        'danger': ['저점 재이탈', '강한 매도압력', '스프레드 과다'],
    },
    '돈흐름 재가속': {
        'structure': ['눌림 후 돈흐름 재유입', 'VWAP/EMA 방어', '거래대금 재유입'],
        'confirm': ['체결 회복', '1분 지속 회복', '상대강도 유지'],
        'danger': ['윗꼬리/매도압력', '스프레드 과다', '반복손실 유사'],
    },
    '돌파 초입': {
        'structure': ['저항 돌파', '거래량 확장', '돌파선 유지', '재테스트 방어'],
        'confirm': ['돌파 유지', '체결 동반', '윗꼬리 제한'],
        'danger': ['가짜돌파', '윗꼬리', '늦은추격', '스프레드 과다'],
    },
    '주도흐름 유동보유': {
        'structure': ['15/30분 주도성', '상대강도', 'VWAP/EMA 유지', '얕은 눌림'],
        'confirm': ['추세 유지', '매도압력 약화', '돈흐름 유지'],
        'danger': ['고점권 되돌림', '강한 매도압력', '심한 stale'],
    },
    'hot-rank 발견/재확인': {
        'structure': ['급등 발견', '거래량 확장', '공통상승조건'],
        'confirm': ['짧은 체결 확인', '스프레드 회복', '윗꼬리 제한'],
        'danger': ['늦은추격', '스프레드/미끄러짐 과다', '체결 약함'],
    },
}

def _v646_add_unique(d: Dict[str, List[str]], key: str, val: Any, limit: int = 12) -> None:
    s = _v646_text(val)
    if not s:
        return
    arr = d.setdefault(key, [])
    if s not in arr and len(arr) < limit:
        arr.append(s)

def _v646_classify_reason(txt: str, family: str, source: str = '') -> str:
    t = str(txt or '').strip()
    if not t:
        return 'display_only'
    # 실행 타이밍은 위험 차단이 아니라 entry gate다.
    if _v646_has(t, ('방아쇠', 'trigger')) and _v646_has(t, ('미도달', 'gap', '도달 전')):
        return 'execution_gate'
    if _v646_has(t, ('진입타이밍 정보없음', 'entry timing')):
        return 'execution_gate'
    # 정보 자체가 없거나 비정상인 경우만 hard.
    if _v646_has(t, ('1분 가격 없음', '재료없음', '재료 없음', '거래정지', '비정상 데이터', '시세정보 없음')):
        return 'hard_block'
    # 실제 실행 위험.
    if _v646_has(t, ('스프레드 과다', '미끄러짐 과다', '급등형 스프레드', '급등형 미끄러짐')) and '회복 대기' not in t:
        return 'hard_block'
    if _v646_has(t, ('매도벽/매도체결압력', '강한 매도압력', '급등형 매도압력/윗꼬리 위험', '늦은추격 위험', '가짜돌파')):
        return 'hard_block'
    if _v646_has(t, ('stale 심함', '공식캔들 stale')):
        return 'hard_block'
    # 부족/근접/대기류는 전략별 확인 신호 부족이므로 재확인이다.
    if _v646_has(t, ('회복 대기', '기준근접', '가격반응 약함', '가격반응 +0.00%', '가격반응', '1분 매수지속 부족', '1분지속', '매수체결', '짧은 매수세 부족', '거래대금부족', 'runner 가격힘 부족', '급등초입 신호 부족')):
        return 'recheck'
    # 구조/알파 재료.
    if _v646_has(t, ('VWAP', 'EMA', '돈흐름', '거래량확장', '저항돌파', '저점유동성쓸림', '쓸림후빠른회복', '공통상승조건', '주도흐름', '상대강도', '눌림', '재돌파')):
        return 'strategy_structure'
    # 발견/설명용.
    if _v646_has(t, ('hot-rank', 'hot_rank', '발견신호', '구조선 근거 재확인')):
        return 'display_only'
    return 'display_only'

def _v646_build_condition_roles(row: Dict[str, Any]) -> Dict[str, Any]:
    family = _v646_strategy_family(row)
    roles: Dict[str, List[str]] = {k: [] for k in _V646_ROLE_KEYS}
    # 이미 v553가 분리한 원천을 우선 사용한다. 없으면 legacy reason으로 보강한다.
    for x in _v646_list(row.get('entry_structure_tags') or row.get('structure_tags'), 12):
        _v646_add_unique(roles, 'strategy_structure', x)
    for x in _v646_list(row.get('confirm_signals'), 12):
        _v646_add_unique(roles, 'confirm_signal', x)
    for x in _v646_list(row.get('execution_risk_tags') or row.get('risk_tags'), 12):
        _v646_add_unique(roles, _v646_classify_reason(x, family, 'risk'), x)
    for x in _v646_list(row.get('freshness_flags') or row.get('stale_reasons'), 10):
        # 정보 오래됨은 기본적으로 재확인. 심한 stale만 classifier가 hard로 올린다.
        role = _v646_classify_reason(x, family, 'freshness')
        if role == 'display_only':
            role = 'recheck'
        _v646_add_unique(roles, role, x)
    for x in _v646_list(row.get('recheck_reasons') or row.get('s2_recheck_reasons'), 12):
        _v646_add_unique(roles, 'recheck', x)
    for x in _v646_list(row.get('block_reasons') or row.get('s1_missing_conditions'), 12):
        _v646_add_unique(roles, _v646_classify_reason(x, family, 'block'), x)
    # 방아쇠는 별도 실행대기로 봉인한다.
    try:
        cur = _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
        trg = _v510_num(row.get('trigger_price'), default=0.0)
        reached = bool(row.get('trigger_reached'))
        if cur > 0 and trg > 0 and cur < trg and not reached:
            gap = ((cur / trg) - 1.0) * 100.0
            _v646_add_unique(roles, 'execution_gate', f'방아쇠 미도달 {gap:+.2f}%')
    except Exception:
        pass
    # legacy reason이 남아 있으면 보조로 분류한다. 단, 기존 분리 필드보다 우선하지 않는다.
    legacy = _v646_list(row.get('s_stage_reasons') or row.get('reason'), 14)
    for x in legacy:
        clean = str(x).replace('구조:', '').strip()
        _v646_add_unique(roles, _v646_classify_reason(clean, family, 'legacy'), clean)
    # hot-rank는 발견/참고 태그로만 둔다.
    hay = ' '.join([str(row.get(k) or '') for k in ('strategy_label','strategy','strategy_key','paper_strategy_key')] + _v646_list(row.get('matched_strategy_labels'), 6) + _v646_list(row.get('matched_strategy_keys'), 6)).lower()
    if 'hot-rank' in hay or 'hot_rank' in hay or '급등' in hay:
        _v646_add_unique(roles, 'display_only', 'hot-rank 발견신호')
    # 각 역할 내부 중복 제거/제한
    clean_roles: Dict[str, List[str]] = {}
    for k in _V646_ROLE_KEYS:
        seen=set(); arr=[]
        for x in roles.get(k, []):
            s=_v646_text(x)
            if s and s not in seen:
                seen.add(s); arr.append(s)
            if len(arr) >= 10:
                break
        clean_roles[k]=arr
    guide = _V646_STRATEGY_GUIDE.get(family, {})
    return {
        'schema': 'strategy_condition_role_spine_v646',
        'strategy_family': family,
        'roles': clean_roles,
        'role_labels': _V646_ROLE_KO,
        'guide': guide,
        'policy': '조건 수치/S등급/청산 변경 없음. strategy_worker가 조건 역할을 row에 직접 봉인하고 main_bot은 표시만 한다.',
    }

def _v553_apply_reason_taxonomy__L9533(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = _v646_prev_apply_reason_taxonomy(row)
    try:
        cr = _v646_build_condition_roles(row)
        row['condition_role_schema'] = cr.get('schema')
        row['condition_roles'] = cr.get('roles')
        row['condition_role_labels'] = cr.get('role_labels')
        row['strategy_condition_family'] = cr.get('strategy_family')
        row['strategy_condition_guide'] = cr.get('guide')
        row['condition_role_policy'] = cr.get('policy')
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        for k in ('condition_role_schema','condition_roles','condition_role_labels','strategy_condition_family','strategy_condition_guide','condition_role_policy'):
            ctx[k] = row.get(k)
        row['entry_context'] = ctx
    except Exception as exc:
        try: log_error('v646_apply_condition_role_spine', exc)
        except Exception: pass
    return row

V656_STRATEGY_BUILD = 'strategy_worker_v0.156_v663_trigger_source_owner'

def _v656_clamp(v: float, lo: float = 0.0, hi: float = 100.0) -> float:
    try:
        return max(lo, min(hi, float(v)))
    except Exception:
        return lo

def _v656_list(v: Any, limit: int = 30) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        if isinstance(x, dict):
            s = str(x.get('reason') or x.get('name') or x.get('value') or x.get('tag') or '').strip()
        else:
            s = str(x or '').strip()
        if s and s not in out:
            out.append(s)
        if len(out) >= limit:
            break
    return out

def _v656_role_items(row: Dict[str, Any], role: str) -> List[str]:
    roles = row.get('condition_roles') if isinstance(row.get('condition_roles'), dict) else {}
    return _v656_list(roles.get(role), 20)

def _v658_age_value(row: Dict[str, Any], keys: Tuple[str, ...]) -> float:
    for k in keys:
        v = row.get(k)
        n = _v510_num(v, default=-1.0)
        if n >= 0:
            return n
    return -1.0

def _v658_text_stale_sources(stale_texts: List[str]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    patterns = [
        ('candle', ('candle','캔들','official_candle','공식캔들','구조재료')),
        ('feature', ('feature','vwap','ema','가격/VWAP','가격반응')),
        ('orderflow', ('orderflow','체결','매수체결','매도압력')),
        ('micro', ('micro','호가','스프레드','미끄러짐')),
        ('ws', ('ws','websocket','시세')),
        ('quote', ('quote','호가시세')),
        ('price', ('price','가격')),
        ('strategy', ('strategy','판단row','봉인')),
    ]
    for raw in stale_texts or []:
        txt = str(raw or '').strip()
        if not txt:
            continue
        low = txt.lower()
        source = 'unknown'
        for name, words in patterns:
            if any(str(w).lower() in low for w in words):
                source = name
                break
        age = -1.0
        m = re.search(r'([0-9]+(?:\.[0-9]+)?)\s*s', txt)
        if m:
            try:
                age = float(m.group(1))
            except Exception:
                age = -1.0
        out.append({'source': source, 'age_sec': round(age, 3) if age >= 0 else None, 'reason': txt, 'from': 'text'})
    return out

def _v658_stale_origin(row: Dict[str, Any]) -> Dict[str, Any]:
    """strategy row 안에서 정보 오래됨의 주인을 봉인한다.

    main_bot 출력부가 임의로 stale을 재계산하지 않도록, candle/feature/orderflow/micro/ws 등
    생산 공장별 원인을 여기서 확정한다. 임계값은 매수조건이 아니라 원인 표시/urgent 배차용이다.
    """
    specs = [
        ('candle', ('candle_age_sec','official_candle_age','official_candle_age_sec','candle_source_age_sec'), 180.0),
        ('feature', ('feature_age_sec','feature_source_age_sec','vwap_age_sec','ema_age_sec'), 45.0),
        ('orderflow', ('orderflow_age_sec','orderflow_source_age_sec','trade_age_sec'), 35.0),
        ('micro', ('micro_age_sec','micro_source_age_sec','orderbook_age_sec'), 35.0),
        ('ws', ('ws_age_sec','websocket_age_sec','price_ws_age_sec'), 35.0),
        ('quote', ('quote_age_sec','quote_source_age_sec'), 35.0),
        ('price', ('price_age_sec','source_age_sec','current_price_age_sec'), 45.0),
        ('strategy', ('strategy_age_sec','row_age_sec','sealed_age_sec'), 45.0),
    ]
    items: List[Dict[str, Any]] = []
    for source, keys, ttl in specs:
        age = _v658_age_value(row, keys)
        if age >= 0 and age > ttl:
            items.append({'source': source, 'age_sec': round(age, 3), 'ttl_sec': ttl, 'reason': f'{source} {age:.1f}s>{ttl:.0f}s', 'from': 'numeric'})
    text_items = _v658_text_stale_sources(_v656_list(row.get('stale_reasons') or row.get('freshness_flags'), 20))
    seen = {(x.get('source'), str(x.get('reason'))) for x in items}
    for it in text_items:
        key = (it.get('source'), str(it.get('reason')))
        if key not in seen:
            items.append(it); seen.add(key)
    cnt = Counter(str(x.get('source') or 'unknown') for x in items)
    top = [f'{k} {v}' for k, v in cnt.most_common(8)]
    return {
        'schema': 'stale_origin_v658',
        'has_stale': bool(items),
        'items': items[:12],
        'source_counts': dict(cnt),
        'top_sources': top,
        'policy': '정보오래됨 원인은 strategy_worker canonical row에서 생산 공장별로 봉인하고 main은 표시만 한다.',
    }

def _v658_quality_hold_reasons(row: Dict[str, Any], q: float, structure_score: float, flow_score: float, confirmation_score: float, risk_score: float, freshness_score: float, stale_origin: Dict[str, Any]) -> List[str]:
    reasons: List[str] = []
    react = _v655_metric(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s')
    buy = _v655_metric(row, 'buy_ratio')
    sustain = _v655_metric(row, 'buy_sustain_1m', 'buy_sustain_20s', 'buy_ratio_20s')
    if structure_score < 55:
        reasons.append(f'구조점수 {structure_score:.0f}<55')
    if flow_score < 55:
        reasons.append(f'돈흐름 {flow_score:.0f}<55')
    if confirmation_score < 42:
        reasons.append(f'확인신호 {confirmation_score:.0f}<42')
    elif confirmation_score < 58:
        reasons.append(f'확인신호 근접 {confirmation_score:.0f}')
    if react < 0.35:
        reasons.append(f'가격반응 {react:+.2f}%<+0.35%')
    if buy < 0.55:
        reasons.append(f'매수체결 {buy:.2f}<0.55')
    if sustain < 0.70:
        reasons.append(f'1분지속 {sustain:.2f}<0.70')
    if risk_score > 42:
        reasons.append(f'실행위험 {risk_score:.0f}>42')
    if freshness_score < 60:
        stale_top = stale_origin.get('top_sources') if isinstance(stale_origin, dict) else []
        reasons.append('신선도 부족' + (': ' + '/'.join(str(x) for x in stale_top[:3]) if stale_top else ''))
    trig = row.get('trigger_price') or row.get('entry_trigger_price') or row.get('trigger')
    if trig in (None, '', 0, 0.0):
        reasons.append('방아쇠 정보 없음')
    hard = _v656_role_items(row, 'hard_block')
    if hard:
        reasons.append('하드차단:' + '/'.join(hard[:2]))
    return _v510_uniq(reasons, 10)

def _v656_blob(row: Dict[str, Any]) -> str:
    vals: List[str] = []
    for k in ('strategy_key','strategy_label','strategy','strategy_condition_family','structure_tags','entry_structure_tags','matched_strategy_labels','matched_strategy_keys','block_reasons','risk_tags','s2_recheck_reasons','condition_roles'):
        v = row.get(k)
        if isinstance(v, dict):
            for vv in v.values():
                vals += _v656_list(vv, 20)
        else:
            vals += _v656_list(v, 20)
    return ' '.join(vals)

def _v656_coin_quality(row: Dict[str, Any]) -> Dict[str, Any]:
    blob = _v656_blob(row)
    low = blob.lower()
    react = _v655_metric(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s')
    ch30 = _v655_metric(row, 'price_chg_30s')
    ch60 = _v655_metric(row, 'price_chg_60s', 'change_1m_pct')
    ch3 = _v655_metric(row, 'change_3m_pct', 'change_3m', 'price_change_3m')
    ch5 = _v655_metric(row, 'change_5m_pct', 'change_5m', 'price_change_5m')
    ch15 = _v655_metric(row, 'change_15m_pct', 'change_15m', 'price_change_15m')
    buy = _v655_metric(row, 'buy_ratio')
    sustain = _v655_metric(row, 'buy_sustain_1m', 'buy_sustain_20s', 'buy_ratio_20s')
    buy10 = _v655_metric(row, 'buy_ratio_10s', 'buy_sustain_10s')
    buy20 = _v655_metric(row, 'buy_ratio_20s', 'buy_sustain_20s')
    spread = _v655_metric(row, 'spread_pct', default=99.0)
    slip = _v655_metric(row, 'slippage_pct', 'spread_pct', default=spread)
    score_base = _v655_metric(row, 'score')
    stale = _v656_list(row.get('stale_reasons') or row.get('freshness_flags'), 20)
    stale_origin_v658 = _v658_stale_origin(row)
    hard = _v656_role_items(row, 'hard_block')
    recheck = _v656_role_items(row, 'recheck')
    struct_items = _v656_list(row.get('structure_tags'), 20) + _v656_role_items(row, 'strategy_structure')
    confirm_items = _v656_role_items(row, 'confirm_signal')
    risk_items = _v656_list(row.get('risk_tags') or row.get('structure_risk_tags'), 20) + _v656_role_items(row, 'execution_gate')

    structure_words = ('VWAP','EMA','돈흐름','주도흐름','상대강도','눌림','재돌파','저점유동성쓸림','쓸림','박스','지지','저항','돌파','공통상승조건')
    structure_hits = sum(1 for w in structure_words if w in blob)
    structure_score = 18.0 + min(48.0, structure_hits * 8.0) + min(18.0, len(set(struct_items)) * 3.0)
    if 'hot-rank' in low or '급등' in blob:
        structure_score += 4.0  # 발견 신호일 뿐, 큰 가점은 주지 않는다.
    structure_score = _v656_clamp(structure_score)

    flow_score = 20.0
    flow_score += _v656_clamp(ch3 * 12.0, 0, 24)
    flow_score += _v656_clamp(ch5 * 8.0, 0, 18)
    flow_score += _v656_clamp(ch15 * 3.0, 0, 14)
    if any(w in blob for w in ('돈흐름','주도흐름','상대강도','거래대금','거래량')):
        flow_score += 14.0
    flow_score += _v656_clamp(score_base / 8.0, 0, 12)
    flow_score = _v656_clamp(flow_score)

    confirmation_score = 15.0
    confirmation_score += _v656_clamp(react * 55.0, 0, 30)
    confirmation_score += _v656_clamp(ch30 * 35.0, 0, 12)
    confirmation_score += _v656_clamp(ch60 * 28.0, 0, 12)
    confirmation_score += _v656_clamp((buy - 0.35) * 70.0, 0, 20)
    confirmation_score += _v656_clamp((sustain - 0.35) * 70.0, 0, 18)
    confirmation_score += _v656_clamp((max(buy10, buy20) - 0.35) * 35.0, 0, 8)
    confirmation_score += min(8.0, len(confirm_items) * 3.0)
    confirmation_score = _v656_clamp(confirmation_score)

    risk_score = 0.0
    risk_score += _v656_clamp((spread - 0.12) * 80.0, 0, 38)
    risk_score += _v656_clamp((slip - 0.12) * 80.0, 0, 38)
    risk_text = ('매도벽','매도체결압력','강한 매도압력','늦은추격','가짜돌파','윗꼬리','스프레드부담','미끄러짐부담')
    risk_score += min(36.0, sum(1 for w in risk_text if w in blob) * 7.0)
    if ('hot-rank' in low or '급등' in blob) and (spread > 0.65 or slip > 0.65 or buy < 0.45 or sustain < 0.45):
        risk_score += 18.0
    if hard:
        risk_score += min(24.0, len(hard) * 6.0)
    execution_risk_score = _v656_clamp(risk_score)
    execution_score = _v656_clamp(100.0 - execution_risk_score)

    freshness_score = 100.0
    freshness_score -= min(70.0, len(stale) * 16.0)
    if stale_origin_v658.get('items'):
        freshness_score -= min(35.0, len(stale_origin_v658.get('items') or []) * 6.0)
    # numeric age fields, when present, reduce the freshness score without creating a fallback value.
    for k in ('source_age_sec','orderflow_age_sec','micro_age_sec','quote_age_sec','feature_age_sec','candle_age_sec','official_candle_age'):
        age = _v510_num(row.get(k), default=-1.0)
        if age > 30:
            freshness_score -= min(35.0, (age - 30.0) / 6.0)
    freshness_score = _v656_clamp(freshness_score)

    quality = (structure_score * 0.24) + (flow_score * 0.22) + (confirmation_score * 0.30) + (execution_score * 0.18) + (freshness_score * 0.06)
    quality = _v656_clamp(quality)
    hot_like = bool('hot-rank' in low or '급등' in blob)
    reasons: List[str] = []
    if structure_score >= 62: reasons.append('구조 양호')
    if flow_score >= 62: reasons.append('돈흐름 양호')
    if confirmation_score >= 58: reasons.append('확인신호 양호')
    elif confirmation_score >= 44: reasons.append('확인신호 근접')
    if execution_risk_score <= 35: reasons.append('실행위험 낮음')
    elif execution_risk_score >= 65: reasons.append('실행위험 높음')
    if freshness_score < 60: reasons.append('신선도 재수집 필요')

    lane = 'observe'
    if execution_risk_score >= 70 or (hot_like and execution_risk_score >= 55):
        lane = 'late_chase_or_execution_risk'
    elif freshness_score < 60 and quality >= 52 and execution_risk_score <= 55:
        lane = 'quality_info_urgent'
    elif quality >= 66 and execution_risk_score <= 42 and freshness_score >= 45 and ((structure_score >= 55 and confirmation_score >= 42) or (quality >= 74 and execution_risk_score <= 25 and confirmation_score >= 35)):
        lane = 'quality_s2_recheck'
    elif quality >= 58 and execution_risk_score <= 55:
        lane = 'quality_watch'
    elif quality < 45:
        lane = 'weak_coin_observe'

    quality_s3_hold_reasons_v658 = _v658_quality_hold_reasons(row, quality, structure_score, flow_score, confirmation_score, execution_risk_score, freshness_score, stale_origin_v658)

    return {
        'schema': 'coin_quality_spine_v658',
        'build': V656_STRATEGY_BUILD,
        'coin_quality_score': round(quality, 2),
        'candidate_quality_score': round(quality, 2),
        'structure_score': round(structure_score, 2),
        'flow_score': round(flow_score, 2),
        'confirmation_score': round(confirmation_score, 2),
        'execution_risk_score': round(execution_risk_score, 2),
        'execution_score': round(execution_score, 2),
        'freshness_score': round(freshness_score, 2),
        'quality_lane': lane,
        'quality_lane_reasons': _v510_uniq(reasons or ['관찰'], 8),
        'stale_origin_v658': stale_origin_v658,
        'stale_origin_top_v658': stale_origin_v658.get('top_sources') if isinstance(stale_origin_v658, dict) else [],
        'quality_s3_hold_reasons_v658': quality_s3_hold_reasons_v658,
        'quality_hold_reason_v658': ' / '.join(quality_s3_hold_reasons_v658[:4]) if quality_s3_hold_reasons_v658 else '-',
        'strategy_key': row.get('strategy_key'),
        'strategy_label': row.get('strategy_label') or row.get('strategy') or row.get('strategy_name'),
        'structure_tags': _v510_uniq(struct_items or _v656_list(row.get('structure_tags'), 12), 12),
        'policy': '전략 추가 없음. 전략명은 구조/복기 태그로 유지하고 코인 자체 품질·실행위험·신선도를 canonical row에 봉인한다.',
    }

def _v656_attach_coin_quality__L9844(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    counts: Dict[str, int] = {}
    promoted = 0
    score_sum = 0.0
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        q = _v656_coin_quality(rr)
        lane = str(q.get('quality_lane') or 'observe')
        counts[lane] = counts.get(lane, 0) + 1
        score_sum += _v510_num(q.get('coin_quality_score'), default=0.0)
        rr['coin_quality_spine'] = q
        for k in ('coin_quality_score','candidate_quality_score','structure_score','flow_score','confirmation_score','execution_risk_score','execution_score','freshness_score','quality_lane','quality_lane_reasons','stale_origin_v658','stale_origin_top_v658','quality_s3_hold_reasons_v658','quality_hold_reason_v658'):
            rr[k] = q.get(k)
        rr['quality_structure_tags'] = q.get('structure_tags') or rr.get('structure_tags') or []
        rr['quality_spine_build'] = V656_STRATEGY_BUILD
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['coin_quality_spine'] = q
        rr['entry_context'] = ctx
        if _v510_stage(rr) == 'S3' and lane == 'quality_s2_recheck':
            rr['s_stage'] = rr['candidate_stage'] = rr['candidate_grade'] = rr['stage'] = rr['grade'] = 'S2'
            rr['recheck_state'] = 'S2 재확인'
            prev = rr.get('s2_recheck_reasons') if isinstance(rr.get('s2_recheck_reasons'), list) else []
            rr['s2_recheck_reasons'] = _v510_uniq(list(prev) + ['v656:코인품질 양호 S2 재확인'] + _v656_list(q.get('quality_lane_reasons'), 6), 10)
            br = rr.get('block_reasons') if isinstance(rr.get('block_reasons'), list) else []
            rr['block_reasons'] = _v510_uniq(list(br) + ['재확인: 코인품질 양호·실행위험 낮음'], 12)
            rr['open_eligible'] = False; rr['paper_bot_open'] = False; rr['trade_ready'] = False
            promoted += 1
        out.append(rr)
    avg = round(score_sum / len(out), 2) if out else 0.0
    return out, {
        'schema': 'coin_quality_summary_v658',
        'version': VERSION,
        'build': V656_STRATEGY_BUILD,
        'updated_ts': nowv,
        'row_count': len(out),
        'avg_coin_quality_score': avg,
        'lane_counts': counts,
        's3_to_s2_quality_promoted': promoted,
        'policy': '전략 추가/조건 완화가 아니라 코인 자체 품질 spine 봉인 및 저위험 품질후보 S2 재확인 승격.',
    }

def _v655_apply_strategy_recheck_lanes__L9892(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    rows2, base = _v656_prev_apply_strategy_recheck_lanes(rows, nowv)
    rows3, qsum = _v656_attach_coin_quality(rows2, nowv)
    if isinstance(base, dict):
        base = dict(base)
    else:
        base = {}
    base['v656_coin_quality_summary'] = qsum
    base['schema'] = 'strategy_recheck_lane_summary_v656_coin_quality_spine'
    return rows3, base

def _v574_attach_s2_fresh_urgent_requests__L9906(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v656_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    seen = {(ticker_norm(r.get('ticker')), str(r.get('bucket') or '')) for r in out_reqs if isinstance(r, dict)}
    added: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker'))
        if not t:
            continue
        lane = str(r.get('quality_lane') or '')
        if lane not in ('quality_s2_recheck', 'quality_info_urgent'):
            continue
        bucket = 'coin_quality_s2_recheck' if lane == 'quality_s2_recheck' else 'coin_quality_info_urgent'
        key = (t, bucket)
        if key in seen:
            continue
        seen.add(key)
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        fresh = _v510_num(r.get('freshness_score'), default=100.0)
        pri = 820.0 + min(80.0, q) - min(40.0, risk / 2.0)
        if lane == 'quality_s2_recheck':
            pri += 80.0
        if fresh < 60:
            pri += 35.0
        req = {
            'ticker': t,
            'bucket': bucket,
            'sub_bucket': lane,
            'priority': round(pri, 3),
            'need': ['quote', 'ws', 'micro', 'candle'],
            'need_orderflow': True,
            'need_micro': True,
            'need_candle': True,
            'source': 'strategy_worker_v658_stale_origin_hold_reason',
            'stage': _v510_stage(r),
            'quality_lane': lane,
            'coin_quality_score': q,
            'execution_risk_score': risk,
            'freshness_score': fresh,
            'reasons': _v656_list(r.get('quality_lane_reasons'), 6),
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'policy': '코인품질 양호/S2재확인/정보오래됨 후보를 target_router 우선수집으로 보낸다. 후보 수 고정 제한 아님.',
        }
        out_reqs.append(req)
        added.append(req)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v656_coin_quality_urgent_summary'] = {
        'schema': 'coin_quality_urgent_requests_v658',
        'version': VERSION,
        'request_count': len(added),
        'targets': [x.get('ticker') for x in added[:50]],
        'lane_counts': dict(Counter(str(x.get('quality_lane') or '-') for x in added)),
        'policy': 'strategy_worker가 봉인한 coin_quality_spine 중 우선 보강 대상만 priority_requests에 추가.',
    }
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v656_coin_quality_spine'
    return out_reqs, base_summary

def _v659_age(row: Dict[str, Any], *keys: str, default: float = -1.0) -> float:
    for k in keys:
        v = _v510_num(row.get(k), default=None)
        if v is not None:
            return float(v)
    return default

def _v656_attach_coin_quality__L10145(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    rows2, qsum = _v659_prev_v656_attach_coin_quality(rows, nowv)
    trig_counter: Counter = Counter()
    risk_counter: Counter = Counter()
    candle_stale_highq = 0
    for rr in rows2 or []:
        if not isinstance(rr, dict):
            continue
        audit = _v659_trigger_audit(rr)
        rr['trigger_structure_audit_v659'] = audit
        ctx = rr.get('entry_context') if isinstance(rr.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['trigger_structure_audit_v659'] = audit
        rr['entry_context'] = ctx
        canon = rr.get('canonical_metric_row') if isinstance(rr.get('canonical_metric_row'), dict) else {}
        canon = dict(canon)
        canon['trigger_structure_audit_v659'] = audit
        rr['canonical_metric_row'] = canon
        trig_counter[str(audit.get('status') or '-')] += 1
        for flag in audit.get('risk_flags') or []:
            risk_counter[str(flag)] += 1
        q = _v510_num(rr.get('coin_quality_score'), default=0.0)
        risk = _v510_num(rr.get('execution_risk_score'), default=99.0)
        if q >= 62 and risk <= 55 and ('candle_stale' in (audit.get('risk_flags') or [])):
            candle_stale_highq += 1
    if isinstance(qsum, dict):
        qsum = dict(qsum)
    else:
        qsum = {}
    qsum['v659_trigger_audit_summary'] = {
        'schema': 'trigger_audit_summary_v659',
        'version': VERSION,
        'trigger_status_counts': dict(trig_counter),
        'trigger_risk_top': dict(risk_counter.most_common(8)),
        'high_quality_candle_stale_count': candle_stale_highq,
        'policy': 'trigger 감사/표시만 추가. S1 조건 완화 없음.',
    }
    return rows2, qsum

def _v574_attach_s2_fresh_urgent_requests__L10187(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v659_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    seen = {(ticker_norm(r.get('ticker')), str(r.get('bucket') or '')) for r in out_reqs if isinstance(r, dict)}
    added: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker'))
        if not t:
            continue
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        audit = r.get('trigger_structure_audit_v659') if isinstance(r.get('trigger_structure_audit_v659'), dict) else _v659_trigger_audit(r)
        flags = [str(x) for x in (audit.get('risk_flags') or [])]
        lane = str(r.get('quality_lane') or '')
        stage = _v510_stage(r)
        trigger_wait = str(audit.get('status') or '') == 'trigger_wait'
        needs_candle = 'candle_stale' in flags or lane == 'quality_info_urgent' or (trigger_wait and q >= 58)
        worth = bool((q >= 62 and risk <= 55) or (stage == 'S2' and q >= 55) or lane == 'quality_s2_recheck')
        if not (needs_candle and worth):
            continue
        bucket = 'coin_quality_candle_trigger_urgent_v659'
        key = (t, bucket)
        if key in seen:
            continue
        seen.add(key)
        pri = 1180.0 + min(120.0, q) - min(45.0, risk / 2.0)
        if stage == 'S2':
            pri += 90.0
        if trigger_wait:
            pri += 45.0
        req = {
            'ticker': t,
            'bucket': bucket,
            'sub_bucket': 'candle_stale_trigger_wait' if trigger_wait else 'candle_stale_quality',
            'priority': round(pri, 3),
            'need': ['candle'],
            'need_candle': True,
            'required_age_sec': 35,
            'target_age': 35,
            'source': 'strategy_worker_v659_candle_trigger_priority',
            'stage': stage,
            'quality_lane': lane,
            'coin_quality_score': q,
            'execution_risk_score': risk,
            'trigger_status': audit.get('status'),
            'trigger_gap_pct': audit.get('trigger_gap_pct'),
            'trigger_source': audit.get('source'),
            'trigger_risk_flags': flags[:8],
            'reasons': _v656_list(r.get('quality_s3_hold_reasons_v658'), 4) + _v656_list(r.get('quality_lane_reasons'), 4),
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'policy': '고품질/S2/trigger_wait 후보 중 candle stale 후보만 candle 우선보강. 후보 수 고정제한 아님.',
        }
        out_reqs.append(req)
        added.append(req)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v659_candle_trigger_urgent_summary'] = {
        'schema': 'candle_trigger_urgent_requests_v659',
        'version': VERSION,
        'added_count': len(added),
        'targets': [x.get('ticker') for x in added[:20]],
        'trigger_status_counts': dict(Counter(str(x.get('trigger_status') or '-') for x in added)),
        'policy': 'strategy_worker가 candle_worker로 넘길 고품질/방아쇠대기 candle urgent 요청을 만든다.',
    }
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v659_candle_trigger'
    return out_reqs, base_summary

V663_STRATEGY_BUILD = "strategy_worker_v0.157_v664_trigger_wait_lifecycle"

def _v663_trigger_source_name(row: Dict[str, Any], levels: Dict[str, Any], plan: Dict[str, Any]) -> str:
    fam = str(levels.get('strategy_family') or _v554_strategy_family(row) or 'common')
    plan_txt = ' '.join(str(x or '') for x in (levels.get('plan_type'), levels.get('trigger_reason'), plan.get('plan_type'), plan.get('trigger_reason')))
    if 'VWAP' in plan_txt or fam == 'sweep_vwap':
        return 'vwap_recovery_line'
    if 'EMA' in plan_txt or '방어' in plan_txt or fam in ('leader_flow','leader_momentum'):
        return 'vwap_ema_defense_rebreak'
    if '박스' in plan_txt:
        return 'box_break_line'
    if '저항' in plan_txt or '돌파' in plan_txt or fam in ('breakout','surge_rebreak','hot_rank'):
        return 'resistance_break_line'
    if '눌림' in plan_txt or '재가속' in plan_txt or fam == 'money_reaccel':
        return 'pullback_reaccel_line'
    if _v510_num(levels.get('trigger_price'), default=0.0) > 0:
        return 'structure_levels_generic'
    if _v510_num(plan.get('trigger_price'), default=0.0) > 0:
        return 'entry_plan_generic'
    return 'missing'

def _v663_trigger_confidence(row: Dict[str, Any], levels: Dict[str, Any], plan: Dict[str, Any], source: str, candle_age: float) -> float:
    q = _v510_num(row.get('coin_quality_score'), default=0.0)
    structure = _v510_num(row.get('structure_score'), default=0.0)
    confirm = _v510_num(row.get('confirmation_score'), default=0.0)
    risk = _v510_num(row.get('execution_risk_score'), default=60.0)
    conf = 40.0
    if source not in ('missing','trigger_not_applicable'):
        conf += 18.0
    if source in ('vwap_recovery_line','vwap_ema_defense_rebreak','resistance_break_line','pullback_reaccel_line','box_break_line'):
        conf += 10.0
    if structure >= 55:
        conf += 10.0
    elif structure < 45:
        conf -= 8.0
    if confirm >= 55:
        conf += 6.0
    if q >= 70:
        conf += 6.0
    if risk >= 65:
        conf -= 12.0
    if candle_age > 180:
        conf -= 18.0
    elif candle_age > 90:
        conf -= 10.0
    if bool(row.get('coverage_only_v661')) or bool(row.get('coverage_light_v662')):
        conf -= 22.0
    return round(_v656_clamp(conf, 0.0, 100.0), 1)

def _v663_missing_reasons(row: Dict[str, Any], levels: Dict[str, Any], plan: Dict[str, Any], source: str, candle_age: float, conf: float) -> List[str]:
    reasons: List[str] = []
    if source == 'missing':
        if _v510_num(row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0) <= 0:
            reasons.append('price_missing')
        if candle_age < 0:
            reasons.append('candle_missing')
        elif candle_age > 90:
            reasons.append('candle_stale')
        reasons.append('no_structure_line')
    if source in ('structure_levels_generic','entry_plan_generic'):
        reasons.append('generic_structure_line')
    if source == 'resistance_break_line' and ('hot-rank' in _v656_blob(row).lower() or '급등' in _v656_blob(row)):
        reasons.append('only_hot_rank_or_breakout_watch')
    if conf < 45:
        reasons.append('line_conf_low')
    if bool(row.get('coverage_only_v661')) or bool(row.get('coverage_light_v662')):
        reasons.append('coverage_observe_only')
    return _v510_uniq(reasons, 8)

def _v659_trigger_audit(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    """v663: entry_plan/structure_levels 생성 이후의 trigger source owner.

    이전 v659/v662 audit이 entry_plan 생성 전 row를 보고 missing을 봉인하는 경로가 있었기 때문에,
    같은 함수명을 재정의해 이후 모든 writer/urgent 요청이 최신 source owner를 보게 한다.
    """
    if not isinstance(row, dict):
        return {'schema': 'trigger_structure_audit_v663', 'status': 'invalid_row', 'source': 'invalid'}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    tg = row.get('trigger_gate') if isinstance(row.get('trigger_gate'), dict) else {}
    canon = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    if not levels and isinstance(canon.get('structure'), dict):
        st_obj = canon.get('structure') or {}
        if isinstance(st_obj.get('levels'), dict):
            levels = st_obj.get('levels') or {}
    if not plan and isinstance(canon.get('entry_plan'), dict):
        plan = canon.get('entry_plan') or {}
    if not tg and isinstance(canon.get('trigger_gate'), dict):
        tg = canon.get('trigger_gate') or {}

    price = _v510_num(tg.get('current_price'), row.get('current_price'), row.get('entry_price'), row.get('price'), default=0.0)
    level_trigger = _v510_num(levels.get('trigger_price'), default=0.0)
    plan_trigger = _v510_num(plan.get('trigger_price'), default=0.0)
    row_trigger = _v510_num(row.get('trigger_price'), default=0.0)
    trigger = _v510_num(tg.get('trigger_price'), level_trigger, plan_trigger, row_trigger, default=0.0)
    source = _v663_trigger_source_name(row, levels, plan)
    if trigger <= 0 and row_trigger > 0:
        source = 'row_trigger_price'
        trigger = row_trigger
    gap = _v510_num(tg.get('trigger_gap_pct'), default=None)
    if gap is None and price and trigger:
        try:
            gap = round((price - trigger) / trigger * 100.0, 3)
        except Exception:
            gap = None
    candle_age = _v659_age(row, 'official_candle_age', 'official_candle_age_sec', 'candle_age_sec', 'candle_age', default=-1.0)
    stale_obj = row.get('stale_origin_v658') if isinstance(row.get('stale_origin_v658'), dict) else {}
    top_sources = _v656_list(stale_obj.get('top_sources'), 8) if isinstance(stale_obj, dict) else []
    has_candle_stale = any(str(x).startswith('candle') for x in top_sources) or any('candle' in str(x).lower() or '캔들' in str(x) for x in _v656_list(row.get('stale_reasons'), 12))
    if has_candle_stale and candle_age < 0:
        candle_age = 999.0
    conf = _v663_trigger_confidence(row, levels, plan, source, candle_age)
    if not trigger:
        status = 'trigger_missing'
    elif price and trigger and price >= trigger * 0.999:
        status = 'trigger_reached'
    else:
        status = 'trigger_wait'
    risk_flags: List[str] = []
    missing_reasons = _v663_missing_reasons(row, levels, plan, source, candle_age, conf)
    if source == 'missing':
        risk_flags.append('trigger_source_missing')
    for mr in missing_reasons:
        if mr not in risk_flags:
            risk_flags.append(mr)
    if candle_age > 90 or has_candle_stale:
        risk_flags.append('candle_stale')
    if conf < 45:
        risk_flags.append('trigger_conf_low')
    if gap is not None and gap < -1.2:
        risk_flags.append('trigger_too_far')
    if gap is not None and gap > 1.0 and status != 'trigger_reached':
        risk_flags.append('trigger_gap_inconsistent')
    risk_flags = _v510_uniq(risk_flags, 12)
    reason = str(levels.get('trigger_reason') or plan.get('trigger_reason') or tg.get('reason') or '')
    if source == 'missing':
        reason = '방아쇠 source 없음: ' + (', '.join(missing_reasons[:4]) if missing_reasons else 'no_structure_line')
    elif status == 'trigger_wait' and not reason:
        reason = f'방아쇠 대기: {source}'
    elif status == 'trigger_reached' and not reason:
        reason = f'방아쇠 도달: {source}'
    return {
        'schema': 'trigger_structure_audit_v663',
        'build': V663_STRATEGY_BUILD,
        'status': status,
        'source': source,
        'current_price': round(price, 8) if price else None,
        'trigger_price': round(trigger, 8) if trigger else None,
        'trigger_gap_pct': gap,
        'trigger_reason': reason,
        'plan_type': levels.get('plan_type') or plan.get('plan_type') or '-',
        'line_quality': source,
        'trigger_confidence': conf,
        'support_confidence': None,
        'candle_age_sec': round(candle_age, 1) if candle_age >= 0 else None,
        'stale_top': top_sources[:6],
        'risk_flags': risk_flags,
        'missing_reasons': missing_reasons,
        'reason': reason or '-',
        'policy': 'v663: trigger source owner는 entry_plan/structure_levels 생성 이후 strategy_worker가 봉인한다. fallback trigger로 S1 통과 금지.',
    }

def _v574_attach_s2_fresh_urgent_requests__L10531(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v663_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    out_reqs = list(out_reqs or [])
    seen = {(ticker_norm(r.get('ticker')), str(r.get('bucket') or '')) for r in out_reqs if isinstance(r, dict)}
    added: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker'))
        if not t:
            continue
        audit = r.get('trigger_structure_audit_v663') if isinstance(r.get('trigger_structure_audit_v663'), dict) else _v659_trigger_audit(r)
        q = _v510_num(r.get('coin_quality_score'), default=0.0)
        risk = _v510_num(r.get('execution_risk_score'), default=99.0)
        stage = _v510_stage(r)
        flags = [str(x) for x in (audit.get('risk_flags') or [])]
        source_missing = 'trigger_source_missing' in flags or str(audit.get('source')) == 'missing'
        candle_issue = 'candle_stale' in flags or 'candle_missing' in flags
        worth = bool((q >= 62 and risk <= 55) or stage == 'S2')
        if not (worth and (source_missing or candle_issue)):
            continue
        bucket = 'quality_trigger_source_urgent_v663'
        key = (t, bucket)
        if key in seen:
            continue
        seen.add(key)
        need = ['candle', 'feature'] if source_missing else ['candle']
        pri = 1260.0 + min(150.0, q) - min(50.0, risk / 2.0)
        if stage == 'S2':
            pri += 100.0
        req = {
            'ticker': t,
            'bucket': bucket,
            'priority': round(pri, 3),
            'need': need,
            'need_candle': 'candle' in need,
            'need_feature': 'feature' in need,
            'required_age_sec': 30,
            'target_age': 30,
            'source': 'strategy_worker_v663_trigger_source_owner',
            'stage': stage,
            'coin_quality_score': q,
            'execution_risk_score': risk,
            'trigger_status': audit.get('status'),
            'trigger_source': audit.get('source'),
            'trigger_confidence': audit.get('trigger_confidence'),
            'trigger_missing_reasons': audit.get('missing_reasons') or [],
            'trigger_risk_flags': flags[:10],
            'reasons': _v656_list(r.get('quality_s3_hold_reasons_v658'), 4) + flags[:4],
            'updated_ts': nowv,
            'updated_text': now_text(nowv),
            'policy': '고품질/S2 후보 중 trigger source missing 또는 candle stale인 경우 구조재료 우선 갱신. S1 조건 완화 없음.',
        }
        out_reqs.append(req)
        added.append(req)
    if isinstance(base_summary, dict):
        base_summary = dict(base_summary)
    else:
        base_summary = {}
    base_summary['v663_trigger_source_urgent_summary'] = {
        'schema': 'trigger_source_urgent_requests_v663',
        'version': VERSION,
        'added_count': len(added),
        'targets': [x.get('ticker') for x in added[:20]],
        'reason_top': dict(Counter('/'.join(str(y) for y in (x.get('trigger_missing_reasons') or [])) or str(x.get('trigger_source')) for x in added).most_common(8)),
        'policy': 'trigger source owner가 missing/candle 원인을 쪼개고 고품질 후보만 candle/feature urgent로 보낸다.',
    }
    base_summary['schema'] = 'strategy_s2_fresh_urgent_summary_v663_trigger_source'
    return out_reqs, base_summary

def _v667_miss_bucket(row: Dict[str, Any]) -> str:
    reasons = ' '.join(str(x) for x in (row.get('block_reasons') or row.get('risk_flags') or row.get('missing_info') or [])).lower()
    if row.get('coverage_only_v661') or row.get('coverage_light_v662') or 'coverage' in reasons or 'base/spike' in reasons:
        return 'coverage_buried'
    if 'trigger' in reasons or str(row.get('trigger_status') or '').startswith('trigger'):
        return 'trigger_wait_missed'
    stale = row.get('stale_cause_v658') or row.get('stale_causes_v658') or row.get('freshness_missing') or []
    stale_s = ' '.join(str(x) for x in stale) if isinstance(stale, list) else str(stale or '')
    if 'candle' in stale_s or '캔들' in reasons:
        return 'candle_late'
    if 'feature' in stale_s or 'vwap' in reasons or '가격' in reasons:
        return 'feature_late'
    if 'orderflow' in stale_s or 'micro' in stale_s or '체결' in reasons or '호가' in reasons:
        return 'orderflow_late'
    if any(w in reasons for w in ('스프레드', '미끄러짐', '매도', '윗꼬리', 'risk')):
        return 'risk_filter_candidate'
    return 'strategy_rejected_or_observed'

V668_RECHECK_SUMMARY = BASE_DIR / "clean_market_miss_recheck_lane_v668.json"

def _v668_is_recheck_worthy(row: Dict[str, Any]) -> Tuple[bool, str, float, List[str]]:
    bucket = _v667_miss_bucket(row)
    q = _v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0)
    risk = _v510_num(row.get('execution_risk_score'), default=99.0)
    react = _v510_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), default=0.0)
    buy = _v510_num(row.get('buy_ratio'), default=0.0)
    sustain = _v510_num(row.get('buy_sustain_1m'), default=0.0)
    stage = _v510_stage(row)
    worthy = False
    reasons: List[str] = []
    if stage == 'S2':
        worthy = True; reasons.append('S2 재확인')
    if q >= 60 and risk <= 45:
        worthy = True; reasons.append(f'품질 {q:.1f}/위험 {risk:.1f}')
    if bucket in ('feature_late','orderflow_late','candle_late','trigger_wait_missed') and (q >= 55 or react >= 0.05 or buy >= 0.45 or sustain >= 0.55):
        worthy = True; reasons.append(bucket)
    if bucket == 'coverage_buried' and (q >= 60 or (react >= 0.05 and (buy >= 0.45 or sustain >= 0.55))):
        worthy = True; reasons.append('묻힌후보 재확인')
    if risk >= 70 and stage != 'S2':
        worthy = False; reasons.append('위험높음 제외')
    pri = 118.0 + min(60.0, q) + max(0.0, react) * 6.0 + (15.0 if stage == 'S2' else 0.0)
    return worthy, bucket, pri, _v510_uniq(reasons, 8)

def _v574_attach_s2_fresh_urgent_requests__L11333(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v668_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    reqs = list(out_reqs or [])
    counts: Counter = Counter(); added=[]
    existing_keys = {f"{ticker_norm(r.get('ticker'))}:{r.get('bucket')}" for r in reqs if isinstance(r, dict)}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        t = _v661_row_ticker(row)
        if not t:
            continue
        worthy, bucket, pri, reasons = _v668_is_recheck_worthy(row)
        if not worthy or bucket == 'risk_filter_candidate':
            continue
        rbucket = f'v668_{bucket}_recheck'
        key = f'{t}:{rbucket}'
        if key in existing_keys:
            continue
        req = {
            'ticker': t,
            'bucket': rbucket,
            'priority': round(pri, 3),
            'need': _v668_recheck_need(bucket, row),
            'source': 'strategy_worker_v668_market_miss_recheck_lane',
            'stage': _v510_stage(row),
            'strategy_key': row.get('strategy_key'),
            'coin_quality_score': round(_v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0), 3),
            'execution_risk_score': round(_v510_num(row.get('execution_risk_score'), default=99.0), 3),
            'miss_bucket': bucket,
            'reasons': reasons,
            'updated_ts': nowv,
        }
        reqs.append(req); existing_keys.add(key); counts[rbucket] += 1
        added.append({k:req.get(k) for k in ('ticker','bucket','priority','need','stage','coin_quality_score','execution_risk_score','miss_bucket','reasons')})
    summary = dict(base_summary or {})
    summary['v668_recheck_lane'] = {
        'schema': 'market_miss_recheck_lane_v668',
        'request_count': sum(counts.values()),
        'bucket_counts': dict(counts.most_common(10)),
        'top': sorted(added, key=lambda x: _v510_num(x.get('priority'), default=0.0), reverse=True)[:20],
        'policy': 'coverage/feature/orderflow late 후보를 정보 재수집 lane으로 보냄. S1/OPEN 조건 변경 없음.',
    }
    try:
        save_json(V668_RECHECK_SUMMARY, {'version': VERSION, 'updated_ts': nowv, 'updated_text': now_text(nowv), **summary['v668_recheck_lane']})
    except Exception as exc:
        append_error(ERROR, 'v668_recheck_lane_save', exc)
    return reqs, summary

_V671_LAST_FAST_SUMMARY: Dict[str, Any] = {}

def _v671_dicts(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if isinstance(row, dict):
        out.append(row)
        for k in ('coin_quality_spine','entry_context','canonical_metric_row','fast_quality_paper_v669'):
            v = row.get(k)
            if isinstance(v, dict):
                out.append(v)
                for kk in ('coin_quality_spine','trigger_structure_audit_v663','trigger_structure_audit_v659','entry_plan','structure_levels','trigger_gate'):
                    vv = v.get(kk)
                    if isinstance(vv, dict):
                        out.append(vv)
        for k in ('entry_plan','structure_levels','trigger_gate','trigger_structure_audit_v663','trigger_structure_audit_v659'):
            v = row.get(k)
            if isinstance(v, dict):
                out.append(v)
    # keep order and identity unique enough
    uniq: List[Dict[str, Any]] = []
    seen: set[int] = set()
    for d in out:
        if id(d) not in seen:
            uniq.append(d); seen.add(id(d))
    return uniq

def _v671_pick_num(row: Dict[str, Any], keys: List[str], default: float=0.0) -> float:
    for d in _v671_dicts(row):
        for k in keys:
            if k in d:
                v = _v510_num(d.get(k), default=None)
                if v is not None:
                    return float(v)
    return default

def _v671_pick_str(row: Dict[str, Any], keys: List[str], default: str='') -> str:
    for d in _v671_dicts(row):
        for k in keys:
            v = d.get(k)
            if v not in (None, '', '-', [], {}):
                return str(v)
    return default

def _v671_pick_list(row: Dict[str, Any], keys: List[str]) -> List[str]:
    out: List[str] = []
    for d in _v671_dicts(row):
        for k in keys:
            v = d.get(k)
            if isinstance(v, list):
                out.extend(str(x) for x in v if x not in (None, ''))
            elif v not in (None, '', {}, []):
                out.append(str(v))
    return _v510_uniq(out, 20)

def _v671_pick_audit(row: Dict[str, Any]) -> Dict[str, Any]:
    for d in _v671_dicts(row):
        for k in ('trigger_structure_audit_v663','trigger_structure_audit_v659'):
            v = d.get(k)
            if isinstance(v, dict) and (v.get('source') or v.get('trigger_price') or v.get('trigger_gap_pct') is not None):
                return dict(v)
    # fallback: build a light audit from row fields/entry plan. This does not create a trade trigger; it only normalizes display/decision inputs.
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    tg = row.get('trigger_gate') if isinstance(row.get('trigger_gate'), dict) else {}
    price = _v671_pick_num(row, ['current_price','price','trade_price','entry_price'], 0.0)
    trigger = _v510_num(tg.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), row.get('trigger_price'), default=0.0)
    gap = _v510_num(tg.get('trigger_gap_pct'), levels.get('trigger_gap_pct'), plan.get('trigger_gap_pct'), row.get('trigger_gap_pct'), default=None)
    if gap is None and price and trigger:
        try: gap = round((price-trigger)/trigger*100.0, 3)
        except Exception: gap = None
    src = str(tg.get('source') or levels.get('trigger_source') or plan.get('trigger_source') or row.get('trigger_source_v663') or row.get('trigger_source') or '')
    return {'schema':'trigger_structure_audit_v671_normalized_fallback','source':src,'current_price':price or None,'trigger_price':trigger or None,'trigger_gap_pct':gap,'trigger_confidence':_v510_num(tg.get('trigger_confidence'), levels.get('trigger_confidence'), plan.get('trigger_confidence'), row.get('trigger_confidence_v663'), default=None),'risk_flags': _v671_pick_list(row, ['risk_flags','trigger_risk_flags','risk_tags'])}

def _v671_fast_quality_diag(row: Dict[str, Any]) -> Dict[str, Any]:
    q = _v671_pick_num(row, ['coin_quality_score','candidate_quality_score','quality_score','q','score'], 0.0)
    risk = _v671_pick_num(row, ['execution_risk_score','risk_score','execution_risk','R','risk'], 99.0)
    if risk == 99.0:
        ex_score = _v671_pick_num(row, ['execution_score'], -1.0)
        if ex_score >= 0:
            risk = max(0.0, min(100.0, 100.0 - ex_score))
    audit = _v671_pick_audit(row)
    gap = _v510_num(audit.get('trigger_gap_pct'), row.get('trigger_gap_pct'), default=-999.0)
    conf = _v510_num(audit.get('trigger_confidence'), row.get('trigger_confidence_v663'), default=0.0)
    src = str(audit.get('source') or _v671_pick_str(row, ['trigger_source_v663','trigger_source','trigger_reason'], ''))
    c_age = _v510_num(audit.get('candle_age_sec'), _v671_pick_num(row, ['candle_age_sec','official_candle_age','candle_age'], 9999.0), default=9999.0)
    react = _v671_pick_num(row, ['price_reaction_pct','change_1m_pct','price_chg_60s','price_chg_30s'], 0.0)
    buy = _v671_pick_num(row, ['buy_ratio','buy_ratio_20s','buy_ratio_10s'], 0.0)
    sustain = _v671_pick_num(row, ['buy_sustain_1m','buy_sustain','buy_sustain_20s','buy_ratio_20s'], 0.0)
    spread = _v671_pick_num(row, ['spread_pct','spread'], 0.0)
    slip = _v671_pick_num(row, ['slippage_pct','expected_slippage_pct'], spread)
    flags = [str(x) for x in (audit.get('risk_flags') or [])] + _v671_pick_list(row, ['risk_tags','execution_risk_tags','structure_risk_tags','block_reasons'])
    return {
        'ticker': _v661_row_ticker(row),
        'q': round(q, 3), 'risk': round(risk, 3), 'gap': round(gap, 3),
        'trigger_source': src, 'trigger_confidence': round(conf, 3), 'candle_age_sec': round(c_age, 1),
        'price_reaction_pct': round(react, 3), 'buy_ratio': round(buy, 3), 'buy_sustain_1m': round(sustain, 3),
        'spread_pct': round(spread, 3), 'slippage_pct': round(slip, 3),
        'risk_flags': flags[:12],
        'field_owner': 'v671_normalized_from_canonical_row',
    }

VERSION = "strategy_worker_v0.801"

INFO_PRIORITY_SUMMARY_V675 = BASE_DIR / "clean_info_priority_summary_v675.json"

def _v675_diag(row: Dict[str, Any]) -> Dict[str, Any]:
    try:
        if '_v671_fast_quality_diag' in globals():
            return _v671_fast_quality_diag(row)  # type: ignore[name-defined]
    except Exception:
        pass
    return {
        'ticker': _v661_row_ticker(row),
        'q': _v510_num(row.get('coin_quality_score'), row.get('score'), default=0.0),
        'risk': _v510_num(row.get('execution_risk_score'), default=99.0),
        'gap': _v510_num(row.get('trigger_gap_pct'), default=None),
        'trigger_source': row.get('trigger_source') or row.get('trigger_source_v663'),
        'trigger_confidence': _v510_num(row.get('trigger_confidence'), row.get('trigger_confidence_v663'), default=0.0),
        'price_reaction_pct': _v510_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), default=0.0),
        'buy_ratio': _v510_num(row.get('buy_ratio'), default=0.0),
        'buy_sustain_1m': _v510_num(row.get('buy_sustain_1m'), default=0.0),
        'spread_pct': _v510_num(row.get('spread_pct'), default=0.0),
        'slippage_pct': _v510_num(row.get('slippage_pct'), default=0.0),
        'candle_age_sec': _v510_num(row.get('candle_age_sec'), row.get('candle_age'), default=9999.0),
    }

def _v668_recheck_need(bucket: str, row: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    if bucket == 'feature_late': return ['feature', 'price_vwap_ema', 'quote']
    if bucket == 'orderflow_late': return ['orderflow', 'micro', 'trade_buy_ratio', 'spread_slippage']
    if bucket == 'candle_late': return ['candle', 'structure_levels', 'support_resistance']
    if bucket == 'trigger_wait_missed': return ['candle', 'feature', 'orderflow', 'trigger_recheck']
    if bucket == 'coverage_buried': return ['feature', 'orderflow', 'candle', 'coverage_rescue']
    return ['quote']

def _v675_priority_tier(bucket: str, row: Dict[str, Any]) -> Tuple[str, float]:
    d = _v675_diag(row); q = _v510_num(d.get('q'), default=0.0); risk = _v510_num(d.get('risk'), default=99.0); stage = _v510_stage(row)
    if row.get('paper_experiment_open') is True or row.get('paper_experiment_handoff_ready_v674') is True: return 'T0_paper_handoff', 260.0 + min(q, 80.0)
    if stage == 'S2': return 'T2_s2_trigger_recheck', 220.0 + min(q, 70.0)
    if bucket == 'coverage_buried': return 'T3_coverage_rescue', 180.0 + min(q, 60.0) - max(0.0, risk-45.0)
    if bucket == 'feature_late': return 'T4_feature_urgent', 170.0 + min(q, 60.0)
    if bucket == 'orderflow_late': return 'T5_orderflow_urgent', 165.0 + min(q, 60.0)
    if bucket == 'candle_late': return 'T6_candle_urgent', 155.0 + min(q, 60.0)
    return 'T7_market_rotation', 100.0 + min(q, 40.0)

def _v574_attach_s2_fresh_urgent_requests__L12345(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out_reqs, base_summary = _v675_prev_attach_s2_fresh_urgent_requests(rows, priority_requests, nowv)
    reqs = list(out_reqs or []); counts: Counter = Counter(); owner_counts: Counter = Counter(); added=[]
    existing_keys = {f"{ticker_norm(r.get('ticker'))}:{r.get('bucket')}" for r in reqs if isinstance(r, dict)}
    for row in rows or []:
        if not isinstance(row, dict): continue
        t = _v661_row_ticker(row)
        if not t: continue
        bucket = _v667_miss_bucket(row); d = _v675_diag(row)
        q = _v510_num(d.get('q'), default=0.0); risk = _v510_num(d.get('risk'), default=99.0)
        react = _v510_num(d.get('price_reaction_pct'), default=0.0); buy = _v510_num(d.get('buy_ratio'), default=0.0); sustain = _v510_num(d.get('buy_sustain_1m'), default=0.0)
        worthy = _v510_stage(row) == 'S2' or row.get('paper_experiment_open') is True or q >= 55 or react >= 0.05 or buy >= 0.45 or sustain >= 0.55
        if risk >= 80 and _v510_stage(row) != 'S2': worthy = False
        if not worthy or bucket == 'risk_filter_candidate': continue
        tier, pri = _v675_priority_tier(bucket, row); rbucket = f'v675_{tier}_{bucket}'; key = f'{t}:{rbucket}'
        if key in existing_keys: continue
        need = _v668_recheck_need(bucket, row)
        for n in need: owner_counts[n] += 1
        req = {'ticker': t, 'bucket': rbucket, 'priority': round(pri, 3), 'tier': tier, 'need': need, 'source': 'strategy_worker_v675_info_priority_spine', 'stage': _v510_stage(row), 'coin_quality_score': round(q, 3), 'execution_risk_score': round(risk, 3), 'miss_bucket': bucket, 'reasons': [tier, bucket, f'Q{q:.1f}', f'R{risk:.1f}'], 'updated_ts': nowv}
        reqs.append(req); existing_keys.add(key); counts[rbucket] += 1; added.append({k:req.get(k) for k in ('ticker','bucket','tier','priority','need','stage','coin_quality_score','execution_risk_score','miss_bucket','reasons')})
    summary = dict(base_summary or {})
    summary['v675_info_priority'] = {'schema': 'info_priority_spine_v675', 'request_count': sum(counts.values()), 'tier_counts': dict(counts.most_common(12)), 'owner_need_counts': dict(owner_counts.most_common(12)), 'top': sorted(added, key=lambda x: _v510_num(x.get('priority'), default=0.0), reverse=True)[:20], 'policy': '정보부족 후보를 T0~T7 우선순위와 owner need(feature/orderflow/candle 등)로 세분화. S1/OPEN 조건 변경 없음.'}
    try: save_json(INFO_PRIORITY_SUMMARY_V675, {'version': VERSION, 'updated_ts': nowv, 'updated_text': now_text(nowv), **summary['v675_info_priority']})
    except Exception as exc: append_error(ERROR, 'v675_info_priority_save', exc)
    return reqs, summary

VERSION = "strategy_worker_v0.801"

INFO_PRIORITY_SUMMARY_V676 = BASE_DIR / "clean_info_priority_summary_v676.json"

def _v676_bucket_for_info(row: Dict[str, Any]) -> str:
    b = _v667_miss_bucket(row)
    if row.get('paper_experiment_open') is True or row.get('paper_experiment_handoff_ready_v674') is True:
        return 'paper_handoff_near_trigger'
    d = _v675_diag(row)
    gap = _v510_num(d.get('gap'), default=-999.0)
    if _v510_stage(row) == 'S2' and -0.50 <= gap <= 0.10:
        return 'near_trigger_fresh'
    return b

def _v574_attach_s2_fresh_urgent_requests__L12535(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    reqs, summary = _v676_prev_attach_info_priority(rows, priority_requests, nowv)
    reqs=list(reqs or []); counts=Counter(); need_counts=Counter(); added=[]
    existing={f"{ticker_norm(r.get('ticker'))}:{r.get('bucket')}" for r in reqs if isinstance(r, dict)}
    for row in rows or []:
        if not isinstance(row, dict): continue
        t=_v661_row_ticker(row)
        if not t: continue
        b=_v676_bucket_for_info(row); d=_v675_diag(row)
        q=_v510_num(d.get('q'), default=0.0); risk=_v510_num(d.get('risk'), default=99.0); gap=_v510_num(d.get('gap'), default=-999.0)
        stage=_v510_stage(row)
        if b in ('paper_handoff_near_trigger','near_trigger_fresh'):
            tier='T0_paper_near_trigger' if b=='paper_handoff_near_trigger' else 'T2_near_trigger_fresh'
            need=['feature','orderflow','micro','candle','trigger_recheck','quote']
            pri=310.0 + min(q,80.0) - max(0.0,risk-30.0)
        elif b=='feature_late':
            tier='T4_feature_urgent'; need=['feature','price_vwap_ema','quote']; pri=235.0+min(q,70.0)
        elif b=='orderflow_late':
            tier='T5_orderflow_urgent'; need=['orderflow','micro','trade_buy_ratio','spread_slippage','quote']; pri=235.0+min(q,70.0)
        elif b=='coverage_buried' and q>=55 and risk<=45:
            tier='T3_coverage_rescue'; need=['feature','orderflow','micro','candle','coverage_rescue','quote']; pri=210.0+min(q,70.0)-max(0.0,risk-25.0)
        else:
            continue
        key=f'{t}:v676_{tier}_{b}'
        if key in existing: continue
        req={'ticker':t,'bucket':f'v676_{tier}_{b}','priority':round(pri,3),'tier':tier,'need':need,'source':'strategy_worker_v676_info_priority_owner','stage':stage,'coin_quality_score':round(q,3),'execution_risk_score':round(risk,3),'trigger_gap_pct':round(gap,3),'miss_bucket':b,'reasons':[tier,b,f'Q{q:.1f}',f'R{risk:.1f}',f'gap{gap:+.2f}'],'updated_ts':nowv}
        reqs.append(req); existing.add(key); counts[req['bucket']]+=1
        for n in need: need_counts[n]+=1
        added.append({k:req.get(k) for k in ('ticker','bucket','tier','priority','need','stage','coin_quality_score','execution_risk_score','trigger_gap_pct','miss_bucket')})
    if isinstance(summary, dict):
        summary=dict(summary)
    else: summary={}
    summary['v676_info_priority']={'schema':'info_priority_spine_v676_near_trigger_owner','request_count':sum(counts.values()),'tier_counts':dict(counts.most_common(12)),'owner_need_counts':dict(need_counts.most_common(12)),'top':sorted(added,key=lambda x:_v510_num(x.get('priority'),default=0.0),reverse=True)[:20],'policy':'near-trigger/feature/orderflow/coverage rescue를 owner need로 분리. target_router v0.22가 v676 bucket을 high lane으로 소비.'}
    try: save_json(INFO_PRIORITY_SUMMARY_V676, {'version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),**summary['v676_info_priority']})
    except Exception as exc: append_error(ERROR,'v676_info_priority_save',exc)
    return reqs, summary

VERSION = 'strategy_worker_v0.801'

MAIN_DEPLOY_VERSION = 'v2.13.764'

BUILD_LABEL = 'v787_missing_v782_helper_cut_2026-06-09'

def _v755_has_text(items: Any, *words: str) -> bool:
    hay = ' '.join(str(x) for x in (items if isinstance(items, list) else [items])).lower()
    return any(str(w).lower() in hay for w in words)

def _v755_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = [row.get(k) for k in keys]
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    vals += [ctx.get(k) for k in keys]
    return _v510_num(*vals, default=default)

def _v755_structure_taxonomy__L12592(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    src_tags = _v553_as_list(row.get('structure_tags')) + _v553_as_list(row.get('matched_strategy_labels'))
    risk_src = _v553_as_list(row.get('risk_tags'))
    good: List[str] = []
    bad: List[str] = []
    recheck: List[str] = []

    vwap_gap = _v755_num(row, 'vwap_gap_pct', default=-999.0)
    ema5_gap = _v755_num(row, 'ema5_gap_pct', 'ma5_gap_pct', default=-999.0)
    ema10_gap = _v755_num(row, 'ema10_gap_pct', default=-999.0)
    react = _v755_num(row, 'price_reaction_pct', 'change_1m_pct', default=0.0)
    chg3 = _v755_num(row, 'change_3m_pct', 'change_3m', default=0.0)
    chg5 = _v755_num(row, 'change_5m_pct', 'change_5m', default=0.0)
    chg20 = _v755_num(row, 'price_chg_20s', default=0.0)
    chg30 = _v755_num(row, 'price_chg_30s', default=0.0)
    chg60 = _v755_num(row, 'price_chg_60s', default=react)
    accel10 = _v755_num(row, 'price_accel_10s', default=0.0)
    buy = _v755_num(row, 'buy_ratio', default=0.0)
    buy10 = _v755_num(row, 'buy_ratio_10s', default=buy)
    sustain = _v755_num(row, 'buy_sustain_1m', default=0.0)
    sustain20 = _v755_num(row, 'buy_sustain_20s', default=sustain)
    spread = _v755_num(row, 'spread_pct', default=99.0)
    slip = _v755_num(row, 'slippage_pct', default=spread)
    vol_ratio = _v755_num(row, 'volume_ratio', default=0.0)
    vol_exp = _v755_num(row, 'volume_expansion_pct', default=0.0)
    wick_up = _v755_num(row, 'upper_wick_pct', default=0.0)
    candle_age = _v755_num(row, 'official_candle_age', default=0.0)
    candle_src = str(row.get('official_candle_source') or '')
    current = _v755_num(row, 'current_price', 'price', 'entry_price', default=0.0)
    trigger = _v755_num(row, 'trigger_price', default=0.0)
    target = _v755_num(row, 'target_price', 'target1_price', default=0.0)
    invalid = _v755_num(row, 'invalid_price', 'stop_price', default=0.0)

    if bool(row.get('sweep_reclaim_hint')) or _v755_has_text(src_tags, '저점유동성쓸림', '쓸림후빠른회복'):
        good.append('저점쓸림후빠른회복')
    if vwap_gap >= 0.0:
        good.append('VWAP재회복/방어')
    elif -0.25 <= vwap_gap < 0.0:
        recheck.append('VWAP근처회복대기')
    if ema5_gap >= 0.0 and (chg20 >= 0.20 or chg30 >= 0.30 or react >= 0.35):
        good.append('EMA방어후재가속')
    if bool(row.get('breakout_hint')) or bool(row.get('box_breakout_hint')) or _v755_has_text(src_tags, '저항돌파'):
        if bool(row.get('support_reclaim_hint')) or bool(row.get('close_near_high')):
            good.append('저항돌파후재테스트성공')
        else:
            recheck.append('재테스트대기')
        good.append('박스상단돌파')
    if bool(row.get('volume_expanding')) or bool(row.get('reclaim_volume_expand')) or vol_ratio >= 1.20 or vol_exp >= 20.0:
        if chg3 >= 0.15 or react >= 0.35:
            good.append('눌림후거래량재유입')
    if chg3 >= 0.35 and buy >= 0.70:
        good.append('돈흐름재가속')
    if bool(row.get('close_near_high')) and wick_up < 25.0 and sustain >= 0.70:
        good.append('고점근처버티기')
    if bool(row.get('support_reclaim_hint')) or (_v755_num(row, 'support_touch_count', default=0.0) >= 2.0 and vwap_gap >= -0.10):
        good.append('지지전환확인')

    if bool(row.get('long_upper_wick')) or wick_up >= 35.0 or _v755_has_text(risk_src, '윗꼬리'):
        bad.append('윗꼬리저항')
    if (bool(row.get('breakout_hint')) or bool(row.get('box_breakout_hint'))) and (bool(row.get('resistance_reject_hint')) or not bool(row.get('close_near_high'))):
        bad.append('가짜돌파위험')
    if current > 0 and target > 0 and current >= target * 0.995:
        bad.append('목표가근처진입')
    if vwap_gap < -0.05 or ema5_gap < -0.10 or ema10_gap < -0.15:
        bad.append('VWAP/EMA하단구조')
    if react >= 0.35 and (vol_ratio <= 0.50 or vol_exp <= -40.0):
        bad.append('거래량없는상승')
    if accel10 <= -0.20 or (buy > 0 and buy10 < max(0.0, buy - 0.15)) or sustain20 < 0.55:
        bad.append('매수세꺼짐')
    if candle_age >= 120.0 or candle_src == 'missing' or _v755_has_text(risk_src, '공식캔들 stale'):
        bad.append('구조선stale/missing')
    if chg5 >= 3.0 or vwap_gap >= 3.0:
        bad.append('늦은추격위험')
    if bool(row.get('resistance_reject_hint')):
        bad.append('저항밀림')
    if vol_exp <= -50.0 and react >= 0.20:
        bad.append('거래량급감')
    if spread > 0.18 or slip > 0.20:
        bad.append('체결비용부담')

    if trigger > 0 and current > 0 and current < trigger:
        recheck.append('구조좋음+방아쇠미도달')
    if buy >= 0.75 and sustain >= 0.70 and react < 0.35:
        recheck.append('체결좋음+가격반응대기')
    if react >= 0.35 and (buy < 0.70 or sustain < 0.70):
        recheck.append('가격반응좋음+체결지속대기')
    if good and not bad and (react < 0.35 or buy < 0.70 or sustain < 0.70):
        recheck.append('구조좋음+확인신호대기')

    rr = 0.0
    if current > 0 and target > current and invalid > 0 and invalid < current:
        rr = (target - current) / (current - invalid)
    side = 'mixed'
    if good and not bad:
        side = 'good'
    elif bad and not good:
        side = 'bad'
    elif not good and not bad and recheck:
        side = 'recheck'
    elif not good and not bad:
        side = 'neutral'
    return {
        'schema': 'structure_taxonomy_v755',
        'good': _v510_uniq(good, 20),
        'bad': _v510_uniq(bad, 20),
        'recheck': _v510_uniq(recheck, 20),
        'side': side,
        'good_count': len(_v510_uniq(good, 20)),
        'bad_count': len(_v510_uniq(bad, 20)),
        'recheck_count': len(_v510_uniq(recheck, 20)),
        'rr_calc_hint': round(rr, 4) if rr else None,
        'policy': 'classification only; does not alter S1/S2/S3 thresholds',
    }

def _v755_attach_structure_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    tax = _v755_structure_taxonomy(row)
    row['structure_taxonomy_v755'] = tax
    row['structure_good_tags_v755'] = tax.get('good') or []
    row['structure_bad_tags_v755'] = tax.get('bad') or []
    row['structure_recheck_tags_v755'] = tax.get('recheck') or []
    row['structure_signal_side_v755'] = tax.get('side') or 'neutral'
    row['structure_taxonomy_policy_v755'] = 'classification_only_no_threshold_change'
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['structure_taxonomy_v755'] = tax
    ctx['structure_good_tags_v755'] = row['structure_good_tags_v755']
    ctx['structure_bad_tags_v755'] = row['structure_bad_tags_v755']
    ctx['structure_recheck_tags_v755'] = row['structure_recheck_tags_v755']
    ctx['structure_signal_side_v755'] = row['structure_signal_side_v755']
    row['entry_context'] = ctx
    return row

def _v532_apply_canonical_entry_decision__L12729(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = _v755_prev_apply_canonical_entry_decision(row)
    return _v755_attach_structure_taxonomy(row)

try:
    BUILD_LABEL = 'v787_missing_v782_helper_cut_2026-06-09'
except Exception:
    pass

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = 'v787_missing_v782_helper_cut_2026-06-09'

def _v759_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ''):
                return float(str(row.get(k)).replace(',', '').replace('%',''))
        except Exception:
            continue
    return default

def _v759_dict_any(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}

def _v759_official_inputs_from(row: Dict[str, Any], levels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    levels = levels if isinstance(levels, dict) else {}
    ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
    official = _v759_dict_any(
        row.get('official_structure_inputs_raw'),
        row.get('official_structure_inputs'),
        ev.get('official_structure_inputs'),
        levels.get('official_structure_inputs'),
    )
    if not official:
        try:
            official = _v596_official_structure_inputs(row) if '_v596_official_structure_inputs' in globals() else {}
        except Exception:
            official = {}
    return official if isinstance(official, dict) else {}

def _v759_structure_line_audit(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    levels = levels if isinstance(levels, dict) else {}
    ev = levels.get('structure_line_evidence') if isinstance(levels.get('structure_line_evidence'), dict) else {}
    official = _v759_official_inputs_from(row, levels)
    present = int(official.get('present_count') or 0) if str(official.get('present_count') or '').replace('.','',1).isdigit() else 0
    age = _v759_num(official, 'official_candle_age', default=_v759_num(row, 'official_candle_age', 'candle_age_sec', default=-1.0))
    quality = str(ev.get('quality') or levels.get('quality') or '')
    schema = str(levels.get('schema') or '')
    trigger_conf = _v759_num(ev, 'trigger_confidence', default=_v759_num(levels, 'trigger_confidence', default=0.0))
    support_conf = _v759_num(ev, 'support_confidence', default=0.0)
    resistance_conf = _v759_num(ev, 'resistance_confidence', default=0.0)
    source_kind = 'synthetic_pct_line'
    if present >= 6 and age >= 0 and age <= 180 and ('official' in quality or trigger_conf >= 52 or support_conf >= 42):
        source_kind = 'official_candle_reactive_line'
    elif present >= 3:
        source_kind = 'official_partial_watch_line'
    elif schema in ('structure_levels_v554_all_strategy','structure_levels_v573_refined_late_chase','structure_levels_v595_reactive_lines'):
        source_kind = 'gap_calculated_line'
    stale = bool(age >= 180 and age >= 0)
    missing = bool(present <= 0)
    if missing:
        reliability = 'missing_official_material'
    elif stale:
        reliability = 'stale_official_material'
    elif source_kind == 'official_candle_reactive_line':
        reliability = 'official_reactive'
    elif source_kind == 'official_partial_watch_line':
        reliability = 'official_partial'
    else:
        reliability = 'synthetic_or_gap'
    return {
        'schema': 'structure_line_source_audit_v759',
        'source_kind': source_kind,
        'reliability': reliability,
        'official_present_count': present,
        'official_candle_age': age if age >= 0 else None,
        'evidence_quality': quality or None,
        'support_confidence': support_conf,
        'resistance_confidence': resistance_conf,
        'trigger_confidence': trigger_conf,
        'line_price_policy': 'v759 audit only; existing trigger/support/target prices are not changed',
    }

def _v554_build_structure_levels__L12832(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v759_prev_build_structure_levels(row)
    if not isinstance(levels, dict):
        levels = {}
    try:
        audit = _v759_structure_line_audit(row, levels)
        levels['structure_line_audit_v759'] = audit
        levels['line_source_kind_v759'] = audit.get('source_kind')
        levels['line_reliability_v759'] = audit.get('reliability')
        levels['line_price_policy_v759'] = audit.get('line_price_policy')
        official = _v759_official_inputs_from(row, levels)
        if official:
            levels['official_structure_inputs_raw_v759'] = official
    except Exception as exc:
        try: log_error('v759_structure_line_audit', exc)
        except Exception: pass
    return levels

def _v755_structure_taxonomy__L12853(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    tax = _v759_prev_taxonomy(row)
    if not isinstance(tax, dict):
        tax = {'good': [], 'bad': [], 'recheck': [], 'side': 'neutral'}
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    audit = levels.get('structure_line_audit_v759') if isinstance(levels.get('structure_line_audit_v759'), dict) else row.get('structure_line_audit_v759') if isinstance(row.get('structure_line_audit_v759'), dict) else {}
    good = list(tax.get('good') or [])
    bad = list(tax.get('bad') or [])
    recheck = list(tax.get('recheck') or [])
    rel = str(audit.get('reliability') or '')
    src = str(audit.get('source_kind') or '')
    if rel == 'official_reactive':
        good.append('공식구조선반응확인')
    elif rel == 'official_partial':
        recheck.append('공식구조선부분확인')
    elif rel in ('missing_official_material','stale_official_material'):
        bad.append('구조선stale/missing')
    elif src in ('gap_calculated_line','synthetic_pct_line'):
        recheck.append('계산선검증필요')
    good = _v510_uniq(good, 24)
    bad = _v510_uniq(bad, 24)
    recheck = _v510_uniq(recheck, 24)
    side = 'neutral'
    if good and not bad:
        side = 'good'
    elif bad and not good:
        side = 'bad'
    elif good and bad:
        side = 'mixed'
    elif recheck:
        side = 'recheck'
    tax.update({'good': good, 'bad': bad, 'recheck': recheck, 'side': side, 'structure_line_audit_v759': audit, 'policy': 'classification only; no threshold/exit change'})
    return tax

def _v532_apply_canonical_entry_decision__L12890(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = _v759_prev_apply_canonical_entry_decision(row)
    try:
        levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
        audit = levels.get('structure_line_audit_v759') if isinstance(levels.get('structure_line_audit_v759'), dict) else _v759_structure_line_audit(row, levels)
        row['structure_line_audit_v759'] = audit
        row['structure_line_source_kind_v759'] = audit.get('source_kind')
        row['structure_line_reliability_v759'] = audit.get('reliability')
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['structure_line_audit_v759'] = audit
        ctx['structure_line_source_kind_v759'] = audit.get('source_kind')
        ctx['structure_line_reliability_v759'] = audit.get('reliability')
        row['entry_context'] = ctx
    except Exception as exc:
        try: log_error('v759_apply_line_audit', exc)
        except Exception: pass
    return row

STRUCTURE_SNAPSHOT_CACHE = BASE_DIR / "clean_structure_snapshot_cache.json"

def _v762_num(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        if v in (None, '', [], {}):
            continue
        try:
            return float(str(v).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return default

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

def _v767_as_ts(v: Any) -> float:
    if v in (None, '', [], {}):
        return 0.0
    try:
        x = float(str(v).replace(',', '').strip())
        if x > 1000000000000:  # ms
            x = x / 1000.0
        # ignore tiny OHLCV values accidentally passed as ts
        if x > 1000000000:
            return x
    except Exception:
        pass
    return 0.0

def _v767_float_age(v: Any) -> float:
    try:
        if v not in (None, '', [], {}):
            a = float(str(v).replace(',', '').replace('s','').strip())
            if 0 <= a < 86400 * 7:
                return a
    except Exception:
        pass
    return 999999.0

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

MAIN_DEPLOY_VERSION = "v2.13.783"

VERSION = "strategy_worker_v0.801"

_V769_TF_PREFIXES = ("m1", "m3", "m5", "m15", "m30", "h1", "1h", "h2", "2h", "h4", "4h")

_V769_TF_LABEL = {"m1":"1m","m3":"3m","m5":"5m","m15":"15m","m30":"30m","h1":"1h","1h":"1h","h2":"2h","2h":"2h","h4":"4h","4h":"4h"}

_V769_SHORT = {"1m", "3m", "5m"}

_V769_MID = {"15m", "30m"}

_V769_LONG = {"1h", "2h", "4h"}

def _v769_first_existing(src: Dict[str, Any], *keys: str) -> Any:
    if not isinstance(src, dict):
        return None
    for k in keys:
        v = src.get(k)
        if v not in (None, "", [], {}):
            return v
    return None

def _v769_pick_candle_value(c: Dict[str, Any], key: str, prefixes: Tuple[str, ...] = _V769_TF_PREFIXES) -> Any:
    if not isinstance(c, dict):
        return None
    for pref in prefixes:
        for k in (f"{pref}_{key}", f"{_V769_TF_LABEL.get(pref, pref)}_{key}"):
            v = c.get(k)
            if v not in (None, ""):
                return v
    return c.get(key) if c.get(key) not in (None, "") else None

def _v769_age_from_cache(c: Dict[str, Any], pref: str, nowv: float) -> float:
    label = _V769_TF_LABEL.get(pref, pref)
    # age fields first
    for k in (
        f"{pref}_age_sec", f"{pref}_candle_age_sec", f"candle_{label}_age_sec", f"{label}_candle_age_sec",
        f"ohlcv_{label}_age_sec", f"age_{label}", f"{label}_age_sec",
    ):
        a = _v767_float_age(c.get(k)) if '_v767_float_age' in globals() else _v762_num(c.get(k), default=999999.0)
        if a < 999998:
            return float(a)
    # timestamp fields
    for k in (
        f"{pref}_ts", f"{pref}_candle_ts", f"{label}_ts", f"{label}_candle_ts",
        f"ohlcv_{label}_ts", f"{pref}_updated_at", f"{label}_updated_at",
    ):
        ts = _v767_as_ts(c.get(k)) if '_v767_as_ts' in globals() else 0.0
        if ts > 0:
            return round(max(0.0, nowv - ts), 1)
    return 999999.0

def _v769_tf_material(c: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    groups = {'short': set(), 'mid': set(), 'long': set()}
    present_by_tf: Dict[str, int] = {}
    age_by_tf: Dict[str, float] = {}
    keys = ('swing_high_price','swing_low_price','box_high_price','box_low_price','recent_high_price','recent_low_price','upper_wick_pct','lower_wick_pct','support_touch_count','resistance_touch_count')
    for pref in _V769_TF_PREFIXES:
        label = _V769_TF_LABEL.get(pref, pref)
        cnt = 0
        for key in keys:
            if _v769_first_existing(c, f"{pref}_{key}", f"{label}_{key}") not in (None, "", [], {}):
                cnt += 1
        ok = bool(c.get(f"{pref}_ok") or c.get(f"{label}_ok") or cnt > 0)
        if ok:
            present_by_tf[label] = cnt
            age = _v769_age_from_cache(c, pref, nowv)
            age_by_tf[label] = age
            if label in _V769_SHORT:
                groups['short'].add(label)
            elif label in _V769_MID:
                groups['mid'].add(label)
            elif label in _V769_LONG:
                groups['long'].add(label)
    out['tf_present_by_group_v769'] = {k: sorted(v) for k, v in groups.items()}
    out['tf_present_counts_v769'] = present_by_tf
    out['tf_age_sec_v769'] = age_by_tf
    out['official_candle_intervals'] = '/'.join([*sorted(groups['short']), *sorted(groups['mid']), *sorted(groups['long'])]) or ''
    # flat age keys read by v767 TTL logic
    for tf, age in age_by_tf.items():
        out[f'candle_{tf}_age_sec'] = age
        out[f'{tf}_candle_age_sec'] = age
    out['short_tf_count_v769'] = len(groups['short'])
    out['mid_tf_count_v769'] = len(groups['mid'])
    out['long_tf_count_v769'] = len(groups['long'])
    return out

def _v597_candle_official_fields__L14027(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    """v769: official candle overlay now reads 1m/3m/5m + 15m/30m + 1h/2h/4h.
    candle_worker remains the raw-data owner; strategy only seals available cache fields.
    """
    if not isinstance(c, dict) or not c:
        return {}
    ts = nowv or now_ts()
    tfmat = _v769_tf_material(c, ts)
    if not any(tfmat.get('tf_present_by_group_v769', {}).values()) and not any(c.get(f'{p}_swing_high_price') for p in _V769_TF_PREFIXES):
        return {}
    out: Dict[str, Any] = {
        'official_candle_source': 'candle_worker_direct_cache_v769',
        'official_candle_cache_schema': c.get('official_structure_schema') or c.get('schema') or 'candle_cache_multi_tf_official_structure_inputs_v769',
        'official_structure_source': 'candle_worker_cache_overlay_v769',
        'official_structure_formula_v769': 'multi_tf_material_spine_v769',
    }
    out.update(tfmat)
    # Representative age: prefer shortest fresh available age, otherwise raw cache ts.
    ages = [a for a in (tfmat.get('tf_age_sec_v769') or {}).values() if isinstance(a, (int,float)) and a < 999998]
    if ages:
        out['official_candle_age'] = round(min(ages), 1)
    else:
        candle_ts = _v510_num(c.get('candle_ts'), default=0.0) if '_v510_num' in globals() else 0.0
        if candle_ts > 0:
            out['official_candle_age'] = round(max(0.0, ts - candle_ts), 1)
    # Unprefixed canonical values: short first for timing lines, but long/mid are retained in tf fields above.
    for key in V597_OFFICIAL_STRUCTURE_KEYS:
        if key in out:
            continue
        v = _v769_pick_candle_value(c, key)
        if v not in (None, ''):
            out[key] = v
    # Per-timeframe raw levels for audit/next surgery.
    for pref in _V769_TF_PREFIXES:
        label = _V769_TF_LABEL.get(pref, pref)
        for key in ('swing_high_price','swing_low_price','box_high_price','box_low_price','recent_high_price','recent_low_price'):
            v = _v769_first_existing(c, f'{pref}_{key}', f'{label}_{key}')
            if v not in (None, '', [], {}):
                out[f'{label}_{key}'] = v
    return out

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

MAIN_DEPLOY_VERSION = "v2.13.783"

VERSION = "strategy_worker_v0.801"

_V770_MATERIAL_KEYS = (
    'tf_present_by_group_v769','tf_present_counts_v769','tf_age_sec_v769',
    'short_tf_count_v769','mid_tf_count_v769','long_tf_count_v769',
    'official_structure_formula_v769',
    'candle_1m_age_sec','1m_candle_age_sec','candle_3m_age_sec','3m_candle_age_sec','candle_5m_age_sec','5m_candle_age_sec',
    'candle_15m_age_sec','15m_candle_age_sec','candle_30m_age_sec','30m_candle_age_sec',
    'candle_1h_age_sec','1h_candle_age_sec','candle_2h_age_sec','2h_candle_age_sec','candle_4h_age_sec','4h_candle_age_sec',
    '1m_swing_high_price','1m_swing_low_price','1m_box_high_price','1m_box_low_price','1m_recent_high_price','1m_recent_low_price',
    '3m_swing_high_price','3m_swing_low_price','3m_box_high_price','3m_box_low_price','3m_recent_high_price','3m_recent_low_price',
    '5m_swing_high_price','5m_swing_low_price','5m_box_high_price','5m_box_low_price','5m_recent_high_price','5m_recent_low_price',
    '15m_swing_high_price','15m_swing_low_price','15m_box_high_price','15m_box_low_price','15m_recent_high_price','15m_recent_low_price',
    '30m_swing_high_price','30m_swing_low_price','30m_box_high_price','30m_box_low_price','30m_recent_high_price','30m_recent_low_price',
    '1h_swing_high_price','1h_swing_low_price','1h_box_high_price','1h_box_low_price','1h_recent_high_price','1h_recent_low_price',
    '2h_swing_high_price','2h_swing_low_price','2h_box_high_price','2h_box_low_price','2h_recent_high_price','2h_recent_low_price',
    '4h_swing_high_price','4h_swing_low_price','4h_box_high_price','4h_box_low_price','4h_recent_high_price','4h_recent_low_price',
)

try:
    V597_OFFICIAL_STRUCTURE_KEYS = tuple(dict.fromkeys(list(V597_OFFICIAL_STRUCTURE_KEYS) + list(_V770_MATERIAL_KEYS)))  # type: ignore[assignment]
except Exception:
    pass

def _v596_official_structure_inputs__L14270(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v770_prev_official_structure_inputs(row)
    if not isinstance(out, dict):
        out = {}
    for k in _V770_MATERIAL_KEYS:
        if isinstance(row, dict) and row.get(k) not in (None, '', [], {}):
            out[k] = row.get(k)
    # If the candidate row preserved the raw pack, merge material fields from there too.
    raw = row.get('official_structure_inputs_raw') if isinstance(row.get('official_structure_inputs_raw'), dict) else {}
    for k in _V770_MATERIAL_KEYS:
        if raw.get(k) not in (None, '', [], {}) and out.get(k) in (None, '', [], {}):
            out[k] = raw.get(k)
    groups = out.get('tf_present_by_group_v769') if isinstance(out.get('tf_present_by_group_v769'), dict) else {}
    if groups:
        out['short_tf_count_v769'] = int(out.get('short_tf_count_v769') or len(groups.get('short') or []))
        out['mid_tf_count_v769'] = int(out.get('mid_tf_count_v769') or len(groups.get('mid') or []))
        out['long_tf_count_v769'] = int(out.get('long_tf_count_v769') or len(groups.get('long') or []))
    out['source_policy'] = 'v770: official multi-timeframe material preserved from candle overlay into canonical row; no threshold change'
    return out

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

MAIN_DEPLOY_VERSION = "v2.13.783"

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

MAIN_DEPLOY_VERSION = "v2.13.783"

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

MAIN_DEPLOY_VERSION = "v2.13.783"

VERSION = "strategy_worker_v0.801"

def _v773_structure_route(row: Dict[str, Any]) -> Dict[str, Any]:
    r = row if isinstance(row, dict) else {}
    react = r.get('chart_line_reaction_v772') if isinstance(r.get('chart_line_reaction_v772'), dict) else {}
    tags = [str(x) for x in (react.get('tags') if isinstance(react.get('tags'), list) else [])]
    good = [str(x) for x in (react.get('good') if isinstance(react.get('good'), list) else [])]
    risk = [str(x) for x in (react.get('risk') if isinstance(react.get('risk'), list) else [])]
    wait = [str(x) for x in (react.get('wait') if isinstance(react.get('wait'), list) else [])]
    side = str(react.get('side') or 'unknown')
    stage = _v510_stage(r) if '_v510_stage' in globals() else str(r.get('stage') or r.get('grade') or '')
    confirm_lack = []
    try:
        if _v762_num(r.get('price_reaction_pct'), r.get('change_1m_pct'), default=0.0) < 0.35:
            confirm_lack.append('가격반응 확인 대기')
        if _v762_num(r.get('buy_ratio'), default=0.0) < 0.70:
            confirm_lack.append('매수체결 확인 대기')
        if _v762_num(r.get('buy_sustain_1m'), r.get('buy_sustain'), default=0.0) < 0.70:
            confirm_lack.append('1분지속 확인 대기')
    except Exception:
        pass
    danger_words = ('저항 바로 아래 추격 주의','저항 터치 후 밀림','저항선에서 윗꼬리 밀림','지지선 이탈','VWAP·EMA 아래 구조','가짜 돌파 위험')
    strong_words = ('지지선 터치 후 반등','지지선 위에서 유지','VWAP·EMA 위 유지','박스 상단 돌파','저점 쓸림 후 회복','돌파 후 재테스트 성공','선 반응 후 매수세 확인')
    wait_words = ('저항 돌파 확인 대기','돌파 후 재테스트 대기','가격은 반응했지만 체결 확인 필요','지지선 근처 반응 대기','EMA는 지키지만 VWAP 회복 대기','저항선 근처')
    has_danger = any(any(w in t for w in danger_words) for t in (risk + tags))
    has_strong = any(any(w in t for w in strong_words) for t in (good + tags))
    has_wait = any(any(w in t for w in wait_words) for t in (wait + tags))
    if has_danger:
        route = '❌ 위험 구조: S1 보류/보류'
        simple = '위험 구조라 바로 진입 금지'
        reasons = _v510_uniq(risk[:6] + [t for t in tags if any(w in t for w in danger_words)][:4], 8)
    elif has_strong and not confirm_lack and side in ('good','mixed'):
        route = '✅ 구조 양호: S1 가능'
        simple = '구조 좋고 확인값 양호'
        reasons = _v510_uniq(good[:6], 8)
    elif has_strong or has_wait or confirm_lack:
        route = '⚠️ 구조 재확인: S2로 살림'
        simple = '구조는 볼 만하지만 확인 더 필요'
        reasons = _v510_uniq((good[:4] + wait[:4] + confirm_lack[:4]), 8)
    else:
        route = '👀 관찰 구조: S3/복기'
        simple = '뚜렷한 구조 반응 부족'
        reasons = _v510_uniq((wait[:4] + tags[:4]), 8)
    return {
        'schema': 'structure_first_route_v773',
        'route': route,
        'simple': simple,
        'reasons': reasons,
        'chart_side': side,
        'current_stage': stage,
        'confirm_lack': confirm_lack,
        'policy': 'structure-first routing advice sealed for S1/S2 review; no threshold/exit/BUY_READY change in v773',
    }

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

MAIN_DEPLOY_VERSION = "v2.13.783"

VERSION = "strategy_worker_v0.801"

STRUCTURE_OBSERVATION_QUEUE_V774 = BASE_DIR / "clean_structure_observation_queue_v774.json"

def _v774_get_structure_route(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    sources = [row]
    for k in ('entry_context','canonical_entry_snapshot','canonical_entry_snapshot_v762','structure_snapshot_v762'):
        v = row.get(k)
        if isinstance(v, dict):
            sources.append(v)
    for src in sources:
        v = src.get('structure_first_route_v773') or src.get('structure_first_route_v774')
        if isinstance(v, dict) and v:
            return v
    return _v773_structure_route(row) if '_v773_structure_route' in globals() else {}

def _v774_route_kind(route: Dict[str, Any]) -> str:
    txt = str((route or {}).get('route') or '')
    if '위험' in txt or '금지' in txt:
        return 'risk_block'
    if '양호' in txt or 'S1 가능' in txt:
        return 's1_possible'
    if '재확인' in txt or 'S2' in txt:
        return 's2_recheck'
    return 'observe'

def _v774_confirm_pass(row: Dict[str, Any]) -> bool:
    try:
        react = _v762_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'), default=0.0)
        buy = _v762_num(row.get('buy_ratio'), default=0.0)
        sustain = _v762_num(row.get('buy_sustain_1m'), row.get('buy_sustain'), row.get('buy_sustain_20s'), default=0.0)
        spread = _v762_num(row.get('spread_pct'), default=99.0)
        slip = _v762_num(row.get('slippage_pct'), row.get('spread_pct'), default=spread)
        stale = bool(row.get('stale_reasons'))
        trigger = _v732_trigger_state_for_hold(row) if '_v732_trigger_state_for_hold' in globals() else {'trigger_reached': True}
        return bool((react >= 0.30 or (react >= 0.22 and buy >= 0.78)) and buy >= 0.65 and sustain >= 0.58 and spread <= 0.35 and slip <= 0.35 and not stale and bool(trigger.get('trigger_reached', True)))
    except Exception:
        return False

def _v774_set_stage(row: Dict[str, Any], stage: str, reason: str, open_allowed: bool = False) -> None:
    for k in ('s_stage','candidate_stage','candidate_grade','stage','grade'):
        row[k] = stage
    row['open_eligible'] = bool(open_allowed and stage == 'S1')
    row['paper_bot_open'] = bool(open_allowed and stage == 'S1')
    row['trade_ready'] = bool(open_allowed and stage == 'S1')
    prev = row.get('s_stage_reasons') if isinstance(row.get('s_stage_reasons'), list) else []
    row['s_stage_reasons'] = _v510_uniq([reason] + [str(x) for x in prev], 12)
    br = row.get('block_reasons') if isinstance(row.get('block_reasons'), list) else []
    if not open_allowed:
        row['block_reasons'] = _v510_uniq([reason] + [str(x) for x in br], 14)
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx.update({'structure_route_stage_v774': stage, 'structure_route_reason_v774': reason, 'open_eligible': row.get('open_eligible')})
    row['entry_context'] = ctx

def _v732_reseal_common_uprising_promotions__L14811(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    resealed, summary = _v774_prev_reseal_common(rows, nowv)
    try:
        routed, rsum = _v774_apply_structure_routing(resealed, nowv)
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_route_apply_summary_v774'] = rsum
        return routed, summary
    except Exception as exc:
        try: append_error(ERROR, 'v774_reseal_structure_route_apply', exc)
        except Exception: pass
        return resealed, summary

def _v774_publish_observation_queue(rows: List[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    buckets = Counter(); samples=[]; q=[]
    for r in rows or []:
        if not isinstance(r, dict): continue
        t = ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol'))
        if not t: continue
        bucket, prio, target_age, reason = _v774_priority_bucket(r)
        buckets[bucket] += 1
        item={'ticker':t, 'bucket':bucket, 'priority':prio, 'required_age_sec':target_age, 'stage':_v510_stage(r), 'route':(_v774_get_structure_route(r).get('route') if isinstance(_v774_get_structure_route(r), dict) else '-'), 'reasons':reason, 'source':'strategy_structure_observation_v774'}
        q.append(item)
        if len(samples)<12: samples.append(item)
    obj={'schema':'structure_observation_queue_v774','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'count':len(q),'buckets':dict(buckets),'rows':sorted(q,key=lambda x:int(x.get('priority') or 0),reverse=True),'sample':samples,'policy':'No fixed candidate cap; priority/TTL/time-budget observation queue for structure refresh.'}
    try: save_json(STRUCTURE_OBSERVATION_QUEUE_V774, obj)
    except Exception as exc:
        try: append_error(ERROR, 'v774_observation_queue_save', exc)
        except Exception: pass
    return obj

def _v574_attach_s2_fresh_urgent_requests__L14861(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    pr, summary = _v774_prev_fresh_urgent(rows, priority_requests, nowv)
    try:
        qobj = _v774_publish_observation_queue(rows, nowv)
        seen = {ticker_norm(x.get('ticker')) for x in (pr or []) if isinstance(x, dict)}
        added = 0
        for item in qobj.get('rows') or []:
            if not isinstance(item, dict): continue
            t = ticker_norm(item.get('ticker'))
            if not t or t in seen: continue
            # Keep coverage in queue cache, but only push recheck/core/good-structure rows into router priority requests.
            if str(item.get('bucket')) == 'structure_coverage_slow':
                continue
            pr.append({'ticker':t,'priority':int(item.get('priority') or 0),'bucket':item.get('bucket'),'reason':item.get('reasons') or ['구조 관찰 큐'],'source':'structure_observation_queue_v774','required_age_sec':item.get('required_age_sec')})
            seen.add(t); added += 1
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_observation_queue_v774'] = {'count':qobj.get('count'), 'buckets':qobj.get('buckets'), 'priority_added':added}
        return pr, summary
    except Exception as exc:
        try: append_error(ERROR, 'v774_priority_queue_attach', exc)
        except Exception: pass
        return pr, summary

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

MAIN_DEPLOY_VERSION = "v2.13.783"

VERSION = "strategy_worker_v0.801"

def _v777_text_blob(row: Dict[str, Any], route: Dict[str, Any]) -> str:
    parts: List[str] = []
    try:
        for x in (route.get('reasons') or []):
            parts.append(str(x))
    except Exception:
        pass
    for key in ('chart_state_tags_v772','structure_tags','risk_tags','s_stage_reasons','block_reasons'):
        v = row.get(key)
        if isinstance(v, list):
            parts.extend(str(x) for x in v[:10])
        elif isinstance(v, str):
            parts.append(v)
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for key in ('chart_state_tags_v772','structure_tags','risk_tags'):
        v = ctx.get(key)
        if isinstance(v, list): parts.extend(str(x) for x in v[:10])
    return ' / '.join(parts)

def _v777_has_word(text: str, words: Tuple[str, ...]) -> bool:
    return any(w in text for w in words)

def _v780_structure_risk_detail(row: Dict[str, Any], route: Dict[str, Any]) -> Dict[str, Any]:
    """Split structure risk into hard block vs caution.
    Hard risk stays S3/S2 hold. Caution is allowed to S2 recheck only when structure hint + near confirmation exists.
    """
    txt = _v777_text_blob(row, route)
    hard_words = (
        '지지선 이탈', '저항 터치 후 밀림', '저항선에서 윗꼬리 밀림',
        '가짜 돌파 위험', 'VWAP·EMA 아래 구조', '윗꼬리 저항 주의',
        '매도압력 강함', '매도벽 강함'
    )
    caution_words = (
        '저항 바로 아래 추격 주의', '저항선 근처', '목표가 근처',
        '저항 돌파 확인 대기', '돌파 후 재테스트 대기', '체결 확인 필요',
        '지지선 근처 반응 대기'
    )
    try:
        spread = _v762_num(row.get('spread_pct'), default=99.0)
        slip = _v762_num(row.get('slippage_pct'), row.get('spread_pct'), default=spread)
    except Exception:
        spread = slip = 99.0
    hard_hits = [w for w in hard_words if w in txt]
    caution_hits = [w for w in caution_words if w in txt]
    if spread > 0.50 or slip > 0.50:
        hard_hits.append('스프레드/미끄러짐 과다')
    elif spread > 0.40 or slip > 0.40:
        caution_hits.append('스프레드/미끄러짐 주의')
    return {
        'schema': 'structure_risk_split_v780',
        'hard': bool(hard_hits),
        'caution': bool(caution_hits) and not bool(hard_hits),
        'hard_hits': hard_hits[:6],
        'caution_hits': caution_hits[:6],
        'spread': spread,
        'slip': slip,
    }

def _v777_s3_recheck_quality_ok(row: Dict[str, Any], route: Dict[str, Any]) -> bool:
    """S3->S2 recheck gate, corrected in v781.
    S1 remains strict elsewhere. S2 is a recheck queue, not an almost-S1 gate.
    Good/meaningful structure + no hard risk is enough for S2; missing confirmations become priority reasons.
    """
    detail = _v780_s3_recheck_detail(row, route) if '_v780_s3_recheck_detail' in globals() else {}
    return bool(detail.get('ok'))

def _v780_s3_recheck_detail(row: Dict[str, Any], route: Dict[str, Any]) -> Dict[str, Any]:
    txt = _v777_text_blob(row, route) if '_v777_text_blob' in globals() else ''
    primary_words = (
        '지지선 터치 후 반등','박스 상단 돌파','저점 쓸림 후 회복',
        '돌파 후 재테스트 성공','선 반응 후 매수세 확인','아래꼬리 회복'
    )
    support_words = ('지지선 위에서 유지','VWAP·EMA 위 유지','EMA 방어','VWAP 재회복')
    wait_words = (
        '저항 돌파 확인 대기','돌파 후 재테스트 대기',
        '가격은 반응했지만 체결 확인 필요','지지선 근처 반응 대기','저항선 근처'
    )
    try:
        react = _v762_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'), default=0.0)
        buy = _v762_num(row.get('buy_ratio'), default=0.0)
        sustain = _v762_num(row.get('buy_sustain_1m'), row.get('buy_sustain'), row.get('buy_sustain_20s'), default=0.0)
        spread = _v762_num(row.get('spread_pct'), default=99.0)
        slip = _v762_num(row.get('slippage_pct'), row.get('spread_pct'), default=spread)
    except Exception:
        react=buy=sustain=0.0; spread=slip=99.0
    risk = _v780_structure_risk_detail(row, route) if '_v780_structure_risk_detail' in globals() else {'hard': False, 'caution': False}

    confirm_hits=[]
    missing=[]
    if react >= 0.10: confirm_hits.append('가격반응 재확인권')
    else: missing.append('가격반응 부족')
    if buy >= 0.64: confirm_hits.append('매수체결 재확인권')
    else: missing.append('매수체결 부족')
    if sustain >= 0.42: confirm_hits.append('1분지속 재확인권')
    else: missing.append('1분지속 부족')

    has_primary = _v777_has_word(txt, primary_words) if '_v777_has_word' in globals() else False
    has_support = _v777_has_word(txt, support_words) if '_v777_has_word' in globals() else False
    has_wait = _v777_has_word(txt, wait_words) if '_v777_has_word' in globals() else False
    if has_support and (react >= 0.08 or buy >= 0.60 or sustain >= 0.38):
        confirm_hits.append('지지/VWAP 유지 재확인권')

    safe = spread <= 0.45 and slip <= 0.45 and not row.get('stale_reasons')
    meaningful_structure = bool(has_primary or has_support)
    wait_with_hint = bool(has_wait and len(confirm_hits) >= 1)

    # v781: S2는 매수 직전 게이트가 아니라 재확인 큐다.
    # 구조가 의미 있고 하드위험이 없으면 확인값이 여러 개 빠져도 S2로 살린다.
    # 단, 단순 대기/저항근처 같은 wait-only 구조는 확인 힌트 1개 이상이 있어야 한다.
    ok = bool((meaningful_structure or wait_with_hint) and not risk.get('hard') and safe)
    priority = 'S2상위' if len(missing) <= 1 else ('S2일반' if len(missing) == 2 else 'S2낮음')
    if not ok:
        priority = 'S3관찰'
    return {
        'schema': 's2_recheck_reason_v781',
        'ok': ok,
        'primary_reaction': has_primary,
        'support_state': has_support,
        'wait_structure': has_wait,
        'meaningful_structure': meaningful_structure,
        'wait_with_hint': wait_with_hint,
        'hard_risk': bool(risk.get('hard')),
        'caution_risk': bool(risk.get('caution')),
        'risk_hits': (risk.get('hard_hits') or risk.get('caution_hits') or [])[:5],
        'confirm_hits': confirm_hits[:5],
        'confirm_hit_count': len(confirm_hits),
        'missing_confirmations': missing[:5],
        'missing_confirm_count': len(missing),
        's2_priority': priority,
        'safe_exec': bool(safe),
        'react': react, 'buy': buy, 'sustain': sustain, 'spread': spread, 'slip': slip,
    }

def _v777_set_stage_keep_reason(row: Dict[str, Any], stage: str, reason: str, open_allowed: bool = False) -> None:
    _v774_set_stage(row, stage, reason, open_allowed) if '_v774_set_stage' in globals() else None

def _v774_apply_structure_routing(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    out: List[Dict[str, Any]] = []
    before = Counter(); after = Counter(); applied = Counter(); samples: List[Dict[str, Any]] = []
    risk_s1_blocked = good_to_s1 = good_to_s2 = s3_to_s2 = risk_to_s3 = observe_kept = weak_recheck_s3_kept = 0
    caution_to_s2 = caution_kept = hard_risk_to_s3 = 0
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = dict(src)
        before_stage = _v510_stage(r)
        before[before_stage] += 1
        route = _v774_get_structure_route(r)
        kind = _v774_route_kind(route)
        confirm_ok = _v774_confirm_pass(r)
        reason_list = route.get('reasons') if isinstance(route.get('reasons'), list) else []
        reason_text = ' / '.join(str(x) for x in reason_list[:3]) or str(route.get('simple') or route.get('route') or '구조 우선 판단')
        detail = _v780_s3_recheck_detail(r, route) if before_stage == 'S3' and '_v780_s3_recheck_detail' in globals() else {}
        risk = _v780_structure_risk_detail(r, route) if '_v780_structure_risk_detail' in globals() else {'hard': False, 'caution': False}
        action = 'kept'

        if kind == 'risk_block':
            if risk.get('hard'):
                if before_stage == 'S1':
                    _v777_set_stage_keep_reason(r, 'S2', '하드 위험 구조라 S1 보류, S2 재확인', False)
                    risk_s1_blocked += 1; action = 'hard_risk_s1_to_s2_hold'
                elif before_stage == 'S2':
                    _v777_set_stage_keep_reason(r, 'S3', '하드 위험 구조라 S2 제외, 관찰 전환', False)
                    risk_to_s3 += 1; hard_risk_to_s3 += 1; action = 'hard_risk_s2_to_s3'
                else:
                    _v777_set_stage_keep_reason(r, 'S3', '하드 위험 구조: S3 관찰', False)
                    risk_to_s3 += 1; hard_risk_to_s3 += 1; action = 'hard_risk_observe'
            else:
                # caution risk is not a buy block for S2; it is a recheck/watch state.
                if before_stage == 'S1':
                    _v777_set_stage_keep_reason(r, 'S2', '주의 구조라 S1 보류, S2 재확인', False)
                    risk_s1_blocked += 1; caution_to_s2 += 1; action = 'caution_s1_to_s2_recheck'
                elif before_stage == 'S2':
                    _v777_set_stage_keep_reason(r, 'S2', '주의 구조 S2 재확인 유지', False)
                    caution_to_s2 += 1; action = 'caution_s2_keep'
                elif before_stage == 'S3' and bool(detail.get('ok')):
                    _v777_set_stage_keep_reason(r, 'S2', '주의 구조지만 선반응/확인값 근접: S2 재확인', False)
                    s3_to_s2 += 1; caution_to_s2 += 1; action = 'caution_s3_to_s2_recheck'
                else:
                    _v777_set_stage_keep_reason(r, 'S3', '주의 구조지만 확인근거 부족: S3 관찰 유지', False)
                    caution_kept += 1; weak_recheck_s3_kept += 1; action = 'caution_s3_kept'

        elif kind == 's1_possible':
            if before_stage in ('S1','S2') and confirm_ok:
                _v777_set_stage_keep_reason(r, 'S1', '구조 양호 + 확인값 통과: S1 가능', True)
                good_to_s1 += 1; action = 'structure_good_to_s1'
            elif before_stage == 'S3' and bool(detail.get('ok')):
                _v777_set_stage_keep_reason(r, 'S2', '구조 양호 + 재확인값 근접: S2 재확인', False)
                s3_to_s2 += 1; good_to_s2 += 1; action = 'structure_good_s3_to_s2_recheck'
            elif before_stage in ('S1','S2'):
                _v777_set_stage_keep_reason(r, 'S2', '구조 양호하지만 확인값 재확인', False)
                good_to_s2 += 1; action = 'structure_good_recheck'
            else:
                _v777_set_stage_keep_reason(r, 'S3', '구조 양호하지만 확인값 부족: S3 관찰 유지', False)
                weak_recheck_s3_kept += 1; action = 'good_but_weak_s3_kept'

        elif kind == 's2_recheck':
            if before_stage == 'S3':
                if bool(detail.get('ok')):
                    _v777_set_stage_keep_reason(r, 'S2', '구조 재확인권 + 확인값 근접: S2 재확인', False)
                    s3_to_s2 += 1; action = 'structure_recheck_s3_to_s2_recheck'
                else:
                    _v777_set_stage_keep_reason(r, 'S3', '구조 재확인 후보지만 확인근거 부족: S3 관찰 유지', False)
                    weak_recheck_s3_kept += 1; action = 'weak_recheck_s3_kept'
            elif before_stage == 'S1' and not confirm_ok:
                _v777_set_stage_keep_reason(r, 'S2', '구조는 좋지만 확인값 부족: S2 재확인', False)
                action = 's1_to_s2_recheck'
            elif before_stage == 'S2':
                _v777_set_stage_keep_reason(r, 'S2', '구조 재확인 유지', False)
                action = 'recheck_keep'
            else:
                _v777_set_stage_keep_reason(r, before_stage if before_stage in ('S1','S2','S3') else 'S3', '구조 관찰 유지', False)
                action = 'recheck_observe_keep'

        else:
            observe_kept += 1
            if before_stage == 'S1':
                _v777_set_stage_keep_reason(r, 'S2', '구조 반응 확인 대기: S1 보류', False)
                action = 's1_to_s2_observe'
            elif before_stage not in ('S1','S2','S3'):
                _v777_set_stage_keep_reason(r, 'S3', '관찰 구조', False)
                action = 'observe_to_s3'

        r['structure_route_applied_v774'] = {
            'schema': 'structure_route_applied_v781',
            'before_stage': before_stage,
            'after_stage': _v510_stage(r),
            'route_kind': kind,
            'action': action,
            'confirm_pass': bool(confirm_ok),
            's2_recheck_ok': bool(detail.get('ok')) if before_stage == 'S3' else None,
            's2_recheck_detail_v780': detail if before_stage == 'S3' else {},
            'risk_split_v780': risk,
            'route': route.get('route') if isinstance(route, dict) else None,
            'reasons': reason_list[:6],
            'updated_ts': nowv,
            'policy': 'v781 S1 strict / S2 true recheck queue: missing confirmations are priority reasons, hard risk stays blocked; exits/BUY_READY/autobuy unchanged',
        }
        ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
        ctx = dict(ctx); ctx['structure_route_applied_v774'] = r['structure_route_applied_v774']; r['entry_context'] = ctx
        snap = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else r.get('canonical_entry_snapshot_v762') if isinstance(r.get('canonical_entry_snapshot_v762'), dict) else {}
        if isinstance(snap, dict):
            snap2 = dict(snap); snap2['structure_route_applied_v774'] = r['structure_route_applied_v774']; snap2['structure_first_route_v774'] = route
            r['canonical_entry_snapshot'] = snap2; r['canonical_entry_snapshot_v762'] = snap2; r['structure_snapshot_v762'] = snap2
        after[_v510_stage(r)] += 1; applied[action] += 1
        if len(samples) < 12 or _v510_stage(r) in ('S1','S2'):
            samples.append({'ticker': r.get('ticker'), 'before': before_stage, 'after': _v510_stage(r), 'action': action, 'route': route.get('route') if isinstance(route, dict) else '-', 'why': reason_text, 's2_detail': detail if isinstance(detail, dict) else {}, 'risk': risk if isinstance(risk, dict) else {}})
        out.append(r)

    s2_actions = ('structure_good_s3_to_s2_recheck','structure_recheck_s3_to_s2_recheck','caution_s3_to_s2_recheck')
    summary = {
        'schema': 'structure_route_apply_summary_v781', 'version': VERSION, 'updated_ts': nowv, 'updated_text': now_text(nowv),
        'before_stage_counts': dict(before), 'after_stage_counts': dict(after), 'action_counts': dict(applied),
        'risk_s1_blocked': risk_s1_blocked, 'risk_to_s3': risk_to_s3, 'hard_risk_to_s3': hard_risk_to_s3,
        'caution_to_s2': caution_to_s2, 'caution_kept': caution_kept,
        'structure_good_to_s1': good_to_s1, 'structure_good_to_s2': good_to_s2,
        's2_recheck_promoted': s3_to_s2, 'true_structure_s3_to_s2': s3_to_s2, 's3_to_s2': s3_to_s2,
        'weak_recheck_s3_kept': weak_recheck_s3_kept, 'observe_kept': observe_kept,
        's2_recheck_sample': [x for x in samples if str(x.get('action','')) in s2_actions][:8],
        'strict_s3_to_s2_sample': [x for x in samples if str(x.get('action','')) in s2_actions][:8],
        'sample': samples[:16],
        'policy': 'S1은 기존처럼 빡세게 유지하고, S2는 의미있는 구조+하드위험 없음이면 확인값이 여러 개 부족해도 재확인으로 살림. 부족값은 차단이 아니라 우선순위로 기록. 청산/자동매수/BUY_READY 변경 없음.',
    }
    try:
        cache = _v1115_structure_cache_load({}) or {}
        if not isinstance(cache, dict): cache = {}
        cache['structure_route_apply_summary_v774'] = summary
        cache['structure_route_apply_counts_v774'] = dict(applied)
        cache['structure_route_apply_sample_v774'] = samples[:12]
        _v1115_structure_cache_save( cache)
    except Exception as exc:
        try: append_error(ERROR, 'v781_structure_route_cache', exc)
        except Exception: pass
    return out, summary

def _v774_priority_bucket(row: Dict[str, Any]) -> Tuple[str, int, int, List[str]]:  # type: ignore[override]
    stage = _v510_stage(row)
    route = _v774_get_structure_route(row)
    kind = _v774_route_kind(route)
    if stage == 'S1' or bool(row.get('open_eligible')):
        return 'structure_core_open_s1', 990, 45, ['OPEN/S1/S1 hold 최우선 구조 갱신']
    if stage == 'S2':
        return 'structure_recheck_s2', 900, 90, ['S2/재확인 구조 자주 갱신']
    if stage == 'S3' and kind == 's1_possible' and _v777_s3_recheck_quality_ok(row, route):
        return 'structure_good_s3_watch', 800, 180, ['구조 좋은 S3 중간 갱신']
    if stage == 'S3' and kind == 's2_recheck' and _v777_s3_recheck_quality_ok(row, route):
        return 'structure_recheck_s3_watch', 760, 240, ['재확인 가치 있는 S3 순환 갱신']
    return 'structure_coverage_slow', 520, 420, ['coverage 느린 순환']

def _v788_s2_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    vals = []
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    cmr = row.get('canonical_metric_row') if isinstance(row.get('canonical_metric_row'), dict) else {}
    dec = row.get('canonical_entry_decision') if isinstance(row.get('canonical_entry_decision'), dict) else {}
    metrics = dec.get('metrics') if isinstance(dec.get('metrics'), dict) else {}
    for src in (row, ctx, cmr, metrics):
        if not isinstance(src, dict):
            continue
        for k in keys:
            vals.append(src.get(k))
    return _v510_num(*vals, default=default)

def _v788_as_list(v: Any) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    out: List[str] = []
    for x in raw:
        if isinstance(x, dict):
            txt = str(x.get('reason') or x.get('name') or x.get('value') or x.get('state') or '').strip()
        else:
            txt = str(x).strip()
        if txt and txt not in out:
            out.append(txt)
    return out

def _v788_trigger_state(row: Dict[str, Any]) -> Dict[str, Any]:
    plan = row.get('entry_plan') if isinstance(row.get('entry_plan'), dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    current = _v788_s2_num(row, 'current_price', 'entry_price', 'price', 'trade_price', default=0.0)
    trigger = _v788_s2_num(row, 'trigger_price', default=0.0)
    if trigger <= 0 and isinstance(plan, dict):
        trigger = _v510_num(plan.get('trigger_price'), default=0.0)
    reached = bool(current > 0 and trigger > 0 and current >= trigger)
    gap = round(((trigger - current) / current * 100.0), 4) if current > 0 and trigger > 0 else None
    return {
        'current_price': current,
        'trigger_price': trigger,
        'trigger_reached': reached if trigger > 0 else None,
        'trigger_gap_pct': gap,
        'trigger_reason': plan.get('trigger_reason') or ctx.get('trigger_reason'),
    }

def _v788_s2_outcome(row: Dict[str, Any], nowv: float) -> Tuple[Dict[str, Any], float]:
    dec = row.get('canonical_entry_decision') if isinstance(row.get('canonical_entry_decision'), dict) else {}
    route_applied = row.get('structure_route_applied_v774') if isinstance(row.get('structure_route_applied_v774'), dict) else {}
    route_detail = route_applied.get('s2_recheck_detail_v780') if isinstance(route_applied.get('s2_recheck_detail_v780'), dict) else {}
    risk_detail = route_applied.get('risk_split_v780') if isinstance(route_applied.get('risk_split_v780'), dict) else {}
    trigger = _v788_trigger_state(row)
    react = _v788_s2_num(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s', default=0.0)
    buy = _v788_s2_num(row, 'buy_ratio', default=0.0)
    sustain = _v788_s2_num(row, 'buy_sustain_1m', 'buy_sustain', 'buy_sustain_20s', default=0.0)
    spread = _v788_s2_num(row, 'spread_pct', default=99.0)
    slip = _v788_s2_num(row, 'slippage_pct', 'spread_pct', default=spread)
    stale = _v788_as_list(row.get('stale_reasons'))
    blocks = _v510_uniq(
        _v788_as_list(row.get('common_uprising_blocked_v732'))
        + _v788_as_list(row.get('s2_to_s1_promotion_blocked_v732'))
        + _v788_as_list(dec.get('s1_recheck_guard_reasons'))
        + _v788_as_list(row.get('s1_missing_conditions'))
        + _v788_as_list(row.get('s2_recheck_reasons')),
        12,
    )
    hard_risk = bool(risk_detail.get('hard')) or any(any(w in str(x) for w in ('하드 위험', '위험태그', '매도압력', '가짜돌파', '윗꼬리')) for x in blocks)
    exec_risk = bool(spread > 0.18 or slip > 0.20 or any(any(w in str(x) for w in ('스프레드', '미끄러짐')) for x in blocks))
    confirm_wait = bool(react < 0.35 or buy < 0.70 or sustain < 0.70 or any(any(w in str(x) for w in ('가격반응', '매수체결', '1분지속', '체결')) for x in blocks))
    trigger_wait = bool(trigger.get('trigger_reached') is False and trigger.get('trigger_price'))
    if hard_risk:
        state = 'hard_risk_hold'
        label = '하드위험 보류'
        next_action = 'observe_or_downgrade'
    elif stale:
        state = 'fresh_wait'
        label = '신선정보 재수집 대기'
        next_action = 'target_router_refresh'
    elif exec_risk:
        state = 'exec_risk_wait'
        label = '스프레드/미끄러짐 회복 대기'
        next_action = 'target_router_refresh'
    elif trigger_wait:
        state = 'trigger_wait'
        label = '방아쇠 가격 대기'
        next_action = 'target_router_refresh'
    elif confirm_wait:
        state = 'confirm_wait'
        label = '가격/체결/지속 확인 대기'
        next_action = 'target_router_refresh'
    else:
        state = 's2_recheck_active'
        label = 'S2 재확인 유지'
        next_action = 'target_router_refresh'
    structure_score = 0.0
    if route_detail.get('meaningful_structure') or route_detail.get('primary_reaction'):
        structure_score += 18.0
    if route_detail.get('support_state'):
        structure_score += 10.0
    if route_detail.get('wait_with_hint'):
        structure_score += 6.0
    confirm_score = 0.0
    confirm_score += min(18.0, max(0.0, react) * 30.0)
    confirm_score += min(14.0, max(0.0, buy - 0.45) * 40.0)
    confirm_score += min(14.0, max(0.0, sustain - 0.35) * 35.0)
    risk_penalty = 25.0 if hard_risk else (10.0 if exec_risk else 0.0)
    stale_penalty = 8.0 if stale else 0.0
    trigger_bonus = 8.0 if trigger_wait and _v510_num(trigger.get('trigger_gap_pct'), default=999.0) <= 0.35 else 0.0
    near_bonus = 8.0 if bool(row.get('s1_near_miss')) else 0.0
    score = max(0.0, 40.0 + structure_score + confirm_score + trigger_bonus + near_bonus - risk_penalty - stale_penalty)
    outcome = {
        'schema': 's2_recheck_outcome_v788',
        'version': VERSION,
        'updated_ts': nowv,
        'state': state,
        'label': label,
        'next_action': next_action,
        'metrics': {'price_reaction_pct': react, 'buy_ratio': buy, 'buy_sustain_1m': sustain, 'spread_pct': spread, 'slippage_pct': slip},
        'trigger': trigger,
        'block_reasons': blocks[:10],
        'stale_reasons': stale[:6],
        'structure_route_action': route_applied.get('action'),
        'structure_recheck_detail': route_detail,
        'risk_detail': risk_detail,
        'policy': 'S1 기준값 변경 없음. 구조 라우팅 후 S2 재확인 결과/다음 액션만 canonical row에 확정 저장.',
    }
    return outcome, round(score, 3)

def _v788_attach_s2_recheck_outcome_spine(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    counts: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = dict(src)
        st = _v510_stage(r)
        if st == 'S1' and bool(r.get('open_eligible')):
            r['s2_recheck_last_state_v788'] = 'promoted_s1'
            r['s2_recheck_outcome_v788'] = {'schema': 's2_recheck_outcome_v788', 'version': VERSION, 'updated_ts': nowv, 'state': 'promoted_s1', 'label': 'S1 승격 완료', 'next_action': 'paper_handoff'}
            counts['promoted_s1'] += 1
        elif st == 'S2':
            outcome, score = _v788_s2_outcome(r, nowv)
            state = str(outcome.get('state') or 's2_recheck_active')
            counts[state] += 1
            r['s2_recheck_outcome_v788'] = outcome
            r['s2_recheck_last_state_v788'] = state
            r['recheck_state'] = 'S2 재확인'
            old_reasons = _v788_as_list(r.get('s2_recheck_reasons'))
            state_reason = str(outcome.get('label') or state)
            r['s2_recheck_reasons'] = _v510_uniq(old_reasons + [f'v788:{state_reason}'], 10)
            r['recheck_score'] = max(_v510_num(r.get('recheck_score'), r.get('score'), default=0.0), score)
            gate_blocks = _v788_as_list(outcome.get('block_reasons')) or _v788_as_list(r.get('s1_missing_conditions'))
            r['s1_promotion_gate'] = {
                'schema': 's1_promotion_gate_v788',
                'version': VERSION,
                'updated_ts': nowv,
                'pass': False,
                'state': state,
                'block_reasons': gate_blocks[:10],
                'next_action': outcome.get('next_action'),
                'recheck_score': r.get('recheck_score'),
            }
            rel = r.get('relative_context') if isinstance(r.get('relative_context'), dict) else {}
            rel = dict(rel)
            rel['missing'] = _v510_uniq(_v788_as_list(rel.get('missing')) + gate_blocks[:8], 12)
            rel['s2_recheck_state_v788'] = state
            r['relative_context'] = rel
            ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
            ctx = dict(ctx)
            ctx['s2_recheck_outcome_v788'] = outcome
            ctx['s1_promotion_gate'] = r['s1_promotion_gate']
            r['entry_context'] = ctx
            if len(samples) < 12:
                samples.append({'ticker': ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')), 'state': state, 'score': r.get('recheck_score'), 'blocks': gate_blocks[:4], 'metrics': outcome.get('metrics'), 'trigger': outcome.get('trigger')})
        out.append(r)
    return out, {
        'schema': 's2_recheck_outcome_summary_v788',
        'version': VERSION,
        'updated_ts': nowv,
        'counts': dict(counts),
        'samples': samples,
        'policy': '구조 라우팅으로 S2가 된 후보의 재확인 결과를 같은 canonical row에 저장하고 target_router가 읽을 gate/recheck_score를 단일화. 조건값/청산/자동매수 변경 없음.',
    }

BUILD_LABEL = "strategy_worker_v0.801_integrated_validation_freshness_2026-06-10"

VERSION = "strategy_worker_v0.801"

def _v789_is_observe_only(row: Dict[str, Any]) -> bool:
    return bool(
        row.get("s3_observe_v732") or row.get("s3_observe_v730") or row.get("s3_observe_v729")
        or row.get("s3_observe_v728") or row.get("s3_observe_v727")
        or str(row.get("strategy_key") or "").startswith("coin_quality_s3_observe")
    )

def _v789_blocks_from(row: Dict[str, Any]) -> List[str]:
    dec = row.get("canonical_entry_decision") if isinstance(row.get("canonical_entry_decision"), dict) else {}
    return _v510_uniq(
        _v788_as_list(row.get("s2_to_s1_promotion_blocked_v732"))
        + _v788_as_list(row.get("common_uprising_blocked_v732"))
        + _v788_as_list(row.get("s1_missing_conditions"))
        + _v788_as_list(row.get("s2_recheck_reasons"))
        + _v788_as_list(dec.get("display_reasons")),
        12,
    )

def _v789_seal_post_route_s1(row: Dict[str, Any], nowv: float, source_stage: str) -> Dict[str, Any]:
    r = dict(row)
    for k in ("created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "updated_ts"):
        r[k] = nowv
    try:
        r["expires_at"] = nowv + max(60.0, float(CANDIDATE_TTL_SEC or 90))
    except Exception:
        r["expires_at"] = nowv + 90.0
    r["promoted_at_v789"] = nowv
    r["promoted_at_text_v789"] = now_text(nowv)
    r["promotion_spine_v789"] = "post_structure_route_rejudged_to_s1"
    r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S1"
    r["open_eligible"] = True
    r["paper_bot_open"] = True
    r["trade_ready"] = True
    r["s2_recheck_last_state_v788"] = "promoted_s1"
    r["s2_recheck_outcome_v788"] = {
        "schema": "s2_recheck_outcome_v788",
        "version": VERSION,
        "updated_ts": nowv,
        "state": "promoted_s1",
        "label": "S1 승격 완료",
        "next_action": "paper_handoff",
        "source": "v789_post_structure_route_rejudge",
    }
    r["s1_promotion_gate"] = {
        "schema": "s1_promotion_gate_v789",
        "version": VERSION,
        "updated_ts": nowv,
        "pass": True,
        "state": "promoted_s1",
        "block_reasons": [],
        "next_action": "paper_handoff",
        "source_stage_before_rejudge": source_stage,
    }
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx.update({
        "promotion_spine_v789": r["promotion_spine_v789"],
        "promoted_at_v789": nowv,
        "stage_after_promotion_v789": "S1",
        "open_eligible": True,
        "s2_recheck_outcome_v788": r["s2_recheck_outcome_v788"],
        "s1_promotion_gate": r["s1_promotion_gate"],
    })
    r["entry_context"] = ctx
    return r

def _v789_post_structure_route_rejudge(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    counts: Counter = Counter()
    block_top: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        before = _v510_stage(src)
        r = dict(src)
        route = r.get("structure_route_applied_v774") if isinstance(r.get("structure_route_applied_v774"), dict) else {}
        action = str(route.get("action") or "")
        should_rejudge = bool(before == "S2" and not _v789_is_observe_only(r))
        if should_rejudge:
            counts["target"] += 1
            judged = _v532_apply_canonical_entry_decision(dict(r))
            after = _v510_stage(judged)
            if after == "S1" and bool(judged.get("open_eligible")) and bool(judged.get("common_uprising_pass_v732") or judged.get("common_entry_pass")):
                judged = _v789_seal_post_route_s1(judged, nowv, before)
                counts["promoted_s1"] += 1
            else:
                if _v510_stage(judged) == "S2":
                    counts["kept_s2"] += 1
                else:
                    counts["downgraded_or_observe"] += 1
                blocks = _v789_blocks_from(judged) or ["S1 승급 조건 미통과"]
                for b in blocks[:5]:
                    block_top[str(b)] += 1
                gate = judged.get("s1_promotion_gate") if isinstance(judged.get("s1_promotion_gate"), dict) else {}
                gate = dict(gate)
                gate.update({
                    "schema": "s1_promotion_gate_v789",
                    "version": VERSION,
                    "updated_ts": nowv,
                    "pass": False,
                    "state": str(judged.get("s2_recheck_last_state_v788") or gate.get("state") or "confirm_wait"),
                    "block_reasons": blocks[:10],
                    "next_action": gate.get("next_action") or "target_router_refresh",
                    "source": "v789_post_structure_route_rejudge",
                    "source_stage_before_rejudge": before,
                })
                judged["s1_promotion_gate"] = gate
                ctx = judged.get("entry_context") if isinstance(judged.get("entry_context"), dict) else {}
                ctx = dict(ctx)
                ctx["s1_promotion_gate"] = gate
                ctx["post_structure_rejudge_v789"] = True
                judged["entry_context"] = ctx
            if len(samples) < 12:
                samples.append({
                    "ticker": ticker_norm(judged.get("ticker") or judged.get("market") or judged.get("symbol")),
                    "before": before,
                    "after": _v510_stage(judged),
                    "action": action,
                    "common_pass": bool(judged.get("common_uprising_pass_v732")),
                    "promoted": bool(judged.get("s2_to_s1_promoted_v732")),
                    "blocks": _v789_blocks_from(judged)[:4],
                })
            r = judged
        out.append(r)
    return out, {
        "schema": "post_structure_route_s1_rejudge_v789",
        "version": VERSION,
        "updated_ts": nowv,
        "updated_text": now_text(nowv),
        "counts": dict(counts),
        "blocked_top": dict(block_top.most_common(8)),
        "sample": samples,
        "policy": "구조 라우팅으로 S2가 된 후보를 같은 cycle에서 canonical S1 승급판에 다시 태움. 조건값/청산/자동매수/BUY_READY 변경 없음.",
    }

def _v732_reseal_common_uprising_promotions__L15544(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    # _v789_prev_reseal_common은 v774까지의 본선: base v732 reseal → structure routing.
    routed, summary = _v789_prev_reseal_common(rows, nowv)
    try:
        rejudged, rejudge_summary = _v789_post_structure_route_rejudge(routed, nowv)
        final_rows, outcome_summary = _v788_attach_s2_recheck_outcome_spine(rejudged, nowv)
        if isinstance(summary, dict):
            summary = dict(summary)
            summary["post_structure_route_s1_rejudge_v789"] = rejudge_summary
            summary["s2_recheck_outcome_summary_v789"] = outcome_summary
        return final_rows, summary
    except Exception as exc:
        try: append_error(ERROR, "v789_post_structure_route_rejudge", exc)
        except Exception: pass
        return routed, summary

def _v792_blob(row: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in (
        'strategy_label','strategy','strategy_key','entry_reasons','entry_basis','matched_strategy_labels',
        'matched_strategy_keys','structure_tags','entry_structure_tags','risk_tags','structure_risk_tags',
        'execution_risk_tags','s_stage_reasons','block_reasons','s2_recheck_reasons','s1_missing_conditions'
    ):
        v = row.get(k)
        if isinstance(v, list):
            parts += [str(x) for x in v]
        elif isinstance(v, dict):
            parts += [str(x) for x in v.values()]
        elif v not in (None, ''):
            parts.append(str(v))
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in ('entry_structure_tags','risk_tags','structure_tags','entry_basis'):
        v = ctx.get(k)
        if isinstance(v, list): parts += [str(x) for x in v]
        elif v not in (None, ''): parts.append(str(v))
    return ' '.join(parts)

def _v794_first_nonempty(row: Dict[str, Any], keys: List[str], default: Any = '') -> Any:
    for k in keys:
        v = row.get(k)
        if v not in (None, '', [], {}):
            return v
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    for k in keys:
        v = ctx.get(k)
        if v not in (None, '', [], {}):
            return v
    sb = row.get('source_basis') if isinstance(row.get('source_basis'), dict) else {}
    for k in keys:
        v = sb.get(k)
        if v not in (None, '', [], {}):
            return v
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    for k in keys:
        v = levels.get(k)
        if v not in (None, '', [], {}):
            return v
    return default

def _v794_line_quality(row: Dict[str, Any]) -> str:
    q = str(_v794_first_nonempty(row, [
        'line_quality_v794','structure_line_quality','structure_line_quality_v762','line_quality_v762','line_quality','reliability','structure_line_reliability'
    ], '') or '')
    if not q or q in ('-', 'None'):
        return 'missing_line'
    ql = q.lower()
    if any(x in q for x in ('무효', '의심', 'invalid')) or 'invalid' in ql:
        return 'invalid_or_suspect_line'
    if any(x in q for x in ('stale', '오래', 'old')) or 'stale' in ql:
        return 'stale_line'
    if any(x in q for x in ('official', '공식', '확실', 'confirmed')) or 'official' in ql:
        return 'confirmed_line'
    if any(x in q for x in ('reactive', 'reaction', '반응')) or 'reactive' in ql:
        return 'reactive_line'
    if any(x in q for x in ('calculated', '계산', '임시')) or 'calculated' in ql:
        return 'calculated_line_recheck'
    if any(x in q for x in ('weak', '부족')) or 'weak' in ql:
        return 'weak_line'
    return q[:60]

def _v794_buy_sustain_source(row: Dict[str, Any], sustain: float) -> str:
    real = row.get('buy_sustain_1m_real')
    if real is True:
        return 'measured'
    if real is False:
        return 'estimated_or_missing'
    src = str(_v794_first_nonempty(row, ['buy_sustain_source','buy_sustain_1m_source','orderflow_source','micro_source'], '') or '')
    if src:
        return src[:60]
    if sustain == 0:
        return 'zero_unknown_source'
    return 'source_unknown'

def _v794_line_reaction_tags(row: Dict[str, Any], blob: str, react: float, ch3: float, ch5: float, buy: float, sustain: float, vwap: float, ema: float) -> List[str]:
    tags: List[str] = []
    if ('지지' in blob or '저점' in blob or '쓸림' in blob) and react >= 0.12 and (buy >= 0.55 or sustain >= 0.55):
        tags.append('지지·저점선반응')
    if ('저항' in blob or '돌파' in blob or '박스상단' in blob) and react >= 0.18 and ch3 >= -0.05:
        tags.append('저항돌파후유지')
    if ('재테스트' in blob or '지지전환' in blob) and react >= 0.10 and sustain >= 0.55:
        tags.append('돌파후재테스트반응')
    if (vwap >= -0.03 and ema >= -0.05 and sustain >= 0.55):
        tags.append('VWAP·EMA선방어')
    if react >= 0.35 and (ch3 < 0.05 or ch5 < 0.05):
        tags.append('초반반응후후속약함')
    if react <= 0.03 and buy >= 0.75 and sustain >= 0.75:
        tags.append('체결대비가격무반응')
    return _v510_uniq(tags, 8)

def _v794_structure_interpretation(good: List[str], risk: List[str], fail: List[str], line_reaction: List[str], line_quality: str) -> str:
    if line_quality in ('invalid_or_suspect_line','stale_line'):
        return '선품질재확인'
    if line_reaction and good and not fail:
        return '선반응양호'
    if line_reaction and fail:
        return '선반응있지만후속약함'
    if good and not fail:
        return '구조양호관찰'
    if fail:
        return '실패패턴주의'
    if line_quality in ('missing_line','weak_line','calculated_line_recheck'):
        return '구조선근거재확인'
    return '중립구조'

def _v792_quality_tags(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    blob = _v792_blob(row)
    react = _v788_s2_num(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s', 'change_1m', 'price_change_1m', default=0.0)
    ch3 = _v788_s2_num(row, 'change_3m', 'price_change_3m', 'change_3m_pct', default=0.0)
    ch5 = _v788_s2_num(row, 'change_5m', 'price_change_5m', 'change_5m_pct', default=0.0)
    ch15 = _v788_s2_num(row, 'change_15m', 'price_change_15m', default=0.0)
    ch30 = _v788_s2_num(row, 'change_30m', 'price_change_30m', default=0.0)
    buy = _v788_s2_num(row, 'buy_ratio', default=0.0)
    sustain = _v788_s2_num(row, 'buy_sustain_1m', 'buy_sustain', 'buy_sustain_20s', default=0.0)
    spread = _v788_s2_num(row, 'spread_pct', default=99.0)
    slip = _v788_s2_num(row, 'slippage_pct', 'spread_pct', default=spread)
    vwap = _v788_s2_num(row, 'vwap_gap_pct', default=0.0)
    ema = _v788_s2_num(row, 'ema5_gap_pct', 'ma5_gap_pct', default=0.0)
    rel = _v788_s2_num(row, 'relative_strength_pct', 'relative_strength', default=0.0)
    high_gap = _v788_s2_num(row, 'recent_high_gap_pct', 'below_high_pct', default=-9.0)
    low_rebound = _v788_s2_num(row, 'recent_low_rebound_pct', default=0.0)
    market_mode = str(row.get('market_mode') or row.get('market_regime') or row.get('market_state') or '')
    weak_market = bool(('약' in market_mode) or ('weak' in market_mode.lower()) or (rel >= 0.45 and ch3 >= 0.0 and ch5 >= 0.0 and ch15 < 0.25))

    good: List[str] = []
    risk: List[str] = []
    fail: List[str] = []
    early: List[str] = []
    line_quality = _v794_line_quality(row)
    sustain_source = _v794_buy_sustain_source(row, sustain)

    if vwap >= -0.03 and ema >= -0.05 and (buy >= 0.65 or sustain >= 0.65):
        good.append('VWAP/EMA방어+체결유지')
    if ('저점' in blob or '쓸림' in blob or low_rebound >= 0.35) and vwap >= -0.05 and buy >= 0.60:
        good.append('저점쓸림후회복')
    if ('재테스트' in blob or '지지전환' in blob or '박스상단' in blob or '돌파후유지' in blob) and react >= 0.15 and sustain >= 0.55:
        good.append('돌파후재테스트/지지전환')
    if ('돈흐름' in blob or '거래량' in blob or '재유입' in blob) and ch3 >= 0.10 and ch5 >= 0.10 and buy >= 0.60:
        good.append('돈흐름재유입')
    if weak_market and ((react >= 0.25 and buy >= 0.60) or (ch3 >= 0.20 and ch5 >= 0.20) or rel >= 0.80):
        good.append('약장상대강도')
    if ch15 >= 0.7 and ch30 >= 0.4 and vwap >= 0 and ema >= 0:
        good.append('주도흐름유지')

    if '윗꼬리' in blob or '저항' in blob and high_gap >= -0.05:
        risk.append('윗꼬리/저항추격주의')
    if vwap < -0.12 or ema < -0.18:
        risk.append('VWAP/EMA하단구조')
    if react <= 0.05 and buy >= 0.80 and sustain >= 0.80:
        fail.append('체결높은데가격무반응')
        early.append('진입후1~2분무반응빠른확인')
    if react >= 0.35 and (ch3 < 0.05 or ch5 < 0.05) and sustain < 0.62:
        fail.append('1분반응후3/5분약화')
    if spread > 0.30 or slip > 0.32:
        risk.append('실행비용높음')
    if spread > 0.18 or slip > 0.20:
        if buy >= 0.75 and sustain >= 0.70 and react >= 0.20 and not any('매도압력' in x for x in _v788_as_list(row.get('risk_tags'))):
            exec_class = 'spread_only_recheckable'
            exec_label = '스프레드만 회복 대기'
        elif spread > 0.35 or slip > 0.35 or buy < 0.55:
            exec_class = 'hard_exec_risk'
            exec_label = '실행위험 큼'
        else:
            exec_class = 'exec_recheck'
            exec_label = '실행위험 재확인'
    else:
        exec_class = 'exec_ok'
        exec_label = '실행위험 정상권'

    # v794: 구조 실패패턴은 차단문이 아니라 선 반응/복기/빠른확인 태그다.
    # 진짜 차단은 기존 하드위험·실행위험 경로가 담당한다. 여기서는 S1 조건값을 직접 바꾸지 않는다.
    line_reaction = _v794_line_reaction_tags(row, blob, react, ch3, ch5, buy, sustain, vwap, ema)
    structure_interpretation = _v794_structure_interpretation(good, risk, fail, line_reaction, line_quality)
    fail_score = len(fail) + (1 if 'VWAP/EMA하단구조' in risk else 0) + (1 if '윗꼬리/저항추격주의' in risk and react < 0.20 else 0)
    s1_block = False

    return {
        'schema': 'structure_quality_v794',
        'version': VERSION,
        'updated_ts': nowv,
        'good_tags': _v510_uniq(good, 8),
        'risk_tags': _v510_uniq(risk, 8),
        'failure_pattern_tags': _v510_uniq(fail, 8),
        'early_fail_watch_tags': _v510_uniq(early, 6),
        'weak_market_relative_strength': bool('약장상대강도' in good),
        'line_quality_v794': line_quality,
        'line_reaction_tags_v794': line_reaction,
        'structure_interpretation_v794': structure_interpretation,
        'buy_sustain_source_v794': sustain_source,
        'failure_pattern_score_v794': fail_score,
        'exec_risk_class': exec_class,
        'exec_risk_label': exec_label,
        's1_structure_block_candidate': s1_block,
        'metrics': {'react': react, 'ch3': ch3, 'ch5': ch5, 'ch15': ch15, 'ch30': ch30, 'buy': buy, 'sustain': sustain, 'spread': spread, 'slippage': slip, 'vwap_gap_pct': vwap, 'ema5_gap_pct': ema, 'relative_strength_pct': rel},
        'policy': '구조태그는 차단문이 아니라 선 품질/선 반응/복기 태그로 사용. 조건 완화 없음.',
    }

def _v792_apply_quality_to_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    q = _v792_quality_tags(r, nowv)
    r['structure_quality_v792'] = q
    r['structure_good_tags_v792'] = q.get('good_tags') or []
    r['structure_failure_tags_v792'] = q.get('failure_pattern_tags') or []
    r['early_fail_watch_tags_v792'] = q.get('early_fail_watch_tags') or []
    r['exec_risk_class_v792'] = q.get('exec_risk_class')
    r['weak_market_relative_strength_v792'] = bool(q.get('weak_market_relative_strength'))
    r['line_quality_v794'] = q.get('line_quality_v794')
    r['line_reaction_tags_v794'] = q.get('line_reaction_tags_v794') or []
    r['structure_interpretation_v794'] = q.get('structure_interpretation_v794')
    r['buy_sustain_source_v794'] = q.get('buy_sustain_source_v794')
    r['structure_warning_tags_v794'] = _v510_uniq(_v788_as_list(q.get('risk_tags')) + _v788_as_list(q.get('failure_pattern_tags')), 12)

    if q.get('good_tags'):
        r['structure_tags'] = _v510_uniq(_v788_as_list(r.get('structure_tags')) + _v788_as_list(q.get('good_tags')), 14)
    if q.get('risk_tags'):
        r['risk_tags'] = _v510_uniq(_v788_as_list(r.get('risk_tags')) + _v788_as_list(q.get('risk_tags')), 14)
    # v794: failure_pattern_tags는 risk_tags에 섞어 하드차단처럼 쓰지 않고 별도 주의/복기 태그로 둔다.
    if q.get('failure_pattern_tags'):
        r['review_tags_v794'] = _v510_uniq(_v788_as_list(r.get('review_tags_v794')) + _v788_as_list(q.get('failure_pattern_tags')), 14)
    if _v510_stage(r) == 'S2':
        add_reasons: List[str] = []
        if q.get('good_tags'):
            add_reasons.append('v792:좋은구조 ' + '/'.join(_v788_as_list(q.get('good_tags'))[:2]))
        if q.get('weak_market_relative_strength'):
            add_reasons.append('v792:약장상대강도 재확인가치')
        if q.get('exec_risk_class') in ('spread_only_recheckable', 'exec_recheck'):
            add_reasons.append('v792:' + str(q.get('exec_risk_label')))
        if q.get('failure_pattern_tags'):
            add_reasons.append('v792:실패패턴주의 ' + '/'.join(_v788_as_list(q.get('failure_pattern_tags'))[:2]))
        if add_reasons:
            r['s2_recheck_reasons'] = _v510_uniq(_v788_as_list(r.get('s2_recheck_reasons')) + add_reasons, 12)
    gate = r.get('s1_promotion_gate') if isinstance(r.get('s1_promotion_gate'), dict) else {}
    gate = dict(gate)
    # v794: 구조 실패패턴은 S1 보류문으로 쓰지 않는다. 기존 공통 단타/S1 gate는 그대로 두고,
    # 선 품질·반응·실패패턴만 warning/source로 남긴다.
    if q.get('failure_pattern_tags') or q.get('line_reaction_tags_v794') or q.get('line_quality_v794'):
        gate['line_quality_v794'] = q.get('line_quality_v794')
        gate['line_reaction_tags_v794'] = q.get('line_reaction_tags_v794') or []
        gate['structure_interpretation_v794'] = q.get('structure_interpretation_v794')
        gate['structure_warning_tags_v794'] = _v510_uniq(_v788_as_list(q.get('risk_tags')) + _v788_as_list(q.get('failure_pattern_tags')), 12)
        gate['source_v794'] = 'line_quality_reaction_note_only'
        r['s1_promotion_gate'] = gate
    outcome = r.get('s2_recheck_outcome_v788') if isinstance(r.get('s2_recheck_outcome_v788'), dict) else {}
    if outcome:
        outcome = dict(outcome)
        outcome['exec_risk_class_v792'] = q.get('exec_risk_class')
        outcome['exec_risk_label_v792'] = q.get('exec_risk_label')
        outcome['structure_good_tags_v792'] = q.get('good_tags') or []
        outcome['failure_pattern_tags_v792'] = q.get('failure_pattern_tags') or []
        outcome['line_quality_v794'] = q.get('line_quality_v794')
        outcome['line_reaction_tags_v794'] = q.get('line_reaction_tags_v794') or []
        outcome['structure_interpretation_v794'] = q.get('structure_interpretation_v794')
        outcome['buy_sustain_source_v794'] = q.get('buy_sustain_source_v794')
        if str(outcome.get('state') or '') == 'exec_risk_wait' and q.get('exec_risk_label'):
            outcome['label'] = str(q.get('exec_risk_label'))
        r['s2_recheck_outcome_v788'] = outcome
    ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['structure_quality_v792'] = q
    r['entry_context'] = ctx
    return r

def _v792_attach_structure_quality_spine(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    good_top: Counter = Counter()
    risk_top: Counter = Counter()
    fail_top: Counter = Counter()
    exec_top: Counter = Counter()
    line_quality_top: Counter = Counter()
    line_reaction_top: Counter = Counter()
    interpretation_top: Counter = Counter()
    sustain_source_top: Counter = Counter()
    weak_rel = 0
    s1_fail_block = 0
    samples: List[Dict[str, Any]] = []
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        r = _v792_apply_quality_to_row(src, nowv)
        q = r.get('structure_quality_v792') if isinstance(r.get('structure_quality_v792'), dict) else {}
        for x in _v788_as_list(q.get('good_tags')): good_top[x] += 1
        for x in _v788_as_list(q.get('risk_tags')): risk_top[x] += 1
        for x in _v788_as_list(q.get('failure_pattern_tags')): fail_top[x] += 1
        if q.get('exec_risk_class'): exec_top[str(q.get('exec_risk_class'))] += 1
        if q.get('line_quality_v794'): line_quality_top[str(q.get('line_quality_v794'))] += 1
        for x in _v788_as_list(q.get('line_reaction_tags_v794')): line_reaction_top[str(x)] += 1
        if q.get('structure_interpretation_v794'): interpretation_top[str(q.get('structure_interpretation_v794'))] += 1
        if q.get('buy_sustain_source_v794'): sustain_source_top[str(q.get('buy_sustain_source_v794'))] += 1
        if q.get('weak_market_relative_strength'): weak_rel += 1
        if q.get('s1_structure_block_candidate'): s1_fail_block += 1
        if len(samples) < 10 and (_v510_stage(r) in ('S1','S2')):
            samples.append({'ticker': ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')), 'stage': _v510_stage(r), 'good': _v788_as_list(q.get('good_tags'))[:3], 'warn': _v788_as_list(q.get('failure_pattern_tags'))[:3], 'exec': q.get('exec_risk_class'), 'line_quality': q.get('line_quality_v794'), 'line_reaction': _v788_as_list(q.get('line_reaction_tags_v794'))[:2], 'interpretation': q.get('structure_interpretation_v794'), 'weak_rel': q.get('weak_market_relative_strength')})
        out.append(r)
    return out, {
        'schema': 'structure_quality_summary_v794',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'good_top': dict(good_top.most_common(8)),
        'risk_top': dict(risk_top.most_common(8)),
        'failure_top': dict(fail_top.most_common(8)),
        'exec_risk_class_top': dict(exec_top.most_common(8)),
        'line_quality_top_v794': dict(line_quality_top.most_common(8)),
        'line_reaction_top_v794': dict(line_reaction_top.most_common(8)),
        'structure_interpretation_top_v794': dict(interpretation_top.most_common(8)),
        'buy_sustain_source_top_v794': dict(sustain_source_top.most_common(8)),
        'weak_market_relative_strength_count': weak_rel,
        's1_structure_block_candidate_count': s1_fail_block,
        'samples': samples,
        'policy': '조건 완화 없음. 구조태그는 S1 보류문이 아니라 선 품질/선 반응/복기 태그로 저장.',
    }

def _v732_reseal_common_uprising_promotions__L15896(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    sealed, summary = _v792_prev_reseal_common(rows, nowv)
    try:
        refined, q_summary = _v792_attach_structure_quality_spine(sealed, nowv)
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_quality_summary_v792'] = q_summary
        return refined, summary
    except Exception as exc:
        try: append_error(ERROR, 'v792_structure_quality_spine', exc)
        except Exception: pass
        return sealed, summary

VERSION = "strategy_worker_v0.801"

BUILD_LABEL = "v802_common_scalp_pattern_lab_2026-06-09"

def _v796_num(*vals: Any, default: float = 0.0) -> float:
    return _v510_num(*vals, default=default)

def _v796_pct(a: float, b: float) -> float:
    try:
        if a and b:
            return (float(a) - float(b)) / float(b) * 100.0
    except Exception:
        pass
    return 0.0

def _v796_basis_dict(row: Dict[str, Any], key: str) -> Dict[str, Any]:
    v = row.get(key)
    return v if isinstance(v, dict) else {}

def _v796_line_quality(row: Dict[str, Any], q: Dict[str, Any]) -> str:
    return str(q.get('line_quality_v794') or row.get('line_quality_v794') or row.get('structure_line_quality_v762') or '')

def _v796_current_plan_inputs(row: Dict[str, Any]) -> Dict[str, Any]:
    levels = _v796_basis_dict(row, 'structure_levels')
    basis = _v796_basis_dict(row, 'canonical_entry_basis_v764')
    pb = basis.get('price_basis') if isinstance(basis.get('price_basis'), dict) else {}
    rr = _v796_basis_dict(row, 'risk_reward')
    ctx = _v796_basis_dict(row, 'entry_context')
    entry = _v796_num(row.get('entry_price'), row.get('current_price'), row.get('price'), pb.get('entry_price'), ctx.get('entry_price'), default=0.0)
    current = _v796_num(row.get('current_price'), row.get('price'), pb.get('current_price'), entry, default=entry)
    trigger = _v796_num(row.get('trigger_price'), levels.get('trigger_price'), levels.get('trigger'), pb.get('trigger_price'), ctx.get('trigger_price'), default=0.0)
    invalid = _v796_num(row.get('invalid_price'), row.get('structure_stop_price'), row.get('stop_price'), levels.get('invalid_price'), levels.get('stop_price'), levels.get('support_price'), pb.get('invalid_price'), ctx.get('invalid_price'), default=0.0)
    target1 = _v796_num(row.get('target1_price'), row.get('target_price'), levels.get('target1_price'), levels.get('target_price'), levels.get('resistance_price'), pb.get('target1_price'), ctx.get('target1_price'), default=0.0)
    target2 = _v796_num(row.get('target2_price'), levels.get('target2_price'), pb.get('target2_price'), ctx.get('target2_price'), default=0.0)
    rr_ratio = _v796_num(rr.get('rr_ratio'), levels.get('rr_ratio'), pb.get('rr_ratio'), row.get('rr_ratio'), default=0.0)
    return {'entry': entry, 'current': current, 'trigger': trigger, 'invalid': invalid, 'target1': target1, 'target2': target2, 'rr_ratio_raw': rr_ratio}

def _v801_blob(row: Dict[str, Any], q: Dict[str, Any]) -> str:
    parts: List[str] = []
    for key in ('strategy_key', 'paper_strategy_key', 'strategy', 'strategy_label', 'structure_interpretation_v794', 'structure_line_quality_v762'):
        v = row.get(key)
        if v not in (None, ''):
            parts.append(str(v))
    for key in ('line_reaction_tags_v794', 'structure_good_tags_v792', 'structure_failure_tags_v792', 'risk_tags'):
        for x in _v788_as_list(q.get(key) or row.get(key)):
            parts.append(str(x))
    return ' / '.join(parts)

def _v801_structure_archetype(row: Dict[str, Any], q: Dict[str, Any], line_quality: str, line_reaction: List[Any], good: List[Any], warn: List[Any]) -> str:
    blob = _v801_blob(row, q)
    if '박스' in blob:
        return 'box_breakout_hold'
    if any(k in blob for k in ('저항돌파후유지', '돌파후재테스트', '지지전환', '박스상단돌파')):
        return 'breakout_hold'
    if any(k in blob for k in ('VWAP·EMA선방어', 'VWAP/EMA방어', 'EMA방어', 'VWAP 위', 'EMA 유지')):
        return 'vwap_ema_hold'
    if any(k in blob for k in ('지지선 근처', '지지선 터치 후 반등', '저점쓸림', '저점 쓸림', '쓸림후회복', '저점유동성')):
        return 'support_rebound'
    fam = _v554_strategy_family(row)
    if fam in ('sweep_vwap',):
        return 'support_rebound'
    if fam in ('leader_flow', 'money_reaccel'):
        return 'vwap_ema_hold'
    if fam in ('breakout', 'surge_rebreak', 'hot_rank', 'leader_momentum'):
        return 'breakout_hold'
    if line_quality == 'calculated_line_recheck' and not line_reaction:
        return 'calculated_recheck'
    return 'common_structure'

def _v801_adjust_structure_trigger(row: Dict[str, Any], q: Dict[str, Any], inp: Dict[str, Any], line_quality: str, line_reaction: List[Any], good: List[Any], warn: List[Any]) -> Dict[str, Any]:
    current = float(inp.get('current') or inp.get('entry') or 0.0)
    old_trigger = float(inp.get('trigger') or 0.0)
    trigger = old_trigger
    archetype = _v801_structure_archetype(row, q, line_quality, line_reaction, good, warn)
    line_strong = bool(line_quality in ('confirmed_line', 'reactive_line') or line_reaction)
    calc_only = bool(line_quality == 'calculated_line_recheck' and not line_reaction)
    notes: List[str] = []
    policy = '기존 방아쇠 유지'
    if current > 0:
        near_current = current
        small_wait = current * 1.0006
        # 지지선 반등/VWAP·EMA 방어는 선 근처에서 잡고, 선 깨지면 빠르게 실패를 본다.
        # old trigger가 위로 너무 멀면 구조와 맞지 않아 S1을 계속 대기시키므로 구조별로 당긴다.
        if archetype in ('support_rebound', 'vwap_ema_hold'):
            if line_strong:
                trigger = min(old_trigger or near_current, near_current)
                policy = '선반응/방어형: 현재 선반응이면 방아쇠 도달로 인정'
                notes.append('지지/VWAP·EMA형 빠른 방아쇠')
            elif not calc_only:
                trigger = min(old_trigger or small_wait, small_wait)
                policy = '선근처 방어형: 0.06% 이내 짧은 재확인'
                notes.append('짧은 방아쇠 재확인')
        elif archetype == 'breakout_hold':
            if any(str(x) in ('저항돌파후유지', '돌파후재테스트반응') for x in line_reaction):
                trigger = min(old_trigger or near_current, near_current)
                policy = '돌파 후 유지 확인됨: 추가 위 추격 방아쇠 제거'
                notes.append('돌파유지 방아쇠 도달')
            else:
                trigger = old_trigger or current * 1.0015
                policy = '돌파형: 기존 돌파 방아쇠 유지'
        elif archetype == 'box_breakout_hold':
            if line_strong:
                trigger = min(old_trigger or small_wait, small_wait)
                policy = '박스상단 유지형: 박스 위 짧은 재확인'
                notes.append('박스상단 재확인')
        elif archetype == 'calculated_recheck':
            trigger = old_trigger or current * 1.0015
            policy = '계산선 단독: 바로 진입 금지, 재확인 유지'
            notes.append('계산선 단독 재확인')
    old_gap = _v796_pct(current, old_trigger) if old_trigger else 0.0
    new_gap = _v796_pct(current, trigger) if trigger else 0.0
    return {
        'archetype': archetype,
        'trigger_price': trigger,
        'old_trigger_price': old_trigger,
        'old_trigger_gap_pct': round(old_gap, 4),
        'new_trigger_gap_pct': round(new_gap, 4),
        'trigger_adjusted': bool(old_trigger and trigger and abs(trigger - old_trigger) / max(old_trigger, 1e-12) > 0.00005),
        'trigger_policy': policy,
        'trigger_notes': notes[:5],
    }

def _v802_metric(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    try:
        return _v796_num(*(row.get(k) for k in keys), default=default)
    except Exception:
        return float(default)

def _v802_common_scalp_profile__L16057(row: Dict[str, Any], q: Dict[str, Any], inp: Dict[str, Any], line_quality: str, line_reaction: List[Any], good: List[Any], warn: List[Any], trigger_adjust: Dict[str, Any]) -> Dict[str, Any]:
    """v802: 구조분류에 딱 안 들어맞지만 강한 단타 초입을 별도 실험실로 봉인한다.
    - 구조형 본선을 대체하지 않는다.
    - 성과가 쌓이면 common_pattern_key 단위로 새 구조 후보를 판단한다.
    """
    react = _v802_metric(row, 'price_reaction_pct', 'change_1m_pct', 'price_chg_60s', 'change_1m', default=0.0)
    ch30 = _v802_metric(row, 'price_chg_30s', 'change_30s_pct', default=0.0)
    ch3 = _v802_metric(row, 'change_3m_pct', 'price_chg_3m', 'change_3m', default=0.0)
    ch5 = _v802_metric(row, 'change_5m_pct', 'price_chg_5m', 'change_5m', default=0.0)
    buy = _v802_metric(row, 'buy_ratio', 'buy_trade_ratio', 'buy_ratio_1m', default=0.0)
    sustain = _v802_metric(row, 'buy_sustain_1m', 'buy_sustain', 'buy_sustain_20s', default=0.0)
    sustain20 = _v802_metric(row, 'buy_sustain_20s', 'buy_ratio_20s', default=sustain)
    spread = _v802_metric(row, 'spread_pct', 'orderbook_spread_pct', default=99.0)
    slip = _v802_metric(row, 'slippage_pct', 'expected_slippage_pct', default=spread)
    rel = _v802_metric(row, 'relative_strength_pct', 'relative_strength', default=0.0)
    vol_ratio = _v802_metric(row, 'volume_ratio', default=0.0)
    vol_exp = _v802_metric(row, 'volume_expansion_pct', 'volume_change_pct', 'trade_value_change_pct', default=0.0)
    turnover = _v802_metric(row, 'turnover_24h', 'trade_value_24h', default=0.0)
    vwap = _v802_metric(row, 'vwap_gap_pct', 'vwap_pos_pct', default=0.0)
    ema = _v802_metric(row, 'ema5_gap_pct', 'ema5_pos_pct', 'ema_gap_pct', default=0.0)
    exec_class = str(q.get('exec_risk_class') or row.get('exec_risk_class_v792') or '')
    risk_blob = ' / '.join(str(x) for x in (_v788_as_list(row.get('risk_tags')) + _v788_as_list(q.get('failure_pattern_tags')))[:16])
    hard_risk = bool(exec_class == 'hard_exec_risk' or any(k in risk_blob for k in ('매도압력', '매도벽', '윗꼬리강함', '미끄러짐 과다', '지지선 이탈')))
    archetype = str(trigger_adjust.get('archetype') or 'common_structure')
    structure_named = bool(archetype in ('support_rebound', 'vwap_ema_hold', 'breakout_hold', 'box_breakout_hold'))
    line_strong = bool(line_quality in ('confirmed_line', 'reactive_line') or line_reaction)
    # v804: common scalp는 두 값을 분리한다.
    # - common_pattern_key: 관찰/분류용. 모든 후보에 붙을 수 있다.
    # - common_scalp_ok: 실제 S1 심사 route. 구조형으로 설명되지 않는 강한 흐름만 허용한다.
    ambiguous_structure = bool(archetype in ('common_structure', 'calculated_recheck') or not line_strong or (line_quality == 'calculated_line_recheck' and not line_reaction) or not structure_named)
    flow_strong = bool(react >= 0.40 or (react >= 0.22 and ch3 >= 0.20) or (ch30 >= 0.15 and react >= 0.15))
    buy_strong = bool(buy >= 0.76 and max(sustain, sustain20) >= 0.68)
    money_strong = bool(row.get('volume_expanding') or row.get('reclaim_volume_expand') or vol_ratio >= 1.18 or vol_exp >= 15.0 or turnover >= 400_000_000)
    rel_ok = bool(rel >= 0.12 or ch3 >= 0.30 or ch5 >= 0.45)
    position_ok = bool(vwap >= -0.10 and ema >= -0.16)
    exec_ok = bool(spread <= 0.22 and slip <= 0.26 and not hard_risk)
    core_score = sum(1 for cond in (flow_strong, buy_strong, money_strong, rel_ok, position_ok, exec_ok) if cond)
    strong_burst = bool(react >= 0.35 and buy >= 0.78 and max(sustain, sustain20) >= 0.70 and (money_strong or rel_ok))
    compression_pop = bool(ch30 >= 0.12 and react >= 0.12 and buy >= 0.82 and max(sustain, sustain20) >= 0.74 and money_strong)
    common_watch = bool(ambiguous_structure and exec_ok and position_ok and (flow_strong or buy_strong or money_strong))
    # 구조가 이미 명확한 후보는 structure route로 둔다. common scalp는 미분류/애매 구조 중 강한 흐름만 실제 승격한다.
    common_ok = bool(ambiguous_structure and exec_ok and position_ok and buy_strong and (strong_burst or compression_pop or (core_score >= 5 and flow_strong and (money_strong or rel_ok))))
    tags: List[str] = []
    if flow_strong: tags.append('가격반응강함')
    if buy_strong: tags.append('체결지속강함')
    if money_strong: tags.append('거래대금증가')
    if rel_ok: tags.append('상대강도양호')
    if position_ok: tags.append('VWAP/EMA근처이상')
    if exec_ok: tags.append('실행위험정상')
    if ambiguous_structure: tags.append('구조미분류')
    parts: List[str] = []
    if react >= 0.45: parts.append('react_strong')
    elif react >= 0.25: parts.append('react_mid')
    if buy >= 0.80: parts.append('buy_very_strong')
    elif buy >= 0.74: parts.append('buy_strong')
    if max(sustain, sustain20) >= 0.75: parts.append('sustain_strong')
    elif max(sustain, sustain20) >= 0.66: parts.append('sustain_mid')
    if vol_ratio >= 1.22 or vol_exp >= 18 or row.get('volume_expanding') or row.get('reclaim_volume_expand'): parts.append('money_expand')
    if rel >= 0.15: parts.append('relative_strong')
    if vwap >= 0 and ema >= 0: parts.append('above_vwap_ema')
    elif position_ok: parts.append('near_vwap_ema')
    if not parts:
        parts.append('common_watch')
    key = 'common_scalp|' + '|'.join(parts[:6])
    score = 0
    for cond in (flow_strong, buy_strong, money_strong, rel_ok, position_ok, exec_ok):
        score += 1 if cond else 0
    return {
        'schema': 'common_scalp_entry_v802',
        'common_scalp_ok': common_ok,
        'common_scalp_watch': common_watch,
        'common_scalp_score': score,
        'common_scalp_core_score_v804': core_score,
        'common_scalp_route_reason_v804': 'strict_pass' if common_ok else ('watch_only' if common_watch else 'blocked'),
        'common_pattern_key': key,
        'common_pattern_tags': tags[:8],
        'ambiguous_structure': ambiguous_structure,
        'metrics': {
            'react': round(react, 4), 'ch30': round(ch30, 4), 'ch3': round(ch3, 4), 'ch5': round(ch5, 4),
            'buy': round(buy, 4), 'sustain': round(sustain, 4), 'sustain20': round(sustain20, 4),
            'spread': round(spread, 4), 'slippage': round(slip, 4), 'relative_strength': round(rel, 4),
            'volume_ratio': round(vol_ratio, 4), 'volume_expansion_pct': round(vol_exp, 4),
            'vwap_gap_pct': round(vwap, 4), 'ema_gap_pct': round(ema, 4),
        },
        'blocks': [x for x, ok in (
            ('구조미분류아님', ambiguous_structure), ('가격반응약함', flow_strong), ('체결지속부족', buy_strong),
            ('거래대금증가부족', money_strong), ('상대강도부족', rel_ok), ('VWAP/EMA위치부족', position_ok), ('실행위험', exec_ok),
            ('강한초입조합부족', (strong_burst or compression_pop or core_score >= 5))
        ) if not ok][:8],
        'policy': 'v804: pattern_key는 관찰값, common_scalp_ok는 실제 route 승격값으로 분리. 구조미분류+강한 흐름만 공통초입 S1 심사.',
    }

def _v796_structure_trade_plan(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    q = row.get('structure_quality_v792') if isinstance(row.get('structure_quality_v792'), dict) else {}
    inp = _v796_current_plan_inputs(row)
    entry = float(inp.get('entry') or 0.0)
    current = float(inp.get('current') or entry or 0.0)
    trigger = float(inp.get('trigger') or 0.0)
    invalid = float(inp.get('invalid') or 0.0)
    target1 = float(inp.get('target1') or 0.0)
    target2 = float(inp.get('target2') or 0.0)
    rr_ratio = float(inp.get('rr_ratio_raw') or 0.0)
    if entry and target1 and invalid and invalid < entry and target1 > entry:
        risk_pct = abs(_v796_pct(entry, invalid))
        reward_pct = _v796_pct(target1, entry)
        if risk_pct > 0:
            rr_ratio = reward_pct / risk_pct
    else:
        risk_pct = 0.0
        reward_pct = 0.0
    line_quality = _v796_line_quality(row, q)
    line_reaction = _v788_as_list(q.get('line_reaction_tags_v794') or row.get('line_reaction_tags_v794'))
    good = _v788_as_list(q.get('good_tags') or row.get('structure_good_tags_v792'))
    warn = _v788_as_list(q.get('failure_pattern_tags') or row.get('structure_failure_tags_v792'))
    trigger_adjust = _v801_adjust_structure_trigger(row, q, inp, line_quality, line_reaction, good, warn)
    common_scalp = _v802_common_scalp_profile(row, q, inp, line_quality, line_reaction, good, warn, trigger_adjust)
    if common_scalp.get('common_scalp_ok'):
        trigger_adjust = dict(trigger_adjust)
        trigger_adjust['archetype'] = 'common_scalp_entry'
        trigger_adjust['trigger_price'] = current
        trigger_adjust['new_trigger_gap_pct'] = 0.0
        trigger_adjust['trigger_adjusted'] = True
        trigger_adjust['trigger_policy'] = '공통초입: 강한 돈흐름/체결 지속이면 현재가 방아쇠 심사'
        trigger_adjust['trigger_notes'] = _v510_uniq(_v788_as_list(trigger_adjust.get('trigger_notes')) + ['공통초입 강한 흐름'], 5)
    old_trigger = trigger
    trigger = float(trigger_adjust.get('trigger_price') or trigger or 0.0)
    trigger_gap = _v796_pct(current, trigger) if trigger else 0.0
    exec_class = str(q.get('exec_risk_class') or row.get('exec_risk_class_v792') or '')
    hard_like = bool(any(str(x) in ('hard_exec_risk', 'hard_risk_hold') for x in (exec_class, str(row.get('s2_recheck_last_state_v788') or ''))))
    risk_tags_blob = ' / '.join(str(x) for x in _v788_as_list(row.get('risk_tags'))[:12])
    hard_pressure = any(k in risk_tags_blob for k in ('매도압력', '매도벽', '윗꼬리', '지지선 이탈', '미끄러짐 과다'))
    has_lines = bool(trigger and invalid and target1)
    rr_ok = bool(rr_ratio >= 1.15 and reward_pct >= 0.35 and risk_pct > 0)
    rr_good = bool(rr_ratio >= 1.45 and reward_pct >= 0.55 and 0 < risk_pct <= 0.75)
    line_ok = line_quality in ('confirmed_line', 'reactive_line', 'calculated_line_recheck')
    line_strong = line_quality in ('confirmed_line', 'reactive_line') or bool(line_reaction)
    if not has_lines:
        state = 'plan_incomplete'
        role = 's3_or_recheck'
        reason = '진입/무효/목표 구조선 부족'
    elif hard_like or hard_pressure:
        state = 'hard_risk_hold'
        role = 'risk_hold'
        reason = '구조계획은 있으나 하드위험 보류'
    elif not rr_ok:
        state = 'rr_wait'
        role = 's2_or_observe'
        reason = f'손익비 부족 rr {rr_ratio:.2f}'
    elif common_scalp.get('common_scalp_ok'):
        state = 'common_scalp_good'
        role = 'common_scalp_s1_review'
        reason = '공통초입 강한 흐름'
    elif not line_ok:
        state = 'line_quality_wait'
        role = 's2_recheck'
        reason = '선 품질 재확인'
    elif rr_good and line_strong:
        state = 'plan_good'
        role = 's1_review_candidate'
        reason = '구조계획 우수'
    else:
        state = 'plan_ready'
        role = 's2_fast_recheck'
        reason = '구조계획 있음·확인값 대기'
    return {
        'schema': 'structure_trade_plan_v796',
        'version': VERSION,
        'updated_ts': nowv,
        'entry_price': round(entry, 8),
        'current_price': round(current, 8),
        'entry_trigger_price': round(trigger, 8),
        'invalid_price': round(invalid, 8),
        'target_1_price': round(target1, 8),
        'target_2_price': round(target2, 8),
        'risk_pct': round(risk_pct, 4),
        'reward_pct': round(reward_pct, 4),
        'rr_ratio': round(rr_ratio, 3),
        'trigger_gap_pct': round(trigger_gap, 4),
        'old_trigger_price_v801': round(float(trigger_adjust.get('old_trigger_price') or 0.0), 8),
        'old_trigger_gap_pct_v801': trigger_adjust.get('old_trigger_gap_pct'),
        'trigger_archetype_v801': trigger_adjust.get('archetype'),
        'trigger_policy_v801': trigger_adjust.get('trigger_policy'),
        'trigger_adjusted_v801': bool(trigger_adjust.get('trigger_adjusted')),
        'trigger_notes_v801': trigger_adjust.get('trigger_notes') or [],
        'entry_route_v802': 'common_scalp' if common_scalp.get('common_scalp_ok') else 'structure',
        'common_scalp_entry_v802': common_scalp,
        'common_pattern_key_v802': common_scalp.get('common_pattern_key'),
        'common_pattern_tags_v802': common_scalp.get('common_pattern_tags') or [],
        'line_quality': line_quality or 'missing_line',
        'line_reaction': line_reaction[:6],
        'good_structure_tags': good[:6],
        'warning_tags': warn[:6],
        'exec_risk_class': exec_class or 'unknown',
        'plan_state': state,
        'plan_role': role,
        'plan_reason': reason,
        'policy': '구조형 본선 + 공통초입 실험실. 구조형은 기존 구조계획, 구조미분류 강한 흐름은 common_scalp_entry_v802로 봉인해 성과가 쌓이면 새 구조 후보로 본다.',
    }

def _v796_confirm_for_s1(row: Dict[str, Any], plan: Dict[str, Any]) -> Tuple[bool, List[str]]:
    react = _v796_num(row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'), default=0.0)
    buy = _v796_num(row.get('buy_ratio'), default=0.0)
    sustain = _v796_num(row.get('buy_sustain_1m'), row.get('buy_sustain_20s'), default=0.0)
    spread = _v796_num(row.get('spread_pct'), default=99.0)
    slip = _v796_num(row.get('slippage_pct'), row.get('spread_pct'), default=spread)
    reasons: List[str] = []
    if str(plan.get('plan_state')) not in ('plan_good', 'plan_ready', 'common_scalp_good'):
        reasons.append(str(plan.get('plan_reason') or '구조계획 미충족'))
    archetype = str(plan.get('trigger_archetype_v801') or 'common_structure')
    line_reacted = bool(plan.get('line_reaction'))
    trigger_wait_limit = -0.03
    if archetype in ('support_rebound', 'vwap_ema_hold') and line_reacted:
        trigger_wait_limit = -0.08
    elif archetype == 'box_breakout_hold':
        trigger_wait_limit = -0.06
    if float(plan.get('trigger_gap_pct') or 0.0) < trigger_wait_limit:
        reasons.append('방아쇠 가격 대기')
    if str(plan.get('entry_route_v802') or '') == 'common_scalp':
        cs = plan.get('common_scalp_entry_v802') if isinstance(plan.get('common_scalp_entry_v802'), dict) else {}
        if not cs.get('common_scalp_ok'):
            reasons.append('공통초입 확인값 부족')
        if spread > 0.24 or slip > 0.28:
            reasons.append('공통초입 실행비용 재확인')
        if str(plan.get('exec_risk_class')) == 'hard_exec_risk':
            reasons.append('하드 실행위험')
        return (not reasons), reasons[:8]
    # v801: 확인값은 구조 타입별로 해석한다. 지지/VWAP 방어형은 +0.35 추격보다
    # 선반응+매수세 유지가 우선이고, 돌파형은 기존 강한 확인을 유지한다.
    good_plan = str(plan.get('plan_state')) == 'plan_good'
    if good_plan and archetype in ('support_rebound', 'vwap_ema_hold'):
        if not ((react >= 0.12 and buy >= 0.66 and sustain >= 0.58 and line_reacted) or (react >= 0.08 and buy >= 0.78 and sustain >= 0.65)):
            reasons.append('구조별 확인값 부족')
    elif good_plan:
        if not ((react >= 0.22 and buy >= 0.62 and sustain >= 0.55) or (react >= 0.12 and buy >= 0.78 and sustain >= 0.72 and line_reacted)):
            reasons.append('구조계획 확인값 부족')
    else:
        if not (react >= 0.30 and buy >= 0.65 and sustain >= 0.70):
            reasons.append('가격/체결/1분지속 확인 부족')
    if spread > 0.30 or slip > 0.32:
        reasons.append('실행비용 재확인')
    if str(plan.get('exec_risk_class')) == 'hard_exec_risk':
        reasons.append('하드 실행위험')
    return (not reasons), reasons[:8]

def _v796_apply_plan_to_row(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    plan = _v796_structure_trade_plan(r, nowv)
    r['structure_trade_plan_v796'] = plan
    r['structure_plan_state_v796'] = plan.get('plan_state')
    r['structure_plan_role_v796'] = plan.get('plan_role')
    r['structure_rr_ratio_v796'] = plan.get('rr_ratio')
    r['structure_reward_pct_v796'] = plan.get('reward_pct')
    r['structure_risk_pct_v796'] = plan.get('risk_pct')
    gate = r.get('s1_promotion_gate') if isinstance(r.get('s1_promotion_gate'), dict) else {}
    gate = dict(gate)
    gate['structure_trade_plan_v796'] = plan
    gate['source_v796'] = 'structure_first_plan_reorder'
    ok, blocks = _v796_confirm_for_s1(r, plan)
    stage = _v510_stage(r)
    # v800: 구조계획이 위험보류이거나 RR<1이면 기존 경로가 S1로 올려도 paper OPEN 대상에서 제외한다.
    plan_state_v800 = str(plan.get('plan_state') or '')
    rr_v800 = _v796_num(plan.get('rr_ratio'), default=0.0)
    if stage == 'S1' and (plan_state_v800 == 'hard_risk_hold' or (rr_v800 > 0 and rr_v800 < 1.0)):
        r['stage'] = r['grade'] = 'S2'
        r['candidate_grade'] = 'S2'
        r['open_eligible'] = False
        r['paper_bot_open'] = False
        r['trade_ready'] = False
        r['s2_recheck_last_state_v788'] = 'plan_risk_hold'
        reason_v800 = '구조계획 위험보류' if plan_state_v800 == 'hard_risk_hold' else f'손익비 RR {rr_v800:.2f}<1.00'
        gate['state'] = 'plan_risk_hold'
        gate['block_reasons'] = _v510_uniq(_v788_as_list(gate.get('block_reasons')) + [reason_v800], 10)
        r['s2_recheck_reasons'] = _v510_uniq(_v788_as_list(r.get('s2_recheck_reasons')) + ['v800:' + reason_v800], 12)
        stage = 'S2'
        ok = False
        blocks = _v510_uniq(_v788_as_list(blocks) + [reason_v800], 8)
    # Only the common scalp plan can promote. No strategy lane split.
    if stage == 'S2' and ok:
        r['stage'] = r['grade'] = 'S1'
        r['open_eligible'] = True
        r['s2_to_s1_promoted_v732'] = True
        r['common_uprising_pass_v732'] = True
        r['s2_recheck_last_state_v788'] = 'promoted_s1'
        gate['state'] = 'promoted_s1'
        gate['block_reasons'] = []
        promo_label = '공통초입 강한 흐름 S1' if str(plan.get('entry_route_v802') or '') == 'common_scalp' else '구조계획 우선 S1'
        gate['promotion_reasons_v796'] = [promo_label, f"RR {plan.get('rr_ratio')}"]
        if str(plan.get('entry_route_v802') or '') == 'common_scalp':
            gate['common_pattern_key_v802'] = plan.get('common_pattern_key_v802')
            r['entry_route_v802'] = 'common_scalp'
            r['common_pattern_key_v802'] = plan.get('common_pattern_key_v802')
            r['common_pattern_tags_v802'] = plan.get('common_pattern_tags_v802') or []
        r['s2_to_s1_promotion_reasons_v732'] = _v510_uniq(_v788_as_list(r.get('s2_to_s1_promotion_reasons_v732')) + ['v802:' + promo_label], 8)
    else:
        gate['block_reasons'] = _v510_uniq(_v788_as_list(gate.get('block_reasons')) + blocks, 10)
        if stage == 'S2':
            add = []
            if str(plan.get('plan_state')) in ('plan_good', 'plan_ready'):
                add.append('v796:구조계획 재확인')
            if str(plan.get('plan_state')) == 'rr_wait':
                add.append('v796:손익비 재확인')
            if blocks:
                add.append('v796:' + str(blocks[0]))
            if add:
                r['s2_recheck_reasons'] = _v510_uniq(_v788_as_list(r.get('s2_recheck_reasons')) + add, 12)
    r['s1_promotion_gate'] = gate
    ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['structure_trade_plan_v796'] = plan
    r['entry_context'] = ctx
    return r

def _v796_attach_structure_trade_plan(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    state_top: Counter = Counter()
    role_top: Counter = Counter()
    line_top: Counter = Counter()
    trigger_type_top: Counter = Counter()
    trigger_adjust_top: Counter = Counter()
    route_top: Counter = Counter()
    common_pattern_top: Counter = Counter()
    common_watch_pattern_top: Counter = Counter()
    common_ok_count = 0
    common_watch_count = 0
    common_promoted = 0
    promoted = 0
    rr_values: List[float] = []
    samples: List[Dict[str, Any]] = []
    for src in rows or []:
        if not isinstance(src, dict):
            continue
        before = _v510_stage(src)
        r = _v796_apply_plan_to_row(src, nowv)
        p = r.get('structure_trade_plan_v796') if isinstance(r.get('structure_trade_plan_v796'), dict) else {}
        state_top[str(p.get('plan_state') or 'unknown')] += 1
        role_top[str(p.get('plan_role') or 'unknown')] += 1
        line_top[str(p.get('line_quality') or 'missing_line')] += 1
        trigger_type_top[str(p.get('trigger_archetype_v801') or 'common_structure')] += 1
        route_top[str(p.get('entry_route_v802') or 'structure')] += 1
        cs = p.get('common_scalp_entry_v802') if isinstance(p.get('common_scalp_entry_v802'), dict) else {}
        if cs.get('common_scalp_watch'):
            common_watch_count += 1
            common_watch_pattern_top[str(p.get('common_pattern_key_v802') or cs.get('common_pattern_key') or 'common_scalp')] += 1
        if cs.get('common_scalp_ok'):
            common_ok_count += 1
            common_pattern_top[str(p.get('common_pattern_key_v802') or cs.get('common_pattern_key') or 'common_scalp')] += 1
        if p.get('trigger_adjusted_v801'):
            trigger_adjust_top[str(p.get('trigger_archetype_v801') or 'common_structure')] += 1
        try:
            if p.get('rr_ratio'):
                rr_values.append(float(p.get('rr_ratio')))
        except Exception:
            pass
        if before != 'S1' and _v510_stage(r) == 'S1':
            promoted += 1
            if str(p.get('entry_route_v802') or '') == 'common_scalp':
                common_promoted += 1
        if len(samples) < 8 and _v510_stage(r) in ('S1','S2'):
            samples.append({'ticker': ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')), 'stage': _v510_stage(r), 'state': p.get('plan_state'), 'rr': p.get('rr_ratio'), 'risk': p.get('risk_pct'), 'reward': p.get('reward_pct'), 'line': p.get('line_quality'), 'trigger_type': p.get('trigger_archetype_v801'), 'trigger_gap': p.get('trigger_gap_pct'), 'route': p.get('entry_route_v802'), 'pattern': p.get('common_pattern_key_v802'), 'reason': p.get('plan_reason')})
        out.append(r)
    avg_rr = round(sum(rr_values)/len(rr_values), 3) if rr_values else 0.0
    return out, {
        'schema': 'structure_trade_plan_summary_v796',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'row_count': len(out),
        'state_top': dict(state_top.most_common(8)),
        'role_top': dict(role_top.most_common(8)),
        'line_quality_top': dict(line_top.most_common(8)),
        'trigger_type_top_v801': dict(trigger_type_top.most_common(8)),
        'trigger_adjusted_top_v801': dict(trigger_adjust_top.most_common(8)),
        'entry_route_top_v802': dict(route_top.most_common(6)),
        'common_pattern_top_v802': dict(common_pattern_top.most_common(8)),
        'common_watch_pattern_top_v804': dict(common_watch_pattern_top.most_common(8)),
        'common_scalp_watch_count_v804': common_watch_count,
        'common_scalp_ok_count_v802': common_ok_count,
        'common_scalp_promoted_s1_v802': common_promoted,
        'avg_rr': avg_rr,
        'promoted_s1_by_plan': promoted,
        'samples': samples,
        'policy': 'v804: 구조형 본선 + 공통초입 실험실. 공통초입 관찰패턴과 실제 route 승격값을 분리. 청산/자동매수 변경 없음.',
    }

def _v732_reseal_common_uprising_promotions__L16448(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    sealed, summary = _v796_prev_reseal_common(rows, nowv)
    try:
        planned, p_summary = _v796_attach_structure_trade_plan(sealed, nowv)
        q_summary_v810 = {}
        try:
            planned, q_summary_v810 = _v810_attach_quality_decision_tags(planned, nowv)
        except Exception as exc:
            try: append_error(ERROR, 'v810_quality_decision_tag_attach', exc)
            except Exception: pass
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_trade_plan_summary_v796'] = p_summary
            summary['quality_decision_summary_v810'] = q_summary_v810
        return planned, summary
    except Exception as exc:
        try: append_error(ERROR, 'v796_structure_trade_plan_spine', exc)
        except Exception: pass
        return sealed, summary

BUILD_LABEL = "strategy_worker_v0.802_v810_quality_route_preopen_spine_2026-06-10"

def _v807_flow_quality_profile(metrics: Dict[str, Any]) -> Dict[str, Any]:
    def nf(*vals: Any, default: float = 0.0) -> float:
        try:
            return _v796_num(*vals, default=default)
        except Exception:
            try: return float(default)
            except Exception: return 0.0
    react = nf(metrics.get('react'), metrics.get('reaction'), default=0.0)
    buy = nf(metrics.get('buy'), metrics.get('buy_ratio'), default=0.0)
    sustain = max(nf(metrics.get('sustain'), default=0.0), nf(metrics.get('sustain20'), default=0.0))
    spread = nf(metrics.get('spread'), default=99.0)
    slip = nf(metrics.get('slippage'), default=spread)
    vol_ratio = nf(metrics.get('volume_ratio'), default=0.0)
    vol_exp = nf(metrics.get('volume_expansion_pct'), default=0.0)
    vwap = nf(metrics.get('vwap_gap_pct'), default=0.0)
    ema = nf(metrics.get('ema_gap_pct'), default=0.0)
    exec_ok = bool(spread <= 0.45 and slip <= 0.45)
    money_hint = bool(vol_ratio >= 1.15 or vol_exp >= 12.0)
    position_ok = bool(vwap >= -0.12 and ema >= -0.18)
    lead_wait = bool(exec_ok and position_ok and buy >= 0.62 and sustain >= 0.62 and -0.12 <= react < 0.18)
    lead_high = bool(exec_ok and position_ok and buy >= 0.72 and sustain >= 0.70 and -0.08 <= react < 0.16)
    illusion_risk = bool(exec_ok and buy >= 0.72 and sustain >= 0.70 and react <= 0.02)
    both_strong = bool(exec_ok and position_ok and react >= 0.30 and buy >= 0.68 and sustain >= 0.65)
    if not exec_ok:
        label = 'execution_cost_burden'
    elif both_strong:
        label = 'price_and_flow_confirmed'
    elif lead_high and money_hint:
        label = 'flow_leads_price_high_quality'
    elif lead_wait:
        label = 'flow_leads_price_watch'
    elif illusion_risk:
        label = 'flow_without_price_illusion_risk'
    else:
        label = 'quality_watch'
    return {
        'schema': 'flow_quality_profile_v807',
        'label': label,
        'flow_leads_price_watch': bool(lead_wait),
        'flow_leads_price_high_quality': bool(lead_high and money_hint),
        'flow_without_price_illusion_risk': bool(illusion_risk),
        'price_and_flow_confirmed': bool(both_strong),
        'exec_ok': bool(exec_ok),
        'position_ok': bool(position_ok),
        'money_hint': bool(money_hint),
        'metrics': {
            'react': round(react, 4), 'buy': round(buy, 4), 'sustain': round(sustain, 4),
            'spread': round(spread, 4), 'slippage': round(slip, 4),
            'volume_ratio': round(vol_ratio, 4), 'volume_expansion_pct': round(vol_exp, 4),
            'vwap_gap_pct': round(vwap, 4), 'ema_gap_pct': round(ema, 4),
        },
        'policy': 'v807 observation-only: 품질판 표시용. S1/S2/S3/OPEN/BUY_READY 조건 변경 없음.',
    }

def _v802_common_scalp_profile__L16535(row: Dict[str, Any], q: Dict[str, Any], inp: Dict[str, Any], line_quality: str, line_reaction: List[Any], good: List[Any], warn: List[Any], trigger_adjust: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    prof = _v807_prev_common_scalp_profile(row, q, inp, line_quality, line_reaction, good, warn, trigger_adjust)
    try:
        metrics = prof.get('metrics') if isinstance(prof.get('metrics'), dict) else {}
        prof = dict(prof)
        prof['flow_quality_profile_v807'] = _v807_flow_quality_profile(metrics)
        prof['policy'] = str(prof.get('policy') or '') + ' v807 품질 profile 추가: 가격후행/체결착시 관찰용.'
    except Exception as exc:
        try: append_error(ERROR, 'v807_flow_quality_profile', exc)
        except Exception: pass
    return prof

VERSION = "strategy_worker_v0.802"

BUILD_LABEL = "strategy_worker_v0.802_v810_quality_route_preopen_spine_2026-06-10"

def _v810_num(*vals: Any, default: float = 0.0) -> float:
    try:
        return _v796_num(*vals, default=default) if '_v796_num' in globals() else fnum(*vals, default=default)
    except Exception:
        return fnum(*vals, default=default)

def _v810_quality_metrics(row: Dict[str, Any]) -> Dict[str, Any]:
    plan = row.get('structure_trade_plan_v796') if isinstance(row.get('structure_trade_plan_v796'), dict) else {}
    common = plan.get('common_scalp_entry_v802') if isinstance(plan.get('common_scalp_entry_v802'), dict) else (row.get('common_scalp_entry_v802') if isinstance(row.get('common_scalp_entry_v802'), dict) else {})
    met = common.get('metrics') if isinstance(common.get('metrics'), dict) else {}
    spread = _v810_num(row.get('spread_pct'), row.get('spread'), plan.get('spread_pct'), met.get('spread'), default=99.0)
    return {
        'react': _v810_num(row.get('price_reaction_pct'), row.get('reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'), plan.get('price_reaction_pct'), met.get('react'), met.get('reaction'), default=0.0),
        'buy': _v810_num(row.get('buy_ratio'), row.get('buy'), plan.get('buy_ratio'), met.get('buy'), default=0.0),
        'sustain': _v810_num(row.get('buy_sustain_1m'), row.get('buy_sustain_60s'), row.get('buy_sustain'), plan.get('buy_sustain_1m'), met.get('sustain'), met.get('sustain20'), default=0.0),
        'spread': spread,
        'slippage': _v810_num(row.get('slippage_pct'), row.get('slippage'), plan.get('slippage_pct'), met.get('slippage'), default=spread),
        'volume_ratio': _v810_num(row.get('volume_ratio'), met.get('volume_ratio'), default=0.0),
        'volume_expansion_pct': _v810_num(row.get('volume_expansion_pct'), met.get('volume_expansion_pct'), default=0.0),
        'vwap_gap_pct': _v810_num(row.get('vwap_gap_pct'), met.get('vwap_gap_pct'), default=0.0),
        'ema_gap_pct': _v810_num(row.get('ema_gap_pct'), met.get('ema_gap_pct'), default=0.0),
    }

def _v810_has_hard_risk(row: Dict[str, Any]) -> bool:
    texts: List[str] = []
    for k in ('plan_state_v800', 'structure_trade_plan_state_v796', 'execution_risk_class', 's2_recheck_last_state_v788'):
        v = row.get(k)
        if v not in (None, ''):
            texts.append(str(v))
    for k in ('block_reasons', 's_stage_reasons', 's1_missing_names', 'paper_final_block_reasons', 'hard_risk_reasons'):
        v = row.get(k)
        if isinstance(v, list):
            texts.extend(str(x) for x in v[:12])
        elif v not in (None, ''):
            texts.append(str(v))
    hay = ' / '.join(texts)
    return bool(any(x in hay for x in ('hard_risk_hold', 'hard_exec_risk', '강한 매도', '매도압력', '매도벽', '스프레드 과다', '미끄러짐 과다', '지지선 이탈', 'VWAP 아래', 'EMA 아래')))

def _v810_quality_decision(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    metrics = _v810_quality_metrics(row)
    try:
        profile = _v807_flow_quality_profile(metrics) if '_v807_flow_quality_profile' in globals() else {}
    except Exception:
        profile = {}
    react = _v810_num(metrics.get('react'), default=0.0)
    buy = _v810_num(metrics.get('buy'), default=0.0)
    sustain = _v810_num(metrics.get('sustain'), default=0.0)
    spread = _v810_num(metrics.get('spread'), default=99.0)
    slip = _v810_num(metrics.get('slippage'), default=spread)
    stage = _v510_stage(row) if '_v510_stage' in globals() else str(row.get('s_stage') or row.get('stage') or '')
    hard = _v810_has_hard_risk(row)
    exec_ok = bool(spread <= 0.45 and slip <= 0.45)
    flow_lead = bool(profile.get('flow_leads_price_watch') or profile.get('flow_leads_price_high_quality') or (exec_ok and buy >= 0.62 and sustain >= 0.62 and -0.12 <= react < 0.18))
    high_quality = bool(profile.get('flow_leads_price_high_quality') or (exec_ok and buy >= 0.72 and sustain >= 0.70 and -0.08 <= react < 0.16 and (_v810_num(metrics.get('volume_ratio'), default=0.0) >= 1.15 or _v810_num(metrics.get('volume_expansion_pct'), default=0.0) >= 12.0)))
    money_hint_v810 = bool(profile.get('money_hint') or _v810_num(metrics.get('volume_ratio'), default=0.0) >= 1.15 or _v810_num(metrics.get('volume_expansion_pct'), default=0.0) >= 12.0)
    position_ok_v810 = bool(profile.get('position_ok', True))
    raw_illusion_v810 = bool(profile.get('flow_without_price_illusion_risk') or (exec_ok and buy >= 0.72 and sustain >= 0.70 and react <= 0.02))
    # v810 separation: 가격 0 근처 + money/position 정상은 flow trap이 아니라 quality_recheck_s2 후보로 보낸다.
    # flow_trap_watch는 가격 음수/포지션 약함/돈흐름 힌트 부족 쪽만 보류 감시한다.
    flow_trap = bool(raw_illusion_v810 and (not high_quality) and (react < -0.02 or not money_hint_v810 or not position_ok_v810))
    if react < -0.03 and buy >= 0.70 and sustain >= 0.70:
        flow_trap = True
    quality_recheck = bool(stage in {'S2', 'S3'} and flow_lead and exec_ok and not hard and not flow_trap)
    s1_quality_hold = bool(stage == 'S1' and flow_trap)
    if quality_recheck:
        action = 'quality_recheck_s2'
        reason = '체결/지속 선행 + 가격 0근처 + 실행비용 정상: S2 상위 재확인'
    elif flow_trap:
        action = 'flow_trap_watch'
        reason = '체결/지속 강함 대비 가격반응 약함/음수: 체결착시 보류감시'
    else:
        action = 'quality_watch'
        reason = '품질 관찰'
    return {
        'schema': 'quality_decision_route_v810',
        'version': VERSION,
        'updated_ts': nowv,
        'stage': stage,
        'label': profile.get('label') or action,
        'action': action,
        'reason': reason,
        'quality_recheck_s2': quality_recheck,
        'flow_trap_watch': flow_trap,
        's1_quality_hold_advice': s1_quality_hold,
        'exec_ok': exec_ok,
        'hard_risk': hard,
        'flow_leads_price': flow_lead,
        'flow_leads_price_high_quality': high_quality,
        'metrics': {k: round(float(v), 4) if isinstance(v, (int, float)) else v for k, v in metrics.items()},
        'profile_v807': profile,
        'policy': 'v810: 품질판을 router/paper 판단 spine에 봉인. S1/S2/S3 점수기준, 청산, BUY_READY, 자동매수 변경 없음.',
    }

def _v810_attach_quality_decision_tags(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    counts: Counter = Counter()
    samples: Dict[str, List[str]] = {'quality_recheck_s2': [], 'flow_trap_watch': [], 's1_quality_hold_advice': []}
    for row in rows or []:
        r = dict(row)
        q = _v810_quality_decision(r, nowv)
        r['quality_route_v810'] = q
        r['quality_bucket_v810'] = q.get('action')
        r['quality_recheck_s2_v810'] = bool(q.get('quality_recheck_s2'))
        r['flow_trap_watch_v810'] = bool(q.get('flow_trap_watch'))
        r['s1_quality_hold_advice_v810'] = bool(q.get('s1_quality_hold_advice'))
        r['quality_route_reason_v810'] = q.get('reason')
        counts[str(q.get('action') or 'quality_watch')] += 1
        for key in samples:
            if bool(r.get(key + '_v810')) and len(samples[key]) < 8:
                t = ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol'))
                m = q.get('metrics') if isinstance(q.get('metrics'), dict) else {}
                samples[key].append(f"{t}({_v510_stage(r)} 반응 {m.get('react',0):+.2f} 체결 {m.get('buy',0):.2f} 지속 {m.get('sustain',0):.2f})")
        out.append(r)
    summary = {
        'schema': 'quality_decision_summary_v810',
        'version': VERSION,
        'updated_ts': nowv,
        'counts': dict(counts),
        'quality_recheck_s2_count': int(counts.get('quality_recheck_s2') or 0),
        'flow_trap_watch_count': int(counts.get('flow_trap_watch') or 0),
        'samples': {k: v for k, v in samples.items() if v},
        'policy': 'strategy canonical row owns quality tags; main reads only, router consumes priority, paper consumes hold advice.',
    }
    return out, summary

def _v810_attach_quality_priority_requests__L16699(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    reqs = list(priority_requests or [])
    added = 0; quality_count = 0; trap_count = 0
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        t = ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol'))
        if not t:
            continue
        q = r.get('quality_route_v810') if isinstance(r.get('quality_route_v810'), dict) else {}
        stage = _v510_stage(r) if '_v510_stage' in globals() else str(r.get('s_stage') or '')
        score = _v810_num(r.get('score'), r.get('leader_score'), default=0.0)
        if bool(r.get('quality_recheck_s2_v810')):
            quality_count += 1
            reqs.append({
                'ticker': t,
                'bucket': 'quality_recheck_s2',
                'priority': round(760.0 + min(120.0, score * 3.0), 3),
                'need': ['ws', 'micro', 'orderflow'],
                'source': 'strategy_worker_v810_quality_recheck_s2',
                'candidate_stage': stage,
                'quality_route_v810': q,
                'quality_recheck_s2_v810': True,
                'micro_urgent': True,
                'strategy_force_active': True,
                'updated_ts': nowv,
                'target_router_policy_v810': '가격후행 성공 가능 후보를 S2 상위 재확인으로 배차. S1 즉시승격 아님.',
            })
            added += 1
        elif bool(r.get('flow_trap_watch_v810')):
            trap_count += 1
            reqs.append({
                'ticker': t,
                'bucket': 'flow_trap_watch',
                'priority': round((880.0 if stage == 'S1' else 520.0) + min(80.0, score * 2.0), 3),
                'need': ['ws', 'micro', 'orderflow'],
                'source': 'strategy_worker_v810_flow_trap_watch',
                'candidate_stage': stage,
                'quality_route_v810': q,
                'flow_trap_watch_v810': True,
                's1_quality_hold_advice_v810': bool(r.get('s1_quality_hold_advice_v810')),
                'micro_urgent': bool(stage == 'S1'),
                'strategy_force_active': bool(stage == 'S1'),
                'updated_ts': nowv,
                'target_router_policy_v810': '체결착시 의심 후보는 신선값 재확인 후 paper 보류/차단 근거로 사용.',
            })
            added += 1
    summary = {
        'schema': 'quality_priority_requests_v810',
        'version': VERSION,
        'updated_ts': nowv,
        'added_count': added,
        'quality_recheck_s2_count': quality_count,
        'flow_trap_watch_count': trap_count,
        'policy': 'router priority only; no fixed candidate cap and no direct S1 threshold relaxation.',
    }
    return reqs, summary

VERSION = "strategy_worker_v0.812"

BUILD_LABEL = "structure_board_mainline_2026-06-10"

def _v812_num(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        if v in (None, '', [], {}):
            continue
        try:
            return float(str(v).replace(',', '').replace('%', ''))
        except Exception:
            continue
    try:
        return float(default)
    except Exception:
        return 0.0

def _v812_list(v: Any) -> List[str]:
    if v in (None, '', [], {}):
        return []
    if isinstance(v, (list, tuple, set)):
        src = list(v)
    else:
        src = [v]
    out: List[str] = []
    for x in src:
        if isinstance(x, dict):
            txt = str(x.get('reason') or x.get('name') or x.get('label') or x.get('value') or '').strip()
        else:
            txt = str(x or '').strip()
        if txt and txt not in out:
            out.append(txt)
    return out

def _v812_plan(row: Dict[str, Any]) -> Dict[str, Any]:
    p = row.get('structure_trade_plan_v796') if isinstance(row.get('structure_trade_plan_v796'), dict) else {}
    if p:
        return dict(p)
    # fallback: keep one canonical plan object even when older rows lack v796 pack.
    return {
        'plan_state': row.get('plan_state') or row.get('structure_plan_state') or '-',
        'plan_role': row.get('plan_role') or row.get('structure_role') or '-',
        'line_quality': row.get('line_quality') or row.get('structure_line_reliability_v759') or '-',
        'trigger_gap_pct': _v812_num(row.get('trigger_gap_pct'), row.get('trigger_gap'), default=0.0),
        'rr_ratio': _v812_num(row.get('rr_ratio'), row.get('risk_reward'), default=0.0),
        'reward_pct': _v812_num(row.get('reward_pct'), row.get('target_room_pct'), default=0.0),
        'risk_pct': _v812_num(row.get('risk_pct'), row.get('stop_risk_pct'), default=0.0),
        'plan_reason': row.get('plan_reason') or '-',
    }

def _v812_setup_type__L16840(row: Dict[str, Any], plan: Dict[str, Any]) -> str:
    txt = _v812_text(row)
    low = txt.lower()
    if any(w in txt for w in ('저점유동성쓸림', '쓸림후빠른회복', 'liquidity_sweep', 'sweep_reclaim')):
        return 'liquidity_sweep_recovery'
    if any(w in txt for w in ('박스', 'box_breakout', 'box')) and any(w in txt for w in ('돌파', 'breakout')):
        return 'box_breakout_hold'
    if any(w in txt for w in ('돌파', '저항돌파', 'breakout', '돌파 유지형')):
        return 'breakout_hold'
    if any(w in txt for w in ('지지선 반등', '지지선반등', 'support_rebound', 'support')):
        return 'support_rebound'
    if any(w in txt for w in ('VWAP', 'EMA', 'vwap', 'ema')):
        return 'vwap_ema_hold'
    if any(w in txt for w in ('눌림', '재가속', 'pullback', 'reaccel', '돈흐름')):
        return 'pullback_reaccel'
    if any(w in txt for w in ('구조', 'structure', 'common_scalp')):
        return 'common_structure_watch'
    return 'weak_or_unknown_structure'

def _v812_survival_risk(row: Dict[str, Any], plan: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    dec = row.get('canonical_entry_decision') if isinstance(row.get('canonical_entry_decision'), dict) else {}
    met = dec.get('metrics') if isinstance(dec.get('metrics'), dict) else {}
    spread = _v812_num(row.get('spread_pct'), row.get('spread'), met.get('spread_pct'), met.get('spread'), default=99.0)
    slip = _v812_num(row.get('slippage_pct'), row.get('slippage'), met.get('slippage_pct'), met.get('slippage'), default=spread)
    source_age = _v812_num(row.get('source_age_sec'), row.get('candidate_age_sec'), row.get('age_sec'), ctx.get('source_age_sec'), default=0.0)
    trigger_gap = _v812_num(row.get('trigger_gap_pct'), row.get('trigger_gap'), plan.get('trigger_gap_pct'), default=0.0)
    reward = _v812_num(plan.get('reward_pct'), row.get('reward_pct'), row.get('target_room_pct'), default=0.0)
    sell_pressure = _v812_num(row.get('sell_pressure'), row.get('sell_pressure_pct'), row.get('ask_wall_pressure'), default=0.0)
    risk_txt = ' '.join(_v812_list(row.get('risk_tags')) + _v812_list(row.get('block_reasons')) + _v812_list(row.get('hard_risk_reasons')) + _v812_list(row.get('s_stage_reasons')))
    stale = _v812_list(row.get('stale_reasons'))
    reasons: List[str] = []
    cautions: List[str] = []
    if stale:
        reasons.append('생존위험: source stale')
    if source_age and source_age > 90:
        reasons.append(f'생존위험: source age {source_age:.0f}s')
    if spread > 0.45:
        reasons.append(f'생존위험: spread {spread:.2f}%')
    elif spread > 0.30:
        cautions.append(f'주의: spread {spread:.2f}%')
    if slip > 0.45:
        reasons.append(f'생존위험: slippage {slip:.2f}%')
    elif slip > 0.30:
        cautions.append(f'주의: slippage {slip:.2f}%')
    if trigger_gap < -0.08 and not bool(row.get('trigger_reached')):
        reasons.append(f'생존위험: trigger 미도달 {trigger_gap:.3f}%')
    if trigger_gap > 0.45:
        reasons.append(f'생존위험: 방아쇠 과다이탈 {trigger_gap:.3f}%')
    if 0 < reward < 0.45:
        reasons.append(f'생존위험: 목표여유 부족 {reward:.2f}%')
    if any(w in risk_txt for w in ('강한 매도압력', '매도압력 과다', '매도벽', '하드위험')):
        reasons.append('생존위험: 강한 매도압력/하드위험')
    if sell_pressure >= 0.75:
        reasons.append(f'생존위험: sell_pressure {sell_pressure:.2f}')
    if any(w in risk_txt for w in ('거래불가', '스프레드 22', '미끄러짐 22')):
        reasons.append('생존위험: 거래불가/유동성 위험')
    return {
        'schema': 'survival_risk_check',
        'pass': not reasons,
        'hard_reasons': _v510_uniq(reasons, 10) if '_v510_uniq' in globals() else reasons[:10],
        'cautions': _v510_uniq(cautions, 8) if '_v510_uniq' in globals() else cautions[:8],
        'metrics': {'spread_pct': spread, 'slippage_pct': slip, 'source_age_sec': source_age, 'trigger_gap_pct': trigger_gap, 'reward_pct': reward, 'sell_pressure': sell_pressure},
        'policy': 'only non-structural execution/survival risks remain hard guards',
    }

def _v812_structure_alive(row: Dict[str, Any], setup: str, plan: Dict[str, Any]) -> Dict[str, Any]:
    dec = row.get('canonical_entry_decision') if isinstance(row.get('canonical_entry_decision'), dict) else {}
    met = dec.get('metrics') if isinstance(dec.get('metrics'), dict) else {}
    react = _v812_num(row.get('price_reaction_pct'), row.get('reaction_pct'), met.get('price_reaction_pct'), default=0.0)
    buy = _v812_num(row.get('buy_ratio'), met.get('buy_ratio'), default=0.0)
    sustain = _v812_num(row.get('buy_sustain_1m'), met.get('buy_sustain_1m'), default=0.0)
    chg10 = _v812_num(row.get('price_chg_10s'), met.get('price_chg_10s'), default=0.0)
    chg30 = _v812_num(row.get('price_chg_30s'), met.get('price_chg_30s'), default=0.0)
    vwap_gap = _v812_num(row.get('vwap_gap_pct'), row.get('vwap_gap'), default=0.0)
    ema_gap = _v812_num(row.get('ema_gap_pct'), row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    txt = _v812_text(row)
    evidence: List[str] = []
    invalid: List[str] = []
    waiting: List[str] = []
    if setup == 'vwap_ema_hold':
        if vwap_gap < -0.20 and ema_gap < -0.20:
            invalid.append('구조부정: VWAP/EMA 동시 이탈')
        if buy >= 0.58 or sustain >= 0.58:
            evidence.append('VWAP/EMA 방어선 체결/지속 근거')
        if react >= -0.03 and (buy >= 0.64 or sustain >= 0.64):
            evidence.append('가격후행 가능 방어흐름')
        if not evidence:
            waiting.append('VWAP/EMA 방어 후속 확인 대기')
    elif setup in ('breakout_hold', 'box_breakout_hold'):
        if react < -0.08 and chg10 <= 0 and chg30 <= 0:
            invalid.append('구조부정: 돌파 후 가격 재진입/후속약함')
        if react >= 0.18 or chg10 > 0.05 or chg30 > 0.12:
            evidence.append('돌파선 위 후속 가격 유지')
        if buy >= 0.60 or sustain >= 0.60:
            evidence.append('돌파 후 체결/지속 보조근거')
        if not evidence:
            waiting.append('돌파선 유지 확인 대기')
    elif setup == 'support_rebound':
        if react < -0.12:
            invalid.append('구조부정: 지지선 반등 실패')
        if react >= 0.05 or chg10 > 0 or buy >= 0.60:
            evidence.append('지지선 반응/회복 근거')
        if not evidence:
            waiting.append('지지선 반등 후속 확인 대기')
    elif setup == 'liquidity_sweep_recovery':
        if react < -0.15:
            invalid.append('구조부정: 쓸림 회복 후 재이탈')
        if ('쓸림' in txt or 'sweep' in txt.lower()) and (react >= -0.05 or buy >= 0.58):
            evidence.append('저점 유동성 쓸림 후 회복 근거')
        if not evidence:
            waiting.append('쓸림 회복 확인 대기')
    elif setup == 'pullback_reaccel':
        if react < -0.12 and buy < 0.55:
            invalid.append('구조부정: 눌림 후 재가속 실패')
        if react >= 0.10 or buy >= 0.62 or sustain >= 0.62:
            evidence.append('눌림 후 재가속 보조근거')
        if not evidence:
            waiting.append('재가속 후속 확인 대기')
    else:
        if react >= 0.15 or buy >= 0.65 or sustain >= 0.65:
            evidence.append('공통 구조 관찰 근거')
        else:
            waiting.append('구조 근거 부족')
    # Flow-trap is not an automatic permanent block, but S1 should not be opened while it is active.
    if bool(row.get('flow_trap_watch_v810')):
        invalid.append('구조부정: flow_trap_watch 체결착시 현재 cycle')
    return {
        'schema': 'structure_alive_check',
        'alive': bool(evidence and not invalid),
        'invalid': bool(invalid),
        'evidence': _v510_uniq(evidence, 8) if '_v510_uniq' in globals() else evidence[:8],
        'waiting': _v510_uniq(waiting, 8) if '_v510_uniq' in globals() else waiting[:8],
        'invalid_reasons': _v510_uniq(invalid, 8) if '_v510_uniq' in globals() else invalid[:8],
        'metrics': {'react': react, 'buy': buy, 'sustain': sustain, 'chg10': chg10, 'chg30': chg30, 'vwap_gap_pct': vwap_gap, 'ema_gap_pct': ema_gap},
        'policy': 'confirmation metrics are structure evidence, not standalone gates',
    }

def _v812_build_structure_board__L16981(row: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:
    nowv = nowv or now_ts()
    plan = _v812_plan(row)
    setup = _v812_setup_type(row, plan)
    survival = _v812_survival_risk(row, plan)
    alive = _v812_structure_alive(row, setup, plan)
    rr = _v812_num(plan.get('rr_ratio'), row.get('rr_ratio'), default=0.0)
    plan_state = str(plan.get('plan_state') or row.get('plan_state') or '')
    line_quality = str(plan.get('line_quality') or row.get('line_quality') or row.get('structure_line_reliability_v759') or '')
    plan_good = any(w in plan_state for w in ('좋음', '준비됨', 'plan_good', 'ready')) or rr >= 1.35
    line_usable = not any(w in line_quality for w in ('missing', '없음', 'stale'))
    structure_present = setup != 'weak_or_unknown_structure' and (plan_good or line_usable or bool(alive.get('evidence')))
    stage = 'S3'
    reasons: List[str] = []
    role = 'structure_observe'
    if not structure_present:
        stage = 'S3'
        role = 'structure_observe'
        reasons.append('구조판: 구조선 근거 부족')
    elif not survival.get('pass'):
        # Survival risk does not erase structure; keep good structures in S2 for quick recheck unless risk is clearly untradable.
        severe_txt = ' / '.join(survival.get('hard_reasons') or [])
        if any(w in severe_txt for w in ('거래불가', 'spread 0.', 'slippage 0.', '강한 매도압력')):
            stage = 'S3'
            role = 'survival_risk_observe'
        else:
            stage = 'S2'
            role = 'survival_risk_recheck'
        reasons.extend(survival.get('hard_reasons') or ['생존위험 재확인'])
    elif alive.get('invalid'):
        stage = 'S2'
        role = 'structure_invalid_recheck'
        reasons.extend(alive.get('invalid_reasons') or ['구조부정 재확인'])
    elif alive.get('alive') and plan_good and rr >= 1.20:
        stage = 'S1'
        role = 'structure_s1_candidate'
        reasons.extend(alive.get('evidence') or ['구조 살아있음'])
    elif structure_present:
        stage = 'S2'
        role = 'structure_recheck'
        reasons.extend(alive.get('waiting') or alive.get('evidence') or ['구조는 있으나 trigger/후속 확인 대기'])
    return {
        'schema': 'structure_board_mainline',
        'updated_ts': nowv,
        'setup_type': setup,
        'stage': stage,
        'role': role,
        'plan': plan,
        'survival_risk': survival,
        'alive_check': alive,
        'rr_ratio': rr,
        'plan_state': plan_state or '-',
        'line_quality': line_quality or '-',
        'structure_present': bool(structure_present),
        'stage_reasons': _v510_uniq(reasons, 12) if '_v510_uniq' in globals() else reasons[:12],
        'legacy_condition_gate': 'diagnostic_only',
        'policy': 'structure owns S1/S2/S3; metrics are evidence; only survival risk remains hard guard',
    }

def _v812_apply_structure_board(row: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    r = dict(row)
    prev_stage = _v510_stage(r) if '_v510_stage' in globals() else str(r.get('stage') or '')
    board = _v812_build_structure_board(r, nowv)
    stage = str(board.get('stage') or 'S3')
    r['structure_board'] = board
    r['structure_board_v812'] = board
    r['structure_setup_type'] = board.get('setup_type')
    r['structure_setup_type_v812'] = board.get('setup_type')
    r['structure_entry_role_v812'] = board.get('role')
    r['structure_alive_state_v812'] = 'alive' if (board.get('alive_check') or {}).get('alive') else ('invalid' if (board.get('alive_check') or {}).get('invalid') else 'waiting')
    r['survival_risk_pass_v812'] = bool((board.get('survival_risk') or {}).get('pass'))
    r['legacy_condition_gate_v812'] = 'diagnostic_only'
    r['v812_prev_stage_before_structure_board'] = prev_stage
    r['s_stage'] = r['candidate_stage'] = r['candidate_grade'] = r['stage'] = r['grade'] = stage
    r['s_stage_reasons'] = list(board.get('stage_reasons') or [])
    r['block_reasons'] = list(board.get('stage_reasons') or [])
    r['s1_missing_conditions'] = [] if stage == 'S1' else list(board.get('stage_reasons') or [])
    r['s1_missing_names'] = [] if stage == 'S1' else [str(x).split(':', 1)[0] for x in list(board.get('stage_reasons') or [])[:8]]
    r['s1_short_reason'] = '구조판 S1 통과' if stage == 'S1' else ' / '.join(list(board.get('stage_reasons') or [])[:4])
    if stage == 'S1':
        r['open_eligible'] = True
        r['paper_bot_open'] = True
        r['trade_ready'] = True
        r['recheck_state'] = '구조판 S1'
    elif stage == 'S2':
        r['open_eligible'] = False
        r['paper_bot_open'] = False
        r['trade_ready'] = False
        r['recheck_state'] = '구조판 S2 재확인'
        r['s2_recheck_reasons'] = list(board.get('stage_reasons') or [])
    else:
        r['open_eligible'] = False
        r['paper_bot_open'] = False
        r['trade_ready'] = False
        r['recheck_state'] = '구조판 S3 관찰'
    ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['structure_board'] = board
    ctx['structure_board_v812'] = board
    ctx['legacy_condition_gate_v812'] = 'diagnostic_only'
    r['entry_context'] = ctx
    return r

def _v532_apply_canonical_entry_decision__L17091(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    r = _v812_prev_apply_canonical_entry_decision(row)
    try:
        return _v812_apply_structure_board(r)
    except Exception as exc:
        try: append_error(ERROR, 'v812_apply_structure_board_single', exc)
        except Exception: pass
        return r

def _v732_reseal_common_uprising_promotions__L17103(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    sealed, summary = _v812_prev_reseal_common(rows, nowv)
    out: List[Dict[str, Any]] = []
    counts: Counter = Counter(); setup_counts: Counter = Counter(); role_counts: Counter = Counter(); prev_to_new: Counter = Counter()
    samples: List[Dict[str, Any]] = []
    try:
        for row in sealed or []:
            before = _v510_stage(row) if '_v510_stage' in globals() else str(row.get('stage') or '')
            r = _v812_apply_structure_board(row, nowv)
            after = _v510_stage(r) if '_v510_stage' in globals() else str(r.get('stage') or '')
            board = r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else {}
            counts[after] += 1
            setup_counts[str(board.get('setup_type') or '-')] += 1
            role_counts[str(board.get('role') or '-')] += 1
            prev_to_new[f'{before}->{after}'] += 1
            if len(samples) < 10 and after in ('S1','S2'):
                samples.append({
                    'ticker': ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')) if 'ticker_norm' in globals() else str(r.get('ticker') or '-'),
                    'stage': after,
                    'setup': board.get('setup_type'),
                    'role': board.get('role'),
                    'reason': ' / '.join(list(board.get('stage_reasons') or [])[:3]),
                })
            out.append(r)
        s812 = {
            'schema': 'structure_board_summary',
            'version': VERSION,
            'updated_ts': nowv,
            'updated_text': now_text(nowv) if 'now_text' in globals() else str(nowv),
            'stage_counts': dict(counts),
            'setup_type_top': dict(setup_counts.most_common(10)),
            'role_top': dict(role_counts.most_common(10)),
            'prev_to_structure_stage_top': dict(prev_to_new.most_common(10)),
            'samples': samples,
            'policy': 'v812: structure_board owns final S1/S2/S3. Legacy condition gate is diagnostic only; survival risk remains hard guard.',
        }
        if isinstance(summary, dict):
            summary = dict(summary)
            summary['structure_board_summary'] = s812
            summary['structure_board_summary_v812'] = s812
        return out, summary
    except Exception as exc:
        try: append_error(ERROR, 'v812_structure_board_reseal', exc)
        except Exception: pass
        return sealed, summary

def _v810_attach_quality_priority_requests__L17152(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:  # type: ignore[override]
    reqs, summary = _v812_prev_quality_priority_requests(rows, priority_requests, nowv)
    added = 0
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        board = r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else {}
        stage = _v510_stage(r) if '_v510_stage' in globals() else str(r.get('stage') or '')
        role = str(board.get('role') or '')
        if stage == 'S2' and role in ('structure_recheck','structure_invalid_recheck','survival_risk_recheck'):
            t = ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')) if 'ticker_norm' in globals() else str(r.get('ticker') or '')
            if not t:
                continue
            reqs.append({
                'ticker': t,
                'bucket': 'structure_recheck_s2',
                'priority': 790.0 if role == 'structure_recheck' else 720.0,
                'need': ['ws','micro','orderflow','candle'],
                'source': 'strategy_worker_structure_board',
                'candidate_stage': stage,
                'structure_setup_type': board.get('setup_type'),
                'structure_entry_role': role,
                'structure_board': board,
                'micro_urgent': True,
                'strategy_force_active': True,
                'updated_ts': nowv,
                'target_router_policy': '좋은 구조 S2는 조건 미달로 죽이지 않고 구조 후속/위험 재확인으로 배차',
            })
            added += 1
    if isinstance(summary, dict):
        summary = dict(summary)
        summary['structure_recheck_s2_req_count'] = added
        summary['structure_recheck_policy'] = 'structure S2 priority added after quality priority; no fixed cap'
    return reqs, summary

VERSION = "strategy_worker_v0.813"

BUILD_LABEL = "structure_board_publish_owner_2026-06-10"

MAIN_DEPLOY_VERSION = BUILD_LABEL

def _v813_structure_recheck_requests(rows: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    reqs = list(priority_requests or [])
    seen = set()
    for q in reqs:
        if isinstance(q, dict):
            t0 = str(q.get('ticker') or q.get('market') or q.get('symbol') or '').upper()
            b0 = str(q.get('bucket') or '')
            if t0 and b0:
                seen.add((t0, b0))
    added = 0
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        b = r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else (r.get('structure_board') if isinstance(r.get('structure_board'), dict) else {})
        st = _v510_stage(r) if '_v510_stage' in globals() else str(r.get('stage') or r.get('grade') or '')
        role = str(b.get('role') or '')
        if st != 'S2' or role not in ('structure_recheck', 'structure_invalid_recheck', 'survival_risk_recheck'):
            continue
        t = ticker_norm(r.get('ticker') or r.get('market') or r.get('symbol')) if 'ticker_norm' in globals() else str(r.get('ticker') or '').upper()
        if not t or (t, 'structure_recheck_s2') in seen:
            continue
        reqs.append({
            'ticker': t,
            'bucket': 'structure_recheck_s2',
            'priority': 790.0 if role == 'structure_recheck' else 720.0,
            'need': ['ws', 'micro', 'orderflow', 'candle'],
            'source': 'strategy_worker_structure_board_publish_owner',
            'candidate_stage': st,
            'structure_setup_type': b.get('setup_type'),
            'structure_entry_role': role,
            'micro_urgent': True,
            'strategy_force_active': True,
            'updated_ts': nowv,
        })
        seen.add((t, 'structure_recheck_s2'))
        added += 1
    return reqs, {'structure_recheck_s2_req_count_v813': added, 'policy': 'structure S2 recheck requests are generated from publish-owned canonical rows'}

VERSION = "strategy_worker_v0.816"

BUILD_LABEL = "structure_board_writer_owner_v816_2026-06-10"

MAIN_DEPLOY_VERSION = BUILD_LABEL

VERSION = "strategy_worker_v0.818"

BUILD_LABEL = "structure_board_writer_owner_v818_worker_manifest_2026-06-10"

MAIN_DEPLOY_VERSION = BUILD_LABEL

VERSION = "strategy_worker_v0.819"

BUILD_LABEL = "structure_board_writer_owner_v819_2026-06-10"

MAIN_DEPLOY_VERSION = BUILD_LABEL

STRUCTURE_BOARD_STATUS = BASE_DIR / "clean_structure_board_publish_status.json"

VERSION = "strategy_worker_v0.820"

BUILD_LABEL = "structure_s1_gate_text_owner_v820_2026-06-10"

MAIN_DEPLOY_VERSION = BUILD_LABEL

def _v820_skip_generated_reason_fields(row: Dict[str, Any]) -> bool:
    return bool(row.get('structure_board') or row.get('structure_board_v812') or row.get('legacy_condition_gate_v812') == 'diagnostic_only')

def _v812_text__L17454(row: Dict[str, Any]) -> str:  # type: ignore[override]
    # v812 used s_stage_reasons/block_reasons as raw text. After structure_board
    # started writing those fields, the next cycle treated its own output as new
    # liquidity-sweep evidence and flooded S1. Keep only raw worker/plan evidence.
    parts: List[str] = []
    skip_generated = _v820_skip_generated_reason_fields(row)
    keys = (
        'strategy_label','strategy','strategy_key','entry_route_v802','common_pattern_key_v802',
        'line_reaction','line_quality','trigger_archetype_v801','plan_state','plan_role',
        'risk_tags','structure_tags','structure_good_tags_v755',
        'structure_bad_tags_v755','structure_recheck_tags_v755'
    )
    for k in keys:
        v = row.get(k)
        if isinstance(v, dict):
            parts.extend([str(x) for x in v.values() if x not in (None, '', [], {})])
        elif isinstance(v, list):
            parts.extend([str(x) for x in v if x not in (None, '', [], {})])
        elif v not in (None, '', [], {}):
            parts.append(str(v))
    if not skip_generated:
        for k in ('s_stage_reasons','block_reasons','hard_risk_reasons'):
            v = row.get(k)
            if isinstance(v, list):
                parts.extend([str(x) for x in v if x not in (None, '', [], {})])
            elif v not in (None, '', [], {}):
                parts.append(str(v))
    plan = row.get('structure_trade_plan_v796') if isinstance(row.get('structure_trade_plan_v796'), dict) else {}
    for k in ('plan_state','plan_role','line_quality','trigger_archetype','plan_reason','setup_type'):
        v = plan.get(k)
        if v not in (None, '', [], {}):
            parts.append(str(v))
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    for v in levels.values():
        if v not in (None, '', [], {}):
            parts.append(str(v))
    return ' '.join(parts)

def _v820_contains(txt: str, *words: str) -> bool:
    return any(w and w in txt for w in words)

def _v820_s1_gate(row: Dict[str, Any], board: Dict[str, Any]) -> Dict[str, Any]:
    plan = board.get('plan') if isinstance(board.get('plan'), dict) else {}
    survival = board.get('survival_risk') if isinstance(board.get('survival_risk'), dict) else {}
    alive = board.get('alive_check') if isinstance(board.get('alive_check'), dict) else {}
    sm = survival.get('metrics') if isinstance(survival.get('metrics'), dict) else {}
    am = alive.get('metrics') if isinstance(alive.get('metrics'), dict) else {}
    plan_state = str(board.get('plan_state') or plan.get('plan_state') or row.get('plan_state') or '')
    plan_role = str(plan.get('plan_role') or row.get('plan_role') or '')
    line_quality = str(board.get('line_quality') or plan.get('line_quality') or row.get('line_quality') or '')
    setup = str(board.get('setup_type') or '')
    rr = _v812_num(board.get('rr_ratio'), plan.get('rr_ratio'), row.get('rr_ratio'), default=0.0)
    spread = _v812_num(sm.get('spread_pct'), row.get('spread_pct'), row.get('spread'), default=99.0)
    slip = _v812_num(sm.get('slippage_pct'), row.get('slippage_pct'), row.get('slippage'), default=spread)
    gap = _v812_num(sm.get('trigger_gap_pct'), row.get('trigger_gap_pct'), row.get('trigger_gap'), plan.get('trigger_gap_pct'), default=0.0)
    react = _v812_num(am.get('react'), row.get('price_reaction_pct'), row.get('reaction_pct'), default=0.0)
    buy = _v812_num(am.get('buy'), row.get('buy_ratio'), default=0.0)
    sustain = _v812_num(am.get('sustain'), row.get('buy_sustain_1m'), default=0.0)

    plan_good = _v820_contains(plan_state, '좋음', 'plan_good') or _v820_contains(plan_role, 'S1 심사', 's1_candidate')
    # 준비됨/ready alone is not S1. It remains a recheck line.
    if _v820_contains(plan_state, '준비됨', 'ready') and not _v820_contains(plan_state, '좋음', 'plan_good'):
        plan_good = False
    survival_ok = bool(survival.get('pass'))
    exec_ok = spread <= 0.18 and slip <= 0.20
    trigger_ok = (gap >= -0.08 or bool(row.get('trigger_reached'))) and gap <= 0.30
    alive_ok = bool(alive.get('alive')) and not bool(alive.get('invalid')) and bool(alive.get('evidence'))
    rr_ok = rr >= 1.50
    flow_ok = not bool(row.get('flow_trap_watch_v810') or row.get('s1_quality_hold_advice_v810'))
    line_confirmed = not _v820_contains(line_quality, '계산선 재확인', 'missing', '없음', 'stale')
    confirmation_ok = (
        react >= 0.20 or
        (react >= 0.00 and buy >= 0.75 and sustain >= 0.75) or
        (line_confirmed and react >= 0.05 and (buy >= 0.65 or sustain >= 0.65))
    )
    # liquidity sweep was the flooding path. Require real recovery confirmation.
    if setup == 'liquidity_sweep_recovery':
        confirmation_ok = confirmation_ok and (react >= 0.05 or (react >= 0.00 and buy >= 0.75 and sustain >= 0.75))
    passed = bool(plan_good and survival_ok and exec_ok and trigger_ok and alive_ok and rr_ok and flow_ok and confirmation_ok)
    missing: List[str] = []
    if not plan_good: missing.append('구조계획 좋음 아님')
    if not survival_ok: missing.append('생존위험 미통과')
    if not exec_ok: missing.append(f'실행비용 대기 spread {spread:.2f}/slip {slip:.2f}')
    if not trigger_ok: missing.append(f'trigger/gap 대기 {gap:.3f}%')
    if not alive_ok: missing.append('구조 alive 근거 부족/부정')
    if not rr_ok: missing.append(f'RR 부족 {rr:.2f}')
    if not flow_ok: missing.append('flow_trap/품질보류')
    if not confirmation_ok: missing.append(f'회복확인 부족 react {react:.2f}/buy {buy:.2f}/sustain {sustain:.2f}')
    return {
        'schema': 'structure_s1_gate_v820',
        'pass': passed,
        'missing': _v510_uniq(missing, 10) if '_v510_uniq' in globals() else missing[:10],
        'metrics': {'rr': rr, 'spread_pct': spread, 'slippage_pct': slip, 'trigger_gap_pct': gap, 'react': react, 'buy': buy, 'sustain': sustain},
        'flags': {'plan_good': plan_good, 'survival_ok': survival_ok, 'exec_ok': exec_ok, 'trigger_ok': trigger_ok, 'alive_ok': alive_ok, 'rr_ok': rr_ok, 'flow_ok': flow_ok, 'confirmation_ok': confirmation_ok, 'line_confirmed': line_confirmed},
        'policy': 'S1 requires structure+survival+execution+trigger+confirmation; incomplete structure remains S2 recheck',
    }

def _v812_build_structure_board__L17554(row: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    board = _v820_prev_v812_build_structure_board(row, nowv)
    if not isinstance(board, dict):
        return board
    gate = _v820_s1_gate(row, board)
    board['s1_gate_v820'] = gate
    board['s1_gate_pass_v820'] = bool(gate.get('pass'))
    board['policy'] = 'v820: structure owns S1/S2/S3, but S1 needs strict structure-survival-execution confirmation; recheck stays S2'
    if str(board.get('stage') or '') == 'S1' and not gate.get('pass'):
        board['stage'] = 'S2'
        board['role'] = 'structure_recheck'
        reasons = list(gate.get('missing') or [])
        if not reasons:
            reasons = ['v820 S1 gate 재확인']
        board['stage_reasons'] = _v510_uniq(['v820 S1승격 보류'] + reasons, 12) if '_v510_uniq' in globals() else (['v820 S1승격 보류'] + reasons)[:12]
    elif str(board.get('stage') or '') == 'S1' and gate.get('pass'):
        board['role'] = 'structure_s1_candidate'
        board['stage_reasons'] = _v510_uniq(list(board.get('stage_reasons') or []) + ['v820 S1 gate 통과'], 12) if '_v510_uniq' in globals() else (list(board.get('stage_reasons') or []) + ['v820 S1 gate 통과'])[:12]
    return board

VERSION = "strategy_worker_v0.821"

BUILD_LABEL = "candidate_snapshot_lite_publish_age_v821_2026-06-10"

MAIN_DEPLOY_VERSION = BUILD_LABEL

CANDIDATE_LITE_SNAPSHOT = BASE_DIR / "clean_candidate_latest_snapshot.json"

def _v821_safe_list(v: Any, limit: int = 12) -> List[Any]:
    if isinstance(v, list):
        return v[:limit]
    if isinstance(v, tuple):
        return list(v[:limit])
    if isinstance(v, str) and v:
        return [v]
    return []

def _v821_lite_dict(v: Any, keys: Tuple[str, ...], max_list: int = 12) -> Dict[str, Any]:
    if not isinstance(v, dict):
        return {}
    out: Dict[str, Any] = {}
    for k in keys:
        if k not in v:
            continue
        val = v.get(k)
        if isinstance(val, (str, int, float, bool)) or val is None:
            out[k] = val
        elif isinstance(val, list):
            out[k] = val[:max_list]
        elif isinstance(val, dict):
            # one shallow level only to prevent bloated main snapshots
            sub: Dict[str, Any] = {}
            for sk, sv in list(val.items())[:30]:
                if isinstance(sv, (str, int, float, bool)) or sv is None:
                    sub[sk] = sv
                elif isinstance(sv, list):
                    sub[sk] = sv[:max_list]
            out[k] = sub
    return out

def _v821_compact_candidate_row__L17626(row: Dict[str, Any]) -> Dict[str, Any]:
    keys = (
        'ticker','market','symbol','stage','grade','s_grade','paper_grade','candidate_stage',
        'canonical_lane','lane','source_lane','strategy_lane','trade_candidate_row_v661','paper_candidate_row',
        'strategy_key','strategy','strategy_label','strategy_name','current_price','price','last_price','entry_price',
        'price_1m_ago','prev_1m_price','price_60s_ago','change_1m_pct','price_chg_60s','price_reaction_pct','reaction_pct',
        'buy_ratio','buy_sustain_1m','buy_sustain_60s','spread_pct','spread','slippage_pct','slippage',
        'trigger_price','entry_trigger_price','planned_entry','trigger_gap_pct','trigger_gap','trigger_reached',
        'rr_ratio','plan_state','plan_role','line_quality','entry_route_v802','common_pattern_key_v802',
        'quality_bucket_v810','quality_recheck_s2_v810','flow_trap_watch_v810','s1_quality_hold_advice_v810',
        'age','source_age','fresh_age','candle_age','created_at','updated_ts','detected_ts','expires_at',
    )
    out = {k: row.get(k) for k in keys if k in row}
    for k in ('block_reasons','s_stage_reasons','hard_risk_reasons','s1_fail_reasons','why_not_s1','risk_tags','warning_tags','structure_tags','structure_good_tags_v755','structure_bad_tags_v755','structure_recheck_tags_v755'):
        if k in row:
            out[k] = _v821_safe_list(row.get(k), 14)
    for k in ('structure_board','structure_board_v812'):
        if isinstance(row.get(k), dict):
            b = row.get(k) or {}
            out[k] = _v821_lite_dict(b, ('stage','setup_type','role','stage_reasons','plan_state','line_quality','rr_ratio','s1_gate_pass_v820','policy'), 10)
            for sub_key in ('survival_risk','alive_check','s1_gate_v820','plan'):
                if isinstance(b.get(sub_key), dict):
                    out[k][sub_key] = _v821_lite_dict(b.get(sub_key), ('pass','alive','invalid','evidence','missing','metrics','flags','plan_state','plan_role','line_quality','rr_ratio'), 8)
    if isinstance(row.get('structure_trade_plan_v796'), dict):
        out['structure_trade_plan_v796'] = _v821_lite_dict(row.get('structure_trade_plan_v796'), ('plan_state','plan_role','line_quality','trigger_archetype_v801','entry_route_v802','common_pattern_key_v802','rr_ratio','trigger_gap_pct','common_scalp_entry_v802'), 8)
    if isinstance(row.get('quality_route_v810'), dict):
        out['quality_route_v810'] = _v821_lite_dict(row.get('quality_route_v810'), ('action','bucket','metrics','reason'), 8)
    return out

def _v821_stage(row: Dict[str, Any]) -> str:
    try:
        return _v510_stage(row)
    except Exception:
        s = str(row.get('stage') or row.get('grade') or row.get('s_grade') or '').upper()
        return s if s in ('S1','S2','S3') else '미집계'

def _v821_lane(row: Dict[str, Any]) -> str:
    return str(row.get('canonical_lane') or row.get('lane') or row.get('source_lane') or row.get('strategy_lane') or '').lower()

def _v821_is_trade_candidate(row: Dict[str, Any]) -> bool:
    if row.get('trade_candidate_row_v661') is True or row.get('paper_candidate_row') is True:
        return True
    lane = _v821_lane(row)
    if lane in ('coverage','raw','market','scanner_only','coverage_light'):
        return False
    sk = str(row.get('strategy_key') or row.get('strategy') or '')
    if 'coverage' in sk or row.get('v661_coverage_reason'):
        return False
    return _v821_stage(row) in ('S1','S2')

def _v821_counter_top_dict(counter: Counter, limit: int = 20) -> Dict[str, int]:
    return {str(k): int(v) for k, v in counter.most_common(limit)}

def _v821_publish_candidate_lite_snapshot(rows: Any, nowv: Optional[float] = None) -> None:
    if not isinstance(rows, list):
        return
    nowv = nowv or now_ts()
    lite_rows: List[Dict[str, Any]] = []
    stage_counts: Counter = Counter(); all_stage_counts: Counter = Counter(); lane_counts: Counter = Counter()
    mats: Counter = Counter(); reasons: Counter = Counter(); risks: Counter = Counter()
    trade_count = 0; coverage_count = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        st = _v821_stage(row)
        all_stage_counts[st] += 1
        if _v821_is_trade_candidate(row):
            trade_count += 1
            stage_counts[st] += 1
        else:
            coverage_count += 1
        lane_counts[_v821_lane(row) or '-'] += 1
        try:
            chg = fnum(row.get('change_1m_pct'), row.get('price_chg_60s'), default=None)
        except Exception:
            chg = None
        if chg is not None:
            mats['1분가격 정상'] += 1
            if chg <= 0: mats['1분반응 0/음수'] += 1
            elif chg >= 0.35: mats['1분반응 통과'] += 1
            else: mats['1분반응 부족'] += 1
        else:
            mats['1분가격 없음'] += 1
        for k in ('block_reasons','s_stage_reasons','hard_risk_reasons','s1_fail_reasons','why_not_s1'):
            for x in _v821_safe_list(row.get(k), 12):
                reasons[str(x)] += 1
        for k in ('risk_tags','warning_tags'):
            for x in _v821_safe_list(row.get(k), 12):
                risks[str(x)] += 1
        lite_rows.append(_v821_compact_candidate_row(row))
    obj = {
        'schema': 'candidate_latest_snapshot_v821',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'row_count': len(lite_rows),
        'trade_count': trade_count,
        'coverage_count': coverage_count,
        'stage_counts': dict(stage_counts),
        'all_stage_counts': dict(all_stage_counts),
        'lane_counts': dict(lane_counts),
        'materials': dict(mats),
        'reason_top': _v821_counter_top_dict(reasons, 30),
        'risk_top': _v821_counter_top_dict(risks, 30),
        'rows_lite': lite_rows,
        'source': 'strategy_worker.paper_candidates_latest.write_owner',
        'policy': 'v821: main commands read this compact snapshot; full paper_candidates_latest remains canonical storage for strategy/paper',
    }
    try:
        save_runtime_json(CANDIDATE_LITE_SNAPSHOT, obj, owner='candidate_lite_v1211')
        _LATEST_PUBLISH_STATUS_V1008.clear()
        _LATEST_PUBLISH_STATUS_V1008.update({
            'latest_publish_ts_v821': nowv,
            'latest_publish_text_v821': obj.get('updated_text'),
            'latest_publish_rows_v821': len(lite_rows),
            'candidate_lite_snapshot_v821': True,
        })
    except Exception as exc:
        append_error(ERROR, 'v1008_candidate_lite_snapshot_save', exc)

VERSION = "strategy_worker_v0.822"

BUILD_LABEL = "structure_scope_recheck_trace_v822_2026-06-11"

MAIN_DEPLOY_VERSION = BUILD_LABEL

def _v822_text_contains_any(txt: str, words: Tuple[str, ...]) -> bool:
    return any(w and w in txt for w in words)

def _v812_setup_type__L17781(row: Dict[str, Any], plan: Dict[str, Any]) -> str:  # type: ignore[override]
    """Narrow the broad liquidity_sweep fallback.

    v821 classified almost every row as liquidity_sweep_recovery because generic
    generated text included sweep/recovery language. Use the actual trigger
    archetype / plan first, and only use liquidity_sweep when explicit raw sweep
    evidence remains.
    """
    plan = plan if isinstance(plan, dict) else {}
    arche = str(plan.get('trigger_archetype_v801') or plan.get('trigger_archetype') or row.get('trigger_archetype_v801') or '')
    plan_reason = str(plan.get('plan_reason') or plan.get('structure_interpretation') or '')
    raw_tags = ' '.join(str(x) for x in (_v812_list(row.get('structure_tags')) + _v812_list(row.get('structure_good_tags_v755')) + _v812_list(row.get('structure_recheck_tags_v755'))))
    raw_txt = ' '.join([arche, plan_reason, raw_tags, str(row.get('strategy_label') or row.get('strategy') or ''), str(row.get('common_pattern_key_v802') or '')])
    low = raw_txt.lower()
    if _v822_text_contains_any(arche, ('VWAP·EMA 방어형', 'VWAP', 'EMA')) or _v822_text_contains_any(low, ('vwap', 'ema')):
        return 'vwap_ema_hold'
    if _v822_text_contains_any(arche, ('돌파 유지형', '박스 상단', '저항돌파')) or _v822_text_contains_any(low, ('breakout', 'box_breakout')):
        return 'breakout_hold'
    if _v822_text_contains_any(arche, ('지지선 반등형', '지지선 반등')) or _v822_text_contains_any(low, ('support_rebound',)):
        return 'support_rebound'
    if _v822_text_contains_any(arche, ('공통 구조형',)) or _v822_text_contains_any(low, ('common_scalp', 'common_structure')):
        return 'common_structure_watch'
    explicit_sweep = _v822_text_contains_any(raw_txt, ('저점유동성쓸림', '쓸림후빠른회복', '저점 쓸림 후 회복')) or _v822_text_contains_any(low, ('liquidity_sweep', 'sweep_reclaim'))
    if explicit_sweep:
        return 'liquidity_sweep_recovery'
    if _v822_text_contains_any(raw_txt, ('눌림', '재가속', '돈흐름')) or _v822_text_contains_any(low, ('pullback', 'reaccel')):
        return 'pullback_reaccel'
    # keep calculated-line rows visible, but do not pretend the setup is sweep.
    if _v822_text_contains_any(arche, ('계산선 재확인형',)):
        return 'calculated_line_recheck'
    return _v822_prev_v812_setup_type(row, plan)

def _v821_compact_candidate_row__L17814(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v822_prev_v821_compact_candidate_row(row)
    # row-level recheck freshness trace for /validation_board. Display only.
    tr = row.get('recheck_freshness_trace_v806')
    if isinstance(tr, dict):
        out['recheck_freshness_trace_v806'] = _v821_lite_dict(tr, ('schema','seen_count','recheck_count','fresh_status','source_event_age_sec','first_seen_age_sec','s2_age_sec','value_changed_count','metric_delta','metrics','stale_reasons','stale_repeat_count','basis'), 12)
    timing = row.get('entry_timing_spine') if isinstance(row.get('entry_timing_spine'), dict) else row.get('entry_timing_trace') if isinstance(row.get('entry_timing_trace'), dict) else {}
    if isinstance(timing, dict) and timing:
        out['entry_timing_spine'] = _v821_lite_dict(timing, ('source_event_age_sec_v752','source_event_age_sec_v750','first_to_s1_delay_sec','first_to_open_delay_sec','s2_to_s1_delay_sec','s2_to_open_delay_sec','first_to_now_return_pct','first_to_current_return_pct'), 12)
    for k in ('source_event_age_sec_v752','source_event_age_sec_v750','source_age_sec','candidate_age_sec','age_sec'):
        if k in row and k not in out:
            out[k] = row.get(k)
    return out

VERSION = "strategy_worker_v0.823"

BUILD_LABEL = "mtf_structure_spine_v823_2026-06-11"

MAIN_DEPLOY_VERSION = BUILD_LABEL

V823_CANDLE_SUFFIXES = (
    'swing_high_price','swing_low_price','box_high_price','box_low_price','recent_high_price','recent_low_price',
    'support_touch_count','resistance_touch_count','upper_wick_pct','lower_wick_pct','vwap_gap_pct','ema5_gap_pct','ema10_gap_pct','ema20_gap_pct',
    'volume_ratio','volume_expansion_pct','breakout_hint','sweep_reclaim_hint','box_breakout_hint','support_reclaim_hint','resistance_reject_hint',
    'pullback_volume_contract','reclaim_volume_expand','long_upper_wick','volume_expanding','close_near_high','change_pct','change'
)

V823_HTF_PREFIXES = ('h4','h2','h1','m60','1h','m30','m15')

V823_MTF_PREFIXES = ('m15','m5','m3')

def _v597_candle_official_fields__L17946(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    """Preserve prefixed 15m/30m/1h candle structure fields for MTF spine.

    Existing v597 only flattened m5/m3/m1/m30 into unprefixed fields. v823 keeps
    the raw prefixed fields as display/structure evidence without changing
    candle_worker ownership or making API calls.
    """
    out = _v823_prev_v597_candle_official_fields(c, nowv)
    if not isinstance(c, dict) or not c:
        return out
    prefixes = V823_HTF_PREFIXES + ('m5','m3','m1')
    present_frames: List[str] = []
    for pref in prefixes:
        frame_has = False
        for suf in V823_CANDLE_SUFFIXES:
            key = f'{pref}_{suf}'
            if c.get(key) not in (None, ''):
                out[key] = c.get(key)
                frame_has = True
        if c.get(f'{pref}_ok') not in (None, ''):
            out[f'{pref}_ok'] = c.get(f'{pref}_ok')
            frame_has = frame_has or bool(c.get(f'{pref}_ok'))
        if frame_has and pref not in present_frames:
            present_frames.append(pref)
    if present_frames:
        out['mtf_structure_frames_v823'] = present_frames
        out['official_candle_intervals'] = '1m/3m/5m/15m/30m/1h'
    return out

def _v823_num_known(row: Dict[str, Any], *keys: str) -> Tuple[float, bool]:
    for k in keys:
        try:
            if isinstance(row, dict) and row.get(k) not in (None, ''):
                return float(str(row.get(k)).replace(',', '').replace('%','')), True
        except Exception:
            continue
    return 0.0, False

def _v823_bool_hint(row: Dict[str, Any], *keys: str) -> bool:
    for k in keys:
        v = row.get(k) if isinstance(row, dict) else None
        if v in (None, '', [], {}):
            continue
        if isinstance(v, bool):
            if v: return True
        elif isinstance(v, (int, float)):
            if float(v) > 0: return True
        else:
            s = str(v).lower()
            if s in ('1','true','yes','y','ok','pass') or any(w in s for w in ('hint','reclaim','breakout','support','확인','돌파','회복','방어')):
                return True
    return False

def _v823_frame_value(row: Dict[str, Any], prefixes: Tuple[str, ...], suffix: str) -> Tuple[float, bool, str]:
    for pref in prefixes:
        v, ok = _v823_num_known(row, f'{pref}_{suffix}')
        if ok:
            return v, True, pref
    return 0.0, False, ''

def _v823_frame_has_any(row: Dict[str, Any], prefixes: Tuple[str, ...]) -> List[str]:
    frames: List[str] = []
    for pref in prefixes:
        found = False
        if row.get(f'{pref}_ok') not in (None, ''):
            found = bool(row.get(f'{pref}_ok'))
        if not found:
            for suf in V823_CANDLE_SUFFIXES:
                if row.get(f'{pref}_{suf}') not in (None, ''):
                    found = True; break
        if found and pref not in frames:
            frames.append(pref)
    return frames

def _v823_ltf_trigger(row: Dict[str, Any], board: Dict[str, Any]) -> Dict[str, Any]:
    survival = board.get('survival_risk') if isinstance(board.get('survival_risk'), dict) else {}
    alive = board.get('alive_check') if isinstance(board.get('alive_check'), dict) else {}
    sm = survival.get('metrics') if isinstance(survival.get('metrics'), dict) else {}
    am = alive.get('metrics') if isinstance(alive.get('metrics'), dict) else {}
    react = _v812_num(am.get('react'), row.get('price_reaction_pct'), row.get('reaction_pct'), default=0.0)
    buy = _v812_num(am.get('buy'), row.get('buy_ratio'), default=0.0)
    sustain = _v812_num(am.get('sustain'), row.get('buy_sustain_1m'), default=0.0)
    spread = _v812_num(sm.get('spread_pct'), row.get('spread_pct'), row.get('spread'), default=99.0)
    slip = _v812_num(sm.get('slippage_pct'), row.get('slippage_pct'), row.get('slippage'), default=spread)
    gap = _v812_num(sm.get('trigger_gap_pct'), row.get('trigger_gap_pct'), row.get('trigger_gap'), default=0.0)
    evidence: List[str] = []
    waiting: List[str] = []
    if react >= 0.20: evidence.append(f'1m 반응 {react:.2f}%')
    if buy >= 0.70 or sustain >= 0.70: evidence.append(f'체결/지속 {buy:.2f}/{sustain:.2f}')
    if -0.08 <= gap <= 0.30 or bool(row.get('trigger_reached')): evidence.append(f'trigger/gap 정상 {gap:.3f}%')
    else: waiting.append(f'trigger/gap 대기 {gap:.3f}%')
    if spread > 0.18 or slip > 0.20: waiting.append(f'실행비용 대기 {spread:.2f}/{slip:.2f}')
    exec_ok = spread <= 0.18 and slip <= 0.20
    trigger_ok = (-0.08 <= gap <= 0.30) or bool(row.get('trigger_reached'))
    confirm_ok = react >= 0.20 or (react >= 0.00 and buy >= 0.75 and sustain >= 0.75)
    passed = bool(exec_ok and trigger_ok and confirm_ok and not bool(row.get('flow_trap_watch_v810')))
    state = 'ltf_trigger_ready' if passed else ('ltf_trigger_wait' if trigger_ok and exec_ok else 'ltf_not_ready')
    return {'state': state, 'pass': passed, 'evidence': _v510_uniq(evidence, 6) if '_v510_uniq' in globals() else evidence[:6], 'waiting': _v510_uniq(waiting, 6) if '_v510_uniq' in globals() else waiting[:6], 'metrics': {'react': react, 'buy': buy, 'sustain': sustain, 'spread_pct': spread, 'slippage_pct': slip, 'trigger_gap_pct': gap}}

def _v821_compact_candidate_row__L18224(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v823_prev_v821_compact_candidate_row(row)
    spine = row.get('mtf_structure_spine_v823')
    if isinstance(spine, dict):
        out['mtf_structure_spine_v823'] = {
            'schema': spine.get('schema'),
            'htf': _v821_lite_dict(spine.get('htf'), ('state','pass','score','frames','evidence','waiting','risk','metrics'), 8),
            'mtf': _v821_lite_dict(spine.get('mtf'), ('state','pass','score','frames','evidence','waiting','risk'), 8),
            'ltf': _v821_lite_dict(spine.get('ltf'), ('state','pass','evidence','waiting','metrics'), 8),
            'policy': spine.get('policy'),
        }
    for k in ('htf_structure_state_v823','mtf_setup_state_v823','ltf_trigger_state_v823','htf_structure_pass_v823','mtf_setup_pass_v823','ltf_trigger_pass_v823'):
        if k in row:
            out[k] = row.get(k)
    return out

VERSION = "strategy_worker_v0.825"

BUILD_LABEL = "runtime_entrypoint_spine_v825_keeps_v824_candle_mtf_2026-06-11"

MAIN_DEPLOY_VERSION = BUILD_LABEL

V824_FRAME_PREFIXES = ('h4','h2','h1','m60','1h','m30','m15','m5','m3','m1')

V824_HTF_PREFIXES = ('h4','h2','h1','m60','1h','m30','m15')

V824_MTF_PREFIXES = ('m15','m5','m3')

V824_STRUCTURE_KEYS = (
    'structure_material_schema_v824','structure_type_v824','structure_line_quality_v824','structure_setup_state_v824','structure_score_v824',
    'structure_reasons_v824','structure_risks_v824','structure_has_box_v824','structure_has_swing_v824','structure_is_breakout_v824',
    'structure_is_sweep_reclaim_v824','structure_hard_risk_v824','box_position_pct','box_range_pct','near_box_low_pct','near_box_high_pct','near_swing_low_pct','near_swing_high_pct'
)

def _v597_candle_official_fields__L18369(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v824_prev_v597_candle_official_fields(c, nowv)
    if not isinstance(c, dict):
        return out
    frames = []
    for pref in V824_FRAME_PREFIXES:
        found = False
        for k, v in c.items():
            if not str(k).startswith(pref + '_'):
                continue
            # Copy structure material and standard OHLCV-derived structure fields.
            suf = str(k)[len(pref)+1:]
            if suf in V823_CANDLE_SUFFIXES or suf in V824_STRUCTURE_KEYS or suf.endswith('_v824'):
                out[k] = v
                found = True
        if c.get(f'{pref}_ok') not in (None, ''):
            out[f'{pref}_ok'] = c.get(f'{pref}_ok')
            found = found or bool(c.get(f'{pref}_ok'))
        if found:
            frames.append(pref)
    if frames:
        out['mtf_structure_frames_v824'] = _v510_uniq(frames, 10) if '_v510_uniq' in globals() else frames[:10]
        out['official_candle_intervals'] = '1m/3m/5m/15m/30m/1h'
        out['official_structure_source'] = 'candle_worker_v824_structure_material'
    return out

def _v824_pref(row: Dict[str, Any], prefixes: Tuple[str, ...], suffix: str, default: Any = None) -> Tuple[Any, str, bool]:
    for pref in prefixes:
        k = f'{pref}_{suffix}'
        if isinstance(row, dict) and row.get(k) not in (None, ''):
            return row.get(k), pref, True
    return default, '', False

def _v824_num(row: Dict[str, Any], prefixes: Tuple[str, ...], suffix: str, default: float = 0.0) -> Tuple[float, str, bool]:
    v, p, ok = _v824_pref(row, prefixes, suffix, None)
    if not ok:
        return default, '', False
    try:
        return float(str(v).replace(',', '').replace('%','')), p, True
    except Exception:
        return default, p, False

def _v824_list_val(v: Any, limit: int = 6) -> List[str]:
    if isinstance(v, list):
        return [str(x) for x in v if str(x).strip()][:limit]
    if v in (None, '', {}, []):
        return []
    return [str(v)][:limit]

def _v824_frame_states__L18418(row: Dict[str, Any], prefixes: Tuple[str, ...]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for pref in prefixes:
        score, _, score_ok = _v824_num(row, (pref,), 'structure_score_v824', 0.0)
        typ, _, typ_ok = _v824_pref(row, (pref,), 'structure_type_v824', '')
        qual, _, qual_ok = _v824_pref(row, (pref,), 'structure_line_quality_v824', '')
        setup, _, setup_ok = _v824_pref(row, (pref,), 'structure_setup_state_v824', '')
        ok = bool(row.get(f'{pref}_ok')) or score_ok or typ_ok or qual_ok or setup_ok
        if not ok:
            continue
        reasons, _, _ = _v824_pref(row, (pref,), 'structure_reasons_v824', [])
        risks, _, _ = _v824_pref(row, (pref,), 'structure_risks_v824', [])
        out.append({'frame': pref, 'score': score, 'type': str(typ or ''), 'quality': str(qual or ''), 'setup': str(setup or ''), 'reasons': _v824_list_val(reasons, 5), 'risks': _v824_list_val(risks, 4)})
    return out

VERSION = "strategy_worker_v0.826"

BUILD_LABEL = "mtf_material_missing_data_spine_v826_2026-06-11"

MAIN_DEPLOY_VERSION = BUILD_LABEL

def _v826_label(v: Any) -> str:
    s = str(v if v is not None else '').strip()
    if not s or s in ('-', 'None', 'none', 'null', 'NULL'):
        return '자료없음'
    for a,b in (('재료없음','자료없음'), ('재료 없음','자료없음'), ('구조재료 없음','구조자료 없음'), ('setup 재료 없음','setup 자료 없음')):
        s = s.replace(a,b)
    return s

def _v826_numeric_htf_structure(row: Dict[str, Any], board: Dict[str, Any]) -> Dict[str, Any]:
    evidence: List[str] = []
    waiting: List[str] = []
    risk: List[str] = []
    score = 0.0
    frames = _v823_frame_has_any(row, V823_HTF_PREFIXES)
    if frames:
        score += 12
    support, support_ok, support_frame = _v823_frame_value(row, V823_HTF_PREFIXES, 'support_touch_count')
    resist, resist_ok, resist_frame = _v823_frame_value(row, V823_HTF_PREFIXES, 'resistance_touch_count')
    lower, lower_ok, lower_frame = _v823_frame_value(row, V823_HTF_PREFIXES, 'lower_wick_pct')
    upper, upper_ok, upper_frame = _v823_frame_value(row, V823_HTF_PREFIXES, 'upper_wick_pct')
    vol, vol_ok, vol_frame = _v823_frame_value(row, V823_HTF_PREFIXES, 'volume_ratio')
    if not support_ok:
        support, support_ok = _v823_num_known(row, 'support_touch_count'); support_frame = 'official' if support_ok else ''
    if not resist_ok:
        resist, resist_ok = _v823_num_known(row, 'resistance_touch_count'); resist_frame = 'official' if resist_ok else ''
    has_low = False; has_high = False
    for suf in ('swing_low_price','box_low_price','recent_low_price'):
        _, ok, _ = _v823_frame_value(row, V823_HTF_PREFIXES, suf)
        if ok: has_low = True; break
    for suf in ('swing_high_price','box_high_price','recent_high_price'):
        _, ok, _ = _v823_frame_value(row, V823_HTF_PREFIXES, suf)
        if ok: has_high = True; break
    if not has_low:
        has_low = any(row.get(k) not in (None,'') for k in ('swing_low_price','box_low_price','recent_low_price'))
    if not has_high:
        has_high = any(row.get(k) not in (None,'') for k in ('swing_high_price','box_high_price','recent_high_price'))
    htf_reclaim = _v823_bool_hint(row, *[f'{p}_support_reclaim_hint' for p in V823_HTF_PREFIXES], *[f'{p}_sweep_reclaim_hint' for p in V823_HTF_PREFIXES], 'support_reclaim_hint','sweep_reclaim_hint')
    htf_breakout = _v823_bool_hint(row, *[f'{p}_box_breakout_hint' for p in V823_HTF_PREFIXES], *[f'{p}_breakout_hint' for p in V823_HTF_PREFIXES], 'box_breakout_hint','breakout_hint')
    if has_low and support_ok and support >= 1:
        score += 18 + min(12, support * 4); evidence.append(f'{support_frame} 지지/스윙저점 반응 {support:g}')
    elif has_low:
        score += 10; evidence.append('15m+ swing/box low 존재')
    if htf_reclaim:
        score += 18; evidence.append('15m+ 저점쓸림/지지회복 힌트')
    if has_high and htf_breakout:
        score += 20; evidence.append('15m+ 박스/전고 돌파 힌트')
    elif has_high and resist_ok and resist >= 1:
        score += 10; evidence.append(f'{resist_frame} 저항/스윙고점 기준선')
    if lower_ok and lower >= 30:
        score += 10; evidence.append(f'{lower_frame} 아랫꼬리 회복 {lower:.0f}%')
    if vol_ok and vol >= 1.15:
        score += 8; evidence.append(f'{vol_frame} 거래량 반응 {vol:.2f}x')
    if upper_ok and upper >= 45 and not htf_breakout:
        risk.append(f'{upper_frame} 상위 윗꼬리 매물 {upper:.0f}%')
    if not frames:
        waiting.append('15m/30m/1h candle 구조자료 없음')
    if not evidence:
        waiting.append('상위구조선 근거 부족')
    has_real_htf_frame = any(f in frames for f in ('m15','m30','m60','h1','1h'))
    passed = bool(score >= 35 and evidence and has_real_htf_frame and not any('윗꼬리' in x for x in risk[:1]))
    state = 'htf_confirmed' if passed and score >= 55 else ('htf_watch' if score >= 25 and evidence else 'htf_missing')
    return {'state': state, 'pass': passed, 'score': round(score, 1), 'frames': frames, 'evidence': _v510_uniq(evidence, 8) if '_v510_uniq' in globals() else evidence[:8], 'waiting': _v510_uniq(waiting, 6) if '_v510_uniq' in globals() else waiting[:6], 'risk': _v510_uniq(risk, 6) if '_v510_uniq' in globals() else risk[:6], 'metrics': {'support_touch': support if support_ok else None, 'resistance_touch': resist if resist_ok else None, 'lower_wick_pct': lower if lower_ok else None, 'upper_wick_pct': upper if upper_ok else None, 'volume_ratio': vol if vol_ok else None}, 'source': 'v823_numeric_fallback_no_candle_v824_material'}

def _v826_numeric_mtf_setup(row: Dict[str, Any], board: Dict[str, Any], htf: Dict[str, Any]) -> Dict[str, Any]:
    plan = board.get('plan') if isinstance(board.get('plan'), dict) else {}
    setup = str(board.get('setup_type') or '')
    plan_state = str(board.get('plan_state') or plan.get('plan_state') or '')
    evidence: List[str] = []
    waiting: List[str] = []
    risk: List[str] = []
    score = 0.0
    frames = _v823_frame_has_any(row, V823_MTF_PREFIXES)
    if frames: score += 8
    support, support_ok, support_frame = _v823_frame_value(row, V823_MTF_PREFIXES, 'support_touch_count')
    lower, lower_ok, lower_frame = _v823_frame_value(row, V823_MTF_PREFIXES, 'lower_wick_pct')
    vol, vol_ok, vol_frame = _v823_frame_value(row, V823_MTF_PREFIXES, 'volume_ratio')
    mtf_reclaim = _v823_bool_hint(row, *[f'{p}_support_reclaim_hint' for p in V823_MTF_PREFIXES], *[f'{p}_sweep_reclaim_hint' for p in V823_MTF_PREFIXES], 'support_reclaim_hint','sweep_reclaim_hint')
    mtf_breakout = _v823_bool_hint(row, *[f'{p}_box_breakout_hint' for p in V823_MTF_PREFIXES], *[f'{p}_breakout_hint' for p in V823_MTF_PREFIXES], 'box_breakout_hint','breakout_hint')
    if setup in ('breakout_hold','box_breakout_hold') or '돌파' in plan_state:
        score += 8; evidence.append('구조계획 돌파/유지형')
    if setup in ('vwap_ema_hold','support_rebound','liquidity_sweep_recovery'):
        score += 6; evidence.append('방어/회복형 setup')
    if support_ok and support >= 1:
        score += 10; evidence.append(f'{support_frame} setup 지지반응 {support:g}')
    if lower_ok and lower >= 25:
        score += 8; evidence.append(f'{lower_frame} 아랫꼬리 회복 {lower:.0f}%')
    if vol_ok and vol >= 1.10:
        score += 7; evidence.append(f'{vol_frame} 거래량 보조 {vol:.2f}x')
    if mtf_reclaim:
        score += 10; evidence.append('3m/5m/15m 회복 힌트')
    if mtf_breakout:
        score += 10; evidence.append('3m/5m/15m 돌파 힌트')
    if not frames:
        waiting.append('3m/5m/15m setup 자료 없음')
    if not evidence:
        waiting.append('중간 setup 근거 부족')
    passed = bool(score >= 24 and evidence)
    state = 'mtf_setup_confirmed' if passed and score >= 38 else ('mtf_setup_watch' if score >= 18 and evidence else 'mtf_setup_missing')
    return {'state': state, 'pass': passed, 'score': round(score, 1), 'frames': frames, 'evidence': _v510_uniq(evidence, 8) if '_v510_uniq' in globals() else evidence[:8], 'waiting': _v510_uniq(waiting, 6) if '_v510_uniq' in globals() else waiting[:6], 'risk': risk[:6], 'source': 'v823_numeric_fallback_no_candle_v824_material'}

def _v826_htf_structure(row: Dict[str, Any], board: Dict[str, Any]) -> Dict[str, Any]:
    states = _v824_frame_states(row, V824_HTF_PREFIXES)
    evidence: List[str] = []
    waiting: List[str] = []
    risk: List[str] = []
    score = 0.0
    frames = [s['frame'] for s in states]
    for s in states:
        sc = float(s.get('score') or 0.0)
        score = max(score, sc)
        typ = str(s.get('type') or '')
        qual = str(s.get('quality') or '')
        setup = str(s.get('setup') or '')
        if qual in ('confirmed_line','reaction_line'):
            evidence.append(f"{s['frame']} {qual}/{typ or setup}")
        elif typ and typ != 'common_structure_watch':
            evidence.append(f"{s['frame']} {typ}")
        for r in s.get('reasons') or []:
            evidence.append(f"{s['frame']} {_v826_label(r)}")
        for rr in s.get('risks') or []:
            risk.append(f"{s['frame']} {_v826_label(rr)}")
    if not states:
        return _v826_numeric_htf_structure(row, board)
    hard_risk = any('윗꼬리' in x or '거절' in x for x in risk[:3])
    confirmed_frames = [s for s in states if str(s.get('quality')) == 'confirmed_line' or str(s.get('setup')) == 'setup_confirmed']
    passed = bool(confirmed_frames and score >= 38 and not hard_risk)
    state = 'htf_confirmed' if passed else ('htf_watch' if evidence else 'htf_missing')
    if not evidence:
        waiting.append('15m/30m/1h 구조자료 부족')
    return {'state': state, 'pass': passed, 'score': round(score, 1), 'frames': frames, 'evidence': _v510_uniq(evidence, 10) if '_v510_uniq' in globals() else evidence[:10], 'waiting': _v510_uniq(waiting, 6) if '_v510_uniq' in globals() else waiting[:6], 'risk': _v510_uniq(risk, 6) if '_v510_uniq' in globals() else risk[:6], 'source': 'candle_worker_v824_structure_material'}

def _v826_mtf_setup(row: Dict[str, Any], board: Dict[str, Any], htf: Dict[str, Any]) -> Dict[str, Any]:
    states = _v824_frame_states(row, V824_MTF_PREFIXES)
    evidence: List[str] = []
    waiting: List[str] = []
    risk: List[str] = []
    score = 0.0
    frames = [s['frame'] for s in states]
    for s in states:
        sc = float(s.get('score') or 0.0)
        score = max(score, sc)
        typ = str(s.get('type') or '')
        qual = str(s.get('quality') or '')
        setup = str(s.get('setup') or '')
        if setup == 'setup_confirmed' or qual in ('confirmed_line','reaction_line'):
            evidence.append(f"{s['frame']} {setup or qual}/{typ}")
        elif typ and typ != 'common_structure_watch':
            evidence.append(f"{s['frame']} {typ}")
        for r in s.get('reasons') or []:
            evidence.append(f"{s['frame']} {_v826_label(r)}")
        for rr in s.get('risks') or []:
            risk.append(f"{s['frame']} {_v826_label(rr)}")
    if not states:
        return _v826_numeric_mtf_setup(row, board, htf)
    confirmed = any(str(s.get('setup')) == 'setup_confirmed' or str(s.get('quality')) == 'confirmed_line' for s in states)
    passed = bool((confirmed and score >= 32) or (bool(htf.get('pass')) and score >= 28 and evidence))
    state = 'mtf_setup_confirmed' if passed else ('mtf_setup_watch' if evidence else 'mtf_setup_missing')
    if not evidence:
        waiting.append('3m/5m/15m setup 구조자료 부족')
    return {'state': state, 'pass': passed, 'score': round(score, 1), 'frames': frames, 'evidence': _v510_uniq(evidence, 10) if '_v510_uniq' in globals() else evidence[:10], 'waiting': _v510_uniq(waiting, 6) if '_v510_uniq' in globals() else waiting[:6], 'risk': _v510_uniq(risk, 6) if '_v510_uniq' in globals() else risk[:6], 'source': 'candle_worker_v824_structure_material'}

def _v823_mtf_spine(row: Dict[str, Any], board: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    htf = _v826_htf_structure(row, board)
    mtf = _v826_mtf_setup(row, board, htf)
    ltf = _v823_ltf_trigger(row, board)
    return {'schema': 'mtf_structure_spine_v826_material_or_numeric', 'htf': htf, 'mtf': mtf, 'ltf': ltf, 's1_requirements': ['15m/30m/1h candle structure material or explicit numeric fallback', '3m/5m/15m setup material or explicit numeric fallback', '1m/orderflow trigger'], 'policy': 'strategy seals HTF->MTF->LTF and marks missing material as 자료없음. 1m trigger alone cannot promote S1'}

def _v812_build_structure_board__L18852(row: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    board = _v824_base_v812_build_structure_board(row, nowv)
    if not isinstance(board, dict):
        return board
    spine = _v823_mtf_spine(row, board)
    board['mtf_structure_spine_v823'] = spine
    board['mtf_structure_spine_v824'] = spine
    board['mtf_structure_spine_v826'] = spine
    board['htf_structure_state_v823'] = (spine.get('htf') or {}).get('state')
    board['mtf_setup_state_v823'] = (spine.get('mtf') or {}).get('state')
    board['ltf_trigger_state_v823'] = (spine.get('ltf') or {}).get('state')
    board['htf_structure_pass_v823'] = bool((spine.get('htf') or {}).get('pass'))
    board['mtf_setup_pass_v823'] = bool((spine.get('mtf') or {}).get('pass'))
    board['ltf_trigger_pass_v823'] = bool((spine.get('ltf') or {}).get('pass'))
    board['htf_structure_source_v824'] = _v826_label((spine.get('htf') or {}).get('source'))
    board['mtf_setup_source_v824'] = _v826_label((spine.get('mtf') or {}).get('source'))
    board['structure_material_status_v826'] = '자료있음' if ((spine.get('htf') or {}).get('frames') or (spine.get('mtf') or {}).get('frames')) else '자료없음'
    board['policy'] = 'v826: candle_worker HTF/MTF 구조자료 -> strategy MTF spine; missing material is 자료없음; no threshold change'
    if str(board.get('stage') or '') == 'S1':
        missing: List[str] = []
        if not board.get('htf_structure_pass_v823'):
            missing += ['v826 S1승격 보류: HTF 구조자료/상위구조 부족'] + list(((spine.get('htf') or {}).get('waiting') or [])[:2])
        if not board.get('mtf_setup_pass_v823'):
            missing += ['v826 S1승격 보류: MTF setup 자료/근거 부족'] + list(((spine.get('mtf') or {}).get('waiting') or [])[:2])
        if not board.get('ltf_trigger_pass_v823'):
            missing += ['v826 진입trigger 대기'] + list(((spine.get('ltf') or {}).get('waiting') or [])[:2])
        missing = [_v826_label(x) for x in missing]
        if missing:
            board['stage'] = 'S2'
            board['role'] = 'mtf_structure_recheck'
            board['stage_reasons'] = _v510_uniq(missing + list(board.get('stage_reasons') or [])[:4], 12) if '_v510_uniq' in globals() else (missing + list(board.get('stage_reasons') or [])[:4])[:12]
        else:
            board['role'] = 'mtf_structure_s1_candidate'
            board['stage_reasons'] = _v510_uniq(list(board.get('stage_reasons') or []) + ['v826 MTF 구조 spine 통과'], 12) if '_v510_uniq' in globals() else (list(board.get('stage_reasons') or []) + ['v826 MTF 구조 spine 통과'])[:12]
    elif str(board.get('stage') or '') == 'S2':
        if board.get('htf_structure_pass_v823') and board.get('mtf_setup_pass_v823'):
            board['role'] = 'mtf_quality_recheck'
            board['stage_reasons'] = _v510_uniq(['v826 MTF 구조 재확인 상위'] + list(board.get('stage_reasons') or []), 12) if '_v510_uniq' in globals() else (['v826 MTF 구조 재확인 상위'] + list(board.get('stage_reasons') or []))[:12]
    board['stage_reasons'] = [_v826_label(x) for x in (board.get('stage_reasons') or [])]
    return board

def _v819_force_structure_board_aliases__L18894(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    # Use the current _v812_build_structure_board through _v812_apply_structure_board, then seal aliases.
    r = _v812_apply_structure_board(row, nowv)
    b = r.get('structure_board') if isinstance(r.get('structure_board'), dict) else (r.get('structure_board_v812') if isinstance(r.get('structure_board_v812'), dict) else {})
    if isinstance(b, dict) and b:
        r['structure_board'] = b
        r['structure_board_v812'] = b
        spine = b.get('mtf_structure_spine_v826') if isinstance(b.get('mtf_structure_spine_v826'), dict) else b.get('mtf_structure_spine_v824') if isinstance(b.get('mtf_structure_spine_v824'), dict) else b.get('mtf_structure_spine_v823')
        if isinstance(spine, dict):
            r['mtf_structure_spine_v823'] = spine
            r['mtf_structure_spine_v824'] = spine
            r['mtf_structure_spine_v826'] = spine
        r['structure_board_source'] = 'strategy_worker_v826_writer_owner'
        r['structure_board_build'] = BUILD_LABEL
        r['structure_stage'] = b.get('stage')
        r['structure_stage_v819'] = b.get('stage')
        r['structure_setup_type'] = b.get('setup_type')
        r['structure_setup_type_v812'] = b.get('setup_type')
        r['structure_entry_role'] = b.get('role')
        r['structure_entry_role_v812'] = b.get('role')
        r['structure_entry_role_v819'] = b.get('role')
        r['htf_structure_state_v823'] = b.get('htf_structure_state_v823')
        r['mtf_setup_state_v823'] = b.get('mtf_setup_state_v823')
        r['ltf_trigger_state_v823'] = b.get('ltf_trigger_state_v823')
        r['htf_structure_pass_v823'] = b.get('htf_structure_pass_v823')
        r['mtf_setup_pass_v823'] = b.get('mtf_setup_pass_v823')
        r['ltf_trigger_pass_v823'] = b.get('ltf_trigger_pass_v823')
        r['htf_structure_source_v824'] = b.get('htf_structure_source_v824')
        r['mtf_setup_source_v824'] = b.get('mtf_setup_source_v824')
        r['structure_material_status_v826'] = b.get('structure_material_status_v826')
        ctx = r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}
        ctx = dict(ctx); ctx['mtf_structure_spine_v826'] = spine; r['entry_context'] = ctx
    return r

def _v821_compact_candidate_row__L18929(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v824_prev_v821_compact_candidate_row(row)
    spine = row.get('mtf_structure_spine_v826') if isinstance(row.get('mtf_structure_spine_v826'), dict) else row.get('mtf_structure_spine_v824') if isinstance(row.get('mtf_structure_spine_v824'), dict) else row.get('mtf_structure_spine_v823')
    if isinstance(spine, dict):
        out['mtf_structure_spine_v826'] = {
            'schema': spine.get('schema'),
            'htf': _v821_lite_dict(spine.get('htf'), ('state','pass','score','frames','evidence','waiting','risk','source'), 10),
            'mtf': _v821_lite_dict(spine.get('mtf'), ('state','pass','score','frames','evidence','waiting','risk','source'), 10),
            'ltf': _v821_lite_dict(spine.get('ltf'), ('state','pass','evidence','waiting','metrics'), 8),
            'policy': spine.get('policy'),
        }
    for k in ('htf_structure_source_v824','mtf_setup_source_v824','structure_material_status_v826','htf_structure_state_v823','mtf_setup_state_v823','ltf_trigger_state_v823'):
        if k in row:
            out[k] = row.get(k)
    return out

VERSION = "strategy_worker_v0.827"

BUILD_LABEL = "candle_material_preserve_spine_v827_2026-06-11"

MAIN_DEPLOY_VERSION = BUILD_LABEL

try:
    _v827_suffixes = set()
    try:
        _v827_suffixes.update(list(V823_CANDLE_SUFFIXES))
    except Exception:
        pass
    try:
        _v827_suffixes.update(list(V824_STRUCTURE_KEYS))
    except Exception:
        pass
    _v827_suffixes.update({
        'ok','age_sec','candle_age_sec','source','err',
        # v913 root fix: candle_worker already produces these role-specific fields,
        # but the active v827 preservation list omitted them (and h2/h4 prefixes).
        # Preserve the actual HTF/MTF/LTF source material before candidate creation.
        'major_support_price','major_resistance_price','setup_support_price','setup_resistance_price',
        'execution_high_price','execution_low_price',
        'major_lookback_rows_v871','setup_lookback_rows_v871','execution_lookback_rows_v871',
        'structure_context_schema_v871','structure_context_policy_v871',
        'horizontal_line_schema_v869','horizontal_line_policy_v869','horizontal_line_closed_rows_v869',
        'horizontal_line_recent_rows_v869','horizontal_line_longer_rows_v869',
        'strategy_is_tag_only_v871','conditions_changed_v871','trigger_formula_changed_v871','paper_open_changed_v871',
        'structure_material_schema_v824','structure_type_v824','structure_line_quality_v824',
        'structure_setup_state_v824','structure_score_v824','structure_reasons_v824','structure_risks_v824',
        'structure_has_box_v824','structure_has_swing_v824','structure_is_breakout_v824',
        'structure_is_sweep_reclaim_v824','structure_hard_risk_v824',
        'box_position_pct','box_range_pct','near_box_low_pct','near_box_high_pct','near_swing_low_pct','near_swing_high_pct',
    })
    _v827_prefixes = tuple(dict.fromkeys(list(globals().get('V824_FRAME_PREFIXES', ('h4','h2','h1','m30','m15','m5','m3','m1')))))
    V827_CANDLE_MATERIAL_PRESERVE_KEYS = tuple(dict.fromkeys(
        [f'{p}_{s}' for p in _v827_prefixes for s in _v827_suffixes]
        + ['mtf_structure_frames_v824','mtf_structure_frames_v826','mtf_structure_frames_v827',
           'structure_material_preserve_v827','structure_material_preserve_source_v827']
    ))
    V597_OFFICIAL_STRUCTURE_KEYS = tuple(dict.fromkeys(list(V597_OFFICIAL_STRUCTURE_KEYS) + list(V827_CANDLE_MATERIAL_PRESERVE_KEYS)))  # type: ignore[assignment]
except Exception:
    V827_CANDLE_MATERIAL_PRESERVE_KEYS = ()

def _v597_candle_official_fields__L19060(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v827_prev_v597_candle_official_fields(c, nowv)
    if not isinstance(out, dict):
        out = {}
    if not isinstance(c, dict) or not c:
        return out
    copied = 0
    frames: List[str] = []
    for pref in globals().get('V824_FRAME_PREFIXES', ('h4','h2','h1','m30','m15','m5','m3','m1')):
        pref_copied = False
        for k, v in c.items():
            if not str(k).startswith(str(pref) + '_'):
                continue
            suf = str(k)[len(str(pref))+1:]
            if k in globals().get('V827_CANDLE_MATERIAL_PRESERVE_KEYS', ()) or suf in globals().get('_v827_suffixes', set()) or suf.endswith('_v824'):
                if v not in (None, ''):
                    out[k] = v
                    copied += 1
                    pref_copied = True
        if pref_copied or c.get(f'{pref}_ok') not in (None, ''):
            frames.append(str(pref))
    if copied:
        try:
            out['mtf_structure_frames_v827'] = _v510_uniq(frames, 12) if '_v510_uniq' in globals() else frames[:12]
        except Exception:
            out['mtf_structure_frames_v827'] = frames[:12]
        out['official_structure_source'] = 'candle_worker_role_material_preserved_v913'
        out['structure_material_preserve_v827'] = True
        out['structure_material_preserve_source_v827'] = 'clean_candle_cache_to_strategy_candidate_row'
        role_fields = []
        for _pref in ('h4','h2','h1','m30','m15','m5','m3','m1'):
            for _suf in ('major_support_price','major_resistance_price','setup_support_price','setup_resistance_price','execution_high_price','execution_low_price'):
                _key = f'{_pref}_{_suf}'
                if out.get(_key) not in (None, ''):
                    role_fields.append(_key)
        out['structure_source_hydrated_v913'] = True
        out['structure_source_hydrated_frames_v913'] = frames[:12]
        out['structure_source_role_fields_v913'] = role_fields[:48]
        out['structure_source_hydration_v913'] = {
            'schema': 'structure_source_hydration_v913',
            'source': 'clean_candle_cache_direct_role_material',
            'copied_fields': copied,
            'frames': frames[:12],
            'role_fields': role_fields[:48],
            'role_field_count': len(role_fields),
            'conditions_changed': False,
            'trigger_formula_changed': False,
            'paper_open_changed': False,
        }
    return out

def _v824_frame_states__L19113(row: Dict[str, Any], prefixes: Tuple[str, ...]) -> List[Dict[str, Any]]:  # type: ignore[override]
    states = _v827_prev_v824_frame_states(row, prefixes)
    if states:
        return states
    raw = row.get('official_structure_inputs_raw') if isinstance(row, dict) and isinstance(row.get('official_structure_inputs_raw'), dict) else {}
    if raw:
        merged = dict(row)
        for k, v in raw.items():
            if merged.get(k) in (None, '', [], {}):
                merged[k] = v
        states = _v827_prev_v824_frame_states(merged, prefixes)
        if states:
            return states
    return []

def _v821_compact_candidate_row__L19130(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v827_prev_v821_compact_candidate_row(row)
    if isinstance(row, dict):
        for k in ('structure_material_preserve_v827','structure_material_preserve_source_v827','mtf_structure_frames_v827'):
            if row.get(k) not in (None, '', [], {}):
                out[k] = row.get(k)
    return out

VERSION = "strategy_worker_v0.861"

BUILD_LABEL = "paper_latest_compact_writer_spine_v861_2026-06-12"

MAIN_DEPLOY_VERSION = BUILD_LABEL

PAPER_LATEST_WRITER_STATUS_V861 = BASE_DIR / "clean_strategy_paper_latest_writer_status.json"

def _v861_file_mb(path: Path) -> float:
    try:
        return round(path.stat().st_size / 1024 / 1024, 2) if path.exists() else 0.0
    except Exception:
        return 0.0

def _v861_cleanup_legacy_tmp(path: Path, min_age_sec: float = 2.0) -> Dict[str, Any]:
    res: Dict[str, Any] = {'legacy_tmp_removed': False, 'legacy_tmp_mb_before': 0.0, 'legacy_tmp_mb_after': 0.0, 'hidden_removed': 0, 'notes': []}
    nowv = now_ts() if 'now_ts' in globals() else time.time()
    legacy = path.with_suffix(path.suffix + '.tmp')
    try:
        if legacy.exists():
            res['legacy_tmp_mb_before'] = _v861_file_mb(legacy)
            age = nowv - legacy.stat().st_mtime
            if age >= min_age_sec:
                legacy.unlink()
                res['legacy_tmp_removed'] = True
            else:
                res['notes'].append(f'legacy_tmp_young_age={age:.1f}s')
        res['legacy_tmp_mb_after'] = _v861_file_mb(legacy)
    except Exception as exc:
        res['notes'].append(f'legacy_tmp_cleanup_error={exc.__class__.__name__}: {exc}')
    try:
        for hp in path.parent.glob(f'.{path.name}.strategy.*.tmp'):
            try:
                if nowv - hp.stat().st_mtime > 60:
                    hp.unlink()
                    res['hidden_removed'] = int(res.get('hidden_removed') or 0) + 1
            except Exception as exc:
                res['notes'].append(f'hidden_tmp_cleanup_error={hp.name}:{exc.__class__.__name__}')
    except Exception as exc:
        res['notes'].append(f'hidden_glob_error={exc.__class__.__name__}: {exc}')
    return res

VERSION = 'strategy_worker_v0.864'

BUILD_LABEL = 'trigger_source_audit_no_relax_v864_2026-06-13'

MAIN_DEPLOY_VERSION = 'v2.13.864'

def collect_trigger_source_audit_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra or {})
    try:
        buckets = Counter(str((r.get('trigger_source_review_v864') or {}).get('bucket') or r.get('trigger_source_bucket_v864') or '-') for r in rows if isinstance(r, dict))
        flags = Counter()
        for r in rows if isinstance(rows, list) else []:
            for f in (r.get('trigger_source_flags_v864') or []):
                flags[str(f)] += 1
        extra.update({
            'schema_extra_v864': 'trigger_source_audit_status_v864',
            'strategy_version_v864': VERSION,
            'strategy_build_v864': BUILD_LABEL,
            'trigger_source_bucket_top_v864': dict(buckets.most_common(8)),
            'trigger_source_flag_top_v864': dict(flags.most_common(8)),
            'v863_reanchor_revoked': True,
            'conditions_changed_v864': False,
            'trigger_formula_changed_v864': False,
            'paper_open_changed_v864': False,
            'policy_v864': 'source audit only; v863 reanchor do-not-apply',
        })
    except Exception as exc:
        append_error(ERROR, 'collect_trigger_source_audit_status', exc)
    return extra

VERSION = 'strategy_worker_v0.868'

BUILD_LABEL = 'trigger_source_dedup_spine_v868_2026-06-13'

MAIN_DEPLOY_VERSION = 'v2.13.868'

def collect_trigger_source_dedup_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra or {})
    try:
        buckets: Counter = Counter()
        flags: Counter = Counter()
        keys: Counter = Counter()
        rows_list = rows if isinstance(rows, list) else []
        for r in rows_list:
            if not isinstance(r, dict):
                continue
            review = r.get('trigger_source_review_v868') if isinstance(r.get('trigger_source_review_v868'), dict) else {}
            buckets[str(review.get('bucket') or r.get('trigger_source_bucket_v868') or '-')] += 1
            dk = str(review.get('dedup_key') or r.get('trigger_dedup_key_v868') or '')
            if dk:
                keys[dk] += 1
            for f in (review.get('risk_flags') or r.get('trigger_source_flags_v868') or []):
                flags[str(f)] += 1
        duplicate_rows = sum(max(0, c - 1) for c in keys.values())
        extra.update({
            'schema_extra_v868': 'trigger_source_dedup_status_v868',
            'strategy_version_v868': VERSION,
            'strategy_build_v868': BUILD_LABEL,
            'trigger_source_bucket_top_v868': dict(buckets.most_common(8)),
            'trigger_source_flag_top_v868': dict(flags.most_common(8)),
            'trigger_dedup_unique_keys_v868': len(keys),
            'trigger_dedup_duplicate_rows_v868': duplicate_rows,
            'trigger_dedup_policy_v868': 'dedup for audit counts only; duplicated rows are not treated as real misses',
            'conditions_changed_v868': False,
            'trigger_formula_changed_v868': False,
            'paper_open_changed_v868': False,
            'v863_reanchor_revoked': True,
        })
    except Exception as exc:
        append_error(ERROR, 'collect_trigger_source_dedup_status', exc)
    return extra

VERSION = 'strategy_worker_v0.871'

BUILD_LABEL = 'structure_context_spine_v871_2026-06-13'

MAIN_DEPLOY_VERSION = 'v2.13.871'

_V869_TF_ORDER = (
    ('m1','1m'), ('m3','3m'), ('m5','5m'), ('m15','15m'), ('m30','30m'), ('h1','1h'), ('h2','2h'), ('h4','4h'),
)

try:
    V597_OFFICIAL_STRUCTURE_KEYS = tuple(dict.fromkeys(list(V597_OFFICIAL_STRUCTURE_KEYS) + list(_V869_LEVEL_SUFFIXES) + [f'{p}_{s}' for p,_l in _V869_TF_ORDER for s in _V869_LEVEL_SUFFIXES]))  # type: ignore[assignment]
except Exception:
    pass

def _v869_num_any(*vals: Any, default: float = 0.0) -> float:
    try:
        return _v510_num(*vals, default=default)
    except Exception:
        for v in vals:
            try:
                if v not in (None, '', [], {}):
                    return float(str(v).replace(',', '').replace('%', ''))
            except Exception:
                continue
        return default

def _v869_pct_between(a: float, b: float) -> float:
    try:
        return (float(a) - float(b)) / max(abs(float(b)), 1e-12) * 100.0
    except Exception:
        return 999999.0

def _v869_pick_first(row: Dict[str, Any], *keys: str) -> Any:
    for k in keys:
        try:
            v = row.get(k)
            if v not in (None, '', [], {}):
                return v
        except Exception:
            pass
    return None

def _v869_collect_line_candidates(row: Dict[str, Any], price: float) -> List[Dict[str, Any]]:
    r = row if isinstance(row, dict) else {}
    out: List[Dict[str, Any]] = []
    suffixes = ('swing_high_price','swing_low_price','box_high_price','box_low_price','recent_high_price','recent_low_price')
    # Unprefixed values are kept as a fallback, but prefixed TF material is preferred.
    sources: List[Tuple[str, str, str]] = [('base','base','')]
    sources += [(p, label, f'{p}_') for p,label in _V869_TF_ORDER]
    for pref, label, key_prefix in sources:
        for suf in suffixes:
            keys = [f'{key_prefix}{suf}'] if key_prefix else [suf]
            # Also tolerate already-human labels like 1m_swing_high_price if they exist.
            if key_prefix:
                keys.append(f'{label}_{suf}')
            raw = _v869_pick_first(r, *keys)
            val = _v869_num_any(raw, default=0.0)
            if val <= 0:
                continue
            gap = _v869_pct_between(val, price) if price else 0.0
            if price and abs(gap) > 50.0:
                # Crazy stale/bad levels are not used as chart lines; still no condition change.
                continue
            kind = 'resistance' if 'high' in suf else 'support'
            out.append({'tf': label, 'prefix': pref, 'key': keys[0], 'kind': kind, 'level_type': suf, 'price': round(val, 8), 'gap_pct': round(gap, 4)})
    return out

def _v869_horizontal_line_pack(row: Dict[str, Any], levels: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    r = row if isinstance(row, dict) else {}
    lv = levels if isinstance(levels, dict) else {}
    price = _v869_num_any(r.get('current_price'), r.get('entry_price'), r.get('price'), lv.get('current_price'), default=0.0)
    cands = _v869_collect_line_candidates(r, price)
    support_candidates = [c for c in cands if c.get('kind') == 'support' and (not price or float(c['price']) <= price * 1.0008)]
    resistance_candidates = [c for c in cands if c.get('kind') == 'resistance' and (not price or float(c['price']) >= price * 0.9992)]
    support = max(support_candidates, key=lambda x: float(x['price']), default=None)
    resistance = min(resistance_candidates, key=lambda x: float(x['price']), default=None)
    raw_above_support = min([c for c in cands if c.get('kind') == 'support' and price and float(c['price']) > price], key=lambda x: float(x['price']), default=None)
    raw_below_resistance = max([c for c in cands if c.get('kind') == 'resistance' and price and float(c['price']) < price], key=lambda x: float(x['price']), default=None)
    source_counts: Counter = Counter(str(c.get('tf') or '-') for c in cands)
    return {
        'schema': 'structure_horizontal_line_price_spine_v869',
        'version': VERSION,
        'build': BUILD_LABEL,
        'current_price': round(price, 8) if price else None,
        'support_price': support.get('price') if support else None,
        'support_tf': support.get('tf') if support else None,
        'support_key': support.get('key') if support else None,
        'support_gap_pct': support.get('gap_pct') if support else None,
        'resistance_price': resistance.get('price') if resistance else None,
        'resistance_tf': resistance.get('tf') if resistance else None,
        'resistance_key': resistance.get('key') if resistance else None,
        'resistance_gap_pct': resistance.get('gap_pct') if resistance else None,
        'candidate_count': len(cands),
        'source_tf_counts': dict(source_counts.most_common(8)),
        'lost_support_above_current': raw_above_support,
        'broken_resistance_below_current': raw_below_resistance,
        'policy': 'closed-candle normalized OHLCV horizontal lines; existing trigger formula reused on corrected support/resistance values',
        'conditions_changed_v869': False,
        'trigger_formula_changed_v869': False,
        'paper_open_changed_v869': False,
    }

def _v554_build_structure_levels__L19743(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v869_prev_build_structure_levels(row)
    if not isinstance(levels, dict):
        levels = {}
    try:
        price = _v869_num_any(row.get('current_price'), row.get('entry_price'), row.get('price'), levels.get('current_price'), default=0.0)
        if price <= 0:
            return levels
        line = _v869_horizontal_line_pack(row, levels)
        old = {
            'support_price': levels.get('support_price'),
            'resistance_price': levels.get('resistance_price'),
            'trigger_price': levels.get('trigger_price'),
            'invalid_price': levels.get('invalid_price'),
            'target1_price': levels.get('target1_price'),
            'target2_price': levels.get('target2_price'),
        }
        support = _v869_num_any(line.get('support_price'), levels.get('support_price'), default=0.0)
        resistance = _v869_num_any(line.get('resistance_price'), levels.get('resistance_price'), default=0.0)
        if not support and not resistance:
            levels['structure_horizontal_lines_v869'] = line
            levels['line_price_fix_applied_v869'] = False
            levels['line_price_fix_reason_v869'] = 'no_closed_ohlcv_line_candidate'
            return levels
        fam = _v554_strategy_family(row)
        vwap_gap = _v510_num(row.get('vwap_gap_pct'), row.get('vwap_pos_pct'), row.get('vwap_position_pct'), default=0.0)
        ema_gap = _v510_num(row.get('ema5_gap_pct'), row.get('ema5_pos_pct'), row.get('ma5_gap_pct'), default=0.0)
        react = _v510_num(row.get('price_reaction_pct'), default=0.0)
        ch1 = _v510_num(row.get('change_1m_pct'), row.get('change_1m'), default=0.0)
        ch3 = _v510_num(row.get('change_3m_pct'), row.get('change_3m'), default=0.0)
        spread = _v510_num(row.get('spread_pct'), default=0.0)
        vwap_price = _v554_price_from_gap(price, vwap_gap)
        ema_price = _v554_price_from_gap(price, ema_gap)
        # Strict fallback only when the corrected closed-candle side is absent.
        if not support:
            support = _v869_num_any(vwap_price if vwap_price and vwap_price < price else 0, ema_price if ema_price and ema_price < price else 0, _v554_pct_to_price(price, -0.45), default=0.0)
        if not resistance:
            resistance = _v554_pct_to_price(price, 0.30 + min(max(react, 0.0), 1.2) * 0.15)
        if fam == 'money_reaccel':
            trigger = max(resistance, _v554_pct_to_price(price, 0.18)); invalid = min(support, _v554_pct_to_price(price, -0.35)); target1 = max(resistance, _v554_pct_to_price(trigger, 0.65)); target2 = max(target1, _v554_pct_to_price(trigger, 1.20))
        elif fam == 'sweep_vwap':
            trigger = max(vwap_price or price, _v554_pct_to_price(price, 0.10)); invalid = min(support, _v554_pct_to_price(price, -0.40)); target1 = max(resistance, _v554_pct_to_price(trigger, 0.70)); target2 = max(target1, _v554_pct_to_price(trigger, 1.25))
        elif fam == 'leader_flow':
            trigger = max(resistance, _v554_pct_to_price(price, 0.16)); invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.45)); target1 = max(resistance, _v554_pct_to_price(trigger, 0.55)); target2 = max(target1, _v554_pct_to_price(trigger, 1.10))
        elif fam == 'leader_momentum':
            trigger = max(resistance, _v554_pct_to_price(price, 0.20)); invalid = min(vwap_price or support, ema_price or support, _v554_pct_to_price(price, -0.50)); target1 = max(resistance, _v554_pct_to_price(trigger, 0.70)); target2 = max(target1, _v554_pct_to_price(trigger, 1.35))
        elif fam in {'breakout', 'surge_rebreak', 'hot_rank'}:
            trigger = max(resistance, _v554_pct_to_price(price, 0.25)); invalid = min(support, _v554_pct_to_price(price, -0.50)); target1 = max(resistance, _v554_pct_to_price(trigger, 0.55)); target2 = max(target1, _v554_pct_to_price(trigger, 1.05))
        else:
            trigger = max(resistance, _v554_pct_to_price(price, 0.20)); invalid = min(support, _v554_pct_to_price(price, -0.45)); target1 = max(resistance, _v554_pct_to_price(trigger, 0.65)); target2 = max(target1, _v554_pct_to_price(trigger, 1.15))
        expected_up = _v554_pct_between(target1, price)
        expected_down = abs(_v554_pct_between(invalid, price))
        rr = (expected_up / expected_down) if expected_down > 0 else 0.0
        late_chase = bool((ch1 >= 1.80 or ch3 >= 3.20 or react >= 1.80) and fam in {'leader_flow', 'leader_momentum', 'breakout', 'hot_rank', 'surge_rebreak'})
        if spread >= 0.60:
            late_chase = True
        levels.update({
            'schema': 'structure_levels_v869_closed_ohlcv_horizontal_lines',
            'support_price': _v554_round_price(support),
            'resistance_price': _v554_round_price(resistance),
            'trigger_price': _v554_round_price(trigger),
            'invalid_price': _v554_round_price(invalid),
            'target1_price': _v554_round_price(target1),
            'target2_price': _v554_round_price(target2),
            'distance_to_trigger_pct': round(_v554_pct_between(trigger, price), 3),
            'distance_to_invalid_pct': round(_v554_pct_between(invalid, price), 3),
            'expected_upside_pct': round(expected_up, 3),
            'expected_downside_pct': round(-abs(expected_down), 3),
            'expected_downside_abs_pct': round(abs(expected_down), 3),
            'rr_ratio': round(rr, 2),
            'late_chase_flag': late_chase,
            'status': 'triggered' if price >= trigger * 0.999 else 'waiting',
            'structure_horizontal_lines_v869': line,
            'line_price_fix_applied_v869': True,
            'old_levels_v869': old,
            'line_price_policy_v869': 'same trigger formula reapplied after correcting support/resistance source from closed OHLCV horizontal lines',
            'conditions_changed_v869': False,
            'trigger_formula_changed_v869': False,
            'paper_open_changed_v869': False,
        })
    except Exception as exc:
        try: append_error(ERROR, 'v869_build_structure_levels', exc)
        except Exception: pass
    return levels

def collect_structure_line_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra or {})
    try:
        rows_list = rows if isinstance(rows, list) else []
        applied = 0; support_tf = Counter(); resistance_tf = Counter(); missing = 0
        samples = []
        for r in rows_list:
            if not isinstance(r, dict):
                continue
            line = r.get('structure_horizontal_lines_v869') if isinstance(r.get('structure_horizontal_lines_v869'), dict) else {}
            if r.get('line_price_fix_applied_v869'):
                applied += 1
            if line.get('support_tf'):
                support_tf[str(line.get('support_tf'))] += 1
            if line.get('resistance_tf'):
                resistance_tf[str(line.get('resistance_tf'))] += 1
            if not line.get('support_price') and not line.get('resistance_price'):
                missing += 1
            if len(samples) < 5 and (line.get('support_price') or line.get('resistance_price')):
                samples.append({'ticker': r.get('ticker'), 'stage': r.get('s_stage') or r.get('candidate_grade'), 'support': line.get('support_price'), 'support_tf': line.get('support_tf'), 'resistance': line.get('resistance_price'), 'resistance_tf': line.get('resistance_tf'), 'current': line.get('current_price')})
        extra.update({
            'schema_extra_v869': 'structure_horizontal_line_price_status_v869',
            'strategy_version_v869': VERSION,
            'strategy_build_v869': BUILD_LABEL,
            'line_price_fix_rows_v869': applied,
            'line_missing_rows_v869': missing,
            'support_tf_top_v869': dict(support_tf.most_common(8)),
            'resistance_tf_top_v869': dict(resistance_tf.most_common(8)),
            'line_samples_v869': samples,
            'line_policy_v869': 'closed OHLCV support/resistance corrected before existing trigger formula; no threshold/exit/paper OPEN change',
            'conditions_changed_v869': False,
            'trigger_formula_changed_v869': False,
            'paper_open_changed_v869': False,
        })
    except Exception as exc:
        append_error(ERROR, 'collect_structure_line_status', exc)
    return extra

_V871_MAJOR_TFS = (('h4','4h'), ('h2','2h'))

_V871_SETUP_TFS = (('h1','1h'), ('m30','30m'))

_V871_EXEC_TFS = (('m15','15m'), ('m5','5m'))

def _v871_line_num(row: Dict[str, Any], pref: str, *names: str) -> Tuple[float, str]:
    for name in names:
        keys = [f'{pref}_{name}'] if pref else [name]
        if pref:
            # tolerate direct labels that may be written by other workers
            keys.append(f'{pref.replace("m", "").replace("h", "h")}_{name}')
        for k in keys:
            v = _v869_num_any(row.get(k), default=0.0)
            if v > 0:
                return v, k
    return 0.0, ''

def _v871_pick_side(cands: List[Dict[str, Any]], price: float, side: str) -> Tuple[Optional[Dict[str, Any]], List[Dict[str, Any]]]:
    valid: List[Dict[str, Any]] = []
    mismatch: List[Dict[str, Any]] = []
    for c in cands:
        p = _v869_num_any(c.get('price'), default=0.0)
        if p <= 0:
            continue
        if price > 0:
            gap = _v869_pct_between(p, price)
            c['gap_pct'] = round(gap, 4)
            if abs(gap) > 80.0:
                c['bad_reason'] = 'stale_or_scale_mismatch'
                mismatch.append(c); continue
            if side == 'support' and p > price * 1.0008:
                c['bad_reason'] = 'support_above_current'
                mismatch.append(c); continue
            if side == 'resistance' and p < price * 0.9992:
                c['bad_reason'] = 'resistance_below_current'
                mismatch.append(c); continue
        valid.append(c)
    if not valid:
        return None, mismatch
    if side == 'support':
        return max(valid, key=lambda x: float(x.get('price') or 0.0)), mismatch
    return min(valid, key=lambda x: float(x.get('price') or 0.0)), mismatch

def _v871_collect_role_candidates(row: Dict[str, Any], price: float, role: str) -> Dict[str, Any]:
    if role == 'major':
        tfs = _V871_MAJOR_TFS
        sup_names = ('major_support_price','box_low_price','swing_low_price','recent_low_price')
        res_names = ('major_resistance_price','box_high_price','swing_high_price','recent_high_price')
    elif role == 'setup':
        tfs = _V871_SETUP_TFS
        sup_names = ('setup_support_price','box_low_price','swing_low_price','recent_low_price')
        res_names = ('setup_resistance_price','box_high_price','swing_high_price','recent_high_price')
    else:
        tfs = _V871_EXEC_TFS
        sup_names = ('execution_low_price','recent_low_price','swing_low_price')
        res_names = ('execution_high_price','recent_high_price','swing_high_price')
    supports: List[Dict[str, Any]] = []
    resistances: List[Dict[str, Any]] = []
    for pref, tf in tfs:
        sp, sk = _v871_line_num(row, pref, *sup_names)
        rp, rk = _v871_line_num(row, pref, *res_names)
        lookback = _v869_num_any(row.get(f'{pref}_major_lookback_rows_v871'), row.get(f'{pref}_setup_lookback_rows_v871'), row.get(f'{pref}_execution_lookback_rows_v871'), default=0.0)
        if sp > 0:
            supports.append({'role': role, 'side': 'support', 'price': round(sp, 8), 'tf': tf, 'source_key': sk, 'lookback_rows': int(lookback or 0), 'source': f'{role}_support:{tf}:{sk}'})
        if rp > 0:
            resistances.append({'role': role, 'side': 'resistance', 'price': round(rp, 8), 'tf': tf, 'source_key': rk, 'lookback_rows': int(lookback or 0), 'source': f'{role}_resistance:{tf}:{rk}'})
    sup, sup_bad = _v871_pick_side(supports, price, 'support')
    res, res_bad = _v871_pick_side(resistances, price, 'resistance')
    return {'support': sup, 'resistance': res, 'bad': sup_bad + res_bad, 'support_candidates': supports[:8], 'resistance_candidates': resistances[:8]}

def _v871_structure_tags(ctx: Dict[str, Any], row: Dict[str, Any]) -> List[str]:
    tags: List[str] = []
    price = _v869_num_any(ctx.get('current_price'), default=0.0)
    major_sup = ctx.get('major_support') or {}
    major_res = ctx.get('major_resistance') or {}
    setup_sup = ctx.get('setup_support') or {}
    setup_res = ctx.get('setup_resistance') or {}
    exec_trig = ctx.get('execution_trigger') or {}
    def gap(obj):
        return abs(_v869_num_any(obj.get('gap_pct'), default=999.0)) if isinstance(obj, dict) else 999.0
    if major_sup and gap(major_sup) <= 2.5: tags.append('htf_support_near')
    if major_res and gap(major_res) <= 2.5: tags.append('htf_resistance_near')
    if setup_sup and gap(setup_sup) <= 1.0: tags.append('setup_support_retest')
    if setup_res and gap(setup_res) <= 1.0: tags.append('setup_resistance_reclaim_watch')
    if exec_trig and gap(exec_trig) <= 0.35: tags.append('execution_trigger_near')
    if bool(row.get('flow_trap_watch_v810')): tags.append('flow_trap_watch')
    if bool(row.get('quality_recheck_s2_v810')): tags.append('quality_recheck_s2')
    # Legacy strategy labels are copied as descriptors only; never as S1/S2/S3 gates.
    for x in _v553_as_list(row.get('matched_strategy_labels')) + _v553_as_list(row.get('strategy_tags')) + _v553_as_list(row.get('structure_tags')):
        sx = str(x or '').strip()
        if sx and sx not in tags:
            tags.append(sx)
        if len(tags) >= 18:
            break
    return _v510_uniq(tags, 18)

def _v871_structure_context_pack(row: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    price = _v869_num_any(row.get('current_price'), row.get('entry_price'), row.get('price'), levels.get('current_price'), default=0.0)
    major = _v871_collect_role_candidates(row, price, 'major')
    setup = _v871_collect_role_candidates(row, price, 'setup')
    execution = _v871_collect_role_candidates(row, price, 'execution')
    trigger_price = _v869_num_any(levels.get('trigger_price'), row.get('trigger_price'), default=0.0)
    invalid_price = _v869_num_any(levels.get('invalid_price'), row.get('invalid_price'), levels.get('support_price'), default=0.0)
    target_price = _v869_num_any(levels.get('target1_price'), row.get('target1_price'), levels.get('resistance_price'), default=0.0)
    # v914 precision audit values: role validation uses pre-round values without changing execution trigger.
    trigger_price_raw_v914 = _v869_num_any(levels.get('trigger_price_raw_v914'), trigger_price, default=0.0)
    invalid_price_raw_v914 = _v869_num_any(levels.get('invalid_price_raw_v914'), invalid_price, default=0.0)
    target_price_raw_v914 = _v869_num_any(levels.get('target1_price_raw_v914'), target_price, default=0.0)
    exec_res = execution.get('resistance') or {}
    if trigger_price > 0 and price > 0:
        exec_trigger = {'role': 'execution', 'side': 'trigger', 'price': round(trigger_price, 8), 'tf': exec_res.get('tf') or '15m', 'source_key': exec_res.get('source_key') or 'existing_trigger_formula', 'source': 'execution_trigger:existing_formula_after_structure_context', 'gap_pct': round(_v869_pct_between(trigger_price, price), 4)}
    else:
        exec_trigger = {}
    ctx: Dict[str, Any] = {
        'schema': 'structure_context_v871',
        'version': VERSION,
        'build': BUILD_LABEL,
        'current_price': round(price, 8) if price else None,
        'major_support': major.get('support') or {},
        'major_resistance': major.get('resistance') or {},
        'setup_support': setup.get('support') or {},
        'setup_resistance': setup.get('resistance') or {},
        'execution_support': execution.get('support') or {},
        'execution_resistance': execution.get('resistance') or {},
        'execution_trigger': exec_trigger,
        'invalid_price': _v554_round_price(invalid_price) if invalid_price else None,
        'target_price': _v554_round_price(target_price) if target_price else None,
        'target_room_pct': round(_v869_pct_between(target_price, price), 3) if target_price and price else None,
        'trigger_price_raw_v914': round(trigger_price_raw_v914, 12) if trigger_price_raw_v914 else None,
        'invalid_price_raw_v914': round(invalid_price_raw_v914, 12) if invalid_price_raw_v914 else None,
        'target_price_raw_v914': round(target_price_raw_v914, 12) if target_price_raw_v914 else None,
        'structure_price_precision_source_v914': levels.get('structure_price_precision_source_v914') or 'raw_pre_round_context_only_existing_trigger_unchanged',
        'risk_reward': levels.get('rr_ratio') or levels.get('risk_reward') or row.get('rr_ratio'),
        'role_mismatch_samples': (major.get('bad') or [])[:3] + (setup.get('bad') or [])[:3] + (execution.get('bad') or [])[:3],
        'major_ready': bool(major.get('support') or major.get('resistance')),
        'setup_ready': bool(setup.get('support') or setup.get('resistance')),
        'execution_ready': bool(exec_trigger or execution.get('resistance') or execution.get('support')),
        'source_missing': not bool((major.get('support') or major.get('resistance')) and (setup.get('support') or setup.get('resistance')) and (exec_trigger or execution.get('resistance') or execution.get('support'))),
        'strategy_is_tag_only': True,
        'strategy_label_role': 'descriptive_result_tag_only_not_entry_blocker',
        'conditions_changed_v871': False,
        'trigger_formula_changed_v871': False,
        'paper_open_changed_v871': False,
    }
    ctx['structure_tags'] = _v871_structure_tags(ctx, row)
    ctx['entry_context_summary'] = ' / '.join([x for x in [
        f"major {ctx['major_support'].get('price','-')}~{ctx['major_resistance'].get('price','-')}",
        f"setup {ctx['setup_support'].get('price','-')}~{ctx['setup_resistance'].get('price','-')}",
        f"trigger {ctx['execution_trigger'].get('price','-')}",
    ] if x])
    return ctx

def _v554_build_structure_levels__L20079(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    levels = _v871_prev_build_structure_levels(row)
    if not isinstance(levels, dict):
        levels = {}
    try:
        ctx = _v871_structure_context_pack(row, levels)
        levels['structure_context_v871'] = ctx
        if ctx.get('major_support'): levels['major_support_price'] = (ctx.get('major_support') or {}).get('price')
        if ctx.get('major_resistance'): levels['major_resistance_price'] = (ctx.get('major_resistance') or {}).get('price')
        if ctx.get('setup_support'): levels['setup_support_price'] = (ctx.get('setup_support') or {}).get('price')
        if ctx.get('setup_resistance'): levels['setup_resistance_price'] = (ctx.get('setup_resistance') or {}).get('price')
        if ctx.get('execution_trigger'): levels['execution_trigger_price'] = (ctx.get('execution_trigger') or {}).get('price')
        levels['strategy_is_tag_only_v871'] = True
        levels['strategy_label_role_v871'] = 'descriptive_result_tag_only_not_entry_blocker'
        levels['structure_tags_v871'] = ctx.get('structure_tags') or []
        levels['structure_context_source_missing_v871'] = bool(ctx.get('source_missing'))
        levels['structure_role_mismatch_v871'] = bool(ctx.get('role_mismatch_samples'))
        levels['structure_context_policy_v871'] = 'HTF major / MTF setup / LTF execution context; strategy labels are tags only; no thresholds changed'
        levels['conditions_changed_v871'] = False
        levels['trigger_formula_changed_v871'] = False
        levels['paper_open_changed_v871'] = False
    except Exception as exc:
        try: append_error(ERROR, 'v871_build_structure_context', exc)
        except Exception: pass
    return levels

def canonical_structure_context(row: Dict[str, Any]) -> Dict[str, Any]:
    """Return the one canonical structure context regardless of storage depth.

    Candidate construction can carry structure_context_v871 either at the row
    root or under structure_levels. All status/audit readers must use this same
    resolver so display counters cannot diverge from role/source audit truth.
    """
    if not isinstance(row, dict):
        return {}
    ctx = row.get('structure_context_v871')
    if isinstance(ctx, dict) and ctx:
        return ctx
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    ctx = levels.get('structure_context_v871')
    return ctx if isinstance(ctx, dict) else {}

def collect_structure_context_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra or {})
    try:
        rows_list = [r for r in (rows if isinstance(rows, list) else []) if isinstance(r, dict)]
        total = len(rows_list); trade_rows = 0
        major_ready = setup_ready = execution_ready = source_missing = role_mismatch = tag_only = strat_block_sus = 0
        context_rows = top_context_rows = nested_context_rows = 0
        hydration_rows_v913 = hydration_role_rows_v913 = 0
        source_missing_stage_v913 = Counter(); hydration_frames_v913 = Counter()
        major_tf = Counter(); setup_tf = Counter(); exec_tf = Counter(); error_counts = Counter(); samples = []
        for r in rows_list:
            stage = str(r.get('s_stage') or r.get('candidate_grade') or '')
            if stage in {'S1','S2','S3'}:
                trade_rows += 1
            top_ctx = r.get('structure_context_v871') if isinstance(r.get('structure_context_v871'), dict) else {}
            levels = r.get('structure_levels') if isinstance(r.get('structure_levels'), dict) else {}
            nested_ctx = levels.get('structure_context_v871') if isinstance(levels.get('structure_context_v871'), dict) else {}
            ctx = canonical_structure_context(r)
            if not ctx:
                continue
            context_rows += 1
            if top_ctx:
                top_context_rows += 1
            elif nested_ctx:
                nested_context_rows += 1
            if ctx.get('major_ready'): major_ready += 1
            else: error_counts['major_missing'] += 1
            if ctx.get('setup_ready'): setup_ready += 1
            else: error_counts['setup_missing'] += 1
            if ctx.get('execution_ready'): execution_ready += 1
            else: error_counts['execution_missing'] += 1
            if ctx.get('source_missing'):
                source_missing += 1; error_counts['source_missing'] += 1; source_missing_stage_v913[stage or '-'] += 1
            hyd = r.get('structure_source_hydration_v913') if isinstance(r.get('structure_source_hydration_v913'), dict) else {}
            if hyd or r.get('structure_source_hydrated_v913'):
                hydration_rows_v913 += 1
                if (hyd.get('role_field_count') or len(r.get('structure_source_role_fields_v913') or [])):
                    hydration_role_rows_v913 += 1
                for _fr in (hyd.get('frames') or r.get('structure_source_hydrated_frames_v913') or []):
                    hydration_frames_v913[str(_fr)] += 1
            role_flag = bool(r.get('structure_role_mismatch_v871') or levels.get('structure_role_mismatch_v871') or ctx.get('role_mismatch') or ctx.get('role_mismatch_flag') or ctx.get('role_mismatch_samples'))
            if role_flag:
                role_mismatch += 1; error_counts['role_mismatch'] += 1
            if r.get('strategy_is_tag_only_v871') or levels.get('strategy_is_tag_only_v871') or ctx.get('strategy_is_tag_only'):
                tag_only += 1
            if r.get('strategy_blocking_suspect_v871') or levels.get('strategy_blocking_suspect_v871') or ctx.get('strategy_blocking_suspect'):
                strat_block_sus += 1; error_counts['strategy_blocking_suspect'] += 1
            ms = ctx.get('major_support') or {}; mr = ctx.get('major_resistance') or {}; ss = ctx.get('setup_support') or {}; sr = ctx.get('setup_resistance') or {}; et = ctx.get('execution_trigger') or {}
            if ms.get('tf'): major_tf[str(ms.get('tf'))] += 1
            if mr.get('tf'): major_tf[str(mr.get('tf'))] += 1
            if ss.get('tf'): setup_tf[str(ss.get('tf'))] += 1
            if sr.get('tf'): setup_tf[str(sr.get('tf'))] += 1
            if et.get('tf'): exec_tf[str(et.get('tf'))] += 1
            if len(samples) < 6 and (ms or mr or ss or sr or et):
                samples.append({
                    'ticker': r.get('ticker'), 'stage': stage,
                    'current': ctx.get('current_price'),
                    'major_support': ms.get('price'), 'major_support_tf': ms.get('tf'),
                    'major_resistance': mr.get('price'), 'major_resistance_tf': mr.get('tf'),
                    'setup_support': ss.get('price'), 'setup_support_tf': ss.get('tf'),
                    'setup_resistance': sr.get('price'), 'setup_resistance_tf': sr.get('tf'),
                    'trigger': et.get('price'), 'trigger_tf': et.get('tf'),
                    'target': ctx.get('target_price'), 'invalid': ctx.get('invalid_price'),
                    'tags': (ctx.get('structure_tags') or [])[:5],
                })
        extra.update({
            'schema_extra_v871': 'structure_context_status_v871',
            'structure_source_hydration_schema_v913': 'candle_role_material_to_candidate_v913',
            'structure_source_hydrated_rows_v913': hydration_rows_v913,
            'structure_source_role_field_rows_v913': hydration_role_rows_v913,
            'structure_source_hydrated_frame_top_v913': dict(hydration_frames_v913.most_common(10)),
            'structure_source_missing_rows_after_v913': source_missing,
            'structure_source_missing_stage_top_v913': dict(source_missing_stage_v913.most_common(8)),
            'structure_source_policy_v913': 'direct preserve h4/h2/h1/m30 + m15/m5/m3 role-specific candle fields before candidate structure_context; remaining missing rows are sent to candle refresh queue; no thresholds/formulas changed',
            'structure_source_hydration_schema_v914': 'structure_full_htf_mtf_ltf_to_candidate_v914',
            'structure_source_hydrated_rows_v914': hydration_rows_v913,
            'structure_source_role_field_rows_v914': hydration_role_rows_v913,
            'structure_source_hydrated_frame_top_v914': dict(hydration_frames_v913.most_common(10)),
            'structure_source_missing_rows_after_v914': source_missing,
            'structure_source_missing_stage_top_v914': dict(source_missing_stage_v913.most_common(8)),
            'structure_source_policy_v914': 'source_missing rows request full HTF/MTF/LTF candle profile; raw low-price context precision is audit-only; no thresholds/formulas changed',
            'strategy_version_v871': VERSION,
            'strategy_build_v871': BUILD_LABEL,
            'structure_context_rows_v871': total,
            'structure_context_trade_rows_v871': trade_rows,
            'structure_context_found_rows_v1024': context_rows,
            'structure_context_top_rows_v1024': top_context_rows,
            'structure_context_nested_rows_v1024': nested_context_rows,
            'structure_context_reader_owner_v1024': 'strategy_worker.canonical_structure_context',
            'structure_context_reader_consistency_v1024': bool(context_rows == top_context_rows + nested_context_rows),
            'major_ready_rows_v871': major_ready,
            'setup_ready_rows_v871': setup_ready,
            'execution_ready_rows_v871': execution_ready,
            'source_missing_rows_v871': source_missing,
            'role_mismatch_rows_v871': role_mismatch,
            'strategy_tag_only_rows_v871': tag_only,
            'strategy_blocking_suspect_rows_v871': strat_block_sus,
            'line_context_error_counts_v871': dict(error_counts.most_common(8)),
            'major_tf_top_v871': dict(major_tf.most_common(8)),
            'setup_tf_top_v871': dict(setup_tf.most_common(8)),
            'execution_tf_top_v871': dict(exec_tf.most_common(8)),
            'structure_context_samples_v871': samples,
            'strategy_tag_policy_v871': 'strategy labels are descriptive/result-analysis tags only; not entry blockers',
            'structure_context_policy_v871': 'HTF major → MTF setup → LTF execution → invalid/target → quality/result tags',
            'conditions_changed_v871': False,
            'trigger_formula_changed_v871': False,
            'paper_open_changed_v871': False,
        })
    except Exception as exc:
        append_error(ERROR, 'collect_structure_context_status', exc)
    return extra

VERSION = "strategy_worker_v0.888"

BUILD_LABEL = "quality_3m5m_compact_preserve_v888_2026-06-14"

MAIN_DEPLOY_VERSION = "v2.13.888"

def collect_quality_reaction_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra) if isinstance(status_extra, dict) else {}
    rows_list = rows if isinstance(rows, list) else []
    ch3_present = 0
    ch5_present = 0
    ch3_sources: Counter = Counter()
    ch5_sources: Counter = Counter()
    for r in rows_list:
        if not isinstance(r, dict):
            continue
        if r.get('change_3m_present_v888') is True:
            ch3_present += 1
            ch3_sources[str(r.get('change_3m_source_v888') or 'present_unknown')] += 1
        if r.get('change_5m_present_v888') is True:
            ch5_present += 1
            ch5_sources[str(r.get('change_5m_source_v888') or 'present_unknown')] += 1
    total = len(rows_list)
    extra.update({
        'schema_extra_v888': 'quality_3m5m_compact_preserve_status_v888',
        'strategy_version_v888': VERSION,
        'strategy_build_v888': BUILD_LABEL,
        'change_3m_present_rows_v888': ch3_present,
        'change_3m_missing_rows_v888': max(0, total - ch3_present),
        'change_3m_source_top_v888': dict(ch3_sources.most_common(6)),
        'change_5m_present_rows_v888': ch5_present,
        'change_5m_missing_rows_v888': max(0, total - ch5_present),
        'change_5m_source_top_v888': dict(ch5_sources.most_common(6)),
        'after_metrics_done_v888': False,
        'after_metrics_remaining_v888': 'max_after/now_after must be connected from paper/review canonical score snapshot in a later version',
        'conditions_changed_v888': False,
        'trigger_formula_changed_v888': False,
        'paper_open_changed_v888': False,
        'policy_v888': 'preserve existing 3m/5m values only; no new calculation, no thresholds, no paper execution change',
    })
    return extra

VERSION = "strategy_worker_v0.895"

BUILD_LABEL = "stable_follow_key_candidate_seal_v895_2026-06-14"

MAIN_DEPLOY_VERSION = "v2.13.894"

def key_value_present(v: Any) -> bool:
    try:
        if v is None:
            return False
        if isinstance(v, str) and v.strip() == '':
            return False
        if isinstance(v, (list, dict)) and len(v) == 0:
            return False
        return True
    except Exception:
        return False

def normalize_key_ticker(v: Any) -> str:
    try:
        t = str(v or '').upper().strip()
        if t.startswith('KRW-'):
            t = t[4:]
        if t.endswith('_KRW'):
            t = t[:-4]
        return t.replace('/', '').strip()
    except Exception:
        return ''

def split_candidate_event_key(ev: Any) -> Tuple[str, Optional[int]]:
    s = str(ev or '').strip()
    if not s or s == '-':
        return '', None
    parts = s.split(':')
    if len(parts) >= 2 and parts[-1].isdigit():
        try:
            return ':'.join(parts[:-1]), int(parts[-1])
        except Exception:
            return ':'.join(parts[:-1]), None
    return s, None

def candidate_event_id(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    for k in ('event_id','event_key','trace_id','candidate_uid','candidate_id','scan_id','source_scan_id'):
        v = row.get(k)
        if key_value_present(v):
            return str(v)
    return ''

def candidate_follow_prefix(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return ''
    t = normalize_key_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
    lane = str(row.get('canonical_lane') or row.get('lane') or row.get('source_lane') or row.get('strategy_lane') or 'unknown').strip() or 'unknown'
    sk = str(row.get('strategy_key') or row.get('paper_strategy_key') or row.get('strategy') or row.get('strategy_label') or 'unknown').strip() or 'unknown'
    if not t:
        return ''
    return f'{t}:{lane}:{sk}'

def seal_candidate_event_identity(row: Dict[str, Any], out: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    src = row if isinstance(row, dict) else {}
    dst = out if isinstance(out, dict) else {}
    ev = candidate_event_id(src) or candidate_event_id(dst)
    prefix, bucket = split_candidate_event_key(ev)
    if not prefix:
        prefix = candidate_follow_prefix(src) or candidate_follow_prefix(dst)
    if ev:
        dst.setdefault('event_id', ev)
        dst.setdefault('event_key', ev)
    if prefix:
        dst['stable_event_key_v894'] = prefix
        dst['candidate_follow_key_v894'] = prefix
    if bucket is not None:
        dst['stable_event_bucket_v894'] = bucket
        dst['candidate_event_bucket_v894'] = bucket
    # 정확한 OPEN/성과 추적용 build key가 없으면 event_id 기반으로만 채운다.
    # prefix-only 값을 entry_build_key로 쓰지 않아 여러 cycle이 섞이지 않게 한다.
    if not key_value_present(dst.get('entry_build_key')) and ev:
        dst['entry_build_key'] = ev
        dst['entry_build_key_source_v894'] = 'event_id_exact'
    if not key_value_present(dst.get('score_patch_version')):
        dst['score_patch_version'] = BUILD_LABEL
        dst['score_patch_version_source_v894'] = 'strategy_worker_build_label'
    for k in ('created_at','candidate_created_at','detected_ts','event_ts','signal_ts'):
        if key_value_present(src.get(k)) and not key_value_present(dst.get(k)):
            dst[k] = src.get(k)
    if not key_value_present(dst.get('signal_ts')):
        for k in ('candidate_created_at','created_at','event_ts','detected_ts'):
            if key_value_present(dst.get(k)):
                dst['signal_ts'] = dst.get(k)
                dst['signal_ts_source_v894'] = k
                break
    dst['stable_key_sealed_v894'] = bool(prefix)
    dst['stable_key_policy_v894'] = 'candidate_follow_key_v894 is for candidate/result review join; entry_build_key remains exact event_id when filled; no condition or paper execution change'
    dst['conditions_changed_v894'] = False
    dst['trigger_formula_changed_v894'] = False
    dst['paper_open_changed_v894'] = False
    return dst

def collect_stable_follow_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra) if isinstance(status_extra, dict) else {}
    rows_list = rows if isinstance(rows, list) else []
    stable = 0
    entry = 0
    score = 0
    buckets = 0
    for r in rows_list:
        if not isinstance(r, dict):
            continue
        if r.get('stable_key_sealed_v894') is True:
            stable += 1
        if key_value_present(r.get('entry_build_key')):
            entry += 1
        if key_value_present(r.get('score_patch_version')):
            score += 1
        if key_value_present(r.get('stable_event_bucket_v894')):
            buckets += 1
    total = len(rows_list)
    extra.update({
        'schema_extra_v894': 'stable_follow_key_candidate_seal_status_v894',
        'strategy_version_v894': VERSION,
        'strategy_build_v894': BUILD_LABEL,
        'stable_key_sealed_rows_v894': stable,
        'stable_key_missing_rows_v894': max(0, total - stable),
        'entry_build_key_rows_v894': entry,
        'score_patch_version_rows_v894': score,
        'stable_event_bucket_rows_v894': buckets,
        'conditions_changed_v894': False,
        'trigger_formula_changed_v894': False,
        'paper_open_changed_v894': False,
        'policy_v894': 'seal exact event_id based entry_build_key plus stable_event_key_v894 for after-metric join audit; no thresholds or execution change',
    })
    return extra

VERSION = "strategy_worker_v0.896"

BUILD_LABEL = "same_number_alias_candidate_seal_v896_2026-06-14"

MAIN_DEPLOY_VERSION = "v2.13.896"

def seal_candidate_follow_aliases(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    stable = row.get('stable_event_key_v894') or row.get('candidate_follow_key_v894') or row.get('stable_event_key_v895') or row.get('candidate_follow_key_v895')
    entry = row.get('entry_build_key')
    bucket = row.get('stable_event_bucket_v894') or row.get('candidate_event_bucket_v894') or row.get('stable_event_bucket_v895') or row.get('candidate_event_bucket_v895')
    if stable:
        row['stable_event_key_v895'] = stable
        row['candidate_follow_key_v895'] = stable
        row['stable_event_key_v896'] = stable
        row['candidate_follow_key_v896'] = stable
        row['same_number_key_v896'] = stable
    if bucket not in (None, '', '-', [], {}):
        row['stable_event_bucket_v895'] = bucket
        row['candidate_event_bucket_v895'] = bucket
        row['stable_event_bucket_v896'] = bucket
        row['candidate_event_bucket_v896'] = bucket
    row['same_key_sealed_v896'] = bool(stable or entry)
    row['same_key_owner_v896'] = 'strategy_worker_canonical_key_sealer_v920'
    row['same_key_policy_v896'] = 'same candidate/result key for performance board; no trading condition change'
    row['conditions_changed_v896'] = False
    row['trigger_formula_changed_v896'] = False
    row['paper_open_changed_v896'] = False
    return row

def collect_candidate_alias_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra) if isinstance(status_extra, dict) else {}
    rows_list = rows if isinstance(rows, list) else []
    sealed = sum(1 for r in rows_list if isinstance(r, dict) and r.get('same_key_sealed_v896'))
    entry = sum(1 for r in rows_list if isinstance(r, dict) and r.get('entry_build_key') not in (None,'','-',[],{}))
    score = sum(1 for r in rows_list if isinstance(r, dict) and r.get('score_patch_version') not in (None,'','-',[],{}))
    extra.update({
        'schema_extra_v896': 'same_number_alias_candidate_seal_status_v896',
        'strategy_version_v896': VERSION,
        'strategy_build_v896': BUILD_LABEL,
        'same_key_sealed_rows_v896': sealed,
        'entry_build_key_rows_v896': entry,
        'score_patch_version_rows_v896': score,
        'conditions_changed_v896': False,
        'trigger_formula_changed_v896': False,
        'paper_open_changed_v896': False,
        'policy_v896': 'same_number_key_v896 aliases are for result/performance join only; no thresholds/execution change',
    })
    return extra

VERSION = "strategy_worker_v0.903"

BUILD_LABEL = "cost_source_separation_v903_2026-06-15"

MAIN_DEPLOY_VERSION = "v2.13.903"

def _v903_present(v: Any) -> bool:
    try:
        if v is None:
            return False
        if isinstance(v, str) and v.strip() in ('', '-'):
            return False
        if isinstance(v, (list, dict)) and len(v) == 0:
            return False
        return True
    except Exception:
        return False

def _v903_num(v: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if not _v903_present(v):
            return default
        return float(v)
    except Exception:
        return default

def collect_execution_cost_source_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra) if isinstance(status_extra, dict) else {}
    rows_list = rows if isinstance(rows, list) else []
    reliable = 0
    missing = 0
    derived = 0
    spread_rows = 0
    src_counter: Counter = Counter()
    for r in rows_list:
        if not isinstance(r, dict):
            continue
        if _v903_num(r.get('spread_pct'), None) is not None:
            spread_rows += 1
        if r.get('slippage_reliable_v903') is True:
            reliable += 1
        if r.get('slippage_missing_v903') is True:
            missing += 1
        if r.get('slippage_derived_from_spread_v903') is True:
            derived += 1
        src_counter[str(r.get('slippage_pct_source_v903') or 'missing')] += 1
    total = len(rows_list)
    extra.update({
        'schema_extra_v903': 'execution_cost_source_separation_status_v903',
        'strategy_version_v903': VERSION,
        'strategy_build_v903': BUILD_LABEL,
        'spread_rows_v903': spread_rows,
        'slippage_reliable_rows_v903': reliable,
        'slippage_missing_rows_v903': missing,
        'slippage_derived_from_spread_rows_v903': derived,
        'slippage_source_top_v903': dict(src_counter.most_common(8)),
        'conditions_changed_v903': False,
        'trigger_formula_changed_v903': False,
        'paper_open_changed_v903': False,
        'policy_v903': 'source separation only; legacy slippage remains compatible but confirmed cost board excludes spread-derived slippage',
    })
    return extra

VERSION = "strategy_worker_v0.904"

BUILD_LABEL = "freshness_missing_trace_v904_2026-06-15"

MAIN_DEPLOY_VERSION = "v2.13.904"

def _v904_present(v: Any) -> bool:
    try:
        if v is None: return False
        if isinstance(v,str) and v.strip() in ('','-'): return False
        if isinstance(v,(list,dict)) and len(v)==0: return False
        return True
    except Exception: return False

def _v904_num_or_none(*vals: Any) -> Optional[float]:
    for v in vals:
        try:
            if not _v904_present(v): continue
            f=float(v)
            if f>=99999.0 or f<0: continue
            return f
        except Exception: continue
    return None

def _v904_age_state(age: Optional[float], ttl: float) -> str:
    if age is None: return 'missing'
    return 'fresh' if float(age)<=float(ttl) else 'stale'

def _v584_build_freshness_map(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:  # type: ignore[override]
    row=row if isinstance(row,dict) else {}; created=_event_created_ts(row); paper_age=max(0.0,nowv-created) if created>0 else None
    age_values={'scanner_hot':_v904_num_or_none(row.get('hot_signal_age_sec'),row.get('scanner_hot_age_sec'),row.get('_scanner_hot_cache_age_sec')),'micro':_v904_num_or_none(row.get('micro_age_sec'),row.get('quote_age_sec')),'orderflow':_v904_num_or_none(row.get('orderflow_age_sec')),'price_reaction':_v904_num_or_none(row.get('price_reaction_age_sec'),row.get('feature_age_sec')),'quote':_v904_num_or_none(row.get('quote_age_sec'),row.get('micro_age_sec')),'paper_row':paper_age}
    ttl={'scanner_hot':35.0,'micro':20.0,'orderflow':20.0,'price_reaction':30.0,'quote':20.0,'paper_row':45.0}; owners={'scanner_hot':'scanner_worker','micro':'micro_sidecar/ws','orderflow':'orderflow_worker','price_reaction':'feature_worker','quote':'micro_sidecar/ws','paper_row':'strategy_worker'}
    items={}; stale_fields=[]; missing_fields=[]; stale_only=[]
    for k,age in age_values.items():
        state=_v904_age_state(age,ttl[k]); items[k]={'owner':owners[k],'age_sec':round(float(age),3) if age is not None else None,'ttl_sec':ttl[k],'state':state}
        if state!='fresh':
            stale_fields.append(f'{k} missing' if age is None else f'{k} {float(age):.1f}s')
            if state=='missing': missing_fields.append(k)
            elif state=='stale': stale_only.append(k)
    for x in row.get('stale_reasons') or []:
        sx=str(x or '').strip().replace('999999.0s','missing').replace('999999s','missing')
        if sx and sx not in stale_fields: stale_fields.append(sx)
    core=('micro','orderflow','price_reaction','quote'); states=[items[k]['state'] for k in core]
    overall='fresh_ok' if all(x=='fresh' for x in states) else ('fresh_missing' if any(x=='missing' for x in states) else 'fresh_recheck')
    nums=[float(items[k]['age_sec']) for k in core if items[k].get('age_sec') is not None]; max_core=max(nums) if nums else None
    return {'schema':'freshness_map_v904','overall':overall,'max_core_age_sec':round(max_core,3) if max_core is not None else None,'items':items,'stale_fields':stale_fields[:10],'missing_fields_v904':missing_fields[:10],'stale_only_fields_v904':stale_only[:10],'sentinel_999999_hidden_v904':True,'policy_v904':'999999 sentinel is missing, not an age'}

def collect_freshness_missing_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Collect the canonical missing-field counters without serialising full rows.

    The retired v904 audit converted every full candidate row to ``str(row)`` only
    to search for the text ``999999``.  No runtime reader consumes that counter,
    while the conversion walks and allocates the complete nested candidate payload
    before the real candidate compactor runs.  v1077 keeps the actionable missing
    counters and explicitly retires only that unused full-row text scan.
    """
    extra=dict(status_extra) if isinstance(status_extra,dict) else {}; rows_list=rows if isinstance(rows,list) else []
    missing_counter=Counter(); fresh_missing_rows=0
    for r in rows_list:
        if not isinstance(r,dict): continue
        miss=r.get('freshness_missing_fields_v904') if isinstance(r.get('freshness_missing_fields_v904'),list) else []
        if miss: fresh_missing_rows+=1
        for m in miss: missing_counter[str(m)]+=1
    extra.update({
        'schema_extra_v904':'freshness_missing_trace_status_v904',
        'strategy_version_v904':VERSION,'strategy_build_v904':BUILD_LABEL,
        'fresh_missing_rows_v904':fresh_missing_rows,
        'fresh_missing_top_v904':dict(missing_counter.most_common(8)),
        'sentinel_full_row_text_scan_retired_v1077':True,
        'sentinel_text_rows_audit_v904':None,
        'conditions_changed_v904':False,'trigger_formula_changed_v904':False,'paper_open_changed_v904':False,
        'policy_v904':'freshness missing counters only; unused full-row str(row) sentinel scan retired; no threshold/execution change',
    })
    return extra

VERSION = 'strategy_worker_v0.905'

BUILD_LABEL = 'paper_input_hydration_support_v905_2026-06-15'

VERSION = 'strategy_worker_v0.906'

BUILD_LABEL = 'candidate_input_coverage_seal_v906_2026-06-15'

MAIN_DEPLOY_VERSION = 'v2.13.906'

def _v906_present(v: Any) -> bool:
    try:
        if v is None: return False
        if isinstance(v, str) and v.strip() in ('','-','None','none','null'): return False
        if isinstance(v, (list, dict)) and len(v) == 0: return False
        if isinstance(v, (int, float)) and float(v) >= 99999.0: return False
        return True
    except Exception:
        return False

def _v906_num_or_none(v: Any) -> Optional[float]:
    try:
        if not _v906_present(v): return None
        f = float(v)
        if f < 0 or f >= 99999.0: return None
        return f
    except Exception:
        return None

def _v906_get_path(obj: Any, path: str) -> Any:
    cur = obj
    try:
        for part in str(path).split('.'):
            if isinstance(cur, dict): cur = cur.get(part)
            else: return None
        return cur
    except Exception:
        return None

def _v906_pick(row: Dict[str, Any], paths: Tuple[str, ...]) -> Tuple[Any, str]:
    if not isinstance(row, dict): return None, 'missing'
    for path in paths:
        v = _v906_get_path(row, path) if '.' in path else row.get(path)
        if _v906_present(v): return v, path
    return None, 'missing'

_V906_INPUT_SPECS = {
    'scanner_hot': ('hot_signal_age_sec','scanner_hot_age_sec','_scanner_hot_cache_age_sec','freshness_map.items.scanner_hot.age_sec','source_snapshot.scanner'),
    'micro': ('micro_age_sec','quote_age_sec','freshness_map.items.micro.age_sec','source_snapshot.micro','source_snapshot.quote'),
    'orderflow': ('orderflow_age_sec','trade_age_sec','freshness_map.items.orderflow.age_sec','source_snapshot.orderflow'),
    'price_reaction': ('price_reaction_age_sec','feature_age_sec','freshness_map.items.price_reaction.age_sec','source_snapshot.feature'),
    'quote': ('quote_age_sec','micro_age_sec','freshness_map.items.quote.age_sec','source_snapshot.quote','source_snapshot.micro'),
}

def _v906_input_state(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    ttl = {'scanner_hot':35.0,'micro':20.0,'orderflow':20.0,'price_reaction':30.0,'quote':20.0}
    items = {}; missing=[]; fresh=[]; stale=[]
    for name, paths in _V906_INPUT_SPECS.items():
        raw, src = _v906_pick(row, paths)
        age = _v906_num_or_none(raw)
        if age is None:
            state = 'missing'; missing.append(name)
        elif age <= ttl[name]:
            state = 'fresh'; fresh.append(name)
        else:
            state = 'stale'; stale.append(name)
        items[name] = {'age_sec': round(age,3) if age is not None else None, 'state': state, 'source': src, 'ttl_sec': ttl[name]}
    overall = 'fresh_ok' if all(items[k]['state']=='fresh' for k in ('micro','orderflow','price_reaction','quote')) else ('fresh_missing' if missing else 'fresh_stale')
    return {'schema':'candidate_input_coverage_v906','overall':overall,'items':items,'missing_fields':missing,'fresh_fields':fresh,'stale_fields':stale,'policy':'candidate input coverage only; no entry decision change'}

def collect_candidate_input_coverage_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra) if isinstance(status_extra, dict) else {}
    rows_list = rows if isinstance(rows, list) else []
    total = 0; fresh_ok = 0; missing_rows = 0; field_missing = Counter(); field_fresh = Counter(); overall = Counter()
    for r in rows_list:
        if not isinstance(r, dict): continue
        total += 1
        st = r.get('candidate_input_coverage_v906') if isinstance(r.get('candidate_input_coverage_v906'), dict) else _v906_input_state(r)
        overall[str(st.get('overall') or 'unknown')] += 1
        if st.get('overall') == 'fresh_ok': fresh_ok += 1
        miss = st.get('missing_fields') if isinstance(st.get('missing_fields'), list) else []
        if miss: missing_rows += 1
        for m in miss: field_missing[str(m)] += 1
        for f in st.get('fresh_fields') if isinstance(st.get('fresh_fields'), list) else []: field_fresh[str(f)] += 1
    extra.update({'schema_extra_v906':'candidate_input_coverage_status_v906','strategy_version_v906':VERSION,'strategy_build_v906':BUILD_LABEL,'candidate_input_rows_v906':total,'candidate_input_fresh_ok_rows_v906':fresh_ok,'candidate_input_missing_rows_v906':missing_rows,'candidate_input_overall_top_v906':dict(overall.most_common(8)),'candidate_input_missing_top_v906':dict(field_missing.most_common(8)),'candidate_input_fresh_top_v906':dict(field_fresh.most_common(8)),'conditions_changed_v906':False,'trigger_formula_changed_v906':False,'paper_open_changed_v906':False,'policy_v906':'seals candidate input coverage to latest rows; no S1/S2/S3 or paper execution change'})
    return extra

VERSION = "strategy_worker_v0.907"

BUILD_LABEL = "candidate_worker_cache_overlay_v907_2026-06-15"

def collect_worker_cache_overlay_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    extra = dict(status_extra) if isinstance(status_extra, dict) else {}
    rows_list = rows if isinstance(rows, list) else []
    total = 0; fresh_ok = 0; missing_rows = 0; field_missing = Counter(); field_fresh = Counter(); changed = Counter(); overall = Counter()
    for r in rows_list:
        if not isinstance(r, dict): continue
        total += 1
        st = r.get('candidate_input_coverage_v907') if isinstance(r.get('candidate_input_coverage_v907'), dict) else (r.get('candidate_input_coverage_v906') if isinstance(r.get('candidate_input_coverage_v906'), dict) else {})
        if not st:
            try: st = _v906_input_state(r)
            except Exception: st = {}
        overall[str(st.get('overall') or 'unknown')] += 1
        if st.get('overall') == 'fresh_ok': fresh_ok += 1
        miss = st.get('missing_fields') if isinstance(st.get('missing_fields'), list) else []
        if miss: missing_rows += 1
        for m in miss: field_missing[str(m)] += 1
        for f in st.get('fresh_fields') if isinstance(st.get('fresh_fields'), list) else []: field_fresh[str(f)] += 1
        ov = r.get('worker_cache_overlay_v907') if isinstance(r.get('worker_cache_overlay_v907'), dict) else {}
        for c in ov.get('changed_fields') if isinstance(ov.get('changed_fields'), list) else []: changed[str(c)] += 1
    extra.update({'schema_extra_v907':'worker_cache_overlay_status_v907','strategy_version_v907':VERSION,'strategy_build_v907':BUILD_LABEL,'candidate_input_rows_v907':total,'candidate_input_fresh_ok_rows_v907':fresh_ok,'candidate_input_missing_rows_v907':missing_rows,'candidate_input_overall_top_v907':dict(overall.most_common(8)),'candidate_input_missing_top_v907':dict(field_missing.most_common(8)),'candidate_input_fresh_top_v907':dict(field_fresh.most_common(8)),'worker_cache_overlay_changed_top_v907':dict(changed.most_common(8)),'conditions_changed_v907':False,'trigger_formula_changed_v907':False,'paper_open_changed_v907':False,'policy_v907':'candidate rows read worker caches directly before compact latest; no thresholds/execution change'})
    return extra

VERSION = "strategy_worker_v0.908"

BUILD_LABEL = "candidate_worker_cache_writer_direct_overlay_v908_2026-06-15"

MAIN_DEPLOY_VERSION = BUILD_LABEL

try:
    MICRO_CACHE_V908 = BASE_DIR / "clean_bithumb_micro_cache.json"
except Exception:
    MICRO_CACHE_V908 = Path("clean_bithumb_micro_cache.json")

_V908_CACHE_PATHS = {
    "scanner_hot": SCANNER_HOT,
    "feature": FEATURE,
    "orderflow": ORDERFLOW,
    "micro": MICRO_CACHE_V908,
}

_V908_TTL = {"scanner_hot": 35.0, "price_reaction": 30.0, "orderflow": 20.0, "micro": 20.0, "quote": 20.0}

_V908_CACHE_STORE: Dict[str, Any] = {"ts": 0.0, "maps": {}, "summary": {}}

def _v908_present(v: Any) -> bool:
    try:
        if v is None:
            return False
        if isinstance(v, str) and v.strip() in ("", "-", "None", "none", "null", "nan"):
            return False
        if isinstance(v, (list, dict)) and len(v) == 0:
            return False
        if isinstance(v, (int, float)) and float(v) >= 99999.0:
            return False
        return True
    except Exception:
        return False

def _v908_num(v: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if not _v908_present(v):
            return default
        f = float(str(v).replace(',', '').replace('%', ''))
        if f < 0 or f >= 99999.0:
            return default
        return f
    except Exception:
        return default

def _v908_collect_rows(obj: Any, out: Dict[str, Dict[str, Any]], depth: int = 0) -> None:
    if depth > 5:
        return
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market') or r.get('code'))
                if t:
                    rr = dict(r); rr.setdefault('ticker', t); out[t] = rr
                else:
                    _v908_collect_rows(r, out, depth + 1)
        return
    if not isinstance(obj, dict):
        return
    for ck in ('rows', 'cache', 'items', 'markets', 'tickers', 'data', 'result'):
        v = obj.get(ck)
        if isinstance(v, (list, dict)):
            _v908_collect_rows(v, out, depth + 1)
    for k, v in obj.items():
        if isinstance(v, dict):
            t = ticker_norm(v.get('ticker') or v.get('symbol') or v.get('market') or v.get('code') or k)
            if t:
                rr = dict(v); rr.setdefault('ticker', t); out[t] = rr

def _v908_file_age(path: Path) -> float:
    try:
        return _v521_file_age(path) if '_v521_file_age' in globals() else max(0.0, now_ts() - path.stat().st_mtime)
    except Exception:
        return 999999.0

def _v908_load_map(path: Path, name: str) -> Dict[str, Dict[str, Any]]:
    file_age = _v908_file_age(path)
    try:
        obj = load_json(path, {}) or {}
    except Exception:
        obj = {}
    out: Dict[str, Dict[str, Any]] = {}
    try:
        base = _v521_load_map_with_cache_age(path, name) if '_v521_load_map_with_cache_age' in globals() else {}
        if isinstance(base, dict):
            out.update(base)
    except Exception:
        pass
    extra: Dict[str, Dict[str, Any]] = {}
    _v908_collect_rows(obj, extra)
    for t, r in extra.items():
        rr = dict(out.get(t, {})); rr.update(dict(r))
        rr.setdefault('_cache_name', name)
        rr.setdefault('_cache_age_sec', file_age)
        rr.setdefault('_cache_updated_ts', now_ts() - file_age if file_age < 99999 else None)
        out[t] = rr
    return out

def _v908_cache_maps() -> Tuple[Dict[str, Dict[str, Dict[str, Any]]], Dict[str, Any]]:
    nowv = now_ts()
    if isinstance(_V908_CACHE_STORE.get('maps'), dict) and nowv - float(_V908_CACHE_STORE.get('ts') or 0.0) < 2.0:
        return _V908_CACHE_STORE['maps'], _V908_CACHE_STORE.get('summary') or {}
    maps = {name: _v908_load_map(path, name) for name, path in _V908_CACHE_PATHS.items()}
    summary = {
        'schema': 'worker_cache_map_summary_v908',
        'paths': {name: str(path) for name, path in _V908_CACHE_PATHS.items()},
        'file_age_sec': {name: round(_v908_file_age(path), 3) for name, path in _V908_CACHE_PATHS.items()},
        'map_rows': {name: len(maps.get(name) or {}) for name in _V908_CACHE_PATHS},
    }
    _V908_CACHE_STORE['ts'] = nowv
    _V908_CACHE_STORE['maps'] = maps
    _V908_CACHE_STORE['summary'] = summary
    return maps, summary

def _v908_age_from_row(row: Dict[str, Any], file_age: float, keys: Tuple[str, ...]) -> Optional[float]:
    if not isinstance(row, dict) or not row:
        return None
    for k in keys:
        v = _v908_num(row.get(k), None)
        if v is not None:
            return v
    for k in ('age_sec', 'cache_age_sec', 'row_age_sec', 'updated_age_sec', 'source_age_sec', '_cache_age_sec'):
        v = _v908_num(row.get(k), None)
        if v is not None:
            return v
    for k in ('updated_ts', 'feature_ts', 'orderflow_ts', 'micro_ts', 'quote_ts', 'scanner_ts', 'hot_ts', 'ts', 'timestamp', 'created_at', 'event_ts', 'last_ts', 'last_update_ts'):
        ts = _v908_num(row.get(k), None)
        if ts and ts > 1_000_000_000:
            return max(0.0, now_ts() - ts)
    return file_age if file_age < 99999.0 else None

def _v908_state(age: Optional[float], name: str) -> str:
    if age is None:
        return 'missing'
    return 'fresh' if age <= float(_V908_TTL.get(name, 20.0)) else 'stale'

def _v908_set_age(row: Dict[str, Any], canonical_key: str, legacy_key: str, age: Optional[float], name: str, source: str, changed: List[str], sources: Dict[str, str]) -> None:
    if age is None:
        return
    old = _v908_num(row.get(canonical_key), _v908_num(row.get(legacy_key), None))
    # Replace only missing/stale/older age. Do not turn real fresh age into a new value.
    if old is None or age < old or old > float(_V908_TTL.get(name, 20.0)):
        row[canonical_key] = round(float(age), 3)
        row[legacy_key] = round(float(age), 3)
        changed.append(name)
        sources[name] = source

def _v908_set_material(row: Dict[str, Any], key: str, val: Any, source: str, sources: Dict[str, str]) -> None:
    if not _v908_present(val):
        return
    if _v908_present(row.get(key)):
        return
    row[key] = val
    sources.setdefault(key, source)

def _v908_overlay_candidate_inputs(row: Dict[str, Any], maps: Dict[str, Dict[str, Dict[str, Any]]], cache_summary: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    row = dict(row or {})
    t = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
    if not t:
        return row
    hot = maps.get('scanner_hot', {}).get(t, {}) or {}
    feat = maps.get('feature', {}).get(t, {}) or {}
    of = maps.get('orderflow', {}).get(t, {}) or {}
    micro = maps.get('micro', {}).get(t, {}) or {}
    changed: List[str] = []
    sources: Dict[str, str] = {}
    hot_age = _v908_age_from_row(hot, _v908_file_age(SCANNER_HOT), ('hot_signal_age_sec', 'scanner_hot_age_sec', 'scanner_hot_observed_1m_sec', 'scanner_hot_observed_3m_sec'))
    feat_age = _v908_age_from_row(feat, _v908_file_age(FEATURE), ('price_reaction_age_sec', 'feature_age_sec', 'price_age_sec'))
    order_age = _v908_age_from_row(of, _v908_file_age(ORDERFLOW), ('orderflow_age_sec', 'trade_age_sec'))
    micro_age = _v908_age_from_row(micro, _v908_file_age(MICRO_CACHE_V908), ('micro_age_sec', 'orderbook_age_sec', 'trade_age_sec', 'quote_age_sec'))
    if micro_age is None:
        micro_age = _v908_age_from_row(of, _v908_file_age(ORDERFLOW), ('micro_age_sec', 'trade_age_sec', 'orderbook_age_sec'))
    quote_age = _v908_age_from_row(micro, _v908_file_age(MICRO_CACHE_V908), ('quote_age_sec', 'ws_age_sec', 'orderbook_age_sec', 'micro_age_sec'))
    if quote_age is None:
        quote_age = _v908_age_from_row(of, _v908_file_age(ORDERFLOW), ('quote_age_sec', 'ws_age_sec', 'micro_age_sec'))

    _v908_set_age(row, 'scanner_hot_age_sec', 'hot_signal_age_sec', hot_age, 'scanner_hot', 'scanner_hot_cache', changed, sources)
    _v908_set_age(row, 'price_reaction_age_sec', 'feature_age_sec', feat_age, 'price_reaction', 'feature_cache', changed, sources)
    _v908_set_age(row, 'orderflow_age_sec', 'trade_age_sec', order_age, 'orderflow', 'orderflow_cache', changed, sources)
    _v908_set_age(row, 'micro_age_sec', 'micro_age_sec', micro_age, 'micro', 'micro_cache_or_orderflow_cache', changed, sources)
    _v908_set_age(row, 'quote_age_sec', 'quote_age_sec', quote_age, 'quote', 'micro_cache_or_orderflow_cache', changed, sources)

    if hot:
        row.setdefault('_scanner_hot_cache_age_sec', hot.get('_cache_age_sec', _v908_file_age(SCANNER_HOT)))
        for k in ('scanner_hot_score', 'scanner_hot_rank_1m', 'scanner_hot_rank_3m', 'hot_fresh', 'scanner_hot_fresh'):
            _v908_set_material(row, k, hot.get(k), 'scanner_hot_cache', sources)
    for k in ('price_reaction_pct', 'reaction_pct', 'change_1m', 'change_1m_pct', 'change_3m', 'change_5m', 'change_3m_pct', 'change_5m_pct'):
        _v908_set_material(row, k, feat.get(k), 'feature_cache', sources)
    row = _v1098_copy_feature_quality_fields(row, feat, 'feature_cache_pre_gate_overlay_v1098')
    for k in ('buy_ratio', 'buy_sustain_1m', 'buy_sustain_60s', 'buy_ratio_5s', 'buy_ratio_10s', 'trade_burst_10s', 'price_chg_5s', 'price_chg_10s', 'price_chg_20s', 'price_chg_30s', 'price_chg_60s'):
        _v908_set_material(row, k, of.get(k), 'orderflow_cache', sources)
    for k in ('current_price', 'trade_price', 'quote_price', 'last_price', 'mid_price', 'best_bid', 'bid_price', 'ask_price', 'best_ask', 'spread_pct', 'micro_spread_pct', 'orderbook_spread_pct'):
        _v908_set_material(row, k, micro.get(k), 'micro_cache', sources)
        _v908_set_material(row, k, of.get(k), 'orderflow_cache', sources)
    trade_path = micro.get('trade_path') if isinstance(micro.get('trade_path'), dict) else {}
    if trade_path:
        row['trade_path'] = dict(trade_path)
        row['trade_path_source'] = 'clean_bithumb_micro_cache'
        sources['trade_path'] = 'micro_cache'
    # v1100 canonical slippage transport: Orderflow is the sole value owner.
    # Replace the complete contract every cycle; never retain a prior candidate's stale value.
    _v1100_slippage_keys = (
        'entry_slippage_est_pct','entry_slippage_source','entry_slippage_ts','entry_slippage_age_sec',
        'entry_slippage_confirmed','entry_slippage_basis','entry_slippage_order_amount_krw',
        'entry_slippage_order_amount_state','entry_slippage_owner','slippage_pct_confirmed',
        'slippage_pct_source_v903','slippage_source','slippage_pct','slippage_est_pct','expected_slippage_pct'
    )
    for k in _v1100_slippage_keys:
        row[k] = of.get(k)
        sources[k] = 'orderflow_cache' if k in of else 'orderflow_cache_missing'
    if micro:
        mts = _v510_num(micro.get('ts'), micro.get('updated_ts'), default=0.0)
        if mts > 0:
            row['micro_quote_ts_v917'] = mts
            row['micro_quote_source_v917'] = 'clean_bithumb_micro_cache'

    items: Dict[str, Dict[str, Any]] = {}
    age_map = {'scanner_hot': hot_age, 'price_reaction': feat_age, 'orderflow': order_age, 'micro': micro_age, 'quote': quote_age}
    missing: List[str] = []
    fresh: List[str] = []
    stale: List[str] = []
    for name, age in age_map.items():
        st = _v908_state(age, name)
        if st == 'missing': missing.append(name)
        elif st == 'fresh': fresh.append(name)
        else: stale.append(name)
        src = sources.get(name) or ('scanner_hot_cache' if name == 'scanner_hot' and hot else 'feature_cache' if name == 'price_reaction' and feat else 'orderflow_cache' if name == 'orderflow' and of else 'micro_cache' if name in ('micro', 'quote') and micro else 'orderflow_cache' if name in ('micro', 'quote') and of else 'missing')
        items[name] = {'age_sec': round(float(age), 3) if age is not None else None, 'state': st, 'source': src, 'ttl_sec': float(_V908_TTL.get(name, 20.0))}
        row[f'{name}_age'] = items[name]['age_sec']
        row[f'{name}_state'] = st
        row[f'{name}_source'] = src
    overall = 'fresh_ok' if all(items[k]['state'] == 'fresh' for k in ('micro', 'orderflow', 'price_reaction', 'quote')) else ('fresh_missing' if missing else 'fresh_stale')
    execution_fresh_ok_v1039 = all(items[k]['state'] == 'fresh' for k in ('micro', 'orderflow', 'quote'))
    coverage = {'schema': 'candidate_input_coverage_v1039_split_role', 'overall': overall, 'items': items, 'missing_fields': missing, 'fresh_fields': fresh, 'stale_fields': stale, 'execution_fresh_ok_v1039': execution_fresh_ok_v1039, 'quality_price_reaction_state_v1039': items['price_reaction']['state'], 'quality_final_hard_block_v1039': False, 'policy': 'execution micro/orderflow/quote can block; price reaction freshness and quality metrics remain score/priority/record only'}
    row['candidate_input_coverage_v908'] = coverage
    row['candidate_input_overall_v908'] = overall
    row['candidate_input_missing_fields_v908'] = missing
    row['candidate_input_fresh_fields_v908'] = fresh
    row['candidate_input_fresh_ok_v908'] = bool(overall == 'fresh_ok')
    row['execution_fresh_ok_v1039'] = bool(execution_fresh_ok_v1039)
    row['quality_price_reaction_state_v1039'] = items['price_reaction']['state']
    row['quality_final_hard_block_v1039'] = False
    # Keep v906 names compatible for existing main/paper readers, now rebuilt from v908 worker cache overlay.
    row['candidate_input_coverage_v906'] = coverage
    row['candidate_input_overall_v906'] = overall
    row['candidate_input_missing_fields_v906'] = missing
    row['candidate_input_fresh_fields_v906'] = fresh
    snap = dict(row.get('source_snapshot') if isinstance(row.get('source_snapshot'), dict) else {})
    snap.update({'scanner': row.get('hot_signal_age_sec'), 'feature': row.get('price_reaction_age_sec'), 'orderflow': row.get('orderflow_age_sec'), 'micro': row.get('micro_age_sec'), 'quote': row.get('quote_age_sec'), 'v908_sources': sources})
    row['source_snapshot'] = snap
    row['worker_cache_overlay_status_v908'] = {'schema': 'worker_cache_overlay_row_v908', 'ticker': t, 'changed_fields': sorted(set(changed)), 'sources': sources, 'cache_summary': cache_summary or {}, 'policy': 'writer-direct overlay before PAPER_LATEST compact; no thresholds/execution change'}
    row['worker_cache_overlay_v908'] = row['worker_cache_overlay_status_v908']
    row['conditions_changed_v908'] = False
    row['trigger_formula_changed_v908'] = False
    row['paper_open_changed_v908'] = False
    return row

def _v908_overlay_rows_for_publish(rows: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    maps, cache_summary = _v908_cache_maps()
    out: List[Dict[str, Any]] = []
    total = 0; fresh_ok = 0; missing_rows = 0; overall = Counter(); field_missing = Counter(); field_fresh = Counter(); changed = Counter(); matched = Counter()
    for r in rows if isinstance(rows, list) else []:
        if not isinstance(r, dict):
            continue
        total += 1
        rr = _v908_overlay_candidate_inputs(r, maps, cache_summary)
        out.append(rr)
        st = rr.get('candidate_input_coverage_v908') if isinstance(rr.get('candidate_input_coverage_v908'), dict) else {}
        overall[str(st.get('overall') or 'unknown')] += 1
        if st.get('overall') == 'fresh_ok': fresh_ok += 1
        miss = st.get('missing_fields') if isinstance(st.get('missing_fields'), list) else []
        if miss: missing_rows += 1
        for m in miss: field_missing[str(m)] += 1
        for f in st.get('fresh_fields') if isinstance(st.get('fresh_fields'), list) else []: field_fresh[str(f)] += 1
        ov = rr.get('worker_cache_overlay_status_v908') if isinstance(rr.get('worker_cache_overlay_status_v908'), dict) else {}
        for c in ov.get('changed_fields') if isinstance(ov.get('changed_fields'), list) else []: changed[str(c)] += 1
        t = ticker_norm(rr.get('ticker') or rr.get('market') or rr.get('symbol'))
        if t:
            for name, mp in maps.items():
                if t in mp: matched[name] += 1
    status = {
        'schema_extra_v908': 'worker_cache_overlay_status_v908',
        'strategy_version_v908': VERSION,
        'strategy_build_v908': BUILD_LABEL,
        'candidate_input_rows_v908': total,
        'candidate_input_fresh_ok_rows_v908': fresh_ok,
        'candidate_input_missing_rows_v908': missing_rows,
        'candidate_input_overall_top_v908': dict(overall.most_common(8)),
        'candidate_input_missing_top_v908': dict(field_missing.most_common(8)),
        'candidate_input_fresh_top_v908': dict(field_fresh.most_common(8)),
        'worker_cache_overlay_changed_top_v908': dict(changed.most_common(8)),
        'worker_cache_overlay_matched_top_v908': dict(matched.most_common(8)),
        'worker_cache_map_summary_v908': cache_summary,
        'conditions_changed_v908': False,
        'trigger_formula_changed_v908': False,
        'paper_open_changed_v908': False,
        'policy_v908': 'worker cache overlay runs in _v510_publish immediately before PAPER_LATEST writer; no thresholds/execution change',
    }
    return out, status

def seal_canonical_candidate_keys(rows: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    """Seal exact candidate keys on canonical rows before any observer/compact writer.

    This is metadata-only. It does not alter stage, thresholds, trigger, OPEN or exit.
    """
    total = 0
    event_ready = 0
    entry_ready = 0
    stable_ready = 0
    missing_event = 0
    out: List[Dict[str, Any]] = []
    for source in rows if isinstance(rows, list) else []:
        if not isinstance(source, dict):
            continue
        row = source
        total += 1
        event_before = candidate_event_id(row)
        if event_before:
            event_ready += 1
        # Direct canonical owner: apply in-place before good-S2 observer.
        seal_candidate_event_identity(row, row)
        seal_candidate_follow_aliases(row)
        row['canonical_key_owner_v920'] = 'seal_canonical_candidate_keys'
        row['key_spine_owner_v943'] = 'strategy_key_spine'
        row['key_spine_order_v943'] = 'candidate_exact->good_s2_occurrence->s1_hold->paper_latest'
        row['canonical_key_sealed_v920'] = bool(key_value_present(row.get('entry_build_key')))
        row['canonical_key_policy_v920'] = 'event_id exact only; no ticker/prefix substitution; compact writer preserves sealed metadata'
        row['conditions_changed_v920'] = False
        row['trigger_formula_changed_v920'] = False
        row['paper_open_changed_v920'] = False
        if key_value_present(row.get('entry_build_key')):
            entry_ready += 1
        else:
            missing_event += 1
        if key_value_present(row.get('stable_event_key_v894')) or key_value_present(row.get('stable_event_key_v896')):
            stable_ready += 1
        out.append(row)
    return out, {
        'canonical_rows_v920': total,
        'event_ready_rows_v920': event_ready,
        'entry_build_key_rows_v920': entry_ready,
        'entry_build_key_missing_rows_v920': missing_event,
        'stable_key_rows_v920': stable_ready,
    }

V925_MINIMAL_GATE_STATE = BASE_DIR / 'clean_strategy_swing_gate_state_v977.json'

V925_MINIMAL_GATE_STATUS = BASE_DIR / 'clean_strategy_swing_gate_status_v977.json'

V925_UNTRADABLE_SPREAD_PCT = 1.20

V925_MIN_RR = 1.50

V925_MIN_TARGET_ROOM_PCT = 1.20

V977_MAX_TRIGGER_OVERSHOOT_PCT = 0.60

V925_STATE_RETENTION_SEC = 2 * 24 * 3600.0

def _v925_present(value: Any) -> bool:
    return value not in (None, '', [], {}, '-')

def _v925_num(*values: Any, default: float = 0.0) -> float:
    return fnum(*values, default=default)

def _v925_row_price(row: Dict[str, Any]) -> float:
    return _v925_num(row.get('current_price'), row.get('entry_price'), row.get('live_price'), row.get('trade_price'), row.get('price'), row.get('detected_price'), default=0.0)

def _v925_structure_context(row: Dict[str, Any]) -> Dict[str, Any]:
    ctx = row.get('structure_context_v871') if isinstance(row.get('structure_context_v871'), dict) else {}
    if not ctx:
        levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
        ctx = levels.get('structure_context_v871') if isinstance(levels.get('structure_context_v871'), dict) else {}
    return ctx if isinstance(ctx, dict) else {}

def minimal_gate_state_key(row: Dict[str, Any]) -> str:
    ticker = ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
    return f'market:{ticker}' if ticker else ''

def build_minimal_gate_decision_key(state_key: str, frozen_ts: float) -> str:
    """Build the existing market+frozen-plan decision key without changing its value."""
    plan_started_ms = int(float(frozen_ts) * 1000.0) if frozen_ts and frozen_ts > 0 else 0
    return f'{state_key}|plan:{plan_started_ms}' if state_key and plan_started_ms > 0 else ''

def _v925_actual_line(ctx: Dict[str, Any], key: str, role: str, side: str) -> Dict[str, Any]:
    obj = ctx.get(key) if isinstance(ctx.get(key), dict) else {}
    price = _v925_num(obj.get('price'), default=0.0)
    source = str(obj.get('source') or '').strip()
    source_key = str(obj.get('source_key') or '').strip()
    combined = f'{source}|{source_key}'.lower()
    if price <= 0 or 'existing_trigger_formula' in combined or 'current_plus' in combined or 'calculated' in combined:
        return {}
    return {
        'role': role, 'side': side, 'raw_price': round(price, 12),
        'rounded_price': _v554_round_price(price), 'tf': obj.get('tf'),
        'source': source or f'structure_context_v871.{key}', 'source_key': source_key or key,
    }

def _v925_current_actual_plan(row: Dict[str, Any]) -> Dict[str, Any]:
    """Build the ALT_SWING_V977 structure plan.

    4h/2h decide the major target, 1h/30m provide the structural invalidation,
    and 15m/5m provide the entry trigger. 1m/quote data is execution-only.
    """
    ctx = _v925_structure_context(row)
    price = _v925_row_price(row)
    execution = _v925_actual_line(ctx, 'execution_resistance', 'execution', 'resistance')
    setup_res = _v925_actual_line(ctx, 'setup_resistance', 'setup', 'resistance')
    major_res = _v925_actual_line(ctx, 'major_resistance', 'major', 'resistance')
    setup_sup = _v925_actual_line(ctx, 'setup_support', 'setup', 'support')
    major_sup = _v925_actual_line(ctx, 'major_support', 'major', 'support')

    trigger = execution or {}
    trigger_price = _v925_num(trigger.get('rounded_price'), trigger.get('raw_price'), default=0.0)
    ceiling = min(price, trigger_price) if price > 0 and trigger_price > 0 else trigger_price

    # Invalidation belongs to the setup/major structure, never the 1m execution noise.
    invalid_candidates = [x for x in (setup_sup, major_sup) if x and 0 < _v925_num(x.get('rounded_price'), x.get('raw_price'), default=0.0) < ceiling]
    invalid = max(invalid_candidates, key=lambda x: _v925_num(x.get('rounded_price'), x.get('raw_price'), default=0.0)) if invalid_candidates else {}

    # The first preference is a major (4h/2h) resistance. Setup resistance is fallback only.
    target_candidates = [x for x in (major_res, setup_res) if x and _v925_num(x.get('rounded_price'), x.get('raw_price'), default=0.0) > trigger_price * 1.000001]
    target = target_candidates[0] if target_candidates else {}
    return {
        'schema': 'alt_swing_actual_structure_plan_v977',
        'strategy_mode': 'ALT_SWING_V977',
        'timeframe_contract': {'major':'4h/2h','setup':'1h/30m','entry':'15m/5m','execution':'1m/quote'},
        'current_price': price or None,
        'trigger': trigger,
        'invalid': invalid,
        'target': target,
        'source_context_schema': ctx.get('schema'),
        'policy': 'major direction/target + setup invalidation + entry trigger; no minimum hold time',
    }

def _v925_read_gate_state() -> Tuple[Dict[str, Dict[str, Any]], str]:
    if not V925_MINIMAL_GATE_STATE.exists():
        return {}, 'file_missing'
    try:
        obj = json.loads(V925_MINIMAL_GATE_STATE.read_text(encoding='utf-8', errors='strict'))
        active = obj.get('active') if isinstance(obj, dict) else None
        if not isinstance(active, dict):
            raise ValueError('minimal gate state active map missing')
        return {str(k): v for k, v in active.items() if isinstance(v, dict)}, 'ok'
    except Exception as exc:
        append_error(ERROR, 'v925_minimal_gate_state_read', exc)
        return {}, 'read_error'

def _v925_write_gate_state(active: Dict[str, Dict[str, Any]], nowv: float, read_state: str) -> Dict[str, Any]:
    kept: Dict[str, Dict[str, Any]] = {}
    pruned = 0
    for key, rec in active.items():
        last_seen = _v925_num(rec.get('last_seen_ts'), rec.get('frozen_ts'), default=0.0)
        if last_seen > 0 and nowv - last_seen <= V925_STATE_RETENTION_SEC:
            kept[key] = rec
        else:
            pruned += 1
    payload = {
        'schema': 'swing_gate_plan_state_v977', 'version': 'strategy_worker_v0.961',
        'build': 'v979_swing_contract_cleanup_2026-06-23',
        'updated_ts': nowv, 'updated_text': now_text(nowv), 'read_state_before': read_state,
        'active_count': len(kept), 'pruned_this_cycle': pruned, 'active': kept,
        'policy': 'one market -> one frozen 15m/5m trigger, 1h/30m invalid, 4h/2h target; no old scalp state reuse',
    }
    save_json(V925_MINIMAL_GATE_STATE, payload)
    return payload

def _v925_slippage_confirmed(row: Dict[str, Any]) -> Tuple[Optional[float], str]:
    """Read only the v1100 Orderflow-owned executable slippage contract."""
    source = str(row.get('entry_slippage_source') or '').strip().lower()
    confirmed = row.get('entry_slippage_confirmed') is True
    owner = str(row.get('entry_slippage_owner') or '').strip().lower()
    if not confirmed or owner != 'orderflow_worker':
        return None, 'missing'
    if not source or source in ('missing','none','-'):
        return None, 'missing'
    if 'spread_copy' in source or 'derived_from_spread' in source:
        return None, 'spread_copy_forbidden'
    if not any(token in source for token in ('best_ask_reference_orderflow_v1100','micro_depth_estimate_orderflow_v1100')):
        return None, f'unconfirmed:{source}'
    value = _v925_num(row.get('entry_slippage_est_pct'), default=-1.0)
    return (value if value >= 0 else None), source

def _v925_quality_observation(row: Dict[str, Any]) -> Dict[str, Any]:
    reaction = _v925_num(row.get('price_reaction_pct'), row.get('price_reaction_1m_pct'), default=0.0)
    buy = _v925_num(row.get('buy_ratio'), row.get('buy_strength'), default=0.0)
    sustain = _v925_num(row.get('buy_sustain_1m'), row.get('buy_sustain_60s'), default=0.0)
    spread = _v925_num(row.get('spread_pct'), row.get('micro_spread_pct'), row.get('orderbook_spread_pct'), default=-1.0)
    vwap_gap = _v925_num(row.get('vwap_gap_pct'), default=0.0)
    relative = _v925_num(row.get('relative_strength'), row.get('relative_strength_pct'), default=0.0)
    money = _v925_num(row.get('money_flow_score'), row.get('money_expand_score'), row.get('turnover_change_pct'), default=0.0)
    extreme: List[str] = []
    if reaction <= -0.50 and buy <= 0.35 and sustain <= 0.35:
        extreme.append('가격하락+매수체결약함+지속약함')
    if buy >= 0.75 and reaction <= -0.35 and spread >= 0.35:
        extreme.append('체결강함착시+가격밀림+스프레드확대')
    if bool(row.get('flow_trap_watch_v810')):
        extreme.append('기존체결착시관찰')
    soft_tags: List[str] = []
    for key in ('quality_tags','quality_tags_v871','quality_tags_v884','structure_tags','structure_tags_v871','risk_tags','execution_risk_tags','matched_strategy_labels','strategy_tags'):
        value = row.get(key)
        seq = value if isinstance(value, list) else ([value] if _v925_present(value) else [])
        for item in seq:
            text = str(item.get('tag') if isinstance(item, dict) else item or '').strip()
            if text and text not in soft_tags:
                soft_tags.append(text[:120])
            if len(soft_tags) >= 24: break
        if len(soft_tags) >= 24: break
    return {
        'schema': 'quality_observation_v925_non_blocking', 'observation_only': True,
        'metrics': {'price_reaction_pct':round(reaction,4),'buy_ratio':round(buy,4),'buy_sustain_1m':round(sustain,4),'spread_pct':round(spread,4) if spread>=0 else None,'vwap_gap_pct':round(vwap_gap,4),'relative_strength':round(relative,4),'money_flow':round(money,4)},
        'soft_tags': soft_tags, 'extreme_quality_risk_tags': extreme,
        'policy': 'record/score/review only; no total-score threshold and no S1/paper block',
    }

def _v925_legacy_audit(row: Dict[str, Any]) -> Dict[str, Any]:
    reasons: List[str] = []
    for key in ('block_reasons','s1_missing_conditions','s1_missing_names','why_not_s1','s_stage_reasons','final_trade_reasons','paper_entry_hold_reasons'):
        value = row.get(key)
        seq = value if isinstance(value, list) else ([value] if _v925_present(value) else [])
        for item in seq:
            text = str(item or '').strip()
            if text and text not in reasons: reasons.append(text[:180])
            if len(reasons) >= 30: break
        if len(reasons) >= 30: break
    return {'schema':'legacy_gate_audit_v925_isolated','previous_stage':str(row.get('s_stage') or row.get('candidate_stage') or row.get('grade') or ''),'previous_final_trade_state':row.get('final_trade_state'),'previous_open_eligible':bool(row.get('open_eligible')),'previous_reasons':reasons,'decision_effect':'none_after_v925_final_gate'}

def _v925_plan_price(rec: Dict[str, Any], name: str) -> float:
    obj = rec.get(name) if isinstance(rec.get(name), dict) else {}
    return _v925_num(obj.get('rounded_price'), obj.get('raw_price'), default=0.0)

def _v925_plan_move_pct(current: Dict[str, Any], frozen: Dict[str, Any], name: str) -> float:
    c = current.get(name) if isinstance(current.get(name), dict) else {}
    f = frozen.get(name) if isinstance(frozen.get(name), dict) else {}
    cp = _v925_num(c.get('raw_price'), c.get('rounded_price'), default=0.0)
    fp = _v925_num(f.get('raw_price'), f.get('rounded_price'), default=0.0)
    return abs(pct(cp, fp)) if cp > 0 and fp > 0 else 0.0

V988_OBSERVATION_STRATEGY_KEYS = {
    'coin_quality_s3_observe',
    'coin_quality_s3_observation',
    's3_observe',
}

def _v988_is_s3_observation_only(row: Dict[str, Any]) -> bool:
    """Return True only for the dedicated S3 review lane, never generic S3 rows."""
    if not isinstance(row, dict):
        return False
    sources: List[Dict[str, Any]] = [row]
    for key in ('entry_context','canonical_entry_decision','common_entry_decision','raw'):
        obj=row.get(key)
        if isinstance(obj,dict):
            sources.append(obj)
    flag_keys=(
        's3_observe_v732','s3_observe_v730','s3_observe_v729','s3_observe_v728','s3_observe_v727',
        's3_observation_only_v988','s3_review_only_v988',
    )
    for source in sources:
        if any(source.get(key) is True for key in flag_keys):
            return True
        for key in ('strategy_key','paper_strategy_key','route','strategy','strategy_label','setup_type'):
            text=str(source.get(key) or '').strip().lower()
            if not text:
                continue
            if text in V988_OBSERVATION_STRATEGY_KEYS or text.startswith('coin_quality_s3_observe'):
                return True
            if 's3 관찰/복기 후보' in text or 's3 관찰 후보' in text:
                return True
    return False

def _v1039_execution_freshness(row: Dict[str, Any]) -> Dict[str, Any]:
    """Split execution freshness from non-blocking feature/quality freshness."""
    row = row if isinstance(row, dict) else {}
    coverage = row.get('candidate_input_coverage_v908') if isinstance(row.get('candidate_input_coverage_v908'), dict) else {}
    items = coverage.get('items') if isinstance(coverage.get('items'), dict) else {}
    required = ('micro', 'orderflow', 'quote')
    states = {name: str((items.get(name) or {}).get('state') or 'missing') for name in required}
    execution_ok = all(states.get(name) == 'fresh' for name in required)
    quality_state = str((items.get('price_reaction') or {}).get('state') or 'missing')
    return {
        'schema':'execution_freshness_v1039',
        'execution_fresh_ok':execution_ok,
        'execution_states':states,
        'quality_price_reaction_state':quality_state,
        'quality_final_hard_block':False,
        'policy':'micro/orderflow/quote remain required for executable price/spread/slippage; price reaction and buy metrics are score/priority/record only',
    }

def _v1048_structure_integrity(row: Dict[str, Any], ctx: Dict[str, Any], price: float) -> Dict[str, Any]:
    """v1049 plan-overlap-only structure integrity classifier.

    Distant historical highs/lows can repeat across 1h/2h/4h because 2h/4h
    are derived from the same official 1h history. Distance or repetition alone
    is audit context, not corruption. Fail-closed applies only when a distant raw
    line overlaps the actual trigger/invalid/target contract that would be frozen.
    """
    raw_samples = ctx.get('role_mismatch_samples') if isinstance(ctx, dict) and isinstance(ctx.get('role_mismatch_samples'), list) else []
    stale = [dict(x) for x in raw_samples if isinstance(x, dict) and str(x.get('bad_reason') or '') == 'stale_or_scale_mismatch']
    levels = row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    plan_values: List[float] = []
    for v in (
        row.get('trigger_price'), row.get('entry_trigger_price'), row.get('swing_trigger_price_v977'),
        row.get('invalid_price'), row.get('swing_invalid_price_v977'),
        row.get('target1_price'), row.get('target_price'), row.get('swing_target_price_v977'),
        levels.get('trigger_price'), levels.get('invalid_price'), levels.get('target1_price'),
        (ctx or {}).get('invalid_price'), (ctx or {}).get('target_price'),
    ):
        n = _v869_num_any(v, default=0.0)
        if n > 0:
            plan_values.append(n)

    grouped: Dict[str, set] = {}
    normalized: List[Dict[str, Any]] = []
    overlap_prices: List[float] = []
    setup_or_execution = False
    for item in stale:
        lp = _v869_num_any(item.get('price'), default=0.0)
        role = str(item.get('role') or '')
        tf = str(item.get('tf') or '')
        side = str(item.get('side') or '')
        if role in {'setup', 'execution'}:
            setup_or_execution = True
        sample_overlap = False
        if lp > 0:
            key = f"{side}:{lp:.8g}"
            grouped.setdefault(key, set()).add(tf or role or '-')
            sample_overlap = any(abs(lp-pv) / max(abs(pv), 1e-12) <= 0.0025 for pv in plan_values)
            if sample_overlap:
                overlap_prices.append(lp)
        normalized.append({
            'role': role or None, 'side': side or None, 'price': lp or None,
            'tf': tf or None, 'source_key': item.get('source_key'),
            'source': item.get('source'), 'gap_pct': item.get('gap_pct'),
            'bad_reason': 'stale_or_scale_mismatch',
            'actual_plan_overlap_v1049': sample_overlap,
        })

    cross_tf_duplicate = any(len(frames) >= 2 for frames in grouped.values())
    plan_overlap = bool(overlap_prices)
    historical_context_only = bool(stale and not plan_overlap)
    blocked = bool(plan_overlap)
    reasons: List[str] = []
    if plan_overlap:
        reasons.append('far_raw_line_overlaps_actual_frozen_plan')
    if cross_tf_duplicate:
        reasons.append('shared_history_extreme_repeated_across_derived_timeframes')
    if setup_or_execution:
        reasons.append('far_historical_extreme_visible_in_setup_or_execution_context')
    if historical_context_only:
        reasons.append('distant_historical_context_not_used_by_plan')
    return {
        'schema': 'structure_integrity_v1049_plan_overlap_only',
        'checked': True,
        'blocked': blocked,
        'refresh_required': blocked,
        'suspect_sample_count': len(stale),
        'cross_timeframe_duplicate': cross_tf_duplicate,
        'derived_timeframe_duplicate_expected_v1049': cross_tf_duplicate,
        'setup_or_execution_suspect': setup_or_execution,
        'actual_plan_overlap': plan_overlap,
        'actual_plan_overlap_prices_v1049': sorted(set(round(x, 8) for x in overlap_prices)),
        'historical_context_only_v1049': historical_context_only,
        'reasons': reasons,
        'samples': normalized[:8],
        'policy': 'v1049: distance/repetition alone is historical context; quarantine+refresh only when a far raw line overlaps actual trigger/invalid/target; existing OPEN unchanged',
    }

def _v1095_known_num(row: Dict[str, Any], *keys: str) -> Tuple[Optional[float], str]:
    for key in keys:
        if key not in row or row.get(key) in (None, ''):
            continue
        try:
            value=float(str(row.get(key)).replace(',','').replace('%','').strip())
            if math.isfinite(value):
                return value,key
        except Exception:
            continue
    return None,'source_missing'

def _v1095_clip(value: float, low: float, high: float) -> float:
    return max(low,min(high,value))

def _swing_quality_gate(row: Dict[str, Any], rr: float, room: float, spread: float, confirmed_slip: Optional[float]) -> Dict[str, Any]:
    """Canonical ALT_SWING quality gate.

    Structure, execution freshness, RR and target room remain separate hard contracts.
    Quality removes clearly weak candidates but does not require every soft axis to be
    bullish at the same instant. Pullback/retest entries may have a small negative
    short reaction, so reaction is treated as a safety floor plus ranking signal.
    """
    reaction,reaction_src=_v1095_known_num(row,'price_reaction_pct','reaction_pct','change_1m_pct','change_1m')
    relative_rank,relative_rank_src=_v1095_known_num(row,'relative_strength_rank_pct_v1095')
    relative,relative_src=_v1095_known_num(row,'relative_strength_pct','relative_strength')
    money,money_src=_v1095_known_num(row,'money_flow_score')
    buy,buy_src=_v1095_known_num(row,'buy_ratio','micro_buy_ratio')
    sustain,sustain_src=_v1095_known_num(row,'buy_sustain_1m','buy_sustain_60s','micro_buy_ratio_sustain_1m')

    reaction_safe = reaction is not None and reaction >= -0.35
    reaction_strong = reaction is not None and reaction >= 0.05
    relative_pass = (relative_rank is not None and relative_rank >= 50.0) or (relative is not None and relative >= 0.0)
    money_pass = money is not None and money >= 50.0
    buy_flow_pass = buy is not None and sustain is not None and buy >= 0.50 and sustain >= 0.45
    axes={
        'reaction': {'known':reaction is not None,'safe':reaction_safe,'pass':reaction_strong,'value':reaction,'source':reaction_src},
        'relative_strength': {'known':relative_rank is not None or relative is not None,'pass':relative_pass,'value':relative_rank if relative_rank is not None else relative,'source':relative_rank_src if relative_rank is not None else relative_src},
        'money_flow': {'known':money is not None,'pass':money_pass,'value':money,'source':money_src},
        'buy_flow': {'known':buy is not None and sustain is not None,'pass':buy_flow_pass,'value':{'buy_ratio':buy,'sustain':sustain},'source':f'{buy_src}/{sustain_src}'},
    }
    known_count=sum(1 for item in axes.values() if item['known'])
    confirmation_count=sum(1 for name in ('relative_strength','money_flow','buy_flow') if axes[name]['pass'])
    missing=[name for name,item in axes.items() if not item['known']]

    structure_score=15.0*_v1095_clip((rr-1.5)/2.5,0.0,1.0)+15.0*_v1095_clip((room-1.2)/2.8,0.0,1.0)
    reaction_score=20.0*_v1095_clip(((reaction if reaction is not None else -0.35)+0.35)/1.35,0.0,1.0)
    rel_basis=(relative_rank if relative_rank is not None else (50.0 + _v1095_clip(relative or 0.0,-2.0,2.0)*12.5))
    rel_score=20.0*_v1095_clip(rel_basis/100.0,0.0,1.0)
    money_score=20.0*_v1095_clip(((money if money is not None else 40.0)/100.0),0.0,1.0)
    execution_base=((buy or 0.0)+(sustain or 0.0))/2.0 if buy is not None and sustain is not None else 0.40
    cost=max(0.0,spread if spread>=0 else 1.2)+max(0.0,confirmed_slip if confirmed_slip is not None else 1.2)
    execution_score=10.0*_v1095_clip(execution_base-(cost/2.4)*0.35,0.0,1.0)
    score=round(structure_score+reaction_score+rel_score+money_score+execution_score,4)

    extreme=list((row.get('quality_observation_v925') or {}).get('extreme_quality_risk_tags') or row.get('extreme_quality_risk_tags_v925') or [])
    source_ready = known_count >= 3
    passed=bool(source_ready and reaction_safe and confirmation_count >= 1 and not extreme)
    tier = 'BLOCK'
    if passed:
        tier = 'A' if reaction_strong and confirmation_count >= 2 else 'B'
    reasons=[]
    if not source_ready: reasons.append('quality_source_missing:' + ','.join(missing))
    if reaction is not None and not reaction_safe: reasons.append(f'quality_reaction_unsafe:{reaction:.4f}')
    elif reaction is None: reasons.append('quality_reaction_source_missing')
    if confirmation_count < 1: reasons.append('quality_confirmation_absent:relative/money/buyflow')
    if extreme: reasons.append('extreme_quality_risk:' + '/'.join(str(x) for x in extreme[:3]))
    return {
        'schema':'swing_quality_gate_v1097','owner':'strategy_worker.apply_swing_entry_gate',
        'known_axes':known_count,'confirmation_passes':confirmation_count,'minimum_known_axes':3,'minimum_confirmation_passes':1,
        'reaction_safety_floor_pct':-0.35,'axes':axes,'missing_axes':missing,'hard_pass':passed,'quality_tier':tier,
        'block_reasons':reasons,'rank_score':score,
        'score_components':{'structure':round(structure_score,4),'reaction':round(reaction_score,4),'relative_strength':round(rel_score,4),'money_flow':round(money_score,4),'execution':round(execution_score,4)},
        'policy':'structure/execution/RR/room are hard contracts; quality blocks unsafe reaction, zero independent confirmation, extreme traps, or material source gaps; remaining candidates compete by rank',
    }

_v908_LAST_STATUS: Dict[str, Any] = {}

ROLE_SOURCE_AUDIT_V1007 = BASE_DIR / 'clean_strategy_role_source_audit_v1007.json'

_LATEST_PUBLISH_STATUS_V1008: Dict[str, Any] = {}

_ROLE_SOURCE_STATUS_V1008: Dict[str, Any] = {}

_STATUS_CANONICAL_PAYLOAD_V1023: Dict[str, Any] = {}

_STATUS_VOLATILE_KEYS_V1023 = {
    'schema','version','build','state','pid','updated_ts','updated_text','last_error',
    'status_heartbeat_only_v1022','status_heartbeat_last_ts_v1022',
}

def _role_source_audit_v1001(row: Dict[str, Any]) -> Dict[str, Any]:
    """Classify canonical structure audit flags without changing any gate.

    v1049 separates distant historical context from actual plan-integrity errors.
    """
    ctx = row.get('structure_context_v871') if isinstance(row.get('structure_context_v871'), dict) else {}
    if not ctx:
        levels=row.get('structure_levels') if isinstance(row.get('structure_levels'),dict) else {}
        ctx=levels.get('structure_context_v871') if isinstance(levels.get('structure_context_v871'),dict) else {}
    current = _v510_num(ctx.get('current_price'), row.get('current_price'), row.get('price'), default=0.0)
    samples = ctx.get('role_mismatch_samples') if isinstance(ctx.get('role_mismatch_samples'), list) else []
    raw_mismatch=bool(samples or row.get('structure_role_mismatch_v871') or ctx.get('role_mismatch'))
    integrity = row.get('structure_integrity_v1049') if isinstance(row.get('structure_integrity_v1049'),dict) else row.get('structure_integrity_v1048') if isinstance(row.get('structure_integrity_v1048'),dict) else {}
    overlap_prices = integrity.get('actual_plan_overlap_prices_v1049') if isinstance(integrity.get('actual_plan_overlap_prices_v1049'),list) else []
    overlap_prices = [_v869_num_any(x, default=0.0) for x in overlap_prices]
    true_samples=[]; flag_samples=[]
    for raw in samples:
        if not isinstance(raw, dict):
            continue
        reason=str(raw.get('bad_reason') or 'role_direction_flag')
        raw_price=_v869_num_any(raw.get('price'), default=0.0)
        actual_overlap = bool(reason == 'stale_or_scale_mismatch' and raw_price > 0 and any(abs(raw_price-p)/max(abs(p),1e-12)<=0.0025 for p in overlap_prices if p>0))
        display_reason = 'far_line_actual_plan_overlap' if actual_overlap else ('distant_historical_context' if reason == 'stale_or_scale_mismatch' else reason)
        item={
            'ticker': ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol')),
            'reason': display_reason,
            'raw_reason_v1049': reason,
            'actual_plan_overlap_v1049': actual_overlap,
            'role': raw.get('role'), 'side': raw.get('side'), 'price': raw.get('price'),
            'current': round(current,8) if current>0 else None, 'tf': raw.get('tf'),
            'source_key': raw.get('source_key'), 'source': raw.get('source'), 'gap_pct': raw.get('gap_pct'),
        }
        if actual_overlap:
            true_samples.append(item)
        else:
            flag_samples.append(item)
    major_missing=not bool(ctx.get('major_ready'))
    setup_missing=not bool(ctx.get('setup_ready'))
    execution_missing=not bool(ctx.get('execution_ready'))
    source_missing=bool(ctx.get('source_missing') or major_missing or setup_missing or execution_missing)
    stage=str(row.get('s_stage') or row.get('candidate_stage') or row.get('candidate_grade') or row.get('grade') or '')
    trade_row=stage in {'S1','S2','S3'}
    return {
        'role_mismatch_raw_v1007': raw_mismatch,
        'role_mismatch_true_error_v1001': bool(true_samples),
        'role_mismatch_flag_only_v1001': bool(flag_samples) and not bool(true_samples),
        'role_mismatch_unclassified_v1007': bool(raw_mismatch and not true_samples and not flag_samples),
        'role_mismatch_class_v1001': 'true_error' if true_samples else ('flag_only' if flag_samples else ('unclassified' if raw_mismatch else 'none')),
        'role_mismatch_true_samples_v1001': true_samples[:4],
        'role_mismatch_flag_samples_v1001': flag_samples[:4],
        'distant_historical_context_v1049': bool(any(str(x.get('reason'))=='distant_historical_context' for x in flag_samples)),
        'source_missing_v1001': source_missing,
        'source_missing_trade_row_v1001': bool(source_missing and trade_row),
        'source_missing_nontrade_row_v1001': bool(source_missing and not trade_row),
        'source_missing_frames_v1001': [name for name,missing in (('major',major_missing),('setup',setup_missing),('execution',execution_missing)) if missing],
        'audit_only_v1001': True,
    }

def _v1021_collect_candidate_publish_status(rows: List[Dict[str, Any]], status_extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Build canonical audit/status from full pre-compact rows. No file write here."""
    extra = dict(status_extra) if isinstance(status_extra, dict) else {}
    if isinstance(_v908_LAST_STATUS, dict):
        extra.update(_v908_LAST_STATUS)
    raw_rows=true_rows=flag_rows=unclassified_rows=missing_trade=missing_nontrade=0
    frame_counts=Counter(); true_reasons=Counter(); flag_reasons=Counter()
    true_samples=[]; flag_samples=[]
    rows_list = rows if isinstance(rows, list) else []
    for row in rows_list:
        if not isinstance(row,dict):
            continue
        audit=_role_source_audit_v1001(row)
        row.update(audit)
        ctx=row.get('structure_context_v871') if isinstance(row.get('structure_context_v871'),dict) else None
        if isinstance(ctx,dict):
            ctx.update({k:v for k,v in audit.items() if k.startswith('role_mismatch_') or k.startswith('source_missing_') or k=='audit_only_v1001'})
        if audit.get('role_mismatch_raw_v1007'): raw_rows += 1
        if audit.get('role_mismatch_true_error_v1001'): true_rows += 1
        elif audit.get('role_mismatch_flag_only_v1001'): flag_rows += 1
        elif audit.get('role_mismatch_unclassified_v1007'): unclassified_rows += 1
        if audit.get('source_missing_trade_row_v1001'): missing_trade += 1
        if audit.get('source_missing_nontrade_row_v1001'): missing_nontrade += 1
        frames = audit.get('source_missing_frames_v1001') if isinstance(audit.get('source_missing_frames_v1001'), list) else []
        for fr in frames: frame_counts[str(fr)] += 1
        true_items = audit.get('role_mismatch_true_samples_v1001') if isinstance(audit.get('role_mismatch_true_samples_v1001'), list) else []
        for x in true_items:
            if isinstance(x,dict):
                true_reasons[str(x.get('reason') or '-')]+=1
                if len(true_samples)<8: true_samples.append(x)
        flag_items = audit.get('role_mismatch_flag_samples_v1001') if isinstance(audit.get('role_mismatch_flag_samples_v1001'), list) else []
        for x in flag_items:
            if isinstance(x,dict):
                flag_reasons[str(x.get('reason') or '-')]+=1
                if len(flag_samples)<8: flag_samples.append(x)
    consistency=(raw_rows == true_rows + flag_rows + unclassified_rows)
    audit_status={
        'schema':'strategy_role_source_audit_v1021','version':VERSION,'build':BUILD_LABEL,'updated_ts':now_ts(),'updated_text':now_text(),
        'role_source_audit_owner_v1001':'strategy_worker._v1021_publish_candidate_snapshot',
        'role_mismatch_rows_v871':raw_rows,'role_mismatch_raw_rows_v1007':raw_rows,
        'role_mismatch_true_error_rows_v1001':true_rows,'role_mismatch_flag_only_rows_v1001':flag_rows,
        'role_mismatch_unclassified_rows_v1006':unclassified_rows,
        'role_mismatch_true_reason_counts_v1001':dict(true_reasons),'role_mismatch_flag_reason_counts_v1001':dict(flag_reasons),
        'role_mismatch_true_samples_v1001':true_samples,'role_mismatch_flag_samples_v1001':flag_samples,
        'source_missing_rows_v871':missing_trade+missing_nontrade,'source_missing_trade_rows_v1001':missing_trade,'source_missing_nontrade_rows_v1001':missing_nontrade,
        'source_missing_frame_counts_v1001':dict(frame_counts),'role_mismatch_classified_rows_v1006':true_rows+flag_rows,
        'source_missing_classified_rows_v1006':missing_trade+missing_nontrade,
        'role_source_audit_consistency_v1006':consistency,'role_source_audit_consistency_v1007':consistency,
        'role_source_equation_v1007':f'{raw_rows}={true_rows}+{flag_rows}+{unclassified_rows}',
        'role_source_audit_policy_v1001':'audit full pre-compact rows; compact handoff never owns audit truth; gates unchanged',
        'role_source_audit_conditions_changed_v1001':False,
    }
    extra.update(audit_status)
    _ROLE_SOURCE_STATUS_V1008.clear(); _ROLE_SOURCE_STATUS_V1008.update(audit_status)
    save_json(ROLE_SOURCE_AUDIT_V1007, audit_status)
    collector_elapsed_v1077: Dict[str, float] = {}
    for collector in (
        collect_worker_cache_overlay_status, collect_candidate_input_coverage_status, collect_freshness_missing_status,
        collect_execution_cost_source_status, collect_candidate_alias_status, collect_stable_follow_status,
        collect_quality_reaction_status, collect_structure_context_status, collect_structure_line_status,
        collect_trigger_source_dedup_status, collect_trigger_source_audit_status,
    ):
        started_v1077 = time.monotonic()
        # Every collector is a pure status producer: none reads keys produced by a
        # previous collector.  Passing the growing canonical payload used to copy
        # that payload eleven times.  Collect a delta and merge it once instead.
        delta_v1077 = collector(rows_list, None)
        if isinstance(delta_v1077, dict):
            extra.update(delta_v1077)
        collector_elapsed_v1077[collector.__name__] = round(time.monotonic() - started_v1077, 6)
    extra.update({
        'candidate_audit_collector_merge_v1077':'delta_update_no_accumulating_payload_copy',
        'candidate_audit_collector_count_v1077':len(collector_elapsed_v1077),
        'candidate_audit_collector_elapsed_sec_v1077':collector_elapsed_v1077,
        'candidate_audit_full_row_text_scan_retired_v1077':True,
        'candidate_audit_strategy_conditions_changed_v1077':False,
        'candidate_audit_entry_exit_changed_v1077':False,
    })
    # v1023: preserve the full canonical audit/display payload independently of
    # liveness timestamps. Heartbeat/cycle writes may refresh runtime fields, but
    # they never erase structure/role/source truth collected from the 460 full rows.
    _STATUS_CANONICAL_PAYLOAD_V1023.clear()
    for key, value in extra.items():
        if key in _STATUS_VOLATILE_KEYS_V1023:
            continue
        _STATUS_CANONICAL_PAYLOAD_V1023[key] = value
    return extra

def _v1022_write_status_file(obj: Dict[str, Any]) -> None:
    """The only filesystem owner for clean_strategy_worker_status.json.

    v1124 keeps the same atomic replace contract but removes fsync from this
    regenerable liveness artifact. Candidate/plan state and ledgers remain on
    their durable canonical writers.
    """
    global _STATUS_LAST_OBJ_V1022, _STATUS_LAST_WRITE_TS_V1022
    save_runtime_json(STATUS, obj, 'strategy_status_v1124')
    _STATUS_LAST_OBJ_V1022 = dict(obj)
    _STATUS_LAST_WRITE_TS_V1022 = fnum(obj.get("updated_ts"), default=now_ts())

def _v1023_merge_nonvolatile(dst: Dict[str, Any], src: Dict[str, Any]) -> None:
    """Merge canonical/status fields without allowing stale producer timestamps to own liveness."""
    if not isinstance(src, dict):
        return
    for key, value in src.items():
        if key in _STATUS_VOLATILE_KEYS_V1023:
            continue
        dst[key] = value

def write_status(state: str, **extra: Any) -> None:
    """Single strategy status writer; cycle and heartbeat both use this owner."""
    global _STATUS_HEARTBEAT_COUNT_V1022
    with _STATUS_WRITE_LOCK_V1022:
        prev: Dict[str, Any] = {}
        if _STATUS_LAST_OBJ_V1022:
            prev = dict(_STATUS_LAST_OBJ_V1022)
        elif STATUS.exists():
            loaded = load_json(STATUS, {})
            if isinstance(loaded, dict):
                prev = loaded

        phase = str(extra.get("phase") or "")
        is_cycle_start_zero = (
            state == "running" and phase.startswith("evaluating")
            and int(float(extra.get("evaluated") or 0)) <= 0
            and int(float(extra.get("target_count") or 0)) <= 0
        )
        nowv = now_ts()

        # Preserve the complete prior/canonical payload first, then refresh only
        # current runtime fields. This prevents a minimal heartbeat or boot write
        # from erasing structure/role/source counters and samples.
        obj: Dict[str, Any] = dict(prev)
        _v1023_merge_nonvolatile(obj, _STATUS_CANONICAL_PAYLOAD_V1023)
        _v1023_merge_nonvolatile(obj, _LATEST_PUBLISH_STATUS_V1008)
        _v1023_merge_nonvolatile(obj, _ROLE_SOURCE_STATUS_V1008)

        runtime_extra = dict(extra)
        if is_cycle_start_zero and prev:
            for key in (
                "evaluated","target_count","s_count","paper_latest_count",
                "s1_count","s2_count","s3_count","router_target_count",
                "router_queue_count","router_backlog_count","last_sec",
            ):
                if runtime_extra.get(key) in (None, "", 0, "0", "-") and key in prev:
                    runtime_extra.pop(key, None)
            runtime_extra["cycle_start_status_only_v1008"] = True

        _v1023_merge_nonvolatile(obj, runtime_extra)
        obj.update(_v1028_live_phase_snapshot())
        obj.update({
            "version": VERSION,
            "build": BUILD_LABEL,
            "state": state,
            "pid": os.getpid(),
            "updated_ts": nowv,
            "updated_text": now_text(nowv),
            "last_error": "",
            "status_writer_owner_v1008": "strategy_worker.write_status",
            "status_writer_count_v1008": 1,
            "status_writer_owner_v1022": "strategy_worker._v1022_write_status_file",
            "status_heartbeat_owner_v1022": "strategy_worker._v1022_status_heartbeat_loop",
            "status_heartbeat_sec_v1022": STATUS_HEARTBEAT_SEC_V1022,
            "status_heartbeat_count_v1022": _STATUS_HEARTBEAT_COUNT_V1022,
            "status_heartbeat_only_v1022": False,
            "status_canonical_payload_preserved_v1023": True,
            "status_volatile_timestamp_blocked_v1023": True,
            "status_canonical_field_count_v1023": len(_STATUS_CANONICAL_PAYLOAD_V1023),
            "status_route_schema": runtime_extra.get("status_route_schema") or obj.get("status_route_schema") or "strategy_status_v1023_canonical_merge_heartbeat",
        })
        publish_ts = fnum(_LATEST_PUBLISH_STATUS_V1008.get("latest_publish_ts_v821"), default=0.0)
        if publish_ts > 0:
            obj["latest_publish_age_sec_v821"] = round(max(0.0, nowv - publish_ts), 3)
        if _ROLE_SOURCE_STATUS_V1008:
            obj["role_source_audit_schema_v1008"] = _ROLE_SOURCE_STATUS_V1008.get("schema")
        if state == "error" and "error" in extra:
            obj["last_error"] = str(extra.get("error") or "")[:240]
        else:
            # v1165: a successful running/status write explicitly closes the prior
            # runtime error. The old merge kept ``error`` forever even after a healthy
            # cycle, which made Guard either hide a real error or report a stale one.
            for _error_key_v1165 in ("error", "error_owner_v1165", "error_traceback_tail_v1165"):
                obj.pop(_error_key_v1165, None)
        _v1022_write_status_file(obj)

def _v1022_status_heartbeat_loop() -> None:
    """Refresh liveness without altering the last completed metrics or phase."""
    global _STATUS_HEARTBEAT_COUNT_V1022
    while not _STATUS_HEARTBEAT_STOP_V1022.wait(STATUS_HEARTBEAT_SEC_V1022):
        try:
            with _STATUS_WRITE_LOCK_V1022:
                if not _STATUS_LAST_OBJ_V1022:
                    continue
                nowv = now_ts()
                if nowv - _STATUS_LAST_WRITE_TS_V1022 < STATUS_HEARTBEAT_SEC_V1022 * 0.8:
                    continue
                obj = dict(_STATUS_LAST_OBJ_V1022)
                _STATUS_HEARTBEAT_COUNT_V1022 += 1
                obj.update(_v1028_live_phase_snapshot())
                obj.update({
                    "updated_ts": nowv, "updated_text": now_text(nowv),
                    "status_heartbeat_count_v1022": _STATUS_HEARTBEAT_COUNT_V1022,
                    "status_heartbeat_only_v1022": True,
                    "status_heartbeat_last_ts_v1022": nowv,
                    "status_writer_owner_v1022": "strategy_worker._v1022_write_status_file",
                    "status_heartbeat_owner_v1022": "strategy_worker._v1022_status_heartbeat_loop",
                    "status_heartbeat_sec_v1022": STATUS_HEARTBEAT_SEC_V1022,
                    "status_canonical_payload_preserved_v1023": True,
                    "status_volatile_timestamp_blocked_v1023": True,
                    "status_canonical_field_count_v1023": len(_STATUS_CANONICAL_PAYLOAD_V1023),
                })
                _v1022_write_status_file(obj)
        except Exception as exc:
            append_error(ERROR, "strategy_status_heartbeat_v1022", exc)

def _v1022_start_status_heartbeat() -> None:
    global _STATUS_HEARTBEAT_THREAD_V1022
    with _STATUS_WRITE_LOCK_V1022:
        if _STATUS_HEARTBEAT_THREAD_V1022 and _STATUS_HEARTBEAT_THREAD_V1022.is_alive():
            return
        _STATUS_HEARTBEAT_STOP_V1022.clear()
        _STATUS_HEARTBEAT_THREAD_V1022 = threading.Thread(
            target=_v1022_status_heartbeat_loop,
            name="strategy-status-heartbeat-v1022",
            daemon=True,
        )
        _STATUS_HEARTBEAT_THREAD_V1022.start()

VERSION = "strategy_worker_v0.970"

BUILD_LABEL = "v1016_strategy_candle_delta_operation_merge_spine_2026-06-25"

MAIN_DEPLOY_VERSION = BUILD_LABEL

_CANDLE_BASE_CACHE_V1014: Dict[str, Dict[str, Any]] = {}

_CANDLE_BASE_SIG_V1014: tuple[int,int,int] = (0,0,0)

_CANDLE_DELTA_CACHE_V1014: Dict[str, Dict[str, Any]] = {}

_CANDLE_DELTA_INODE_V1014=0

_CANDLE_DELTA_OFFSET_V1014=0

_CANDLE_BASE_CHECKPOINT_ID_V1016=''

def _v1014_file_sig(path: Path) -> tuple[int,int,int]:
    try:
        st=path.stat(); return (int(st.st_ino),int(st.st_size),int(st.st_mtime_ns))
    except OSError: return (0,0,0)

def _v1016_candle_path_parent(root: Dict[str, Any], path: List[str], create: bool=True) -> tuple[Optional[Dict[str, Any]], str]:
    if not path:
        return None,''
    cur: Any=root
    for raw in path[:-1]:
        key=str(raw)
        if not isinstance(cur,dict):
            return None,str(path[-1])
        nxt=cur.get(key)
        if not isinstance(nxt,dict):
            if not create:
                return None,str(path[-1])
            nxt={}; cur[key]=nxt
        cur=nxt
    return cur if isinstance(cur,dict) else None,str(path[-1])

def _v1016_apply_candle_ops(row: Dict[str, Any], ops: List[Dict[str, Any]]) -> Dict[str, Any]:
    out=copy.deepcopy(row) if isinstance(row,dict) else {}
    for op in ops if isinstance(ops,list) else []:
        if not isinstance(op,dict):
            continue
        kind=str(op.get('op') or '')
        path=[str(x) for x in (op.get('path') or [])]
        if not path:
            continue
        parent,key=_v1016_candle_path_parent(out,path,create=kind!='remove')
        if not isinstance(parent,dict):
            continue
        if kind=='remove':
            parent.pop(key,None)
        elif kind=='set':
            parent[key]=copy.deepcopy(op.get('value'))
        elif kind=='list_roll':
            current=parent.get(key)
            if not isinstance(current,list):
                current=[]
            try: drop=max(0,int(op.get('drop_front') or 0))
            except Exception: drop=0
            append_rows=op.get('append') if isinstance(op.get('append'),list) else []
            parent[key]=copy.deepcopy(current[drop:]+append_rows)
    return out

def _v1014_read_candle_delta_incremental() -> None:
    global _CANDLE_DELTA_INODE_V1014,_CANDLE_DELTA_OFFSET_V1014,_CANDLE_DELTA_CACHE_V1014,_CANDLE_BASE_CHECKPOINT_ID_V1016
    try: st=CANDLE_DELTA_V1014.stat()
    except OSError:
        _CANDLE_DELTA_INODE_V1014=0; _CANDLE_DELTA_OFFSET_V1014=0; _CANDLE_DELTA_CACHE_V1014={}; return
    inode=int(st.st_ino); size=int(st.st_size)
    if inode!=_CANDLE_DELTA_INODE_V1014 or size<_CANDLE_DELTA_OFFSET_V1014:
        _CANDLE_DELTA_INODE_V1014=inode; _CANDLE_DELTA_OFFSET_V1014=0; _CANDLE_DELTA_CACHE_V1014={}
    if size<=_CANDLE_DELTA_OFFSET_V1014: return
    try:
        with CANDLE_DELTA_V1014.open('r',encoding='utf-8',errors='ignore') as handle:
            handle.seek(_CANDLE_DELTA_OFFSET_V1014)
            for line in handle:
                try: item=json.loads(line)
                except Exception: continue
                if not isinstance(item,dict): continue
                ticker=ticker_norm(item.get('ticker'))
                schema=str(item.get('schema') or '')
                if schema=='candle_delta_ops_v1016':
                    item_base_id=str(item.get('base_checkpoint_id_v1016') or '')
                    if _CANDLE_BASE_CHECKPOINT_ID_V1016 and item_base_id and item_base_id!=_CANDLE_BASE_CHECKPOINT_ID_V1016:
                        continue
                    if not ticker: continue
                    seed=_CANDLE_DELTA_CACHE_V1014.get(ticker)
                    if not isinstance(seed,dict): seed=_CANDLE_BASE_CACHE_V1014.get(ticker) or {}
                    row=_v1016_apply_candle_ops(seed,item.get('ops') if isinstance(item.get('ops'),list) else [])
                    row['ticker']=ticker; _CANDLE_DELTA_CACHE_V1014[ticker]=row
                    continue
                if schema=='candle_delta_patch_v1015':
                    patch=item.get('patch') if isinstance(item.get('patch'),dict) else {}
                    seed=_CANDLE_DELTA_CACHE_V1014.get(ticker)
                    if not isinstance(seed,dict): seed=_CANDLE_BASE_CACHE_V1014.get(ticker) or {}
                    row=dict(seed); row.update(patch)
                    for key in item.get('remove') or []: row.pop(str(key),None)
                    if ticker: row['ticker']=ticker; _CANDLE_DELTA_CACHE_V1014[ticker]=row
                    continue
                row=item.get('row') if isinstance(item.get('row'),dict) else item
                if not isinstance(row,dict): continue
                ticker=ticker or ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
                if ticker: _CANDLE_DELTA_CACHE_V1014[ticker]=row
            _CANDLE_DELTA_OFFSET_V1014=handle.tell()
    except OSError: return

def _v1014_load_candle_map() -> Dict[str, Dict[str, Any]]:
    global _CANDLE_BASE_CACHE_V1014,_CANDLE_BASE_SIG_V1014,_CANDLE_DELTA_CACHE_V1014,_CANDLE_DELTA_OFFSET_V1014,_CANDLE_DELTA_INODE_V1014,_CANDLE_BASE_CHECKPOINT_ID_V1016
    # Retry once if candle replaces the full checkpoint while this reader is merging.
    for _attempt in range(2):
        before=_v1014_file_sig(CANDLE)
        if before!=_CANDLE_BASE_SIG_V1014:
            raw=load_json(CANDLE,{}) or {}
            _CANDLE_BASE_CACHE_V1014=map_rows(raw)
            _CANDLE_BASE_CHECKPOINT_ID_V1016=str(raw.get('delta_checkpoint_id_v1016') or '') if isinstance(raw,dict) else ''
            if not _CANDLE_BASE_CHECKPOINT_ID_V1016 and before!=(0,0,0):
                _CANDLE_BASE_CHECKPOINT_ID_V1016=f'legacy-{before[0]}-{before[2]}'
            _CANDLE_BASE_SIG_V1014=before
            _CANDLE_DELTA_CACHE_V1014={}; _CANDLE_DELTA_OFFSET_V1014=0; _CANDLE_DELTA_INODE_V1014=0
        _v1014_read_candle_delta_incremental()
        after=_v1014_file_sig(CANDLE)
        if after==before: break
        _CANDLE_BASE_SIG_V1014=(0,0,0)
    merged=dict(_CANDLE_BASE_CACHE_V1014); merged.update(_CANDLE_DELTA_CACHE_V1014)
    return merged

_STRATEGY_SNAPSHOT_STATE_V1015: Dict[str, Dict[str, Any]] = {}

def _v1015_snapshot_semantic(value: Any) -> Any:
    if isinstance(value,dict):
        return {str(k):_v1015_snapshot_semantic(v) for k,v in value.items() if str(k) not in {'updated_ts','updated_text','cycle_started_ts','cycle_elapsed_sec','elapsed_sec','last_sec','heartbeat_due_v1014'}}
    if isinstance(value,list): return [_v1015_snapshot_semantic(v) for v in value]
    return value

def _v1015_bounded_snapshot_write(path: Path, obj: Dict[str, Any], heartbeat_sec: float=60.0) -> bool:
    nowv=now_ts(); stable=_v1015_snapshot_semantic(obj)
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,separators=(',',':'),default=str).encode('utf-8')).hexdigest()
    state=_STRATEGY_SNAPSHOT_STATE_V1015.setdefault(str(path),{'digest':'','ts':0.0})
    changed=digest!=state.get('digest'); due=nowv-float(state.get('ts') or 0.0)>=heartbeat_sec
    if not path.exists() or changed or due:
        payload=dict(obj); payload['semantic_digest_v1015']=digest; payload['semantic_changed_v1015']=changed
        save_runtime_json(path,payload,'bounded_snapshot_v1124'); state.update({'digest':digest,'ts':nowv}); return True
    return False

VERSION = "strategy_worker_v0.985"

BUILD_LABEL = "v1039_candidate_freshness_quality_nonblocking_status_spine_2026-06-26"

MAIN_DEPLOY_VERSION = BUILD_LABEL

STRATEGY_IO_STATUS_V1021 = BASE_DIR / "clean_strategy_io_status_v1021.json"

V1020_ROW_SOFT_CEILING_BYTES = 16384

V1020_ROW_HARD_CEILING_BYTES = 24576

_V1020_CANDIDATE_VALIDATION_FAILURES = 0

_SOURCE_CACHE_WRITE_COUNT = 0

_SOURCE_CACHE_SKIP_COUNT = 0

_V1032_CANDLE_OFFICIAL_CACHE: Dict[str, Dict[str, Any]] = {}

_V1032_CANDLE_CACHE_HITS = 0

_V1032_CANDLE_CACHE_MISSES = 0

_V1032_CANDLE_CACHE_AGE_REFRESHES = 0

_V1078_CANDLE_OBJECT_REBUILD_REUSE = 0

_V1078_CANDLE_STABLE_IDENTITY_HITS = 0

_V1078_CANDLE_TRUE_SOURCE_MISSES = 0

def _v1032_candle_source_signature(c: Dict[str, Any]) -> Tuple[Any, ...]:
    """Stable canonical identity for Candle rows.

    candle_worker.fetch_one seals a new candle_ts on every actual ticker refresh.
    A full checkpoint replace only reconstructs Python dict objects and preserves
    candle_ts/material, so process-local id(c) must not invalidate the cache.
    """
    if not isinstance(c, dict):
        return (0,)
    lab = c.get('structure_lab_candles') if isinstance(c.get('structure_lab_candles'), dict) else {}
    return (
        ticker_norm(c.get('ticker') or c.get('market') or c.get('symbol')),
        len(c), c.get('candle_ts'), c.get('candle_refresh_profile'), c.get('candle_worker_build'),
        lab.get('updated_ts'), lab.get('last_full_profile_fetch_ts'),
        c.get('m1_ok'), c.get('m3_ok'), c.get('m5_ok'), c.get('m15_ok'),
        c.get('m30_ok'), c.get('h1_ok'), c.get('h2_ok'), c.get('h4_ok'),
    )

def _v1032_refresh_candle_age_fields(out: Dict[str, Any], c: Dict[str, Any], nowv: float) -> None:
    """Refresh only fields whose v769 value depends on nowv; static material stays exact."""
    try:
        tfmat = _v769_tf_material(c, nowv)
    except Exception:
        return
    ages = tfmat.get('tf_age_sec_v769') if isinstance(tfmat.get('tf_age_sec_v769'), dict) else {}
    out['tf_age_sec_v769'] = dict(ages)
    frame_prefixes = tuple(globals().get('V824_FRAME_PREFIXES', ('h4','h2','h1','m60','1h','m30','m15','m5','m3','m1')))
    for key, value in tfmat.items():
        ks = str(key)
        if not ((ks.startswith('candle_') and ks.endswith('_age_sec')) or ks.endswith('_candle_age_sec')):
            continue
        # Later v824/v827 wrappers overwrite prefixed age fields with the raw
        # candle value. Preserve that exact final value on cache hits.
        if any(ks.startswith(pref + '_') for pref in frame_prefixes) and c.get(ks) not in (None, ''):
            continue
        out[ks] = value
    valid = [float(v) for v in ages.values() if isinstance(v, (int, float)) and float(v) < 999998]
    if valid:
        out['official_candle_age'] = round(min(valid), 1)
    else:
        candle_ts = _v510_num(c.get('candle_ts'), default=0.0)
        if candle_ts > 0:
            out['official_candle_age'] = round(max(0.0, nowv - candle_ts), 1)

def _v597_candle_official_fields__L23709(c: Dict[str, Any], nowv: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    global _V1032_CANDLE_CACHE_HITS, _V1032_CANDLE_CACHE_MISSES, _V1032_CANDLE_CACHE_AGE_REFRESHES
    global _V1078_CANDLE_OBJECT_REBUILD_REUSE, _V1078_CANDLE_STABLE_IDENTITY_HITS, _V1078_CANDLE_TRUE_SOURCE_MISSES
    if not isinstance(c, dict) or not c:
        return {}
    ts = float(nowv or now_ts())
    ticker = ticker_norm(c.get('ticker') or c.get('market') or c.get('symbol'))
    cache_key = ticker or f'row:{id(c)}'
    sig = _v1032_candle_source_signature(c)
    cached = _V1032_CANDLE_OFFICIAL_CACHE.get(cache_key)
    if isinstance(cached, dict) and cached.get('signature') == sig and isinstance(cached.get('output'), dict):
        _V1032_CANDLE_CACHE_HITS += 1
        _V1078_CANDLE_STABLE_IDENTITY_HITS += 1
        old_object_id = cached.get('object_id_v1078')
        if old_object_id is not None and int(old_object_id) != id(c):
            _V1078_CANDLE_OBJECT_REBUILD_REUSE += 1
        cached['object_id_v1078'] = id(c)
        out = dict(cached['output'])
        _v1032_refresh_candle_age_fields(out, c, ts)
        _V1032_CANDLE_CACHE_AGE_REFRESHES += 1
        return out
    _V1032_CANDLE_CACHE_MISSES += 1
    _V1078_CANDLE_TRUE_SOURCE_MISSES += 1
    out = _v1032_legacy_candle_official_fields(c, ts)
    out = dict(out) if isinstance(out, dict) else {}
    _V1032_CANDLE_OFFICIAL_CACHE[cache_key] = {
        'signature': sig, 'output': dict(out), 'object_id_v1078': id(c), 'candle_ts_v1078': c.get('candle_ts'),
    }
    return out

def _v1032_candle_cache_status() -> Dict[str, Any]:
    total = _V1032_CANDLE_CACHE_HITS + _V1032_CANDLE_CACHE_MISSES
    return {
        'schema': 'strategy_candle_overlay_cache_v1078_stable_identity',
        'owner': 'strategy_worker._v597_candle_official_fields exact-output cache',
        'signature_owner_v1078': 'candle_worker candle_ts + canonical row material markers',
        'python_object_id_in_signature_v1078': False,
        'entries': len(_V1032_CANDLE_OFFICIAL_CACHE),
        'hits': _V1032_CANDLE_CACHE_HITS,
        'misses': _V1032_CANDLE_CACHE_MISSES,
        'hit_ratio_pct_v1078': round((_V1032_CANDLE_CACHE_HITS / total * 100.0) if total else 0.0, 2),
        'age_refreshes': _V1032_CANDLE_CACHE_AGE_REFRESHES,
        'stable_identity_hits_v1078': _V1078_CANDLE_STABLE_IDENTITY_HITS,
        'checkpoint_object_rebuild_reuse_v1078': _V1078_CANDLE_OBJECT_REBUILD_REUSE,
        'true_source_misses_v1078': _V1078_CANDLE_TRUE_SOURCE_MISSES,
        'legacy_wrapper_chain_called_only_on_true_source_change_v1078': True,
        'exact_overlay_output_preserved_v1078': True,
        'conditions_changed': False,
        'trigger_formula_changed': False,
        'paper_open_changed': False,
    }

def _active_scalar_map(value: Any, keys: Tuple[str, ...], list_limit: int = 8) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out: Dict[str, Any] = {}
    for key in keys:
        if key not in value:
            continue
        item = value.get(key)
        if isinstance(item, (str, int, float, bool)) or item is None:
            out[key] = item
        elif isinstance(item, list):
            out[key] = item[:list_limit]
    return out

def _active_zone_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out = _v1020_line_view(value)
    for key in ('source_count','tf_count','type_count'):
        if value.get(key) not in (None, ''):
            out[key] = value.get(key)
    reaction = value.get('reaction_evidence')
    if isinstance(reaction, dict):
        out['reaction_evidence'] = _active_scalar_map(
            reaction, ('touch_count','reclaim','reject','lower_wick_pct','upper_wick_pct','volume_ratio'), 4
        )
    sources = value.get('sources')
    if isinstance(sources, list):
        out['sources'] = [
            _active_scalar_map(x, ('tf','key','type','price'), 4)
            for x in sources[:4] if isinstance(x, dict)
        ]
    return out

def _active_smart_shadow_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out = _active_scalar_map(
        value,
        ('schema','shadow_key','exact_identity','ticker','current_price','dynamic_zone_tolerance_pct',
         'tick_pct','low_price_tick_risk','support_cluster_count','resistance_cluster_count',
         'observation_only','used_for_entry_gate','used_for_trigger','used_for_exit','trading_rules_changed'),
        6,
    )
    existing = value.get('existing')
    if isinstance(existing, dict):
        out['existing'] = _active_scalar_map(existing, ('trigger','invalid','target'), 4)
    smart = value.get('smart')
    if isinstance(smart, dict):
        compact = _active_scalar_map(smart, ('trigger','invalid','target','risk_reward'), 4)
        for key in ('support_zone','trigger_zone','target_zone'):
            if isinstance(smart.get(key), dict):
                compact[key] = _active_zone_view(smart.get(key))
        out['smart'] = compact
    return out

def _active_structure_lab_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out = _active_scalar_map(
        value,
        ('schema','ticker','candidate_exact_identity','current_price','analysis_eligible','found_methods',
         'complete_methods','partial_methods','no_structure_methods','found_method_count','complete_method_count',
         'all_methods_no_structure','structure_found_but_no_complete_plan','current_state_fresh','priority_lane',
         'map_source_fresh','map_refresh_pending','map_freshness_basis','created_ts','observation_only',
         'trading_rules_changed'),
        8,
    )
    current = value.get('current_state')
    if isinstance(current, dict):
        out['current_state'] = _active_scalar_map(
            current,
            ('fresh','current_price','overlay_fresh','price_age_sec','price_age_source','quote_age_sec',
             'quote_age_source','micro_age_sec','micro_age_source','orderflow_age_sec','orderflow_age_source',
             'fresh_ttl_sec','stale_reasons'),
            6,
        )
    methods = value.get('methods')
    if isinstance(methods, dict):
        compact_methods: Dict[str, Any] = {}
        for method, plan in list(methods.items())[:8]:
            if not isinstance(plan, dict):
                continue
            compact = _active_scalar_map(
                plan,
                ('method','signal_state','event_key','event_is_fresh','trackable','trigger_already_reached_on_source',
                 'tracking_start_ts','tracking_start_price','event_source_candle_ts','event_source_ts',
                 'event_source_price','event_kind','current_invalidated','current_target_reached','primary_tf',
                 'plan_complete','structure_found','trigger_activation_mode','invalid','target','trigger'),
                8,
            )
            for key in ('support_zone','trigger_zone','target_zone'):
                if isinstance(plan.get(key), dict):
                    compact[key] = _active_zone_view(plan.get(key))
            compact_methods[str(method)] = compact
        if compact_methods:
            out['methods'] = compact_methods
    return out

def _active_hot_watch_view(value: Any) -> Dict[str, Any]:
    return _active_scalar_map(
        value,
        ('scanner_hot_now','scanner_hot_started_ts','strategy_first_seen_ts','s3_first_ts','s2_first_ts',
         's1_first_ts','scanner_to_strategy_sec','scanner_to_s2_sec','scanner_to_s1_sec','occurrence_key',
         'observation_only'),
        6,
    )

def _v1020_trim_scalar(value: Any) -> Any:
    if isinstance(value, str):
        return value if len(value) <= 1024 else value[:1024]
    if isinstance(value, (int, float, bool)) or value is None:
        return value
    return None

def _v1020_bounded_tree(value: Any, depth: int = 0, max_depth: int = 3, max_items: int = 28, max_list: int = 12) -> Any:
    if isinstance(value, (str, int, float, bool)) or value is None:
        return _v1020_trim_scalar(value)
    if depth >= max_depth:
        return None
    if isinstance(value, list):
        out = []
        for item in value[:max_list]:
            compact = _v1020_bounded_tree(item, depth + 1, max_depth, max_items, max_list)
            if compact not in (None, {}, []):
                out.append(compact)
        return out
    if isinstance(value, dict):
        out: Dict[str, Any] = {}
        for key, item in list(value.items())[:max_items]:
            compact = _v1020_bounded_tree(item, depth + 1, max_depth, max_items, max_list)
            if compact not in (None, {}, []):
                out[str(key)] = compact
        return out
    return None


def _v1327_trigger_occurrence_view(value: Any) -> Dict[str, Any]:
    """Minimal trigger occurrence transport view.

    v1326 restored the v1051 reset/rebreak state, but the full evidence/policy
    text could push PAPER_LATEST rows over the v1021 hard ceiling.  Keep only
    fields that Paper/exact validation need; leave strategy logic unchanged.
    """
    if not isinstance(value, dict):
        return {}
    keys = (
        'schema','decision_key','candidate_key','kind','side','event_ts',
        'qualification_ts_v1177','contract_ready','qualification_state',
        'requires_new_rebreak','plan_frozen_ts','reset_ts','rebreak_ts',
        'sequence','trigger_price','current_price','trigger_reached',
        'event_time_owner','prior_cycle_event_carried',
        's1_ready_ts_v1173','s1_ready_decision_key_v1173',
        'transport_ttl_owner_v1173','actual_trigger_ts_immutable_v1173',
        'prior_cycle_event_carried_v1177',
    )
    out: Dict[str, Any] = {}
    for key in keys:
        raw = value.get(key)
        clean = _v1020_trim_scalar(raw)
        if clean not in (None, '', [], {}):
            out[key] = clean
    return out


def _v1327_minimal_gate_for_writer(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    keys = (
        'schema','strategy_mode','stage','final_trade_state','hard_pass','decision_key',
        'trigger_price','invalid_price','target_price','risk_reward','target_room_pct',
        'trigger_chase_pct','spread_pct','source_fresh','observation_only',
        'open_eligible','paper_bot_open','trade_ready','created_ts','frozen_ts',
        'structure_complete','actual_structural_invalid_missing','next_structural_target_missing',
        'trigger_occurrence_owner_state_v1128','trigger_occurrence_owner_reason_v1128',
    )
    out: Dict[str, Any] = {}
    for key in keys:
        clean = _v1020_trim_scalar(value.get(key))
        if clean not in (None, '', [], {}):
            out[key] = clean
    for key in ('hard_block_reasons','reasons'):
        raw = value.get(key)
        if isinstance(raw, list):
            compact = [_v1020_trim_scalar(x) for x in raw[:8] if isinstance(x, (str, int, float, bool))]
            if compact:
                out[key] = compact
    occ = _v1327_trigger_occurrence_view(value.get('trigger_occurrence'))
    if occ:
        out['trigger_occurrence'] = occ
    return out


def _v1327_shrink_row_for_writer_budget(out: Dict[str, Any], hard_ceiling: int) -> Dict[str, Any]:
    """Drop display-only duplicated context until exact row fits hard ceiling."""
    if not isinstance(out, dict):
        return out
    drop_order = (
        'entry_context','common_entry_decision','canonical_entry_decision','entry_diagnostics',
        'structure_context_v871','swing_structure_plan_v977',
        'structure_lab_v956','smart_structure_shadow_v948','entry_evidence_v983',
        'paper_timing_spine_v940','paper_selection_spine_v940','execution_cost_evidence_v983',
        'worker_cache_overlay_v907','worker_cache_overlay_v908','worker_cache_overlay_status_v908',
        'source_snapshot','freshness_map','legacy_gate_audit_v925','quality_observation_v925',
        'trigger_source_review_v864','trigger_source_review_v868','structure_horizontal_lines_v869',
        's2_observation_v919','paper_final_safety_diagnostics',
    )
    for key in drop_order:
        if _v1020_json_bytes(out) <= hard_ceiling:
            break
        out.pop(key, None)
    if _v1020_json_bytes(out) > hard_ceiling and isinstance(out.get('swing_entry_gate_v977'), dict):
        out['swing_entry_gate_v977'] = _v1327_minimal_gate_for_writer(out.get('swing_entry_gate_v977'))
    if _v1020_json_bytes(out) > hard_ceiling:
        # Last resort: keep quality as score scalars already present at top-level.
        gate = out.get('swing_entry_gate_v977')
        if isinstance(gate, dict):
            for key in ('swing_quality_gate','structure_plan','trigger','invalid','target','quality_tags','structure_tags'):
                gate.pop(key, None)
    return out

def _v1020_json_bytes(value: Any) -> int:
    try:
        return len(json.dumps(value, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8'))
    except Exception:
        return 0

_V1079_JSON_KEY_BYTES_CACHE: Dict[str, int] = {}

_V1079_SCALAR_FIELD_FASTPATH_CALLS = 0

_V1079_NESTED_FIELD_SERIALIZE_CALLS = 0

# v1194: the exact hard-ceiling serialization is the same byte representation
# written to PAPER_LATEST. Capture it only inside the canonical writer so the
# full candidate row is not serialized a second time.
_V1194_CAPTURE_COMPACT_BLOB = False
_V1194_COMPACT_BLOB_CACHE: Dict[int, Tuple[Dict[str, Any], bytes]] = {}

def _v1029_json_field_bytes(key: str, value: Any) -> int:
    """Exact UTF-8 bytes for one JSON object field, excluding outer braces.

    v1079 keeps the exact JSON byte contract but avoids constructing a temporary
    one-field dict for the hundreds of scalar fields repeated across every row.
    Nested containers retain the legacy serializer.
    """
    global _V1079_SCALAR_FIELD_FASTPATH_CALLS, _V1079_NESTED_FIELD_SERIALIZE_CALLS
    skey = str(key)
    if isinstance(value, (str, int, float, bool)) or value is None:
        key_bytes = _V1079_JSON_KEY_BYTES_CACHE.get(skey)
        if key_bytes is None:
            key_bytes = len(json.dumps(skey, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8'))
            _V1079_JSON_KEY_BYTES_CACHE[skey] = key_bytes
        if isinstance(value, str):
            value_bytes = len(json.encoder.encode_basestring(value).encode('utf-8'))
        elif value is True:
            value_bytes = 4
        elif value is False:
            value_bytes = 5
        elif value is None:
            value_bytes = 4
        elif isinstance(value, int):
            value_bytes = len(str(value).encode('ascii'))
        else:
            if math.isnan(value):
                value_bytes = 3
            elif math.isinf(value):
                value_bytes = 8 if value > 0 else 9
            else:
                value_bytes = len(repr(value).encode('ascii'))
        _V1079_SCALAR_FIELD_FASTPATH_CALLS += 1
        return key_bytes + 1 + value_bytes
    _V1079_NESTED_FIELD_SERIALIZE_CALLS += 1
    blob = json.dumps({skey: value}, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8')
    return max(0, len(blob) - 2)

def _v1029_budget_state(out: Dict[str, Any]) -> Dict[str, Any]:
    return {'bytes': _v1020_json_bytes(out), 'field_bytes': {}}

def _v1029_budget_add(out: Dict[str, Any], state: Dict[str, Any], key: str, value: Any, ceiling: Optional[int] = None) -> bool:
    """Add/replace one field using an exact incremental JSON byte budget.

    v1028 serialized the complete growing row after every optional field.  This
    computes only the candidate field once and preserves the exact same accept/
    reject boundary and insertion order.
    """
    if value in (None, {}, []):
        return False
    skey = str(key)
    new_field = _v1029_json_field_bytes(skey, value)
    cache = state.setdefault('field_bytes', {})
    current = int(state.get('bytes') or 2)
    if skey in out:
        old_field = int(cache.get(skey) or _v1029_json_field_bytes(skey, out.get(skey)))
        projected = current - old_field + new_field
    else:
        projected = current + new_field + (1 if out else 0)
    if ceiling is not None and projected > int(ceiling):
        return False
    out[skey] = value
    cache[skey] = new_field
    state['bytes'] = projected
    return True

def _v1029_budget_remove(out: Dict[str, Any], state: Dict[str, Any], key: str) -> bool:
    skey = str(key)
    if skey not in out:
        return False
    cache = state.setdefault('field_bytes', {})
    old_field = int(cache.get(skey) or _v1029_json_field_bytes(skey, out.get(skey)))
    before_count = len(out)
    out.pop(skey, None)
    cache.pop(skey, None)
    state['bytes'] = max(2, int(state.get('bytes') or 2) - old_field - (1 if before_count > 1 else 0))
    return True

def _v1020_line_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    keys = (
        'price','raw_price','rounded_price','center','center_raw','zone_low','zone_low_raw',
        'zone_high','zone_high_raw','timeframe','tf','source_tf','role_tf','role','source',
        'source_name','source_key','line_source','method','reason','line_quality','quality',
        'gap_pct','score','frozen_ts','created_ts','source_plan_move_detected','frozen_plan_held',
    )
    return {k: _v1020_trim_scalar(value.get(k)) for k in keys if value.get(k) not in (None, '', [], {})}

def _v1020_plan_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out: Dict[str, Any] = {}
    for key in (
        'schema','plan_state','state','plan_id','plan_key','source','method','setup_type',
        'current_price','trigger_price','invalid_price','target_price','risk_reward',
        'target_room_pct','trigger_chase_pct','spread_pct','source_fresh','frozen_ts',
        'created_ts','source_plan_move_detected','frozen_plan_held','structure_complete',
    ):
        if value.get(key) not in (None, '', [], {}):
            out[key] = _v1020_trim_scalar(value.get(key))
    for key in ('trigger','invalid','target'):
        view = _v1020_line_view(value.get(key))
        if view:
            out[key] = view
    if isinstance(value.get('trigger_occurrence'),dict):
        out['trigger_occurrence']=_v1327_trigger_occurrence_view(value.get('trigger_occurrence'))
    return out

def _v1020_gate_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out: Dict[str, Any] = {}
    for key in (
        'schema','strategy_mode','stage','final_trade_state','hard_pass','decision_key',
        'trigger_price','invalid_price','target_price','risk_reward','target_room_pct',
        'trigger_chase_pct','spread_pct','reason','source_fresh','observation_only',
        'open_eligible','paper_bot_open','trade_ready','created_ts','frozen_ts',
        'structure_complete','actual_structural_invalid_missing','next_structural_target_missing','trigger_occurrence_owner_state_v1128','trigger_occurrence_owner_reason_v1128',
    ):
        if value.get(key) not in (None, '', [], {}):
            out[key] = _v1020_trim_scalar(value.get(key))
    for key in ('hard_block_reasons','reasons','quality_tags','structure_tags'):
        raw = value.get(key)
        if isinstance(raw, list):
            out[key] = [_v1020_trim_scalar(x) for x in raw[:12] if isinstance(x, (str, int, float, bool))]
    if isinstance(value.get('trigger_occurrence'),dict):
        out['trigger_occurrence']=_v1327_trigger_occurrence_view(value.get('trigger_occurrence'))
    if isinstance(value.get('swing_quality_gate'),dict):
        out['swing_quality_gate']=_v1020_bounded_tree(value.get('swing_quality_gate'),max_depth=4,max_items=40,max_list=10)
    plan = _v1020_plan_view(value.get('structure_plan'))
    if plan:
        out['structure_plan'] = plan
    for key in ('trigger','invalid','target'):
        view = _v1020_line_view(value.get(key))
        if view:
            out[key] = view
    return out

def _v1020_context_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out: Dict[str, Any] = {}
    for key, item in value.items():
        if isinstance(item, (str, int, float, bool)) or item is None:
            clean = _v1020_trim_scalar(item)
            if clean not in (None, ''):
                out[str(key)] = clean
    nested = {
        'swing_entry_gate_v977': _v1020_gate_view,
        'swing_structure_plan_v977': _v1020_plan_view,
        'structure_levels': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=24, max_list=10),
        'entry_plan': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=24, max_list=10),
        'trigger_gate_v738': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=20, max_list=10),
        'trigger_gate_v737': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=20, max_list=10),
        'trigger_gate_v736': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=20, max_list=10),
        'freshness_map': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=24, max_list=10),
        'candidate_input_coverage_v906': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=24, max_list=10),
        'quality_observation_v925': lambda x: _v1020_bounded_tree(x, max_depth=3, max_items=24, max_list=10),
    }
    for key, fn in nested.items():
        if isinstance(value.get(key), dict):
            compact = fn(value.get(key))
            if compact:
                out[key] = compact
    return out

def _v1020_structure_context_view(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    out: Dict[str, Any] = {}
    for key in (
        'schema','current_price','invalid_price','target_price','target_room_pct','risk_reward',
        'trigger_price_raw_v914','invalid_price_raw_v914','target_price_raw_v914',
        'structure_price_precision_source_v914','major_ready','setup_ready','execution_ready',
        'source_missing','strategy_is_tag_only','strategy_label_role','entry_context_summary',
        'role_mismatch_true_error_v1001','role_mismatch_flag_only_v1001','role_mismatch_class_v1001',
        'source_missing_v1001','source_missing_trade_row_v1001','source_missing_nontrade_row_v1001',
    ):
        if value.get(key) not in (None, '', [], {}):
            out[key] = _v1020_trim_scalar(value.get(key))
    for key in ('major_support','major_resistance','setup_support','setup_resistance','execution_trigger'):
        view = _v1020_line_view(value.get(key))
        if view:
            out[key] = view
    for key in ('structure_tags','role_mismatch_samples','role_mismatch_true_samples_v1001','role_mismatch_flag_samples_v1001','source_missing_frames_v1001'):
        compact = _v1020_bounded_tree(value.get(key), max_depth=3, max_items=12, max_list=8)
        if compact:
            out[key] = compact
    return out

def _v1020_validate_exact_contract(src: Dict[str, Any], out: Dict[str, Any]) -> None:
    global _V1020_CANDIDATE_VALIDATION_FAILURES
    gate_src = src.get('swing_entry_gate_v977') if isinstance(src.get('swing_entry_gate_v977'), dict) else {}
    gate_out = out.get('swing_entry_gate_v977') if isinstance(out.get('swing_entry_gate_v977'), dict) else {}
    src_key = str(src.get('swing_gate_decision_key_v977') or gate_src.get('decision_key') or '').strip()
    out_key = str(out.get('swing_gate_decision_key_v977') or gate_out.get('decision_key') or '').strip()
    active = bool(gate_src) or bool(src_key)
    errors = []
    if active and not gate_out:
        errors.append('gate_missing')
    if src_key and out_key != src_key:
        errors.append('decision_key_changed')
    if gate_src.get('schema') and gate_out.get('schema') != gate_src.get('schema'):
        errors.append('gate_schema_changed')
    src_occ=gate_src.get('trigger_occurrence') if isinstance(gate_src.get('trigger_occurrence'),dict) else (src.get('trigger_occurrence') if isinstance(src.get('trigger_occurrence'),dict) else {})
    out_occ=gate_out.get('trigger_occurrence') if isinstance(gate_out.get('trigger_occurrence'),dict) else {}
    if src_occ:
        if not out_occ:
            errors.append('trigger_occurrence_missing')
        for key in ('decision_key','candidate_key','kind','reset_ts','rebreak_ts','plan_frozen_ts'):
            if src_occ.get(key) != out_occ.get(key):
                errors.append(f'trigger_occurrence_{key}_changed')
    src_candidate_occ=str(src.get('trigger_occurrence_candidate_key') or '').strip()
    out_candidate_occ=str(out.get('trigger_occurrence_candidate_key') or '').strip()
    if src_candidate_occ and src_candidate_occ!=out_candidate_occ:
        errors.append('trigger_occurrence_candidate_key_changed')
    if gate_src.get('final_trade_state') == 'S1_PASS':
        for key in ('risk_reward','target_room_pct','source_fresh','hard_pass','final_trade_state'):
            if gate_out.get(key) != gate_src.get(key):
                errors.append(f'gate_{key}_changed')
    if errors:
        _V1020_CANDIDATE_VALIDATION_FAILURES += 1
        raise ValueError('v1020 candidate exact contract: ' + ','.join(errors))

def _v861_compact_row_for_latest__L24130(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    """v1029: exact v1021 allowlist with one incremental JSON budget pass."""
    src = row if isinstance(row, dict) else {}
    out: Dict[str, Any] = {}

    mandatory_scalars = (
        'ticker','market','symbol','event_id','event_key','trace_id','scan_id','source_scan_id','candidate_id',
        'build_key','entry_build_key','candidate_entry_build_key','open_build_key','score_patch_version','candidate_pipeline_cycle_id_v1150',
        'strategy_mode','strategy_mode_v977','strategy','strategy_key','strategy_label','paper_strategy_key','paper_strategy_label',
        's_stage','candidate_stage','candidate_grade','grade','canonical_lane','route','setup_type',
        'swing_gate_decision_key_v977','paper_decision_key_v926','decision_key','candidate_exact_identity','trigger_occurrence_candidate_key','trigger_occurrence_owner_state_v1128','trigger_occurrence_owner_reason_v1128',
        'open_eligible','paper_bot_open','trade_ready','real_eligible','auto_buy_ready','buy_ready',
        'observation_only','observation_only_v988','s3_observation_only_v988','s3_review_only_v988',
        'observation_open_forbidden_v988','strategy_role','final_trade_state','final_entry_action','final_entry_label',
        'paper_final_safety_passed','paper_entry_action','s1_hold_status','hold_status',
        'current_price','price','entry_price','detected_price','trigger_price','entry_trigger_price',
        'swing_trigger_price_v977','swing_invalid_price_v977','swing_target_price_v977',
        'invalid_price','target_price','risk_reward_ratio','target_room_pct','trigger_gap_pct','trigger_chase_pct','invalid_distance_pct',
        'trigger_chase_source_v1203','invalid_distance_source_v1203','scanner_occurrence_started_ts_v1203','scanner_occurrence_key_v1203','scanner_occurrence_source_v1203',
        'spread_pct','entry_slippage_est_pct','entry_slippage_source','entry_slippage_ts','entry_slippage_age_sec','entry_slippage_confirmed','entry_slippage_basis','entry_slippage_order_amount_krw','entry_slippage_order_amount_state','entry_slippage_owner','slippage_pct','buy_ratio','buy_sustain_1m','price_reaction_pct','change_1m_pct','change_3m','change_5m','relative_strength_pct','relative_strength_source_v1095','relative_strength_rank_pct_v1095','money_flow_score','money_flow_source_v1095','money_flow_source_missing_v1095','feature_quality_owner_v1095','turnover_24h_for_quality_v1095','turnover_rank_pct_v1095','volume_flow_rank_pct_v1095','short_flow_rank_pct_v1095','volume_ratio','volume_expansion_pct','vwap_gap_pct','ema5_gap_pct','ema10_gap_pct','ema20_gap_pct','recent_high_gap_pct','recent_high_gap_source_v1208','recent_low_rebound_pct','day_pos_pct','day_position_source_v1208','upper_wick_pct','lower_wick_pct','market_mode','official_candle_age','swing_quality_rank_score','swing_quality_rank','quality_rank_owner','quality_source_missing','swing_quality_gate',
        'score','leader_score','fresh_gate_ok','trigger_reached','source_fresh','execution_fresh_ok_v1039','quality_price_reaction_state_v1039','quality_final_hard_block_v1039',
        'updated_ts','updated_at','published_at','created_ts','first_seen_ts','hold_created_at','hold_expires_at',
        'strategy_worker_version','source_version','brain_version','score_patch_version_source_v925',
        'conditions_changed_v925','trigger_formula_changed_v925','paper_open_changed_v925','exit_changed_v925',
        'role_mismatch_true_error_v1001','role_mismatch_flag_only_v1001','role_mismatch_class_v1001',
        'source_missing_v1001','source_missing_trade_row_v1001','source_missing_nontrade_row_v1001','audit_only_v1001',
    )
    for key in mandatory_scalars:
        if key not in src:
            continue
        clean = _v1020_trim_scalar(src.get(key))
        if clean not in (None, ''):
            out[key] = clean

    for key in ('paper_entry_hold_reasons','paper_final_block_reasons','final_entry_reasons','final_trade_reasons',
                'hold_reasons','source_missing_frames_v1001'):
        raw = src.get(key)
        if isinstance(raw, list):
            out[key] = [_v1020_trim_scalar(x) for x in raw[:12] if isinstance(x, (str, int, float, bool))]

    gate = _v1020_gate_view(src.get('swing_entry_gate_v977'))
    if gate:
        out['swing_entry_gate_v977'] = gate
    plan = _v1020_plan_view(src.get('swing_structure_plan_v977'))
    if not plan and isinstance(gate.get('structure_plan') if isinstance(gate, dict) else None, dict):
        plan = dict(gate.get('structure_plan') or {})
    if plan:
        out['swing_structure_plan_v977'] = plan
    context = _v1020_structure_context_view(canonical_structure_context(src))
    if context:
        out['structure_context_v871'] = context

    budget = _v1029_budget_state(out)

    _context_view_cache_v1079: Dict[int, Dict[str, Any]] = {}
    for key in ('entry_context','canonical_entry_decision','common_entry_decision','entry_diagnostics'):
        raw_context = src.get(key)
        if not isinstance(raw_context, dict):
            continue
        object_key = id(raw_context)
        view = _context_view_cache_v1079.get(object_key)
        if view is None:
            view = _v1020_context_view(raw_context)
            _context_view_cache_v1079[object_key] = view
        if view:
            _v1029_budget_add(out, budget, key, view, 18000)

    priority_dicts = (
        'trigger_gate_v738','trigger_gate_v737','trigger_gate_v736','trigger_gate_v735','trigger_gate_v734',
        'trigger_provenance_v924','structure_levels','entry_plan','minimal_entry_gate_v925',
        'candidate_input_coverage_v906','candidate_input_coverage_v907','candidate_input_coverage_v908',
        'freshness_map','source_snapshot','worker_cache_overlay_v907','worker_cache_overlay_v908',
        'worker_cache_overlay_status_v908','feature_quality_transport_v1098','quality_observation_v925','swing_quality_gate','swing_quality_score_components_v1208','entry_evidence_v983',
        'paper_timing_spine_v940','paper_selection_spine_v940','execution_cost_evidence_v983',
        'trigger_source_review_v864','trigger_source_review_v868','structure_horizontal_lines_v869',
        'quality_metric_compact_v888','s2_observation_v919','legacy_gate_audit_v925','paper_final_safety_diagnostics',
    )
    for key in priority_dicts:
        if isinstance(src.get(key), dict):
            compact = _v1020_bounded_tree(src.get(key), max_depth=3, max_items=24, max_list=10)
            _v1029_budget_add(out, budget, key, compact, 19000)

    _v1029_budget_add(out, budget, 'smart_structure_shadow_v948', _active_smart_shadow_view(src.get('smart_structure_shadow_v948')), 20000)
    _v1029_budget_add(out, budget, 'structure_lab_v956', _active_structure_lab_view(src.get('structure_lab_v956')), 21000)
    _v1029_budget_add(out, budget, 'hot_watch_timing_v945', _active_hot_watch_view(src.get('hot_watch_timing_v945')), 22000)

    optional_added: List[str] = []
    for key, value in src.items():
        if key in out or not isinstance(value, (str, int, float, bool)):
            continue
        clean = _v1020_trim_scalar(value)
        if clean in (None, ''):
            continue
        if _v1029_budget_add(out, budget, str(key), clean, 12000):
            optional_added.append(str(key))

    for key, value in (
        ('paper_latest_compact_schema_v1021', 'paper_candidate_runtime_allowlist_v1021'),
        ('paper_latest_writer_build_v1021', BUILD_LABEL),
        ('candidate_nested_payload_policy_v1021', 'empty-row allowlist; exact contract first; optional scalars bounded'),
        ('conditions_changed_v1021', False),
        ('trigger_formula_changed_v1021', False),
        ('paper_open_changed_v1021', False),
    ):
        _v1029_budget_add(out, budget, key, value, None)
    _v1020_validate_exact_contract(src, out)

    while int(budget.get('bytes') or 0) > V1020_ROW_SOFT_CEILING_BYTES and optional_added:
        _v1029_budget_remove(out, budget, optional_added.pop())
    if int(budget.get('bytes') or 0) > V1020_ROW_SOFT_CEILING_BYTES:
        for key in ('structure_lab_v956','smart_structure_shadow_v948','entry_diagnostics','worker_cache_overlay_v907',
                    'worker_cache_overlay_v908','source_snapshot','legacy_gate_audit_v925','quality_observation_v925'):
            _v1029_budget_remove(out, budget, key)
            if int(budget.get('bytes') or 0) <= V1020_ROW_SOFT_CEILING_BYTES:
                break

    if int(budget.get('bytes') or 0) > V1020_ROW_HARD_CEILING_BYTES:
        for key in ('structure_lab_v956','smart_structure_shadow_v948','entry_diagnostics','worker_cache_overlay_v907',
                    'worker_cache_overlay_v908','source_snapshot','legacy_gate_audit_v925','quality_observation_v925'):
            _v1029_budget_remove(out, budget, key)
            if int(budget.get('bytes') or 0) <= V1020_ROW_HARD_CEILING_BYTES:
                break

    out = _v1327_shrink_row_for_writer_budget(out, V1020_ROW_HARD_CEILING_BYTES)
    budget = _v1029_budget_state(out)
    _v1020_validate_exact_contract(src, out)
    exact_blob = json.dumps(out, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8')
    exact_bytes = len(exact_blob)
    if exact_bytes != int(budget.get('bytes') or 0):
        raise ValueError(f'v1029 incremental JSON budget mismatch: budget={budget.get("bytes")} exact={exact_bytes}')
    if exact_bytes > V1020_ROW_HARD_CEILING_BYTES:
        raise ValueError(f'v1021 candidate row exceeds hard ceiling: {exact_bytes}B')
    if _V1194_CAPTURE_COMPACT_BLOB:
        _V1194_COMPACT_BLOB_CACHE[id(out)] = (out, exact_blob)
    return out

_V1021_CANDIDATE_WRITE_COUNT=0

_V1021_CANDIDATE_LAST_BYTES=0

_V1021_CANDIDATE_LAST_MAX_ROW_BYTES=0

_V1021_CANDIDATE_LAST_AVG_ROW_BYTES=0

_V1021_CANDIDATE_LAST_ROWS=0

_V1021_CANDIDATE_OVER_SOFT=0

_V1021_CANDIDATE_OVER_HARD=0

_V1021_CANDIDATE_VALIDATION_FAILURES=0

_V1026_COUNTER_STATE_LOADED=False

_V1026_TOTAL_COMMIT_COUNT=0

_V1026_TOTAL_COMMIT_RECORDED=False

_V1026_PROCESS_COMMIT_COUNT=0

_V1026_PROCESS_START_TS=now_ts()

_V1026_PROCESS_ID=f"{os.getpid()}:{int(_V1026_PROCESS_START_TS*1000)}"

_V1026_LAST_COMMIT_TS=0.0

_V1026_LAST_COMMIT_TEXT=""

_V1026_LAST_COMMIT_ID=""

_V1028_LAST_COMMIT_PID: Optional[int] = None

_V1028_LAST_COMMIT_PID_RECORDED = False

def _v1026_nonnegative_int(value: Any) -> Optional[int]:
    try:
        if value is None or isinstance(value, bool):
            return None
        out = int(value)
        return out if out >= 0 else None
    except (TypeError, ValueError):
        return None

def _v1026_load_candidate_commit_state() -> None:
    global _V1026_COUNTER_STATE_LOADED, _V1026_TOTAL_COMMIT_COUNT, _V1026_TOTAL_COMMIT_RECORDED
    global _V1026_LAST_COMMIT_TS, _V1026_LAST_COMMIT_TEXT, _V1026_LAST_COMMIT_ID
    global _V1028_LAST_COMMIT_PID, _V1028_LAST_COMMIT_PID_RECORDED
    if _V1026_COUNTER_STATE_LOADED:
        return
    previous = load_json(PAPER_LATEST_WRITER_STATUS_V861, {})
    previous = previous if isinstance(previous, dict) else {}
    total = _v1026_nonnegative_int(previous.get('candidate_total_commit_count_v1026'))
    state = str(previous.get('candidate_total_commit_count_state_v1026') or '')
    if total is not None and state == 'recorded':
        _V1026_TOTAL_COMMIT_COUNT = total
        _V1026_TOTAL_COMMIT_RECORDED = True
    else:
        _V1026_TOTAL_COMMIT_COUNT = 0
        _V1026_TOTAL_COMMIT_RECORDED = False
    _V1026_LAST_COMMIT_TS = fnum(previous.get('candidate_last_commit_ts_v1026'), default=0.0)
    _V1026_LAST_COMMIT_TEXT = str(previous.get('candidate_last_commit_text_v1026') or '')
    _V1026_LAST_COMMIT_ID = str(previous.get('candidate_last_commit_id_v1026') or '')
    last_pid = _v1026_nonnegative_int(previous.get('candidate_last_commit_pid_v1028'))
    last_pid_state = str(previous.get('candidate_last_commit_pid_state_v1028') or '')
    if last_pid is not None and last_pid_state == 'recorded':
        _V1028_LAST_COMMIT_PID = last_pid
        _V1028_LAST_COMMIT_PID_RECORDED = True
    else:
        _V1028_LAST_COMMIT_PID = None
        _V1028_LAST_COMMIT_PID_RECORDED = False
    _V1026_COUNTER_STATE_LOADED = True

def _v1026_candidate_commit_fields() -> Dict[str, Any]:
    _v1026_load_candidate_commit_state()
    return {
        'candidate_total_commit_count_v1026': (_V1026_TOTAL_COMMIT_COUNT if _V1026_TOTAL_COMMIT_RECORDED else None),
        'candidate_total_commit_count_state_v1026': ('recorded' if _V1026_TOTAL_COMMIT_RECORDED else 'not_recorded_legacy'),
        'candidate_total_commit_scope_v1026': 'v1026_and_later_only',
        'candidate_process_commit_count_v1026': _V1026_PROCESS_COMMIT_COUNT,
        'candidate_process_start_ts_v1026': _V1026_PROCESS_START_TS,
        'candidate_process_start_text_v1026': now_text(_V1026_PROCESS_START_TS),
        'candidate_commit_process_id_v1026': _V1026_PROCESS_ID,
        'candidate_writer_pid_v1026': os.getpid(),
        'candidate_runtime_pid_v1028': os.getpid(),
        'candidate_last_commit_pid_v1028': (_V1028_LAST_COMMIT_PID if _V1028_LAST_COMMIT_PID_RECORDED else None),
        'candidate_last_commit_pid_state_v1028': ('recorded' if _V1028_LAST_COMMIT_PID_RECORDED else 'not_recorded_legacy'),
        'candidate_last_commit_ts_v1026': (_V1026_LAST_COMMIT_TS or None),
        'candidate_last_commit_text_v1026': (_V1026_LAST_COMMIT_TEXT or None),
        'candidate_last_commit_id_v1026': (_V1026_LAST_COMMIT_ID or None),
        'candidate_commit_counter_owner_v1026': 'strategy_worker._v1021_publish_candidate_snapshot',
    }

def _v1026_write_candidate_counter_boot_status() -> None:
    """Reset only the current-process counter while preserving the last committed snapshot."""
    global _V1021_CANDIDATE_WRITE_COUNT, _V1026_PROCESS_COMMIT_COUNT
    _v1026_load_candidate_commit_state()
    _V1021_CANDIDATE_WRITE_COUNT = 0
    _V1026_PROCESS_COMMIT_COUNT = 0
    previous = load_json(PAPER_LATEST_WRITER_STATUS_V861, {})
    payload = dict(previous) if isinstance(previous, dict) else {}
    payload.update(_v1026_candidate_commit_fields())
    payload.update({
        'candidate_write_count_v1021': 0,
        'candidate_counter_boot_only_v1026': True,
        'candidate_counter_runtime_version_v1026': VERSION,
        'candidate_counter_runtime_build_v1026': BUILD_LABEL,
        'candidate_counter_status_updated_ts_v1026': now_ts(),
        'candidate_counter_status_updated_text_v1026': now_text(),
        'conditions_changed_v1026': False,
        'trigger_formula_changed_v1026': False,
        'paper_open_changed_v1026': False,
    })
    save_json(PAPER_LATEST_WRITER_STATUS_V861, payload)

def _v1021_write_io_status(extra: Optional[Dict[str, Any]] = None) -> None:
    """Write only structure-cache I/O state.

    Candidate commit statistics are owned exclusively by
    clean_strategy_paper_latest_writer_status.json.  A cache checkpoint must
    never rebuild or zero candidate statistics from fresh-process globals.
    """
    allowed_extra = {
        'source_cache_due_v1021','source_cache_records_v1021',
        'source_cache_output_bytes_v1021','source_cache_policy_v1021',
        'source_cache_error_v1025',
    }
    payload={
        'schema':'strategy_cache_io_status_v1025','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':now_ts(),'updated_text':now_text(),
        'source_cache_write_count_v1021':_SOURCE_CACHE_WRITE_COUNT,
        'source_cache_skip_count_v1021':_SOURCE_CACHE_SKIP_COUNT,
        'source_cache_checkpoint_sec_v1021':300.0,
        'candidate_status_source_v1025':str(PAPER_LATEST_WRITER_STATUS_V861),
        'candidate_stats_retired_from_io_status_v1025':True,
        'status_source_split_owner_v1025':'candidate=paper_latest_writer_status; cache=strategy_io_status; liveness=strategy_worker_status',
        'conditions_changed_v1021':False,'trigger_formula_changed_v1021':False,'paper_open_changed_v1021':False,
    }
    if isinstance(extra,dict):
        for key, value in extra.items():
            if key in allowed_extra:
                payload[key] = value
    save_runtime_json(STRATEGY_IO_STATUS_V1021, payload, owner='strategy_io_status_v1211')

def _v1194_build_candidate_publish_views(full_rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], List[bytes], List[int], Dict[str, Any]]:
    """Build Paper rows, encoded bytes, and Main-lite rows in one source traversal."""
    compact: List[Dict[str, Any]] = []
    encoded: List[bytes] = []
    sizes: List[int] = []
    lite_rows: List[Dict[str, Any]] = []
    stage_counts: Counter = Counter(); all_stage_counts: Counter = Counter(); lane_counts: Counter = Counter()
    mats: Counter = Counter(); reasons: Counter = Counter(); risks: Counter = Counter()
    trade_count = 0; coverage_count = 0
    lite_error: Optional[str] = None
    global _V1194_CAPTURE_COMPACT_BLOB
    previous_capture = _V1194_CAPTURE_COMPACT_BLOB
    _V1194_CAPTURE_COMPACT_BLOB = True
    try:
        for row in full_rows:
            # Canonical Paper compacting stays fail-closed and independent from the display-only lite view.
            candidate = _v861_compact_row_for_latest(row)
            cached = _V1194_COMPACT_BLOB_CACHE.pop(id(candidate), None)
            blob = cached[1] if cached is not None and cached[0] is candidate else json.dumps(candidate, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8')
            compact.append(candidate); encoded.append(blob); sizes.append(len(blob))
            if lite_error is not None:
                continue
            try:
                st = _v821_stage(row)
                all_stage_counts[st] += 1
                if _v821_is_trade_candidate(row):
                    trade_count += 1; stage_counts[st] += 1
                else:
                    coverage_count += 1
                lane_counts[_v821_lane(row) or '-'] += 1
                try:
                    chg = fnum(row.get('change_1m_pct'), row.get('price_chg_60s'), default=None)
                except Exception:
                    chg = None
                if chg is not None:
                    mats['1분가격 정상'] += 1
                    if chg <= 0: mats['1분반응 0/음수'] += 1
                    elif chg >= 0.35: mats['1분반응 통과'] += 1
                    else: mats['1분반응 부족'] += 1
                else:
                    mats['1분가격 없음'] += 1
                for key in ('block_reasons','s_stage_reasons','hard_risk_reasons','s1_fail_reasons','why_not_s1'):
                    for item in _v821_safe_list(row.get(key), 12): reasons[str(item)] += 1
                for key in ('risk_tags','warning_tags'):
                    for item in _v821_safe_list(row.get(key), 12): risks[str(item)] += 1
                lite_rows.append(_v821_compact_candidate_row(row))
            except Exception as exc:
                lite_error = f'{exc.__class__.__name__}: {exc}'
                append_error(ERROR, 'v1194_candidate_lite_build_nonblocking', exc)
    finally:
        _V1194_CAPTURE_COMPACT_BLOB = previous_capture
        if not previous_capture:
            _V1194_COMPACT_BLOB_CACHE.clear()
    lite_obj = {} if lite_error else {
        'schema': 'candidate_latest_snapshot_v821', 'version': VERSION, 'build': BUILD_LABEL,
        'updated_ts': nowv, 'updated_text': now_text(nowv), 'row_count': len(lite_rows),
        'trade_count': trade_count, 'coverage_count': coverage_count,
        'stage_counts': dict(stage_counts), 'all_stage_counts': dict(all_stage_counts),
        'lane_counts': dict(lane_counts), 'materials': dict(mats),
        'reason_top': _v821_counter_top_dict(reasons, 30), 'risk_top': _v821_counter_top_dict(risks, 30),
        'rows_lite': lite_rows, 'source': 'strategy_worker.paper_candidates_latest.write_owner',
        'policy': 'v1194: Main-lite and canonical Paper rows are built in one source traversal; values and trading rules unchanged',
        'single_source_traversal_v1194': True,
    }
    return compact, encoded, sizes, lite_obj

def _v1194_publish_candidate_lite_object(obj: Dict[str, Any]) -> None:
    if not isinstance(obj, dict) or not obj:
        return
    try:
        save_runtime_json(CANDIDATE_LITE_SNAPSHOT, obj, owner='candidate_lite_v1211')
        _LATEST_PUBLISH_STATUS_V1008.clear()
        _LATEST_PUBLISH_STATUS_V1008.update({
            'latest_publish_ts_v821': obj.get('updated_ts'), 'latest_publish_text_v821': obj.get('updated_text'),
            'latest_publish_rows_v821': len(obj.get('rows_lite') or []), 'candidate_lite_snapshot_v821': True,
            'candidate_views_single_source_traversal_v1194': True,
        })
    except Exception as exc:
        append_error(ERROR, 'v1194_candidate_lite_snapshot_save', exc)

def _v1021_publish_candidate_snapshot(path: Path, rows: List[Dict[str, Any]], profile: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Only active PAPER_LATEST publisher with v1029 exact subphase ownership."""
    global _V1021_CANDIDATE_WRITE_COUNT,_V1021_CANDIDATE_LAST_BYTES,_V1021_CANDIDATE_LAST_MAX_ROW_BYTES
    global _V1021_CANDIDATE_LAST_AVG_ROW_BYTES,_V1021_CANDIDATE_LAST_ROWS,_V1021_CANDIDATE_OVER_SOFT
    global _V1021_CANDIDATE_OVER_HARD,_V1021_CANDIDATE_VALIDATION_FAILURES
    global _V1026_TOTAL_COMMIT_COUNT,_V1026_TOTAL_COMMIT_RECORDED,_V1026_PROCESS_COMMIT_COUNT
    global _V1026_LAST_COMMIT_TS,_V1026_LAST_COMMIT_TEXT,_V1026_LAST_COMMIT_ID
    global _V1028_LAST_COMMIT_PID,_V1028_LAST_COMMIT_PID_RECORDED
    _v1026_load_candidate_commit_state()

    token = _v1028_live_phase_enter(profile or {}, 'candidate_writer_full_row_audit')
    full_rows=[r for r in (rows if isinstance(rows,list) else []) if isinstance(r,dict)]
    nowv=now_ts()
    status=_v1021_collect_candidate_publish_status(full_rows,{
        'schema':'paper_latest_writer_status_v1032','version':VERSION,'build':BUILD_LABEL,
        'writer_owner':'strategy_worker._v1021_publish_candidate_snapshot',
        'input_rows':len(full_rows),'result':'START','updated_ts':nowv,'updated_text':now_text(nowv),
    })
    status.update(_v1026_candidate_commit_fields())
    _v1027_phase_stop(profile or {}, 'candidate_writer_full_row_audit', token, calls=1, rows=len(full_rows))
    token = _v1028_live_phase_enter(profile or {}, 'candidate_writer_views_single_source_pass_v1194')
    compact: List[Dict[str, Any]] = []; encoded: List[bytes] = []; sizes: List[int] = []; lite_obj: Dict[str, Any] = {}
    try:
        compact, encoded, sizes, lite_obj = _v1194_build_candidate_publish_views(full_rows, nowv)
    except Exception as exc:
        _V1021_CANDIDATE_VALIDATION_FAILURES += 1
        status.update({'result':'ERROR_BEFORE_WRITE','error':f'{exc.__class__.__name__}: {exc}','compact_rows':len(compact)})
        save_runtime_json(PAPER_LATEST_WRITER_STATUS_V861, status, owner='paper_latest_writer_status_v1211')
        raise
    _v1027_phase_stop(profile or {}, 'candidate_writer_views_single_source_pass_v1194', token, calls=len(full_rows), rows=len(full_rows))

    token = _v1028_live_phase_enter(profile or {}, 'candidate_writer_lite_snapshot')
    _v1194_publish_candidate_lite_object(lite_obj)
    _v1027_phase_stop(profile or {}, 'candidate_writer_lite_snapshot', token, calls=1, rows=len(full_rows))

    total=sum(x+1 for x in sizes); max_row=max(sizes,default=0); avg=int(sum(sizes)/len(sizes)) if sizes else 0
    over_soft=sum(1 for x in sizes if x>V1020_ROW_SOFT_CEILING_BYTES); over_hard=sum(1 for x in sizes if x>V1020_ROW_HARD_CEILING_BYTES)
    if over_hard:
        _V1021_CANDIDATE_VALIDATION_FAILURES += over_hard
        err=f'v1021 hard ceiling rows={over_hard} max={max_row}'
        status.update({'result':'ERROR_BEFORE_WRITE','error':err,'compact_rows':len(compact)})
        save_runtime_json(PAPER_LATEST_WRITER_STATUS_V861, status, owner='paper_latest_writer_status_v1211')
        raise ValueError(err)

    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.parent/f'.{path.name}.strategy.{os.getpid()}.{time.time_ns()}.tmp'
    try:
        token = _v1028_live_phase_enter(profile or {}, 'candidate_writer_tmp_write_fsync')
        with tmp.open('wb') as f:
            for blob in encoded:
                f.write(blob); f.write(b'\n')
            f.flush(); os.fsync(f.fileno())
        _v1027_phase_stop(profile or {}, 'candidate_writer_tmp_write_fsync', token, calls=len(encoded), rows=len(encoded))

        token = _v1028_live_phase_enter(profile or {}, 'candidate_writer_atomic_replace')
        os.replace(tmp,path)
        cleanup=_v861_cleanup_legacy_tmp(path)
        _v1027_phase_stop(profile or {}, 'candidate_writer_atomic_replace', token, calls=1, rows=len(encoded))
    except Exception as exc:
        try: tmp.unlink(missing_ok=True)
        except Exception: pass
        status.update({'result':'ERROR_WRITE','error':f'{exc.__class__.__name__}: {exc}'})
        save_runtime_json(PAPER_LATEST_WRITER_STATUS_V861, status, owner='paper_latest_writer_status_v1211')
        raise

    token = _v1028_live_phase_enter(profile or {}, 'candidate_writer_status_commit')
    _V1021_CANDIDATE_WRITE_COUNT += 1
    _V1026_PROCESS_COMMIT_COUNT += 1
    _V1026_TOTAL_COMMIT_COUNT = (_V1026_TOTAL_COMMIT_COUNT + 1) if _V1026_TOTAL_COMMIT_RECORDED else 1
    _V1026_TOTAL_COMMIT_RECORDED = True
    _V1026_LAST_COMMIT_TS = now_ts()
    _V1026_LAST_COMMIT_TEXT = now_text(_V1026_LAST_COMMIT_TS)
    _V1028_LAST_COMMIT_PID = os.getpid()
    _V1028_LAST_COMMIT_PID_RECORDED = True
    commit_material = f"{os.getpid()}:{time.time_ns()}:{_V1026_TOTAL_COMMIT_COUNT}:{len(compact)}:{path.stat().st_size}"
    _V1026_LAST_COMMIT_ID = 'candidate-' + hashlib.sha256(commit_material.encode('utf-8')).hexdigest()[:20]
    _V1021_CANDIDATE_LAST_BYTES=total; _V1021_CANDIDATE_LAST_MAX_ROW_BYTES=max_row
    _V1021_CANDIDATE_LAST_AVG_ROW_BYTES=avg; _V1021_CANDIDATE_LAST_ROWS=len(compact)
    _V1021_CANDIDATE_OVER_SOFT=over_soft; _V1021_CANDIDATE_OVER_HARD=over_hard
    status.update(cleanup)
    status.update({
        'result':'OK','compact_rows':len(compact),'rows_written':len(compact),'output_bytes':path.stat().st_size,
        'candidate_write_count_v1021':_V1021_CANDIDATE_WRITE_COUNT,
        'candidate_rows_v1021':len(compact),'candidate_bytes_v1021':path.stat().st_size,
        'candidate_avg_row_bytes_v1021':avg,'candidate_max_row_bytes_v1021':max_row,
        'candidate_over_soft_ceiling_v1021':over_soft,'candidate_over_hard_ceiling_v1021':over_hard,
        'candidate_validation_failures_v1021':_V1021_CANDIDATE_VALIDATION_FAILURES,
        'candidate_legacy_publish_paths_retired_v1021':True,
        'role_source_from_full_rows_v1021':True,
        'candidate_compactor_schema_v1029':'candidate_runtime_allowlist_incremental_budget_v1029',
        'candidate_compactor_single_pass_budget_v1029':True,
        'candidate_views_single_source_traversal_v1194':True,
        'candidate_encoded_bytes_reused_for_write_v1194':True,
        'candidate_hard_ceiling_exact_blob_reused_v1194':True,
        'candidate_compactor_full_row_json_checks_per_row_v1029':1,
        'candidate_compactor_scalar_field_fastpath_v1079':True,
        'candidate_compactor_scalar_fastpath_calls_v1079':_V1079_SCALAR_FIELD_FASTPATH_CALLS,
        'candidate_compactor_nested_serialize_calls_v1079':_V1079_NESTED_FIELD_SERIALIZE_CALLS,
        'candidate_compactor_context_identity_reuse_v1079':True,
        'candidate_writer_phase_owner_v1029':'strategy_worker._v1021_publish_candidate_snapshot direct subphases',
        'candidate_writer_audit_lite_split_v1032':True,
        'canonical_candle_map_reuse_v1032':True,
        'candidate_snapshot_scope':{
            'schema':'strategy_candidate_snapshot_scope_v1143',
            'pipeline_cycle_id_v1150': (str(compact[0].get('candidate_pipeline_cycle_id_v1150') or '') if compact else ''),
            'pipeline_cycle_id_consistent_v1150': len({str(x.get('candidate_pipeline_cycle_id_v1150') or '') for x in compact}) <= 1,
            'state':'NORMAL',
            'owner':'strategy_worker._v1021_publish_candidate_snapshot',
            'atomic_replace':True,
            'complete_snapshot':True,
            'rows_written':len(compact),
            'output_bytes':path.stat().st_size,
            'invalid_rows':0,
            'commit_id':_V1026_LAST_COMMIT_ID,
            'updated_ts':_V1026_LAST_COMMIT_TS,
            'tail_cap':None,
            'legacy_tail_300_retired':True,
        },
        'conditions_changed':False,'trigger_formula_changed':False,'paper_open_changed':False,
    })
    # v1317: after commit id is sealed, publish one immutable full candidate file.
    # The rolling paper_candidates_latest.jsonl can advance before Review/Paper async readers finish.
    try:
        _v1317_candidate_generation = _v1317_publish_candidate_generation_file(
            str(compact[0].get('candidate_pipeline_cycle_id_v1150') or '') if compact else '',
            _V1026_LAST_COMMIT_ID,
            compact,
        )
    except Exception as exc:
        _v1317_candidate_generation = {'schema':'strategy_candidate_generation_file_v1317','state':'ERROR','error':f'{type(exc).__name__}: {exc}','auto_buy':False}
    status['candidate_generation_v1317'] = _v1317_candidate_generation
    status['committed_candidate_file_v1317'] = _v1317_candidate_generation.get('path')
    status['committed_candidate_file_sha256_v1317'] = _v1317_candidate_generation.get('sha256')
    status['committed_candidate_file_rows_v1317'] = _v1317_candidate_generation.get('rows')
    status.update(_v1026_candidate_commit_fields())
    status['candidate_counter_boot_only_v1026'] = False
    status['candidate_counter_status_updated_ts_v1026'] = _V1026_LAST_COMMIT_TS
    status['candidate_counter_status_updated_text_v1026'] = _V1026_LAST_COMMIT_TEXT
    save_runtime_json(PAPER_LATEST_WRITER_STATUS_V861, status, owner='paper_latest_writer_status_v1211')
    _v1021_write_io_status({
        'candidate_last_result_v1021':'OK','candidate_path_v1021':str(path),
        'candidate_output_file_bytes_v1021':path.stat().st_size,
        'role_source_from_full_rows_v1021':True,
        'candidate_policy_v1021':'one caller, one writer, full-row audit before compact, atomic replace',
    })
    _v1027_phase_stop(profile or {}, 'candidate_writer_status_commit', token, calls=2, rows=len(compact))
    status['strategy_writer_runtime_mirrors_v1211'] = 'atomic_no_fsync'
    status['canonical_candidate_fsync_v1211'] = True
    return dict(status)

VERSION = "strategy_worker_v0.989"

BUILD_LABEL = "v1051_compact_intermediate_status_single_full_payload_2026-06-26"

MAIN_DEPLOY_VERSION = BUILD_LABEL

def _v861_compact_row_for_latest__L24516(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v1049_prev_compact_row_for_latest(row)
    if not isinstance(out, dict):
        out = {}
    for key in (
        'structure_integrity_v1048','structure_integrity_block_v1048','structure_integrity_refresh_required_v1048',
        'structure_integrity_v1049','structure_integrity_block_v1049','structure_integrity_refresh_required_v1049',
        'structure_distant_historical_context_v1049',
    ):
        value = row.get(key) if isinstance(row, dict) else None
        if value not in (None, '', [], {}):
            out[key] = value
    return out

def _v1165_count_value(*values: Any, default: int = 0, field: str = '') -> int:
    for value in values:
        if value is None or value == '':
            continue
        if isinstance(value, bool):
            continue
        if isinstance(value, (list, tuple, set, dict)):
            return len(value)
        if isinstance(value, (int, float)):
            return int(value)
        if isinstance(value, str):
            text=value.strip().replace(',', '')
            if not text:
                continue
            try:
                return int(float(text))
            except (TypeError, ValueError):
                continue
    return int(default)

VERSION = 'strategy_worker_v1.028'

BUILD_LABEL = 'v1169_restore_quality_safety_keep_runtime_cleanup_2026-07-01'

MAIN_DEPLOY_VERSION = BUILD_LABEL

_V1115_STRUCTURE_TX = threading.local()

_V1115_STRUCTURE_TX_LAST: Dict[str,Any] = {}

def _v1115_structure_cache_load(default: Any=None) -> Any:
    tx=getattr(_V1115_STRUCTURE_TX,'state',None)
    if isinstance(tx,dict) and tx.get('active') and tx.get('has_pending'):
        return copy.deepcopy(tx.get('pending'))
    return _V1115_RAW_LOAD_JSON(STRUCTURE_SNAPSHOT_CACHE,default)

def _v1115_structure_cache_save(obj: Any) -> None:
    tx=getattr(_V1115_STRUCTURE_TX,'state',None)
    if isinstance(tx,dict) and tx.get('active'):
        tx['pending']=copy.deepcopy(obj)
        tx['has_pending']=True
        tx['buffered_writes']=int(tx.get('buffered_writes') or 0)+1
        return
    _V1115_RAW_SAVE_JSON(STRUCTURE_SNAPSHOT_CACHE,obj)

def _v1115_structure_tx_flush(reason: str) -> Dict[str,Any]:
    global _V1115_STRUCTURE_TX_LAST
    tx=getattr(_V1115_STRUCTURE_TX,'state',None)
    if not isinstance(tx,dict) or not tx.get('active'):
        return dict(_V1115_STRUCTURE_TX_LAST)
    pending=tx.get('pending') if tx.get('has_pending') else None
    error=''
    tx['active']=False
    try:
        if pending is not None:
            _V1115_RAW_SAVE_JSON(STRUCTURE_SNAPSHOT_CACHE,pending)
    except Exception as exc:
        error=f'{exc.__class__.__name__}: {exc}'
        raise
    finally:
        _V1115_STRUCTURE_TX.state=None
        _V1115_STRUCTURE_TX_LAST={
            'schema':'structure_snapshot_single_commit_v1115',
            'buffered_writes':int(tx.get('buffered_writes') or 0),
            'physical_writes':1 if pending is not None and not error else 0,
            'writes_avoided':max(0,int(tx.get('buffered_writes') or 0)-(1 if pending is not None and not error else 0)),
            'result_rows':int(tx.get('entry_plan_rows') or 0),
            'flush_reason':str(reason or 'unknown'),
            'error':error or None,
            'strategy_contract_changed':False,
            'policy':'same-thread reads observe pending merged cache from entry-plan through final promotion reseal; one final atomic fsync preserves final payload',
        }
    return dict(_V1115_STRUCTURE_TX_LAST)

def _v732_reseal_common_uprising_promotions__v1115(rows: List[Dict[str,Any]], nowv: float) -> Tuple[List[Dict[str,Any]],Dict[str,Any]]:
    try:
        return _V1115_PREV_PROMOTION_RESEAL(rows,nowv)
    finally:
        _v1115_structure_tx_flush('promotion_reseal_complete')

def _v1027_finalize_cpu_profile__v1115(profile: Dict[str,Any], result: Any=None) -> Dict[str,Any]:
    out=_V1115_PREV_FINALIZE_CPU_PROFILE(profile,result)
    if isinstance(out,dict):
        out['structure_snapshot_single_commit_v1115']=dict(_V1115_STRUCTURE_TX_LAST)
        out['speed_surgery_v1115']={
            'same_file_snapshot_writes_collapsed':True,
            'structure_lab_detail_event_driven':True,
            'structure_lab_precomputed_frame_timestamps':True,
            'structure_lab_immutable_map_deepcopy_removed':True,
            'entry_gate_changed':False,'rank_changed':False,'trigger_invalid_target_changed':False,
        }
    return out

def run_once__v1115_tx_closeout() -> Dict[str, Any]:
    result=None
    try:
        result=_V1115_PREV_RUN_ONCE()
    finally:
        _v1115_structure_tx_flush('run_once_finally_closeout')
    return result

VERSION = 'strategy_worker_v1.081'

BUILD_LABEL = 'v1327_rebreak_writer_row_budget_fix_2026-07-07'

MAIN_DEPLOY_VERSION = BUILD_LABEL

def _v1180_apply_execution_entry_plan_core(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    """One active plan-state pass for the execution handoff."""
    return _v554_apply_entry_plan_state__L2086(rows, nowv)

VERSION = 'strategy_worker_v1.081'

BUILD_LABEL = 'v1327_rebreak_writer_row_budget_fix_2026-07-07'

MAIN_DEPLOY_VERSION = BUILD_LABEL

def _v1177_current_cycle_occurrence(rec: Dict[str, Any], state_key: str, price: float, trigger_price: float, nowv: float) -> Tuple[Dict[str, Any], str]:
    """v1326: restore v1051 trigger occurrence semantics.

    Keep the same frozen major/setup/entry plan while it is valid.
    If price moves below trigger, mark RESET_BELOW.  When it crosses back above
    trigger after that reset, create a REBREAK decision event.  This restores the
    swing-watch contract without changing trigger/invalid/target/RR values.
    """
    if not isinstance(rec, dict):
        return {}, ''
    base_key = build_minimal_gate_decision_key(state_key, _v925_num(rec.get('frozen_ts'), default=0.0))
    if not base_key or price <= 0 or trigger_price <= 0:
        return {}, base_key
    side = 'above' if price >= trigger_price else 'below'
    previous = str(rec.get('trigger_side_v1037') or '').strip().lower()
    kind = str(rec.get('trigger_occurrence_kind_v1037') or '').strip()
    decision = str(rec.get('trigger_occurrence_decision_key_v1037') or '').strip()
    reset_ts = _v925_num(rec.get('trigger_reset_ts_v1037'), default=0.0)
    rebreak_ts = _v925_num(rec.get('trigger_rebreak_ts_v1037'), default=0.0)
    sequence = int(_v925_num(rec.get('trigger_occurrence_seq_v1037'), default=0.0))

    if previous not in ('above', 'below'):
        if side == 'below':
            reset_ts = nowv
            rebreak_ts = 0.0
            kind = 'RESET_BELOW'
            decision = base_key
        else:
            kind = 'INITIAL_OR_MIGRATED_ABOVE'
            decision = base_key
            sequence = max(1, sequence)
    elif side == 'below' and previous != 'below':
        reset_ts = nowv
        rebreak_ts = 0.0
        kind = 'RESET_BELOW'
        decision = decision or base_key
    elif side == 'above' and previous == 'below' and reset_ts > 0:
        rebreak_ts = nowv
        sequence = max(1, sequence + 1)
        decision = f'{base_key}|rebreak:{int(rebreak_ts*1000)}'
        kind = 'REBREAK'
    elif not decision:
        decision = base_key
        kind = kind or ('INITIAL_OR_MIGRATED_ABOVE' if side == 'above' else 'RESET_BELOW')

    rec['trigger_side_v1037'] = side
    rec['trigger_reset_ts_v1037'] = reset_ts or None
    rec['trigger_rebreak_ts_v1037'] = rebreak_ts or None
    rec['trigger_occurrence_seq_v1037'] = sequence
    rec['trigger_occurrence_kind_v1037'] = kind
    rec['trigger_occurrence_decision_key_v1037'] = decision or base_key
    rec['trigger_occurrence_schema_v1326'] = 'v1051_rebreak_restored'

    event_ts = rebreak_ts if kind == 'REBREAK' and rebreak_ts > 0 else (nowv if side == 'above' else 0.0)
    evidence = {
        'schema': 'trigger_occurrence_v1037_rebreak_restored_v1326',
        'state_key': state_key or None,
        'base_plan_decision_key': base_key or None,
        'decision_key': (decision or base_key) or None,
        'kind': kind or None,
        'side': side,
        'event_ts': event_ts or None,
        'qualification_ts_v1177': event_ts or None,
        'contract_ready': bool(side == 'above' and (decision or base_key)),
        'qualification_state': 'QUALIFIED_EVENT' if side == 'above' else 'WAIT_TRIGGER_REBREAK',
        'requires_new_rebreak': bool(side == 'below'),
        'current_cycle_requalification_v1177': False,
        'v1051_rebreak_restored_v1326': True,
        'plan_frozen_ts': _v925_num(rec.get('frozen_ts'), default=0.0) or None,
        'reset_ts': reset_ts or None,
        'rebreak_ts': rebreak_ts or None,
        'sequence': sequence,
        'trigger_price': trigger_price,
        'current_price': price,
        'trigger_reached': side == 'above',
        'event_time_owner': 'strategy_v1051_trigger_rebreak_occurrence_v1326',
        'prior_cycle_event_carried': True,
        'policy': 'v1326 restores v1051: same frozen swing plan remains under watch; below-trigger reset followed by above-trigger rebreak creates a new direct decision event; trigger/invalid/target/RR unchanged',
    }
    return evidence, (decision or base_key)


V1208_HOT_WATCH_SNAPSHOT = BASE_DIR / 'clean_hot_watch_scanner_snapshot.json'


def _v1208_hot_watch_by_ticker() -> Dict[str, Dict[str, Any]]:
    root=load_json(V1208_HOT_WATCH_SNAPSHOT,{}) or {}
    rows=root.get('rows') if isinstance(root,dict) else []
    out: Dict[str, Dict[str, Any]]={}
    for item in rows if isinstance(rows,list) else []:
        if not isinstance(item,dict):
            continue
        ticker=ticker_norm(item.get('ticker') or item.get('market') or item.get('symbol'))
        if ticker:
            out[ticker]=item
    return out


def _v1208_first_owner_value(row: Dict[str, Any], keys: Tuple[str,...]) -> Any:
    sources=[row]
    for name in ('feature_quality_transport_v1098','quality_observation_v925','entry_context','canonical_entry_decision'):
        value=row.get(name)
        if isinstance(value,dict):
            sources.append(value)
    for source in sources:
        for key in keys:
            if source.get(key) not in (None,''):
                return source.get(key)
    return None


def _v1208_seal_owner_evidence(row: Dict[str, Any], hot_map: Dict[str, Dict[str, Any]]) -> None:
    high=_v1208_first_owner_value(row,('recent_high_gap_pct','below_high_pct','high_gap_pct'))
    day=_v1208_first_owner_value(row,('day_pos_pct','current_close_pos_ratio','day_position_pct'))
    try:
        high_num=float(str(high).replace(',','').replace('%','').strip()) if high not in (None,'') else None
    except Exception:
        high_num=None
    try:
        day_num=float(str(day).replace(',','').replace('%','').strip()) if day not in (None,'') else None
    except Exception:
        day_num=None
    if high_num is not None and math.isfinite(high_num):
        row['recent_high_gap_pct']=round(high_num,6)
        row['recent_high_gap_source_v1208']='existing scanner/feature owner value'
    if day_num is not None and math.isfinite(day_num):
        row['day_pos_pct']=round(day_num,6)
        row['day_position_source_v1208']='existing scanner/feature owner value'
    ticker=ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol'))
    hot=hot_map.get(ticker) if ticker else None
    if isinstance(hot,dict):
        started=_v925_num(hot.get('hot_watch_started_ts_v945'),default=0.0)
        key=str(hot.get('hot_watch_occurrence_key_v945') or '').strip()
        if started>0:
            row['scanner_occurrence_started_ts_v1203']=started
            row['scanner_occurrence_source_v1203']='scanner_worker.hot_watch_occurrence_v945'
        if key:
            row['scanner_occurrence_key_v1203']=key

def apply_swing_entry_gate__v1177_current_cycle(rows: List[Dict[str, Any]], nowv: float) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    previous_active_v1177, read_state = _v925_read_gate_state()
    active: Dict[str, Dict[str, Any]] = dict(previous_active_v1177 or {})
    summary = Counter(); hard_reason_counter = Counter(); source_counter = Counter(); out: List[Dict[str, Any]] = []; samples: List[Dict[str, Any]] = []
    summary['prior_cycle_state_loaded_v1326'] = len(previous_active_v1177)
    seen_keys = set()
    hot_watch_by_ticker_v1208 = _v1208_hot_watch_by_ticker()
    for source in rows if isinstance(rows, list) else []:
        if not isinstance(source, dict): continue
        row = source; summary['rows'] += 1
        _v1208_seal_owner_evidence(row, hot_watch_by_ticker_v1208)
        observation_only_v988 = _v988_is_s3_observation_only(row)
        quality = _v925_quality_observation(row); legacy = _v925_legacy_audit(row)
        extreme_tags = list(quality.get('extreme_quality_risk_tags') or [])
        summary['quality_rows'] += 1
        if extreme_tags: summary['extreme_rows'] += 1
        price = _v925_row_price(row); ctx = _v925_structure_context(row); state_key = minimal_gate_state_key(row)
        integrity_v1048 = _v1048_structure_integrity(row, ctx, price)
        integrity_block_v1048 = bool(integrity_v1048.get('blocked'))
        row['structure_integrity_v1048'] = integrity_v1048
        row['structure_integrity_block_v1048'] = integrity_block_v1048
        row['structure_integrity_refresh_required_v1048'] = integrity_block_v1048
        row['structure_integrity_v1049'] = integrity_v1048
        row['structure_integrity_block_v1049'] = integrity_block_v1048
        row['structure_integrity_refresh_required_v1049'] = bool(integrity_v1048.get('refresh_required'))
        row['structure_distant_historical_context_v1049'] = bool(integrity_v1048.get('historical_context_only_v1049'))
        if isinstance(ctx, dict):
            ctx['structure_integrity_v1048'] = integrity_v1048
            ctx['structure_integrity_block_v1048'] = integrity_block_v1048
            ctx['structure_integrity_v1049'] = integrity_v1048
            ctx['structure_integrity_block_v1049'] = integrity_block_v1048
            ctx['structure_distant_historical_context_v1049'] = bool(integrity_v1048.get('historical_context_only_v1049'))
        if integrity_v1048.get('suspect_sample_count'):
            summary['structure_integrity_suspect_rows_v1048'] += 1
        if integrity_v1048.get('historical_context_only_v1049'):
            summary['structure_distant_historical_context_rows_v1049'] += 1
        if integrity_v1048.get('actual_plan_overlap'):
            summary['structure_actual_plan_overlap_rows_v1049'] += 1
        if integrity_block_v1048:
            summary['structure_integrity_quarantined_rows_v1048'] += 1
        current_plan = _v925_current_actual_plan(row)
        hard: List[str] = []; severe = False
        if observation_only_v988:
            hard.append('s3_observation_only_no_open')
            severe = True
            summary['observation_only_blocked_v988'] += 1
        if not state_key:
            hard.append('stable_market_state_key_missing'); severe = True
        else: seen_keys.add(state_key)
        if integrity_block_v1048:
            hard.append('structure_integrity_quarantine_v1048'); severe = True
            if state_key and state_key in active:
                active.pop(state_key, None)
                summary['structure_integrity_retired_plan_rows_v1048'] += 1
        source_structure_ready_v1048 = bool(ctx and ctx.get('major_ready') and ctx.get('setup_ready') and ctx.get('execution_ready') and not ctx.get('source_missing'))
        structure_ready = bool(source_structure_ready_v1048 and not integrity_block_v1048)
        if not source_structure_ready_v1048:
            hard.append('structure_source_or_role_missing'); severe = True
        rec = active.get(state_key) if state_key else None
        retired_reason = ''
        if isinstance(rec, dict):
            frozen_invalid = _v925_plan_price(rec, 'invalid'); frozen_target = _v925_plan_price(rec, 'target')
            if price > 0 and frozen_invalid > 0 and price <= frozen_invalid: retired_reason = 'frozen_structure_invalidated'
            elif price > 0 and frozen_target > 0 and price >= frozen_target: retired_reason = 'frozen_target_completed'
            if retired_reason:
                active.pop(state_key, None); rec = None; hard.append(retired_reason); severe = True
        if rec is None and state_key and not retired_reason and not integrity_block_v1048:
            trigger = current_plan.get('trigger') if isinstance(current_plan.get('trigger'), dict) else {}
            invalid = current_plan.get('invalid') if isinstance(current_plan.get('invalid'), dict) else {}
            target = current_plan.get('target') if isinstance(current_plan.get('target'), dict) else {}
            if trigger and invalid and target:
                rec = {'state_key':state_key,'ticker':ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol')),'frozen_ts':nowv,'first_seen_ts':nowv,'last_seen_ts':nowv,'trigger':trigger,'invalid':invalid,'target':target,'plan_schema':'alt_swing_actual_structure_plan_v977'}
                active[state_key] = rec; summary['plan_frozen_new'] += 1
            else:
                if not trigger: hard.append('actual_structural_trigger_missing')
                if not invalid: hard.append('actual_structural_invalid_missing')
                if not target: hard.append('next_structural_target_missing')
                severe = True
        elif isinstance(rec, dict):
            rec['last_seen_ts'] = nowv; active[state_key] = rec; summary['plan_frozen_continued'] += 1
        if isinstance(rec, dict):
            move_trigger = _v925_plan_move_pct(current_plan, rec, 'trigger'); move_invalid = _v925_plan_move_pct(current_plan, rec, 'invalid'); move_target = _v925_plan_move_pct(current_plan, rec, 'target')
            moved = any(x > 0.0001 for x in (move_trigger, move_invalid, move_target))
            if moved:
                summary['source_plan_move_detected'] += 1; summary['frozen_plan_held'] += 1
        else:
            move_trigger = move_invalid = move_target = 0.0; moved = False
        trigger_price = _v925_plan_price(rec or {}, 'trigger'); invalid_price = _v925_plan_price(rec or {}, 'invalid'); target_price = _v925_plan_price(rec or {}, 'target')
        if isinstance(rec, dict):
            source_counter[f"trigger:{(rec.get('trigger') or {}).get('role') or '-'}"] += 1
            source_counter[f"invalid:{(rec.get('invalid') or {}).get('role') or '-'}"] += 1
            source_counter[f"target:{(rec.get('target') or {}).get('role') or '-'}"] += 1
        risk = max(0.0, trigger_price-invalid_price); reward = max(0.0,target_price-trigger_price)
        rr = reward/risk if risk>0 else 0.0; room = reward/trigger_price*100.0 if trigger_price>0 else 0.0
        if not integrity_block_v1048:
            if trigger_price <= 0 or invalid_price <= 0 or target_price <= 0:
                hard.append('coherent_structure_plan_incomplete'); severe = True
            elif not (invalid_price < min(price or trigger_price, trigger_price) <= trigger_price < target_price):
                hard.append('invalid_trigger_target_order_invalid'); severe = True
            if rr < V925_MIN_RR: hard.append('risk_reward_below_minimum')
            if room < V925_MIN_TARGET_ROOM_PCT: hard.append('target_room_below_minimum')
        freshness_v1039 = _v1039_execution_freshness(row)
        fresh_ok = freshness_v1039.get('execution_fresh_ok') is True
        if not fresh_ok: hard.append('execution_sources_not_fresh')
        spread = _v925_num(row.get('spread_pct'),row.get('micro_spread_pct'),row.get('orderbook_spread_pct'),default=-1.0)
        if spread < 0: hard.append('spread_source_missing')
        elif spread > V925_UNTRADABLE_SPREAD_PCT: hard.append('untradable_spread'); severe=True
        risk_text=' / '.join(str(x) for key in ('risk_tags','execution_risk_tags') for x in (row.get(key) if isinstance(row.get(key),list) else [row.get(key)]) if _v925_present(x))
        if '거래불가' in risk_text or bool(row.get('trade_unavailable')) or bool(row.get('liquidity_untradable')):
            hard.append('untradable_liquidity'); severe=True
        confirmed_slip, slip_source = _v925_slippage_confirmed(row)
        if confirmed_slip is not None and confirmed_slip > V925_UNTRADABLE_SPREAD_PCT:
            hard.append('confirmed_slippage_untradable'); severe=True
        quality_gate_raw_v1170 = _swing_quality_gate(row, rr, room, spread, confirmed_slip) if '_swing_quality_gate' in globals() else {}
        quality_gate_v1170 = dict(quality_gate_raw_v1170 or {})
        quality_gate_v1170['would_hard_pass_v1097'] = bool(quality_gate_v1170.get('hard_pass') is True)
        quality_gate_v1170['would_block_reasons_v1097'] = list(quality_gate_v1170.get('block_reasons') or [])
        quality_gate_v1170['hard_pass'] = True
        quality_gate_v1170['block_reasons'] = []
        quality_gate_v1170['enforced'] = False
        quality_gate_v1170['recovery_mode_v1170'] = True
        quality_gate_v1170['policy'] = 'v1170: v1051 role restored; quality is score/rank/observation only and cannot create a final S1 hard block'
        row['swing_quality_score_components_v1208'] = dict(quality_gate_v1170.get('score_components') or {})
        row['swing_quality_score_components_owner_v1208'] = 'strategy_worker._swing_quality_gate existing calculation'
        trigger_reached = bool(trigger_price>0 and price>0 and price>=trigger_price)
        trigger_occurrence_v1037, occurrence_decision_key_v1037 = _v1037_trigger_occurrence(rec or {}, state_key, price, trigger_price, nowv)
        trigger_event_ts_v1170 = _v925_num((trigger_occurrence_v1037 or {}).get('event_ts'), default=0.0)
        if isinstance(rec, dict): active[state_key] = rec
        trigger_overshoot_pct = pct(price, trigger_price) if trigger_price>0 and price>0 else 0.0
        # v1203 evidence seal only: publish the exact values already used by the
        # existing gate.  These fields do not alter pass/fail, prices, or exits.
        invalid_distance_pct_v1203 = abs(pct(invalid_price, price)) if invalid_price>0 and price>0 else None
        row['trigger_chase_pct'] = round(trigger_overshoot_pct, 6) if trigger_price>0 and price>0 else None
        row['trigger_chase_source_v1203'] = 'current_candidate_price_vs_frozen_trigger'
        row['invalid_distance_pct'] = round(invalid_distance_pct_v1203, 6) if invalid_distance_pct_v1203 is not None else None
        row['invalid_distance_source_v1203'] = 'current_candidate_price_to_frozen_invalid'
        hot_timing_v1203 = row.get('hot_watch_timing_v945') if isinstance(row.get('hot_watch_timing_v945'), dict) else {}
        scanner_occurrence_ts_v1203 = _v925_num(
            row.get('scanner_occurrence_started_ts_v1203'), hot_timing_v1203.get('scanner_hot_started_ts'), row.get('hot_watch_started_ts_v945'), default=0.0
        )
        scanner_occurrence_key_v1203 = str(
            row.get('scanner_occurrence_key_v1203') or hot_timing_v1203.get('occurrence_key') or row.get('hot_watch_occurrence_key_v945') or ''
        ).strip()
        row['scanner_occurrence_started_ts_v1203'] = scanner_occurrence_ts_v1203 or None
        row['scanner_occurrence_key_v1203'] = scanner_occurrence_key_v1203 or None
        row['scanner_occurrence_source_v1203'] = (
            'scanner_worker.hot_watch_occurrence_v945' if scanner_occurrence_ts_v1203 > 0 else 'SOURCE_MISSING'
        )
        if not integrity_block_v1048:
            if not trigger_reached: hard.append('frozen_trigger_not_reached')
            elif trigger_overshoot_pct > V977_MAX_TRIGGER_OVERSHOOT_PCT: hard.append('trigger_chase_overshoot')
        clean: List[str] = []
        for reason in hard:
            if reason and reason not in clean:
                clean.append(reason); hard_reason_counter[reason] += 1
        passed = bool((not clean) and (not observation_only_v988))
        # v1173 root repair: preserve the real trigger occurrence time and create
        # one immutable transport-ready time when this exact decision first becomes S1.
        occurrence_decision_v1173 = str(occurrence_decision_key_v1037 or '').strip()
        s1_ready_decision_v1173 = str((rec or {}).get('s1_ready_decision_key_v1173') or '').strip() if isinstance(rec,dict) else ''
        s1_ready_ts_v1173 = _v925_num((rec or {}).get('s1_ready_ts_v1173'), default=0.0) if isinstance(rec,dict) else 0.0
        if occurrence_decision_v1173 and s1_ready_decision_v1173 != occurrence_decision_v1173:
            s1_ready_ts_v1173 = 0.0
            if isinstance(rec,dict):
                rec['s1_ready_decision_key_v1173'] = occurrence_decision_v1173
                rec['s1_ready_ts_v1173'] = None
        if passed and occurrence_decision_v1173 and s1_ready_ts_v1173 <= 0:
            s1_ready_ts_v1173 = nowv
            if isinstance(rec,dict):
                rec['s1_ready_decision_key_v1173'] = occurrence_decision_v1173
                rec['s1_ready_ts_v1173'] = s1_ready_ts_v1173
        if isinstance(trigger_occurrence_v1037,dict):
            trigger_occurrence_v1037['event_time_owner'] = 'strategy_v1051_trigger_rebreak_occurrence_v1326'
            trigger_occurrence_v1037['s1_ready_ts_v1173'] = s1_ready_ts_v1173 or None
            trigger_occurrence_v1037['s1_ready_decision_key_v1173'] = occurrence_decision_v1173 or None
            trigger_occurrence_v1037['transport_ttl_owner_v1173'] = 'v1051_rebreak_s1_ready_v1326'
            trigger_occurrence_v1037['actual_trigger_ts_immutable_v1173'] = False
            trigger_occurrence_v1037['prior_cycle_event_carried_v1177'] = True
        if isinstance(rec,dict):
            active[state_key] = rec
        candidate_path_timestamps_v1153 = {
            'schema':'candidate_path_timestamps_v1153',
            'owner':'strategy_worker_v1326_v1051_rebreak_watch',
            'trigger_event_at':trigger_event_ts_v1170 or None,
            'quality_evaluated_at':nowv,
            'quality_pass_at':s1_ready_ts_v1173 if passed else None,
            's1_ready_at_v1173':s1_ready_ts_v1173 if passed else None,
            's1_hold_created_at':None,
            'paper_received_at':None,
            'execution_data_ready_at':None,
            'selector_decided_at':None,
            'open_committed_at':None,
            'terminal_blocked_at':None,
            'strategy_gate_evaluated_at':nowv,
            'strategy_gate_pass':bool(passed),
        }
        if passed: stage='S1'; state='S1_PASS'; label='알트 스윙 구조 통과 · 페이퍼 진입 가능'; summary['pass_s1'] += 1
        elif observation_only_v988: stage='S3'; state='S3_OBSERVE_ONLY'; label='S3 관찰·복기 전용 · OPEN 금지'; summary['observe_s3'] += 1
        elif severe: stage='S3'; state='S3_OBSERVE'; label='실제 구조계획·거래가능성 문제 · 관찰'; summary['observe_s3'] += 1
        else: stage='S2'; state='S2_RECHECK'; label='필수조건 재확인 대기'; summary['recheck_s2'] += 1
        decision_key = occurrence_decision_key_v1037 or build_minimal_gate_decision_key(state_key, _v925_num((rec or {}).get('frozen_ts'), default=0.0) if isinstance(rec, dict) else 0.0)
        base_candidate_key_v1037 = str(row.get('entry_build_key') or row.get('event_id') or row.get('event_key') or '').strip()
        occurrence_suffix_v1037 = int(_v925_num(trigger_occurrence_v1037.get('rebreak_ts'), default=0.0)*1000.0) if isinstance(trigger_occurrence_v1037,dict) else 0
        occurrence_candidate_key_v1037 = (f'{base_candidate_key_v1037}|rebreak:{occurrence_suffix_v1037}' if base_candidate_key_v1037 and occurrence_suffix_v1037>0 else base_candidate_key_v1037)
        if isinstance(trigger_occurrence_v1037,dict): trigger_occurrence_v1037['candidate_key']=occurrence_candidate_key_v1037 or None
        provenance = {
            'schema':'coherent_frozen_structure_provenance_v925','state_key':state_key or None,'frozen_ts':(rec or {}).get('frozen_ts'),
            'trigger':(rec or {}).get('trigger') or {},'invalid':(rec or {}).get('invalid') or {},'target':(rec or {}).get('target') or {},
            'current_source_plan':current_plan,'source_plan_move_detected':moved,'frozen_plan_held':bool(moved and rec),
            'move_pct':{'trigger':round(move_trigger,6),'invalid':round(move_invalid,6),'target':round(move_target,6)},
            'trigger_reached':trigger_reached,'current_confirmation_price':price or None,'distance_pct':round(pct(price,trigger_price),6) if price>0 and trigger_price>0 else None,
            'trigger_occurrence_v1037':trigger_occurrence_v1037,
            'structure_integrity_v1048':integrity_v1048,
            'policy':'15m/5m trigger + 1h/30m invalid + 4h/2h target frozen together; v1048 quarantines repeated/setup-execution/plan-overlap stale-scale source before plan freeze',
        }
        gate = {
            'schema':'swing_entry_gate_v977_single_owner','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,
            'decision_key':decision_key or None,'state_key':state_key or None,'trigger_occurrence_v1037':trigger_occurrence_v1037,'trigger_occurrence':trigger_occurrence_v1037,'trigger_occurrence_contract':{'contract_ready':bool((trigger_occurrence_v1037 or {}).get('contract_ready')),'event_ts':(trigger_occurrence_v1037 or {}).get('event_ts'),'qualification_state':(trigger_occurrence_v1037 or {}).get('qualification_state'),'requires_new_rebreak':bool((trigger_occurrence_v1037 or {}).get('requires_new_rebreak')),'recovery_mode_v1170':True,'event_time_owner':'strategy_v1051_trigger_rebreak_occurrence_v1326','s1_ready_ts_v1173':s1_ready_ts_v1173 or None,'s1_ready_decision_key_v1173':occurrence_decision_v1173 or None,'transport_ttl_owner_v1173':'v1051_rebreak_s1_ready_v1326'},'hard_pass':passed,'stage':stage,'final_trade_state':state,'hard_block_reasons':clean,
            'structure_ready':structure_ready,'source_fresh':fresh_ok,'execution_fresh_ok_v1039':fresh_ok,'execution_freshness_v1039':freshness_v1039,'quality_final_hard_block_v1039':False,'quality_metric_role_v1039':'score_priority_record_only','swing_quality_gate':quality_gate_v1170,'swing_quality_rank_score':quality_gate_v1170.get('rank_score'),'quality_rank_owner':'strategy_worker.apply_swing_entry_gate','candidate_path_timestamps_v1153':candidate_path_timestamps_v1153,'recovery_mode_v1170':True,'recovery_base_v1170':'strategy_worker_v0.989','structure_integrity_v1048':integrity_v1048,'structure_integrity_block_v1048':integrity_block_v1048,'structure_integrity_v1049':integrity_v1048,'structure_integrity_block_v1049':integrity_block_v1048,'structure_distant_historical_context_v1049':bool(integrity_v1048.get('historical_context_only_v1049')),'structure_plan':provenance,'trigger':provenance,
            'invalid_price':invalid_price or None,'target_price':target_price or None,'target_room_pct':round(room,4),'risk_reward':round(rr,4),
            'invalid_distance_pct':round(invalid_distance_pct_v1203,6) if invalid_distance_pct_v1203 is not None else None,
            'trigger_chase_pct':round(trigger_overshoot_pct,6) if trigger_price>0 and price>0 else None,
            'spread_pct':round(spread,4) if spread>=0 else None,'spread_limit_pct':V925_UNTRADABLE_SPREAD_PCT,'confirmed_slippage_pct':confirmed_slip,'confirmed_slippage_source':slip_source,
            'minimum_risk_reward':V925_MIN_RR,'minimum_target_room_pct':V925_MIN_TARGET_ROOM_PCT,'maximum_trigger_overshoot_pct':V977_MAX_TRIGGER_OVERSHOOT_PCT,'quality_observation_only':True,'extreme_quality_risk_tags':extreme_tags,'observation_only_candidate_v988':observation_only_v988,'observation_open_forbidden_v988':observation_only_v988,'auto_buy':False,'exit_changed':True,
        }
        row['legacy_gate_audit_v925']=legacy; row['quality_observation_v925']=quality; row['extreme_quality_risk_tags_v925']=extreme_tags
        row['swing_quality_gate']=quality_gate_v1170; row['swing_quality_rank_score']=quality_gate_v1170.get('rank_score'); row['quality_rank_owner']='strategy_worker.apply_swing_entry_gate'; row['quality_source_missing']=bool(quality_gate_v1170.get('missing_axes'))
        row.pop('minimal_entry_gate_v925', None); row.pop('minimal_gate_decision_key_v925', None)
        row['swing_entry_gate_v977']=gate; row['swing_gate_decision_key_v977']=decision_key or None; row['swing_structure_plan_v977']=provenance
        row['trigger_occurrence_v1037']=trigger_occurrence_v1037; row['trigger_occurrence_candidate_key_v1037']=occurrence_candidate_key_v1037 or None
        row['trigger_occurrence']=trigger_occurrence_v1037; row['trigger_occurrence_contract']=gate.get('trigger_occurrence_contract'); row['trigger_occurrence_candidate_key']=occurrence_candidate_key_v1037 or None
        row['candidate_path_timestamps_v1153']=candidate_path_timestamps_v1153
        row['trigger_event_at_v1153']=trigger_event_ts_v1170 or None; row['quality_evaluated_at_v1153']=nowv; row['quality_pass_at_v1153']=s1_ready_ts_v1173 if passed else None
        row['actual_trigger_event_at_v1173']=trigger_event_ts_v1170 or None; row['s1_ready_at_v1173']=s1_ready_ts_v1173 if passed else None; row['s1_ready_decision_key_v1173']=occurrence_decision_v1173 or None
        row['strategy_recovery_cohort_v1170']='V1051_TRADING_CORE_RECOVERY'; row['strategy_recovery_base_v1170']='strategy_worker_v0.989'; row['strategy_transport_contract_v1173']='actual_trigger_immutable_plus_first_s1_ready'
        row['strategy_mode']='ALT_SWING_V977'; row['strategy_mode_v977']='ALT_SWING_V977'
        row['strategy_timeframe_contract_v977']={'major':'4h/2h','setup':'1h/30m','entry':'15m/5m','execution':'1m/quote'}
        row['swing_trigger_price_raw_v977']=_v925_num(((rec or {}).get('trigger') or {}).get('raw_price'),default=0.0) or None
        row['swing_trigger_price_v977']=trigger_price or None; row['swing_trigger_source_v977']=((rec or {}).get('trigger') or {}).get('source'); row['swing_trigger_frozen_ts_v977']=(rec or {}).get('frozen_ts'); row['swing_source_plan_moved_v977']=moved
        row['swing_invalid_price_v977']=invalid_price or None; row['swing_target_price_v977']=target_price or None
        row['trigger_price']=trigger_price or None; row['entry_trigger_price']=trigger_price or None; row['trigger_reached']=trigger_reached; row['trigger_gap_pct']=provenance.get('distance_pct')
        for key in ('s_stage','candidate_stage','candidate_grade','grade'): row[key]=stage
        row['open_eligible']=passed; row['paper_bot_open']=passed; row['trade_ready']=passed; row['real_eligible']=False; row['auto_buy_ready']=False; row['buy_ready']=False
        row['s3_observation_only_v988']=bool(observation_only_v988)
        row['s3_review_only_v988']=bool(observation_only_v988)
        row['observation_role_v988']='review_only' if observation_only_v988 else None
        row['observation_open_forbidden_v988']=bool(observation_only_v988)
        if observation_only_v988:
            row['strategy_role']='observation'
            row['trade_strategy_label_v988']=None
        row['final_trade_state']=state; row['final_trade_label']=label; row['final_trade_reasons']=clean; row['final_entry_action']='paper_open_ready_swing_v977' if passed else ('structure_observe_swing_v979' if stage=='S3' else 'recheck_wait_swing_v979'); row['final_entry_label']=label; row['final_entry_reasons']=clean; row['trade_ready_label']=label
        row['paper_entry_hold_reasons']=[] if passed else clean; row['paper_final_block_reasons']=[] if passed else clean
        row['canonical_entry_decision']={'schema':'canonical_entry_decision_v977_alt_swing','decision_key':decision_key or None,'gate_pass':passed,'s1_allowed':passed,'hard_block_reasons':clean,'display_reasons':clean,'metrics':gate,'quality_observation_only':quality,'swing_quality_gate':quality_gate_v1170,'quality_rank_score_v1095':quality_gate_v1170.get('rank_score'),'recovery_mode_v1170':True,'observation_only_candidate_v988':observation_only_v988,'observation_open_forbidden_v988':observation_only_v988}
        row['score_patch_version']='alt_swing_timeframe_exit_reset_v977_2026-06-22'; row['score_patch_version_source_v925']='v977_final_swing_gate'
        row['conditions_changed_v925']=True; row['trigger_formula_changed_v925']=True; row['paper_open_changed_v925']=True; row['exit_changed_v925']=True
        if len(samples)<8 and (not passed or moved):
            samples.append({'ticker':ticker_norm(row.get('ticker') or row.get('market') or row.get('symbol')),'stage':stage,'price':price,'trigger':trigger_price,'invalid':invalid_price,'target':target_price,'rr':round(rr,4),'room':round(room,4),'reasons':clean[:5],'source_move':moved})
        out.append(row)
    state_status=_v925_write_gate_state(active,nowv,read_state)
    integrity_uncontained_v1048 = sum(1 for r in out if isinstance(r,dict) and r.get('structure_integrity_block_v1048') and (r.get('open_eligible') or str(r.get('s_stage') or '') == 'S1'))
    top=[{'reason':k,'count':v} for k,v in hard_reason_counter.most_common(14)]
    status={
        'schema':'swing_gate_status_v977_single_spine','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),
        'rows':int(summary.get('rows',0)),'pass_s1':int(summary.get('pass_s1',0)),'recheck_s2':int(summary.get('recheck_s2',0)),'observe_s3':int(summary.get('observe_s3',0)),'observation_only_blocked_v988':int(summary.get('observation_only_blocked_v988',0)),
        'quality_observation_rows':int(summary.get('quality_rows',0)),'extreme_quality_observation_rows':int(summary.get('extreme_rows',0)),'quality_metric_hard_block_count_v1039':0,'quality_metric_role_v1039':'score_priority_record_only',
        'quality_gate_pass_count_v1097':int(summary.get('rows',0)),'quality_gate_block_count_v1097':0,
        'quality_gate_pass_count_v1098':int(summary.get('rows',0)),'quality_gate_block_count_v1098':0,
        'quality_stage_accounting_mode_v1173':'RANK_ONLY_ALL_ROWS_CONTINUE','quality_stage_error_count_v1173':0,
        'structure_integrity_suspect_rows_v1048':int(summary.get('structure_integrity_suspect_rows_v1048',0)),
        'structure_integrity_quarantined_rows_v1048':int(summary.get('structure_integrity_quarantined_rows_v1048',0)),
        'structure_integrity_retired_plan_rows_v1048':int(summary.get('structure_integrity_retired_plan_rows_v1048',0)),
        'structure_integrity_uncontained_rows_v1048':int(integrity_uncontained_v1048),
        'structure_distant_historical_context_rows_v1049':int(summary.get('structure_distant_historical_context_rows_v1049',0)),
        'structure_actual_plan_overlap_rows_v1049':int(summary.get('structure_actual_plan_overlap_rows_v1049',0)),
        'structure_integrity_policy_v1048':'v1049 compatibility: distance/repetition alone is historical context; only actual-plan overlap is fail-closed and sent to full candle refresh',
        'structure_integrity_policy_v1049':'distance/repetition alone is historical context; only far raw lines overlapping trigger/invalid/target are quarantined and refreshed',
        'plan_frozen_new':int(summary.get('plan_frozen_new',0)),'plan_frozen_continued':int(summary.get('plan_frozen_continued',0)),
        'source_plan_move_detected':int(summary.get('source_plan_move_detected',0)),'frozen_plan_held':int(summary.get('frozen_plan_held',0)),
        'trigger_occurrence_rebreak_rows_v1037':sum(1 for r in out if isinstance(r.get('trigger_occurrence_v1037'),dict) and r['trigger_occurrence_v1037'].get('kind')=='REBREAK'),
        'trigger_occurrence_reset_rows_v1037':sum(1 for r in out if isinstance(r.get('trigger_occurrence_v1037'),dict) and r['trigger_occurrence_v1037'].get('kind')=='RESET_BELOW'),
        'hard_reason_top':top,'line_role_counts':dict(source_counter),'samples':samples,
        'trigger_state':{'read_state':read_state,'active_count':state_status.get('active_count'),'pruned_this_cycle':state_status.get('pruned_this_cycle')},
        'thresholds':{'untradable_spread_pct':V925_UNTRADABLE_SPREAD_PCT,'minimum_risk_reward':V925_MIN_RR,'minimum_target_room_pct':V925_MIN_TARGET_ROOM_PCT,'maximum_trigger_overshoot_pct':V977_MAX_TRIGGER_OVERSHOOT_PCT},
        'soft_conditions':'1m/quote is execution confirmation only; price reaction / buy strength / VWAP·EMA / relative strength / money flow remain observation inputs',
        'single_owner':'strategy_worker.apply_swing_entry_gate','paper_contract':'paper reads swing_entry_gate_v977 + swing_gate_decision_key_v977 only for new OPEN','state_identity':'one frozen swing plan per market, carried while valid; trigger reset/rebreak occurrence restored v1326','auto_buy':False,'exit_changed':True,
    }
    status.update({
        'recovery_mode_v1170':True,
        'recovery_base_v1170':'strategy_worker_v0.989',
        'quality_role_v1170':'score_rank_observation_only',
        'quality_would_block_count_v1097':sum(1 for r in out if isinstance(r,dict) and isinstance(r.get('swing_quality_gate'),dict) and r['swing_quality_gate'].get('would_hard_pass_v1097') is not True),
        'trigger_contract_v1170':'RESTORED_BY_V1326',
        'trigger_contract_v1177':'superseded: current-cycle-only event retired by v1326',
        'trigger_contract_v1326':'v1051 rebreak restored: frozen swing plan remains under watch; reset below trigger then rebreak above creates decision event',
        'writer_row_budget_fix_v1327':True,
        'writer_row_budget_policy_v1327':'compact display-only duplicated trigger/rebreak context; preserve exact decision/occurrence keys and trade contract',
        'prior_cycle_state_loaded_v1326':int(summary.get('prior_cycle_state_loaded_v1326',0)),
        'current_cycle_requalification_v1177':False,
        'v1051_rebreak_restored_v1326':True,
        'current_ops_pipeline_preserved_v1170':True,
        'auto_buy':False,
    })
    save_json(V925_MINIMAL_GATE_STATUS,status)
    return out, {'swing_gate_schema_v979':status['schema'],'swing_gate_rows_v979':status['rows'],'swing_gate_pass_v979':status['pass_s1'],'swing_gate_s2_v979':status['recheck_s2'],'swing_gate_s3_v979':status['observe_s3'],'swing_gate_extreme_observe_v979':status['extreme_quality_observation_rows'],'swing_gate_source_plan_move_v979':status['source_plan_move_detected'],'swing_gate_state_active_v979':state_status.get('active_count'),'swing_gate_hard_reason_top_v979':top,'structure_integrity_suspect_rows_v1048':status['structure_integrity_suspect_rows_v1048'],'structure_integrity_quarantined_rows_v1048':status['structure_integrity_quarantined_rows_v1048'],'structure_integrity_retired_plan_rows_v1048':status['structure_integrity_retired_plan_rows_v1048'],'structure_integrity_uncontained_rows_v1048':status['structure_integrity_uncontained_rows_v1048'],'structure_distant_historical_context_rows_v1049':status['structure_distant_historical_context_rows_v1049'],'structure_actual_plan_overlap_rows_v1049':status['structure_actual_plan_overlap_rows_v1049'],'structure_integrity_policy_v1048':status['structure_integrity_policy_v1048'],'structure_integrity_policy_v1049':status['structure_integrity_policy_v1049'],'obsolete_minimal_gate_live_write_v979':0,'obsolete_v925_price_fields_live_write_v981':0,'conditions_changed_v925':True,'trigger_formula_changed_v925':True,'paper_open_changed_v925':True,'exit_changed_v925':True}



# v1182: restore the process-held Strategy singleton contract removed during
# the v1181 flattening. Guard remains strict: a fresh target PID/version/time
# must own the lock before the remaining bundle can continue.
_STRATEGY_SINGLETON_FH_V1182 = None
_STRATEGY_SINGLETON_BOOT_ID_V1182 = ""
STRATEGY_SINGLETON_LOCK_V1182 = BASE_DIR / "runtime" / "strategy_worker_singleton_v1110.lock"
STRATEGY_SINGLETON_STATUS_V1182 = BASE_DIR / "clean_strategy_singleton_status_v1111.json"


def _refresh_strategy_singleton_status_v1182(event: str) -> Dict[str, Any]:
    fh = _STRATEGY_SINGLETON_FH_V1182
    held = bool(fh is not None and not getattr(fh, "closed", True))
    fd = -1
    inode = 0
    try:
        if held:
            fd = int(fh.fileno())
            inode = int(os.fstat(fd).st_ino)
    except Exception:
        held = False
        fd = -1
        inode = 0
    payload = {
        "schema": "strategy_singleton_status_v1182",
        "state": "LOCKED_SINGLE_INSTANCE" if held else "LOCK_PROOF_MISSING",
        "pid": os.getpid(),
        "lock_pid": os.getpid() if held else 0,
        "boot_id": _STRATEGY_SINGLETON_BOOT_ID_V1182,
        "version": VERSION,
        "build": BUILD_LABEL,
        "lock_path": str(STRATEGY_SINGLETON_LOCK_V1182),
        "lock_fd": fd,
        "lock_inode": inode,
        "lock_held": held,
        "event": str(event or "refresh"),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "auto_buy": False,
        "strategy_contract_changed": False,
        "policy": "same process-held flock restored after v1181 flattening",
    }
    save_json(STRATEGY_SINGLETON_STATUS_V1182, payload)
    return payload


def _acquire_strategy_singleton_v1182() -> None:
    global _STRATEGY_SINGLETON_FH_V1182, _STRATEGY_SINGLETON_BOOT_ID_V1182
    boot_id = f"{os.getpid()}-{time.time_ns()}"
    _STRATEGY_SINGLETON_BOOT_ID_V1182 = boot_id
    STRATEGY_SINGLETON_LOCK_V1182.parent.mkdir(parents=True, exist_ok=True)
    fh = STRATEGY_SINGLETON_LOCK_V1182.open("a+", encoding="utf-8")
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        try:
            fh.seek(0)
            owner = fh.read().strip()
        except Exception:
            owner = "unknown"
        fh.close()
        raise SystemExit(f"strategy singleton lock busy; owner={owner}")
    acquired_ts = now_ts()
    fh.seek(0)
    fh.truncate(0)
    fh.write(json.dumps({
        "schema": "strategy_singleton_lock_v1182",
        "pid": os.getpid(),
        "boot_id": boot_id,
        "version": VERSION,
        "build": BUILD_LABEL,
        "acquired_ts": acquired_ts,
        "acquired_text": now_text(),
        "lock_path": str(STRATEGY_SINGLETON_LOCK_V1182),
    }, ensure_ascii=False, separators=(",", ":")))
    fh.flush()
    os.fsync(fh.fileno())
    _STRATEGY_SINGLETON_FH_V1182 = fh
    _refresh_strategy_singleton_status_v1182("acquired")


def _release_strategy_singleton_v1182() -> None:
    global _STRATEGY_SINGLETON_FH_V1182
    fh = _STRATEGY_SINGLETON_FH_V1182
    _STRATEGY_SINGLETON_FH_V1182 = None
    if fh is None:
        return
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
    except Exception:
        pass
    try:
        fh.close()
    except Exception:
        pass

# Flattened final runtime bindings
_V1115_PREV_FINALIZE_CPU_PROFILE = _v1027_finalize_cpu_profile
_V1115_PREV_PROMOTION_RESEAL = _v732_reseal_common_uprising_promotions__L17103
_V1115_PREV_RUN_ONCE = run_once
_V1115_RAW_LOAD_JSON = load_json
_V1115_RAW_SAVE_JSON = save_json
_v1027_finalize_cpu_profile = _v1027_finalize_cpu_profile__v1115
_v1032_legacy_candle_official_fields = _v597_candle_official_fields__L19060
_v1037_trigger_occurrence = _v1177_current_cycle_occurrence
_v1049_prev_compact_row_for_latest = _v861_compact_row_for_latest__L24130
_v510_make_row = _v510_make_row__L9296
_v532_apply_canonical_entry_decision = _v532_apply_canonical_entry_decision__L17091
_v532_build_canonical_entry_decision = _v532_build_canonical_entry_decision__L6846
_v553_apply_reason_taxonomy = _v553_apply_reason_taxonomy__L9533
_v554_build_structure_levels = _v554_build_structure_levels__L20079
_v563_s2_promotion_record = _v563_s2_promotion_record__L6920
_v573_base_apply_entry_decision = _v532_apply_canonical_entry_decision__L1469
_v573_base_build_entry_decision = _v532_build_canonical_entry_decision__L1136
_v573_base_build_structure_levels = _v554_build_structure_levels__L1754
_v573_base_s2_promotion_record = _v563_s2_promotion_record__L6490
_v574_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests__L14861
_v575_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests__L7022
_v583_attach_structure_freshness = _v596_attach_official_structure_rows
_v584_build_canonical_metric_row = _v584_build_canonical_metric_row__L9320
_v595_base_attach_canonical_metric_rows = _v584_attach_canonical_metric_rows
_v595_base_build_structure_levels = _v554_build_structure_levels__L6828
_v595_structure_line_evidence = _v595_structure_line_evidence__L8336
_v596_official_structure_inputs = _v596_official_structure_inputs__L14270
_v596_prev_attach_reactive_structure_rows = _v595_attach_reactive_structure_rows
_v596_prev_structure_line_evidence = _v595_structure_line_evidence__L8034
_v597_candle_official_fields = _v597_candle_official_fields__L23709
_v603_prev_attach_s2_fresh_urgent_requests = _v575_attach_s2_fresh_urgent_requests
_v613_prev_attach_s2_fresh_urgent_requests = _v603_attach_s2_fresh_urgent_requests
_v635_prev_build_canonical_metric_row = _v584_build_canonical_metric_row__L7563
_v635_prev_make_row = _v510_make_row__L2100
_v646_prev_apply_reason_taxonomy = _v553_apply_reason_taxonomy__L1619
_v655_apply_strategy_recheck_lanes = _v655_apply_strategy_recheck_lanes__L9892
_v656_attach_coin_quality = _v656_attach_coin_quality__L10145
_v656_prev_apply_strategy_recheck_lanes = _v655_apply_strategy_recheck_lanes__L2924
_v656_prev_attach_s2_fresh_urgent_requests = _v613_attach_s2_fresh_urgent_requests
_v659_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests__L9906
_v659_prev_v656_attach_coin_quality = _v656_attach_coin_quality__L9844
_v663_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests__L10187
_v668_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests__L10531
_v675_prev_attach_s2_fresh_urgent_requests = _v574_attach_s2_fresh_urgent_requests__L11333
_v676_prev_attach_info_priority = _v574_attach_s2_fresh_urgent_requests__L12345
_v732_reseal_common_uprising_promotions = _v732_reseal_common_uprising_promotions__v1115
_v755_prev_apply_canonical_entry_decision = _v532_apply_canonical_entry_decision__L6896
_v755_structure_taxonomy = _v755_structure_taxonomy__L12853
_v759_prev_apply_canonical_entry_decision = _v532_apply_canonical_entry_decision__L12729
_v759_prev_build_structure_levels = _v554_build_structure_levels__L8155
_v759_prev_taxonomy = _v755_structure_taxonomy__L12592
_v770_prev_official_structure_inputs = _v596_official_structure_inputs__L8312
_v774_prev_fresh_urgent = _v574_attach_s2_fresh_urgent_requests__L12535
_v774_prev_reseal_common = _v732_reseal_common_uprising_promotions__L2948
_v789_prev_reseal_common = _v732_reseal_common_uprising_promotions__L14811
_v792_prev_reseal_common = _v732_reseal_common_uprising_promotions__L15544
_v796_prev_reseal_common = _v732_reseal_common_uprising_promotions__L15896
_v802_common_scalp_profile = _v802_common_scalp_profile__L16535
_v807_prev_common_scalp_profile = _v802_common_scalp_profile__L16057
_v810_attach_quality_priority_requests = _v810_attach_quality_priority_requests__L17152
_v812_build_structure_board = _v812_build_structure_board__L18852
_v812_prev_apply_canonical_entry_decision = _v532_apply_canonical_entry_decision__L12890
_v812_prev_quality_priority_requests = _v810_attach_quality_priority_requests__L16699
_v812_prev_reseal_common = _v732_reseal_common_uprising_promotions__L16448
_v812_setup_type = _v812_setup_type__L17781
_v812_text = _v812_text__L17454
_v819_force_structure_board_aliases = _v819_force_structure_board_aliases__L18894
_v820_prev_v812_build_structure_board = _v812_build_structure_board__L16981
_v821_compact_candidate_row = _v821_compact_candidate_row__L19130
_v822_prev_v812_setup_type = _v812_setup_type__L16840
_v822_prev_v821_compact_candidate_row = _v821_compact_candidate_row__L17626
_v823_prev_v597_candle_official_fields = _v597_candle_official_fields__L14027
_v823_prev_v821_compact_candidate_row = _v821_compact_candidate_row__L17814
_v824_base_v812_build_structure_board = _v812_build_structure_board__L17554
_v824_frame_states = _v824_frame_states__L19113
_v824_prev_v597_candle_official_fields = _v597_candle_official_fields__L17946
_v824_prev_v821_compact_candidate_row = _v821_compact_candidate_row__L18224
_v827_prev_v597_candle_official_fields = _v597_candle_official_fields__L18369
_v827_prev_v821_compact_candidate_row = _v821_compact_candidate_row__L18929
_v827_prev_v824_frame_states = _v824_frame_states__L18418
_v861_compact_row_for_latest = _v861_compact_row_for_latest__L24516
_v869_prev_build_structure_levels = _v554_build_structure_levels__L12832
_v871_prev_build_structure_levels = _v554_build_structure_levels__L19743
apply_swing_entry_gate = apply_swing_entry_gate__v1177_current_cycle
run_once = run_once__v1115_tx_closeout



# =============================================================================
# v1341 - candidate material capture transport (NO strategy logic change)
# Captures old-good-period quality ingredients into candidate/entry_context so
# Paper/Main can audit them later. Missing values remain source_missing; no zero fallback.
# =============================================================================

def _v1341_first_present(*vals: Any) -> Any:
    for v in vals:
        if v not in (None, '', [], {}):
            return v
    return None


def _v1341_num_or_none(*vals: Any) -> Optional[float]:
    for v in vals:
        if v in (None, '', [], {}):
            continue
        try:
            return float(str(v).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return None


def _v1341_src_num(src: Mapping[str, Any], of: Mapping[str, Any], keys: Tuple[str, ...]) -> Optional[float]:
    for k in keys:
        v = _v1341_num_or_none((src or {}).get(k), (of or {}).get(k))
        if v is not None:
            return v
    return None


def _v1341_bool_or_none(*vals: Any) -> Optional[bool]:
    for v in vals:
        if v in (None, '', [], {}):
            continue
        if isinstance(v, bool):
            return v
        s = str(v).strip().lower()
        if s in {'1','true','yes','y','on','pass','ok'}:
            return True
        if s in {'0','false','no','n','off','fail'}:
            return False
    return None


def _v1341_pct_from_ohlc(src: Mapping[str, Any], of: Mapping[str, Any]) -> Dict[str, float]:
    open_p = _v1341_num_or_none((src or {}).get('open'), (src or {}).get('open_price'), (src or {}).get('candle_open'), (of or {}).get('open'))
    high_p = _v1341_num_or_none((src or {}).get('high'), (src or {}).get('high_price'), (src or {}).get('candle_high'), (of or {}).get('high'))
    low_p = _v1341_num_or_none((src or {}).get('low'), (src or {}).get('low_price'), (src or {}).get('candle_low'), (of or {}).get('low'))
    close_p = _v1341_num_or_none((src or {}).get('close'), (src or {}).get('trade_price'), (src or {}).get('current_price'), (src or {}).get('price'), (of or {}).get('current_price'), (of or {}).get('trade_price'))
    if not open_p or not high_p or not low_p or not close_p or min(open_p, high_p, low_p, close_p) <= 0:
        return {}
    denom = close_p if close_p else open_p
    upper = max(0.0, (high_p - max(open_p, close_p)) / denom * 100.0)
    lower = max(0.0, (min(open_p, close_p) - low_p) / denom * 100.0)
    body = abs(close_p - open_p) / denom * 100.0
    return {'upper_wick_pct': upper, 'lower_wick_pct': lower, 'body_ratio': body, 'body_pct': body}


def _v1341_capture_candidate_materials(row: Dict[str, Any], src: Dict[str, Any], of: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out = dict(row or {})
    src = src if isinstance(src, dict) else {}
    of = of if isinstance(of, dict) else {}
    mat: Dict[str, Any] = {'schema': 'candidate_material_capture_v1341', 'owner': 'strategy_worker_transport_only', 'captured_ts': nowv, 'recomputed_strategy_gate': False}
    missing: List[str] = []

    def put(name: str, value: Any, source: str) -> None:
        if value in (None, '', [], {}):
            missing.append(name)
            return
        mat[name] = value
        mat[name + '_source'] = source
        # Flat alias for Paper compact/Main audits. Existing top-level evidence wins.
        if out.get(name) in (None, '', [], {}):
            out[name] = value

    put('change_1m_pct', _v1341_src_num(src, of, ('change_1m_pct','change_1m','price_change_1m','ret_1m','momentum_1m_pct')), 'scanner/feature')
    put('change_3m_pct', _v1341_src_num(src, of, ('change_3m_pct','change_3m','price_change_3m','ret_3m','momentum_3m_pct')), 'scanner/feature')
    put('change_5m_pct', _v1341_src_num(src, of, ('change_5m_pct','change_5m','price_change_5m','ret_5m','momentum_5m_pct')), 'scanner/feature')
    put('change_15m_pct', _v1341_src_num(src, of, ('change_15m_pct','change_15m','price_change_15m','ret_15m','momentum_15m_pct')), 'scanner/feature')
    put('turnover_24h', _v1341_src_num(src, of, ('turnover_24h','trade_value_24h','acc_trade_price_24h','quote_volume_24h','turnover')), 'scanner')
    put('turnover_change_pct', _v1341_src_num(src, of, ('turnover_change_pct','trade_value_change_pct','quote_volume_change_pct','money_flow_change_pct')), 'scanner/feature')
    put('volume_ratio', _v1341_src_num(src, of, ('volume_ratio','vol_ratio','volume_vs_avg','volume_z','volume_ratio_5m','volume_ratio_15m')), 'feature/scanner')
    put('volume_change_pct', _v1341_src_num(src, of, ('volume_change_pct','volume_delta_pct','vol_change_pct','vol_delta_pct')), 'feature/scanner')
    put('volume_expanding', _v1341_bool_or_none(src.get('volume_expanding'), src.get('volume_expand'), src.get('vol_expanding')), 'feature/scanner')

    wick = _v1341_pct_from_ohlc(src, of)
    put('upper_wick_pct', _v1341_src_num(src, of, ('upper_wick_pct','upper_shadow_pct','wick_up_pct','top_wick_pct')) if _v1341_src_num(src, of, ('upper_wick_pct','upper_shadow_pct','wick_up_pct','top_wick_pct')) is not None else wick.get('upper_wick_pct'), 'candle/feature')
    put('lower_wick_pct', _v1341_src_num(src, of, ('lower_wick_pct','lower_shadow_pct','wick_down_pct','bottom_wick_pct')) if _v1341_src_num(src, of, ('lower_wick_pct','lower_shadow_pct','wick_down_pct','bottom_wick_pct')) is not None else wick.get('lower_wick_pct'), 'candle/feature')
    put('body_ratio', _v1341_src_num(src, of, ('body_ratio','body_pct','candle_body_pct','real_body_pct')) if _v1341_src_num(src, of, ('body_ratio','body_pct','candle_body_pct','real_body_pct')) is not None else wick.get('body_ratio'), 'candle/feature')

    # Post-trigger reactions are only copied if an upstream owner already measured them.
    # We do NOT fake future 1m/3m/5m reactions with current values.
    put('trigger_reaction_1m_pct', _v1341_src_num(src, of, ('trigger_reaction_1m_pct','post_trigger_1m_pct','reaction_1m_pct','after_trigger_1m_return_pct')), 'strategy/feature')
    put('trigger_reaction_3m_pct', _v1341_src_num(src, of, ('trigger_reaction_3m_pct','post_trigger_3m_pct','reaction_3m_pct','after_trigger_3m_return_pct')), 'strategy/feature')
    put('trigger_reaction_5m_pct', _v1341_src_num(src, of, ('trigger_reaction_5m_pct','post_trigger_5m_pct','reaction_5m_pct','after_trigger_5m_return_pct')), 'strategy/feature')

    put('buy_ratio_delta', _v1341_src_num(src, of, ('buy_ratio_delta','buy_pressure_delta','buy_trade_ratio_delta','buy_ratio_slope','buy_pressure_slope')), 'orderflow/micro')
    put('spread_delta_pct', _v1341_src_num(src, of, ('spread_delta_pct','spread_change_pct','spread_slope','spread_widen_pct','spread_widening_10s')), 'orderflow/micro')
    put('market_state', _v1341_first_present(src.get('market_state'), src.get('market_regime'), src.get('btc_state'), src.get('alt_market_state'), src.get('market_condition')), 'scanner/strategy')

    # Existing useful aliases that were already present but not consistently transported under audit names.
    if out.get('vwap_gap_pct') in (None, '', [], {}):
        v = _v1341_src_num(src, of, ('vwap_gap_pct','vwap_distance_pct','vwap_dist_pct','distance_from_vwap_pct','vwap_gap_pct'))
        if v is not None: out['vwap_gap_pct'] = v; mat['vwap_gap_pct'] = v; mat['vwap_gap_pct_source'] = 'feature'
    if out.get('ema5_gap_pct') in (None, '', [], {}):
        v = _v1341_src_num(src, of, ('ema5_gap_pct','ema5_distance_pct','ema_5_distance_pct','distance_from_ema5_pct','ema5_gap_pct'))
        if v is not None: out['ema5_gap_pct'] = v; mat['ema5_gap_pct'] = v; mat['ema5_gap_pct_source'] = 'feature'

    mat['missing_fields'] = sorted(set(missing))
    mat['present_fields'] = sorted(k for k in mat.keys() if not k.endswith('_source') and k not in {'schema','owner','captured_ts','recomputed_strategy_gate','missing_fields','present_fields'})
    out['candidate_material_v1341'] = mat
    out['candidate_material_missing_v1341'] = mat['missing_fields']
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['candidate_material_v1341'] = mat
    for k in mat['present_fields']:
        if ctx.get(k) in (None, '', [], {}) and mat.get(k) not in (None, '', [], {}):
            ctx[k] = mat.get(k)
    out['entry_context'] = ctx
    return out

_V1341_PREV_MAKE_ROW = _v510_make_row

def _v510_make_row__v1341_material_capture(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    row = _V1341_PREV_MAKE_ROW(src, of, stage, skey, label, lane, score, reasons, nowv, hard)
    try:
        return _v1341_capture_candidate_materials(row, src if isinstance(src, dict) else {}, of if isinstance(of, dict) else {}, nowv)
    except Exception as exc:
        try: log_error('v1341_candidate_material_capture', exc)
        except Exception: pass
        return row

_v510_make_row = _v510_make_row__v1341_material_capture


# =============================================================================
# v1343 - candidate material capture completion (NO strategy logic change)
# Adds extra aliases for v1180-style materials and a merge-candidate marker.
# Missing values remain source_missing; post-trigger reaction is copied only when
# already measured upstream. No selector/entry/exit threshold changes.
# =============================================================================

def _v1343_mat_put(out: Dict[str, Any], mat: Dict[str, Any], name: str, value: Any, source: str) -> None:
    if value in (None, '', [], {}):
        return
    mat[name] = value
    mat[name + '_source'] = source
    if out.get(name) in (None, '', [], {}):
        out[name] = value


def _v1343_alias_capture(row: Dict[str, Any], src: Dict[str, Any], of: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out = dict(row or {})
    src = src if isinstance(src, dict) else {}
    of = of if isinstance(of, dict) else {}
    mat = out.get('candidate_material_v1341') if isinstance(out.get('candidate_material_v1341'), dict) else {}
    mat = dict(mat)
    mat['schema'] = 'candidate_material_capture_v1343'
    mat['owner'] = 'strategy_worker_transport_only'
    mat['capture_extension_v1343'] = True
    mat['captured_ts_v1343'] = nowv
    mat['recomputed_strategy_gate'] = False

    def need(name: str) -> bool:
        return mat.get(name) in (None, '', [], {}) and out.get(name) in (None, '', [], {})

    # v1180-style short-flow aliases seen across old/current workers.
    if need('change_15m_pct'):
        _v1343_mat_put(out, mat, 'change_15m_pct', _v1341_src_num(src, of, (
            'change_15m_pct','change_15m','price_change_15m','ret_15m','ret_15m_pct','momentum_15m_pct',
            'flow_15m_pct','flow_15m','chg_15m','rate_15m','return_15m_pct','candle_change_15m_pct'
        )), 'scanner/feature')

    # Volume/turnover change aliases. This is transport only; no synthetic zero fallback.
    if need('volume_change_pct'):
        _v1343_mat_put(out, mat, 'volume_change_pct', _v1341_src_num(src, of, (
            'volume_change_pct','volume_delta_pct','vol_change_pct','vol_delta_pct','volume_change_rate_pct',
            'volume_expansion_pct','volume_expansion_rate_pct','vol_expansion_pct','vol_expand_pct','volume_growth_pct'
        )), 'feature/scanner')
    if need('turnover_change_pct'):
        _v1343_mat_put(out, mat, 'turnover_change_pct', _v1341_src_num(src, of, (
            'turnover_change_pct','trade_value_change_pct','quote_volume_change_pct','money_flow_change_pct',
            'turnover_delta_pct','turnover_growth_pct','trade_value_delta_pct','trade_value_growth_pct',
            'acc_trade_price_change_pct','acc_trade_price_delta_pct'
        )), 'scanner/feature')

    # Candle body aliases and OHLC fallback. Keep body_ratio/body_pct both for readers.
    body_v = _v1341_src_num(src, of, ('body_ratio','body_pct','candle_body_pct','real_body_pct','body_percent','real_body_percent'))
    if body_v is None:
        body_v = _v1341_pct_from_ohlc(src, of).get('body_ratio')
    if need('body_ratio'):
        _v1343_mat_put(out, mat, 'body_ratio', body_v, 'candle/feature')
    if body_v not in (None, '', [], {}) and out.get('body_pct') in (None, '', [], {}):
        out['body_pct'] = body_v
        mat['body_pct'] = body_v
        mat['body_pct_source'] = 'candle/feature'

    # Post-trigger reactions remain upstream-owned. Broaden aliases only.
    for base, aliases in {
        'trigger_reaction_1m_pct': ('trigger_reaction_1m_pct','post_trigger_1m_pct','reaction_1m_pct','after_trigger_1m_return_pct','trigger_return_1m_pct','trigger_after_1m_pct','trigger_follow_1m_pct','post_entry_1m_pct'),
        'trigger_reaction_3m_pct': ('trigger_reaction_3m_pct','post_trigger_3m_pct','reaction_3m_pct','after_trigger_3m_return_pct','trigger_return_3m_pct','trigger_after_3m_pct','trigger_follow_3m_pct','post_entry_3m_pct'),
        'trigger_reaction_5m_pct': ('trigger_reaction_5m_pct','post_trigger_5m_pct','reaction_5m_pct','after_trigger_5m_return_pct','trigger_return_5m_pct','trigger_after_5m_pct','trigger_follow_5m_pct','post_entry_5m_pct'),
    }.items():
        if need(base):
            _v1343_mat_put(out, mat, base, _v1341_src_num(src, of, aliases), 'strategy/feature')

    if need('buy_ratio_delta'):
        _v1343_mat_put(out, mat, 'buy_ratio_delta', _v1341_src_num(src, of, (
            'buy_ratio_delta','buy_pressure_delta','buy_trade_ratio_delta','buy_ratio_slope','buy_pressure_slope',
            'buy_ratio_change','buy_trade_ratio_change','buy_trade_ratio_change_pct','taker_buy_ratio_delta','micro_buy_ratio_delta'
        )), 'orderflow/micro')

    # Merge-candidate marker for Main audits. This is read-only evidence, not a gate.
    try:
        buy = _v1341_num_or_none(out.get('buy_trade_ratio'), out.get('buy_ratio'), mat.get('buy_ratio'))
        persist = _v1341_num_or_none(out.get('buy_persistence'), out.get('buy_sustain_1m'), out.get('buy_sustain'), mat.get('buy_sustain_1m'))
        rs = _v1341_num_or_none(out.get('relative_strength'), out.get('relative_strength_score'))
        inv = _v1341_num_or_none(out.get('invalid_distance_pct'), out.get('stop_distance_pct'))
        rr = _v1341_num_or_none(out.get('actual_entry_rr'), out.get('entry_rr'), out.get('rr'))
        cap_hint = 0
        if buy is not None and buy >= 0.70: cap_hint += 1
        if persist is not None and persist >= 0.45: cap_hint += 1
        if rs is not None and rs > 0: cap_hint += 1
        if inv is not None and inv >= 3.0: cap_hint += 1
        if rr is not None and rr > 10 and (buy is None or buy < 0.50): cap_hint -= 1
        mat['merge_candidate_hint_v1343'] = 'cap_rank_priority' if cap_hint >= 3 else ('recheck' if cap_hint >= 1 else 'observe')
        mat['merge_candidate_hint_score_v1343'] = cap_hint
    except Exception:
        pass

    present = sorted(k for k in mat.keys() if not k.endswith('_source') and k not in {'schema','owner','captured_ts','captured_ts_v1343','recomputed_strategy_gate','missing_fields','present_fields'})
    required = ['change_1m_pct','change_3m_pct','change_5m_pct','change_15m_pct','turnover_24h','turnover_change_pct','volume_ratio','volume_change_pct','upper_wick_pct','lower_wick_pct','body_ratio','trigger_reaction_1m_pct','trigger_reaction_3m_pct','trigger_reaction_5m_pct','buy_ratio_delta','spread_delta_pct','market_state']
    mat['present_fields'] = present
    mat['missing_fields'] = sorted(k for k in required if mat.get(k) in (None, '', [], {}) and out.get(k) in (None, '', [], {}))
    out['candidate_material_v1341'] = mat
    out['candidate_material_missing_v1341'] = mat['missing_fields']
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['candidate_material_v1341'] = mat
    for k in mat.get('present_fields', []):
        if ctx.get(k) in (None, '', [], {}) and mat.get(k) not in (None, '', [], {}):
            ctx[k] = mat.get(k)
    out['entry_context'] = ctx
    return out


# =============================================================================
# v1344 - old keep/recheck/observe grade annotation (transport only in Strategy)
# Paper owns actual selector consumption. Strategy only seals the evidence onto rows.
# =============================================================================
def _v1344_num_or_none(*vals: Any) -> Optional[float]:
    for v in vals:
        try:
            if v in (None, '', [], {}):
                continue
            return float(str(v).replace(',', '').replace('%', ''))
        except Exception:
            continue
    return None

def _v1344_old_grade(out: Dict[str, Any]) -> Tuple[str, int, List[str]]:
    mat = out.get('candidate_material_v1341') if isinstance(out.get('candidate_material_v1341'), dict) else {}
    buy = _v1344_num_or_none(out.get('buy_trade_ratio'), out.get('buy_ratio'), mat.get('buy_ratio'))
    persist = _v1344_num_or_none(out.get('buy_persistence'), out.get('buy_persist'), out.get('buy_sustain'), out.get('buy_sustain_1m'), mat.get('buy_sustain_1m'))
    invd = _v1344_num_or_none(out.get('invalid_distance_pct'), out.get('stop_distance_pct'), out.get('loss_distance_pct'), out.get('invalid_pct'))
    rr = _v1344_num_or_none(out.get('actual_entry_rr'), out.get('actual_rr'), out.get('entry_rr'), out.get('risk_reward'), out.get('rr'), out.get('sealed_rr'))
    vwap = _v1344_num_or_none(out.get('vwap_distance_pct'), out.get('vwap_dist_pct'), out.get('distance_from_vwap_pct'), out.get('vwap_gap_pct'))
    ema = _v1344_num_or_none(out.get('ema5_distance_pct'), out.get('ema_5_distance_pct'), out.get('distance_from_ema5_pct'), out.get('ema5_gap_pct'))
    rs = _v1344_num_or_none(out.get('relative_strength'), out.get('rel_strength'), out.get('rs_score'), out.get('market_relative_strength'))
    spread = _v1344_num_or_none(out.get('spread_pct'), out.get('entry_spread_pct'), out.get('best_spread_pct'), out.get('micro_spread_pct'))
    slip = _v1344_num_or_none(out.get('slippage_pct'), out.get('entry_slippage_pct'), out.get('expected_slippage_pct'))
    risk = 0; tags: List[str] = []
    if buy is None:
        risk += 1; tags.append('매수체결없음')
    elif buy < 0.25:
        risk += 3; tags.append('매수극약')
    elif buy < 0.45:
        risk += 1; tags.append('매수주의')
    if persist is None:
        risk += 1; tags.append('지속없음')
    elif persist < 0.25:
        risk += 2; tags.append('지속약함')
    elif persist < 0.40:
        risk += 1; tags.append('지속주의')
    if rr is not None and rr >= 8 and (buy is None or buy < 0.50):
        risk += 3; tags.append('RR높음+매수약함')
    if rr is not None and rr >= 8 and invd is not None and invd < 2.5:
        risk += 2; tags.append('RR높음+invalid좁음')
    if invd is not None and invd < 1.5:
        risk += 2; tags.append('invalid극좁음')
    if rs is not None and rs < 0:
        risk += 1; tags.append('상대강도음수')
    if spread is not None and spread > 0.80:
        risk += 1; tags.append('spread큼')
    if slip is not None and slip > 0.30:
        risk += 1; tags.append('slippage주의')
    if vwap is not None and vwap < 0:
        risk += 1; tags.append('VWAP아래')
    if ema is not None and ema < 0:
        risk += 1; tags.append('EMA아래')
    if risk <= 1:
        return 'old_proxy_keep', risk, tags
    if risk <= 3:
        return 'old_proxy_recheck', risk, tags
    return 'old_proxy_observe', risk, tags

def _v1344_attach_old_grade(out: Dict[str, Any]) -> Dict[str, Any]:
    try:
        label, risk, tags = _v1344_old_grade(out)
        out['old_keep_recheck_grade_v1344'] = label
        out['old_keep_recheck_risk_v1344'] = risk
        out['old_keep_recheck_tags_v1344'] = tags
        out['paper_selector_grade_v1344'] = label
        mat = out.get('candidate_material_v1341') if isinstance(out.get('candidate_material_v1341'), dict) else {}
        mat = dict(mat)
        mat['old_keep_recheck_grade_v1344'] = label
        mat['old_keep_recheck_risk_v1344'] = risk
        mat['old_keep_recheck_tags_v1344'] = tags
        mat['selector_connection_v1344'] = 'paper_selector_consumes_grade_keep_recheck_observe'
        out['candidate_material_v1341'] = mat
    except Exception:
        pass
    return out

_V1343_PREV_MAKE_ROW = _v510_make_row

def _v510_make_row__v1343_material_capture(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    row = _V1343_PREV_MAKE_ROW(src, of, stage, skey, label, lane, score, reasons, nowv, hard)
    try:
        return _v1344_attach_old_grade(_v1343_alias_capture(row, src if isinstance(src, dict) else {}, of if isinstance(of, dict) else {}, nowv))
    except Exception as exc:
        try: log_error('v1343_candidate_material_capture_completion', exc)
        except Exception: pass
        return row

_v510_make_row = _v510_make_row__v1343_material_capture



# =============================================================================
# v1345 - material fill state cache (NO strategy/entry/exit change)
# Fills missing v1180-style materials from actual observed snapshots only.
# - No zero fallback.
# - 15m/volume/turnover/buy/spread deltas require prior same-ticker observation.
# - Trigger reaction is copied only when trigger price + elapsed window exist.
# - Old observe hard exclusion is intentionally NOT decided in Strategy.
# =============================================================================
MATERIAL_STATE_V1345 = BASE_DIR / 'clean_candidate_material_state_v1345.json'


def _v1345_ticker(row: Dict[str, Any], src: Dict[str, Any]) -> str:
    try:
        return str(row.get('ticker') or row.get('market') or row.get('symbol') or src.get('ticker') or src.get('market') or src.get('symbol') or '').upper().strip()
    except Exception:
        return ''


def _v1345_pick_num(row: Dict[str, Any], src: Dict[str, Any], of: Dict[str, Any], *keys: str) -> Optional[float]:
    vals=[]
    mats=[]
    for d in (row, src, of):
        if isinstance(d, dict):
            mats.append(d)
    cm = row.get('candidate_material_v1341') if isinstance(row.get('candidate_material_v1341'), dict) else {}
    if cm: mats.append(cm)
    ec = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    if ec: mats.append(ec)
    for k in keys:
        for d in mats:
            if d.get(k) not in (None, '', [], {}):
                vals.append(d.get(k))
    return _v1341_num_or_none(*vals)


def _v1345_state_load() -> Dict[str, Any]:
    st = load_json(MATERIAL_STATE_V1345, {}) or {}
    return st if isinstance(st, dict) else {}


def _v1345_state_save(st: Dict[str, Any]) -> None:
    try:
        # regenerable runtime evidence only; keep small
        if len(st) > 800:
            items = sorted(st.items(), key=lambda kv: float((kv[1] or {}).get('ts') or 0.0), reverse=True)[:800]
            st = dict(items)
        save_runtime_json(MATERIAL_STATE_V1345, {'schema':'candidate_material_state_v1345','updated_ts':now_ts(),'records':st}, owner='candidate_material_state_v1345')
    except Exception as exc:
        try: log_error('v1345_material_state_save', exc)
        except Exception: pass


def _v1345_delta(cur: Optional[float], prev: Optional[float]) -> Optional[float]:
    try:
        if cur is None or prev is None or abs(float(prev)) <= 1e-12:
            return None
        return (float(cur)-float(prev))/abs(float(prev))*100.0
    except Exception:
        return None


def _v1345_observed_material_fill(row: Dict[str, Any], src: Dict[str, Any], of: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out = dict(row or {})
    src = src if isinstance(src, dict) else {}
    of = of if isinstance(of, dict) else {}
    mat = out.get('candidate_material_v1341') if isinstance(out.get('candidate_material_v1341'), dict) else {}
    mat = dict(mat)
    mat['schema'] = 'candidate_material_capture_v1345'
    mat['capture_extension_v1345'] = True
    mat['owner_v1345'] = 'strategy_worker_observed_snapshot_delta'
    mat['recomputed_strategy_gate'] = False
    ticker = _v1345_ticker(out, src)
    price = _v1345_pick_num(out, src, of, 'current_price','trade_price','price','close','close_price','entry_price','last_price')
    volume = _v1345_pick_num(out, src, of, 'volume','candle_volume','acc_trade_volume','trade_volume','volume_24h','base_volume_24h')
    turnover = _v1345_pick_num(out, src, of, 'turnover_24h','trade_value_24h','acc_trade_price_24h','quote_volume_24h','turnover','money_flow')
    buy = _v1345_pick_num(out, src, of, 'buy_trade_ratio','buy_ratio','buy_taker_ratio','bid_buy_ratio','taker_buy_ratio')
    spread = _v1345_pick_num(out, src, of, 'spread_pct','entry_spread_pct','best_spread_pct','micro_spread_pct','orderbook_spread_pct')

    # read prior state; supports both raw records dict and wrapper object
    state_obj = _v1345_state_load()
    records = state_obj.get('records') if isinstance(state_obj.get('records'), dict) else state_obj
    records = records if isinstance(records, dict) else {}
    prev = records.get(ticker) if ticker and isinstance(records.get(ticker), dict) else {}
    pts = float(prev.get('ts') or 0.0) if isinstance(prev, dict) else 0.0
    age = max(0.0, float(nowv)-pts) if pts > 0 else None

    def put(name: str, value: Any, source: str) -> None:
        if value in (None, '', [], {}):
            return
        mat[name] = value
        mat[name + '_source'] = source
        if out.get(name) in (None, '', [], {}):
            out[name] = value

    # 15m flow from same-ticker state if prior observation is old enough.
    if mat.get('change_15m_pct') in (None, '', [], {}) and out.get('change_15m_pct') in (None, '', [], {}) and age is not None and age >= 600 and price is not None:
        put('change_15m_pct', _v1345_delta(price, _v1341_num_or_none(prev.get('price'))), 'strategy_observed_state_15m_v1345')
        if mat.get('change_15m_pct') not in (None, '', [], {}):
            mat['material_flow_15m_pct_v1345'] = mat.get('change_15m_pct')
    # delta fields from prior same-ticker observation. Window is recorded for audit.
    if age is not None:
        mat['material_delta_window_sec_v1345'] = age
        if mat.get('volume_change_pct') in (None, '', [], {}) and out.get('volume_change_pct') in (None, '', [], {}) and volume is not None:
            put('volume_change_pct', _v1345_delta(volume, _v1341_num_or_none(prev.get('volume'))), 'strategy_observed_state_delta_v1345')
            if mat.get('volume_change_pct') not in (None, '', [], {}): mat['material_volume_change_pct_v1345'] = mat.get('volume_change_pct')
        if mat.get('turnover_change_pct') in (None, '', [], {}) and out.get('turnover_change_pct') in (None, '', [], {}) and turnover is not None:
            put('turnover_change_pct', _v1345_delta(turnover, _v1341_num_or_none(prev.get('turnover'))), 'strategy_observed_state_delta_v1345')
            if mat.get('turnover_change_pct') not in (None, '', [], {}): mat['material_turnover_change_pct_v1345'] = mat.get('turnover_change_pct')
        if mat.get('buy_ratio_delta') in (None, '', [], {}) and out.get('buy_ratio_delta') in (None, '', [], {}) and buy is not None:
            put('buy_ratio_delta', float(buy)-float(_v1341_num_or_none(prev.get('buy')) or buy), 'strategy_observed_state_delta_v1345')
            if mat.get('buy_ratio_delta') not in (None, '', [], {}): mat['material_buy_ratio_delta_v1345'] = mat.get('buy_ratio_delta')
        if mat.get('spread_delta_pct') in (None, '', [], {}) and out.get('spread_delta_pct') in (None, '', [], {}) and spread is not None:
            put('spread_delta_pct', float(spread)-float(_v1341_num_or_none(prev.get('spread')) or spread), 'strategy_observed_state_delta_v1345')
    # Body fallback from OHLC aliases, still actual candle-derived only.
    if mat.get('body_ratio') in (None, '', [], {}) and out.get('body_ratio') in (None, '', [], {}):
        body = _v1341_pct_from_ohlc(src, of).get('body_ratio')
        put('body_ratio', body, 'candle_ohlc_v1345')
        if body not in (None, '', [], {}): mat['material_body_ratio_v1345'] = body
    # Trigger reaction only if trigger price and enough elapsed time are already observable.
    trig_price = _v1345_pick_num(out, src, of, 'trigger_price','trigger_px','signal_price','triggered_price','entry_trigger_price')
    trig_ts = _v1345_pick_num(out, src, of, 'trigger_ts','trigger_time_ts','signal_ts','triggered_ts','triggered_at_ts')
    if trig_price is not None and price is not None and trig_ts is not None:
        elapsed = max(0.0, float(nowv)-float(trig_ts))
        mat['trigger_elapsed_sec_v1345'] = elapsed
        reaction = _v1345_delta(price, trig_price)
        if elapsed >= 60 and mat.get('trigger_reaction_1m_pct') in (None, '', [], {}):
            put('trigger_reaction_1m_pct', reaction, 'strategy_observed_trigger_elapsed_v1345')
            mat['material_trigger_reaction_1m_pct_v1345'] = reaction
        if elapsed >= 180 and mat.get('trigger_reaction_3m_pct') in (None, '', [], {}):
            put('trigger_reaction_3m_pct', reaction, 'strategy_observed_trigger_elapsed_v1345')
            mat['material_trigger_reaction_3m_pct_v1345'] = reaction
        if elapsed >= 300 and mat.get('trigger_reaction_5m_pct') in (None, '', [], {}):
            put('trigger_reaction_5m_pct', reaction, 'strategy_observed_trigger_elapsed_v1345')
            mat['material_trigger_reaction_5m_pct_v1345'] = reaction

    # update state after derivation
    if ticker:
        rec = {'ts': float(nowv)}
        if price is not None: rec['price'] = price
        if volume is not None: rec['volume'] = volume
        if turnover is not None: rec['turnover'] = turnover
        if buy is not None: rec['buy'] = buy
        if spread is not None: rec['spread'] = spread
        records[ticker] = rec
        _v1345_state_save(records)

    required = ['change_1m_pct','change_3m_pct','change_5m_pct','change_15m_pct','turnover_24h','turnover_change_pct','volume_ratio','volume_change_pct','upper_wick_pct','lower_wick_pct','body_ratio','trigger_reaction_1m_pct','trigger_reaction_3m_pct','trigger_reaction_5m_pct','buy_ratio_delta','spread_delta_pct','market_state']
    present = sorted(k for k in mat.keys() if not k.endswith('_source') and k not in {'schema','owner','owner_v1345','captured_ts','captured_ts_v1343','recomputed_strategy_gate','missing_fields','present_fields'})
    mat['present_fields'] = present
    mat['missing_fields'] = sorted(k for k in required if mat.get(k) in (None, '', [], {}) and out.get(k) in (None, '', [], {}))
    out['candidate_material_v1341'] = mat
    out['candidate_material_missing_v1341'] = mat['missing_fields']
    ctx = out.get('entry_context') if isinstance(out.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['candidate_material_v1341'] = mat
    for k in mat.get('present_fields', []):
        if ctx.get(k) in (None, '', [], {}) and mat.get(k) not in (None, '', [], {}):
            ctx[k] = mat.get(k)
    out['entry_context'] = ctx
    return out

# wrap current v1343/v1344 row maker one more time
_V1345_PREV_MAKE_ROW = _v510_make_row

def _v510_make_row__v1345_material_fill(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    row = _V1345_PREV_MAKE_ROW(src, of, stage, skey, label, lane, score, reasons, nowv, hard)
    try:
        return _v1345_observed_material_fill(row, src if isinstance(src, dict) else {}, of if isinstance(of, dict) else {}, nowv)
    except Exception as exc:
        try: log_error('v1345_candidate_material_fill', exc)
        except Exception: pass
        return row

_v510_make_row = _v510_make_row__v1345_material_fill

VERSION = 'strategy_worker_v1.087'
BUILD_LABEL = 'v1347_overlay_registration_order_fix_2026-07-08'

# v1190 read-only phase timing evidence
from runtime_phase_probe_v1190 import wrap_function as _v1190_wrap_function
_v1190_wrap_function(
    globals(), "run_once", "strategy", "cycle", VERSION, 300.0,
    profile_enabled=(os.getenv("COINBOT_STRATEGY_DEEP_CPROFILE", "").strip() == "1"),
)

# =============================================================================
# v1346 - owner cache overlay material fill (NO threshold/entry/exit change)
# Root fix: v1345 tried to infer missing materials after row creation. The real
# owner values live in feature/scanner/orderflow caches and were not copied into
# publish rows/candidate_material. This wrapper copies actual owner fields at
# publish overlay time, then refreshes candidate_material missing_fields.
# =============================================================================
try:
    _V1346_PREV_OVERLAY_INPUTS = _v908_overlay_candidate_inputs
except Exception:
    _V1346_PREV_OVERLAY_INPUTS = None

_V1346_OWNER_MATERIAL_ALIASES = {
    'change_15m_pct': ('change_15m_pct','change_15m','price_change_15m','ret_15m','ret_15m_pct','momentum_15m_pct','flow_15m_pct','flow_15m','chg_15m','rate_15m','return_15m_pct'),
    'volume_change_pct': ('volume_change_pct','volume_delta_pct','vol_change_pct','vol_delta_pct','volume_change_rate_pct','volume_expansion_pct','volume_expansion_rate_pct','vol_expansion_pct','vol_expand_pct','volume_growth_pct'),
    'turnover_change_pct': ('turnover_change_pct','trade_value_change_pct','quote_volume_change_pct','money_flow_change_pct','turnover_delta_pct','turnover_growth_pct','trade_value_delta_pct','trade_value_growth_pct','acc_trade_price_change_pct','acc_trade_price_delta_pct'),
    'body_ratio': ('body_ratio','body_pct','candle_body_pct','real_body_pct','body_percent','real_body_percent'),
    'buy_ratio_delta': ('buy_ratio_delta','buy_pressure_delta','buy_trade_ratio_delta','buy_ratio_slope','buy_pressure_slope','buy_ratio_change','buy_trade_ratio_change','buy_trade_ratio_change_pct','taker_buy_ratio_delta','micro_buy_ratio_delta'),
    'spread_delta_pct': ('spread_delta_pct','spread_change_pct','micro_spread_delta_pct','orderbook_spread_delta_pct','spread_slope','spread_change'),
}
_V1346_REQUIRED_MATERIALS = ['change_1m_pct','change_3m_pct','change_5m_pct','change_15m_pct','turnover_24h','turnover_change_pct','volume_ratio','volume_change_pct','upper_wick_pct','lower_wick_pct','body_ratio','trigger_reaction_1m_pct','trigger_reaction_3m_pct','trigger_reaction_5m_pct','buy_ratio_delta','spread_delta_pct','market_state']

def _v1346_present(v: Any) -> bool:
    try:
        return v not in (None, '', [], {}) and not (isinstance(v, str) and v.strip() in ('-', 'None', 'none', 'null', 'nan'))
    except Exception:
        return False

def _v1346_first_num_from_dicts(dicts: List[Dict[str, Any]], aliases: Tuple[str, ...]) -> Tuple[Any, str]:
    for dname, d in dicts:
        if not isinstance(d, dict):
            continue
        for k in aliases:
            if _v1346_present(d.get(k)):
                try:
                    return float(str(d.get(k)).replace(',', '').replace('%', '')), f'{dname}.{k}'
                except Exception:
                    return d.get(k), f'{dname}.{k}'
    return None, ''

def _v1346_body_from_row(row: Dict[str, Any]) -> Any:
    try:
        op = _v1341_num_or_none(row.get('open'), row.get('open_price'), row.get('candle_open'))
        hi = _v1341_num_or_none(row.get('high'), row.get('high_price'), row.get('candle_high'))
        lo = _v1341_num_or_none(row.get('low'), row.get('low_price'), row.get('candle_low'))
        cl = _v1341_num_or_none(row.get('close'), row.get('close_price'), row.get('trade_price'), row.get('current_price'), row.get('price'))
        if op and hi and lo and cl and min(op, hi, lo, cl) > 0:
            return abs(float(cl)-float(op))/float(cl)*100.0
    except Exception:
        return None
    return None

def _v1346_refresh_material(row: Dict[str, Any], source_hits: Dict[str, str]) -> Dict[str, Any]:
    mat = row.get('candidate_material_v1341') if isinstance(row.get('candidate_material_v1341'), dict) else {}
    mat = dict(mat)
    mat['schema'] = 'candidate_material_capture_v1346'
    mat['capture_extension_v1346'] = True
    mat['owner_v1346'] = 'strategy_publish_owner_cache_overlay'
    mat['source_hits_v1346'] = dict(source_hits)
    for k, src in source_hits.items():
        if _v1346_present(row.get(k)) and not _v1346_present(mat.get(k)):
            mat[k] = row.get(k)
            mat[k + '_source'] = src
    present = sorted(k for k in mat.keys() if not k.endswith('_source') and k not in {'schema','owner','owner_v1345','owner_v1346','captured_ts','captured_ts_v1343','recomputed_strategy_gate','missing_fields','present_fields'})
    mat['present_fields'] = present
    mat['missing_fields'] = sorted(k for k in _V1346_REQUIRED_MATERIALS if not _v1346_present(mat.get(k)) and not _v1346_present(row.get(k)))
    row['candidate_material_v1341'] = mat
    row['candidate_material_missing_v1341'] = mat['missing_fields']
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['candidate_material_v1341'] = mat
    for k in present:
        if _v1346_present(mat.get(k)) and not _v1346_present(ctx.get(k)):
            ctx[k] = mat.get(k)
    row['entry_context'] = ctx
    return row

def _v908_overlay_candidate_inputs__v1346(row: Dict[str, Any], maps: Dict[str, Dict[str, Dict[str, Any]]], cache_summary: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    try:
        base = _V1346_PREV_OVERLAY_INPUTS(row, maps, cache_summary) if _V1346_PREV_OVERLAY_INPUTS else dict(row or {})
    except Exception:
        base = dict(row or {})
    try:
        t = ticker_norm(base.get('ticker') or base.get('market') or base.get('symbol'))
        feat = (maps.get('feature', {}) or {}).get(t, {}) if t else {}
        hot = (maps.get('scanner_hot', {}) or {}).get(t, {}) if t else {}
        of = (maps.get('orderflow', {}) or {}).get(t, {}) if t else {}
        micro = (maps.get('micro', {}) or {}).get(t, {}) if t else {}
        dicts = [('row', base), ('feature', feat), ('scanner_hot', hot), ('orderflow', of), ('micro', micro)]
        hits: Dict[str, str] = {}
        for key, aliases in _V1346_OWNER_MATERIAL_ALIASES.items():
            if _v1346_present(base.get(key)):
                continue
            val, src = _v1346_first_num_from_dicts(dicts, aliases)
            if _v1346_present(val):
                base[key] = val
                base[key + '_source_v1346'] = src
                hits[key] = src
        if not _v1346_present(base.get('body_ratio')):
            body = _v1346_body_from_row(base)
            if _v1346_present(body):
                base['body_ratio'] = body
                base['body_ratio_source_v1346'] = 'row_ohlc'
                hits['body_ratio'] = 'row_ohlc'
        base['candidate_material_owner_overlay_v1346'] = {'schema':'owner_overlay_material_v1346','ticker':t,'hits':hits,'feature_keys_sample':sorted(list(feat.keys()))[:40] if isinstance(feat, dict) else [],'scanner_hot_keys_sample':sorted(list(hot.keys()))[:40] if isinstance(hot, dict) else [],'orderflow_keys_sample':sorted(list(of.keys()))[:40] if isinstance(of, dict) else [],'policy':'copy actual owner cache values only; no zero fallback; no gate/selector/exit threshold change'}
        base = _v1346_refresh_material(base, hits)
    except Exception as exc:
        try: log_error('v1346_owner_material_overlay', exc)
        except Exception: pass
    return base

_v908_overlay_candidate_inputs = _v908_overlay_candidate_inputs__v1346

VERSION = 'strategy_worker_v1.087'
BUILD_LABEL = 'v1347_overlay_registration_order_fix_2026-07-08'
MAIN_DEPLOY_VERSION = BUILD_LABEL

if __name__ == "__main__":
    import atexit
    _acquire_strategy_singleton_v1182()
    atexit.register(_release_strategy_singleton_v1182)
    main()

