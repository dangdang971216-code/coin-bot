v1415 targeted: paper_bot + strategy_worker path-state debounce, micro identity refresh only. No guard/main/disk/trading-rule changes. 자동매수 OFF.
