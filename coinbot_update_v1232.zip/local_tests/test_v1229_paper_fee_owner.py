#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def main() -> None:
    paper = load('paper_v1229_fee', PACKAGE_ROOT / 'paper_bot_v1.065.py')
    paper.load_control = lambda: {'fee_pct_roundtrip': 0.12}
    paper.load_json = lambda _path, default=None: default if default is not None else {}
    paper._v1206_active_epoch = lambda: {}
    paper._v1204_read_control = lambda: {}
    paper._v1205_reset_thread_alive = lambda: False
    paper._v1206_ranked_active = lambda: False
    payload = paper._v1208_active_contract_payload({})
    assert payload['cost']['owner'] == 'paper_bot.load_control'
    assert payload['cost']['configured_roundtrip_fee_pct'] == 0.12
    assert payload['cost']['complete'] is True

    strategy = load('strategy_v1229_fee', PACKAGE_ROOT / 'strategy_worker_v1.058.py')
    with tempfile.TemporaryDirectory() as td:
        path = pathlib.Path(td) / 'paper_active_contract_snapshot_v1208.json'
        path.write_text(json.dumps({'snapshot_id': 'fee-snap', 'cost': payload['cost']}), encoding='utf-8')
        strategy.PAPER_ACTIVE_CONTRACT_V1229 = path
        strategy._RUNTIME_JSON_IDENTITY_CACHE.clear()
        fee = strategy._v1229_paper_fee_owner()
        assert fee['fee_pct'] == 0.12
        assert fee['complete'] is True
        assert fee['snapshot_id'] == 'fee-snap'
        assert fee['source'].startswith('paper_active_contract_snapshot_v1208')

        path.write_text(json.dumps({'snapshot_id': 'missing', 'cost': {}}), encoding='utf-8')
        strategy._RUNTIME_JSON_IDENTITY_CACHE.clear()
        missing = strategy._v1229_paper_fee_owner()
        assert missing['fee_pct'] is None
        assert missing['complete'] is False
        assert missing['source'] == 'SOURCE_MISSING'

    assert paper.VERSION == 'paper_bot_v1.065'
    assert strategy.VERSION == 'strategy_worker_v1.058'
    print('PASS v1229 Paper-owned fee snapshot, Strategy exact reader, missing is not zero')

if __name__ == '__main__':
    main()
