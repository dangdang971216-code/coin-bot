import ast
import hashlib
import importlib.util
import json
import os
import pathlib
import py_compile
import shutil
import tempfile

ROOT=pathlib.Path(__file__).resolve().parent
REVIEW=ROOT/'review_worker_v2.162.py'
MAIN=ROOT/'coinbot_main_v2_13_2238.py'
for path in (REVIEW,MAIN):
    py_compile.compile(str(path),doraise=True)
    ast.parse(path.read_text(encoding='utf-8'))


def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

base=pathlib.Path(tempfile.mkdtemp(prefix='review_v2393_'))
os.environ['TRADING_BOT_DIR']=str(base)
(base/'runtime').mkdir(parents=True,exist_ok=True)
review=load('review_v2393',REVIEW)


def material(value):
    return {'state':'READY','source_state':'READY','value_state':'READY','value':value}

review._EVENTS.clear(); review._OUTCOMES.clear(); review._OUTCOME_ROWS.clear()
groups=('UP_UP','UP_DOWN','DOWN_UP','DOWN_DOWN')
for horizon in ('3h','6h'):
    for group in groups:
        for index in range(12):
            event_key=f'{horizon}:{group}:{index}'
            false_positive=(group=='UP_DOWN')
            missed=(group=='DOWN_UP')
            values={
                'return_30m_atr_adjusted':0.2,
                'price_acceleration_30m':0.1,
                'price_acceleration_1h':3.0 if false_positive else 1.0,
                'relative_strength_1h':0.3,
                'relative_strength_acceleration_1h':0.2,
                'turnover_growth_recent1h_vs_prior3h':10.0,
                'turnover_acceleration_30m':12.0,
                'higher_low_strength_atr':0.4,
                'pullback_recovery_ratio':0.8 if missed else 0.2,
                'btc_price_acceleration_1h':0.1,
                'market_breadth_change':1.0,
                'market_liquidity_state':{'risk_state':'RISK_ON' if false_positive else 'NEUTRAL','context_state':'BULL' if false_positive else 'SIDEWAYS'},
            }
            review._EVENTS[event_key]={
                'event_key':event_key,
                'episode_id':event_key,
                'prediction_contract_id':'PRE_STRUCTURE_12',
                'material_names':list(review.MATERIAL_NAMES),
                'prediction_first':True,
                'target_path_used_by_primary_prediction':False,
                'materials':{name:material(value) for name,value in values.items()},
                'explanation_tags':['CHASE'] if false_positive else ['BEGINNING'],
                'price_volume_sequence':{'state':'PRICE_LEADS' if missed else 'VOLUME_LEADS'},
            }
            review._OUTCOME_ROWS[(event_key,horizon)]={
                'event_key':event_key,'horizon':horizon,'outcome_state':'READY',
                'directional_score_group':group,
            }

comp=review.build_directional_material_comparison()
for horizon in ('3h','6h'):
    block=comp['horizons'][horizon]
    assert block['resolved_count']==48
    assert block['overall_accuracy_pct']==50.0
    assert block['up_prediction_precision_pct']==50.0
    assert block['missed_rise_rate_pct']==50.0
    assert block['top_false_positive_materials'][0]['material'] in {'price_acceleration_1h','market_liquidity_state'}
    assert block['top_missed_rise_materials'][0]['material']=='pullback_recovery_ratio'
assert comp['analysis_only'] is True
assert comp['weights_changed'] is False and comp['thresholds_changed'] is False

# run_once publishes the read-only comparison in canonical even with an empty runtime.
review._STATE_LOADED=True
review._EVENTS.clear(); review._OUTCOMES.clear(); review._OUTCOME_ROWS.clear()
(base/'runtime'/'current_candidate_snapshot_v2176.json').write_text('{}',encoding='utf-8')
status=review.run_once()
canonical=status.get('rise_prediction_canonical') or {}
assert 'directional_material_comparison' in canonical
assert canonical['directional_material_comparison']['analysis_only'] is True

# Main places accuracy first and exposes the two failure comparisons.
main_base=pathlib.Path(tempfile.mkdtemp(prefix='main_v2393_'))
main_copy=main_base/MAIN.name
shutil.copy2(MAIN,main_copy)
main=load('main_v2393',main_copy)
lines=main._prediction_review_split_lines({
    'live_prediction_model_id':'model-test',
    'current_prediction_contract_directional_scoring':{'resolved_counts':{'3h':48,'6h':48}},
    'directional_material_comparison':comp,
})
text='\n'.join(lines)
assert text.startswith('[정확도 핵심]')
assert '3h: 전체 50.0% · 상승선별 50.0%' in text
assert '3h 잘못 상승 1:' in text
assert '3h 놓친 상승 1: 눌림 회복률' in text
assert '예측식·가중치·기준 변경 0' in text

assert "VERSION = 'review_worker_v2.162'" in REVIEW.read_text(encoding='utf-8')
assert "BUILD_LABEL = 'directional_accuracy_material_compare_2026-08-02'" in REVIEW.read_text(encoding='utf-8')
assert "MAIN_VERSION='수익형 v2.13.2238'" in MAIN.read_text(encoding='utf-8')
assert "BUILD='prediction_accuracy_material_diagnosis_2026-08-02'" in MAIN.read_text(encoding='utf-8')


# Preserve v2392 Main Paper/Candle reader behavior.
main.BASE_DIR=main_base
paper={
  'version':'paper_bot_v2.142','build':'paper-build','running':True,
  'telegram_command':{'state':'READY'},
  'clean_v2_status':{
    'performance':{'open_count':3,'closed_count':4},
    'last_nonzero_s1_attempt_v2158':{
      'paper_processed_candidate_commit_id_v2176':'commit-v2393',
      'paper_processed_s1_generation_id_v2176':'generation-v2393',
      'strategy_s1_received_v2158':2,
      's1_terminal_accounted_v2158':2,
      'enrolled':1,
      's1_terminal_counts_v2158':{'OPENED':1,'EXECUTION_WAIT':1},
      's1_terminal_rows_v2158':[
        {'ticker':'AAA','terminal':'OPENED','reasons':[]},
        {'ticker':'BBB','terminal':'EXECUTION_WAIT','reasons':['TTL_WAIT']},
      ],
    },
  },
}
(main_base/'paper_bot_status.json').write_text(json.dumps(paper,ensure_ascii=False),encoding='utf-8')
read=main.read_paper_status()
assert read['paper_status_owner']=='paper_bot_status.json:clean_v2_status'
truth={'commit':'commit-v2393','generation':'generation-v2393','receipt_count':2,'paper_match':True}
s1=main._current_paper_s1_truth(truth)
assert s1['state']=='PASS' and s1['received']==2 and s1['accounted']==2

import time
now=time.time()
candle={
  'version':'candle_worker_v2.031','updated_ts':now,
  'collection_proof':{
    'proof_updated_ts':now,'runtime_version':'candle_worker_v2.031',
    'selected_count':422,'ticker_full_success':420,'ticker_partial_success':0,'ticker_no_success':2,
    'thread_exception_count':0,
    'planned_due_frame_count_v2389':146,'planned_due_attempted_count_v2389':146,
    'planned_due_unattempted_count_v2389':0,
    'failure_samples':[{'ticker':'ES','failed':['m30','h1']}],
  },
}
(main_base/'clean_candle_status.json').write_text(json.dumps(candle,ensure_ascii=False),encoding='utf-8')
current=main.read_candle_collection_truth()
assert current['state']=='PASS' and current['unattempted']==0

# Review ERROR remains visible as FAIL.
(main_base/'clean_review_worker_status.json').write_text(
    json.dumps({'state':'ERROR','error':'SyntheticReviewError'},ensure_ascii=False),encoding='utf-8'
)
review_text=main.render_trade_review()
assert '상태 FAIL' in review_text and 'SyntheticReviewError' in review_text

# Unchanged runtime components remain byte-identical to v2392.
expected_hashes={
    'strategy_v2_core.py':'522b35ec31bd906586cfc66b7e257fff907022450cdfaf291af40cc9ed24a56b',
    'strategy_worker.py':'2acbe938e845568ddae3d773ee38c8d3aa6d8e82fb8bef044ac84b42dea4f28c',
    'candle_worker.py':'c0ca901e9ba095df6bce3e2b61921583fbee88f64db7f829d1c2b36652629793',
    'paper_bot.py':'c4e48908e030953cd3e55ea83094a328206411e0561d8a88725b72a29637ed3f',
    'backga_guard_bot.py':'6a67159b9c1297f6ea56a61806b29bdb32ba470700bbbac765de3adf0608bcf3',
}
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8')) if (ROOT/'DEPLOY_BUNDLE.json').exists() else {}
changed=set(manifest.get('changed_files') or [])|set((manifest.get('aliases') or {}).keys())
for name,expected in expected_hashes.items():
    path=ROOT/name
    if path.exists():
        assert hashlib.sha256(path.read_bytes()).hexdigest()==expected
    else:
        assert name not in changed

print(json.dumps({
    'compile_ast':'PASS',
    'four_group_material_compare':'PASS',
    'accuracy_primary_display':'PASS',
    'false_positive_top':comp['horizons']['3h']['top_false_positive_materials'][0]['material'],
    'missed_rise_top':comp['horizons']['3h']['top_missed_rise_materials'][0]['material'],
    'canonical_publish':'PASS',
    'paper_terminal_reader_regression':'PASS',
    'candle_collection_reader_regression':'PASS',
    'review_error_truth_regression':'PASS',
    'unchanged_component_hashes':'PASS',
    'prediction_formula_changed':False,
    'weights_changed':False,
    'thresholds_changed':False,
    'auto_buy':False,
},ensure_ascii=False))
