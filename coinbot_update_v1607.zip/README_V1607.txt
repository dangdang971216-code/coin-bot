v1607 packaging fix for v1606 candidate-preserve recheck. No trading thresholds changed. Auto-buy OFF. Apply with /gupgrade_bundle, then verify main /candidate_recheck.
