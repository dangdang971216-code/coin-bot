v940 paper 실행 path·시간 spine 정리판
- 숫자 단일 버전 사용
- paper_selected_ts를 select_candidates selected_for_open 순간 봉인
- paper_timing_spine_v940을 OPEN row/decision_state/trade_detail로 전달
- main은 read-only로 selected→OPEN, trigger→selected를 표시
- 매매조건/S등급/trigger/entry/청산/비용 변경 없음
