v1624 fixes actual Paper→TargetRouter→Orderflow refresh route latency. No thresholds changed. Auto-buy OFF.
