#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""수익형_v2.13.467.py

Clean main bot renewal phase v366.
- 메인봇은 무거운 전체시장 스캔/정밀/전략판정을 직접 하지 않는다.
- scanner/feature/orderflow/strategy/review worker가 만든 캐시만 읽는다.
- 실제 paper OPEN은 strategy worker의 S급 후보만 허용한다.
- A/B/C 실시간 후보와 무거운 가상복기는 메인봇 경로에서 제거한다.
"""
from __future__ import annotations
import json, os, sys, time, traceback, re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
import threading
from collections import Counter

try:
    from telegram import Bot, BotCommand
    from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
except Exception:
    Bot = None; BotCommand = None; Updater = None; CommandHandler = None; MessageHandler = None; Filters = None

BOT_VERSION = "수익형 v2.13.491"
BASE_DIR=Path(__file__).resolve().parent
TELEGRAM_TOKEN=os.getenv("TELEGRAM_TOKEN","").strip()
CHAT_ID=os.getenv("CHAT_ID","").strip()
WORKERS={
    "scanner": {"file":"scanner_worker_v0.3.py", "status":"clean_scanner_status.json"},
    "candle": {"file":"candle_worker_v0.2.py", "status":"clean_candle_status.json"},
    "market": {"file":"market_regime_worker_v0.1.py", "status":"clean_market_regime_status.json"},
    "feature": {"file":"feature_worker_v0.2.py", "status":"clean_feature_status.json"},
    "orderflow": {"file":"orderflow_worker_v0.8.py", "status":"clean_orderflow_status.json"},
    "risk": {"file":"risk_worker_v0.2.py", "status":"clean_risk_status.json"},
    "strategy": {"file":"strategy_worker_v0.52.py", "status":"clean_strategy_worker_status.json"},
    "target_router": {"file":"target_router_worker_v0.8.py", "status":"clean_target_router_status.json"},
    "review": {"file":"review_worker_v0.11.py", "status":"clean_review_worker_status.json"},
}
FILES={
    "brain_status":BASE_DIR/"clean_brain_status.json",
    "brain_runtime":BASE_DIR/"clean_brain_runtime.log",
    "brain_error":BASE_DIR/"clean_brain_error.log",
    "resource":BASE_DIR/"clean_resource_status.json",
    "scanner_market":BASE_DIR/"clean_scanner_market_cache.json",
    "feature":BASE_DIR/"clean_feature_cache.json",
    "orderflow":BASE_DIR/"clean_orderflow_summary_cache.json",
    "strategy_summary":BASE_DIR/"clean_strategy_s_summary.json",
    "candle":BASE_DIR/"clean_candle_cache.json",
    "market_regime":BASE_DIR/"clean_market_regime_cache.json",
    "risk":BASE_DIR/"clean_risk_filter_cache.json",
    "strategy_reject":BASE_DIR/"clean_strategy_s_reject_summary.json",
    "review":BASE_DIR/"clean_review_summary.json",
    "paper_status":BASE_DIR/"paper_bot_status.json",
    "paper_open":BASE_DIR/"paper_bot_open.json",
    "paper_score":BASE_DIR/"paper_bot_score_cache.json",
    "paper_latest":BASE_DIR/"paper_candidates_latest.jsonl",
    "paper_archive":BASE_DIR/"paper_candidates.jsonl",
    "paper_handoff":BASE_DIR/"clean_strategy_paper_handoff_status.json",
    "paperbot_handoff":BASE_DIR/"paper_bot_candidate_handoff_status.json",
    "candidate_handoff_trace":BASE_DIR/"paper_bot_candidate_handoff_trace.json",
    "candidate_reason_text":BASE_DIR/"clean_candidate_reason_text_cache.txt",
    "candidate_reason_text_state":BASE_DIR/"clean_candidate_reason_state_cache.json",
    "trigger_shadow_review":BASE_DIR/"clean_trigger_shadow_review_v665.json",
    "paper_closed":BASE_DIR/"paper_bot_closed.jsonl",
    "score_anchor":BASE_DIR/"paper_bot_current_score_anchor.json",
    "target_router":BASE_DIR/"clean_target_router_queue.json",
    "ws_status":BASE_DIR/"clean_ws_sidecar_status.json",
    "micro_status":BASE_DIR/"clean_bithumb_micro_status.json",
    "micro_targets":BASE_DIR/"clean_micro_targets.json",
}
START_TS=time.time()

def now_ts()->float: return time.time()
def now_text(ts:Optional[float]=None)->str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(v:Any, *more:Any, default:float=0.0)->float:
    """안전 숫자 변환.

    기존 호출(fnum(x, -1.0))은 두 번째 인자를 fallback 값처럼 쓰고,
    v345 preview 쪽 호출(fnum(a,b,c, default=0))은 앞에서부터 숫자값을 고른다.
    """
    for val in (v,) + tuple(more):
        try:
            if val is None or val == "":
                continue
            return float(str(val).replace(",", ""))
        except Exception:
            continue
    return default

def norm_ticker(v: Any) -> str:
    """메인봇 preview 전용 안전 티커 정규화.

    v345에서 paper 추적 로직이 norm_ticker를 참조했지만 메인봇 파일에는
    정의가 없어 /preview NameError가 났다. 여기서는 거래소 접두사/마켓 접미사만
    정리하고, 판단 로직에는 관여하지 않는다.
    """
    try:
        s = str(v or "").strip().upper()
        if not s:
            return ""
        if ":" in s:
            s = s.split(":", 1)[1]
        for suf in ("_KRW", "-KRW", "/KRW", "KRW"):
            if s.endswith(suf):
                s = s[:-len(suf)]
                break
        s = s.replace("_", "").replace("-", "").replace("/", "")
        return s
    except Exception:
        return ""

def load_json(path:Path, default:Any=None)->Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+".tmp")
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(",",":"),default=str),encoding="utf-8")
    os.replace(tmp,path)

def read_jsonl(path:Path,max_lines:int=1000)->List[Dict[str,Any]]:
    """JSONL tail reader for Telegram status commands.

    Older code used path.read_text().splitlines(), which read the entire paper
    CLOSED ledger even when only recent rows were needed. That made /health,
    /pstatus and /version_score block for minutes after the ledger grew.
    This keeps default commands cache/tail-only: read only the end of the file,
    then parse at most max_lines rows.
    """
    if not path.exists(): return []
    try:
        max_lines = max(1, int(max_lines or 1000))
    except Exception:
        max_lines = 1000
    try:
        size = path.stat().st_size
        # Enough for normal JSONL status rows, bounded so a huge ledger never
        # blocks the Telegram command loop. Larger requests get a larger tail,
        # but are still capped for safety.
        tail_bytes = min(size, max(256_000, min(8_000_000, max_lines * 4096)))
        with path.open('rb') as f:
            if size > tail_bytes:
                f.seek(-tail_bytes, os.SEEK_END)
                f.readline()  # drop possible partial first line
            data = f.read().decode('utf-8', errors='ignore')
        lines = data.splitlines()
        if len(lines) > max_lines:
            lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception:
                pass
        return out
    except Exception:
        return []

def line_count(path: Path, max_bytes: int = 2_000_000) -> int:
    try:
        if not path.exists(): return 0
        if path.stat().st_size > max_bytes:
            # 큰 archive는 기본 명령에서 전체를 세지 않는다. tail이 아니라 대략 표시만 한다.
            return -1
        return len(path.read_text(encoding="utf-8", errors="ignore").splitlines())
    except Exception: return 0

def log_runtime(msg:str)->None:
    try:
        with FILES["brain_runtime"].open("a",encoding="utf-8") as f: f.write(f"[{now_text()}] {msg}\n")
    except Exception: pass

def log_error(where:str,exc:BaseException)->None:
    try:
        with FILES["brain_error"].open("a",encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n{traceback.format_exc()[-1500:]}\n")
    except Exception: pass

def age(path:Path)->float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0

def pid_alive(pid:int)->bool:
    if pid<=0: return False
    try: os.kill(pid,0); return True
    except Exception: return False

def worker_status(name:str)->Dict[str,Any]:
    spec=WORKERS[name]; path=BASE_DIR/spec["status"]
    obj=load_json(path,{}) or {}; pid=int(fnum(obj.get("pid"),default=0)); alive=pid_alive(pid)
    a=age(path)
    state=str(obj.get("state") or "missing") if obj else "missing"
    return {"name":name,"state":state,"pid":pid,"alive":alive,"age":round(a,1),"version":obj.get("version","-"),"last_sec":obj.get("last_sec","-"),"row_count":obj.get("row_count",obj.get("evaluated",obj.get("closed_recent","-"))),"raw":obj}

def ensure_workers()->None:
    # v329: worker 실행/재시작은 가드봇 systemd 전담. 메인봇은 절대 직접 worker를 켜지 않는다.
    return

def resource_snapshot()->Dict[str,Any]:
    try:
        import shutil
        total, used, free = shutil.disk_usage(BASE_DIR)
        mem_total=mem_free=0
        try:
            for ln in Path('/proc/meminfo').read_text().splitlines():
                if ln.startswith('MemTotal:'): mem_total=int(ln.split()[1])*1024
                if ln.startswith('MemAvailable:'): mem_free=int(ln.split()[1])*1024
        except Exception: pass
        load=os.getloadavg() if hasattr(os,'getloadavg') else (0,0,0)
        return {"disk_free_gb":round(free/1024**3,2),"disk_used_pct":round(used/total*100,1),"mem_free_mb":round(mem_free/1024**2,1) if mem_free else 0,"mem_used_pct":round((1-mem_free/mem_total)*100,1) if mem_total and mem_free else 0,"load":[round(x,2) for x in load]}
    except Exception as exc:
        log_error("resource_snapshot",exc); return {}

def update_brain_status(state:str="running")->None:
    """메인봇 heartbeat/status만 저장한다.
    v329 기준 worker 실행/재시작은 가드봇 systemd 전담이다.
    """
    workers={k:worker_status(k) for k in WORKERS}
    save_json(FILES["brain_status"],{
        "version":BOT_VERSION,
        "state":state,
        "telegram_state":state,
        "pid":os.getpid(),
        "updated_ts":now_ts(),
        "updated_text":now_text(),
        "uptime_sec":round(now_ts()-START_TS,1),
        "workers":workers,
        "resource":resource_snapshot(),
        "note":"v330 main is cache-only; worker lifecycle is guard/systemd only",
    })

def worker_ok(st:Dict[str,Any])->str:
    state=str(st.get('state') or '').lower()
    a=fnum(st.get('age'), default=999999)
    if state in {'error','failed','stopped','missing','dead'}:
        return '❌'
    if state in {'running','ready','ok','initializing'}:
        return '✅' if a < 45 else '⚠️'
    return '❔'

def line_worker(st:Dict[str,Any], detail:bool=False)->str:
    icon=worker_ok(st)
    base=f"- {icon} {st['name']}: {st.get('version','-')} / {st.get('state')} / age {st.get('age')}s"
    if detail:
        base += f" / rows {st.get('row_count')} / sec {st.get('last_sec')}"
    return base

def router_flow_summary(router: Dict[str, Any]) -> str:
    """v337: target_router를 개수 제한표가 아니라 전체/우선/순환/대기/버림으로 보여준다."""
    if not isinstance(router, dict) or not router:
        return "- 정보배차: 상태 없음"
    return (
        f"- 정보배차: 전체 {router.get('queue_count','-')} / 최우선 {router.get('priority_protected_count','-')} "
        f"/ 이번내보냄 {router.get('active_target_count', router.get('target_count','-'))} "
        f"/ 순환대기 {router.get('rotation_wait_count', router.get('backlog_count','-'))} "
        f"/ 버림 {router.get('dropped_count',0)}"
    )

def router_flow_detail(router: Dict[str, Any]) -> List[str]:
    if not isinstance(router, dict) or not router:
        return ["- 정보배차 상태 없음"]
    return [
        router_flow_summary(router),
        f"- 채워야할 정보: WS필요 {router.get('need_ws','-')} / micro필요 {router.get('need_micro','-')} / fresh회복 {router.get('fresh_recovered','-')}",
        f"- 순환상태: rotation pool {router.get('rotation_pool_count','-')} / 이번순환 {router.get('rotation_export_count','-')} / 다음커서 {router.get('next_rotation_cursor','-')}",
        f"- 보호슬롯: 전략요청 {router.get('strategy_req_total_count','-')} / 강제보호 {router.get('strategy_req_forced_active_count','-')} / micro요청 {router.get('strategy_req_micro_target_count','-')}",
    ]


def health_text()->str:
    # v340: health는 기본 상태판이므로 v338 형식 유지. worker 시작/재시작/직접계산 금지.
    update_brain_status('running')
    workers=[worker_status(k) for k in WORKERS]
    res=resource_snapshot()
    paper=load_json(FILES['paper_status'],{}) or {}
    ws=load_json(FILES['ws_status'],{}) or {}
    micro=load_json(FILES['micro_status'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    reject=load_json(FILES['strategy_reject'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    router=load_json(FILES['target_router'],{}) or {}
    good=sum(1 for w in workers if worker_ok(w)=='✅')
    warn=sum(1 for w in workers if worker_ok(w)=='⚠️')
    bad=sum(1 for w in workers if worker_ok(w)=='❌')
    evaluated = int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0, 0))
    quote_ready = int(fnum(strat.get('quote_ready_count') or reject.get('quote_ready_count') or oflow.get('quote_fresh') or 0, 0))
    micro_ready = int(fnum(strat.get('micro_ready_count') or reject.get('micro_ready_count') or oflow.get('fresh_micro') or 0, 0))
    full_ready = int(fnum(strat.get('full_info_ready_count') or reject.get('full_info_ready_count') or oflow.get('info_ready') or 0, 0))
    sent_count = router.get('export_count', router.get('active_target_count', router.get('target_count','-')))
    lines=[
        "🧭 건강상태 /health",
        f"✅ 메인봇 {BOT_VERSION} / clean worker hub v369 / uptime {int(now_ts()-START_TS)}s",
        "",
        "[한눈요약 · 기존 health 값 유지]",
        f"✅ 전체 {evaluated or '-'}개 평가 / 시세 {quote_ready}/{evaluated or '-'} / 호가·체결 {micro_ready}/{evaluated or '-'} / 둘다 {full_ready}/{evaluated or '-'}",
        f"✅ 배차 전체 {router.get('queue_count','-')}개 → 이번내보냄 {sent_count}개 / 순환대기 {router.get('rotation_wait_count','-')}개 / 버림 {router.get('dropped_count',0)}개",
        f"✅ worker 정상 {good}개 / 주의 {warn}개 / 문제 {bad}개",
        f"✅ 오류 없음 기준은 /errorlog / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        f"- worker: ✅ {good} / ⚠️ {warn} / ❌ {bad}",
        f"- paper: {paper.get('version','-')} / OPEN {paper.get('open_count', paper.get('open_total','-'))} / age {age(FILES['paper_status']):.1f}s",
        f"- WS: age {age(FILES['ws_status']):.1f}s / cache {ws.get('cache', ws.get('cache_count','-'))} / fresh {ws.get('fresh','-')}",
        f"- micro: age {age(FILES['micro_status']):.1f}s / targets {micro.get('targets','-')} / batch {micro.get('poll_batch','-')} / cached {micro.get('cached','-')} / fresh {micro.get('fresh','-')}",
        f"- orderflow: quote {oflow.get('quote_fresh','-')} / micro {oflow.get('fresh_micro','-')} / ready {oflow.get('info_ready','-')} / active {oflow.get('active_count','-')}",
        router_flow_summary(router),
        f"- S 후보 {strat.get('s_count',0)} / 평가 {reject.get('evaluated','-')} / 탈락 {reject.get('reject_count','-')}",
        f"- 디스크 {res.get('disk_used_pct','-')}% / 남음 {res.get('disk_free_gb','-')}GB / 메모리 {res.get('mem_used_pct','-')}% / load {res.get('load','-')}",
        "",
        "[worker 요약]",
    ]
    lines += [line_worker(w, detail=False) for w in workers]
    lines += ["", "[worker 품질 · v482]"]
    try:
        lines += _v482_worker_quality_lines({k: worker_status(k) for k in WORKERS})
    except Exception as exc:
        lines.append(f"- ⚠️ worker 품질 요약 생성 실패: {exc.__class__.__name__}")
    lines += ["", "[원칙] 메인봇은 worker cache만 읽음. worker 실행/재시작은 가드봇 systemd 전담. v482부터 running/age뿐 아니라 data-quality도 같이 봄."]
    return "\n".join(lines)

def _worker_metric_int(st: Dict[str, Any], *keys: str) -> Any:
    raw = st.get('raw') if isinstance(st.get('raw'), dict) else {}
    for k in keys:
        v = raw.get(k)
        if v not in (None, '', '-'):
            return v
    return '-'


def _v482_worker_quality_lines(workers: Dict[str, Dict[str, Any]]) -> List[str]:
    """v482: worker가 살아있는지만 보던 상태판 착시를 줄인다.

    메인봇은 여전히 cache/status만 읽는다. 여기서는 worker가 이미 저장한
    품질 숫자만 요약한다: hot-rank 생성, 1m/3m 실제 source, hot target 배차,
    strategy canonical source coverage. 값이 없으면 계산 fallback을 하지 않고 '-'로 표시한다.
    """
    def raw(name: str) -> Dict[str, Any]:
        st = workers.get(name, {}) if isinstance(workers, dict) else {}
        return st.get('raw') if isinstance(st.get('raw'), dict) else {}
    scanner = raw('scanner')
    feature = raw('feature')
    target = raw('target_router')
    strategy = raw('strategy')
    router = load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'), {}) or {}
    hot = load_json(BASE_DIR/'clean_scanner_hot_rank_cache.json', {}) or {}
    feat_cache = load_json(FILES.get('feature', BASE_DIR/'clean_feature_cache.json'), {}) or {}
    lines: List[str] = []
    # Scanner: process alive != hot-rank usable. Show both known count and hot cache age.
    lines.append(
        f"- scanner 품질: hot1m {scanner.get('hot_known_1m', hot.get('known_1m','-'))} / "
        f"hot3m {scanner.get('hot_known_3m', hot.get('known_3m','-'))} / "
        f"hot cache age {age(BASE_DIR/'clean_scanner_hot_rank_cache.json'):.1f}s"
    )
    # Feature: show real short-flow source coverage. v481 removed fake 24h/1440 fallback.
    lines.append(
        f"- feature 품질: 1m known {feature.get('known_1m', feat_cache.get('known_1m','-'))} / "
        f"3m known {feature.get('known_3m', feat_cache.get('known_3m','-'))} / "
        f"1m missing {feature.get('missing_1m', feat_cache.get('missing_1m','-'))} / "
        f"3m missing {feature.get('missing_3m', feat_cache.get('missing_3m','-'))} / "
        f"hot 사용 {feature.get('hot_used', feat_cache.get('hot_used','-'))}"
    )
    # Router: show whether hot-rank actually entered active collection targets.
    lines.append(
        f"- target 품질: hot 요청 {target.get('hot_rank_req_count', router.get('hot_rank_req_count','-'))} / "
        f"hot active {target.get('hot_rank_active_count', router.get('hot_rank_active_count','-'))} / "
        f"recheck 요청 {target.get('recheck_req_count', router.get('recheck_req_count','-'))} / "
        f"recheck micro {target.get('recheck_micro_target_count', router.get('recheck_micro_target_count','-'))}"
    )
    # Strategy: show current canonical source schema where available.
    lines.append(
        f"- strategy 품질: canonical {strategy.get('canonical_metric_schema', strategy.get('stage_policy_schema','-'))} / "
        f"S1 {strategy.get('s1_count','-')} / S2 {strategy.get('s2_count','-')} / S3 {strategy.get('s3_count','-')} / "
        f"target {strategy.get('target_count','-')}"
    )
    return lines

def workers_text()->str:
    update_brain_status('running')
    workers={k:worker_status(k) for k in WORKERS}
    router=load_json(FILES['target_router'],{}) or {}
    strat=load_json(FILES['strategy_summary'],{}) or {}
    oflow=load_json(FILES['orderflow'],{}) or {}
    scanner=workers.get('scanner',{})
    feature=workers.get('feature',{})
    candle=workers.get('candle',{})
    market=workers.get('market',{})
    orderflow=workers.get('orderflow',{})
    risk=workers.get('risk',{})
    strategy=workers.get('strategy',{})
    target=workers.get('target_router',{})
    review=workers.get('review',{})
    lines=["🧩 worker 상태 /workers", "- 메인봇은 상태파일만 읽고 worker를 직접 실행하지 않음.", "", "[시장/재료]"]
    lines.append(f"- {worker_ok(scanner)} 스캐너: 전체 {_worker_metric_int(scanner,'row_count','pool_count')}개 수집 / {scanner.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(feature)} 특징: {_worker_metric_int(feature,'row_count')}개 표준값 / {feature.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(candle)} 캔들: {_worker_metric_int(candle,'row_count')}개 보강 / target {_worker_metric_int(candle,'target_count')} / {candle.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(market)} 장세: {_worker_metric_int(market,'row_count')}개 확인 / {market.get('last_sec','-')}초")
    lines += ["", "[정보 보강]"]
    lines.append(f"- {worker_ok(orderflow)} 호가요약: 전체 {_worker_metric_int(orderflow,'row_count')}개 / WS {_worker_metric_int(orderflow,'fresh_ws')} / micro {_worker_metric_int(orderflow,'fresh_micro')} / {orderflow.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(target)} 정보배차: 전체 {router.get('queue_count','-')}개 → 내보냄 {router.get('export_count',router.get('active_target_count','-'))}개 / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    lines += ["", "[판정/복기]"]
    # v346: strategy status가 순간적으로 rows 0으로 보일 때 summary 캐시 기준값으로 보정 표시.
    # 상태 판단은 worker status를 쓰되, 숫자 표시는 clean_strategy_s_summary / reject summary까지 같이 본다.
    reject_sum = load_json(FILES['strategy_reject'], {}) or {}
    st_eval = _worker_metric_int(strategy,'evaluated','row_count')
    if st_eval in ('-', None, '', 0, '0'):
        st_eval = strat.get('evaluated') or reject_sum.get('evaluated') or '-'
    st_s = _worker_metric_int(strategy,'s_count')
    if st_s in ('-', None, ''):
        st_s = strat.get('s_count', 0)
    st_pending = _worker_metric_int(strategy,'info_pending_count')
    if st_pending in ('-', None, ''):
        st_pending = strat.get('info_pending_count') or reject_sum.get('info_pending_count') or 0
    st_sec = strategy.get('last_sec','-')
    if st_sec in ('-', None, '', 0, '0'):
        st_sec = strat.get('last_sec') or reject_sum.get('last_sec') or st_sec
    lines.append(f"- {worker_ok(strategy)} 전략판정: 평가 {st_eval}개 / S {st_s}개 / 정보대기 {st_pending}개 / {st_sec}초")
    lines.append(f"- {worker_ok(risk)} 위험: 최근손실/쿨다운 확인 / {risk.get('last_sec','-')}초")
    lines.append(f"- {worker_ok(review)} 복기: 최근완료 {_worker_metric_int(review,'closed_recent')}개 / 큰손실 {_worker_metric_int(review,'big_loss')} / 좋은승리 {_worker_metric_int(review,'good_win')} / {review.get('last_sec','-')}초")
    lines += ["", "[데이터 품질 · v482]"]
    try:
        lines += _v482_worker_quality_lines(workers)
    except Exception as exc:
        lines.append(f"- ⚠️ 데이터 품질 요약 생성 실패: {exc.__class__.__name__}")
    lines += ["", "[상세 원본]"]
    lines += [line_worker(workers[k], detail=True) for k in WORKERS]
    return "\n".join(lines)

def _paper_score_cache_version_ok(ver: str) -> bool:
    """v355: paper score cache gate 단일화.

    기존 v354는 허용 버전을 v0.86~v0.92 목록으로 박아두어 paper_bot이 v0.95로
    올라가면 같은 current-version score cache도 구버전으로 오판했다.
    이제 schema/scope는 그대로 엄격히 보되, paper_bot_v0.86 이상은 버전 숫자로 판정한다.
    구 v0.77/v0.80 계열 cache가 섞이지 않게 86 미만은 계속 차단한다.
    """
    m = re.search(r"paper_bot_v0\.(\d+)", str(ver or ""))
    if not m:
        return False
    return int(m.group(1)) >= 86


def _current_paper_score_cache() -> Dict[str, Any]:
    """v355: /score는 현재판 paper score cache만 읽는다.

    오래된 직접계산 fallback은 쓰지 않는다. 다만 paper_bot 버전이 올라갈 때마다
    메인봇 허용목록을 손으로 추가해야 하는 구경로는 제거했다.
    """
    c = load_json(FILES['paper_score'], {}) or {}
    if not isinstance(c, dict):
        return {}
    if not _paper_score_cache_version_ok(str(c.get('version') or '')):
        return {}
    if str(c.get('schema') or '') != 'paper_score_cache_v086':
        return {}
    if str(c.get('score_scope') or '') != 'current_version_anchor':
        return {}
    if c.get('current_closed_count') is None:
        return {}
    return c


def _score_stat_line(label: str, st: Dict[str, Any]) -> str:
    if not isinstance(st, dict):
        st = {}
    n = int(fnum(st.get('n', st.get('count', 0)), default=0))
    wins = int(fnum(st.get('wins', 0), default=0))
    losses = int(fnum(st.get('losses', 0), default=0))
    wr = fnum(st.get('win_rate', st.get('win_rate_pct', 0)), default=0.0)
    total = fnum(st.get('total', st.get('total_pct', st.get('profit_sum', 0))), default=0.0)
    avg = fnum(st.get('avg', st.get('avg_pct', 0)), default=0.0)
    return f"- {label}: {n}전 {wins}승 {losses}패 / 승률 {wr:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%"



def score_text()->str:
    cache = _current_paper_score_cache()
    raw = load_json(FILES['paper_score'], {}) or {}
    lines=["📊 전략별 스코어 /score", "- 목적: 닫힌 paper 결과를 대표전략 기준으로 본다. 중복태그 성과는 참고용."]
    label_map={'money_reaccel_s':'돈흐름 재가속','leader_momentum_s':'주도추세 지속','breakout_early_s':'돌파 초입','sweep_vwap_recovery_s':'저점 VWAP 회복','surge_rebreak_s':'급등 후 재돌파','leader_flow_adaptive_hold_s':'주도흐름 유동보유'}
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n=int(fnum(cache.get('current_closed_count') or 0,0))
        primary_stats = cache.get('strategy_primary_stats') if isinstance(cache.get('strategy_primary_stats'), list) else cache.get('strategy_s_stats') if isinstance(cache.get('strategy_s_stats'), list) else []
        overlap_stats = cache.get('strategy_overlap_stats') if isinstance(cache.get('strategy_overlap_stats'), list) else []
        primary_total=int(fnum(cache.get('strategy_primary_total') or sum(int(fnum(x.get('n') or 0,0)) for x in primary_stats if isinstance(x,dict)),0))
        overlap_total=int(fnum(cache.get('strategy_overlap_total') or sum(int(fnum(x.get('n') or 0,0)) for x in overlap_stats if isinstance(x,dict)),0))
        lines.append(f"- 캐시 age {age(FILES['paper_score']):.1f}s / 현재판 CLOSED {current_n}개 / 대표전략 집계 {primary_total}개")
        lines += [
            _score_stat_line('✅ S 전체', gs.get('S', {})),
            _score_stat_line('현재판 전체', gs.get('ALL', {})),
        ]
        lines += ["", "[대표전략 기준 · 실제 거래수와 맞는 성과]"]
        stat_map={str(st.get('key') or st.get('label') or ''):st for st in primary_stats if isinstance(st,dict)}
        for key,label in label_map.items():
            lines.append(_score_stat_line(label, stat_map.get(key, {})))
        if overlap_stats:
            lines += ["", f"[중복태그 포함 · 참고용 / 합계 {overlap_total}개]"]
            over_map={str(st.get('key') or st.get('label') or ''):st for st in overlap_stats if isinstance(st,dict)}
            for key,label in label_map.items():
                lines.append(_score_stat_line(label, over_map.get(key, {})))
            if overlap_total > current_n:
                lines.append(f"- ⚠️ 중복태그 때문에 참고용 합계가 CLOSED보다 {overlap_total-current_n}개 많습니다.")
    else:
        old_ver = raw.get('version','없음') if isinstance(raw,dict) else '없음'
        old_schema = raw.get('schema','-') if isinstance(raw,dict) else '-'
        lines.append(f"- ✅ 구 score cache 차단: {old_ver} / {old_schema}")
        lines.append("- 현재판 paper_bot score cache 준비중입니다. 예전 승률·수익률은 기본 /score에 섞지 않습니다.")
    strat=load_json(FILES['strategy_summary'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    if strat:
        router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
        lines += ["", "[현재 후보/정보 흐름]"]
        lines.append(f"- 현재 S {strat.get('s_count',0)} / latest {strat.get('paper_latest_count',0)} / paper 병합 {pbh.get('merged_fresh','-')} / archive {pbh.get('archive_window','-')}")
        lines.append(f"- 정보: 전체 {strat.get('evaluated','-')}개 / 시세 {strat.get('quote_ready_count','-')} / micro {strat.get('micro_ready_count','-')} / 둘다 {strat.get('full_info_ready_count','-')}")
        lines.append(f"- 배차: 전체 {router.get('queue_count','-')} / 내보냄 {router.get('export_count', router.get('active_target_count','-'))} / 대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)}")
    return "\n".join(lines)



def quality_text()->str:
    reject=load_json(FILES['strategy_reject'],{}) or {}; strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    pbh=load_json(FILES['paperbot_handoff'],{}) or {}
    latest_lines=line_count(FILES['paper_latest'])
    archive_lines=line_count(FILES['paper_archive'])
    router=load_json(FILES.get('target_router', BASE_DIR/'clean_target_router_queue.json'),{}) or {}
    evaluated=int(fnum(reject.get('evaluated') or strat.get('evaluated') or 0,0))
    quote=int(fnum(reject.get('quote_ready_count') or strat.get('quote_ready_count') or evaluated,0))
    micro=int(fnum(reject.get('micro_ready_count') or strat.get('micro_ready_count') or 0,0))
    both=int(fnum(reject.get('full_info_ready_count') or strat.get('full_info_ready_count') or min(quote,micro),0))
    not_micro=max(0,evaluated-micro) if evaluated else 0
    dropped=int(fnum(router.get('dropped_count') or 0,0))
    rot_wait=int(fnum(router.get('rotation_wait_count') or 0,0))
    need_micro=int(fnum(router.get('need_micro') or reject.get('info_pending_count') or 0,0))
    lines=[
        "🔍 후보품질 /quality",
        f"✅ 전체 {evaluated}개 평가 / 최종 S {strat.get('s_count',0)}개 / paper latest {latest_lines}줄 / 병합 {pbh.get('merged_fresh','-')}",
        "",
        "[정보가 얼마나 채워졌나]",
        f"- 시세: {quote}/{evaluated}개 / 호가·체결: {micro}/{evaluated}개 / 둘다: {both}/{evaluated}개",
        f"- 아직 micro 미신선: {not_micro}개 / 지금 꼭 필요한 micro: {need_micro}개",
        "",
        "[안 넣은 게 아니라 순환 상태]",
        f"- 전체배차 {router.get('queue_count','-')}개 → 이번내보냄 {router.get('export_count', router.get('active_target_count','-'))}개",
        f"- 순환대기 {rot_wait}개 / 버림 {dropped}개 / safety초과 {router.get('export_over_budget_count',0)}개",
        f"- 최우선 {router.get('priority_protected_count','-')}개 / 보호슬롯 req {router.get('strategy_req_total_count','-')}개 / req_micro_target {router.get('strategy_req_micro_target_count','-')}개",
        "",
        "[후보 판정]",
        f"- cheap탈락 {reject.get('cheap_reject_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / 정보불필요 {reject.get('info_not_requested','-')} / fresh완료 {reject.get('fresh_ready_count','-')}",
        f"- paper 전달: strategy handoff {hand.get('paper_latest_count','-')} / archive {'대형' if archive_lines<0 else str(archive_lines)+'줄'}",
    ]
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    cur_s=int(fnum(strat.get('s_count') or 0,0))
    lines += ["", "[현재 최종 S 후보 TOP]" if cur_s else "[latest/handoff 후보 TOP · 현재 S 0이면 보관 후보]"]
    if evs:
        for e in evs[:8]:
            lines.append(f"- {'✅' if cur_s else '❔'} {e.get('ticker')} / {e.get('strategy_bucket_primary_label', e.get('strategy_name'))} / 점수 {e.get('score')} / 근거 {', '.join(e.get('reasons',[])[:4])}")
    else: lines.append("- 없음")
    wait_sample=reject.get('priority_wait_sample') if isinstance(reject.get('priority_wait_sample'),list) else []
    micro_payload=load_json(FILES.get('micro_targets', BASE_DIR/'clean_micro_targets.json'),{}) or {}
    micro_targets=set(str(x).upper() for x in (micro_payload.get('targets') if isinstance(micro_payload.get('targets'),list) else []))
    active_targets=set(str(x).upper() for x in ((router.get('active_targets') or router.get('targets')) if isinstance((router.get('active_targets') or router.get('targets')),list) else []))
    lines += ["", "[정보대기 TOP · 왜 아직 못 들어갔나]"]
    if wait_sample:
        for x in wait_sample[:6]:
            t=str(x.get('ticker') or '').upper(); mt_bool=bool(x.get('micro_target')) or t in micro_targets; act_bool=bool(x.get('router_active')) or t in active_targets
            q='✅' if x.get('quote_ready') else '❌'; m='✅' if x.get('micro_ready') else '❌'; mt='✅' if mt_bool else '❌'; a='✅' if act_bool else '❌'
            if (not mt_bool): why='target 미반영'
            elif not x.get('micro_ready'): why='micro 수집대기'
            else: why='확인필요'
            lines.append(f"- {t}: 시세 {q} / micro {m} / target {mt} / active {a} / {why}")
    else:
        lines.append("- 없음")
    lines += ["", "[탈락 사유 TOP]"]
    tops=reject.get('reason_top') if isinstance(reject.get('reason_top'),list) else []
    for x in tops[:12]:
        reason=str(x.get('reason') or '-')
        icon='⚠️' if ('고점' in reason or '손실' in reason or '매도' in reason or '윗꼬리' in reason) else '❔'
        lines.append(f"- {icon} {reason}: {x.get('count')}")
    if not tops: lines.append("- 아직 없음")
    return "\n".join(lines)


def strategy_watch_text()->str:
    strat=load_json(FILES['strategy_summary'],{}) or {}
    hand=load_json(FILES['paper_handoff'],{}) or {}
    lines=["👀 전략 감시 /strategy_watch", "- 전략별 S만 감시. A/B/C는 기본화면에서 제외.", f"- handoff: latest {hand.get('paper_latest_count','-')} / 새S {hand.get('new_s_count','-')} / append {hand.get('archive_appended','-')}"]
    for k,v in (strat.get('strategies') or {}).items(): lines.append(f"- {k}: S {v}")
    evs=strat.get('events') if isinstance(strat.get('events'),list) else []
    lines += ["", "[OPEN 전달 후보]"]
    if evs:
        for e in evs[:10]: lines.append(f"- ✅ {e.get('ticker')} / {e.get('strategy_bucket_primary_label')} / {e.get('score')} / {', '.join(e.get('reasons',[])[:3])}")
    else: lines.append("- 없음")
    return "\n".join(lines)

def errorlog_text()->str:
    path=FILES['brain_error']
    header="🧯 오류로그 /errorlog"
    if not path.exists():
        return header+"\n\n✅ 새 실행 중 오류 없음"
    txt=path.read_text(encoding='utf-8',errors='ignore')
    lines=txt.splitlines()
    # 로그 형식: [YYYY-MM-DD HH:MM:SS] where: Error
    new_lines=[]; old_lines=[]
    for ln in lines[-300:]:
        ts=0.0
        m=re.match(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", ln)
        if m:
            try:
                ts=time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))
            except Exception:
                ts=0.0
        if ts and ts >= START_TS:
            new_lines.append(ln)
        elif '[' in ln:
            old_lines.append(ln)
    out=[header]
    if new_lines:
        out += ["", "❌ 새 실행 이후 오류", *new_lines[-10:]]
    else:
        out += ["", "✅ 새 실행 중 오류 없음"]
        if old_lines:
            out.append(f"- 과거 오류 흔적 {len(old_lines)}줄 있음 / 최근 2개만 참고")
            out += old_lines[-2:]
    return "\n".join(out)

def open_text()->str:
    obj=load_json(FILES['paper_open'],{}) or {}
    lines=["📂 OPEN 요약 /popen_short"]
    if not obj: return "\n".join(lines+["- OPEN 없음"])
    for _,p in list(obj.items())[:12]: lines.append(f"- {p.get('ticker')} / {p.get('strategy_name',p.get('strategy_key','-'))} / {p.get('profit_pct',p.get('current_profit_pct','-'))}%")
    return "\n".join(lines)



def _rows_for_pipe(obj:Any)->List[Any]:
    if isinstance(obj,list): return obj
    if isinstance(obj,dict):
        for k in ("rows","items","targets","active","active_rows","queue","data","symbols"):
            if isinstance(obj.get(k),list): return obj.get(k)
    return []

def _sym_for_pipe(x:Any)->str:
    if isinstance(x,str): v=x
    elif isinstance(x,dict): v=x.get("symbol") or x.get("ticker") or x.get("market") or x.get("coin") or x.get("code") or ""
    else: v=""
    return str(v).replace("KRW-","").replace("_KRW","").replace("/KRW","").upper()

def _set_from_file(path:Path)->set:
    return {_sym_for_pipe(r) for r in _rows_for_pipe(load_json(path,{}) or {}) if _sym_for_pipe(r)}

def pipe_check_text()->str:
    update_brain_status('running')
    paths={
        'ws_targets': BASE_DIR/'clean_ws_targets.json',
        'micro_targets': BASE_DIR/'clean_micro_targets.json',
        'router': BASE_DIR/'clean_target_router_queue.json',
        'strategy_req': BASE_DIR/'clean_strategy_priority_requests.json',
        'strategy': BASE_DIR/'clean_strategy_s_reject_summary.json',
        'orderflow': BASE_DIR/'clean_orderflow_summary_cache.json',
        'ws_status': FILES['ws_status'],
        'micro_status': FILES['micro_status'],
    }
    sets={k:_set_from_file(p) for k,p in paths.items()}
    router=load_json(paths['router'],{}) or {}; reject=load_json(paths['strategy'],{}) or {}; req=load_json(paths['strategy_req'],{}) or {}; of=load_json(paths['orderflow'],{}) or {}; ws=load_json(paths['ws_status'],{}) or {}; mi=load_json(paths['micro_status'],{}) or {}
    of_rows=_rows_for_pipe(of)
    quote_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('quote_fresh') or r.get('ws_fresh')))
    micro_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('micro_fresh'))
    full_ready=sum(1 for r in of_rows if isinstance(r,dict) and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    active_ready=sum(1 for r in of_rows if isinstance(r,dict) and r.get('router_active') and (r.get('info_ready') or ((r.get('quote_fresh') or r.get('ws_fresh')) and r.get('micro_fresh'))))
    lines=["🧪 정보배관 점검 /pipe_check", "- SSH 없이 target → orderflow → strategy 병합 상태만 봅니다."]
    lines.append(f"- WS 상태: age {age(paths['ws_status']):.1f}s / fresh {ws.get('fresh','-')} / targets {len(sets['ws_targets'])}")
    lines.append(f"- micro 상태: age {age(paths['micro_status']):.1f}s / fresh {mi.get('fresh','-')} / targets {mi.get('targets','-')} / target파일 {len(sets['micro_targets'])}")
    lines.append(f"- orderflow: rows {len(of_rows)} / quote준비 {quote_ready} / micro준비 {micro_ready} / 둘다준비 {full_ready} / active준비 {active_ready}")
    lines.append(router_flow_summary(router))
    lines.append(f"- router 세부: 이번순환 {router.get('rotation_export_count','-')} / 순환대기 {router.get('rotation_wait_count','-')} / 버림 {router.get('dropped_count',0)} / fresh회복 {router.get('fresh_recovered','-')}")
    lines.append(f"- strategy: 평가 {reject.get('evaluated','-')} / cheap탈락 {reject.get('cheap_reject_count','-')} / 정보필요 {reject.get('info_needed_count','-')} / 정보대기 {reject.get('info_pending_count','-')} / fresh완료 {reject.get('fresh_ready_count','-')} / 병합 {reject.get('orderflow_attached_count','-')}")
    lines.append("")
    checks=[('ws_targets','orderflow'),('micro_targets','orderflow'),('router','ws_targets'),('router','micro_targets'),('strategy_req','orderflow')]
    for a,b in checks:
        lines.append(f"- 겹침 {a}↔{b}: {len(sets[a] & sets[b])}")
    lines.append("")
    if len(sets['ws_targets']) and len(sets['ws_targets'] & sets['orderflow']): lines.append("✅ WS target은 orderflow에 심볼 기준 붙음")
    elif len(sets['ws_targets']): lines.append("❌ WS target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ WS active target 없음")
    if len(sets['micro_targets']) and len(sets['micro_targets'] & sets['orderflow']): lines.append("✅ micro target은 orderflow에 심볼 기준 붙음")
    elif len(sets['micro_targets']): lines.append("❌ micro target은 있으나 orderflow에 심볼이 안 붙음")
    else: lines.append("⚠️ micro active target 없음")
    # 전략 요청 후보를 개별로 짧게 보여준다. 흐름이 막히면 여기서 quote/micro/target 중 무엇이 빠졌는지 바로 보인다.
    of_map = { _sym_for_pipe(r): r for r in of_rows if isinstance(r, dict) and _sym_for_pipe(r) }
    req_rows = _rows_for_pipe(req)
    if isinstance(req, dict) and isinstance(req.get('requests'), list):
        req_rows = req.get('requests')
    if req_rows:
        lines += ["", "[전략요청 후보 상태]"]
        for r in req_rows[:8]:
            t=_sym_for_pipe(r)
            ofr=of_map.get(t,{})
            q=bool(ofr.get('quote_fresh') or ofr.get('ws_fresh'))
            m=bool(ofr.get('micro_fresh'))
            a=t in sets['micro_targets']
            active=bool(ofr.get('router_active'))
            qicon='✅' if q else '❌'
            micon='✅' if m else '❌'
            ticon='✅' if a else '❌'
            aicon='✅' if active else '❌'
            need = r.get('need') if isinstance(r,dict) and isinstance(r.get('need'),list) else []
            why=''
            if not a:
                why=' / 원인 microTarget 미반영'
            elif not active:
                why=' / 원인 orderflow active 미표시'
            elif not m:
                why=' / 원인 micro 수집대기'
            lines.append(f"- {t}: quote {qicon} / micro {micon} / microTarget {ticon} / active {aicon} / {r.get('bucket','-') if isinstance(r,dict) else '-'} / need {','.join(need)}{why}")
    if full_ready:
        lines.append("✅ orderflow canonical 정보가 준비된 후보 있음")
    else:
        lines.append("⚠️ orderflow canonical 둘다준비 후보 없음: micro/quote 중 하나가 부족")
    lines.append("- 판단: v340 기준: strategy는 quote_fresh(WS 또는 scanner REST)+micro_fresh를 기준으로 보고, S근접 micro 대기는 우선배차로 따로 추적합니다.")
    return "\n".join(lines)


# -----------------------------
# v343: 메인봇에서 paper 복기/성과 명령을 캐시 전용으로 읽는다.
# paper_bot은 실행/장부/알림 담당, 메인봇은 사용자가 한 방에서 볼 수 있게 요약만 읽는다.
# -----------------------------
STRATEGY_LABELS = {
    'money_reaccel_s': '돈흐름 재가속',
    'leader_momentum_s': '주도추세 지속',
    'breakout_early_s': '돌파 초입',
    'sweep_vwap_recovery_s': '저점 VWAP 회복',
    'surge_rebreak_s': '급등 후 재돌파',
    'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
}

def _short_ticker(v: Any) -> str:
    return str(v or '').upper().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '').replace('KRW', '').strip()

def _paper_open_positions() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES['paper_open'], {}) or {}
    return obj if isinstance(obj, dict) else {}

def _paper_score_cache_current() -> Dict[str, Any]:
    return _current_paper_score_cache()

def _stat_line(label: str, st: Dict[str, Any]) -> str:
    return _score_stat_line(label, st)

def _paper_strategy_label(row_or_key: Any) -> str:
    if isinstance(row_or_key, dict):
        k = str(row_or_key.get('strategy_key') or row_or_key.get('primary_strategy_key') or row_or_key.get('representative_strategy_key') or '')
        name = str(row_or_key.get('strategy_bucket_primary_label') or row_or_key.get('strategy_name') or row_or_key.get('strategy') or '')
        if k in STRATEGY_LABELS:
            return STRATEGY_LABELS[k]
        for kk, vv in STRATEGY_LABELS.items():
            if vv in name:
                return vv
        return name or '-'
    k = str(row_or_key or '')
    return STRATEGY_LABELS.get(k, k or '-')

def _paper_grade(row: Dict[str, Any]) -> str:
    g = str(row.get('grade') or row.get('entry_grade') or row.get('signal_grade') or 'S').upper()
    return g if g else 'S'

def pstatus_text() -> str:
    status = load_json(FILES['paper_status'], {}) or {}
    open_pos = _paper_open_positions()
    cache = _paper_score_cache_current()
    hand = load_json(FILES['paperbot_handoff'], {}) or {}
    grade_counts = Counter(_paper_grade(p) for p in open_pos.values() if isinstance(p, dict))
    lines = [
        '🧪 paper 상태 /pstatus · 메인봇 캐시전용',
        '- paper_bot 명령을 메인봇방에서 읽는 요약입니다. 실행/장부/알림은 paper_bot 담당.',
        f"- 상태: {'ON' if status.get('running', True) else '확인필요'} / loop {status.get('loop_sec', status.get('loop_interval_sec', '-'))}s / OPEN {len(open_pos)} / age {age(FILES['paper_status']):.1f}s",
        f"- OPEN: S {grade_counts.get('S',0)} / A {grade_counts.get('A',0)} / B {grade_counts.get('B',0)} / C {grade_counts.get('C',0)} / 제외 {grade_counts.get('X',0)}",
        f"- handoff: latest {hand.get('latest_count', hand.get('paper_latest_count','-'))} / archive창 {hand.get('archive_window','-')} / 병합fresh {hand.get('merged_fresh','-')}",
        f"- 선별배관: 읽음 {status.get('pick_stats',{}).get('paper_file','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S1선택 {status.get('pick_stats',{}).get('v369_s1_selected', status.get('pick_stats',{}).get('v368_s1_open','-')) if isinstance(status.get('pick_stats'),dict) else '-'} / S2보류 {status.get('pick_stats',{}).get('v369_s2_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / S3관찰 {status.get('pick_stats',{}).get('v369_s3_trace','-') if isinstance(status.get('pick_stats'),dict) else '-'} / 실제OPEN {status.get('opened_this_cycle','-')}",
    ]
    if cache:
        gs = cache.get('grade_stats') if isinstance(cache.get('grade_stats'), dict) else {}
        current_n = int(fnum(cache.get('current_closed_count') or 0, 0))
        primary_total = int(fnum(cache.get('strategy_primary_total') or 0, 0))
        lines += [
            f"- 성과범위: 현재판 앵커 이후 / {cache.get('anchor_text','-')} / CLOSED {current_n}개 / 대표전략 집계 {primary_total}개",
            '[현재판 성과]',
            _stat_line('✅ S', gs.get('S', {})),
            _stat_line('현재판 전체', gs.get('ALL', {})),
            '- 전략별 상세는 /pscore 또는 /score',
        ]
    else:
        raw = load_json(FILES['paper_score'], {}) or {}
        lines += [
            '- 현재판 score cache 준비중',
            f"- 구버전 성과캐시 무시: {raw.get('version','-')} / {raw.get('schema','-')}",
        ]
    return '\n'.join(lines)

def pscore_text() -> str:
    # 메인봇 /score와 같은 현재판 cache를 사용하되 paper 명령 이름으로 보여준다.
    txt = score_text()
    return txt.replace('📊 전략별 스코어 /score', '📊 paper 전략별 스코어 /pscore · 메인봇 캐시전용', 1)

def _pos_profit_pct(pos: Dict[str, Any]) -> float:
    for k in ('pnl_pct','profit_pct','current_profit_pct','unrealized_pct'):
        if pos.get(k) not in (None, ''):
            return fnum(pos.get(k), 0.0)
    entry = fnum(pos.get('entry_price'), 0.0)
    cur = fnum(pos.get('current_price') or pos.get('last_price'), 0.0)
    if entry > 0 and cur > 0:
        return (cur - entry) / entry * 100.0
    return 0.0

def _pos_entry_price(pos: Dict[str, Any]) -> str:
    v = pos.get('entry_price') or pos.get('entry') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_current_price(pos: Dict[str, Any]) -> str:
    v = pos.get('current_price') or pos.get('last_price') or pos.get('entry_price') or '-'
    try:
        fv = float(str(v).replace(',', ''))
        if fv >= 1000:
            return f"{fv:,.0f}"
        return f"{fv:.4f}"
    except Exception:
        return str(v)

def _pos_snapshot_flat(pos: Dict[str, Any]) -> Dict[str, Any]:
    ctx = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
    snap = ctx.get('entry_snapshot') if isinstance(ctx.get('entry_snapshot'), dict) else pos.get('entry_snapshot') if isinstance(pos.get('entry_snapshot'), dict) else {}
    vals: Dict[str, Any] = {}
    if isinstance(snap, dict):
        flat = snap.get('flat')
        if isinstance(flat, dict): vals.update(flat)
        for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
            g = snap.get(gname)
            if isinstance(g, dict):
                for k, v in g.items(): vals.setdefault(k, v)
    if isinstance(ctx, dict):
        for k, v in ctx.items(): vals.setdefault(k, v)
    for k, v in pos.items():
        if k not in vals and k not in {'entry_context','entry_snapshot'}:
            vals[k] = v
    return vals

def _pos_hold_sec(pos: Dict[str, Any]) -> float:
    for k in ('hold_sec','age_sec'):
        v = fnum(pos.get(k), default=-1.0)
        if v > 0:
            return v
    for k in ('opened_at','entry_ts','open_ts','opened_ts','created_at','start_ts'):
        v = pos.get(k)
        ts = fnum(v, default=0.0)
        if ts > 10_000_000_000:
            ts = ts / 1000.0
        if ts <= 0 and isinstance(v, str):
            try:
                # ISO/text time fallback. timezone 없는 서버 로컬 기준.
                ts = time.mktime(time.strptime(v[:19].replace('T',' '), '%Y-%m-%d %H:%M:%S'))
            except Exception:
                ts = 0.0
        if ts > 0:
            return max(0.0, now_ts() - ts)
    return 0.0

def popen_text() -> str:
    open_pos = _paper_open_positions()
    lines = ['📂 paper OPEN /popen · 메인봇 캐시전용']
    if not open_pos:
        return '\n'.join(lines + ['OPEN 없음'])
    rows = [p for p in open_pos.values() if isinstance(p, dict)]
    rows.sort(key=lambda p: fnum(p.get('opened_at') or p.get('entry_ts') or 0, 0), reverse=True)
    by_strategy = Counter(_paper_strategy_label(p) for p in rows)
    lines.append('전략별 OPEN: ' + ' / '.join(f'{k} {v}' for k, v in by_strategy.items()))
    for p in rows[:10]:
        t = _short_ticker(p.get('ticker') or p.get('symbol'))
        pnl = _pos_profit_pct(p)
        hold = _pos_hold_sec(p)
        vals = _pos_snapshot_flat(p)
        buy = vals.get('buy_ratio') or vals.get('micro_trade_buy_ratio_30') or '-'
        reason = p.get('reason') or p.get('entry_reason') or p.get('watch_note') or 'time_exit 대기'
        try: buy_txt = f"{float(buy):.2f}"
        except Exception: buy_txt = str(buy)
        lines.append(f"- ✅ {_paper_grade(p)}급 {t} / {_paper_strategy_label(p)} / 진입 {_pos_entry_price(p)} / 현재 {_pos_current_price(p)} / {pnl:+.2f}% / 보유 {int(hold//60)}분 {int(hold%60)}초 / 감시 {reason}")
        lines.append(f"  · 근거: 매수체결 {buy_txt} / 주의: {p.get('risk_label') or p.get('risk_tags') or '특이사항 없음'}")
    if len(rows) > 10:
        lines.append(f"- 나머지 {len(rows)-10}개는 paper_bot /popen 단독 또는 이후 full에서 확인")
    return '\n'.join(lines)


# =============================================================================
# v347: paper review canonical module
# - 기존 v341~v346에서 덧붙은 preview/missed_review override들을 제거하고
#   단일 canonical 경로로 재작성한다.
# - 목적: /preview가 어떤 필드 타입(dict/float/list/None)을 만나도 죽지 않게 하고,
#   놓친 후보 추적/손실 복기 판단을 한 곳에서만 수행한다.
# =============================================================================

def as_dict(v: Any) -> Dict[str, Any]:
    return v if isinstance(v, dict) else {}

def as_list(v: Any) -> List[Any]:
    if isinstance(v, list):
        return v
    if isinstance(v, tuple):
        return list(v)
    return []

def first_value(*vals: Any, default: Any = None) -> Any:
    for v in vals:
        if v is None or v == "":
            continue
        return v
    return default

def price_from_any(v: Any) -> float:
    """dict/float/int/str/list 어떤 형태든 current price 후보를 안전하게 숫자로 변환."""
    if isinstance(v, dict):
        return fnum(v.get('current_price'), v.get('price'), v.get('trade_price'), v.get('close'), v.get('last'), default=0.0)
    if isinstance(v, (int, float, str)):
        return fnum(v, default=0.0)
    return 0.0

def _event_ts(ev: Dict[str, Any]) -> float:
    row = as_dict(ev)
    return fnum(
        row.get('candidate_created_at'), row.get('source_created_at'), row.get('detected_ts'),
        row.get('event_ts'), row.get('created_at'), row.get('timestamp'), default=0.0
    )

def _primary_strategy_key(row: Dict[str, Any]) -> str:
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    strat = as_dict(snap.get('strategy'))
    candidates = [
        row.get('representative_strategy_key'), row.get('primary_strategy_key'), row.get('paper_strategy_key'),
        row.get('strategy_bucket_primary'), row.get('strategy_key'), row.get('strategy'), row.get('strategy_name'),
        row.get('strategy_label'), row.get('strategy_bucket_primary_label'),
        ctx.get('representative_strategy_key'), ctx.get('primary_strategy_key'), ctx.get('paper_strategy_key'),
        ctx.get('strategy_bucket_primary'), ctx.get('strategy_key'), ctx.get('strategy'), ctx.get('strategy_name'),
        ctx.get('strategy_bucket_primary_label'), strat.get('primary_key'), strat.get('primary_label')
    ]
    for v in candidates:
        text = str(v or '')
        if not text:
            continue
        if text in STRATEGY_LABELS:
            return text
        for k, label in STRATEGY_LABELS.items():
            if k in text or label in text or f'{label} S' in text:
                return k
    for vals in (
        row.get('multi_strategy_s'), row.get('strategy_bucket_keys'), ctx.get('multi_strategy_s'),
        ctx.get('strategy_bucket_keys'), strat.get('tags')
    ):
        for x in as_list(vals):
            text = str(x or '')
            if text in STRATEGY_LABELS:
                return text
            for k, label in STRATEGY_LABELS.items():
                if k in text or label in text:
                    return k
    return 'unknown'

def _paper_anchor_ts() -> float:
    c = _paper_score_cache_current()
    if isinstance(c, dict) and c:
        return fnum(c.get('anchor_ts'), c.get('current_anchor_ts'), default=0.0)
    a = load_json(FILES.get('score_anchor', BASE_DIR/'paper_bot_current_score_anchor.json'), {}) or {}
    return fnum(as_dict(a).get('anchor_ts'), default=0.0)

def _paper_current_closed_rows(max_lines:int=2600) -> List[Dict[str, Any]]:
    rows = read_jsonl(FILES.get('paper_closed', BASE_DIR/'paper_bot_closed.jsonl'), max_lines=max_lines)
    anchor = _paper_anchor_ts()
    if not anchor:
        return rows
    out=[]
    for r in rows:
        if not isinstance(r, dict):
            continue
        ts = fnum(r.get('closed_at'), r.get('closed_ts'), r.get('close_ts'), r.get('timestamp'), default=0.0)
        ots = fnum(r.get('opened_at'), r.get('entry_ts'), r.get('open_ts'), default=0.0)
        if max(ts, ots) >= anchor:
            out.append(r)
    return out

def _snapshot_flat(row: Dict[str, Any]) -> Dict[str, Any]:
    """entry_context/entry_snapshot nested group을 안전하게 평탄화한다."""
    row = as_dict(row)
    ctx = as_dict(row.get('entry_context'))
    snap = as_dict(row.get('entry_snapshot') or ctx.get('entry_snapshot'))
    vals: Dict[str, Any] = {}
    for gname in ('price_flow','position','money_flow','orderflow','risk','strategy'):
        g = as_dict(snap.get(gname))
        vals.update({k:v for k,v in g.items() if k not in vals})
    vals.update({k:v for k,v in ctx.items() if k not in vals and k != 'entry_snapshot'})
    vals.update({k:v for k,v in row.items() if k not in vals and k not in {'entry_context','entry_snapshot'}})
    return vals

def _loss_causes(row: Dict[str, Any]) -> List[str]:
    row = as_dict(row); ctx=_snapshot_flat(row)
    causes=[]
    pnl=fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    peak=fnum(row.get('peak_pct'), row.get('max_profit_pct'), row.get('max_pnl_pct'), default=0.0)
    trough=fnum(row.get('trough_pct'), row.get('min_profit_pct'), row.get('min_pnl_pct'), default=0.0)
    hold=fnum(row.get('hold_sec'), row.get('duration_sec'), default=0.0)
    spread=fnum(ctx.get('spread_pct'), default=-1.0)
    buy=fnum(ctx.get('buy_ratio'), ctx.get('micro_trade_buy_ratio_30'), ctx.get('buy_trade_ratio'), default=-1.0)
    buy_s=fnum(ctx.get('buy_ratio_1m'), ctx.get('micro_buy_ratio_sustain_1m'), ctx.get('buy_ratio_sustain'), default=-1.0)
    vwap=fnum(ctx.get('vwap_gap_pct'), default=999.0)
    ema=fnum(ctx.get('ema5_gap_pct'), ctx.get('ema_gap_pct'), default=999.0)
    ch3=fnum(ctx.get('change_3m'), ctx.get('price_change_3m'), default=999.0)
    ch5=fnum(ctx.get('change_5m'), ctx.get('price_change_5m'), default=999.0)
    if pnl < 0:
        if peak <= 0.10: causes.append('진입후반응없음(최고+0.1%이하)')
        elif peak <= 0.30: causes.append('반응약함(최고+0.3%이하)')
        if hold and hold <= 180: causes.append('초반빠른손실(3분이내)')
        if trough <= -0.70: causes.append('깊은역행')
    if spread >= 0.28: causes.append('스프레드넓음')
    if 0 <= buy < 0.65: causes.append('매수체결약함')
    if 0 <= buy_s < 0.60: causes.append('매수체결지속약함')
    if ctx.get('sell_pressure') or ctx.get('ask_wall_pressure') or ctx.get('sell_trade_pressure'):
        causes.append('매도압력')
    if vwap != 999.0 and vwap < -0.15: causes.append('VWAP아래')
    if ema != 999.0 and ema < -0.20: causes.append('EMA아래')
    if ch3 != 999.0 and ch5 != 999.0 and ch3 <= 0.05 and ch5 <= 0.10:
        causes.append('가격반응부족')
    if not any(k in ctx for k in ('change_3m','price_change_3m','vwap_gap_pct','buy_ratio','spread_pct')):
        causes.append('근거스냅샷부족')
    if not causes and pnl < 0:
        causes.append('기타손실')
    # 중복 제거, 순서 유지
    out=[]
    for c in causes:
        if c not in out: out.append(c)
    return out

def ploss_review_text() -> str:
    rows=_paper_current_closed_rows()
    losses=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)<0]
    wins=[r for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)>0]
    cc=Counter(); by={k:[] for k in STRATEGY_LABELS}; sc={k:Counter() for k in STRATEGY_LABELS}; unknown=[]
    for r in losses:
        key=_primary_strategy_key(r)
        if key not in STRATEGY_LABELS:
            unknown.append(r); key='unknown'
        by.setdefault(key,[]).append(r); sc.setdefault(key,Counter())
        for cause in _loss_causes(r):
            cc[cause]+=1; sc[key][cause]+=1
    lines=['🧯 손실 원인 복기 /ploss_review · 메인봇 캐시전용', '- 현재판 CLOSED 손실에서 공통 패배 패턴을 봅니다.', f'- 현재판 CLOSED {len(rows)}개 / 승리 {len(wins)}개 / 손실 {len(losses)}개 / 미분류손실 {len(unknown)}개', '', '[공통 손실 TOP]']
    if cc:
        for k,v in cc.most_common(10): lines.append(f'- ⚠️ {k}: {v}개')
    else:
        lines.append('- 아직 손실 표본 없음')
    lines += ['', '[전략별 손실 원인 · 대표전략 기준]']
    for k,label in STRATEGY_LABELS.items():
        sub=by.get(k,[]); tops=', '.join(f'{a} {b}' for a,b in sc.get(k,Counter()).most_common(3)) or '-'
        lines.append(f'- {label}: 손실 {len(sub)}개 / {tops}')
    if unknown:
        tops=', '.join(f'{a} {b}' for a,b in sc.get('unknown',Counter()).most_common(3)) or '-'
        lines.append(f'- 미분류: 손실 {len(unknown)}개 / {tops}')
    lines += ['', '[조건 설계 힌트]']
    if cc.get('진입후반응없음(최고+0.1%이하)',0) >= max(3, len(losses)*0.25): lines.append('- 진입 전/직후 가격반응 조건을 전략별로 넣을 가치가 큼')
    if cc.get('매수체결약함',0) or cc.get('매수체결지속약함',0): lines.append('- 매수체결 순간값보다 지속성 조건을 봐야 함')
    if cc.get('매도압력',0): lines.append('- 매도벽/매도체결압력은 공통 하드차단이 아니라 전략별 강도 조절 필요')
    if cc.get('근거스냅샷부족',0): lines.append('- 일부 구 OPEN/CLOSED는 snapshot 부족. 신규 snapshot CLOSED를 더 신뢰')
    return '\n'.join(lines)

def _market_price_map() -> Dict[str, Dict[str, Any]]:
    """시장 가격 map을 항상 dict 형태로 반환한다. 기존 float 반환 경로 제거."""
    out: Dict[str, Dict[str, Any]] = {}
    for p in (FILES['scanner_market'], FILES['feature'], FILES['orderflow']):
        obj=load_json(p,{}) or {}; rows=[]
        if isinstance(obj, list):
            rows=obj
        elif isinstance(obj, dict):
            for key in ('rows','items','data'):
                if isinstance(obj.get(key), list):
                    rows=obj.get(key); break
            if not rows and isinstance(obj.get('cache'), dict):
                for k,v in obj.get('cache',{}).items():
                    if isinstance(v,dict):
                        vv=dict(v); vv.setdefault('ticker',k); rows.append(vv)
        for r in rows or []:
            if not isinstance(r,dict):
                continue
            t=norm_ticker(r.get('ticker') or r.get('symbol') or r.get('market'))
            price=price_from_any(r)
            if t and price>0:
                cur=out.setdefault(t, {})
                cur['current_price']=price
                cur.setdefault('source', p.name)
    return out

def _candidate_norm(ev: Dict[str, Any]) -> Dict[str, Any]:
    row=dict(as_dict(ev))
    raw_id = first_value(row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), row.get('id'))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or 'UNKNOWN'
    sk=_primary_strategy_key(row) or 'strategy_s'
    ts=_event_ts(row) or now_ts()
    eid=str(raw_id or f"ev:{t}:{sk}:{int(ts//30)}")
    row['event_id']=eid; row['event_key']=eid
    row.setdefault('trace_id', eid); row.setdefault('handoff_id', eid); row.setdefault('candidate_uid', eid)
    if not raw_id:
        row.setdefault('event_id_origin','legacy_fallback')
    return row

def _candidate_keys(ev: Dict[str, Any]) -> set:
    row=_candidate_norm(ev); keys=set()
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','pos_id'):
        v=row.get(k)
        if v not in (None,'','-'): keys.add(str(v))
    t=norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    sk=_primary_strategy_key(row); ts=_event_ts(row)
    if t and sk and ts:
        keys.add(f'fb:{t}:{sk}:{int(ts//30)}')
        keys.add(f'fbm:{t}:{sk}:{int(ts//60)}')
    if t: keys.add(f'ticker:{t}')
    return keys

def _open_closed_candidate_keys():
    open_rows=[]
    try:
        op=load_json(BASE_DIR/'paper_open_positions.json',{})
        if isinstance(op,dict): open_rows=list(op.values())
    except Exception: pass
    closed_rows = _paper_current_closed_rows(max_lines=2600)
    open_keys=set(); closed_keys=set(); open_tickers=set()
    for p in open_rows:
        if isinstance(p,dict):
            open_keys |= _candidate_keys(p)
            t=norm_ticker(p.get('ticker') or p.get('market') or p.get('symbol')) or ''
            if t: open_tickers.add(t)
    for r in closed_rows:
        if isinstance(r,dict):
            closed_keys |= _candidate_keys(r)
            src=as_dict(r.get('source_event'))
            if src: closed_keys |= _candidate_keys(src)
    return open_keys, closed_keys, open_tickers



# v349: preview/missed_review/open-closed key canonical alias.
# 기존 pmissed_review 계열에서 _open_closed_keys 이름을 쓰는 경로와
# _open_closed_candidate_keys 이름을 쓰는 경로를 하나로 통일한다.
def _open_closed_keys():
    return _open_closed_candidate_keys()

def _merged_candidate_keys():
    rows=[]
    for name in ['paper_candidates_handoff_merged.jsonl','paper_candidates_latest.jsonl']:
        try: rows += read_jsonl(BASE_DIR/name, max_lines=500)
        except Exception: pass
    keys=set()
    for r in rows:
        if isinstance(r,dict): keys |= _candidate_keys(r)
    return keys

def _missed_reason(row: Dict[str,Any], merged_keys=None) -> str:
    row=_candidate_norm(row); nowv=now_ts(); reasons=[]
    keys=_candidate_keys(row); merged_keys=merged_keys if merged_keys is not None else _merged_candidate_keys()
    exp=fnum(row.get('expires_at'), default=0.0); ts=_event_ts(row)
    if exp and exp < nowv: reasons.append('handoff만료')
    if ts and nowv-ts>180: reasons.append('후보오래됨')
    if not (keys & merged_keys): reasons.append('paper미병합')
    ctx=as_dict(row.get('entry_context'))
    if not (row.get('micro_fresh') or ctx.get('micro_fresh')): reasons.append('micro미확인')
    if row.get('stale') or row.get('is_stale'): reasons.append('stale')
    if row.get('open_eligible') is False or row.get('paper_bot_open') is False: reasons.append('open_eligible_false')
    if row.get('event_id_origin') == 'legacy_fallback': reasons.append('구후보ID보정')
    if not reasons: reasons.append('paper미병합/만료확인')
    out=[]
    for r in reasons:
        if r not in out: out.append(r)
    return ','.join(out[:5])

def pmissed_review_text() -> str:
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1000),('paper_candidates_latest.jsonl',250)]:
        try: events += read_jsonl(BASE_DIR/name, max_lines=maxn)
        except Exception: pass
    market = _market_price_map()
    open_keys, closed_keys, open_tickers = _open_closed_candidate_keys()
    merged_keys = _merged_candidate_keys()
    seen=set(); missed=[]; watched=0; counter=Counter()
    for raw in events:
        if not isinstance(raw,dict): continue
        ev=_candidate_norm(raw); ts=_event_ts(ev)
        if anchor_ts and ts and ts<anchor_ts: continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol')) or ''
        if not t: continue
        keys=_candidate_keys(ev); dedupe=str(ev.get('event_id') or f'{t}:{_primary_strategy_key(ev)}:{int(ts//30) if ts else 0}')
        if dedupe in seen: continue
        seen.add(dedupe); watched+=1
        if (keys & closed_keys) or (keys & open_keys) or t in open_tickers: continue
        cur=market.get(t,{}) if isinstance(market,dict) else {}
        cur_price=price_from_any(cur)
        entry=fnum(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), default=0.0)
        if cur_price<=0 or entry<=0: continue
        gain=(cur_price-entry)/entry*100.0
        if gain>=0.70:
            why=_missed_reason(ev, merged_keys)
            for r in why.split(','):
                if r: counter[r]+=1
            rs=ev.get('reasons') or ev.get('final_entry_reasons') or []
            missed.append({'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy'), 'score':ev.get('score'), 'reasons':rs if isinstance(rs,list) else [], 'missed_reason':why})
    missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용','- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.',f'- 확인 후보 {watched}개 / 현재가 비교 가능 상승후보 {len(missed)}개','','[놓친 이유 추정 TOP]']
    if counter:
        for k,v in counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'),list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)

def preview_text() -> str:
    # 단일 canonical preview: loss + missed를 각각 보호 실행해 한쪽 오류가 전체를 죽이지 않게 한다.
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'❌ {title} 생성 오류: {exc.__class__.__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v348: missed trace / handoff canonical review
# - paper_bot_v0.91의 candidate_handoff_trace를 우선 사용한다.
# - 같은 ticker/전략의 중복 놓친 후보는 1개로 합친다.
# - 조건 판단 전, 왜 paper OPEN으로 이어지지 않았는지 추적한다.
# =============================================================================

def _v348_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []


def _v348_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for r in _v348_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        for k in [str(r.get('event_id') or ''), str(r.get('event_key') or ''), str(r.get('trace_id') or ''), str(r.get('handoff_id') or ''), f'{t}:{sk}']:
            if k and k != '-':
                out[k] = r
    return out


def _v348_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v348_trace_map()
    t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
    keys = [str(ev.get('event_id') or ''), str(ev.get('event_key') or ''), str(ev.get('trace_id') or ''), str(ev.get('handoff_id') or ''), str(ev.get('candidate_uid') or ''), f'{t}:{sk}']
    for k in keys:
        if k and k in trace_map:
            return trace_map[k]
    return {}


def _v348_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key) if isinstance(src, dict) else None
            if isinstance(v, list):
                vals += [str(x) for x in v if str(x)]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st = str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'


def missed_trace_text() -> str:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v348_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(8):
            icon = '✅' if k in {'open','closed'} else '⚠️' if k in {'expired','not_merged','merged_waiting_open'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    seen_risky=set(); shown=0
    for r in risky:
        t = norm_ticker(r.get('ticker'))
        sk = str(r.get('strategy_key') or r.get('strategy') or '-')
        key = f'{t}:{sk}:{r.get("status","-")}:{r.get("reason","-")}'
        if key in seen_risky:
            continue
        seen_risky.add(key); shown += 1
        lines.append(f"- ⚠️ {t} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
        if shown >= 10:
            break
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    elif len(seen_risky) < len(risky):
        lines.append(f'- 중복 후보 {len(risky)-len(seen_risky)}개는 묶어서 숨김')
    return '\n'.join(lines)


def pmissed_review_text() -> str:  # type: ignore[override]
    anchor_ts = _paper_anchor_ts()
    events=[]
    for name,maxn in [('paper_candidates.jsonl',1200),('paper_candidates_latest.jsonl',300)]:
        events += read_jsonl(BASE_DIR/name, max_lines=maxn)
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v348_trace_map()
    nowv=now_ts(); watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = ensure_event_id(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur = market.get(t, {})
        cur_price = price_from_any(cur)
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v348_trace_for_candidate(ev, trace_map)
        why = _v348_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old = by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 후보 archive/latest 중 OPEN/CLOSED로 이어지지 않았는데 이후 오른 코인을 봅니다.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(10):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:10]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 자주 오르는 패턴은 조건에서 죽이면 안 됨', '- paper미병합/만료/오래됨이 많으면 전략조건보다 handoff·진입타이밍 문제를 먼저 봅니다', '- 손실필터는 /ploss_review와 같이 봐야 합니다']
    return '\n'.join(lines)


def preview_text() -> str:  # type: ignore[override]
    parts=[]
    for title, fn in [('ploss_review', ploss_review_text), ('pmissed_review', pmissed_review_text)]:
        try:
            parts.append(fn())
        except Exception as exc:
            log_error(f'preview_{title}', exc)
            parts.append(f'⚠️ {title} 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)



# =============================================================================
# v354: main review canonical final layer
# v355: score cache version gate는 목록식 whitelist 대신 paper_bot_v0.86+ 숫자 판정으로 단일화
# - preview/missed_trace에서 이름 누락/중복 override가 다시 타지 않도록 최종 단일 함수를 둔다.
# - 전략/청산/자동매수에는 관여하지 않고, paper_bot_v0.92 trace/cache를 읽는 조회 전용이다.
# =============================================================================

def _v354_trace_rows() -> List[Dict[str, Any]]:
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    return [r for r in rows if isinstance(r, dict)] if isinstance(rows, list) else []

def _v354_trace_map() -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    priority = {'closed': 60, 'open': 55, 'picked': 50, 'merged_waiting_pick': 40, 'micro_wait': 35, 'not_merged': 25, 'expired': 10, 'skipped': 5}
    for r in _v354_trace_rows():
        t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
        sk = _primary_strategy_key(r) or str(r.get('strategy_key') or r.get('strategy') or '')
        ts = fnum(r.get('created_at') or r.get('updated_at'), default=0.0)
        keys = [r.get('event_id'), r.get('event_key'), r.get('trace_id'), r.get('handoff_id'), r.get('candidate_uid'), f'{t}:{sk}']
        for k in keys:
            k=str(k or '')
            if not k or k == '-':
                continue
            old = out.get(k)
            if old is None:
                out[k] = r
                continue
            old_score = priority.get(str(old.get('status') or ''), 0)
            new_score = priority.get(str(r.get('status') or ''), 0)
            old_ts = fnum(old.get('created_at') or old.get('updated_at'), default=0.0)
            # 같은 ticker:strategy 키에서 과거 expired가 최신 open/closed/picked를 덮지 못하게 한다.
            if (new_score, ts) > (old_score, old_ts):
                out[k] = r
    return out

def _v354_trace_for_candidate(ev: Dict[str, Any], trace_map: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    trace_map = trace_map or _v354_trace_map()
    row = _candidate_norm(ev)
    t = norm_ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
    sk = _primary_strategy_key(row) or str(row.get('strategy_key') or row.get('strategy') or '')
    keys = [row.get('event_id'), row.get('event_key'), row.get('trace_id'), row.get('handoff_id'), row.get('candidate_uid'), f'{t}:{sk}']
    for k in keys:
        k=str(k or '')
        if k and k in trace_map:
            return trace_map[k]
    return {}

def _v354_reason_from_trace(ev: Dict[str, Any], trace: Dict[str, Any], fallback: str = '') -> str:
    vals: List[str] = []
    for src in (trace, ev):
        if not isinstance(src, dict):
            continue
        for key in ('reason', 'missed_reason', 'status_reason'):
            v = src.get(key)
            if isinstance(v, list):
                vals += [str(x).strip() for x in v if str(x).strip()]
            elif v not in (None, '', '-'):
                vals += [x.strip() for x in str(v).split(',') if x.strip()]
    if fallback:
        vals += [x.strip() for x in str(fallback).split(',') if x.strip()]
    if trace:
        st=str(trace.get('status') or '')
        if st and st not in {'candidate','unknown'}:
            vals.append(st)
    out=[]
    for v in vals:
        if v and v not in out:
            out.append(v)
    return ','.join(out[:6]) if out else 'paper미병합/만료확인'

def missed_trace_text() -> str:  # type: ignore[override]
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = _v354_trace_rows()
    by_status = Counter(str(r.get('status') or 'unknown') for r in rows)
    reasons = Counter()
    for r in rows:
        for x in str(r.get('reason') or '').split(','):
            x=x.strip()
            if x: reasons[x]+=1
    lines = [
        '🧭 놓친 후보 추적 /missed_trace',
        '- strategy 후보 → handoff → paper 병합/OPEN/CLOSED 흐름을 추적합니다.',
        f"- trace age {age(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json')):.1f}s / rows {len(rows)} / version {obj.get('version','-') if isinstance(obj,dict) else '-'}",
        '', '[상태 TOP]'
    ]
    if by_status:
        for k,v in by_status.most_common(10):
            icon = '✅' if k in {'open','closed','picked'} else '⚠️' if k in {'expired','not_merged','merged_waiting_pick','micro_wait','skipped'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- trace 없음')
    lines += ['', '[이유 TOP]']
    if reasons:
        for k,v in reasons.most_common(10):
            icon = '⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 이유 없음')
    lines += ['', '[주의 후보 TOP]']
    risky = [r for r in rows if str(r.get('status') or '') not in {'open','closed'}]
    risky.sort(key=lambda r: (float(first_value(r.get('score'),0) or 0), float(first_value(r.get('created_at'),0) or 0)), reverse=True)
    for r in risky[:10]:
        lines.append(f"- ⚠️ {norm_ticker(r.get('ticker'))} / {r.get('strategy') or r.get('strategy_key','-')} / score {r.get('score','-')} / status {r.get('status','-')} / 이유 {r.get('reason','-')}")
    if not risky:
        lines.append('- 현재 주의 후보 없음')
    return '\n'.join(lines)

def _v358_recent_review_events() -> List[Dict[str, Any]]:
    """v358: /pmissed_review 기본판은 오래된 archive 전체를 다시 훑지 않는다.

    trace 수술 이후 기본 복기는 latest/handoff/actual trace 중심으로만 본다.
    archive 전체 재검사는 나중에 full 명령으로 분리할 대상이며, 기본 명령에서
    handoff만료/paper미병합을 과대표시하지 않게 한다.
    """
    events: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for name, maxn in [('paper_candidates_latest.jsonl', 250), ('paper_candidates_handoff_merged.jsonl', 300)]:
        for ev in read_jsonl(BASE_DIR/name, max_lines=maxn):
            if not isinstance(ev, dict):
                continue
            key = str(ev.get('event_id') or ev.get('event_key') or ev.get('candidate_uid') or '')
            t = norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
            ts = str(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('event_ts'), ''))
            sk = str(_primary_strategy_key(ev) or ev.get('strategy_key') or ev.get('strategy') or '')
            dk = key or f'{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(ev)
    # actual trace도 후보 추적 기준으로만 보강한다. 오래된 source/archive trace fallback은 쓰지 않는다.
    obj = load_json(FILES.get('candidate_handoff_trace', BASE_DIR/'paper_bot_candidate_handoff_trace.json'), {}) or {}
    rows = obj.get('rows') if isinstance(obj, dict) else []
    if isinstance(rows, list):
        for r in rows[:300]:
            if not isinstance(r, dict):
                continue
            key = str(r.get('event_id') or r.get('event_key') or r.get('candidate_uid') or r.get('trace_id') or '')
            t = norm_ticker(r.get('ticker') or r.get('market') or r.get('symbol'))
            ts = str(first_value(r.get('created_at'), r.get('candidate_created_at'), r.get('event_ts'), ''))
            sk = str(_primary_strategy_key(r) or r.get('strategy_key') or r.get('strategy') or '')
            dk = key or f'trace:{t}:{sk}:{ts}'
            if dk in seen:
                continue
            seen.add(dk)
            events.append(r)
    return events


def pmissed_review_text() -> str:  # type: ignore[override]
    """v358 기본 missed 복기.

    기본 명령은 latest/handoff/actual trace만 본다. archive 전체 재검사는 렉과
    과대표시를 만들 수 있으므로 기본 경로에서 제외한다.
    """
    anchor_ts = _paper_anchor_ts()
    events = _v358_recent_review_events()
    market = _market_price_map()
    open_ids, closed_ids, open_tickers = _open_closed_keys()
    trace_map = _v354_trace_map()
    watched=0; by_key: Dict[str, Dict[str, Any]] = {}; reason_counter=Counter()
    for raw in events:
        if not isinstance(raw, dict):
            continue
        ev = _candidate_norm(raw)
        ts = float(first_value(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('detected_ts'), ev.get('event_ts'), 0) or 0)
        if anchor_ts and ts and ts < anchor_ts:
            continue
        t=norm_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if not t:
            continue
        watched += 1
        keys=_candidate_keys(ev)
        if (keys & open_ids) or (keys & closed_ids) or t in open_tickers:
            continue
        cur_price = price_from_any(market.get(t, {}))
        entry = float(first_value(ev.get('entry_price'), ev.get('current_price'), ev.get('detected_price'), ev.get('price'), 0) or 0)
        if cur_price <= 0 or entry <= 0:
            continue
        gain = (cur_price-entry)/entry*100.0
        if gain < 0.70:
            continue
        trace = _v354_trace_for_candidate(ev, trace_map)
        why = _v354_reason_from_trace(ev, trace, _missed_reason(ev, set()))
        for x in why.split(','):
            if x: reason_counter[x]+=1
        sk = _primary_strategy_key(ev) or str(ev.get('strategy_key') or ev.get('strategy') or '')
        dedupe = f'{t}:{sk}'
        item = {'ticker':t,'gain':gain,'strategy':ev.get('strategy_bucket_primary_label') or ev.get('strategy_name') or ev.get('strategy') or trace.get('strategy'), 'score':ev.get('score') or trace.get('score'), 'reasons':ev.get('reasons') or ev.get('final_entry_reasons') or [], 'missed_reason':why, 'trace_status':trace.get('status','-') if trace else '-'}
        old=by_key.get(dedupe)
        if old is None or gain > float(old.get('gain',0)):
            by_key[dedupe]=item
    missed=list(by_key.values()); missed.sort(key=lambda x:x.get('gain',0), reverse=True)
    lines=['🔎 놓친 후보 복기 /pmissed_review · 메인봇 캐시전용', '- 기본 범위: latest/handoff/actual trace 중심. archive 전체 재검사는 기본에서 제외.', f'- 확인 후보 {watched}개 / 중복제거 상승후보 {len(missed)}개', '', '[놓친 이유 추정 TOP]']
    if reason_counter:
        for k,v in reason_counter.most_common(8):
            icon='⚠️' if k in {'paper미병합','handoff만료','후보오래됨','micro미확인','picked_not_opened'} else '❔'
            lines.append(f'- {icon} {k}: {v}개')
    else:
        lines.append('- 아직 분류할 상승후보 없음')
    lines += ['', '[이후 오른 후보 TOP]']
    if missed:
        for m in missed[:5]:
            rs=m.get('reasons') if isinstance(m.get('reasons'), list) else []
            lines.append(f"- {'⚠️' if m['gain']>=1.5 else '❔'} {m['ticker']} / +{m['gain']:.2f}% / {m.get('strategy','-')} / 점수 {m.get('score','-')} / 상태 {m.get('trace_status','-')} / 놓친이유 {m.get('missed_reason','-')} / 근거 {', '.join(map(str, rs[:3]))}")
    else:
        lines.append('- 아직 뚜렷한 놓친 상승후보 없음')
    lines += ['', '[판독]', '- 기본판에서 paper미병합/만료가 많으면 handoff·paper 병합 타이밍을 봅니다', '- 전략조건 수정은 score/trace가 정상 출력된 뒤 판단합니다']
    return '\n'.join(lines)


def _v358_trim_loss_preview(txt: str) -> str:
    lines = txt.splitlines()
    out: List[str] = []
    keep = True
    for ln in lines:
        if ln.startswith('[전략별 손실 원인'):
            keep = False
            continue
        if ln.startswith('[조건 설계 힌트]'):
            keep = True
        if keep:
            out.append(ln)
        if len(out) >= 18:
            break
    if '[전략별 손실 원인 · 대표전략 기준]' in txt:
        out += ['', '- 전략별 상세 손실은 /ploss_review에서 확인']
    return '\n'.join(out)


def preview_text() -> str:  # type: ignore[override]
    """v358 기본 preview 경량화.

    전체 상세를 반복 출력하지 않고 손실 TOP + missed 기본판만 묶는다.
    """
    parts=[]
    try:
        parts.append(_v358_trim_loss_preview(ploss_review_text()))
    except Exception as exc:
        log_error('preview_ploss_review', exc)
        parts.append(f'⚠️ ploss_review 출력 오류: {type(exc).__name__}: {exc}')
    try:
        parts.append(pmissed_review_text())
    except Exception as exc:
        log_error('preview_pmissed_review', exc)
        parts.append(f'⚠️ pmissed_review 출력 오류: {type(exc).__name__}: {exc}')
    return '\n\n'.join(parts)




# =============================================================================



def send(update, text: str) -> None:
    try:
        if len(text) > 3900:
            text = text[:3850] + "\n…(길어 일부만 표시)"
        update.message.reply_text(text)
    except Exception as exc:
        log_error('telegram_send', exc)


def heartbeat_loop():
    while True:
        try:
            update_brain_status('running')
        except Exception as exc:
            log_error('heartbeat', exc)
        time.sleep(10)

# =============================================================================
# v650: main_bot command trunk rebuild
# - 이전 v366~v649 tail/wrapper 명령어 덮어쓰기 구간을 잘라내고,
#   기본 명령은 아래 단일 본선으로만 연결한다.
# - main_bot은 candidate/score-review/paper runtime snapshot만 읽는다.
# - 조건/S등급/청산/paper 장부/자동매수는 변경하지 않는다.
# =============================================================================
V650_BUILD_LABEL = 'v675_open_hold_missed_info_priority_2026-06-03'
BOT_VERSION = '수익형 v2.13.490'


def _v650_int(*vals: Any, default: int = 0) -> int:
    for v in vals:
        try:
            if v is None or v == '':
                continue
            return int(float(str(v).replace(',', '')))
        except Exception:
            continue
    return default


def _v650_num(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == '':
                continue
            return float(str(v).replace(',', ''))
        except Exception:
            continue
    return default


def _v650_pct(v: Any, digits: int = 2) -> str:
    try:
        return f'{float(v):+.{digits}f}%'
    except Exception:
        return '-'


def _v650_load(path: Path, default: Any = None) -> Any:
    try:
        if not path or not path.exists():
            return default
        return json.loads(path.read_text(encoding='utf-8', errors='ignore'))
    except Exception:
        return default


def _v650_file_age(path: Path) -> float:
    try:
        return max(0.0, time.time() - path.stat().st_mtime)
    except Exception:
        return 999999.0


def _v650_read_candidate_rows(limit: int = 5000) -> List[Dict[str, Any]]:
    path = FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl')
    out: List[Dict[str, Any]] = []
    try:
        if not path.exists():
            return []
        with path.open('r', encoding='utf-8', errors='ignore') as f:
            for ln in f:
                if not ln.strip():
                    continue
                try:
                    obj = json.loads(ln)
                    if isinstance(obj, dict):
                        out.append(obj)
                except Exception:
                    pass
        if len(out) > limit:
            # 서버 보호용 안전상한. 화면 표시/집계 제한 목적이 아니다.
            out = out[-limit:]
    except Exception as exc:
        log_error('v650_read_candidate_rows', exc)
    return out


def _v650_stage(row: Dict[str, Any]) -> str:
    for k in ('stage', 'grade', 's_grade', 'paper_grade', 'signal_grade', 'candidate_stage'):
        s = str(row.get(k) or '').strip().upper()
        if s in ('S1', 'S2', 'S3'):
            return s
        if s in ('S', 'A'):
            return 'S1'
        if s in ('B', 'C'):
            return 'S3'
    return '미집계'


def _v650_ticker(row: Dict[str, Any]) -> str:
    for k in ('ticker', 'symbol', 'market', 'code'):
        s = str(row.get(k) or '').strip().upper()
        if not s:
            continue
        for pfx in ('KRW-', 'KRW_', 'BITHUMB:'):
            if s.startswith(pfx):
                s = s[len(pfx):]
        for suf in ('-KRW', '_KRW', '/KRW'):
            if s.endswith(suf):
                s = s[:-len(suf)]
        return s
    return '-'


def _v650_strategy(row: Dict[str, Any]) -> str:
    raw = str(row.get('strategy_label') or row.get('strategy_name') or row.get('strategy') or row.get('strategy_key') or '-').strip()
    maps = {
        'leader_flow_adaptive_hold_s': '주도흐름 유동보유',
        'money_reaccel_s': '돈흐름 재가속',
        'breakout_early_s': '돌파 초입',
        'sweep_vwap_recovery_s': '저점 VWAP 회복',
        'hot_rank_recheck_s': 'hot-rank 발견/재확인',
        'leader_momentum_s': '주도추세 지속',
    }
    return maps.get(raw, raw or '-')


def _v650_listify(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, list):
        out=[]
        for x in v:
            if isinstance(x, str): out.append(x)
            elif isinstance(x, dict): out += [str(y) for y in x.values() if y]
            elif x: out.append(str(x))
        return [x for x in out if x]
    if isinstance(v, dict):
        out=[]
        for k, val in v.items():
            if isinstance(val, (int, float)):
                if val: out.append(str(k))
            elif val:
                out.append(str(k) if val is True else f'{k}:{val}')
        return out
    s = str(v).strip()
    if not s:
        return []
    parts = re.split(r'[/,|]\s*|\s{2,}', s)
    return [p.strip() for p in parts if p.strip()]


def _v650_reasons(row: Dict[str, Any]) -> List[str]:
    keys = ('block_reasons','block_reason','reasons','reason','s1_block_reasons','s1_fail_reasons','why_not_s1','missing_info','recheck_reason')
    out: List[str] = []
    for k in keys:
        out += _v650_listify(row.get(k))
    return list(dict.fromkeys(out))


def _v650_risks(row: Dict[str, Any]) -> List[str]:
    keys = ('risk_tags','risk_tag','risks','risk','danger_tags','warning_tags')
    out: List[str] = []
    for k in keys:
        out += _v650_listify(row.get(k))
    # 이유 안에 위험 문구가 섞인 경우 보조로만 반영
    for r in _v650_reasons(row):
        if any(w in r for w in ('스프레드','미끄러','매도','윗꼬리','stale','오래','위험')):
            out.append(r)
    return list(dict.fromkeys(out))


def _v650_structures(row: Dict[str, Any]) -> List[str]:
    keys = ('structure_tags','structure_tag','structures','structure','entry_structure','entry_reason')
    out: List[str] = []
    for k in keys:
        out += _v650_listify(row.get(k))
    return list(dict.fromkeys(out))


def _v650_price_1m(row: Dict[str, Any]) -> Dict[str, Any]:
    cur = _v650_num(row.get('current_price'), row.get('price'), row.get('last_price'), default=0.0)
    prev = _v650_num(row.get('price_1m_ago'), row.get('prev_1m_price'), row.get('price_60s_ago'), default=0.0)
    chg = row.get('change_1m_pct')
    if chg is None:
        chg = row.get('price_chg_60s')
    chgf = _v650_num(chg, default=None) if chg is not None else None
    if chgf is None and cur and prev:
        try:
            chgf = (cur - prev) / prev * 100.0
        except Exception:
            chgf = None
    return {'ready': chgf is not None, 'chg': chgf if chgf is not None else 0.0, 'cur': cur, 'prev': prev}


def _v650_trigger(row: Dict[str, Any]) -> Tuple[float, float, float]:
    cur = _v650_num(row.get('current_price'), row.get('price'), default=0.0)
    trg = _v650_num(row.get('trigger_price'), row.get('entry_trigger_price'), row.get('planned_entry'), default=0.0)
    gap = _v650_num(row.get('trigger_gap_pct'), default=None) if row.get('trigger_gap_pct') is not None else None
    if gap is None and cur and trg:
        gap = (cur - trg) / trg * 100.0
    return cur, trg, gap if gap is not None else 0.0


def _v652_trigger_display(row: Dict[str, Any]) -> Tuple[float, str]:
    """후보 화면에서 방아쇠 0으로 gap을 계산하지 않는다.

    trigger_price가 없으면 진입타이밍 재료 누락으로 표시한다. 0원 방아쇠는
    정상 값이 아니므로 `gap +0.xx%` 같은 착시를 만들면 안 된다.
    """
    cur, trg, gap = _v650_trigger(row)
    if trg <= 0:
        return cur, '방아쇠 정보 없음 / gap 계산안함'
    return cur, f'방아쇠 {trg:g} / gap {gap:+.2f}%'


def _v650_stat_obj(obj: Any) -> Dict[str, Any]:
    if not isinstance(obj, dict):
        return {'n':0,'wins':0,'losses':0,'total':0.0,'avg':0.0}
    n = _v650_int(obj.get('n'), obj.get('count'), obj.get('trades'), obj.get('total_count'), obj.get('closed_count'), default=0)
    wins = _v650_int(obj.get('wins'), obj.get('win'), obj.get('profit_count'), default=0)
    losses = _v650_int(obj.get('losses'), obj.get('loss'), obj.get('loss_count'), default=max(0, n-wins))
    total = _v650_num(obj.get('total'), obj.get('sum'), obj.get('sum_pct'), obj.get('total_pct'), obj.get('total_pnl_pct'), obj.get('pnl_sum'), obj.get('profit_sum'), obj.get('profit_pct_sum'), default=0.0)
    avg = _v650_num(obj.get('avg'), obj.get('average'), obj.get('avg_pct'), obj.get('mean_pct'), default=(total/n if n else 0.0))
    return {'n':n,'wins':wins,'losses':losses,'total':total,'avg':avg}


def _v650_stat_line(label: str, st: Dict[str, Any]) -> str:
    n = _v650_int(st.get('n'), default=0)
    if n <= 0:
        return f'❔ {label}: 0전'
    wins = _v650_int(st.get('wins'), default=0)
    losses = _v650_int(st.get('losses'), default=max(0,n-wins))
    total = _v650_num(st.get('total'), default=0.0)
    avg = _v650_num(st.get('avg'), default=(total/n if n else 0.0))
    icon = '✅' if total > 0 else ('⚠️' if abs(total) < 0.05 else '❌')
    return f'{icon} {label}: {n}전 {wins}승 {losses}패 / 합산 {total:+.2f}% / 평균 {avg:+.2f}%'


def _v650_score() -> Dict[str, Any]:
    path = FILES.get('paper_score', BASE_DIR/'paper_bot_score_cache.json')
    obj = _v650_load(path, {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v650_review() -> Dict[str, Any]:
    """Review count view follows the paper score-review owner.

    v657: paper_bot v654+ already seals review_today_closed_count in
    paper_bot_score_cache.json from the same reconciled CLOSED rows as score.
    main_bot must not read a separate stale review count and create 0/1 drift.
    It may keep review summary_text from review cache, but the displayed count/schema
    comes from the score owner cache. No CLOSED ledger direct scan here.
    """
    score = _v650_score()
    review_obj: Dict[str, Any] = {}
    for path in (BASE_DIR/'paper_bot_trade_review_cache.json', BASE_DIR/'paper_bot_review_cache.json'):
        obj = _v650_load(path, None)
        if isinstance(obj, dict) and obj:
            review_obj = dict(obj)
            break
    if isinstance(score, dict) and str(score.get('schema') or '').startswith('paper_score_cache_v654'):
        owned_n = _v650_int(score.get('review_today_closed_count'), score.get('today_closed_count'), default=0)
        review_obj['today_closed_count'] = owned_n
        review_obj['schema'] = score.get('review_schema') or 'paper_review_spine_v657_score_owner_view'
        review_obj['source_owner'] = 'paper_score_cache.review_today_closed_count'
        review_obj['score_review_same_rows'] = True
        review_obj['updated_at'] = score.get('updated_at', review_obj.get('updated_at'))
        review_obj['updated_at_text'] = score.get('updated_at_text', review_obj.get('updated_at_text'))
        return review_obj
    return review_obj


def _v650_status() -> Dict[str, Any]:
    obj = _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
    return obj if isinstance(obj, dict) else {}


def _v650_open_count() -> int:
    obj = _v650_load(FILES.get('paper_open', BASE_DIR/'paper_bot_open.json'), [])
    if isinstance(obj, list): return len(obj)
    if isinstance(obj, dict):
        for k in ('open','OPEN','rows','positions'):
            if isinstance(obj.get(k), list): return len(obj.get(k))
        return _v650_int(obj.get('open_count'), obj.get('count'), default=0)
    return 0


def _v650_score_stats() -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    score = _v650_score()
    today = _v650_stat_obj(score.get('today_global_stats') or score.get('today') or {})
    r3 = _v650_stat_obj(score.get('recent_3h_stats') or score.get('recent_3h') or {})
    r6 = _v650_stat_obj(score.get('recent_6h_stats') or score.get('recent_6h') or {})
    # count mirror 보강
    if today['n'] == 0:
        today['n'] = _v650_int(score.get('today_closed_count'), default=0)
    return score, today, r3, r6


def _v651_pick_score_stat(score: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    """paper score cache 안의 여러 버전 key를 같은 성과 stat으로 읽는다.

    main_bot은 CLOSED 장부를 직접 훑지 않고, paper score cache에 이미 봉인된
    날짜창/rolling window 값만 표시한다.
    """
    if not isinstance(score, dict):
        return _v650_stat_obj({})
    for k in keys:
        v = score.get(k)
        if isinstance(v, dict):
            st = _v650_stat_obj(v)
            if st.get('n') or any(x in v for x in ('total','sum','sum_pct','total_pct','avg','wins','losses')):
                return st
    # date_stats 계열에서 어제 날짜를 찾는다.
    if 'yesterday' in keys or 'yesterday_stats' in keys or 'yesterday_global_stats' in keys:
        date_stats = score.get('date_stats') or score.get('daily_stats') or score.get('by_date')
        if isinstance(date_stats, dict):
            ymd = time.strftime('%Y-%m-%d', time.localtime(time.time() - 86400))
            for dk in (ymd, ymd.replace('-', ''), 'yesterday'):
                if isinstance(date_stats.get(dk), dict):
                    return _v650_stat_obj(date_stats.get(dk))
    return _v650_stat_obj({})


def _v651_score_windows() -> Dict[str, Any]:
    score, today, r3, r6 = _v650_score_stats()
    yesterday = _v651_pick_score_stat(
        score,
        'yesterday_global_stats', 'yesterday_stats', 'previous_day_stats',
        'prev_day_stats', 'last_day_stats', 'yesterday'
    )
    r24 = _v651_pick_score_stat(
        score,
        'recent_24h_stats', 'last_24h_stats', 'rolling_24h_stats',
        'recent_24h_global_stats', 'recent_24h', 'last_24h', 'stats_24h'
    )
    r24_note = ''
    if r24.get('n', 0) <= 0 and any((x.get('n', 0) > 0 for x in (today, r3, r6) if isinstance(x, dict))):
        # v653: main_bot에서 24h를 임시로 만들지 않는다. paper score cache가 주인이다.
        r24_note = '최근 24시간 source 없음 · paper score cache writer 연결 필요'
    try:
        hour = int(time.strftime('%H', time.localtime()))
    except Exception:
        hour = 99
    midnight_note = ''
    if today.get('n', 0) <= 0 and hour <= 3:
        midnight_note = '자정 이후라 오늘 전적은 0전일 수 있음 · 어제/최근 24시간을 같이 확인'
    return {'score': score, 'today': today, 'yesterday': yesterday, 'r3': r3, 'r6': r6, 'r24': r24, 'r24_note': r24_note, 'midnight_note': midnight_note}


def _v651_score_window_lines(compact: bool = True) -> List[str]:
    w = _v651_score_windows()
    lines = [
        _v650_stat_line('오늘', w['today']),
        _v650_stat_line('어제', w['yesterday']),
        _v650_stat_line('최근 24시간', w['r24']),
        _v650_stat_line('최근 3시간', w['r3']),
        _v650_stat_line('최근 6시간', w['r6']),
    ]
    if w.get('midnight_note'):
        lines.append(f"- 참고: {w['midnight_note']}")
    if w.get('r24_note'):
        lines.append(f"- 24h: {w['r24_note']}")
    return lines


def _v650_candidate_snapshot() -> Dict[str, Any]:
    rows = _v650_read_candidate_rows()
    stage = Counter(_v650_stage(r) for r in rows)
    reasons = Counter()
    risks = Counter()
    mats = Counter()
    stale = 0
    for r in rows:
        p = _v650_price_1m(r)
        if p['ready']:
            mats['1분가격 정상'] += 1
            if p['chg'] <= 0: mats['1분반응 0/음수'] += 1
            elif p['chg'] >= 0.35: mats['1분반응 통과'] += 1
            else: mats['1분반응 부족'] += 1
        else:
            mats['1분가격 없음'] += 1
        for x in _v650_reasons(r): reasons[x] += 1
        for x in _v650_risks(r): risks[x] += 1
        age_val = _v650_num(r.get('age'), r.get('source_age'), r.get('fresh_age'), r.get('candle_age'), default=0.0)
        if age_val >= 120 or any('stale' in x.lower() or '오래' in x for x in _v650_reasons(r)+_v650_risks(r)):
            stale += 1
    return {'rows': rows, 'counts': stage, 'reasons': reasons, 'risks': risks, 'materials': mats, 'stale': stale, 'file_age': _v650_file_age(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl'))}


def _v650_pipeline() -> Dict[str, Any]:
    snap = _v650_candidate_snapshot()
    rows = snap['rows']
    scanner = _v650_load(FILES.get('scanner_market', BASE_DIR/'clean_scanner_market_cache.json'), {}) or {}
    strategy_summary = _v650_load(FILES.get('strategy_summary', BASE_DIR/'clean_strategy_s_summary.json'), {}) or {}
    if isinstance(scanner, dict):
        krw = _v650_int(scanner.get('krw_universe'), scanner.get('krw_count'), scanner.get('row_count'), scanner.get('rows'), default=0)
        sc_rows = _v650_int(scanner.get('row_count'), scanner.get('rows'), scanner.get('count'), default=krw)
        market_all = scanner.get('market_all') or scanner.get('market_all_count') or scanner.get('all_count') or '확인필요'
    elif isinstance(scanner, list):
        krw = sc_rows = len(scanner); market_all = '확인필요'
    else:
        krw = sc_rows = 0; market_all = '확인필요'
    st = snap['counts']
    strategy_input = _v650_int(strategy_summary.get('strategy_input_count_v661'), strategy_summary.get('evaluated'), default=len(rows)) if isinstance(strategy_summary, dict) else len(rows)
    sealed_rows = _v650_int(strategy_summary.get('strategy_coverage_rows_v661'), strategy_summary.get('paper_latest_count'), default=len(rows)) if isinstance(strategy_summary, dict) else len(rows)
    trade_rows = _v650_int(strategy_summary.get('trade_candidate_rows_v661'), default=sealed_rows) if isinstance(strategy_summary, dict) else len(rows)
    return {
        'market_all': market_all or '확인필요', 'krw': krw or '확인필요', 'scanner': sc_rows or '확인필요',
        'strategy': strategy_input or len(rows), 'sealed': sealed_rows or len(rows), 'paper': trade_rows or len(rows), 'fresh': len(rows),
        'S1': int(st.get('S1',0)), 'S2': int(st.get('S2',0)), 'S3': int(st.get('S3',0)), 'uncat': int(st.get('미집계',0)),
    }


def _v650_pipeline_lines() -> List[str]:
    p = _v650_pipeline()
    return [
        f"✅ 후보 배관: KRW {p['krw']} → scanner {p['scanner']} → 전략입력 {p['strategy']} → canonical봉인 {p['sealed']} → paper후보 {p['paper']}",
        f"- 등급: S1 {p['S1']} / S2 {p['S2']} / S3 {p['S3']} / 미집계 {p['uncat']}",
        '- 후보 판단 rows 제한 없음 · paper후보와 전체 coverage rows를 분리 표시',
    ]


def _v650_counter_line(counter: Any, limit: int = 4) -> str:
    try:
        items = Counter(counter or {}).most_common(limit)
        return ' / '.join(f'{k} {v}' for k, v in items if v) or '-'
    except Exception:
        return '-'


def _v650_candidate_lines(limit_reasons: int = 4) -> List[str]:
    s = _v650_candidate_snapshot()
    c = s['counts']
    lines = [
        f"🚦 후보: S1 {int(c.get('S1',0))} / S2 {int(c.get('S2',0))} / S3 {int(c.get('S3',0))}",
        f"- 1분 가격: {_v650_counter_line(s['materials'], 4)}",
        f"- S1 막힘 TOP: {_v650_counter_line(s['reasons'], limit_reasons)}",
        f"- 위험 TOP: {_v650_counter_line(s['risks'], limit_reasons)}",
    ]
    if s['stale']:
        lines.append(f"- 정보 오래됨: {s['stale']}개")
    if int(c.get('S1',0)) <= 0:
        lines.append('📌 판독: 후보는 들어오지만 S1까지 못 올라감')
    return lines


def _v650_resource_lines() -> List[str]:
    r = resource_snapshot() or {}
    load = r.get('load') or [0,0,0]
    try:
        cores = os.cpu_count() or 1
        per = float(load[0]) / max(1, cores)
    except Exception:
        per = 0.0
    # psutil 없이도 최소한 load 기반 CPU 체감값을 %로 같이 보여준다.
    cpu_pct = _v650_num(r.get('cpu_percent'), r.get('cpu_pct'), r.get('cpu_used_pct'), default=None) if any(k in r for k in ('cpu_percent','cpu_pct','cpu_used_pct')) else None
    if cpu_pct is None:
        cpu_pct = min(100.0, per * 100.0 / 2.5) if per else 0.0
    cpu_icon = '⚠️' if (cpu_pct >= 85 or per >= 2.0) else '✅'
    disk = _v650_num(r.get('disk_used_pct'), default=0.0)
    mem = _v650_num(r.get('mem_used_pct'), default=0.0)
    return [
        f"{cpu_icon} CPU: {cpu_pct:.1f}% / load {load} / 코어당 {per:.2f}",
        f"{'⚠️' if disk >= 85 else '✅'} 디스크: {disk:.1f}% 사용 / 남음 {r.get('disk_free_gb','-')}GB",
        f"{'⚠️' if mem >= 85 else '✅'} 메모리: {mem:.1f}% 사용 / 여유 {r.get('mem_free_mb','-')}MB",
    ]


def _v650_worker_line() -> str:
    ok=warn=bad=0; tops=[]
    for k in WORKERS:
        try:
            w=worker_status(k); a=_v650_num(w.get('age'), default=999999)
            if not w.get('alive') and str(w.get('state')) == 'missing': bad += 1
            elif a >= 60: warn += 1
            else: ok += 1
            tops.append((a,k))
        except Exception:
            warn += 1
    tops = sorted(tops, reverse=True)[:3]
    return f"- worker: ✅ {ok} / ⚠️ {warn} / ❌ {bad} · TOP " + ' / '.join(f'{k} {a:.1f}s' for a,k in tops)


def _v652_latest_file(pattern: str) -> Optional[Path]:
    try:
        files = [p for p in BASE_DIR.glob(pattern) if p.is_file()]
        if not files:
            return None
        return max(files, key=lambda x: x.stat().st_mtime)
    except Exception:
        return None


def _v653_load_trace_file(name: str) -> Dict[str, Any]:
    try:
        obj = _v650_load(BASE_DIR / name, {})
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}


def _v653_ok(v: Any) -> str:
    if v is True or str(v).lower() in ('true','ok','sent_ok','success','✅'):
        return '✅'
    if v is False or str(v).lower() in ('false','error','send_error','❌'):
        return '❌'
    return '❔'


def _v650_hourly_lines() -> List[str]:
    # v653: paper_bot이 저장한 trace 파일을 직접 읽는다. main_bot은 상태문구를 임시 생성하지 않는다.
    st = _v650_status()
    h = _v653_load_trace_file('paper_bot_hourly_summary_trace.json') or (st.get('paper_hourly_summary_trace') if isinstance(st.get('paper_hourly_summary_trace'), dict) else {})
    raw = _v653_load_trace_file('paper_bot_hourly_raw_pack_trace.json') or (st.get('paper_hourly_raw_pack_trace') if isinstance(st.get('paper_hourly_raw_pack_trace'), dict) else {})

    def _target_ok(obj: Dict[str, Any], key: str) -> str:
        if key == 'paper':
            for k in ('paper_sent_ok','paper_ok','paper_sent','paper_room'):
                if k in obj: return _v653_ok(obj.get(k))
        if key == 'main':
            for k in ('main_sent_ok','main_ok','main_sent','main_room'):
                if k in obj: return _v653_ok(obj.get(k))
        targets = obj.get('send_targets') or obj.get('targets')
        if isinstance(targets, dict):
            t = targets.get(key) or targets.get(key + '_room') or {}
            if isinstance(t, dict):
                return _v653_ok(t.get('sent_ok') if 'sent_ok' in t else t.get('ok'))
        return '❔'

    def fmt(title: str, obj: Any) -> str:
        if not isinstance(obj, dict) or not obj:
            return f'- {title}: trace 없음'
        paper = _target_ok(obj, 'paper')
        main = _target_ok(obj, 'main')
        deleted = _v653_ok(obj.get('temp_deleted') if 'temp_deleted' in obj else obj.get('deleted') if 'deleted' in obj else obj.get('cleanup_ok'))
        ts = obj.get('updated_at_text') or obj.get('time') or obj.get('sent_at') or obj.get('created_at') or obj.get('ts') or '-'
        fn = obj.get('filename') or obj.get('file') or obj.get('path') or '-'
        result = obj.get('result') or obj.get('phase') or ''
        note = f' / {result}' if result else ''
        return f'- {title}: paper방 {paper} / main방 {main} / 삭제 {deleted} / {ts} / {Path(str(fn)).name if fn else "-"}{note}'

    out = [fmt('1시간 요약 알림', h), fmt('원문 묶음', raw)]
    if out[1].endswith('trace 없음'):
        latest = _v652_latest_file('paper_hourly_raw_pack_*.txt')
        if latest is not None:
            out[1] = f'- 원문 묶음: 최근파일 {latest.name} / trace 없음 / age {_v650_file_age(latest):.1f}s'
    if all('trace 없음' in x for x in out):
        return ['- 1시간 요약 trace 없음 · paper_bot trace 파일 미생성']
    return out

def _v650_closed_source_lines(limit: int = 5) -> List[str]:
    score = _v650_score()
    lines=[]
    allc = score.get('closed_source_counts') if isinstance(score.get('closed_source_counts'), dict) else {}
    todayc = score.get('today_source_counts') if isinstance(score.get('today_source_counts'), dict) else {}
    total_ledger = _v650_int(score.get('ledger_closed_count'), score.get('closed_ledger_count'), score.get('closed_total'), allc.get('ledger'), default=0)
    total_rec = _v650_int(score.get('recovered_closed_count'), score.get('alert_recovered_count'), allc.get('alert_trace_recovered'), default=0)
    today_ledger = _v650_int(score.get('today_ledger_count'), score.get('today_ledger_closed_count'), todayc.get('ledger'), default=0)
    today_rec = _v650_int(score.get('today_recovered_count'), score.get('today_alert_recovered_count'), todayc.get('alert_trace_recovered'), default=0)
    if total_ledger or total_rec or today_ledger or today_rec:
        lines.append(f'- CLOSED 원천 전체: 장부 {total_ledger} / 알림보강 {total_rec}')
        lines.append(f'- 오늘 CLOSED 원천: 장부 {today_ledger} / 알림보강 {today_rec}')
    recent = (
        score.get('recent_closed_source_trace') or score.get('recent_closed_source') or
        score.get('recent_closed_rows') or score.get('recent_closed') or []
    )
    if isinstance(recent, list) and recent:
        lines.append('[최근 CLOSED 원천]')
        for r in recent[-limit:]:
            if not isinstance(r, dict): continue
            extra=[]
            peak=_v650_num(r.get('max_profit_pct'), r.get('peak_profit_pct'), r.get('best_pct'), default=None) if any(k in r for k in ('max_profit_pct','peak_profit_pct','best_pct')) else None
            hold=_v650_num(r.get('hold_sec'), r.get('duration_sec'), default=None) if any(k in r for k in ('hold_sec','duration_sec')) else None
            post=_v650_num(r.get('post_close_10m_pct'), r.get('after_close_10m_pct'), r.get('post_close_max_pct'), default=None) if any(k in r for k in ('post_close_10m_pct','after_close_10m_pct','post_close_max_pct')) else None
            if peak is not None: extra.append(f'최고 {peak:+.2f}%')
            if hold is not None: extra.append(f'보유 {hold/60:.1f}분')
            if post is not None: extra.append(f'청산후 {post:+.2f}%')
            ex = (' / ' + ' / '.join(extra)) if extra else ''
            src = r.get('source') or ('알림보강' if r.get('reconciled_from_close_alert_trace') else '장부')
            lines.append(f"- {_v650_ticker(r)} {_v650_pct(_v650_num(r.get('pnl_pct'), r.get('profit_pct'), default=0.0))} / {_v650_strategy(r)} / {r.get('entry_build_key') or r.get('score_patch_version') or 'legacy_unknown'} / source {src}{ex}")
    else:
        lines.append('- 최근 CLOSED 원천 상세 없음 · paper score cache 확인 필요')
    return lines


def _v650_condition_snapshot() -> Dict[str, Any]:
    rows = _v650_candidate_snapshot()['rows']
    roles = Counter(); by: Dict[str, Counter] = {}; sealed=0; s2like=0; dup=Counter()
    for r in rows:
        role_obj = r.get('condition_roles') or r.get('role_buckets') or r.get('condition_role_buckets') or r.get('condition_role_spine')
        if isinstance(role_obj, dict):
            sealed += 1
            for k in ('hard_block','execution_gate','recheck','score_only','confirm_pass','display_only'):
                if _v650_listify(role_obj.get(k)):
                    roles[k] += 1
        else:
            # fallback: reason/tag 기반 진단. worker 봉인과 구분해서 표시한다.
            rs = _v650_reasons(r); rk = _v650_risks(r); stg = _v650_structures(r)
            if rk or any(any(w in x for w in ('스프레드','미끄러','매도','stale','오래')) for x in rs): roles['hard_block'] += 1
            if any(any(w in x for w in ('방아쇠','trigger','대기','미도달')) for x in rs): roles['execution_gate'] += 1
            if rs: roles['recheck'] += 1
            if stg: roles['score_only'] += 1
            if rs or rk or stg: roles['display_only'] += 1
        name = _v650_strategy(r); by.setdefault(name, Counter()); by[name]['rows'] += 1; by[name][_v650_stage(r)] += 1
        for k in ('hard_block','execution_gate','recheck','score_only','display_only'):
            if roles[k]: pass
        if _v650_stage(r)=='S3' and _v650_structures(r) and _v650_reasons(r): s2like += 1
        for x in _v650_risks(r)+_v650_reasons(r): dup[x] += 1
    return {'rows': len(rows), 'sealed': sealed, 'roles': roles, 'by': by, 's2like': s2like, 'dup': dup}


def _v650_batch_text() -> str:
    score, today, r3, r6 = _v650_score_stats(); review = _v650_review()
    review_n = _v650_int(review.get('today_closed_count'), review.get('today_count'), default=0)
    lines = [
        '📦 코인봇 요약 /batch · v661', '',
        *_v651_score_window_lines(),
        f"✅ score/review: {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count', review_n)}",
        '', *_v650_candidate_lines(4), '', *_v650_pipeline_lines(), '', '자원', *_v650_resource_lines(), '',
        '상세 보기: /candidate_reason · /version_score · /health · /condition_review'
    ]
    return '\n'.join(lines)


def _v650_health_text() -> str:
    score, today, _, _ = _v650_score_stats(); review=_v650_review(); st=_v650_status()
    lines = [
        '🧭 시스템 상태 /health · v661',
        f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}',
        f"- paper: {st.get('version','-')} / build {st.get('build','-')} / OPEN {_v650_open_count()}",
        f"- score/review: 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count', '-')}",
        '', _v650_worker_line(), '', '자원', *_v650_resource_lines(), '', '후보 cache', *_v650_pipeline_lines()[:2], '', '요약 알림', *_v650_hourly_lines()
    ]
    return '\n'.join(lines)


def _v650_version_score_text() -> str:
    score, today, r3, r6 = _v650_score_stats(); review=_v650_review()
    lines = [
        '📊 성과 /version_score · v661', '- 기준: OPEN 당시 수정버전. 현재 실행버전으로 과거 전적 덮지 않음.', '',
        *_v651_score_window_lines(),
        f"- cache: score {score.get('schema','-')} / review {review.get('schema','-')}", '', '전략별 오늘'
    ]
    strat = score.get('today_strategy_stats') if isinstance(score.get('today_strategy_stats'), dict) else {}
    if strat:
        items=[]
        for name,obj in strat.items():
            st=_v650_stat_obj(obj); items.append((st.get('total',0.0), name, st))
        for _, name, st in sorted(items, reverse=True)[:8]:
            lines.append(_v650_stat_line(str(name), st))
    else:
        lines.append('- 오늘 전략별 집계 없음')
    lines += ['', '최근 CLOSED 원천/알림', *_v650_closed_source_lines(6)]
    return '\n'.join(lines)



def _v666_trigger_shadow_visible_block() -> str:
    """Display-only consumer for trigger shadow benchmark.

    main reads strategy/review worker cache files only and prints the shadow
    queue/result near the top of /candidate_reason. No candidate/price
    recomputation here.
    """
    try:
        cand_path = BASE_DIR / 'clean_trigger_shadow_strategy_summary_v665.json'
        review_path = FILES.get('trigger_shadow_review', BASE_DIR/'clean_trigger_shadow_review_v665.json')
        cand = _v650_load(cand_path, {}) or {}
        rev = _v650_load(review_path, {}) or {}
        lines = ['[트리거 shadow 검증 · v666]']
        if isinstance(cand, dict) and cand:
            cage = _v650_file_age(cand_path) if cand_path.exists() else 9999.0
            srcs = cand.get('source_counts') if isinstance(cand.get('source_counts'), dict) else {}
            gaps = cand.get('gap_counts') if isinstance(cand.get('gap_counts'), dict) else {}
            lines.append(f"- 후보 cache: age {cage:.1f}s / 저장후보 {cand.get('candidate_count',0)} / 방식 current·near_0_10·near_0_30·actual_trigger")
            lines.append('- source TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(srcs).most_common(5)) if srcs else '-'))
            lines.append('- gap TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(gaps).most_common(5)) if gaps else '-'))
        else:
            lines.append('- 후보 cache 준비중: strategy_worker shadow 후보 파일 미생성/비어 있음')
        lines.append('[트리거 shadow 결과 · v666]')
        if isinstance(rev, dict) and rev:
            rage = _v650_file_age(review_path) if review_path.exists() else 9999.0
            vs = rev.get('variant_summary') if isinstance(rev.get('variant_summary'), dict) else {}
            def vline(key: str, label: str) -> str:
                st = vs.get(key) if isinstance(vs.get(key), dict) else {}
                if not st:
                    return f'- {label}: -'
                return f'- {label}: 진입 {st.get("entered",0)}/{st.get("total",0)} / avg max {float(st.get("avg_max_pct") or 0):+.2f}% / +0.3 {st.get("win_0_3_count",0)} / -0.3 {st.get("loss_0_3_count",0)}'
            lines.append(f"- 결과 cache: age {rage:.1f}s / active {rev.get('active_count',0)} / entered {rev.get('entered_count',0)} / pending {rev.get('pending_count',0)}")
            lines.append(vline('current_price', '현재가'))
            lines.append(vline('near_0_10', '방아쇠-0.10%'))
            lines.append(vline('near_0_30', '방아쇠-0.30%'))
            lines.append(vline('actual_trigger', '기존방아쇠'))
            top = rev.get('top_entered') if isinstance(rev.get('top_entered'), list) else []
            tops=[]
            for r in top[:5]:
                if not isinstance(r, dict):
                    continue
                tops.append(f"{r.get('ticker')} {r.get('variant')} max {float(r.get('max_pct') or 0):+.2f}% cur {float(r.get('current_pct') or 0):+.2f}%")
            lines.append('- TOP: ' + (' / '.join(tops) if tops else '-'))
        else:
            lines.append('- 결과 cache 준비중: review_worker가 후보 수집 후 다음 cycle부터 집계')
        lines.append('- 기준: shadow 검증만 표시. 실제 S1/OPEN/청산/자동매수 변경 없음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v666_trigger_shadow_visible_block', exc)
        return '[트리거 shadow 검증 · v666]\n- cache 읽기 실패'



def _v667_market_miss_visible_block() -> str:
    """v668 display-only consumer for whole-market missed-scan review.

    review_worker owns 3/5/10m follow-up. main_bot reads only the worker caches.
    This block also shows candidate/source counts so the user does not need to
    manually wait and guess whether the 10m review is running.
    """
    try:
        result_path = BASE_DIR / 'clean_market_miss_review_v667.json'
        cand_path = BASE_DIR / 'clean_market_miss_candidates_v667.json'
        state_path = BASE_DIR / 'clean_market_miss_state_v667.json'
        obj = _v650_load(result_path, {}) or {}
        cand = _v650_load(cand_path, {}) or {}
        state = _v650_load(state_path, {}) or {}
        lines = ['[전체 스캔 놓침 검증 · v668]']
        cand_rows = cand.get('rows') if isinstance(cand, dict) and isinstance(cand.get('rows'), list) else []
        cand_age = _v650_file_age(cand_path) if cand_path.exists() else 9999.0
        active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        active_rows = list(active.values()) if isinstance(active, dict) else []
        near_mature = sum(1 for r in active_rows if isinstance(r, dict) and float(r.get('age_sec') or 0) >= 120)
        lines.append(f"- 후보 cache: age {cand_age:.1f}s / 저장 {len(cand_rows)} / 추적중 {len(active_rows)} / 2분경과 {near_mature}")
        if isinstance(cand, dict):
            src_total = cand.get('source_total_count') or cand.get('canonical_source_count') or cand.get('candidate_count') or len(cand_rows)
            excl = cand.get('source_exclude_counts') if isinstance(cand.get('source_exclude_counts'), dict) else {}
            lines.append(f"- 저장범위: source {src_total} → 저장 {cand.get('candidate_count', len(cand_rows))} / 품질60+ {cand.get('quality_candidate_count',0)}")
            if excl:
                lines.append('- 저장제외 TOP: ' + ' / '.join(f'{k} {v}' for k, v in Counter(excl).most_common(5)))
        if not isinstance(obj, dict) or not obj:
            lines.append('- 결과 cache 준비중: review_worker가 3/5/10분 사후 가격을 자동 추적 중')
            lines.append('- 기준: 전체 canonical snapshot 사후검증. 실제 S1/OPEN/청산/자동매수 변경 없음.')
            return '\n'.join(lines)
        age = _v650_file_age(result_path) if result_path.exists() else 9999.0
        lines.append(f"- 결과 cache: age {age:.1f}s / tracking {obj.get('tracking_total',0)} / matured {obj.get('matured_count',0)} / 상승후보 {obj.get('rise_count',0)} / 진짜놓침 {obj.get('true_missed_count',0)}")
        buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
        lines.append('- 놓침분류 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(buckets).most_common(7)) if buckets else '-'))
        dec = obj.get('decision_counts') if isinstance(obj.get('decision_counts'), dict) else {}
        lines.append('- 판정 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(dec).most_common(6)) if dec else '-'))
        top = obj.get('top_risers') if isinstance(obj.get('top_risers'), list) else []
        tops=[]
        for r in top[:6]:
            if not isinstance(r, dict):
                continue
            tops.append(f"{r.get('ticker')} {r.get('initial_stage')} max {float(r.get('max_pct') or 0):+.2f}% / {r.get('miss_bucket')} / {r.get('miss_decision','-')}")
        lines.append('- 오른 후보 TOP: ' + (' / '.join(tops) if tops else '-'))
        true_missed = obj.get('true_missed_top') if isinstance(obj.get('true_missed_top'), list) else []
        miss=[]
        for r in true_missed[:5]:
            if not isinstance(r, dict):
                continue
            miss.append(f"{r.get('ticker')} max {float(r.get('max_pct') or 0):+.2f}% / {r.get('miss_bucket')} / {r.get('initial_reason','-')}")
        lines.append('- 진짜놓침 후보 TOP: ' + (' / '.join(miss) if miss else '-'))
        lane = obj.get('recheck_lane_counts') if isinstance(obj.get('recheck_lane_counts'), dict) else {}
        if lane:
            lines.append('- 재수집 lane TOP: ' + ' / '.join(f'{k} {v}' for k, v in Counter(lane).most_common(6)))
        lines.append('- 기준: scanner/feature/candle/orderflow/strategy/trigger 중 어디서 묻혔는지 사후 상승률로 검증. 실제 매수조건 변경 없음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v668_market_miss_visible_block', exc)
        return '[전체 스캔 놓침 검증 · v668]\n- cache 읽기 실패'

def _v666_strip_shadow_blocks(text: str) -> str:
    """Remove old shadow blocks from worker text so v666 top block is single source."""
    out=[]; skip=False
    for line in str(text or '').splitlines():
        if '[트리거 shadow 검증' in line or '[트리거 shadow 결과' in line:
            skip=True
            continue
        if skip and line.startswith('['):
            skip=False
        if not skip:
            out.append(line)
    return '\n'.join(out).strip()


def _v673_fast_quality_visible_block() -> str:
    """Display-only consumer for fast-quality paper experiment lane.

    strategy_worker owns candidate marking and writes clean_fast_quality_paper_lane_v669.json.
    paper_bot owns actual paper selection/open counters through status/handoff pick_stats.
    main_bot only reads those caches and prints the lane state.
    """
    try:
        path = BASE_DIR / 'clean_fast_quality_paper_lane_v669.json'
        obj = _v650_load(path, {}) or {}
        hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
        pst = _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
        pick = {}
        for src in (pst, hand):
            ps = src.get('pick_stats') if isinstance(src, dict) and isinstance(src.get('pick_stats'), dict) else {}
            if isinstance(ps, dict):
                pick.update(ps)
        lines = ['[고품질 빠른진입 paper 실험 · v673]']
        age = _v650_file_age(path) if path.exists() else 9999.0
        if isinstance(obj, dict) and obj:
            acc = obj.get('accepted_top') if isinstance(obj.get('accepted_top'), list) else []
            rej = obj.get('reject_reason_top') if isinstance(obj.get('reject_reason_top'), dict) else {}
            lines.append(f"- 후보 cache: age {age:.1f}s / accepted {obj.get('accepted_count',0)} / real_eligible false / BUY_READY false")
            if acc:
                tops=[]
                for x in acc[:6]:
                    if not isinstance(x, dict):
                        continue
                    tops.append(f"{x.get('ticker')} {x.get('stage')} Q{float(x.get('q') or 0):.1f} R{float(x.get('risk') or 0):.1f} gap {float(x.get('gap') or 0):+.2f}%")
                lines.append('- 후보 TOP: ' + (' / '.join(tops) if tops else '-'))
            else:
                lines.append('- 후보 TOP: -')
            lines.append('- 탈락 TOP: ' + (' / '.join(f'{k} {v}' for k, v in Counter(rej).most_common(6)) if rej else '-'))
        else:
            lines.append('- 후보 cache 준비중: strategy_worker가 clean_fast_quality_paper_lane_v669.json 생성 전')
        lines.append(
            '- paper 수신: seen {seen} / selected {sel} / limit_skip {lim} / hold {hold}'.format(
                seen=pick.get('fast_quality_paper_seen',0),
                sel=pick.get('selected_fast_quality_paper',0),
                lim=pick.get('fast_quality_paper_limit_skip',0),
                hold=pick.get('fast_quality_paper_final_hold', pick.get('paper_entry_hold', pick.get('paper_final_block',0))),
            )
        )
        last_hold = pick.get('last_fast_quality_paper_hold') or pick.get('last_paper_entry_hold')
        if isinstance(last_hold, dict) and last_hold:
            lines.append('- paper 최종보류: {ticker} / {reason}'.format(
                ticker=last_hold.get('ticker') or last_hold.get('market') or '-',
                reason=last_hold.get('reason') or last_hold.get('status') or '-'))
        lines.append(f"- paper version: {pst.get('version','-')} / build {pst.get('build','-')}")
        lines.append('- 기준: paper-only 실험 lane. 실제 자동매수/BUY_READY/청산조건 변경 없음.')
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v673_fast_quality_visible_block', exc)
        return '[고품질 빠른진입 paper 실험 · v673]\n- cache 읽기 실패'


def _v673_strip_fast_quality_blocks(text: str) -> str:
    out=[]; skip=False
    for line in str(text or '').splitlines():
        if '[고품질 빠른진입 paper 실험' in line or '[fast quality paper 실험' in line:
            skip=True
            continue
        if skip and line.startswith('['):
            skip=False
        if not skip:
            out.append(line)
    return '\n'.join(out).strip()

def _v657_worker_candidate_reason_text() -> str:
    """Read strategy_worker-rendered candidate reason text cache only.

    The coin-quality spine is produced by strategy_worker and written to
    clean_candidate_reason_text_cache.txt. main_bot is a consumer: no candidate
    resorting, no strategy recomputation, no output-side quality calculation.
    """
    txt_path = FILES.get('candidate_reason_text', BASE_DIR/'clean_candidate_reason_text_cache.txt')
    state_path = FILES.get('candidate_reason_text_state', BASE_DIR/'clean_candidate_reason_state_cache.json')
    state = _v650_load(state_path, {}) or {}
    try:
        if not txt_path.exists():
            return '🧭 후보 이유 /candidate_reason · v661\n\n❔ strategy_worker 후보 이유 text cache 준비중\n- main_bot은 후보를 재계산하지 않습니다. strategy_worker가 만든 cache만 읽습니다.'
        text = txt_path.read_text(encoding='utf-8', errors='ignore').strip()
        if not text:
            return '🧭 후보 이유 /candidate_reason · v661\n\n❔ strategy_worker 후보 이유 text cache 비어 있음'
        age_sec = _v650_file_age(txt_path)
        header = f'🧭 후보 이유 /candidate_reason · v661\n- source: strategy_worker text cache / age {age_sec:.1f}s / schema {state.get("schema", "-")}'
        # Avoid double title spam if worker text already starts with a candidate title.
        body = text
        if body.startswith('🧭'):
            body = '\n'.join(body.split('\n')[1:]).strip()
        body = _v666_strip_shadow_blocks(body)
        body = _v673_strip_fast_quality_blocks(body)
        shadow_block = _v666_trigger_shadow_visible_block()
        fast_block = _v673_fast_quality_visible_block()
        miss_block = _v667_market_miss_visible_block()
        if '[코인 종합품질' not in body:
            body += '\n\n[코인 종합품질]\n- 품질 block 미표시: strategy_worker_v0.150 이후 cache 갱신을 한 번 더 기다리거나 /gworker_state 확인 필요'
        merged = shadow_block + '\n' + fast_block + '\n' + miss_block + ('\n' + body if body else '')
        return header + ('\n' + merged if merged else '')
    except Exception as exc:
        log_error('v657_worker_candidate_reason_text', exc)
        return f'🧭 후보 이유 /candidate_reason · v661\n\n❌ 후보 이유 cache 읽기 실패: {exc.__class__.__name__}'


def _v650_candidate_reason_text() -> str:
    return _v657_worker_candidate_reason_text()


def _v650_condition_review_text() -> str:
    d=_v650_condition_snapshot(); roles=d['roles']; by=d['by']; dup=d['dup']
    lines = [
        '🧩 조건 역할 상세 /condition_review · v657',
        '- 조건값은 바꾸지 않고, 후보 row 역할 정보와 fallback 진단을 분리해서 봅니다.', '',
        f"전체 후보 {d['rows']}개 / worker 역할봉인 {d['sealed']}개",
        f"- ❌ 진짜 차단: {roles.get('hard_block',0)}",
        f"- ⚠️ 진입 대기: {roles.get('execution_gate',0)}",
        f"- 🔁 재확인 필요: {roles.get('recheck',0)}",
        f"- ✅ 구조/가점: {roles.get('score_only',0)}",
        f"- ✅ 확인 통과: {roles.get('confirm_pass',0)}",
        f"- ❔ 참고 태그: {roles.get('display_only',0)}", '',
        f"구조는 괜찮지만 확인/대기 부족: {d['s2like']}개", '', '전략별 요약'
    ]
    for name,c in sorted(by.items(), key=lambda kv: kv[1].get('rows',0), reverse=True)[:6]:
        lines.append(f"- {name}: {c.get('rows',0)}개 / S1 {c.get('S1',0)} · S2 {c.get('S2',0)} · S3 {c.get('S3',0)}")
    if dup:
        lines += ['', '참고/중복 태그 TOP', '- ' + _v650_counter_line(dup,5)]
    lines += ['', '판독', '- 공통층은 위험/실행만, 매수 논리는 전략별로 분리합니다. 조건 수치 변경은 별도 승인 후 진행합니다.']
    return '\n'.join(lines)


def _v650_paper_handoff_text() -> str:
    hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
    score,today,_,_=_v650_score_stats(); review=_v650_review()
    lines = [
        '📨 paper 전달 /paper_handoff · v661',
        f"- OPEN: {_v650_open_count()} / status age {_v650_file_age(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json')):.1f}s",
        f"- 후보선별: latest {hand.get('latest', hand.get('candidate_count','-'))} / fresh {hand.get('fresh', hand.get('fresh_count','-'))}",
        f"- score/review: 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}", '',
        *_v650_pipeline_lines(), '', *_v650_candidate_lines(4), '', '요약 알림', *_v650_hourly_lines()
    ]
    return '\n'.join(lines)


def _v650_pstatus_text() -> str:
    st=_v650_status(); score,today,_,_=_v650_score_stats(); review=_v650_review()
    trace = st.get('s1_flow') or st.get('s1_trace') or {}
    trace_line = f"- S1 흐름 trace: 감지 {trace.get('detected', trace.get('s1_detected',0))} / 선택 {trace.get('selected',0)} / 보류 {trace.get('deferred', trace.get('hold',0))} / micro대기 {trace.get('micro_wait',0)} / OPEN {_v650_open_count()} / drop {trace.get('drop',0)}" if isinstance(trace, dict) else '- S1 흐름 trace: 준비중'
    return '\n'.join([
        '🧪 paper 상태 /pstatus · v661',
        f"- paper: {st.get('version','-')} / build {st.get('build','-')}",
        f"- OPEN: {_v650_open_count()} / CLOSED누적 {st.get('closed_total', st.get('closed_count','-'))}",
        f"- score/review: 오늘 {score.get('today_closed_count', today['n'])} / {review.get('today_closed_count','-')}",
        '- fast paper: ' + (lambda _p: f"seen {_p.get('fast_quality_paper_seen',0)} / selected {_p.get('selected_fast_quality_paper',0)} / limit {_p.get('fast_quality_paper_limit_skip',0)} / hold {_p.get('fast_quality_paper_final_hold',0)}")((_v650_status().get('pick_stats') if isinstance(_v650_status().get('pick_stats'), dict) else {})), '',
        *_v650_candidate_lines(4), '', 'S1 선택/보류 trace', trace_line, '', '최근 CLOSED 원천/알림', *_v650_closed_source_lines(5)
    ])


def _v650_trade_review_text() -> str:
    obj = _v650_review()
    txt = obj.get('summary_text') or obj.get('text') or obj.get('report')
    if txt:
        return str(txt)[:3800]
    return '📊 전략 복기 /trade_review · v650\n- paper review cache summary_text 준비중\n- /version_score의 전략별 오늘 성과를 우선 확인하세요.'


def _v650_errorlog_text() -> str:
    p=FILES.get('brain_error', BASE_DIR/'clean_brain_error.log')
    try:
        if not p.exists() or p.stat().st_size <= 0:
            return '🧯 오류로그 /errorlog\n\n✅ 새 실행 중 오류 없음'
        txt=p.read_text(encoding='utf-8', errors='ignore').splitlines()
        recent=[x for x in txt if x.strip()][-8:]
        v650_err=[x for x in recent if 'v650' in x]
        if not v650_err:
            return '🧯 오류로그 /errorlog\n\n✅ 새 실행 중 오류 없음\n- 과거 오류 흔적 있음 / 최근 2개만 참고\n'+'\n'.join(recent[-2:])
        return '🧯 오류로그 /errorlog\n\n❌ 새 실행 이후 오류\n'+'\n'.join(v650_err[-4:])
    except Exception as exc:
        return f'🧯 오류로그 /errorlog\n- 오류로그 읽기 실패: {exc.__class__.__name__}'


def _v650_safe_body(txt: Any, limit: int = 1800) -> str:
    s=str(txt or '')
    return s if len(s) <= limit else s[:limit].rstrip() + '\n…(상세 생략)'


def _v650_batch_summary_text(cmds: List[str], outputs: Dict[str,str], timings: List[Dict[str,Any]], recv_delay: float, total_sec: float) -> str:
    lines=[
        '코인봇 최신 묶음 요약집 v654', f'- 생성: {now_text()}', f'- 메인봇: {BOT_VERSION} / {V650_BUILD_LABEL}',
        f'- batch 접수지연: {recv_delay:.2f}s / 처리합계: {total_sec:.2f}s', '', '[명령 시간표]'
    ]
    for t in timings:
        lines.append(f"- {'✅' if not t.get('error') else '❌'} /{t.get('name','?')}: {float(t.get('sec') or 0):.2f}s / {'OK' if not t.get('error') else 'ERR'}")
    lines += ['', '[빠른판독]', _v650_batch_text(), '', '[명령 출력 요약]']
    for name in cmds:
        lines += ['', f'[/{name}]', _v650_safe_body(outputs.get(name,''), 1800)]
    return '\n'.join(lines)


def _v650_send_summary_file(update: Any, text: str) -> str:
    path = BASE_DIR / f"coinbot_batch_summary_{time.strftime('%Y%m%d_%H%M%S')}.txt"
    sent=False
    try:
        path.write_text(text, encoding='utf-8')
        with path.open('rb') as fh:
            update.message.reply_document(document=fh, filename=path.name)
        sent=True
        return 'txt 전송완료 후 서버삭제'
    except Exception as exc:
        log_error('v652_batch_summary_send', exc)
        return f'txt 전송실패 {exc.__class__.__name__}'
    finally:
        if sent:
            try: path.unlink(missing_ok=True)
            except Exception as exc: log_error('v652_batch_summary_delete', exc)



# =============================================================================
# main_bot v2.13.490 / v674: real candidate board + fast handoff single-source display
# - main remains a cache consumer.  No candidate recalculation here.
# =============================================================================
def _v674_fast_handoff_visible_line() -> str:
    try:
        hpath = BASE_DIR / 'clean_fast_quality_paper_handoff_v674.json'
        obj = _v650_load(hpath, {}) or {}
        if not isinstance(obj, dict) or not obj:
            return '- 실제 handoff: cache 준비중'
        rows = obj.get('rows') if isinstance(obj.get('rows'), list) else []
        tops=[]
        for r in rows[:5]:
            if not isinstance(r, dict):
                continue
            tops.append(f"{r.get('ticker')} {r.get('stage')} Q{float(r.get('q') or 0):.1f} R{float(r.get('risk') or 0):.1f} gap {float(r.get('gap') or 0):+.2f}%")
        return f"- 실제 handoff: age {_v650_file_age(hpath):.1f}s / rows {obj.get('actual_handoff_count',0)} / " + (' / '.join(tops) if tops else '-')
    except Exception as exc:
        log_error('v674_fast_handoff_visible_line', exc)
        return '- 실제 handoff: 읽기 실패'

_v674_prev_fast_quality_visible_block = _v673_fast_quality_visible_block

def _v673_fast_quality_visible_block() -> str:  # type: ignore[override]
    txt = _v674_prev_fast_quality_visible_block()
    lines = str(txt or '').split('\n')
    # Rename block label while keeping existing content.
    if lines and '[고품질 빠른진입 paper 실험' in lines[0]:
        lines[0] = '[고품질 빠른진입 paper 실험 · v674]'
    insert_at = 1 if len(lines) > 1 else len(lines)
    lines.insert(insert_at, _v674_fast_handoff_visible_line())
    # Append raw/filter counters if paper_bot exposed them.
    try:
        hand = _v650_load(FILES.get('paperbot_handoff', BASE_DIR/'paper_bot_candidate_handoff_status.json'), {}) or {}
        pst = _v650_load(FILES.get('paper_status', BASE_DIR/'paper_bot_status.json'), {}) or {}
        pick = {}
        for src in (pst, hand):
            ps = src.get('pick_stats') if isinstance(src, dict) and isinstance(src.get('pick_stats'), dict) else {}
            if isinstance(ps, dict): pick.update(ps)
        raw = pick.get('fast_quality_paper_raw_rows')
        filt = pick.get('fast_quality_paper_filtered_rows')
        if raw is not None or filt is not None:
            lines.append(f"- paper latest 실제필터: raw_fast {raw or 0} / filtered_fast {filt or 0}")
    except Exception as exc:
        log_error('v674_fast_filter_stats_visible', exc)
    return '\n'.join(lines)


def _v674_short_reason(v: Any, max_len: int = 36) -> str:
    if isinstance(v, list):
        txt = ','.join(str(x) for x in v[:3])
    else:
        txt = str(v or '-')
    return txt if len(txt) <= max_len else txt[:max_len-1] + '…'

def _v674_miss_row_line(r: Dict[str, Any]) -> str:
    return (f"- {r.get('ticker','-')} {r.get('initial_stage','-')} "
            f"max {float(r.get('max_pct') or 0):+.2f}% / cur {float(r.get('current_pct') or 0):+.2f}% "
            f"/ {r.get('miss_bucket','-')} / Q{float(r.get('q') or r.get('quality') or 0):.1f} R{float(r.get('risk') or 0):.1f} "
            f"/ 이유 {_v674_short_reason(r.get('initial_reason') or r.get('reject_reason') or r.get('block_reason'))}")

def _v674_condition_suggestion(obj: Dict[str, Any]) -> List[str]:
    buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
    true_n = int(obj.get('true_missed_count') or 0)
    rise_n = int(obj.get('rise_count') or 0)
    lines = ['[조건 수정 후보 · v674]']
    if not buckets:
        lines.append('- 결과 부족: market miss review cache가 아직 비어 있음')
        return lines
    cov = int(buckets.get('coverage_buried',0)); feat = int(buckets.get('feature_late',0)); of = int(buckets.get('orderflow_late',0)); trig = int(buckets.get('trigger_wait_missed',0))
    lines.append(f"- 근거: 상승후보 {rise_n} / 진짜놓침 {true_n} / coverage {cov} / feature {feat} / orderflow {of} / trigger {trig}")
    if cov:
        lines.append('- coverage_buried 상승이 많음 → coverage rescue/S2 재확인 기준 후보. 단, 위험태그 낮은 종목만')
    if feat:
        lines.append('- feature_late 상승 존재 → feature urgent 배차 강화 후보')
    if of:
        lines.append('- orderflow_late 상승 존재 → micro/orderflow urgent 강화 후보')
    if trig:
        lines.append('- trigger_wait_missed 상승 존재 → trigger gap/near 진입은 별도 paper로 비교 후보')
    lines.append('- 실제 조건값 자동 변경 없음. 이 표 보고 다음 판에서 승인 후 수치 조정')
    return lines

def _v674_missed_candidates_text() -> str:
    try:
        obj = _v650_load(BASE_DIR/'clean_market_miss_review_v667.json', {}) or {}
        hand = _v650_load(BASE_DIR/'clean_fast_quality_paper_handoff_v674.json', {}) or {}
        if not isinstance(obj, dict): obj = {}
        lines = ['🧭 놓친 후보판 /missed_candidates · v675', '- 기준: review_worker 사후검증 cache만 읽음. main 재계산 없음.']
        lines.append(f"- tracking {obj.get('tracking_total',0)} / matured {obj.get('matured_count',0)} / 상승후보 {obj.get('rise_count',0)} / 진짜놓침 {obj.get('true_missed_count',0)}")
        buckets = obj.get('miss_bucket_counts') if isinstance(obj.get('miss_bucket_counts'), dict) else {}
        lines.append('- 분류 TOP: ' + (' / '.join(f'{k} {v}' for k,v in Counter(buckets).most_common(8)) if buckets else '-'))
        true_rows = obj.get('true_missed_top') if isinstance(obj.get('true_missed_top'), list) else []
        rise_rows = obj.get('top_risers') if isinstance(obj.get('top_risers'), list) else []
        lines += ['', '[진짜놓침 TOP]']
        lines += [_v674_miss_row_line(r) for r in true_rows[:10] if isinstance(r, dict)] or ['- 없음']
        lines += ['', '[아까운상승 TOP]']
        lines += [_v674_miss_row_line(r) for r in rise_rows[:10] if isinstance(r, dict)] or ['- 없음']
        # Bucket-specific top groups.
        for bucket, title in [('coverage_buried','coverage에 묻힌 상승'),('feature_late','feature 늦은 상승'),('orderflow_late','체결/orderflow 늦은 상승'),('risk_filter_candidate','위험필터 후보 상승')]:
            rows = [r for r in rise_rows if isinstance(r, dict) and str(r.get('miss_bucket')) == bucket]
            lines += ['', f'[{title}]']
            lines += [_v674_miss_row_line(r) for r in rows[:6]] or ['- 없음']
        hrows = hand.get('rows') if isinstance(hand, dict) and isinstance(hand.get('rows'), list) else []
        lines += ['', '[fast accepted 실제 handoff]']
        if hrows:
            for r in hrows[:8]:
                lines.append(f"- {r.get('ticker')} {r.get('stage')} Q{float(r.get('q') or 0):.1f} R{float(r.get('risk') or 0):.1f} gap {float(r.get('gap') or 0):+.2f}% / scan {r.get('scan_id','-')}")
        else:
            lines.append('- 없음')
        lines += ['', *_v674_condition_suggestion(obj)]
        return '\n'.join(lines)
    except Exception as exc:
        log_error('v674_missed_candidates_text', exc)
        return f'🧭 놓친 후보판 /missed_candidates · v675\n❌ cache 읽기 실패: {exc.__class__.__name__}'

COMMANDS = {
    'batch': _v650_batch_text,
    'health': _v650_health_text, 'core': _v650_health_text,
    'version_score': _v650_version_score_text, 'vscore': _v650_version_score_text,
    'candidate_reason': _v650_candidate_reason_text, 'reason': _v650_candidate_reason_text, 'why_s1': _v650_candidate_reason_text,
    'missed_candidates': _v674_missed_candidates_text, 'missed': _v674_missed_candidates_text,
    'condition_review': _v650_condition_review_text, 'condition': _v650_condition_review_text,
    'paper_handoff': _v650_paper_handoff_text, 'handoff': _v650_paper_handoff_text,
    'pstatus': _v650_pstatus_text, 'status': _v650_pstatus_text,
    'trade_review': _v650_trade_review_text, 'review': _v650_trade_review_text,
    'errorlog': _v650_errorlog_text,
}

# 호환용 이름도 단일 본선으로 재지정한다.
health_text = _v650_health_text
version_score_text = _v650_version_score_text
candidate_reason_text = _v650_candidate_reason_text
pstatus_text = _v650_pstatus_text
paper_handoff_text = _v650_paper_handoff_text
trade_review_text = _v650_trade_review_text
errorlog_text = _v650_errorlog_text


def batch_handler(update, context):  # type: ignore[override]
    try:
        msg_date=getattr(getattr(update,'message',None),'date',None)
        recv_delay = time.time() - msg_date.timestamp() if hasattr(msg_date,'timestamp') else 0.0
    except Exception:
        recv_delay = 0.0
    default_cmds=['batch','health','version_score','candidate_reason','condition_review','paper_handoff','pstatus','errorlog']
    cmds = getattr(context, 'args', None) or default_cmds
    cmds = [str(x).strip().lstrip('/') for x in cmds[:10] if str(x).strip()]
    stime=time.time(); timings=[]; outputs={}
    try: send(update, f'📦 자동 묶음 확인 · v661\n- 실행 {len(cmds)}개 / 접수지연 {recv_delay:.2f}s\n- worker 후보품질 text cache 소비 / score-review same rows 표시')
    except Exception: pass
    for i,name in enumerate(cmds,1):
        fn=COMMANDS.get(name); t0=time.time(); err=None
        if not fn:
            body=f'❌ /{name} 연결 없음'; err='no_handler'
        else:
            try: body=fn()
            except Exception as exc:
                body=f'❌ /{name} 오류 {exc.__class__.__name__}: {exc}'; err=f'{exc.__class__.__name__}: {exc}'; log_error(f'v650_batch_{name}', exc)
        sec=time.time()-t0; outputs[name]=body; timings.append({'name':name,'sec':sec,'error':err})
        try: send(update, f'[{i}/{len(cmds)}] /{name} ({sec:.2f}s / {"OK" if not err else "ERR"})\n{body}')
        except Exception as exc: log_error('v650_batch_send_step', exc)
    total=time.time()-stime
    try:
        status=_v650_send_summary_file(update, _v650_batch_summary_text(cmds, outputs, timings, recv_delay, total))
    except Exception as exc:
        status=f'txt 생성실패 {exc.__class__.__name__}'; log_error('v652_batch_summary_file', exc)
    mark='✅' if '전송완료' in status else '⚠️'
    del_mark='✅' if '서버삭제' in status else ('❌' if '전송완료' in status else '❔')
    try: send(update, f'📎 묶음 요약집\n- 전송: {mark} {status}\n- 임시파일 삭제: {del_mark}\n- 처리합계: {total:.2f}s')
    except Exception: pass


def make_handler(name: str):  # type: ignore[override]
    def h(update, context):
        try:
            txt=getattr(update.message,'text','') or ''
            lines=[x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
            if len(lines)>=2:
                context.args=lines[:12]
                return batch_handler(update, context)
            fn=COMMANDS.get(name)
            send(update, fn() if fn else f'❌ /{name} 연결 없음')
        except Exception as exc:
            log_error(f'cmd_{name}', exc); send(update, f'❌ /{name} 오류: {exc.__class__.__name__}: {exc}')
    return h


def text_router(update, context):  # type: ignore[override]
    try:
        txt=getattr(update.message,'text','') or ''
        lines=[x.strip().lstrip('/') for x in txt.splitlines() if x.strip().startswith('/')]
        if len(lines)>=2:
            context.args=lines[:12]
            return batch_handler(update, context)
    except Exception as exc:
        log_error('v652_text_router', exc)


def set_commands(updater):  # type: ignore[override]
    try:
        updater.bot.set_my_commands([
            BotCommand('batch','핵심 상태 묶음'), BotCommand('health','시스템 상태'),
            BotCommand('version_score','성과판'), BotCommand('trade_review','전략 복기'),
            BotCommand('candidate_reason','S1 못 가는 이유'), BotCommand('missed_candidates','놓친 후보판'), BotCommand('condition_review','조건 역할 상세'),
            BotCommand('paper_handoff','paper 전달 상태'), BotCommand('pstatus','paper 상태'),
            BotCommand('errorlog','오류 로그')])
    except Exception as exc:
        log_error('v652_set_commands', exc)


log_runtime('v654_score_review_same_rows_loaded')


def main():
    log_runtime(f'telegram_state=initializing version={BOT_VERSION} build={V650_BUILD_LABEL}')
    update_brain_status('initializing')
    if not TELEGRAM_TOKEN:
        print('TELEGRAM_TOKEN missing; worker hub status only')
        while True:
            update_brain_status('running_no_telegram'); time.sleep(5)
    updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
    dp = updater.dispatcher
    for name in COMMANDS:
        dp.add_handler(CommandHandler(name, make_handler(name)))
    dp.add_handler(CommandHandler('batch', batch_handler))
    if MessageHandler is not None and Filters is not None:
        dp.add_handler(MessageHandler(Filters.text & (~Filters.command), text_router))
    set_commands(updater)
    update_brain_status('running')
    threading.Thread(target=heartbeat_loop, daemon=True).start()
    updater.start_polling(drop_pending_updates=True)
    try:
        if CHAT_ID:
            updater.bot.send_message(chat_id=CHAT_ID, text=f'✅ 메인봇 시작 완료\n- 버전: {BOT_VERSION}\n- build: {V650_BUILD_LABEL}\n- 명령: /batch /health /version_score /candidate_reason /condition_review')
    except Exception as exc:
        log_error('v650_startup_notify', exc)
    log_runtime(f'{BOT_VERSION} telegram polling_started build={V650_BUILD_LABEL}')
    updater.idle()


# =============================================================================
# main_bot v675: missed candidate value display + info priority summary
# - main still reads worker caches only.
# - Show Q/R aliases and enough trigger/execution fields when review_worker provides them.
# =============================================================================
def _v675_miss_row_line(r: Dict[str, Any]) -> str:
    q = _v650_num(r.get('q'), r.get('quality'), r.get('coin_quality_score'), default=0.0)
    risk = _v650_num(r.get('risk'), r.get('execution_risk_score'), default=0.0)
    gap = r.get('trigger_gap_pct')
    gap_txt = f" / gap {float(gap):+.2f}%" if gap not in (None, '', '-') else ''
    exec_bits=[]
    for label,k in (('체결','buy_ratio'),('지속','buy_sustain_1m'),('스프','spread_pct'),('미끄','slippage_pct')):
        if r.get(k) not in (None,'','-'):
            try: exec_bits.append(f"{label} {float(r.get(k)):.2f}")
            except Exception: pass
    exec_txt = (' / ' + ', '.join(exec_bits[:4])) if exec_bits else ''
    return (f"- {r.get('ticker','-')} {r.get('initial_stage','-')} "
            f"max {float(r.get('max_pct') or 0):+.2f}% / cur {float(r.get('current_pct') or 0):+.2f}% "
            f"/ {r.get('miss_bucket','-')} / Q{q:.1f} R{risk:.1f}{gap_txt}{exec_txt} "
            f"/ 이유 {_v674_short_reason(r.get('initial_reason') or r.get('reject_reason') or r.get('block_reason'))}")

def _v674_miss_row_line(r: Dict[str, Any]) -> str:  # type: ignore[override]
    return _v675_miss_row_line(r)

if __name__ == "__main__":
    main()
