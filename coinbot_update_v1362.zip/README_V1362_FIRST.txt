v1362 old-base bridge contract boot seeder. No trading criteria change. Auto-buy OFF.
