from pathlib import Path
import importlib.util, tempfile

source=Path('strategy_worker_v1.033.py')
text=source.read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.033'" in text
assert '_v1037_trigger_occurrence__v1170_recovery' not in text
assert 'def _v1177_current_cycle_occurrence' in text
assert 'previous_active_v1177, read_state = _v925_read_gate_state()' in text
assert 'active: Dict[str, Dict[str, Any]] = {}' in text
assert 'apply_swing_entry_gate = apply_swing_entry_gate__v1177_current_cycle' in text

spec=importlib.util.spec_from_file_location('strategy_v1177',source)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
rec={'frozen_ts':1000.0,'trigger_occurrence_event_ts_v1170':1.0,'trigger_occurrence_decision_key_v1037':'old','s1_ready_ts_v1173':2.0,'trigger_side_v1037':'above'}
occ1,key1=mod._v1177_current_cycle_occurrence(rec,'market:TEST',110.0,100.0,2000.0)
assert occ1['event_ts']==2000.0 and occ1['prior_cycle_event_carried'] is False
assert 'trigger_occurrence_event_ts_v1170' not in rec and 'trigger_side_v1037' not in rec and 's1_ready_ts_v1173' not in rec
occ2,key2=mod._v1177_current_cycle_occurrence({'frozen_ts':2001.0},'market:TEST',110.0,100.0,2001.0)
assert key1 != key2 and occ2['event_ts']==2001.0
wait,key3=mod._v1177_current_cycle_occurrence({'frozen_ts':2002.0},'market:TEST',90.0,100.0,2002.0)
assert not key3 and wait['contract_ready'] is False

# Full gate: current plan/event must rebuild on the next cycle.
root=Path(tempfile.mkdtemp())
mod.V925_MINIMAL_GATE_STATE=root/'state.json'; mod.V925_MINIMAL_GATE_STATUS=root/'status.json'
ctx={'schema':'structure_context_v871','major_ready':True,'setup_ready':True,'execution_ready':True,'source_missing':False,
'execution_resistance':{'price':100.0,'source':'candle','source_key':'m5_execution_high','tf':'5m'},
'setup_support':{'price':95.0,'source':'candle','source_key':'m30_setup_support','tf':'30m'},
'major_support':{'price':90.0,'source':'candle','source_key':'h4_major_support','tf':'4h'},
'setup_resistance':{'price':110.0,'source':'candle','source_key':'h1_setup_resistance','tf':'1h'},
'major_resistance':{'price':120.0,'source':'candle','source_key':'h4_major_resistance','tf':'4h'}}
row={'ticker':'TEST','current_price':100.2,'structure_context_v871':ctx,
'candidate_input_coverage_v908':{'items':{'micro':{'state':'fresh'},'orderflow':{'state':'fresh'},'quote':{'state':'fresh'},'price_reaction':{'state':'fresh'}}},
'spread_pct':0.1,'entry_slippage_confirmed':True,'entry_slippage_owner':'orderflow_worker','entry_slippage_source':'best_ask_reference_orderflow_v1100','entry_slippage_est_pct':0.05,
'entry_build_key':'test-key','s_stage':'S1','candidate_grade':'S1','price_reaction_pct':0.2,'relative_strength_pct':1.0,'money_flow_score':70,'buy_ratio':0.7,'buy_sustain_1m':0.7}
out1,_=mod.apply_swing_entry_gate([dict(row)],1000.0)
out2,_=mod.apply_swing_entry_gate([dict(row)],1010.0)
assert out1[0]['s_stage']=='S1' and out2[0]['s_stage']=='S1'
assert out1[0]['swing_gate_decision_key_v977'] != out2[0]['swing_gate_decision_key_v977']
assert out1[0]['trigger_occurrence']['event_ts']==1000.0
assert out2[0]['trigger_occurrence']['event_ts']==1010.0
assert out2[0]['trigger_occurrence']['prior_cycle_event_carried_v1177'] is False
print('PASS')
