from pathlib import Path
import json, zipfile, hashlib, sys
zip_path=Path(sys.argv[1] if len(sys.argv)>1 else '/mnt/data/coinbot_update_v1177.zip')
assert zip_path.exists()
with zipfile.ZipFile(zip_path) as z:
    names=set(z.namelist())
    assert 'DEPLOY_BUNDLE.json' in names
    assert 'strategy_worker_v1.033.py' in names
    manifest=json.loads(z.read('DEPLOY_BUNDLE.json').decode('utf-8'))
    assert manifest['workers']['strategy']=='strategy_worker_v1.033.py'
    assert manifest.get('paper') is None
    source=z.read('strategy_worker_v1.033.py')
    assert hashlib.sha256(source).hexdigest()==manifest['source_sha256']['strategy_worker_v1.033.py']
    text=source.decode('utf-8')
    assert '_v1037_trigger_occurrence__v1170_recovery' not in text
    assert "VERSION = 'strategy_worker_v1.033'" in text
    assert "apply_swing_entry_gate = apply_swing_entry_gate__v1177_current_cycle" in text
    assert manifest['auto_buy'] is False
print('PASS')
