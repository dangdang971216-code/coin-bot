코인봇 v2101 · 수익 +2% 후 손실전환 최종방어

목적
- STAT·GRACY·WIKEN·D처럼 수익구간을 경험한 뒤 음수까지 반납하는 거래를 막는다.
- 기존 동적 trailing은 그대로 두고, 마지막 구멍만 막는 단일 안전막이다.
- NEW OPEN뿐 아니라 사용자가 승인한 현재 OPEN에도 같은 overlay를 1회 append한다.

본선 규칙
- 비용후 MFE가 +2.0% 이상이면 최종 안전막 ARMED
- 이후 비용후 현재손익이 0.0% 이하가 되면 첫 가용 Paper 청산평가에서 종료
- 기존 target·invalid·dynamic trailing·v2100 -4% guard는 우선순위와 수치 모두 유지
- +5% Runner 허용폭과 짧은 target 연장은 이번 버전에서 변경하지 않음

현재 OPEN
- 현재 OPEN 전체에 overlay를 append해 이미 +2%를 경험한 거래도 인식
- 적용 시점에 이미 음수인 거래는 다음 quote 평가에서 현재가 부근 청산 가능
- 과거 수익을 복구하는 기능은 아님

원장
- OPEN row에 overlay contract만 append
- 원래 계약은 그대로 유지
- change_verify_ledger·issue_ledger에 전환 수·ARMED·즉시대상 기록
- 과거 CLOSED/decision/exact 재작성 없음

서버 검수
- Guard: /gupgrade_bundle coinbot_update_v2101.zip 단독 후 /grelease_verify
- Paper: /pstatus, /popen, /perror
- Main: /open_book_audit, /version_score, /errorlog

자동매수 OFF
