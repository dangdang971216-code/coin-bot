v2202
- 원인: Main이 outcome 전체원장을 명령마다 직접 계산해 /trade_review·/version_score·TXT에서 최대 3회 반복.
- 수정: Review worker가 기존 outcome status에 계산본 1개를 미리 저장하고 모든 명령은 읽기만 함.
- health status는 건강상태만, outcome status는 분석값만 담당.
- 실제 상승 식미통과 / 입력·점수없음 / 통과후하락 / 점수구간을 분리.
- 상승예측식·후보·구조·Paper·청산·초기화·원장 변경 없음. 자동매수 OFF.
