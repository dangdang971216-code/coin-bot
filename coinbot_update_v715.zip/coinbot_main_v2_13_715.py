#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
coinbot_main_v2_13_715.py

TRUE REBUILD HUB
- Reads only cache/status files.
- Does not recalculate strategy, paper ledger, missed review, or score.
- No legacy command blocks, no tail override, no fallback computation chain.
"""
from __future__ import annotations

import json
import os
import time
import traceback
import shutil
from pathlib import Path
import re
from typing import Any, Dict, List, Callable
from collections import Counter

try:
    from telegram import BotCommand
    from telegram.ext import Updater, CommandHandler, MessageHandler, Filters
except Exception:
    BotCommand = None
    Updater = None
    CommandHandler = None
    MessageHandler = None
    Filters = None

BOT_VERSION = "수익형 v2.13.715"
BUILD_LABEL = "v715_errorlog_summary_trace_2026-06-04"
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", Path(__file__).resolve().parent))
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "").strip()

def ts() -> float:
    return time.time()

def fnum(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "":
            return default
        return float(str(v).replace(",", "").replace("%", ""))
    except Exception:
        return default

def load_json(name: str, default: Any = None) -> Any:
    path = BASE_DIR / name
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def read_text(name: str, default: str = "") -> str:
    path = BASE_DIR / name
    try:
        if not path.exists():
            return default
        return path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return default

def read_jsonl_tail(name: str, limit: int = 80) -> List[Dict[str, Any]]:
    path = BASE_DIR / name
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()[-limit:]
    except Exception:
        return []
    out = []
    for line in lines:
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                out.append(obj)
        except Exception:
            pass
    return out

def save_json(name: str, data: Any) -> None:
    try:
        p = BASE_DIR / name
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)
    except Exception:
        pass

def append_error(where: str, exc: Exception) -> None:
    row = {"ts": ts(), "where": where, "error": repr(exc), "trace": traceback.format_exc()[-2000:]}
    try:
        with (BASE_DIR / "main_bot_errorlog.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
    except Exception:
        pass

def age(v: Any) -> str:
    try:
        a = max(0.0, ts() - float(v))
        if a < 60:
            return f"{a:.1f}s"
        if a < 3600:
            return f"{a/60:.1f}m"
        return f"{a/3600:.1f}h"
    except Exception:
        return "-"

def age_text(v: Any) -> str:
    return age(v)

def stat_line(label: str, d: Dict[str, Any]) -> str:
    n = int(fnum(d.get("n") or d.get("total"), 0))
    wins = int(fnum(d.get("wins"), 0))
    losses = int(fnum(d.get("losses"), max(0, n - wins)))
    pnl = fnum(d.get("sum_pct") or d.get("pnl_sum") or d.get("sum"), 0)
    avg = fnum(d.get("avg_pct") or d.get("avg"), pnl / n if n else 0)
    icon = "✅" if n and pnl > 0 else ("❌" if n and pnl < 0 else "❔")
    return f"{icon} {label}: {n}전 {wins}승 {losses}패 / 합산 {pnl:+.2f}% / 평균 {avg:+.2f}%"

def resource() -> Dict[str, Any]:
    try:
        total, used, free = shutil.disk_usage(str(BASE_DIR))
    except Exception:
        total = used = free = 0
    mem_total = mem_avail = 0
    try:
        m = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            k, v = line.split(":", 1)
            m[k] = int(v.strip().split()[0]) * 1024
        mem_total = m.get("MemTotal", 0)
        mem_avail = m.get("MemAvailable", 0)
    except Exception:
        pass
    try:
        load = os.getloadavg()
    except Exception:
        load = (0, 0, 0)
    cores = os.cpu_count() or 1
    return {
        "load": list(load),
        "cores": cores,
        "cpu_pct": min(100.0, load[0] / cores * 100.0) if cores else 0.0,
        "disk_used_pct": used / total * 100 if total else 0.0,
        "disk_free_gb": free / 1024**3 if free else 0.0,
        "mem_used_pct": (mem_total - mem_avail) / mem_total * 100 if mem_total else 0.0,
        "mem_free_mb": mem_avail / 1024**2 if mem_avail else 0.0,
    }

def score_cache() -> Dict[str, Any]:
    return load_json("paper_bot_score_cache.json", {}) or {}

def strategy_summary() -> Dict[str, Any]:
    return load_json("clean_strategy_canonical_summary.json", {}) or {}

def paper_status() -> Dict[str, Any]:
    return load_json("paper_bot_status.json", {}) or {}

def candidate_summary() -> Dict[str, Any]:
    return strategy_summary()

def cleanup_state() -> Dict[str, Any]:
    return load_json("paper_bot_cleanup_state.json", {}) or {}

def open_rows() -> List[Dict[str, Any]]:
    data = load_json("paper_bot_open.json", {}) or {}
    if isinstance(data, list):
        return [r for r in data if isinstance(r, dict)]
    if isinstance(data, dict):
        pos = data.get("positions")
        if isinstance(pos, dict):
            return [r for r in pos.values() if isinstance(r, dict)]
        if isinstance(pos, list):
            return [r for r in pos if isinstance(r, dict)]
        return [r for r in data.values() if isinstance(r, dict) and ("symbol" in r or "ticker" in r)]
    return []

def period_lines(cache: Dict[str, Any]) -> List[str]:
    periods = cache.get("periods") or {}
    order = [("today", "오늘"), ("yesterday", "어제"), ("recent_24h", "최근 24시간"), ("recent_3h", "최근 3시간"), ("recent_6h", "최근 6시간")]
    out = []
    for key, label in order:
        out.append(stat_line(label, periods.get(key) or {}))
    return out

def menu_text() -> str:
    return """🧭 코인봇 명령어 메뉴 /menu · v715
- 목표: 평소 확인용 / 이상시 확인용 / 개발·상세용을 분리합니다.

[평소 5개만 보면 됨]
- /health: 봇 생존, worker 지연, CPU·메모리·디스크, cleanup, 손절초과 요약
- /score: 정식 S1 성과와 S2/S3 실험 성과 분리
- /stop_review: 손절이 기준대로 닫혔는지, 루프gap/가격age 원인 확인
- /strategy_review: 전략별 폐기·관찰·더보기 판단
- /errorlog: 새 오류 확인

[이상할 때]
- /pstatus: paper_bot 내부 상태와 fast paper 수신
- /popen: 현재 OPEN 목록
- /candidate_reason: 왜 S1이 안 나오는지
- /paper_handoff: strategy_worker → paper_bot 전달 상태

[개발·상세]
- /version_score: 버전 기준 성과
- /missed_candidates: 놓친 후보 사후검증
- /condition_review: 조건 역할/태그 상세

[표시 기준]
- 전체 KRW는 scanner가 가볍게 감시합니다.
- S3_watch는 관찰 가치 있는 후보만, coverage/raw는 전체시장 참고값입니다.
- 손절은 paper_bot OPEN 전용 루프가 주인입니다."""

def feature_map_text() -> str:
    return """🧩 코인봇 기능 지도 /feature_map · v715
- 기능은 가져가고, 구 wrapper/fallback/tail patch는 가져가지 않습니다.

[가져간 기능]
- 전체시장 스캔 cache 소비
- canonical row / S1·S2·S3_watch·coverage 분리
- paper handoff / OPEN / CLOSED / stop trace / score cache
- missed review / target routing / menu / health / score / stop_review / strategy_review
- cleanup / raw pack deletion status / resource 표시

[이식 금지]
- tail wrapper, fallback reader, 출력부 보정, alert_trace 과다복구, 중복 writer/reader

[주인]
- main_bot: cache 표시
- strategy_worker: 후보 판단/canonical
- paper_bot: OPEN/CLOSED/청산/score/cleanup
- review_worker: 놓친 후보
- target_router: 정밀대상 배차"""

def batch_text() -> str:
    sc = score_cache()
    ss = strategy_summary()
    counts = ss.get("counts") or {}
    stale = ss.get("stale") or {}
    r = resource()
    lines = ["📦 코인봇 요약 /batch · v715", ""]
    lines += period_lines(sc)
    lines += ["", f"🚦 실전후보: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3_watch {counts.get('S3_watch',0)}",
              f"- 전체시장 참고: raw {counts.get('raw',0)} / coverage·비후보 {counts.get('coverage',0)} / 제외 {counts.get('excluded',0)}",
              f"- 정보 오래됨: 실전후보 {stale.get('actionable',0)} / S1·S2 {stale.get('s1_s2',0)} / coverage참고 {stale.get('coverage',0)} / 전체 {stale.get('all',0)}"]
    block = ss.get("block_top") or []
    risk = ss.get("risk_top") or []
    if block:
        lines.append("- S1 막힘 TOP: " + " / ".join(f"{k} {v}" for k, v in block[:4]))
    if risk:
        lines.append("- 위험 TOP: " + " / ".join(f"{k} {v}" for k, v in risk[:4]))
    lines += ["📌 판독: coverage/raw는 후보가 아니라 전체시장 감시 흔적입니다.", "",
              f"✅ 후보 배관: KRW {counts.get('krw',0)} → scanner {counts.get('scanner',0)} → 전략입력 {counts.get('strategy_input',0)} → canonical봉인 {counts.get('canonical',0)} → 실전후보 {counts.get('actionable',0)} / coverage {counts.get('coverage',0)}",
              "", "자원",
              f"{'⚠️' if r['cpu_pct']>80 else '✅'} CPU: {r['cpu_pct']:.1f}% / load {[round(x,2) for x in r['load']]} / 코어당 {r['load'][0]/max(1,r['cores']):.2f}",
              f"{'⚠️' if r['disk_used_pct']>85 else '✅'} 디스크: {r['disk_used_pct']:.1f}% 사용 / 남음 {r['disk_free_gb']:.2f}GB",
              f"{'⚠️' if r['mem_used_pct']>85 else '✅'} 메모리: {r['mem_used_pct']:.1f}% 사용 / 여유 {r['mem_free_mb']:.1f}MB",
              "", "평소 보기: /menu → /health /score /stop_review /strategy_review /errorlog · 기능지도 /feature_map"]
    return "\n".join(lines)

def _recent_stop_counts(minutes: int = 30) -> Dict[str, Any]:
    rows = read_jsonl_tail("paper_bot_stop_overrun_trace.jsonl", 300)
    cutoff = ts() - minutes * 60
    recent = [r for r in rows if fnum(r.get("ts"), 0) >= cutoff]
    return {
        "n": len(recent),
        "loop_gap": sum(1 for r in recent if fnum(r.get("position_update_gap_sec"), 0) > 10),
        "price_age": sum(1 for r in recent if fnum(r.get("price_cache_age_sec"), 0) > 10),
    }

def health_text() -> str:
    r = resource()
    ps = paper_status()
    ss = strategy_summary()
    counts = ss.get("counts") or {}
    cleanup = cleanup_state()
    stop = ps.get("stop_overrun_summary") or {}
    recent_stop = _recent_stop_counts(30)
    worker_files = [
        ("scanner", "clean_scanner_status.json"),
        ("feature", "clean_feature_status.json"),
        ("candle", "clean_candle_status.json"),
        ("orderflow", "clean_orderflow_status.json"),
        ("risk", "clean_risk_status.json"),
        ("strategy", "clean_strategy_worker_status.json"),
        ("review", "clean_review_worker_status.json"),
        ("target", "clean_target_router_status.json"),
        ("paper", "paper_bot_status.json"),
    ]
    workers = []
    for name, fn in worker_files:
        st = load_json(fn, {}) or {}
        workers.append(f"{name}:{st.get('status','-')}/{age(st.get('ts'))}")
    raw = load_json("paper_bot_hourly_raw_pack_trace.json", {}) or {}
    batch_trace = load_json("main_bot_batch_summary_trace.json", {}) or {}
    return "\n".join([
        "🧭 시스템 상태 /health · v715",
        f"- 메인봇: {BOT_VERSION} / {BUILD_LABEL}",
        f"- paper: {ps.get('version','-')} / build {ps.get('build','-')} / OPEN {len(open_rows())}",
        "- worker: " + " · ".join(workers),
        "",
        "자원",
        f"{'⚠️' if r['cpu_pct']>80 else '✅'} CPU: {r['cpu_pct']:.1f}% / load {[round(x,2) for x in r['load']]} / 코어당 {r['load'][0]/max(1,r['cores']):.2f}",
        f"{'⚠️' if r['disk_used_pct']>85 else '✅'} 디스크: {r['disk_used_pct']:.1f}% 사용 / 남음 {r['disk_free_gb']:.2f}GB",
        f"{'⚠️' if r['mem_used_pct']>85 else '✅'} 메모리: {r['mem_used_pct']:.1f}% 사용 / 여유 {r['mem_free_mb']:.1f}MB",
        "",
        "후보 cache",
        f"✅ 후보 배관: KRW {counts.get('krw',0)} → scanner {counts.get('scanner',0)} → 전략입력 {counts.get('strategy_input',0)} → canonical봉인 {counts.get('canonical',0)} → 실전후보 {counts.get('actionable',0)} / coverage {counts.get('coverage',0)}",
        f"- 실전후보 등급: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3_watch {counts.get('S3_watch',0)} / 미집계 {counts.get('unknown',0)}",
        "",
        "정리/순환",
        f"- cleanup: {cleanup.get('status','-')} / age {age(cleanup.get('ts'))} / trace삭제 {cleanup.get('trace_deleted_lines',0)}줄 / 임시파일 {cleanup.get('tmp_deleted_files',0)}개",
        f"- score hot: 최근 {cleanup.get('score_hot_hours',24)}h 또는 tail {cleanup.get('score_hot_tail',420)} / CLOSED 원장 보존 {cleanup.get('ledger_preserved', True)}",
        f"- 손절초과 누적: {stop.get('n',0)}건 / 평균초과 {fnum(stop.get('avg_overrun'),0):+.2f}% / 최대초과 {fnum(stop.get('max_overrun'),0):+.2f}% / 루프gap의심 {stop.get('loop_gap_suspect',0)}",
        f"- 손절초과 최근30분: {recent_stop.get('n',0)}건 / 루프gap {recent_stop.get('loop_gap',0)} / 가격age {recent_stop.get('price_age',0)}",
        "",
        "요약 알림",
        f"- 명령어 요약집: 전송 {batch_trace.get('sent','❔')} / 삭제 {batch_trace.get('deleted','❔')} / {batch_trace.get('file','-')} / owner {batch_trace.get('owner','-')}",
        f"- 원문 묶음 삭제: {raw.get('deleted','❔')} / {raw.get('reason','-')} / owner {raw.get('owner','-')}",
    ])

def score_text() -> str:
    sc = score_cache()
    lines = ["📊 성과 /score · v715 정식/실험/원천 분리",
             "- 기준: paper_bot score cache만 읽음. main_bot 장부 직접조회 없음.",
             "- 정식 S1 성과와 S2/S3 실험 lane을 분리 표시. 전체합산은 참고값.",
             f"- cache schema: {sc.get('schema','-')} / owner {sc.get('owner','-')}",
             "", "[기간별 전체합산 · 참고]"]
    lines += period_lines(sc)
    lines.append("")
    by_grade = sc.get("by_grade") or {}
    if by_grade:
        lines.append("[등급별]")
        for g in ["S1", "S2", "S3", "S3_watch", "ALL"]:
            if g in by_grade:
                lines.append(stat_line(g, by_grade[g]))
        lines.append("")
    lines.append("[정식/비실험 전략 성과]")
    official = sc.get("official_by_strategy") or {}
    if official:
        for k, v in sorted(official.items(), key=lambda kv:fnum(kv[1].get("sum_pct"),0), reverse=True):
            lines.append(stat_line(k, v))
    else:
        lines.append("- 정식/비실험 전략 집계 없음")
    lines += ["", "[실험 lane 성과 · 자동매수/B​UY_READY 대상 아님]"]
    exp = sc.get("experiment_by_strategy") or {}
    if exp:
        for k, v in sorted(exp.items(), key=lambda kv:fnum(kv[1].get("sum_pct"),0)):
            lines.append(stat_line(k, v))
    else:
        lines.append("- 실험 lane 집계 없음")
    interp = sc.get("interpretation") or []
    if interp:
        lines += ["", "[해석]"] + [f"- {x}" for x in interp[:6]]
    return "\n".join(lines)

def stop_review_text() -> str:
    ps = paper_status()
    summ = ps.get("stop_overrun_summary") or {}
    recent = _recent_stop_counts(30)
    rows = read_jsonl_tail("paper_bot_stop_overrun_trace.jsonl", 120)
    lines = ["🛑 손절 해석 /stop_review · v715",
             "- 기준: paper_bot_stop_overrun_trace.jsonl만 읽음. 손절/청산값 변경 없음.",
             f"- 누적 손절초과 {summ.get('n',len(rows))}건 / 정식 {summ.get('official',0)} / 실험 {summ.get('experiment',0)} / 미분류 {summ.get('unknown',0)}",
             f"- 최근30분 손절초과 {recent.get('n',0)}건 / 루프gap {recent.get('loop_gap',0)} / 가격age {recent.get('price_age',0)}",
             f"- 누적 평균초과 {fnum(summ.get('avg_overrun'),0):+.2f}% / 최대초과 {fnum(summ.get('max_overrun'),0):+.2f}%",
             "", "최근 상세"]
    if not rows:
        lines.append("- 손절초과 trace 없음")
    for r in rows[-12:][::-1]:
        lane = "실험" if r.get("is_experiment") or r.get("lane")=="experiment" else ("정식" if r.get("lane")=="official" else "미분류")
        sym = r.get("symbol") or r.get("ticker") or "-"
        strat = r.get("strategy_name") or r.get("strategy") or "-"
        flags = r.get("flags") or []
        if isinstance(flags, list):
            flags = ",".join(flags)
        lines.append(f"- {sym} / {lane} / {strat} / 기준 {fnum(r.get('stop_loss_pct'),-0.55):+.2f}% → 실제 {fnum(r.get('pnl_pct'),0):+.2f}% / 초과 {fnum(r.get('overrun_pct'),0):+.2f}% / age {fnum(r.get('price_cache_age_sec'),0):.1f}s / gap {fnum(r.get('position_update_gap_sec'),0):.1f}s / {r.get('exit_reason','-')} / {flags}")
    lines += ["", "판독", "- 최근30분이 0이면 현재 새 손절초과는 추가되지 않는 상태입니다.", "- 루프gap이 많으면 손절선 문제가 아니라 OPEN 청산검사 지연 문제입니다.", "- 미분류가 많으면 closed/alert trace에 strategy/lane 봉인이 빠진 것입니다."]
    return "\n".join(lines)

def strategy_review_text() -> str:
    sc = score_cache()
    ss = strategy_summary()
    ps = paper_status()
    lines = ["🧭 전략별 문제판 /strategy_review · v715",
             "- 기준: paper_bot score cache + strategy summary만 읽음. 조건값 재계산 없음.", "",
             "[정식/비실험 전략]"]
    official = sc.get("official_by_strategy") or {}
    if official:
        for k, v in sorted(official.items(), key=lambda kv:fnum(kv[1].get("sum_pct"),0), reverse=True):
            label = "더보기" if fnum(v.get("sum_pct"),0)>0 else "주의"
            lines.append(f"- {label}: {stat_line(k, v)}")
    else:
        lines.append("- 정식/비실험 전략 집계 없음")
    lines += ["", "[실험 lane]"]
    exp = sc.get("experiment_by_strategy") or {}
    if exp:
        for k, v in sorted(exp.items(), key=lambda kv:fnum(kv[1].get("sum_pct"),0)):
            label = "중지/폐기검토" if fnum(v.get("sum_pct"),0)<0 else "관찰"
            lines.append(f"- {label}: {stat_line(k, v)}")
    else:
        lines.append("- 실험 lane 없음")
    block = ss.get("block_top") or []
    risk = ss.get("risk_top") or []
    stop = ps.get("stop_overrun_summary") or {}
    lines += ["", "[현재 후보 막힘 TOP]",
              "- S1 막힘: " + (" / ".join(f"{k} {v}" for k,v in block[:5]) if block else "-"),
              "- 위험: " + (" / ".join(f"{k} {v}" for k,v in risk[:5]) if risk else "-"),
              "", "[손절/운영 참고]",
              f"- 손절초과 {stop.get('n',0)}건 / 가격age의심 {stop.get('price_age_suspect',0)} / 루프gap의심 {stop.get('loop_gap_suspect',0)}",
              "", "판독",
              "- 전략 조건을 바꾸기 전, 실험 lane 성과와 정식 S1 성과를 분리해서 봅니다."]
    return "\n".join(lines)

def pstatus_text() -> str:
    ps = paper_status()
    ss = strategy_summary()
    counts = ss.get("counts") or {}
    fast = ps.get("fast_paper") or {}
    return "\n".join([
        "🧪 paper 상태 /pstatus · v715",
        f"- paper: {ps.get('version','-')} / build {ps.get('build','-')}",
        f"- OPEN: {len(open_rows())} / CLOSED누적 {ps.get('closed_count',0)}",
        f"- fast paper: seen {fast.get('seen',0)} / selected {fast.get('selected',0)} / limit {fast.get('limit_skip',0)} / hold {fast.get('hold',0)}",
        "",
        f"🚦 실전후보: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3_watch {counts.get('S3_watch',0)}",
        f"- 전체시장 참고: raw {counts.get('raw',0)} / coverage·비후보 {counts.get('coverage',0)}",
    ])

def popen_text() -> str:
    rows = open_rows()
    lines = ["📂 paper OPEN /popen · v715 캐시전용", "- 기준: paper_bot OPEN cache만 읽음. main_bot 장부 직접조회 없음.", f"- OPEN {len(rows)}개"]
    if not rows:
        lines.append("- 현재 OPEN 없음")
        return "\n".join(lines)
    cnt = Counter(str(r.get("grade") or r.get("stage") or "-") for r in rows)
    lines.append("OPEN 등급: " + " / ".join(f"{k} {v}" for k,v in cnt.items()))
    for r in rows[:15]:
        sym = r.get("symbol") or r.get("ticker") or "-"
        lane = "실험" if r.get("is_experiment") or r.get("lane")=="experiment" else "정식"
        strat = r.get("strategy_name") or r.get("strategy") or "-"
        entry = fnum(r.get("entry_price"),0)
        cur = fnum(r.get("current_price") or r.get("last_price"), entry)
        pnl = fnum(r.get("pnl_pct"), (cur/entry-1)*100 if entry else 0)
        lines.append(f"- {sym} / {lane} / {strat} / 진입 {entry:g} → 현재 {cur:g} / {pnl:+.2f}%")
    if len(rows)>15:
        lines.append(f"- 나머지 {len(rows)-15}개 생략")
    return "\n".join(lines)

def candidate_reason_text() -> str:
    txt = read_text("clean_candidate_reason_text_cache.txt", "")
    if txt.strip():
        return "🧭 후보 이유 /candidate_reason · v715\n- source: strategy_worker cache\n" + txt[:3600]
    ss = strategy_summary()
    lines = ["🧭 후보 이유 /candidate_reason · v715", "- source: strategy canonical summary"]
    for k,v in (ss.get("block_top") or [])[:10]:
        lines.append(f"- {k}: {v}")
    return "\n".join(lines)

def paper_handoff_text() -> str:
    st = load_json("paper_bot_candidate_handoff_status.json", {}) or {}
    ss = strategy_summary()
    counts = ss.get("counts") or {}
    return "\n".join([
        "📨 paper 전달 /paper_handoff · v715",
        f"- OPEN: {len(open_rows())} / status age {age((paper_status() or {}).get('ts'))}",
        f"- 후보선별: raw_fast {st.get('raw_fast',0)} / filtered_fast {st.get('filtered_fast',0)} / seen {st.get('seen',0)} / selected {st.get('selected',0)}",
        "",
        f"✅ 후보 배관: KRW {counts.get('krw',0)} → scanner {counts.get('scanner',0)} → 전략입력 {counts.get('strategy_input',0)} → canonical봉인 {counts.get('canonical',0)} → 실전후보 {counts.get('actionable',0)} / coverage {counts.get('coverage',0)}",
        f"- 실전후보 등급: S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3_watch {counts.get('S3_watch',0)}",
    ])

def missed_candidates_text() -> str:
    data = load_json("clean_market_miss_review_v667.json", {}) or load_json("clean_review_summary.json", {}) or {}
    summary = data.get("summary") or {}
    lines = ["🧭 놓친 후보판 /missed_candidates · v715", "- 기준: review_worker cache만 읽음. main 재계산 없음."]
    if summary:
        lines.append("- " + " / ".join(f"{k} {v}" for k,v in summary.items()))
    rows = data.get("missed") or data.get("rows") or []
    for r in rows[:10] if isinstance(rows, list) else []:
        lines.append(f"- {r.get('symbol') or r.get('ticker','-')} / max {fnum(r.get('max_pct') or r.get('max_profit_pct'),0):+.2f}% / {r.get('class','-')}")
    return "\n".join(lines)

def condition_review_text() -> str:
    ss = strategy_summary()
    counts = ss.get("counts") or {}
    return "\n".join([
        "🧩 조건 역할 상세 /condition_review · v715",
        "- 조건값은 바꾸지 않고, canonical row 역할 정보를 봅니다.",
        f"전체 {counts.get('canonical',0)}개 / 실전후보 {counts.get('actionable',0)} / coverage {counts.get('coverage',0)} / 제외 {counts.get('excluded',0)}",
        f"- S1 {counts.get('S1',0)} / S2 {counts.get('S2',0)} / S3_watch {counts.get('S3_watch',0)}",
        "판독",
        "- 공통층은 위험/실행만, 매수 논리는 전략별로 분리합니다.",
    ])

def version_score_text() -> str:
    return "📊 성과 /version_score · v715\n- v715에서는 /score가 기준 성과판입니다.\n\n" + score_text()

def _active_start_ts() -> float:
    # Use current component status timestamps as the "current run is alive after this" marker.
    vals = []
    for name in ["main_bot_status.json", "paper_bot_status.json", "clean_strategy_worker_status.json", "clean_review_worker_status.json"]:
        st = load_json(name, {}) or {}
        x = fnum(st.get("ts"), 0)
        if x:
            vals.append(x)
    return min(vals) if vals else ts() - 600

def errorlog_text() -> str:
    rows = []
    for name in ["main_bot_errorlog.jsonl","paper_bot_errorlog.jsonl","strategy_worker_errorlog.jsonl","review_worker_errorlog.jsonl","target_router_errorlog.jsonl"]:
        for r in read_jsonl_tail(name, 30):
            r["_file"] = name
            rows.append(r)
    if not rows:
        return "🧯 오류로그 /errorlog\n\n✅ 새 실행 중 오류 없음"
    cutoff = _active_start_ts()
    recent = sorted([r for r in rows if fnum(r.get("ts"),0) >= cutoff], key=lambda r:fnum(r.get("ts"),0), reverse=True)[:12]
    old = sorted([r for r in rows if fnum(r.get("ts"),0) < cutoff], key=lambda r:fnum(r.get("ts"),0), reverse=True)[:8]
    lines = ["🧯 오류로그 /errorlog · v715", f"- 기준: 현재 실행 기준시각 {time.strftime('%H:%M:%S', time.localtime(cutoff))} 이후를 새 오류로 표시", ""]
    if recent:
        lines.append("[새 오류]")
        for r in recent:
            lines.append(f"- {time.strftime('%H:%M:%S', time.localtime(fnum(r.get('ts'),ts())))} / {r.get('where','-')} / {r.get('error','-')}")
    else:
        lines.append("✅ 새 실행 중 오류 없음")
    if old:
        lines += ["", "[이전 오류 · 참고]"]
        for r in old:
            lines.append(f"- {time.strftime('%H:%M:%S', time.localtime(fnum(r.get('ts'),ts())))} / {r.get('where','-')} / {r.get('error','-')}")
    return "\n".join(lines)


def latest_hourly_summary_text() -> str:
    """Read paper_bot hourly summary/raw pack cache. Cache-only, no regeneration."""
    lines = ["🕐 1시간 요약 /hourly_summary · v715",
             "- 기준: paper_bot이 이미 만든 hourly summary/raw pack cache만 읽음. main_bot 재생성 없음."]
    latest = read_text("paper_bot_latest_hourly_summary.txt", "").strip()
    trace = load_json("paper_bot_hourly_summary_trace.json", {}) or {}
    raw_trace = load_json("paper_bot_hourly_raw_pack_trace.json", {}) or {}
    if latest:
        lines += ["", "[최근 요약]", latest[:2600]]
    else:
        lines += ["", "❔ 최근 1시간 요약 txt 없음"]
    lines += [
        "",
        "[전송/삭제 상태]",
        f"- 요약 trace: age {age_text(trace.get('ts'))} / paper방 {trace.get('paper_sent','❔')} / main방 {trace.get('main_sent','❔')} / 삭제 {trace.get('deleted','❔')} / {trace.get('reason','-')}",
        f"- 원문 묶음: age {age_text(raw_trace.get('ts'))} / paper방 {raw_trace.get('paper_sent','❔')} / main방 {raw_trace.get('main_sent','❔')} / 삭제 {raw_trace.get('deleted','❔')} / {raw_trace.get('file','-')} / owner {raw_trace.get('owner','-')}",
    ]
    return "\n".join(lines)

def pbatch_text() -> str:
    """Paper-focused quick summary. Cache-only."""
    ps = paper_status()
    op = open_rows()
    s = score_cache()
    fast = ps.get("fast_paper") or {}
    lines = [
        "🧪 paper 요약 /pbatch · v715",
        f"- paper: {ps.get('version','-')} / build {ps.get('build','-')} / status age {age_text(ps.get('ts'))}",
        f"- OPEN {len(op)} / CLOSED누적 {ps.get('closed_count',0)}",
        f"- fast paper: seen {fast.get('seen',0)} / selected {fast.get('selected',0)} / limit {fast.get('limit_skip',0)} / hold {fast.get('hold',0)}",
        "",
        "[기간별]",
    ]
    lines += periods_lines(s)
    stop = stop_summary()
    lines += [
        "",
        "[손절]",
        f"- 손절초과 {stop.get('n',0)}건 / 평균초과 {fnum(stop.get('avg_overrun'),0):+.2f}% / 최대초과 {fnum(stop.get('max_overrun'),0):+.2f}% / 루프gap의심 {stop.get('loop_gap_suspect',0)}",
        "",
        "[OPEN 일부]",
    ]
    if not op:
        lines.append("- 현재 OPEN 없음")
    else:
        for r in op[:8]:
            sym = r.get("symbol") or r.get("ticker") or "-"
            strat = r.get("strategy_name") or r.get("strategy") or "-"
            lane = "실험" if r.get("is_experiment") or r.get("lane") == "experiment" else "정식"
            lines.append(f"- {sym} / {lane} / {r.get('grade','-')} / {strat} / {fmt_pct(r.get('pnl_pct'))}")
        if len(op) > 8:
            lines.append(f"- 나머지 {len(op)-8}개 생략")
    return "\n".join(lines)

def summary_text() -> str:
    """One-screen user summary. Cache-only."""
    c = candidate_summary()
    counts = c.get("counts") or {}
    r = resource_snapshot()
    s = score_cache()
    stop = stop_summary()
    lines = [
        "📌 코인봇 한눈요약 /summary · v715",
        f"- 버전: {BOT_VERSION} / {BUILD_LABEL}",
        "",
        "[상태]",
        f"- OPEN {len(open_rows())} / 실전후보 S1 {counts.get('S1',0)} · S2 {counts.get('S2',0)} · S3_watch {counts.get('S3_watch', counts.get('S3',0))} / coverage {counts.get('coverage',0)}",
        f"- CPU {r['cpu_pct']:.1f}% / 메모리 {r['mem_used_pct']:.1f}% / 디스크 {r['disk_used_pct']:.1f}%",
        f"- 손절초과 {stop.get('n',0)}건 / 루프gap의심 {stop.get('loop_gap_suspect',0)}",
        "",
        "[성과]",
    ]
    lines += periods_lines(s)[:4]
    lines += [
        "",
        "[다음에 볼 명령]",
        "- 평소: /health /score /stop_review /strategy_review /errorlog",
        "- paper 요약: /pbatch",
        "- 1시간 요약: /hourly_summary",
    ]
    return "\n".join(lines)


COMMANDS: Dict[str, Callable[[], str]] = {
    "menu": menu_text, "help": menu_text, "guide": feature_map_text, "feature_map": feature_map_text, "map": feature_map_text,
    "batch": batch_text, "health": health_text, "score": score_text, "version_score": version_score_text,
    "stop_review": stop_review_text, "exit_review": stop_review_text, "strategy_review": strategy_review_text, "sreview": strategy_review_text,
    "pstatus": pstatus_text, "popen": popen_text, "open": popen_text, "candidate_reason": candidate_reason_text,
    "paper_handoff": paper_handoff_text, "handoff": paper_handoff_text, "missed_candidates": missed_candidates_text,
    "condition_review": condition_review_text, "errorlog": errorlog_text,
    "summary": summary_text,
    "hourly_summary": latest_hourly_summary_text,
    "hourly": latest_hourly_summary_text,
    "raw_summary": latest_hourly_summary_text,
    "paper_summary": latest_hourly_summary_text,
    "pbatch": pbatch_text,
    # Legacy/guard compatibility aliases. These stay cache-only.
    "core": health_text,
    "trade": pstatus_text,
    "quality": candidate_reason_text,
    "deploy": health_text,
    "upgradestatus": health_text,
    "retention": health_text,
}

def send(update: Any, text: str) -> None:
    if update is None:
        print(text)
        return
    msg = getattr(update, "message", None)
    if msg is None:
        return
    for i in range(0, len(text), 3800):
        msg.reply_text(text[i:i+3800])

def _kst_stamp() -> str:
    return time.strftime("%Y%m%d_%H%M%S", time.localtime(time.time()))

def _summary_header_time() -> str:
    return time.strftime("%Y-%m-%d %H:%M:%S KST", time.localtime(time.time()))

def make_batch_summary_text(cmds: List[str], results: List[Dict[str, Any]], started_ts: float) -> str:
    total = max(0.0, time.time() - started_ts)
    batch_result = ""
    for r in results:
        if r.get("name") == "batch":
            batch_result = r.get("text", "")
            break
    if not batch_result and results:
        batch_result = results[0].get("text", "")

    lines: List[str] = [
        "코인봇 최신 묶음 요약집 v715",
        f"- 생성: {_summary_header_time()}",
        f"- 메인봇: {BOT_VERSION} / {BUILD_LABEL}",
        f"- 명령 개수: {len(cmds)}",
        f"- 처리합계: {total:.2f}s",
        "",
        "[명령 시간표]",
    ]
    for r in results:
        ok = "✅" if r.get("ok") else "❌"
        lines.append(f"- {ok} /{r.get('name','-')}: {r.get('elapsed',0):.2f}s / {'OK' if r.get('ok') else 'ERROR'}")

    lines += [
        "",
        "[빠른판독]",
        batch_result[:3500] if batch_result else "- 빠른판독 없음",
        "",
        "[명령 출력 요약]",
    ]
    for r in results:
        text = str(r.get("text", ""))
        lines += [
            "",
            f"[/{r.get('name','-')}]",
            text[:4500],
        ]
        if len(text) > 4500:
            lines.append("…(상세 생략)")
    return "\n".join(lines)

def send_batch_summary_document(update: Any, cmds: List[str], results: List[Dict[str, Any]], started_ts: float) -> None:
    # The user workflow depends on this txt file being sent after pasted command bundles.
    # It is a main_bot output artifact, not paper hourly raw pack.
    if update is None or len(cmds) <= 1:
        return
    filename = f"coinbot_batch_summary_{_kst_stamp()}.txt"
    path = BASE_DIR / filename
    sent = False
    deleted = False
    err = ""
    try:
        path.write_text(make_batch_summary_text(cmds, results, started_ts), encoding="utf-8")
        msg = getattr(update, "message", None)
        if msg is not None and hasattr(msg, "reply_document"):
            with path.open("rb") as f:
                msg.reply_document(document=f, filename=filename, caption="📎 명령어 결과 요약집")
            sent = True
    except Exception as exc:
        err = repr(exc)
        append_error("batch_summary_document", exc)
    try:
        if sent and path.exists():
            path.unlink()
            deleted = True
    except Exception as exc:
        err = err or repr(exc)
        append_error("batch_summary_delete", exc)
    try:
        save_json("main_bot_batch_summary_trace.json", {
            "ts": ts(),
            "owner": "main_bot_v715",
            "file": filename,
            "commands": cmds,
            "sent": "✅" if sent else "❌",
            "deleted": "✅" if deleted else ("❔" if sent else "❌"),
            "error": err,
            "result_count": len(results),
        })
    except Exception:
        pass

def parse_command_tokens(raw: str) -> List[str]:
    """Parse multi-line Telegram command blocks.

    Telegram CommandHandler only triggers the first command in a message.
    v715 keeps the old user workflow: paste many commands at once, execute all in order.
    """
    cmds: List[str] = []
    for line in (raw or "").splitlines():
        line = line.strip()
        if not line.startswith("/"):
            continue
        token = line.split()[0].strip()
        token = token[1:]
        if "@" in token:
            token = token.split("@", 1)[0]
        token = token.strip().lower()
        if token:
            cmds.append(token)
    return cmds

def run_command_text(name: str) -> Dict[str, Any]:
    started = time.time()
    ok = True
    if name not in COMMANDS:
        ok = False
        text = f"❔ /{name} 연결 없음"
    else:
        try:
            text = COMMANDS[name]()
        except Exception as exc:
            ok = False
            append_error(name, exc)
            text = f"❌ /{name} 오류\n{exc}"
    return {"name": name, "text": text, "ok": ok, "elapsed": time.time() - started}

def dispatch_message_commands(update: Any, raw: str, first_name: str = "") -> None:
    started_ts = time.time()
    cmds = parse_command_tokens(raw)
    if not cmds and first_name:
        cmds = [first_name]
    # If user pasted a block, process every command in order.
    # If the first command handler was triggered, this prevents the rest of the pasted block being ignored.
    if not cmds:
        send(update, menu_text())
        return
    results: List[Dict[str, Any]] = []
    for name in cmds:
        result = run_command_text(name)
        results.append(result)
        send(update, result["text"])
    send_batch_summary_document(update, cmds, results, started_ts)


_VALID_BOT_COMMAND_RE = re.compile(r"^[a-z][a-z0-9_]{0,31}$")

def is_valid_bot_command(name: str) -> bool:
    return bool(_VALID_BOT_COMMAND_RE.match(str(name or "")))

def handler_for(name: str):
    def handler(update, context):
        raw = ""
        try:
            raw = getattr(getattr(update, "message", None), "text", "") or ""
        except Exception:
            raw = ""
        dispatch_message_commands(update, raw, name)
    return handler

def unknown(update, context) -> None:
    raw = ""
    try:
        raw = getattr(getattr(update, "message", None), "text", "") or ""
    except Exception:
        raw = ""
    dispatch_message_commands(update, raw, "")

def write_status(status: str) -> None:
    save_json("main_bot_status.json", {"ts": ts(), "status": status, "version": BOT_VERSION, "build": BUILD_LABEL, "commands": sorted(COMMANDS)})
    save_json("clean_brain_status.json", {"ts": ts(), "status": status, "version": BOT_VERSION, "build": BUILD_LABEL})

def main() -> None:
    write_status("initializing")
    if not TELEGRAM_TOKEN or Updater is None:
        while True:
            write_status("running_no_telegram")
            time.sleep(5)
    updater = Updater(token=TELEGRAM_TOKEN, use_context=True)
    dp = updater.dispatcher
    for name in sorted(COMMANDS):
        if not is_valid_bot_command(name):
            continue
        dp.add_handler(CommandHandler(name, handler_for(name)))
    if MessageHandler is not None and Filters is not None:
        dp.add_handler(MessageHandler(Filters.text & ~Filters.command, unknown))
    try:
        if BotCommand is not None:
            updater.bot.set_my_commands([
                BotCommand("menu","명령어 메뉴"), BotCommand("summary","한눈요약"), BotCommand("batch","요약"), BotCommand("health","상태"),
                BotCommand("score","성과"), BotCommand("stop_review","손절 해석"), BotCommand("strategy_review","전략 문제"),
                BotCommand("pstatus","paper 상태"), BotCommand("popen","OPEN 목록"),
                BotCommand("candidate_reason","후보 이유"), BotCommand("paper_handoff","paper 전달"), BotCommand("errorlog","오류 로그"),
                BotCommand("pbatch","paper 요약"), BotCommand("hourly_summary","1시간 요약"), BotCommand("core","상태 alias"), BotCommand("trade","paper alias"), BotCommand("deploy","배포상태 alias"), BotCommand("upgradestatus","업그레이드 alias")
            ])
    except Exception as exc:
        append_error("set_commands", exc)
    write_status("running")
    updater.start_polling()
    updater.idle()

if __name__ == "__main__":
    main()
