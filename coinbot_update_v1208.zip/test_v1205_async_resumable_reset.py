import importlib.util
import json
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'paper_bot_v1.059.py'
spec=importlib.util.spec_from_file_location('paper_v1205_test',SOURCE)
paper=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(paper)

class V1205ResetTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); root=Path(self.tmp.name)
        paper.V1204_RESET_CONTROL=root/'control.json'; paper.V1204_RESET_STATUS=root/'status.json'
        paper.V1204_RESET_MANIFEST=root/'manifest.json'; paper.V1204_RESET_EVENTS=root/'events.jsonl'; paper.V1204_RESET_EPOCH=root/'epoch.json'
    def tearDown(self): self.tmp.cleanup()

    def test_command_returns_after_starting_background_worker(self):
        with mock.patch.object(paper,'_v1205_start_reset_worker',return_value=(True,'batch-x')):
            text=paper._v1205_reset_command()
        self.assertIn('백그라운드',text); self.assertIn('/preset_status',text)

    def test_batch_writes_decision_and_open_once(self):
        book={'p1':{'ticker':'A'},'p2':{'ticker':'B'},'p3':{'ticker':'C'}}
        prepared=[]
        for pid in list(book):
            prepared.append((pid,dict(book[pid]),{'pos_id':pid,'ticker':book[pid]['ticker'],'paper_decision_key_v926':'d-'+pid,'closed_result_key':'closed:d-'+pid,'pnl_pct':1.0}))
        state={'records':{}}
        with mock.patch.object(paper,'_v1205_append_closed_once_cached',side_effect=lambda row,keys:(row,True,'appended_verified')) as app, \
             mock.patch.object(paper,'_v926_load_decision_state',return_value=state) as load_state, \
             mock.patch.object(paper,'_v1205_apply_closed_decision_in_memory',return_value=(True,'ok')), \
             mock.patch.object(paper,'_v926_save_decision_state',return_value=True) as save_state, \
             mock.patch.object(paper,'_v1055_persist_open_force',return_value=True) as save_open, \
             mock.patch.object(paper,'record_closed_commit'):
            committed,pnl,fail=paper._v1205_commit_reset_batch(book,prepared,set())
        self.assertEqual(committed,3); self.assertEqual(book,{}); self.assertEqual(fail,[])
        self.assertEqual(load_state.call_count,1); self.assertEqual(save_state.call_count,1); self.assertEqual(save_open.call_count,1); self.assertEqual(app.call_count,3)

    def test_normal_cycle_and_exit_skip_during_reset(self):
        old=paper._V1205_RESET_ACTIVE; paper._V1205_RESET_ACTIVE=True
        try:
            with mock.patch.object(paper,'load_open',return_value={'p':{}}), mock.patch.object(paper,'write_status') as write:
                cycle=paper.run_cycle__v1205_reset_aware(); exit_status=paper.run_exact_exit_monitor__v1205_reset_aware()
            self.assertEqual(cycle['engine'],'paper_v1205_reset_heartbeat'); self.assertEqual(exit_status['state'],'RESET_OWNS_OPEN'); self.assertTrue(write.called)
        finally: paper._V1205_RESET_ACTIVE=old

    def test_resume_state_is_accepted(self):
        paper.V1204_RESET_STATUS.write_text(json.dumps({'state':'RUNNING','batch_id':'old','target_count':10}),encoding='utf-8')
        paper.V1204_RESET_CONTROL.write_text(json.dumps({'pause_new_open':True,'batch_id':'old'}),encoding='utf-8')
        with mock.patch.object(paper,'load_open',return_value={'p1':{'ticker':'A'}}), \
             mock.patch.object(paper,'_v1204_write_control',return_value=True), mock.patch.object(paper,'_v1204_write_status',return_value=True):
            ok,batch,reason=paper._v1205_prepare_reset_request()
        self.assertTrue(ok); self.assertEqual(batch,'old'); self.assertEqual(reason,'queued')

    def test_no_normal_trade_formula_change(self):
        source=SOURCE.read_text(encoding='utf-8')
        self.assertIn('normal candidate/entry/exit formulas are unchanged',source.lower())
        self.assertIn('background_resumable_batch_worker_v1205',source)
        self.assertIn("auto_buy':False",source)

if __name__=='__main__': unittest.main(verbosity=2)
