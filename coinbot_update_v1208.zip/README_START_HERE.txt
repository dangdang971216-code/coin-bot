코인봇 v1208

[이번 수정]
- 전체 OPEN 최대 10개, 일반 9개, 대수익 1개 계약 유지.
- 같은 Strategy generation(cycle+commit)에서 신규 OPEN은 최대 2개만 실행.
- cycle 제한으로 대기한 후보는 보관·재사용하지 않고 다음 Strategy generation에서 현재 가격·RR·목표공간·추격률·spread·slippage·비용을 다시 계산.
- Paper가 실제 진입·청산 계약 snapshot을 한 곳에서 만들고 Paper/Main/Guard/Review 화면이 같은 snapshot을 읽음.
- 새 OPEN에 일반/대수익 역할, 전략순위, cycle순위, cycle cap, cycle/commit, 실제 진입근거를 append-once로 봉인.
- 전체정리 상태판의 이미 끝난 경고 문구를 현재 TOP10 활성 상태로 교체.
- 청산이 없는 동안 오래된 closed_append는 EVENT_DRIVEN_IDLE로 표시.
- 재시작 전 PID·버전의 내부시간 표본은 현재 오류에서 제외.
- 최근 고점 거리·당일 위치·점수 구성·Scanner 최초발견 값을 기존 owner 자료에서 후보에 봉인.

[변경하지 않음]
- 후보 수와 S1 기준, trigger, invalid, target, RR.
- v1207 동적 청산 수치와 기존 OPEN의 진입 당시 계약.
- OPEN/CLOSED/decision 원장과 exact commit 순서.
- 자동매수 OFF.

[다음 버전]
- v1209에서 Micro·Strategy·Paper CPU/I/O 원인을 별도 분석·최적화.
