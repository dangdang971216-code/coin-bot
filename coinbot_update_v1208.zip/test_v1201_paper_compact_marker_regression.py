import importlib.util
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

HERE = Path(__file__).resolve().parent


def source_path() -> Path:
    direct = HERE / 'paper_bot_v1.059.py'
    if direct.exists():
        return direct
    return HERE.parent / 'source' / 'latest_intended' / 'paper_bot_v1.059.py'


def load_module():
    src = source_path().resolve()
    sys.path.insert(0, str(src.parent))
    spec = importlib.util.spec_from_file_location('paper_v1202_compact_regression', src)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


paper = load_module()


class PaperCompactMarkerV1201Tests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.orig_open = paper.FILES['open']
        paper.FILES['open'] = self.root / 'paper_bot_open.json'
        paper._V1201_LAST_COMPACT_STATS = {}

    def tearDown(self):
        paper.FILES['open'] = self.orig_open
        self.tmp.cleanup()

    @staticmethod
    def candidate(schema='strategy_candidate_v1200'):
        return {
            'schema': schema,
            'ticker': 'TEST',
            'paper_decision_key_v926': 'decision-test',
            'trigger_price': 100.0,
            'invalid_price': 90.0,
            'target_price': 130.0,
            'risk_reward': {'ratio': 3.0, 'target_room_pct': 30.0},
            'trigger_gate': {'trigger_gap_pct': 0.25, 'trigger_reached': True},
            'block_reasons': [],
        }

    @staticmethod
    def contract_row(raw):
        return {
            'pos_id': 'pos-test',
            'ticker': 'TEST',
            'paper_decision_key_v926': 'decision-test',
            'swing_trigger_price_v977': 100.0,
            'swing_invalid_price_v977': 90.0,
            'swing_target_price_v977': 130.0,
            'risk_reward': {'ratio': 3.0, 'target_room_pct': 30.0},
            'exit_contract_v1038': {
                'schema': 'alt_swing_exit_contract_v1038',
                'trailing_exit': True,
                'trailing_trigger_pct': 2.0,
                'trailing_giveback_pct': 0.8,
            },
            'raw': raw,
        }

    def test_source_schema_cannot_overwrite_compact_schema(self):
        compact = paper._v930_compact_candidate_evidence(self.candidate())
        self.assertEqual(compact['schema'], paper._V930_COMPACT_EVIDENCE_SCHEMA)
        self.assertEqual(compact['source_schema'], 'strategy_candidate_v1200')
        self.assertEqual(compact['compact_contract_version'], 'v1201')
        self.assertTrue(compact['source_sha256'])
        self.assertGreater(compact['source_bytes'], 0)

    def test_true_legacy_row_compacts_once_then_second_pass_is_noop(self):
        row = self.contract_row(self.candidate())
        book = {'pos-test': row}
        before_contract = {
            'trigger': row['swing_trigger_price_v977'],
            'invalid': row['swing_invalid_price_v977'],
            'target': row['swing_target_price_v977'],
            'rr': row['risk_reward'],
            'exit': row['exit_contract_v1038'],
            'decision': row['paper_decision_key_v926'],
        }
        self.assertEqual(paper._v930_compact_existing_open_rows(book), 1)
        self.assertEqual(paper._V1201_LAST_COMPACT_STATS['full_compacted'], 1)
        self.assertEqual(book['pos-test']['raw']['schema'], paper._V930_COMPACT_EVIDENCE_SCHEMA)
        self.assertEqual(paper._v930_compact_existing_open_rows(book), 0)
        self.assertEqual(paper._V1201_LAST_COMPACT_STATS['already_compact'], 1)
        after = book['pos-test']
        self.assertEqual(before_contract['trigger'], after['swing_trigger_price_v977'])
        self.assertEqual(before_contract['invalid'], after['swing_invalid_price_v977'])
        self.assertEqual(before_contract['target'], after['swing_target_price_v977'])
        self.assertEqual(before_contract['rr'], after['risk_reward'])
        self.assertEqual(before_contract['exit'], after['exit_contract_v1038'])
        self.assertEqual(before_contract['decision'], after['paper_decision_key_v926'])

    def test_buggy_pre_v1201_row_uses_marker_only_repair(self):
        # This is the exact old bug shape: compact digest/size exist, but source
        # candidate schema overwrote the compact schema.
        buggy_raw = {
            'schema': 'strategy_candidate_v1200',
            'ticker': 'TEST',
            'paper_decision_key_v926': 'decision-test',
            'source_sha256': 'abc123',
            'source_bytes': 4321,
        }
        row = self.contract_row(buggy_raw)
        row['paper_open_payload_v930'] = {
            'schema': paper._V930_COMPACT_OPEN_SCHEMA,
            'source_sha256': 'abc123',
            'raw_payload_full_stored': False,
        }
        book = {'pos-test': row}
        with mock.patch.object(paper, '_v930_compact_open_row', side_effect=AssertionError('full compact must not run')):
            self.assertEqual(paper._v930_compact_existing_open_rows(book), 1)
        stats = paper._V1201_LAST_COMPACT_STATS
        self.assertEqual(stats['marker_repaired'], 1)
        self.assertEqual(stats['full_compacted'], 0)
        self.assertEqual(book['pos-test']['raw']['schema'], paper._V930_COMPACT_EVIDENCE_SCHEMA)
        self.assertEqual(book['pos-test']['raw']['source_schema'], 'strategy_candidate_v1200')
        self.assertTrue(book['pos-test']['paper_open_payload_v930']['compact_marker_repaired_v1201'])
        self.assertEqual(paper._v930_compact_existing_open_rows(book), 0)

    def test_222_buggy_rows_repair_without_json_recompaction(self):
        book = {}
        for i in range(222):
            raw = {
                'schema': 'strategy_candidate_v1200',
                'ticker': f'T{i}',
                'source_sha256': f'digest-{i}',
                'source_bytes': 100000 + i,
                'large_compact_list': list(range(50)),
            }
            row = self.contract_row(raw)
            row['pos_id'] = f'pos-{i}'
            row['ticker'] = f'T{i}'
            row['paper_decision_key_v926'] = f'decision-{i}'
            row['paper_open_payload_v930'] = {
                'schema': paper._V930_COMPACT_OPEN_SCHEMA,
                'source_sha256': f'digest-{i}',
            }
            book[f'pos-{i}'] = row
        with mock.patch.object(paper, '_v930_json_bytes', side_effect=AssertionError('marker repair must not serialize full rows')):
            self.assertEqual(paper._v930_compact_existing_open_rows(book), 222)
        self.assertEqual(paper._V1201_LAST_COMPACT_STATS['marker_repaired'], 222)
        self.assertEqual(paper._V1201_LAST_COMPACT_STATS['full_compacted'], 0)
        self.assertEqual(paper._v930_compact_existing_open_rows(book), 0)
        self.assertEqual(paper._V1201_LAST_COMPACT_STATS['already_compact'], 222)

    def test_reserved_digest_fields_from_source_cannot_replace_compact_metadata(self):
        src = self.candidate()
        src.update({'source_sha256': 'fake', 'source_bytes': 1, 'source_schema': 'fake', 'compact_contract_version': 'fake'})
        compact = paper._v930_compact_candidate_evidence(src)
        self.assertNotEqual(compact['source_sha256'], 'fake')
        self.assertNotEqual(compact['source_bytes'], 1)
        self.assertEqual(compact['source_schema'], 'strategy_candidate_v1200')
        self.assertEqual(compact['compact_contract_version'], 'v1201')


if __name__ == '__main__':
    unittest.main(verbosity=2)
