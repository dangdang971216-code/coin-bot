import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'paper_bot_v1.059.py'
spec=importlib.util.spec_from_file_location('paper_v1206_test',SOURCE)
paper=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(paper)

def candidate(i,strategy,score,runner=False,target=15.0):
    return (f'p{i}',{
        'ticker':f'T{i}','paper_decision_key_v926':f'd{i}','strategy_key':strategy,
        'swing_quality_rank_score':score,'target_room_pct':target,'risk_reward_ratio':3.0,
        'trigger_gate':{'profile_decisions':{'spike':{'runner_pass':runner}}},
    })

class V1206Tests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); root=Path(self.tmp.name)
        paper.V1204_RESET_CONTROL=root/'control.json'; paper.V1204_RESET_STATUS=root/'reset_status.json'
        paper.V1204_RESET_EPOCH=root/'epoch.json'; paper.V1204_RESET_EVENTS=root/'events.jsonl'
        paper.V1206_TOP10_STATE=root/'top10.json'; paper.V1206_TOP10_LEDGER=root/'top10.jsonl'
    def tearDown(self): self.tmp.cleanup()

    def test_general_nine_plus_qualified_runner_one(self):
        picked=[]
        for i in range(12): picked.append(candidate(i,['A','B','C'][i%3],100-i,runner=(i==10),target=20 if i==10 else 15))
        selected,e=paper.rank_executable_candidates_for_open(picked,{},10)
        roles=[row['ranked_top10_slot_role_v1206'] for _,row in selected]
        self.assertEqual(len(selected),10); self.assertEqual(roles.count('general'),9); self.assertEqual(roles.count('runner'),1)
        self.assertFalse(e['runner_slot_empty'])
        general=[row for _,row in selected if row['ranked_top10_slot_role_v1206']=='general']
        self.assertGreaterEqual(len({row['ranked_top10_strategy_v1206'] for row in general[:3]}),3)

    def test_runner_slot_stays_empty(self):
        selected,e=paper.rank_executable_candidates_for_open([candidate(i,'A',100-i,runner=False) for i in range(15)],{},10)
        self.assertEqual(len(selected),9); self.assertTrue(e['runner_slot_empty'])

    def test_response_profit_protection(self):
        pos={'entry_price':100.0,'current_price':100.0,'exit_contract_v1206':{'schema':'alt_swing_exit_contract_v1206','response_protect_enabled':True,'response_trigger_net_peak_pct':1.0,'response_floor_net_pct':0.0,'emergency_gross_loss_cap_enabled':True,'emergency_gross_loss_cap_pct':4.0}}
        d=paper._exit_decision_spine__v1206(pos,30.0,1.2,0.0,{'fee_pct_roundtrip':0.1})
        self.assertEqual(d['reason'],'swing_response_protect')

    def test_closer_structure_line_only_for_4h_or_1h_invalid(self):
        row={'entry_price':100.0,'current_price':100.0,'swing_structure_plan_v977':{'invalid':{'price':90.0,'tf':'4h'}},'entry_context':{'1h_recent_low_price':96.0}}
        line=paper._v1206_closer_entry_failure_line(row)
        self.assertTrue(line['active']); self.assertEqual(line['entry_failure_invalid_price'],96.0)
        pos=dict(row); pos['current_price']=96.0; pos['exit_contract_v1206']={'schema':'alt_swing_exit_contract_v1206','response_protect_enabled':True,'response_trigger_net_peak_pct':1.0,'response_floor_net_pct':0.0,'entry_failure_structure_line':line}
        d=paper._exit_decision_spine__v1206(pos,20.0,0.2,-4.1,{'fee_pct_roundtrip':0.1})
        self.assertEqual(d['reason'],'swing_entry_failure_invalid')
        row30={'entry_price':100.0,'swing_structure_plan_v977':{'invalid':{'price':95.0,'tf':'30m'}},'entry_context':{'15m_recent_low_price':98.0}}
        self.assertFalse(paper._v1206_closer_entry_failure_line(row30)['active'])

    def test_activation_requires_zero_open_proof(self):
        paper.V1204_RESET_CONTROL.write_text(json.dumps({'pause_new_open':True,'batch_id':'b'}),encoding='utf-8')
        paper.V1204_RESET_STATUS.write_text(json.dumps({'state':'ZERO_OPEN_ENTRY_PAUSED','zero_open_proof':True,'remaining_count':0,'failed_count':0,'batch_id':'b'}),encoding='utf-8')
        with mock.patch.object(paper,'load_open',return_value={}):
            ok,reason=paper._v1206_activate_ranked_top10()
        self.assertTrue(ok)
        control=json.loads(paper.V1204_RESET_CONTROL.read_text(encoding='utf-8'))
        epoch=json.loads(paper.V1204_RESET_EPOCH.read_text(encoding='utf-8'))
        self.assertFalse(control['pause_new_open']); self.assertTrue(control['ranked_top10_active_v1206'])
        self.assertTrue(epoch['state'].startswith('ACTIVE_RANKED_TOP10_V1206'))

if __name__=='__main__': unittest.main(verbosity=2)
