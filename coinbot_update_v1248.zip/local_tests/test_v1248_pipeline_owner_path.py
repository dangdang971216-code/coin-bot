#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, sys, tempfile
from pathlib import Path

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); assert spec and spec.loader
    sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

review=load('review_v1248_test',BASE/'review_worker_v1.035.py')
spine=load('spine_v1248_test',BASE/'canonical_spine_v1187.py')

def wj(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')
def wr(path,rows): path.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in rows),encoding='utf-8')
def row(ticker,cycle,stage='S1'):
    return {
      'ticker':ticker,'s_stage':stage,'candidate_grade':stage,
      'candidate_pipeline_cycle_id_v1150':cycle,'current_price':100.0,'entry_price':100.0,
      'rank_score':50.0,'candidate_decision_key':f'd-{ticker}','candidate_key':f'c-{ticker}',
      'dynamic_structure_plan_v1212':{'trigger':{'price':100,'source':'cur'},'invalid':{'price':98,'source':'cur'},'target':{'price':103,'source':'cur'}},
      'v1211_structure_shadow_v1222':{'source_exact':True,'trigger':{'price':100,'source':'old'},'invalid':{'price':98.5,'source':'old'},'target':{'price':104,'source':'old'}},
    }

def req(cycle,commit):
    return {'pipeline_cycle_id':cycle,'candidate_commit_id':commit,'candidate_rows':1,'s1_count':1,
            's2_count':0,'s3_count':0,'committed_handoff_id':'handoff-A',
            'committed_handoff_digest':'digest-A','created_ts':1,'committed_handoff_completed_ts':1}

def complete(cycle,commit):
    return {'cycle_id':cycle,'candidate_commit_id':commit,'state':'NORMAL','all_required_commits':True,
            'committed_handoff_id_v1158':'handoff-A','committed_handoff_digest_v1158':'digest-A'}

with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    paths=spine.SpinePaths(base)
    assert paths.strategy_pipeline.name=='strategy_candidate_pipeline_commit_v1150.json'
    request=req('cycle-A','commit-A')
    wr(paths.strategy_candidates,[row('AAA','cycle-A')])
    wj(paths.review_request,request)

    # A stale legacy file must never be accepted as the pipeline owner.
    wj(base/'clean_strategy_candidate_pipeline_status_v1150.json',{
      'state':'NORMAL','complete':True,'cycle_id':'cycle-A','candidate_commit_id':'commit-A',
      'all_required_commits_v1150':True})
    try:
        review._v1241_stable_committed_rows(base,request,True)
        raise AssertionError('legacy pipeline file was accepted')
    except RuntimeError as exc:
        assert 'no completed pipeline proof' in str(exc)

    # Actual Strategy owner file: current B in progress, A retained as last complete.
    wj(paths.strategy_pipeline,{
      'state':'RUNNING','complete':False,'cycle_id':'cycle-B','candidate_commit_id':'commit-B',
      'last_complete_cycle_v1152':complete('cycle-A','commit-A')})
    rows,proof=review._v1241_stable_committed_rows(base,request,True)
    assert len(rows)==1 and proof['pipeline_proof_source_v1247']=='LAST_COMPLETE_NORMAL',proof

    # Commit must advance from the request using the canonical owner file.
    review.update_version_score_review=lambda *a,**k:{'paired_matchup_v1241':{'entry_ready_pairs':1},'paper_exact_exit_replay_v1242':{}}
    result=review.process_once(base,force=True)
    assert result.get('processed') is True,result
    snap=json.loads(paths.review_snapshot.read_text())
    assert snap['source']['pipeline_cycle_id']=='cycle-A',snap['source']
    assert snap['source']['candidate_commit_id']=='commit-A',snap['source']

    # Mismatched canonical proof stays fail-closed.
    wj(paths.strategy_pipeline,{
      'state':'RUNNING','complete':False,'cycle_id':'cycle-B','candidate_commit_id':'commit-B',
      'last_complete_cycle_v1152':complete('cycle-X','commit-X')})
    try:
        review._v1241_stable_committed_rows(base,request,True)
        raise AssertionError('mismatched canonical proof accepted')
    except RuntimeError as exc:
        assert 'no completed pipeline proof' in str(exc)

review_src=(BASE/'review_worker_v1.035.py').read_text()
spine_src=(BASE/'canonical_spine_v1187.py').read_text()
assert 'clean_strategy_candidate_pipeline_status_v1150.json' not in review_src
assert 'clean_strategy_candidate_pipeline_status_v1150.json' not in spine_src
assert 'strategy_candidate_pipeline_commit_v1150.json' in spine_src
assert 'pipeline=read_json(paths.strategy_pipeline,{}) or {}' in review_src
assert review.VERSION=='review_worker_v1.035'
assert review.AUTO_BUY is False
print('PASS 12/12')
