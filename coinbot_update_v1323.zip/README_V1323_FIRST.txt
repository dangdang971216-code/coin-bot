코인봇 v1323 · Strategy writer hard-ceiling 수리

목적:
- v1322에서 S1 감시풀 복구 후 후보 writer가 row hard ceiling으로 ERROR_BEFORE_WRITE 나는 문제를 수리.
- 선택/OPEN/청산/trigger/invalid/target/RR 변경 없음.
- 자동매수 OFF.

검수:
1) /gupgrade_bundle
2) /grelease_verify
3) 메인봇 /flow_map_full /version_score /candidate_standard

확인 기준:
- Strategy writer result OK
- candidate_commit_id 새로 생성
- 후보 전달 NORMAL은 writer OK일 때만 신뢰
- 후보 전체가 다시 정상 universe 수준으로 회복되는지 확인
