코인봇 v1217 · 후보 최종 저장 증거 누락 근본수리
===============================================

핵심
- 구조선 진단 계산은 정상인데, 후보 JSONL 저장에 쓰인 cached bytes가 최종 wrapper 이전 값이었음.
- v1217은 최종 compact dict와 실제 저장 bytes를 정확히 일치시킴.
- /gstructure_missing_audit는 writer expected·compact·encoded 건수까지 확인한 뒤 실제 누락 원인을 표시함.

변경 없음
- 구조선 계산식·ATR·RR·점수·진입·청산·기존 OPEN 변경 없음.
- 자동매수 OFF.
