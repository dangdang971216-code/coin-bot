import importlib.util
import inspect
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    mod = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


class PaperV1211HotpathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = load_module('paper_v1211_test', 'paper_bot_v1.064.py')

    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        m = self.m
        m.V1181_POSTPROCESS_QUEUE = self.base / 'queue'
        m.V1181_POSTPROCESS_STATUS = self.base / 'post_status.json'
        m.V1206_TOP10_STATE = self.base / 'top10_state.json'
        m.V1206_TOP10_LEDGER = self.base / 'top10_ledger.jsonl'
        m._V1211_LAST_POSTPROCESS_GENERATION = ''
        m._V1211_LAST_QUEUE_DECISION = {}
        m._V1211_CLEANUP_LAST_TS = 0.0
        m._V1211_CLEANUP_LAST_RESULT = {}
        m._V1206_LAST_LEDGER_DIGEST = ''
        for key in list(m._V1211_WRITE_STATS):
            if key not in {'schema', 'auto_buy'}:
                m._V1211_WRITE_STATS[key] = 0

    def tearDown(self):
        self.tmp.cleanup()

    def test_runtime_tier_avoids_fsync_but_exact_tier_preserves_it(self):
        m = self.m
        runtime_path = self.base / 'runtime.json'
        exact_path = self.base / 'exact.json'
        fsync_calls = []
        original_fsync = os.fsync

        def counting_fsync(fd):
            fsync_calls.append(fd)
            return original_fsync(fd)

        with mock.patch.object(m.os, 'fsync', side_effect=counting_fsync):
            self.assertTrue(m._v1211_atomic_runtime_json(runtime_path, {'a': 1}))
            runtime_count = len(fsync_calls)
            self.assertEqual(runtime_count, 0)
            self.assertTrue(m._paper_write_json_verified__v1211(exact_path, {'a': 2}))
            self.assertGreater(len(fsync_calls), runtime_count)
        self.assertEqual(json.loads(runtime_path.read_text()), {'a': 1})
        self.assertEqual(json.loads(exact_path.read_text()), {'a': 2})

    def test_postprocess_is_once_per_generation_but_open_always_queues(self):
        m = self.m
        payload = {
            'request_id': 'r1', 'opened_count': 0,
            'pick_stats': {'generation_key_v1208': 'generation-A'},
        }
        first = m._v1181_queue_postprocess__v1211(payload)
        self.assertTrue(first.exists())
        second = m._v1181_queue_postprocess__v1211({**payload, 'request_id': 'r2'})
        self.assertFalse(second.exists())
        self.assertEqual(m._V1211_LAST_QUEUE_DECISION['reason'], 'same_generation_no_open')
        third = m._v1181_queue_postprocess__v1211({**payload, 'request_id': 'r3', 'opened_count': 1})
        self.assertTrue(third.exists())

    def test_cleanup_full_chain_is_rate_limited(self):
        m = self.m
        calls = []
        old = m._V1211_ORIGINAL_CLEANUP
        m._V1211_ORIGINAL_CLEANUP = lambda ctrl, status: calls.append(1) or {'ok': True, 'marker': 'full'}
        try:
            a = m._v678_runtime_cleanup__v1211({}, {})
            b = m._v678_runtime_cleanup__v1211({}, {})
        finally:
            m._V1211_ORIGINAL_CLEANUP = old
        self.assertEqual(len(calls), 1)
        self.assertFalse(a['cleanup_cached_v1211'])
        self.assertTrue(b['cleanup_cached_v1211'])
        self.assertEqual(b['state'], 'EVENT_DRIVEN_IDLE')

    def test_unchanged_top10_state_skips_exact_rewrite(self):
        m = self.m
        calls = []
        old_writer = m._V1211_ORIGINAL_VERIFIED_WRITE

        def fake_writer(path, obj):
            calls.append(dict(obj))
            Path(path).write_text(json.dumps(obj, ensure_ascii=False), encoding='utf-8')
            return True

        m._V1211_ORIGINAL_VERIFIED_WRITE = fake_writer
        evidence = {
            'generation_key_v1208': 'g1', 'generation_selected_total_v1208': 1,
            'open_before': 3, 'candidate_count': 10, 'selected': [{'ticker': 'BTC'}],
            'runner_slot_empty': False,
        }
        try:
            m._v1206_write_rank_state__v1211(evidence)
            m._v1206_write_rank_state__v1211(evidence)
            changed = dict(evidence)
            changed['generation_selected_total_v1208'] = 2
            m._v1206_write_rank_state__v1211(changed)
        finally:
            m._V1211_ORIGINAL_VERIFIED_WRITE = old_writer
        self.assertEqual(len(calls), 2)
        self.assertEqual(m._V1211_WRITE_STATS['top10_state_skips'], 1)

    def test_postprocess_does_not_reenter_full_status_writer(self):
        m = self.m
        request = self.base / 'req.json'
        request.write_text(json.dumps({
            'request_id': 'x', 'opened_items': [], 'pick_stats': {},
            'generation_key_v1211': 'g1',
        }), encoding='utf-8')
        m.FILES['status'] = self.base / 'paper_status.json'
        m.FILES['status'].write_text('{}', encoding='utf-8')
        m.FILES['open'] = self.base / 'open.json'
        m.FILES['open'].write_text('{}', encoding='utf-8')
        with mock.patch.object(m, 'load_control', return_value={'write_score_cache': False}), \
             mock.patch.object(m, 'load_open', return_value={}), \
             mock.patch.object(m, 'notify_s1_decision_summary'), \
             mock.patch.object(m, 'notify_market_hot_summary'), \
             mock.patch.object(m, '_v628_send_due_hourly_raw_pack'), \
             mock.patch.object(m, '_v631_maybe_send_paper_hourly_summary'), \
             mock.patch.object(m, '_v678_runtime_cleanup', return_value={'ok': True}), \
             mock.patch.object(m, 'write_status', side_effect=AssertionError('full writer must not run')):
            result = m._v1181_process_postrequest__v1211(request)
        self.assertFalse(request.exists())
        self.assertFalse(result['full_status_writer_reentry_v1211'])
        self.assertTrue(m.V1181_POSTPROCESS_STATUS.exists())

    def test_release_identity(self):
        self.assertEqual(self.m.VERSION, 'paper_bot_v1.064')
        self.assertIn('v1213_structure_before_after_score_scope', self.m.BUILD_LABEL)


class StrategyV1211HotpathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = load_module('strategy_v1211_test', 'strategy_worker_v1.047.py')

    def sample(self):
        now = time.time()
        rows = [{
            'ticker': 'BTC', 'current_price': 100.0, 'price': 100.0,
            'change_1m': 0.2, 'change_3m': 0.4, 'change_5m': 0.5,
            'price_reaction_pct': 0.3, 'structure_tags': ['VWAP 지지'],
            'feature_ts': now, 'official_candle_age': 1.0,
        }]
        ofmap = {'BTC': {
            'trade_buy_ratio_30': 0.60, 'buy_sustain_1m': 0.65,
            'micro_spread_pct': 0.10, 'micro_age_sec': 1.0,
            'orderflow_age_sec': 1.0, 'quote_price': 100.0,
        }}
        return rows, ofmap

    def test_coverage_reuses_shared_metrics_without_recalling_owners(self):
        m = self.m
        rows, ofmap = self.sample()
        shared = m._v1210_shared_candidate_eval(rows, ofmap)
        direct_rows, direct_summary = m._v661_build_coverage_rows(rows, [], ofmap, time.time(), None)
        with mock.patch.object(m, '_v510_price_reaction', side_effect=AssertionError('duplicate reaction')), \
             mock.patch.object(m, '_v510_buy', side_effect=AssertionError('duplicate buy')), \
             mock.patch.object(m, '_v524_sustain_detail', side_effect=AssertionError('duplicate sustain')), \
             mock.patch.object(m, '_v510_spread', side_effect=AssertionError('duplicate spread')):
            shared_rows, shared_summary = m._v661_build_coverage_rows(rows, [], ofmap, time.time(), shared)
        keep = ('ticker', 's_stage', 'canonical_lane', 'price_reaction_pct', 'buy_ratio', 'buy_sustain_1m', 'spread_pct', 'open_eligible')
        self.assertEqual([{k:r.get(k) for k in keep} for r in direct_rows], [{k:r.get(k) for k in keep} for r in shared_rows])
        self.assertEqual(direct_summary['coverage_added_count'], shared_summary['coverage_added_count'])

    def test_single_overlay_matches_old_two_step_values(self):
        m = self.m
        src = {'ticker': 'BTC', 'change_1m': 0.0}
        candle = {'BTC': {'official_candle_age': 2.0, 'candle_source': 'test'}}
        hot = {'BTC': {'change_1m': 1.2, 'scanner_hot_score': 88.0, '_cache_age_sec': 1.0}}
        old = m._v521_overlay_feature(m._v597_overlay_candle_cache(src, candle, time.time()), hot['BTC'])
        new = m._v1211_overlay_candle_scanner_once(src, candle, hot, time.time())
        for key in ('ticker', 'change_1m', 'scanner_hot_score', '_scanner_hot_cache_age_sec'):
            self.assertEqual(old.get(key), new.get(key))

    def test_candidate_writer_returns_status_and_caller_avoids_reload(self):
        src = (ROOT / 'strategy_worker_v1.047.py').read_text(encoding='utf-8')
        self.assertIn('def _v1021_publish_candidate_snapshot(path: Path, rows: List[Dict[str, Any]], profile: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:', src)
        self.assertIn('_v1150_writer_status = _v1021_publish_candidate_snapshot(PAPER_LATEST, rows, _v1027_profile)', src)
        window = src[src.index('_v1150_writer_status = _v1021_publish_candidate_snapshot'):]
        self.assertNotIn('load_json(PAPER_LATEST_WRITER_STATUS_V861', window[:500])
        writer_src = inspect.getsource(self.m._v1021_publish_candidate_snapshot)
        self.assertIn('save_runtime_json(PAPER_LATEST_WRITER_STATUS_V861', writer_src)
        self.assertIn('return dict(status)', writer_src)

    def test_release_identity(self):
        self.assertEqual(self.m.VERSION, 'strategy_worker_v1.047')
        self.assertIn('v1217_candidate_final_blob_evidence_persistence', self.m.BUILD_LABEL)


if __name__ == '__main__':
    unittest.main(verbosity=2)
