#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, time, traceback, urllib.parse, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

BASE_DIR=Path(os.getenv("TRADING_BOT_DIR","/home/dangdang971216/trading_bot"))
VERSION='market_regime_worker_v2.003'
BUILD_LABEL='v2156_market_input_truth_2026-07-22'
MAIN_DEPLOY_VERSION=BUILD_LABEL
INTERVAL_SEC=float(os.getenv('MARKET_REGIME_INTERVAL_SEC','3.0'))
STATUS=BASE_DIR/'clean_market_regime_status.json'; OUT=BASE_DIR/'clean_market_regime_cache.json'
ERROR=BASE_DIR/'clean_market_regime_error.log'; MARKET=BASE_DIR/'clean_scanner_market_cache.json'
STATE=BASE_DIR/'clean_market_context_state_v2130.json'
EXTERNAL_REFRESH_SEC=float(os.getenv('MARKET_EXTERNAL_REFRESH_SEC','20.0'))
EXTERNAL_READY_TTL_SEC=float(os.getenv('MARKET_EXTERNAL_READY_TTL_SEC','60.0'))
EXTERNAL_TIMEOUT_SEC=float(os.getenv('MARKET_EXTERNAL_TIMEOUT_SEC','1.5'))
UPBIT_MINUTE_URL='https://api.upbit.com/v1/candles/minutes/1'

def now_ts()->float:return time.time()
def now_text(ts:Optional[float]=None)->str:return time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(ts or now_ts()))
def fnum(*vals:Any,default:Optional[float]=0.0)->Optional[float]:
    for v in vals:
        try:
            if v in (None,''):continue
            return float(str(v).replace(',','').replace('%',''))
        except Exception:continue
    return default
def ticker_norm(x:Any)->str:
    t=str(x or '').strip().upper().replace('/','-').replace('_','-'); parts=[p for p in t.split('-') if p]
    if len(parts)>=2:
        non=[p for p in parts if p!='KRW'];t=non[-1] if non else parts[-1]
    if t.endswith('KRW') and len(t)>3:t=t[:-3]
    return t.strip().upper()
def load_json(path:Path,default:Any=None)->Any:
    try:return json.loads(path.read_text(encoding='utf-8',errors='ignore')) if path.exists() else default
    except Exception:return default
def save_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+f'.tmp.{os.getpid()}.{time.time_ns()}')
    try:
        tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':'),default=str),encoding='utf-8');os.replace(tmp,path)
    finally:
        try:tmp.unlink(missing_ok=True)
        except Exception:pass
def append_error(where:str,exc:BaseException)->None:
    try:
        with ERROR.open('a',encoding='utf-8') as f:f.write(f'[{now_text()}] {where}: {type(exc).__name__}: {exc}\n{traceback.format_exc()[-1500:]}\n')
    except Exception:pass
def write_status(state:str,**extra:Any)->None:
    save_json(STATUS,{'version':VERSION,'build':BUILD_LABEL,'state':state,'pid':os.getpid(),'updated_ts':now_ts(),'updated_text':now_text(),**extra})
def _row_num(row:Dict[str,Any],*keys:str)->Optional[float]:
    for key in keys:
        if key in row and row.get(key) not in (None,''):
            value=fnum(row.get(key),default=None)
            if value is not None:return value
    return None
def _btc_row(rows:List[Dict[str,Any]])->Dict[str,Any]:
    for row in rows:
        if not isinstance(row,dict):continue
        t=ticker_norm(row.get('ticker') or row.get('symbol') or row.get('market'))
        if t=='BTC':return row
    return {}
def _direction_from_changes(values:List[Optional[float]])->str:
    vals=[float(v) for v in values if v is not None]
    if not vals:return 'SOURCE_MISSING'
    avg=sum(vals)/len(vals)
    if avg>=0.55:return 'STRONG_UP'
    if avg>=0.12:return 'UP'
    if avg<=-0.55:return 'STRONG_DOWN'
    if avg<=-0.12:return 'DOWN'
    return 'FLAT'

def _upbit_external_btc(nowv:float, previous:Dict[str,Any])->Dict[str,Any]:
    prev=dict(previous) if isinstance(previous,dict) else {}
    prev_ts=fnum(prev.get('fetched_ts'),prev.get('updated_ts'),default=0.0) or 0.0
    if prev and prev.get('state')=='READY' and nowv-prev_ts<=EXTERNAL_REFRESH_SEC:
        prev['age_sec']=round(max(0.0,nowv-prev_ts),3);return prev
    try:
        query=urllib.parse.urlencode({'market':'KRW-BTC','count':8})
        req=urllib.request.Request(UPBIT_MINUTE_URL+'?'+query,headers={'User-Agent':'coinbot-market-context-v2130','Accept':'application/json'})
        with urllib.request.urlopen(req,timeout=EXTERNAL_TIMEOUT_SEC) as response:
            payload=json.loads(response.read().decode('utf-8','ignore'))
        if not isinstance(payload,list) or len(payload)<6:raise ValueError('upbit minute candles <6')
        rows=[x for x in payload if isinstance(x,dict) and fnum(x.get('trade_price'),default=None) is not None]
        rows.sort(key=lambda x:fnum(x.get('timestamp'),default=0.0) or 0.0)
        closes=[fnum(x.get('trade_price'),default=None) for x in rows]
        closes=[float(x) for x in closes if x is not None and x>0]
        if len(closes)<6:raise ValueError('upbit valid closes <6')
        last=closes[-1]
        def change(back:int)->Optional[float]:
            if len(closes)<=back or closes[-1-back]<=0:return None
            return (last/closes[-1-back]-1.0)*100.0
        c1,c3,c5=change(1),change(3),change(5)
        direction=_direction_from_changes([c1,c3,c5])
        return {'schema':'external_market_lead_v2130','owner':'market_regime_worker','state':'READY',
                'source':'upbit_public_minute_candle','market':'KRW-BTC','direction':direction,
                'btc_change_1m':round(c1,5) if c1 is not None else None,
                'btc_change_3m':round(c3,5) if c3 is not None else None,
                'btc_change_5m':round(c5,5) if c5 is not None else None,
                'fetched_ts':nowv,'age_sec':0.0,'source_missing':[],'auto_buy':False}
    except Exception as exc:
        if prev and prev_ts>0 and nowv-prev_ts<=EXTERNAL_READY_TTL_SEC:
            return {**prev,'state':'STALE','age_sec':round(max(0.0,nowv-prev_ts),3),
                    'last_error':f'{type(exc).__name__}: {exc}','source_missing':['external_market_fresh'] ,'auto_buy':False}
        return {'schema':'external_market_lead_v2130','owner':'market_regime_worker','state':'SOURCE_MISSING',
                'source':'upbit_public_minute_candle','market':'KRW-BTC','direction':'SOURCE_MISSING',
                'fetched_ts':prev_ts or None,'age_sec':round(max(0.0,nowv-prev_ts),3) if prev_ts else None,
                'last_error':f'{type(exc).__name__}: {exc}','source_missing':['external_market_lead'],'auto_buy':False}

def _btc_direction(row:Dict[str,Any])->tuple[str,List[str]]:
    missing=[]
    c1=_row_num(row,'change_1m','scanner_change_1m_pct','change_1m_pct')
    c3=_row_num(row,'change_3m','scanner_change_3m_pct','change_3m_pct')
    c5=_row_num(row,'change_5m','change_5m_pct','m5_change_pct')
    vals=[v for v in (c1,c3,c5) if v is not None]
    if c1 is None:missing.append('btc_1m')
    if c3 is None:missing.append('btc_3m')
    if not vals:return 'SOURCE_MISSING',missing
    avg=sum(vals)/len(vals)
    if avg>=0.55:return 'STRONG_UP',missing
    if avg>=0.12:return 'UP',missing
    if avg<=-0.55:return 'STRONG_DOWN',missing
    if avg<=-0.12:return 'DOWN',missing
    return 'FLAT',missing

def run_once()->Dict[str,Any]:
    started=time.monotonic();nowv=now_ts();obj=load_json(MARKET,{}) or {}
    rows=obj.get('rows') if isinstance(obj,dict) and isinstance(obj.get('rows'),list) else []
    tradable=[r for r in rows if isinstance(r,dict) and not r.get('major_watch') and ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market')) not in {'BTC','ETH'}]
    n=len(tradable); changes=[_row_num(r,'change_24h') or 0.0 for r in tradable]
    up=sum(1 for x in changes if x>0); down=sum(1 for x in changes if x<0); strong=sum(1 for x in changes if x>=2.0); breadth=up/max(1,n)*100.0
    downside_breadth=down/max(1,n)*100.0
    change_mean=(sum(changes)/len(changes)) if changes else 0.0
    change_dispersion=(sum((x-change_mean)**2 for x in changes)/len(changes))**0.5 if changes else 0.0
    ordered=sorted(tradable,key=lambda r:_row_num(r,'turnover_24h') or 0.0,reverse=True)
    top30=ordered[:30]; top10=ordered[:10]
    top30_turn=sum(_row_num(r,'turnover_24h') or 0.0 for r in top30)
    total_turn=sum(_row_num(r,'turnover_24h') or 0.0 for r in ordered)
    top10_turn=sum(_row_num(r,'turnover_24h') or 0.0 for r in top10)
    concentration=(top10_turn/total_turn*100.0) if total_turn>0 else None
    avg_top60=sum(changes[:60])/max(1,min(60,n)) if changes else 0.0
    leaders=[ticker_norm(r.get('ticker') or r.get('symbol') or r.get('market')) for r in top10]

    state=load_json(STATE,{}) or {}; history=state.get('history') if isinstance(state,dict) and isinstance(state.get('history'),list) else []
    external=_upbit_external_btc(nowv,state.get('external_market_v2130') if isinstance(state,dict) else {})
    history=[x for x in history if isinstance(x,dict) and nowv-float(x.get('ts') or 0.0)<=900]
    prev=history[-1] if history else {}
    prev_b=fnum(prev.get('breadth'),default=None);prev_c=fnum(prev.get('concentration'),default=None)
    breadth_vel=(breadth-prev_b) if prev_b is not None else None
    concentration_vel=(concentration-prev_c) if concentration is not None and prev_c is not None else None
    overlaps=[]
    current=set(leaders)
    for sample in history[-5:]:
        past=set(str(x) for x in (sample.get('leaders') or []))
        if past:overlaps.append(len(current & past)/max(1,len(current | past))*100.0)
    leader_persistence=sum(overlaps)/len(overlaps) if overlaps else None

    btc=_btc_row(rows);btc_direction,btc_missing=_btc_direction(btc)
    missing=[]
    if not btc:missing.append('btc_row')
    missing.extend(btc_missing)
    if external.get('state')!='READY':missing.append('external_market_lead')
    if concentration is None:missing.append('turnover_concentration')
    if breadth_vel is None:missing.append('breadth_velocity_warmup')
    if leader_persistence is None:missing.append('leader_persistence_warmup')

    components=[]
    components.append(max(0.0,min(100.0,50.0+(breadth-50.0)*2.0)))
    components.append(max(0.0,min(100.0,50.0+avg_top60*12.0)))
    if breadth_vel is not None:components.append(max(0.0,min(100.0,50.0+breadth_vel*5.0)))
    if leader_persistence is not None:components.append(leader_persistence)
    btc_score={'STRONG_UP':85.0,'UP':70.0,'FLAT':50.0,'DOWN':28.0,'STRONG_DOWN':15.0}.get(btc_direction)
    if btc_score is not None:components.append(btc_score)
    external_score={'STRONG_UP':85.0,'UP':70.0,'FLAT':50.0,'DOWN':28.0,'STRONG_DOWN':15.0}.get(external.get('direction')) if external.get('state')=='READY' else None
    if external_score is not None:components.append(external_score)
    continuation=sum(components)/len(components) if components else None
    if continuation is None:ctx_state='SOURCE_MISSING'
    elif continuation>=65:ctx_state='STRONG'
    elif continuation>=55:ctx_state='SUPPORTIVE'
    elif continuation>=42:ctx_state='MIXED'
    else:ctx_state='WEAK'
    risk='RISK_OFF' if btc_direction in {'DOWN','STRONG_DOWN'} and breadth<42 else ('DANGER' if breadth<35 else ('WEAK' if ctx_state=='WEAK' else 'NORMAL'))
    old_score=0
    old_score+=2 if breadth>=55 else (-1 if breadth<42 else 0)
    old_score+=2 if strong>=35 else (1 if strong>=18 else -1)
    old_score+=2 if avg_top60>=0.8 else (-1 if avg_top60<-0.5 else 0)
    old_score+=1 if top30_turn>=25_000_000_000 else 0
    mode='강함' if old_score>=4 else ('보통' if old_score>=1 else '약함')
    context={
        'schema':'global_market_context_v2130','owner':'market_regime_worker','state':ctx_state,
        'continuation_score_v2130':round(continuation,3) if continuation is not None else None,
        'risk_state_v2130':risk,'breadth_up_pct':round(breadth,3),'breadth_down_pct_v2155':round(downside_breadth,3),
        'breadth_velocity_pct_v2130':round(breadth_vel,4) if breadth_vel is not None else None,
        'market_change_mean_pct_v2155':round(change_mean,4),'market_change_dispersion_pct_v2155':round(change_dispersion,4),
        'avg_top60_change_v2155':round(avg_top60,4),'strong_alt_count_v2155':strong,'tradable_alt_count_v2155':n,
        'turnover_concentration_top10_pct_v2130':round(concentration,3) if concentration is not None else None,
        'turnover_concentration_velocity_v2130':round(concentration_vel,4) if concentration_vel is not None else None,
        'leader_persistence_pct_v2130':round(leader_persistence,3) if leader_persistence is not None else None,
        'btc_short_direction':btc_direction,'btc_change_1m':_row_num(btc,'change_1m','scanner_change_1m_pct','change_1m_pct'),
        'btc_change_3m':_row_num(btc,'change_3m','scanner_change_3m_pct','change_3m_pct'),
        'btc_change_5m':_row_num(btc,'change_5m','change_5m_pct','m5_change_pct'),
        'source_missing_v2130':sorted(set(missing)),'external_market_source_v2130':external.get('source') if external.get('state')=='READY' else 'SOURCE_MISSING_NOT_FAKED',
        'external_market_lead_v2130':external,
        'component_truth_v2155':{
            'breadth_level_pct':round(breadth,3),'breadth_velocity_pct':round(breadth_vel,4) if breadth_vel is not None else None,
            'downside_breadth_pct':round(downside_breadth,3),'avg_top60_change_pct':round(avg_top60,4),
            'market_change_dispersion_pct':round(change_dispersion,4),'turnover_concentration_top10_pct':round(concentration,3) if concentration is not None else None,
            'turnover_concentration_velocity':round(concentration_vel,4) if concentration_vel is not None else None,
            'leader_persistence_pct':round(leader_persistence,3) if leader_persistence is not None else None,
            'btc_direction':btc_direction,'external_direction':external.get('direction') if external.get('state')=='READY' else None,
            'risk_state':risk,'mode':mode,
        },
        'component_truth_v2156':{
            'breadth':{'current':round(breadth,4),'prior':round(prev_b,4) if prev_b is not None else None,
                       'delta':round(breadth_vel,4) if breadth_vel is not None else None,
                       'current_ts':nowv,'prior_ts':prev.get('ts'),'state':'READY' if breadth_vel is not None else 'WARMUP'},
            'btc':{'direction':btc_direction,'change_1m':_row_num(btc,'change_1m','scanner_change_1m_pct','change_1m_pct'),
                   'change_3m':_row_num(btc,'change_3m','scanner_change_3m_pct','change_3m_pct'),
                   'change_5m':_row_num(btc,'change_5m','change_5m_pct','m5_change_pct'),
                   'source':'bithumb_scanner_market_cache','state':'READY' if btc_direction!='SOURCE_MISSING' else 'SOURCE_MISSING'},
            'external':{'direction':external.get('direction'),'state':external.get('state'),'source':external.get('source'),
                        'change_1m':external.get('btc_change_1m'),'change_3m':external.get('btc_change_3m'),
                        'change_5m':external.get('btc_change_5m'),'age_sec':external.get('age_sec')},
            'risk':{'state':risk,'breadth':round(breadth,4),'btc_direction':btc_direction,'context_state':ctx_state},
            'liquidity':{'concentration_current':round(concentration,4) if concentration is not None else None,
                         'concentration_prior':round(prev_c,4) if prev_c is not None else None,
                         'concentration_delta':round(concentration_vel,4) if concentration_vel is not None else None,
                         'dispersion':round(change_dispersion,4),'leader_persistence':round(leader_persistence,4) if leader_persistence is not None else None},
            'updated_ts':nowv,'prior_ts':prev.get('ts'),
        },
        'raw_relative_strength_owner_v2130':'feature_worker','structure_owner_v2130':'candle/strategy','updated_ts':nowv,'owner_version_v2155':VERSION,'owner_version_v2156':VERSION,'auto_buy':False,
    }
    out={'version':VERSION,'build':BUILD_LABEL,'schema':'market_regime_v2156_prediction_input_truth','updated_ts':nowv,'updated_text':now_text(nowv),
         'mode':mode,'score':old_score,'row_count':n,'breadth_up_pct':round(breadth,1),'strong_count':strong,'avg_top60_change':round(avg_top60,3),
         'top30_turnover':round(top30_turn,0),'global_market_context_v2130':context,
         'policy_v2130':'Market owns separate breadth, BTC, leadership, concentration, volatility and risk-state inputs; v2156 seals current/prior/delta/source truth without changing the score formula.'}
    save_json(OUT,out)
    history.append({'ts':nowv,'breadth':breadth,'concentration':concentration,'leaders':leaders})
    save_json(STATE,{'schema':'market_context_state_v2130','version':VERSION,'updated_ts':nowv,'history':history[-120:],
                     'external_market_v2130':external,'auto_buy':False})
    write_status('running',row_count=n,mode=mode,score=old_score,global_state_v2130=ctx_state,global_score_v2130=context.get('continuation_score_v2130'),
                 btc_short_direction_v2130=btc_direction,external_market_state_v2130=external.get('state'),
                 external_market_direction_v2130=external.get('direction'),source_missing_count_v2130=len(set(missing)),last_sec=round(time.monotonic()-started,4),auto_buy=False)
    return out

def main()->None:
    write_status('initializing',auto_buy=False)
    while True:
        try:run_once()
        except KeyboardInterrupt:write_status('stopping',auto_buy=False);raise
        except Exception as exc:append_error('loop',exc);write_status('error',error=f'{type(exc).__name__}: {exc}',auto_buy=False)
        time.sleep(max(1.0,INTERVAL_SEC))

if __name__=='__main__':main()
