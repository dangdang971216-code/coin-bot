v2176 목적
- 같은 commit인데 Strategy S1과 Paper S1 개수가 달라 보이던 원인을 commit-only 비교와 generation 혼합으로 확인
- Strategy hold writer 하나가 commit+generation+hold hash+row count를 봉인
- Paper receipt/처리도 같은 tuple만 PASS
- S1 0개도 정상 tuple로 처리
- 단일화 후 남는 구 versioned Python/bytecode는 기존 /gupgrade_bundle 과정에서 삭제
- 거래원장·과거 후보·Shadow·전략수치·자동매수 상태는 변경하지 않음
