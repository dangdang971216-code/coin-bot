v934: issue_ledger NameError 직접호출 수정 + exact 표본 0 대기표시
적용: 가드 /gupgrade_bundle
검수: 메인 /batch
