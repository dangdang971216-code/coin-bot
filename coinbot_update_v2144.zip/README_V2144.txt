coinbot update v2144

Purpose
- Add Guard /gprediction_export.
- One command sends the three existing prediction-analysis source files as one Telegram ZIP.
- Fixed filenames only; missing file fails closed. No fallback/cache.

Changed
- Guard v2.6.23 only

Unchanged
- Main, Paper, Strategy, Review and all other workers
- Prediction/trading/entry/exit numbers and ledgers
- Auto-buy OFF
