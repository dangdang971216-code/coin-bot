v1706: guard post-restart auto-continuation fix + condition owner inventory support_files/cache-missing fail marker. No trading rule change. Auto-buy OFF.
