# v1097 quality/open/Paper recovery

## Confirmed causes
1. The v1096 quality gate required positive short reaction plus two additional confirmations, which blocked all 416 evaluated rows, including valid pullback/retest swing structures.
2. The reset manifest had a batch id and an empty target list. The runtime treated it as reusable, so the remaining active PAPER OPEN set was not resealed.
3. Paper published `startup_permissions` before several later startup tasks and ran performance/classifier refresh before entering the cycle. This hid the real phase and delayed reset ownership.

## Fix
- Structure, execution freshness, actual-entry RR and target room remain hard contracts.
- Quality now rejects unsafe reaction, zero independent confirmation, extreme traps, or material source gaps. It does not require every soft axis.
- Remaining candidates are ranked by Strategy before Paper applies OPEN 30 / new-per-cycle 3.
- An empty/exhausted reset manifest with active OPEN is replaced by a new recovery batch built only from the actual current OPEN set. The prior batch is recorded in the reset event ledger.
- Exact commit ordering remains CLOSED append -> decision CLOSED -> OPEN removal. Failed items remain OPEN.
- Paper defers heavy startup performance/classifier refresh while reset is pending and enters the runtime cycle immediately.

## Server verification
1. `/gupgrade_bundle`
2. `/gquality_recovery_v1097 240`
3. `/gworker_state`
4. `/gops_refresh`
5. Main: `/quality_rebuild_status`, `/quality_open_audit`, `/ops_focus`, `/errorlog`
6. Paper: `/pstatus`, `/perror`

## DONE conditions
- Paper v1.010, Strategy v0.998, Guard v2.5.150, Main v2.13.1083.
- Recovery reseal target is greater than zero.
- Remaining/unresolved/failed reset counts are zero and exact CLOSED count covers the target.
- Reset-transition rows stay excluded from strategy windows.
- Epoch is ACTIVE and current OPEN is at most 30.
- Quality gate pass count is greater than zero and block count is less than total evaluated rows.
- Paper status is fresh and runtime phase is not stuck in startup.
- New runtime errors zero; exact duplicate/key-missing/unlinked remain zero; auto-buy OFF.
