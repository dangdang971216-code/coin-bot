# v1088 public command dispatcher single-registry repair

## Symptom
- Main runtime was v2.13.1075 and the five map handlers were present in `COMMANDS` and Telegram menu registration.
- Direct and multiline requests returned `공개 명령 없음` for `/ops_map`, `/code_map`, `/system_map`, `/resource_map`, `/ledger_map`.

## Root cause
- `render_command_text` owned a second hard-coded public command allowlist.
- The map commands were added to the canonical `COMMANDS` table but omitted from that separate allowlist.
- Both single-command and multiline execution pass through `render_command_text`, so all five were blocked.

## Repair
- Remove the hard-coded public allowlist from `render_command_text`.
- Resolve public commands only from canonical `COMMANDS`.
- Preserve unknown-command rejection and per-command error logging.
- Record runtime issue/change evidence once on Main startup.

## Not changed
- Guard map collector and snapshot schema
- Paper, Strategy, Risk, Review and surrounding workers
- trigger, invalid, target, RR, spread, slippage, entry or exit
- OPEN limits and automatic trading
- OPEN/CLOSED/trade_log/decision/exact ledgers

## Local verification
- Python compile PASS.
- Top-level duplicate definitions 0.
- Extracted real dispatcher chain: all five maps PASS.
- Existing `/health`, `/popen`, `/book_reset_status` PASS.
- Unknown command still rejected.
- Source diff limited to dispatcher, v1088 runtime evidence and Main VERSION/BUILD.

## Server DONE criteria
- Main runtime `수익형 v2.13.1076`.
- All five map commands no longer return `공개 명령 없음`.
- All five display the same Guard snapshot ID and digest after `/gops_refresh`.
- `/commands` lists all five map commands.
- New runtime errors 0 and auto-buy OFF.
