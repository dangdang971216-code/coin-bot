import importlib.util
import json
import os
import tempfile
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def load_guard(bot_dir: Path):
    os.environ['BOT_DIR']=str(bot_dir)
    os.environ.setdefault('GUARD_BOT_TOKEN','dummy-token')
    os.environ.setdefault('GUARD_CHAT_ID','1')
    spec=importlib.util.spec_from_file_location('guard_v1146',ROOT/'backga_guard_bot_v2_5_187.py')
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def raw_performance_edge():
    return [{
        'from':'performance','to':'main','artifact':{
            'name':'canonical_performance_snapshot_v987.json','status':'CHECK',
            'freshness_policy':'SEMANTIC_SIGNATURE_EVENT_DRIVEN',
            'event_driven_contract':{
                'applicable':True,'state':'CHECK_OWNER_HEARTBEAT_STALE',
                'source_changed_after_output':False,'heartbeat_fresh':False,
                'output_mtime':1.0,'status_ts':0.0,
                'sources':[{'name':'paper_bot_open.json','newer_than_output':False}],
            },
        },
    }]

with tempfile.TemporaryDirectory() as td_raw:
    td=Path(td_raw)
    guard=load_guard(td)
    nowv=time.time()

    current_after_write_status={
        'paper_performance_semantic_heartbeat_v1117':{
            'last_check_at':nowv,
            'owner':'paper_bot_single_canonical_performance_writer',
            'state':'CURRENT_AFTER_WRITE',
            'last_mode':'future_exact_reseal',
            'semantic_current':True,
            'event_driven_idle':False,
            'source_signature_match':True,
            'boundary_due_after_check':False,
            'snapshot_exists':True,
            'snapshot_id':'perf-current',
            'snapshot_age_sec':0.08,
            'next_boundary_in_sec':737.4,
            'canonical_snapshot_rewrite_for_heartbeat':False,
        }
    }
    current_root=guard._ops_performance_root_cause_v1117(current_after_write_status,nowv)
    assert current_root['diagnosis_state']=='PROVEN_CURRENT_AFTER_WRITE',current_root
    assert current_root['semantic_status']=='CURRENT_AFTER_WRITE'
    current_final=guard._ops_finalize_semantic_lineage_v1145(raw_performance_edge(),{'performance':current_root})
    assert guard._ops_final_semantic_edge_checks_v1145(current_final)==[]
    art=current_final[0]['artifact']
    assert art['status']=='NORMAL'
    assert art['semantic_status']=='CURRENT_AFTER_WRITE'
    assert art['event_driven_contract']['state']=='PROVEN_CURRENT_AFTER_WRITE'
    assert art['event_driven_contract']['raw_evidence_reference_v1145']['judgement_owner']=='REFERENCE_ONLY_NOT_A_VERDICT'
    assert current_final[0]['final_edge_digest_v1145']==art['final_semantic_edge_v1145']['digest']

    idle_status={
        'paper_performance_semantic_heartbeat_v1117':{
            'last_check_at':nowv,
            'owner':'paper_bot_single_canonical_performance_writer',
            'state':'EVENT_DRIVEN_IDLE',
            'last_mode':'noop',
            'semantic_current':True,
            'event_driven_idle':True,
            'source_signature_match':True,
            'boundary_due_after_check':False,
            'snapshot_exists':True,
            'snapshot_id':'perf-idle',
        }
    }
    idle_root=guard._ops_performance_root_cause_v1117(idle_status,nowv)
    assert idle_root['diagnosis_state']=='PROVEN_EVENT_DRIVEN_IDLE',idle_root
    idle_final=guard._ops_finalize_semantic_lineage_v1145(raw_performance_edge(),{'performance':idle_root})
    assert guard._ops_final_semantic_edge_checks_v1145(idle_final)==[]
    assert idle_final[0]['artifact']['semantic_status']=='EVENT_DRIVEN_IDLE'

    stale_status={
        'paper_performance_semantic_heartbeat_v1117':{
            'last_check_at':nowv-120,
            'owner':'paper_bot_single_canonical_performance_writer',
            'state':'CURRENT_AFTER_WRITE',
            'last_mode':'boundary_refresh',
            'semantic_current':True,
            'event_driven_idle':False,
            'source_signature_match':True,
            'boundary_due_after_check':False,
            'snapshot_exists':True,
            'snapshot_id':'perf-stale',
        }
    }
    stale_root=guard._ops_performance_root_cause_v1117(stale_status,nowv)
    assert stale_root['diagnosis_state']=='CHECK_PERFORMANCE_WRITER',stale_root
    stale_final=guard._ops_finalize_semantic_lineage_v1145(raw_performance_edge(),{'performance':stale_root})
    checks=guard._ops_final_semantic_edge_checks_v1145(stale_final)
    assert len(checks)==1
    assert stale_final[0]['artifact']['status']=='CHECK'
    assert stale_final[0]['artifact']['semantic_status']=='SEMANTIC_OWNER_NOT_PROVEN'

    mismatch_status={
        'paper_performance_semantic_heartbeat_v1117':{
            'last_check_at':nowv,
            'owner':'paper_bot_single_canonical_performance_writer',
            'state':'CURRENT_AFTER_WRITE','last_mode':'boundary_refresh',
            'semantic_current':True,'event_driven_idle':False,
            'source_signature_match':False,'boundary_due_after_check':False,
            'snapshot_exists':True,'snapshot_id':'perf-mismatch',
        }
    }
    assert guard._ops_performance_root_cause_v1117(mismatch_status,nowv)['diagnosis_state']=='CHECK_PERFORMANCE_WRITER'

    boundary_due_status={
        'paper_performance_semantic_heartbeat_v1117':{
            'last_check_at':nowv,
            'owner':'paper_bot_single_canonical_performance_writer',
            'state':'CURRENT_AFTER_WRITE','last_mode':'boundary_refresh',
            'semantic_current':True,'event_driven_idle':False,
            'source_signature_match':True,'boundary_due_after_check':True,
            'snapshot_exists':True,'snapshot_id':'perf-boundary-due',
        }
    }
    assert guard._ops_performance_root_cause_v1117(boundary_due_status,nowv)['diagnosis_state']=='CHECK_PERFORMANCE_WRITER'

    wrong_owner_status={
        'paper_performance_semantic_heartbeat_v1117':{
            'last_check_at':nowv,
            'owner':'legacy_or_unknown_writer',
            'state':'CURRENT_AFTER_WRITE','last_mode':'boundary_refresh',
            'semantic_current':True,'event_driven_idle':False,
            'source_signature_match':True,'boundary_due_after_check':False,
            'snapshot_exists':True,'snapshot_id':'perf-wrong-owner',
        }
    }
    assert guard._ops_performance_root_cause_v1117(wrong_owner_status,nowv)['diagnosis_state']=='CHECK_PERFORMANCE_WRITER'

    # Canonical lifecycle paths must be used; retired BOT_DIR root ledgers are not v1146 targets.
    source=(ROOT/'backga_guard_bot_v2_5_187.py').read_text(encoding='utf-8')
    assert "BOT_DIR/'runtime'/'change_verify_ledger.jsonl'" in source
    assert "BOT_DIR/'ledger'/'issue_ledger_events.jsonl'" in source
    lifecycle=source[source.find('# v1146: canonical lifecycle records'):source.find('if __name__ == "__main__":')]
    assert "BOT_DIR/'issue_ledger.jsonl'" not in lifecycle
    assert "BOT_DIR/'change_verify_ledger.jsonl'" not in lifecycle
    assert 'v1146-guard-semantic-current-after-write-owner-001' in source
    assert 'guard_v2.5.187_semantic_current_after_write_owner_v1146_2026-06-30' in source

print(json.dumps({
    'ok':True,
    'current_after_write_normal':True,
    'event_driven_idle_normal':True,
    'stale_semantic_proof_check':True,
    'signature_boundary_owner_fail_closed':True,
    'paper_last_mode_reference_only':True,
    'same_final_digest':True,
    'canonical_lifecycle_paths':True,
},ensure_ascii=False))
