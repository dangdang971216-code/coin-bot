# v1146 작업 잠금 — Performance CURRENT_AFTER_WRITE semantic owner closeout

- issue: GUARD-SEMANTIC-CURRENT-1146 / OPEN
- 이전 서버: v1145 Guard v2.5.186
- 수정 파일: backga_guard_bot.py → backga_guard_bot_v2_5_187.py
- 전략 영향: 없음 / Guard read-only owner 판정만 수정
- 자동매수: OFF 유지

## 서버에서 확인된 v1145 결과
- Risk→Strategy, Risk→Paper: raw mtime CHECK는 reference-only로 남고 final semantic edge는 NORMAL. v1145 목표 달성.
- Performance→Main: Paper heartbeat가 CURRENT_AFTER_WRITE, semantic_current=True, signature match=True, boundary_due=False, snapshot fresh였지만 Guard가 EVENT_DRIVEN_IDLE만 정상으로 인정해 CHECK.
- v1145 issue/change seed는 retired BOT_DIR root ledger를 사용해 Main canonical 장부에 나타나지 않음.
- 후보 기준판의 EXECUTION_DEGRADED 조기 승격은 별도 Review truth issue이며 v1146 범위에서 제외.

## owner / caller / writer / reader
- semantic truth owner: Paper `paper_performance_semantic_heartbeat_v1117`
- caller: Guard `_ops_performance_root_cause_v1117`
- final writer: Guard one final semantic edge object/digest → ops_map snapshot
- readers: edge list, error groups, location index, root cause, Main `/flow_map_full`

## 삭제할 구판정
1. Performance semantic proof를 EVENT_DRIVEN_IDLE 하나로만 제한하는 idle-only 조건
2. CURRENT_AFTER_WRITE를 writer failure로 바꾸는 경로
3. v1145 lifecycle seed의 retired root-level ledger targets

## 새 본선
fresh Paper heartbeat + canonical owner match + semantic_current + source signature match + snapshot exists + boundary not due
→ Paper가 봉인한 EVENT_DRIVEN_IDLE 또는 CURRENT_AFTER_WRITE
→ final NORMAL edge object/digest 1개
→ 모든 Guard reader가 동일 object 소비
- `last_mode`는 참고 증거만 보존하고 Guard가 별도 mode whitelist를 만들지 않음

## 변경 금지
Strategy/Paper/Risk source, Strategy cache, 후보 기준판 계산, Gate, rank, TTL, trigger, invalid, target, RR, trailing, OPEN 30, cycle 3, 보호 원장, 자동매수.
