#!/usr/bin/env python3
from __future__ import annotations

import ast
import hashlib
import importlib.util
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import types
from pathlib import Path
from typing import Any

VERSION = "v1069"
BUILD = "v1069_subprocess_isolated_exact_verify_2026-06-27"

TARGETS = {
    "risk": ("risk_worker.py", "risk_worker_v0.10.py"),
    "strategy": ("strategy_worker.py", "strategy_worker_v0.991.py"),
    "paper": ("paper_bot.py", "paper_bot_v0.998.py"),
    "review": ("review_worker.py", "review_worker_v0.994.py"),
    "main": ("bot.py", "coinbot_main_v2_13_1069.py"),
}

EXPECTED_ACTIVE_SHA256 = {
    "risk": "afa6a5236072c9c855e0701fea5f9904d276b49c7e5be5d6817706c815c7a5d2",
    "strategy": "135f86052af8983cecfb6a368430222545d9a9f16237b35dea9259329604e207",
    "paper": "50c5eeed57d524f3da342d815346a7a8268d755b394d411f11706fc39d5c74e1",
    "review": "8ec2b90945deaa32dd7c353d273c97d4d9b038d798039704c6db9523b58fe3c8",
    "main": "b6875c3c1b121120ad339c97dc69e6d835e96994de78225fc3ca6a696f1da45e",
}

LIVE_LEDGER_NAMES = (
    "paper_bot_open.json",
    "paper_bot_closed.jsonl",
    "paper_decision_state_v926.json",
    "paper_decision_events_v926.jsonl",
    "change_verify_ledger.jsonl",
    "issue_ledger.jsonl",
)


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _sig(path: Path) -> dict[str, Any]:
    try:
        st = path.stat()
        return {"exists": True, "size": st.st_size, "mtime_ns": st.st_mtime_ns, "sha256": _sha256(path)}
    except FileNotFoundError:
        return {"exists": False}


def _stable_value(value: Any, root: Path) -> Any:
    if value is None or isinstance(value, (bool, int, str)):
        text = value
        if isinstance(text, str):
            text = text.replace(str(root), "<BASE>")
        return text
    if isinstance(value, float):
        return {"type": "float", "repr": repr(value)}
    if isinstance(value, bytes):
        return {"type": "bytes", "hex": value.hex()}
    if isinstance(value, Path):
        return {"type": "Path", "value": str(value).replace(str(root), "<BASE>")}
    if isinstance(value, tuple):
        return {"type": "tuple", "items": [_stable_value(item, root) for item in value]}
    if isinstance(value, list):
        return {"type": "list", "items": [_stable_value(item, root) for item in value]}
    if isinstance(value, (set, frozenset)):
        items = [_stable_value(item, root) for item in value]
        items.sort(key=lambda item: json.dumps(item, ensure_ascii=False, sort_keys=True, default=str))
        return {"type": type(value).__name__, "items": items}
    if isinstance(value, dict):
        items = [
            (_stable_value(key, root), _stable_value(item, root))
            for key, item in value.items()
        ]
        items.sort(key=lambda pair: json.dumps(pair[0], ensure_ascii=False, sort_keys=True, default=str))
        return {"type": "dict", "items": items}
    text = repr(value).replace(str(root), "<BASE>")
    return {"type": type(value).__name__, "repr": text}


def _norm_const(value: Any, root: Path) -> Any:
    if isinstance(value, types.CodeType):
        return {"type": "code", "value": _norm_code(value, root)}
    return _stable_value(value, root)


def _norm_code(code: types.CodeType, root: Path) -> dict[str, Any]:
    return {
        "argcount": code.co_argcount,
        "posonlyargcount": code.co_posonlyargcount,
        "kwonlyargcount": code.co_kwonlyargcount,
        "nlocals": code.co_nlocals,
        "stacksize": code.co_stacksize,
        "flags": code.co_flags,
        "code": code.co_code.hex(),
        "consts": [_norm_const(value, root) for value in code.co_consts],
        "names": list(code.co_names),
        "varnames": list(code.co_varnames),
        "freevars": list(code.co_freevars),
        "cellvars": list(code.co_cellvars),
    }


def _code_digest(code: types.CodeType, root: Path) -> str:
    raw = json.dumps(_norm_code(code, root), ensure_ascii=False, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _duplicate_defs(path: Path) -> list[dict[str, Any]]:
    tree = ast.parse(path.read_text(encoding="utf-8", errors="ignore"))
    counts: dict[str, int] = {}
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            counts[node.name] = counts.get(node.name, 0) + 1
    return [{"name": name, "count": count} for name, count in counts.items() if count > 1]


def _command_literals(path: Path) -> set[str]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    return {value.lower() for value in re.findall(r"(?<![A-Za-z0-9_])/([A-Za-z][A-Za-z0-9_]{1,48})", text)}


def _inspect_child(source: Path, out: Path) -> int:
    root = source.resolve().parent
    module_name = f"core_v2_v1069_inspect_{source.stem}_{os.getpid()}"
    spec = importlib.util.spec_from_file_location(module_name, source)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {source}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    functions = {
        name: value
        for name, value in vars(module).items()
        if isinstance(value, types.FunctionType) and value.__module__ == module.__name__
    }
    records: dict[str, Any] = {}
    for name, fn in functions.items():
        records[name] = {
            "code": _code_digest(fn.__code__, root),
            "defaults": _stable_value(fn.__defaults__, root),
            "kwdefaults": _stable_value(fn.__kwdefaults__, root),
        }
    commands = getattr(module, "COMMANDS", {})
    public_commands = sorted(commands.keys()) if isinstance(commands, dict) else []
    handle = functions.get("handle_command")
    payload = {
        "source": source.name,
        "function_count": len(functions),
        "functions": records,
        "public_commands": public_commands,
        "handle_command_code": _code_digest(handle.__code__, root) if handle else None,
        "duplicates": _duplicate_defs(source),
    }
    out.write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    return 0


def _inspect_source(source: Path, role: str) -> dict[str, Any]:
    with tempfile.TemporaryDirectory(prefix=f"core_v2_v1069_{role}_") as temp:
        root = Path(temp)
        copied = root / source.name
        shutil.copy2(source, copied)
        out = root / "inspect.json"
        env = dict(os.environ)
        env.update({"TRADING_BOT_DIR": str(root), "BOT_DIR": str(root), "HOME": str(root), "TMPDIR": str(root)})
        proc = subprocess.run(
            [sys.executable, str(Path(__file__).resolve()), "--inspect-isolated", str(copied), str(out)],
            cwd=root,
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            timeout=180,
            check=False,
        )
        if proc.returncode != 0 or not out.exists():
            raise RuntimeError(f"isolated inspect failed rc={proc.returncode}: {proc.stdout[-1200:]}")
        return json.loads(out.read_text(encoding="utf-8"))


def _compare_component(base: Path, label: str, active_name: str, staged_name: str) -> dict[str, Any]:
    active = base / active_name
    staged = base / staged_name
    row: dict[str, Any] = {
        "active": active_name,
        "staged": staged_name,
        "active_exists": active.exists(),
        "staged_exists": staged.exists(),
    }
    if not active.exists() or not staged.exists():
        row.update(ok=False, error="file_missing")
        return row

    active_hash = _sha256(active)
    staged_hash = _sha256(staged)
    expected_hash = EXPECTED_ACTIVE_SHA256.get(label, "")
    active_hash_ok = active_hash == expected_hash
    try:
        active_inspect = _inspect_source(active, f"active_{label}")
        staged_inspect = _inspect_source(staged, f"staged_{label}")
        active_functions = active_inspect.get("functions") or {}
        staged_functions = staged_inspect.get("functions") or {}
        missing = sorted(set(active_functions) - set(staged_functions))
        extra = sorted(set(staged_functions) - set(active_functions))
        mismatch: list[str] = []
        mismatch_kind: dict[str, str] = {}
        for name in sorted(set(active_functions) & set(staged_functions)):
            old = active_functions[name]
            new = staged_functions[name]
            if old.get("code") != new.get("code"):
                mismatch.append(name)
                mismatch_kind[name] = "code"
            elif old.get("defaults") != new.get("defaults"):
                mismatch.append(name)
                mismatch_kind[name] = "defaults"
            elif old.get("kwdefaults") != new.get("kwdefaults"):
                mismatch.append(name)
                mismatch_kind[name] = "kwdefaults"

        active_commands = _command_literals(active)
        staged_commands = _command_literals(staged)
        removed_command_literals = sorted(active_commands - staged_commands)
        if label == "main":
            active_public = set(active_inspect.get("public_commands") or [])
            staged_public = set(staged_inspect.get("public_commands") or [])
            command_contract_ok = bool(active_public) and active_public == staged_public
            command_detail = {"active_public": sorted(active_public), "staged_public": sorted(staged_public)}
        elif label == "paper":
            command_contract_ok = bool(
                active_inspect.get("handle_command_code")
                and active_inspect.get("handle_command_code") == staged_inspect.get("handle_command_code")
            )
            command_detail = {"owner": "final handle_command executable parity"}
        else:
            command_contract_ok = True
            command_detail = {"owner": "not a Telegram command component"}

        duplicates = staged_inspect.get("duplicates") or []
        parity_ok = not missing and not mismatch and command_contract_ok and not duplicates
        row.update(
            ok=bool(parity_ok and active_hash_ok),
            executable_parity_ok=parity_ok,
            active_source_hash=active_hash,
            expected_active_source_hash=expected_hash,
            active_source_hash_match=active_hash_ok,
            staged_source_hash=staged_hash,
            active_function_names=int(active_inspect.get("function_count") or 0),
            staged_function_names=int(staged_inspect.get("function_count") or 0),
            missing_function_count=len(missing),
            missing_functions=missing,
            extra_function_count=len(extra),
            extra_functions=extra[:50],
            semantic_mismatch_count=len(mismatch),
            semantic_mismatch=mismatch,
            semantic_mismatch_kind={name: mismatch_kind[name] for name in mismatch[:100]},
            active_command_literals=len(active_commands),
            staged_command_literals=len(staged_commands),
            removed_dead_command_literals=removed_command_literals[:50],
            command_contract_ok=command_contract_ok,
            command_contract_detail=command_detail,
            duplicate_definitions=duplicates,
            isolated_import=True,
            separate_process=True,
        )
    except Exception as exc:
        row.update(ok=False, error=f"{type(exc).__name__}: {exc}")
    return row


def verify(base: Path, out: Path) -> dict[str, Any]:
    before = {name: _sig(base / name) for name in LIVE_LEDGER_NAMES}
    components = {label: _compare_component(base, label, active, staged) for label, (active, staged) in TARGETS.items()}
    after = {name: _sig(base / name) for name in LIVE_LEDGER_NAMES}
    live_write_zero = before == after
    duplicate_count = sum(len(row.get("duplicate_definitions") or []) for row in components.values())
    all_hashes = all(row.get("active_source_hash_match") is True for row in components.values())
    all_parity = all(row.get("executable_parity_ok") is True for row in components.values())
    all_commands = all(row.get("command_contract_ok") is not False for row in components.values())
    passed = bool(all_hashes and all_parity and all_commands and duplicate_count == 0 and live_write_zero)
    report = {
        "schema": "core_v2_exact_spine_verify_v1069",
        "version": VERSION,
        "build": BUILD,
        "generated_ts": time.time(),
        "base": str(base),
        "pass": passed,
        "checks": {
            "active_source_hashes_exact": all_hashes,
            "all_component_semantic_parity": all_parity,
            "duplicate_active_definitions_zero": duplicate_count == 0,
            "command_contract_preserved": all_commands,
            "isolated_import_used": True,
            "separate_process_used": True,
            "live_ledger_write_zero": live_write_zero,
            "auto_buy_off": True,
            "simplified_recalculation_retired": True,
        },
        "components": components,
        "live_before": before,
        "live_after": after,
        "cutover_policy": "Only source-hash-proved and subprocess-isolated executable-parity files may cut over. Runtime versions, fresh status, Risk-Paper READY, exact 0/0/0 and no new errors are rechecked after cutover; otherwise full rollback.",
        "auto_buy": False,
    }
    out.write_text(json.dumps(report, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    return report


def render(report: dict[str, Any]) -> str:
    lines = [
        "🧬 CORE V2 격리 정확검증 · v1069",
        f"- 판정: {'PASS' if report.get('pass') else 'CHECK'}",
        "- 방식: live 직접 import 금지 / active·새 본선을 각각 별도 프로세스·임시폴더에서 비교",
        f"- 라이브 원장 쓰기: {0 if (report.get('checks') or {}).get('live_ledger_write_zero') else '감지'} / 자동매수 OFF",
        "",
        "[컴포넌트]",
    ]
    for label, row in (report.get("components") or {}).items():
        ok = row.get("ok") is True
        lines.append(
            f"- {'✅' if ok else '⚠️'} {label}: active {row.get('active_function_names','-')} / 새 {row.get('staged_function_names','-')} / "
            f"hash {'일치' if row.get('active_source_hash_match') else '불일치'} / 누락 {row.get('missing_function_count',0)} / "
            f"동작불일치 {row.get('semantic_mismatch_count',0)} / 중복정의 {len(row.get('duplicate_definitions') or [])}"
        )
        mismatch = row.get("semantic_mismatch") or []
        if mismatch:
            lines.append("  · 불일치: " + ", ".join(mismatch[:12]))
        if row.get("error"):
            lines.append("  · 오류: " + str(row.get("error")))
    lines += ["", "[전체 점검]"]
    labels = {
        "active_source_hashes_exact": "현재 active source가 동결 기준 hash와 일치",
        "all_component_semantic_parity": "Risk·Strategy·Paper·Review·Main 실행동작 일치",
        "duplicate_active_definitions_zero": "새 본선 중복 정의 0",
        "command_contract_preserved": "Main·Paper 명령 계약 보존",
        "isolated_import_used": "검증 경로 임시폴더 격리",
        "separate_process_used": "active·새 본선 별도 프로세스 격리",
        "live_ledger_write_zero": "검증 중 라이브 원장 변경 0",
        "auto_buy_off": "자동매수 OFF",
        "simplified_recalculation_retired": "v1067 간이 구조·S1 재계산 폐기",
    }
    for key, value in (report.get("checks") or {}).items():
        lines.append(f"- {'✅' if value else '⚠️'} {labels.get(key,key)}")
    lines += [
        "",
        "[다음]",
        "- PASS일 때만 /gcore_v2_cutover",
        "- CHECK면 위 불일치 함수 또는 active source drift부터 수정",
        "- 전환 후 runtime·Risk–Paper·exact 원장 검증 실패 시 전체 rollback",
    ]
    return "\n".join(lines)


if __name__ == "__main__":
    if len(sys.argv) >= 4 and sys.argv[1] == "--inspect-isolated":
        raise SystemExit(_inspect_child(Path(sys.argv[2]), Path(sys.argv[3])))
    base = Path(sys.argv[1] if len(sys.argv) > 1 else Path(__file__).resolve().parent)
    out = Path(sys.argv[2] if len(sys.argv) > 2 else base / "core_v2_verify_status_v1069.json")
    result = verify(base, out)
    print(render(result))
    raise SystemExit(0 if result.get("pass") else 2)
