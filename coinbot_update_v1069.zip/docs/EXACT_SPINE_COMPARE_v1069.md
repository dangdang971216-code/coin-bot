# CORE V2 v1069 정확 본선 비교

## v1068 CHECK 원인
v1068 검증기는 서버의 active `bot.py`와 `paper_bot.py`를 원래 경로에서 직접 import했다. 두 파일은 `BASE_DIR = Path(__file__).resolve().parent`를 사용하므로 검증 import가 라이브 status/ledger 경로를 읽고 일부 상태를 갱신했다. active와 staged import가 서로 다른 runtime 상태를 보면서 가짜 의미불일치와 live-write 경고가 발생했다.

## v1069 수정
- active/staged source를 각각 독립 임시폴더로 복사한 뒤 import
- CWD, HOME, TMPDIR, TRADING_BOT_DIR, BOT_DIR 모두 임시폴더로 격리
- 현재 active alias SHA256을 동결 기준과 exact 비교
- 전체 불일치 개수와 함수명을 숨기지 않고 출력
- live OPEN/CLOSED/decision/change/issue 원장 전후 SHA256 일치 확인
- PASS 전에는 cutover 금지

## 전략 영향
없음. 진입·청산·RR·trigger·invalid·target·trailing·OPEN 한도는 변경하지 않는다.
