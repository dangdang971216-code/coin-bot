# CORE V2 v1070 전체점검표

- [x] Risk active source hash exact
- [x] Strategy active source hash exact
- [x] Paper active source hash exact
- [x] Review active source hash exact
- [x] Main active source hash exact
- [x] active/staged 독립 임시폴더 import
- [x] 실행 바이트코드·defaults·kwdefaults 비교
- [x] Main command registry 보존
- [x] Paper final handle_command 보존
- [x] 새 본선 중복 top-level 정의 0
- [x] 검증 중 라이브 원장 write 0
- [x] 자동매수 OFF
- [x] cutover 전체 rollback 유지
- [ ] 서버 /gcore_v2_verify PASS
- [ ] 서버 /gcore_v2_cutover runtime 증명
- [ ] 재시작 후 유지 증명
