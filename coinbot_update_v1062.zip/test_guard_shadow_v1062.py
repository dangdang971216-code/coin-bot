import importlib.util, json, os, tempfile
from pathlib import Path

os.environ['GUARD_BOT_TOKEN']='dummy'
os.environ['GUARD_CHAT_ID']='1'
spec=importlib.util.spec_from_file_location('guardv1062','/mnt/data/v1062_work/backga_guard_bot_v2_5_118.py')
mod=importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
base=Path(tempfile.mkdtemp(prefix='corev2shadow1062_'))
mod.BOT_DIR=base
mod.CORE_V2_SHADOW_OUTPUT_DIR_V1061=base.parent/(base.name+'_out')
mod.PAPER_ACTIVE_FILE='paper_bot.py'
(base/'paper_bot.py').write_text('DEFAULT_CONTROL={"max_open_strict": 0, "max_new_per_cycle": 0}\n',encoding='utf-8')

def row(ticker, decision, candidate, entry=102, occurrence=None):
    occ=occurrence or {'candidate_key':candidate,'kind':'INITIAL_OR_MIGRATED_ABOVE','plan_frozen_ts':300,'trigger_price':100}
    return {
        'ticker':ticker,'s_stage':'S1','strategy_mode':'ALT_SWING_V977',
        'open_eligible':True,'paper_bot_open':True,'trade_ready':True,
        'swing_gate_decision_key_v977':decision,'candidate_entry_build_key':candidate,
        'current_price':entry,'spread_pct':0.2,'strategy':'hot-rank 급등 재확인',
        'trigger_occurrence_v1037':occ,
        'swing_entry_gate_v977':{
            'schema':'swing_entry_gate_v977_single_owner','strategy_mode':'ALT_SWING_V977',
            'decision_key':decision,'hard_pass':True,'final_trade_state':'S1_PASS','source_fresh':True,
            'trigger_price':100,'invalid_price':95,'target_price':115,'trigger_occurrence_v1037':occ,
        },
        'trigger_gate_v738':{'entry_price':entry,'trigger_gap_pct':0.3,'trigger_price':100,'trigger_reached':True},
    }

rows=[
    # Prior loss, exact new reset/rebreak => must be allowed even cooldown active.
    row('AAA','d-new','c-new',102,{'candidate_key':'c-new','kind':'REBREAK','reset_ts':210,'rebreak_ts':220,'plan_frozen_ts':150,'trigger_price':100}),
    # Prior loss, same event => exact reentry block.
    row('BBB','d-old','c-old',102,{'candidate_key':'c-old','kind':'INITIAL_OR_MIGRATED_ABOVE','plan_frozen_ts':150,'trigger_price':100}),
    # No prior loss, but same ticker already OPEN and actual RR below 1.5.
    row('CCC','d-ccc','c-ccc',109,{'candidate_key':'c-ccc','kind':'INITIAL_OR_MIGRATED_ABOVE','plan_frozen_ts':300,'trigger_price':100}),
]
(base/'paper_s1_hold_cache.json').write_text(json.dumps({'schema':'paper_s1_hold_cache_v979_swing_contract','rows':rows}),encoding='utf-8')
prior={
 'AAA':{'candidate_key':'c-old-a','decision_key':'d-old-a','closed_ts':200,'trigger_price':100,'exit_price':98,'identity_complete':True},
 'BBB':{'candidate_key':'c-old','decision_key':'d-old','closed_ts':200,'trigger_price':100,'exit_price':98,'identity_complete':True},
}
(base/'clean_risk_filter_cache.json').write_text(json.dumps({
    'schema':'risk_filter_v1057_canonical_loss_closed_ts',
    'cooldown':{'AAA':{'level':'loss'},'BBB':{'level':'loss'}},
    'last_loss_event_by_ticker':prior,
}),encoding='utf-8')
(base/'paper_bot_status.json').write_text(json.dumps({
    'risk_paper_contract_v1059':{
        'schema':'paper_risk_contract_status_v1059','ready':True,
        'closed_signature_match':True,'consumer_evidence_present':True,
        'latest_loss_selection':'max_numeric_closed_ts_per_ticker'},
    'pick_stats':{'s1_seen':3,'selected_s1':1},'opened_count':1,'elapsed_sec':12.3}),encoding='utf-8')
(base/'paper_bot_open.json').write_text(json.dumps({'decision:x':{'ticker':'CCC'}}),encoding='utf-8')
text, report=mod._v1061_run_shadow('')
print(text)
by={r['ticker']:r for r in report['results']}
assert report['schema']=='coinbot_core_v2_shadow_report_v1062'
assert report['version']=='v1062'
assert by['AAA']['risk']['loss_reentry_state']=='NEW_TRIGGER_REBREAK_CONFIRMED'
assert by['AAA']['core_v2_shadow_pass'] is True
assert 'loss_reentry_blocked' not in by['AAA']['blockers']
assert by['BBB']['risk']['loss_reentry_state']=='SAME_EVENT_BLOCK'
assert 'loss_reentry_blocked' in by['BBB']['blockers']
assert 'same_ticker_open' in by['CCC']['blockers']
assert 'actual_rr_below_1_5' in by['CCC']['blockers']
assert report['counts']['reentry_allowed_new_trigger']==1
assert report['counts']['reentry_blocked']==1
assert report['counts']['reentry_no_prior_loss']==1
assert report['counts']['core_v2_shadow_pass']==1
assert report['live_trade_write_performed'] is False
print('PASS')
