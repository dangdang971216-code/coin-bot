#!/usr/bin/env python3
from pathlib import Path
import json,hashlib
ROOT=Path(__file__).parent
m=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1166'
assert m['main']=='coinbot_main_v2_13_1126.py'
assert m['paper']=='paper_bot_v1.035.py'
assert m['workers']=={'strategy':'strategy_worker_v1.025.py'}
assert m['guard'] is None
assert m['approved_target_sha256']==hashlib.sha256((ROOT/m['main']).read_bytes()).hexdigest()
assert m['auto_buy'] is False and m['live_ledger_included'] is False
for name in m['support_files']:
    assert (ROOT/name).exists(),name
for forbidden in ('paper_bot.py','strategy_worker.py','bot.py','paper_bot_open.json','paper_bot_closed.jsonl','paper_bot_trade_log.jsonl','issue_ledger.jsonl','change_verify_ledger.jsonl'):
    assert not (ROOT/forbidden).exists(),forbidden
print('PASS v1166 package')
