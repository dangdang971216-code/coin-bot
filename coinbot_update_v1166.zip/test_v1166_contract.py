#!/usr/bin/env python3
from pathlib import Path
import ast, hashlib, json, tempfile, types
from collections import Counter
from typing import Any, Dict, Optional

ROOT=Path(__file__).parent
MAIN=ROOT/'coinbot_main_v2_13_1126.py'
STRATEGY=ROOT/'strategy_worker_v1.025.py'
PAPER=ROOT/'paper_bot_v1.035.py'

for src in (MAIN,STRATEGY,PAPER):
    mod=ast.parse(src.read_text(encoding='utf-8'))
    names=Counter(n.name for n in mod.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)))
    assert not {k:v for k,v in names.items() if v>1}, (src.name,names)

main_text=MAIN.read_text(encoding='utf-8')
assert "BOT_VERSION = '수익형 v2.13.1126'" in main_text
assert "V650_BUILD_LABEL = 'v1166_candidate_time_owner_and_transport_spine_2026-06-30'" in main_text
assert "EXPECTED_STRATEGY_VERSION = 'strategy_worker_v1.025'" in main_text
for key in ('s1_event_to_s1_commit_sec','s1_commit_to_candidate_snapshot_sec','candidate_snapshot_to_priority_commit_sec','priority_commit_to_handoff_commit_sec','handoff_commit_to_paper_resolve_sec','paper_resolve_to_candidate_read_sec'):
    assert key in main_text
assert main_text.index("COMMANDS['issue_ledger']=render_issue_ledger_text") < main_text.rindex('if __name__ == "__main__":')

strategy_text=STRATEGY.read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.025'" in strategy_text
assert "BUILD_LABEL = 'v1166_candidate_time_owner_and_transport_spine_2026-06-30'" in strategy_text
assert 'completed_generation_committed_at_v1166' in strategy_text
assert strategy_text.index('_v1158_committed_handoff = _v1158_commit_paper_handoff(') < strategy_text.index("'key_spine_status_after_handoff_v1166'")

paper_text=PAPER.read_text(encoding='utf-8')
assert "VERSION = 'paper_bot_v1.035'" in paper_text
assert "BUILD_LABEL = 'v1166_candidate_time_owner_and_transport_spine_2026-06-30'" in paper_text
assert "schema':'paper_candidate_delay_path_v1166_owner_split'" in paper_text
assert "time_owner_policy_v1166" in paper_text

# Trading decision functions must be byte-for-byte AST equivalent to the prior verified baseline.
expected_strategy={
'apply_swing_entry_gate':'7cd11edf742e92e77d7b9b7cd75dc9a27c7e189629f234176ad7d309dff17a01',
'_v1133_trigger_occurrence':'9168d76eeff876e69b8a69c0f436933b0e47fcf6a749d2ab1a34dbe78090c3b4',
'_swing_quality_gate':'1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1',
'_v554_apply_entry_plan_state__v1115':'a256712ce2ebe9b3813e529d55211cc68d31495345c8f9d49951005fab5ccc1d',
}
mod=ast.parse(strategy_text)
for name,digest in expected_strategy.items():
    node=next(n for n in mod.body if isinstance(n,ast.FunctionDef) and n.name==name)
    assert hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()==digest,name
expected_paper={
'trigger_occurrence_freshness_v1133':'fcffc4577cc5bf3d70491dd602e61737d3abead0267434f8e3a92925091c5da9',
'candidate_freshness_evidence_v1039':'8617c23fa5f7c3e880f471ae533dce296b238270e2872f2f05e00d265e7bc045',
'is_s1_candidate':'afcba1710258499af2ce8de239080fc1e434ff0530835296cc8690c66c52e09d',
}
modp=ast.parse(paper_text)
for name,digest in expected_paper.items():
    node=next(n for n in modp.body if isinstance(n,ast.FunctionDef) and n.name==name)
    assert hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()==digest,name

# Isolated owner-split test: a long semantic wait must not be labeled as a writer bottleneck.
def extract_func(text: str, name: str):
    mod=ast.parse(text)
    node=next(n for n in mod.body if isinstance(n,ast.FunctionDef) and n.name==name)
    return compile(ast.Module(body=[node],type_ignores=[]),'<isolated>','exec')

def fnum(*vals,default=0.0):
    for v in vals:
        try:
            if v not in (None,'',[],{}): return float(v)
        except Exception: pass
    return float(default)

def delta(end,start):
    end=fnum(end); start=fnum(start)
    if end<=0 or start<=0 or end<start: return None
    return round(end-start,3)

g={
'Any':Any,'Dict':Dict,'Optional':Optional,
'fnum':fnum,'_v1152_nonnegative_delta':delta,
'read_strategy_entry_gate':lambda row: row.get('swing_entry_gate_v977') or {},
'_v1153_paper_path_identity':lambda row:{'trigger_event_key':'K','candidate_key':'C','direct_decision_key':'D'},
'normalize_ticker':lambda x:str(x or '').replace('KRW-',''),
'now_ts':lambda:147.0,
}
exec(extract_func(paper_text,'candidate_delay_path_v1152'),g)
row={
 'ticker':'KRW-TEST','candidate_pipeline_cycle_id_v1150':'cycle-1',
 'candidate_path_timestamps_v1153':{
   'trigger_event_at':100.0,'quality_evaluated_at':110.0,'quality_pass_at':110.0,
   's1_hold_created_at':140.0,'s1_hold_file_committed_at_v1166':141.0,
   'candidate_snapshot_committed_at_v1166':143.0,'priority_requests_committed_at_v1166':144.0,
   'completed_generation_committed_at_v1166':145.0,'paper_generation_resolved_at_v1166':146.0,
   'paper_received_at':147.0,
 },
}
path=g['candidate_delay_path_v1152'](row,{'candidate_commit_id':'commit-1'},{'candidate_ttl_sec':120.0},147.0)
assert path['semantic_wait_segments_v1166']['quality_to_s1_sec']==30.0
assert path['largest_transport_segment_v1166']=='s1_commit_to_candidate_snapshot_sec'
assert path['largest_segment']=='s1_commit_to_candidate_snapshot_sec'
assert path['paper_transport_total_sec_v1166']==6.0
assert path['transport_spine_complete_v1166'] is True
assert path['expired_by_sec']==0.0

# Isolated immutable-handoff test: Strategy must seal the same cycle/commit stage clocks
# that Paper later hashes and consumes.
with tempfile.TemporaryDirectory() as td:
    tdir=Path(td)
    hs={
        'Any':Any,'Dict':Dict,'Optional':Optional,'Path':Path,
        'hashlib':hashlib,'json':json,
        'STRATEGY_PAPER_HANDOFF_DIR_V1158':tdir,
        'VERSION':'strategy_worker_v1.025','BUILD_LABEL':'v1166',
        'now_ts':lambda:145.0,'now_text':lambda ts=None:'T',
        'save_json':lambda path,obj: Path(path).write_text(json.dumps(obj,ensure_ascii=False,sort_keys=True),encoding='utf-8'),
    }
    exec(extract_func(strategy_text,'_v1158_commit_paper_handoff'),hs)
    hold={'candidate_pipeline_cycle_id_v1150':'cycle-1','updated_ts':141.0,'schema':'hold','rows':[{'ticker':'TEST','candidate_path_timestamps_v1153':{'s1_hold_created_at':140.0}}]}
    payload=hs['_v1158_commit_paper_handoff']('cycle-1','commit-1',hold,461,12,5,145.0,
        s1_hold_completed_ts=141.0,candidate_snapshot_completed_ts=143.0,priority_requests_completed_ts=144.0)
    sealed=payload['s1_rows'][0]['candidate_path_timestamps_v1153']
    assert sealed['s1_hold_file_committed_at_v1166']==141.0
    assert sealed['candidate_snapshot_committed_at_v1166']==143.0
    assert sealed['priority_requests_committed_at_v1166']==144.0
    assert sealed['completed_generation_committed_at_v1166']==145.0
    assert sealed['transport_cycle_id_v1166']=='cycle-1'
    assert Path(payload['handoff_file_v1158']).is_file()

print('PASS v1166 contract')
