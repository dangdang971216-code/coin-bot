# v1166 작업 잠금

- 증상: 후보 시간판이 전략 상태대기와 실제 전달처리를 섞어 writer 병목으로 오판함.
- 실제 owner: Strategy semantic events / Strategy file+generation commits / Paper generation resolve+candidate read.
- 수정 파일: Strategy, Paper, Main.
- 삭제 구경로: semantic gap을 writer delay로 판정하는 largest owner, S1→Paper 단일 덩어리, handoff 전 key-spine status writer.
- 새 본선: S1 commit → candidate snapshot → priority commit → completed generation → Paper resolve → candidate read.
- 검수: 동일 cycle_id·candidate_commit_id, 6개 transport timestamp, runtime/hash, 신규 오류 0.
- 전략 영향: 없음. Gate·TTL·RR·trigger·invalid·target·청산·OPEN 한도 고정.
