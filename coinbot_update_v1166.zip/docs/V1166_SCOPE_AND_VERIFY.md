# v1166 범위와 서버 검수

## 수정
1. Strategy가 S1 파일·candidate snapshot·priority·completed generation 실제 commit 시각을 immutable handoff row에 봉인한다.
2. Paper가 completed generation 확인시각과 후보 최초 판독시각을 기록한다.
3. 시간판은 전략 상태대기와 실제 전달처리를 분리하며 writer 병목은 transport commit 증거로만 판정한다.
4. key-spine 상태 writer는 completed generation 봉인 뒤 실행한다.

## 서버 완료 기준
- Main v2.13.1126 / Strategy v1.025 / Paper v1.035 exact runtime·hash.
- 신규 후보 10개에서 transport spine 6구간 중 누락 0 또는 누락 원인 명시.
- largest segment가 실제 transport owner로 표시.
- 같은 cycle_id·candidate_commit_id 연결.
- 새 runtime 오류 0, 자동매수 OFF.
