v1600: v1427 candidate spine rebuild. Preserve shadow/ledgers/readable commands. Active status files are versionless canonical names. Auto-buy OFF. No trading thresholds changed.
