import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_manifest():
    m=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text())
    assert m['version']=='v1255'
    assert m['guard']=='backga_guard_bot_v2_5_234.py'
    assert m['main']=='coinbot_main_v2_13_1158.py'
    assert m['workers']['structure_rebuild']=='structure_rebuild_worker_v0.1.py'
    assert m['actual_trading_changed'] is False
    assert m['auto_buy'] is False

def test_no_live_ledgers():
    forbidden={'paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.jsonl','paper_decision_state_v926.json'}
    names={p.name for p in ROOT.rglob('*') if p.is_file()}
    assert not (names & forbidden)

def test_main_command_is_registered():
    text=(ROOT/'coinbot_main_v2_13_1158.py').read_text()
    assert '"structure_rebuild": render_structure_rebuild' in text
    assert 'BotCommand("structure_rebuild", "v1211 구조선 중심 감사")' in text
    assert 'dispatcher.add_handler(CommandHandler(name, make_handler(name)))' in text

def test_main_worker_versions_present():
    assert '수익형 v2.13.1158' in (ROOT/'coinbot_main_v2_13_1158.py').read_text()
    assert 'structure_rebuild_worker_v0.1' in (ROOT/'structure_rebuild_worker_v0.1.py').read_text()
