coinbot_update_v1366.zip
- Guard-only fix.
- Does not modify Strategy/Paper/Main trading logic.
- OLD_BASE_REBUILD release verification now accepts Strategy active=activating only when strong runtime evidence exists: pid/version/rows/evaluated/S/target/last_sec/writer OK/error none.
- cycle/commit native absence remains INFO for old-base.
