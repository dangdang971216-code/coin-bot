v1351 material final connection. Runtime change: main+strategy+paper. Auto-buy OFF. No live ledger included.
