v1330 SCORE REASON AUDIT DEEP READONLY

목적:
- /score_reason_audit 강화
- CLOSED row + paper_decision_state exact key 연결
- invalid 손실군 vs swing_trailing 수익군의 점수 구성·저장 커버리지·RR/매수체결/invalid거리 패턴 비교
- 현재 S1의 약한 힘 표시를 진단 전용으로 출력

변경 없음:
- 후보식, trigger, invalid, target, RR, 청산계약, Paper 실행, 자동매수
- 라이브 OPEN/CLOSED/decision 원장 포함 없음

적용 후:
- guard: /grelease_verify
- main: /score_reason_audit
