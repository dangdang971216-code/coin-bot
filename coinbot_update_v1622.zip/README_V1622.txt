v1622 SLIPPAGE_STALE boundary immediate refresh retry - compat deploy manifest
- v1621 bundle was copied but not applied because the deployed guard read expected targets as SKIP.
- v1622 keeps the same trading intent and adds the v1619-compatible manifest keys: main/paper/strategy/target_router/workers/aliases.
- 35~60s stale slippage is retried once with fresh execution data; >60s or trigger/RR/target/spread/slippage risk stays blocked.
- Candidate criteria, Gate, RR, trigger/invalid/target, exit, OPEN limit and auto-buy OFF are unchanged.
