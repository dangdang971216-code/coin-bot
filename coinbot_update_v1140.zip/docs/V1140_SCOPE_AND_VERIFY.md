# v1140 scope

## Actual fixes

- Promote event-driven edge CHECK evidence into the full-map top problem groups.
- Replace `/candidate_summary` tail-300 display scope with the complete current atomic Strategy snapshot.
- Record a fresh proof file and mark scope CHECK if writer count, parse count, or writer result disagrees.

## Strategy safety lock

- The active `id(rows)` normalized-frame cache key remains unchanged.
- v1140 adds a deterministic shadow sample only.
- The shadow compares the exact normalized output across JSON object reloads under a Candle-owned source identity.
- A synthetic same-identity/different-output case is detected as a violation while active output continues to follow the real input.
- No optimization may be activated until server comparisons >=30, reload-object samples >0, exact-output violations=0, and locked function hashes remain identical.

## Not changed

Gate, rank, candidate TTL, trigger, invalid, target, actual-entry RR, spread/slippage limits, OPEN 30, cycle 3, exit contracts, protected ledgers, auto-buy OFF.

## Verification order

1. Paper `/candidate_summary`, `/pstatus`, `/perror` creates the current full-snapshot proof.
2. Guard `/gops_refresh`, `/gdeploy` maps the proof and runtime identities.
3. Main `/flow_map_full`, `/change_verify`, `/issue_ledger`, `/errorlog` confirms visible edge CHECKs and cache shadow evidence.
