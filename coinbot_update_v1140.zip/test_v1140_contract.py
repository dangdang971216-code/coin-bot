import ast, hashlib, importlib.util, json, os, shutil, tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parent
STRAT=ROOT/'strategy_worker_v1.012.py'
PAPER=ROOT/'paper_bot_v1.024.py'
GUARD=ROOT/'backga_guard_bot_v2_5_181.py'
MAIN=ROOT/'coinbot_main_v2_13_1107.py'
BASE=json.loads((ROOT/'BASELINE_FUNCTION_HASHES_V1139.json').read_text(encoding='utf-8'))


def load_copy(src: Path, name: str):
    td=Path(tempfile.mkdtemp(prefix='v1140_'))
    dst=td/src.name
    shutil.copy2(src,dst)
    old=os.environ.get('TRADING_BOT_DIR')
    os.environ['TRADING_BOT_DIR']=str(td)
    try:
        spec=importlib.util.spec_from_file_location(name,dst)
        mod=importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)
        return mod,td
    finally:
        if old is None: os.environ.pop('TRADING_BOT_DIR',None)
        else: os.environ['TRADING_BOT_DIR']=old


def function_hashes(path: Path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    out={}
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
            h=hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest()
            out.setdefault(n.name,[]).append(h)
    return out

# 1) Every pre-existing function outside the explicit display/map/shadow owners
# must remain AST-identical to v1139/v1.011/v1.023.
allowed={
    'strategy':{'_lab_rows','attach_structure_lab'},
    'paper':{'candidate_summary_text__v1135','write_status__v1135'},
    'guard':{'_ops_problem_location_v1107','_ops_build_flow_map_v1103','collect_ops_map_snapshot'},
    'main':{'render_flow_map_full_text__v1137'},
}
paths={'strategy':STRAT,'paper':PAPER,'guard':GUARD,'main':MAIN}
for component,path in paths.items():
    cur=function_hashes(path)
    for name,hashes in BASE[component].items():
        if name in allowed[component]:
            continue
        assert cur.get(name)==hashes, f'{component}:{name} changed outside locked scope'

# 2) Strategy active key and output remain unchanged. v1140 is shadow-only.
smod,std=load_copy(STRAT,'strategy_v1140_test')
rows1=[[1,10,11,12,9,100],[2,11,12,13,10,110],[3,12,13,14,11,120],[4,13,14,15,12,130],[5,14,15,16,13,140],[6,15,16,17,14,150]]
rows2=json.loads(json.dumps(rows1))
assert id(rows1)!=id(rows2)
assert smod._lab_frame_cache_key_v1109(rows1,'m5')!=smod._lab_frame_cache_key_v1109(rows2,'m5'), 'active id(rows) key was changed'
# choose a deterministic shadow-sampled ticker
sample_ticker=None
for i in range(5000):
    t=f'T{i}'
    if smod._lab_stable_identity_shadow_sample_v1140({'ticker':t},'m5'):
        sample_ticker=t; break
assert sample_ticker
meta={'ticker':sample_ticker,'candle_ts':1000.0,'structure_lab_candles':{'updated_ts':1000.0,'last_full_profile_fetch_ts':900.0,'sources':{'m5':'official'},'frames':{'m5':rows1}}}
a=smod._lab_rows(meta,'m5')
meta2=json.loads(json.dumps(meta))
b=smod._lab_rows(meta2,'m5')
assert a==b
shadow=smod._lab_stable_identity_shadow_status_v1140()
assert shadow['comparisons']>=1 and shadow['exact_equivalent']>=1 and shadow['exact_output_violations']==0, shadow
assert shadow['json_reload_object_change_samples']>=1, shadow
# Synthetic upstream owner violation: same metadata, changed interior frame. Shadow must detect it,
# while active output still follows the changed input (shadow is never used for reads).
meta3=json.loads(json.dumps(meta)); meta3['structure_lab_candles']['frames']['m5'][2][2]=99
c=smod._lab_rows(meta3,'m5')
shadow2=smod._lab_stable_identity_shadow_status_v1140()
assert shadow2['exact_output_violations']>=1, shadow2
assert any(abs(r['c']-99.0)<1e-9 for r in c), c
src=STRAT.read_text(encoding='utf-8')
key_body=src.split('def _lab_frame_cache_key_v1109',1)[1].split('def _lab_normalized_frame_stats_snapshot_v1109',1)[0]
assert 'id(rows)' in key_body and 'stable_source_identity_shadow_v1140' not in key_body
assert smod.VERSION=='strategy_worker_v1.012'
shutil.rmtree(std,ignore_errors=True)

# 3) Paper reads all 460 rows from the atomic current snapshot and fails CHECK on writer mismatch.
pmod,ptd=load_copy(PAPER,'paper_v1140_test')
now=pmod.now_ts()
rows=[]
for i in range(460):
    grade='S1' if i<10 else ('S2' if i<200 else 'S3')
    rows.append({'ticker':f'T{i}','candidate_grade':grade,'created_ts':now})
with (ptd/'paper_candidates_latest.jsonl').open('w',encoding='utf-8') as f:
    for row in rows: f.write(json.dumps(row,ensure_ascii=False)+'\n')
(ptd/'clean_strategy_paper_latest_writer_status.json').write_text(json.dumps({'result':'OK','rows_written':460,'candidate_rows_v1021':460}),encoding='utf-8')
parsed,scope=pmod._v1140_read_current_candidate_snapshot()
assert len(parsed)==460 and scope['state']=='NORMAL' and scope['tail_cap_removed'] is True, scope
text=pmod.candidate_summary_text()
assert '현재 후보판 snapshot 460' in text and 'tail 300 표본이 아님' in text, text[:1500]
proof=json.loads((ptd/'paper_candidate_summary_scope_v1140.json').read_text(encoding='utf-8'))
assert proof['state']=='NORMAL' and proof['parsed_rows']==460
(ptd/'clean_strategy_paper_latest_writer_status.json').write_text(json.dumps({'result':'OK','rows_written':300}),encoding='utf-8')
_,bad=pmod._v1140_read_current_candidate_snapshot()
assert bad['state']=='CHECK' and bad['writer_expected_rows']==300 and bad['parsed_rows']==460, bad
assert pmod.VERSION=='paper_bot_v1.024'
shutil.rmtree(ptd,ignore_errors=True)

# 4) Map contract is direct, not another renderer wrapper/fallback.
gsrc=GUARD.read_text(encoding='utf-8'); msrc=MAIN.read_text(encoding='utf-8')
assert 'EVENT_DRIVEN_EDGE_CONTRACT_CHECK' in gsrc
assert 'CANDIDATE_SUMMARY_SCOPE_MISMATCH' in gsrc
assert 'STRATEGY_CACHE_SHADOW_VIOLATION' in gsrc
assert "reader_owner_contracts_v1140" in gsrc
assert '_ops_age(' not in gsrc
assert 'guard_v2.5.181_map_edge_scope_shadow_v1140_2026-06-29' in gsrc
assert "수익형 v2.13.1107" in msrc
assert 'MAP-SCOPE-CACHE-SHADOW-1140' in msrc
assert 'render_flow_map_full_text__v1140' not in msrc
assert "extra1140=globals().get('_v1140_map_contract_lines')" in msrc

# 5) Locked trading invariants and no live ledger payloads in sources.
paper_src=PAPER.read_text(encoding='utf-8')
assert '"max_open_strict": 30' in paper_src
assert '"max_new_per_cycle": 3' in paper_src
for path in (STRAT,PAPER,GUARD,MAIN):
    txt=path.read_text(encoding='utf-8')
    assert 'auto_buy' in txt.lower() or 'AUTO_BUY' in txt

print('PASS v1140 display/map fixes + Strategy shadow-only exact-equivalence contract')
