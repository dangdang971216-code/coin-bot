import hashlib,json,zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1140' and m['auto_buy'] is False and m['live_ledger_included'] is False
assert m['main']=='coinbot_main_v2_13_1107.py'
assert m['paper']=='paper_bot_v1.024.py'
assert m['guard']=='backga_guard_bot_v2_5_181.py'
assert m['workers']=={'strategy':'strategy_worker_v1.012.py'}
assert m['strategy_behavior_change'] is False and m['strategy_cache_activation'] is False and m['strategy_shadow_only'] is True
for f in [m['main'],m['paper'],m['guard'],*m['workers'].values(),*m['support_files']]:
    assert (ROOT/f).is_file(),f
for forbidden in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','paper_decision_state_v926.json','canonical_performance_snapshot_v987.json','change_verify_ledger.jsonl','issue_ledger.jsonl'):
    assert not (ROOT/forbidden).exists(),forbidden
rows=(ROOT/'FILES_SHA256_v1140.tsv').read_text(encoding='utf-8').splitlines()
for row in rows[1:]:
    h,size,name=row.split('\t',2); p=ROOT/name
    assert p.stat().st_size==int(size),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
print('PASS v1140 extracted bundle manifest/hash/no-live-ledger contract')
