Coinbot v1480
Canonical runtime root single transaction repair.
Main/Paper/Strategy active state files use TRADING_BOT_DIR only.
Source directories are not runtime state roots.
Build v1480_CANONICAL_RUNTIME_ROOT_SINGLE_TRANSACTION_AUTOBUY_OFF_2026-07-12
Auto-buy OFF. Trading rules unchanged.
