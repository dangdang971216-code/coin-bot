v1335: /score_reason_audit and /exit_shadow_audit read-only shadow expansion. Soft loss suppressor + protective-exit shadow only. No trading logic change. SERVER_CHECK until applied.
