#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_bot_v0.218_v603_final_trade_state_open_only_runtime_reapply_2026-05-31

목적:
- v0.50/v389/v397 계열의 무거운 paper runtime을 더 이상 타지 않는다.
- paper 실행기는 S1 후보 읽기 → OPEN → 기존 OPEN 청산 → 장부 저장 → 알림만 담당한다.
- OPEN/CLOSED/trade_log 장부는 보존하고, 전체 CLOSED 재계산/복기/score full 계산은 실행 루프에서 제외한다.
- v416/v0.127: paper OPEN 직전 최종 안전문을 직접 확인하고, 약한 체결/넓은 스프레드/미끄러짐 후보를 장부 OPEN 전에 보류한다.
- v479: 무반응 S1은 폐기/차단이 아니라 paper OPEN만 보류하고 다음 recheck cycle에 맡긴다.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
import traceback
import re
import urllib.parse
import urllib.request
from collections import Counter, deque
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'
BASE_DIR = Path(__file__).resolve().parent

FILES: Dict[str, Path] = {
    "paper_latest": BASE_DIR / "paper_candidates_latest.jsonl",
    "s1_hold": BASE_DIR / "paper_s1_hold_cache.json",
    "s1_hold_jsonl": BASE_DIR / "paper_s1_hold_cache.jsonl",
    "s1_hold_trace": BASE_DIR / "paper_s1_hold_consume_trace.jsonl",
    "open": BASE_DIR / "paper_bot_open.json",
    "closed": BASE_DIR / "paper_bot_closed.jsonl",
    "status": BASE_DIR / "paper_bot_status.json",
    "control": BASE_DIR / "paper_bot_control.json",
    "pid": BASE_DIR / "paper_bot.pid",
    "trace": BASE_DIR / "paper_bot_candidate_handoff_trace.json",
    "handoff_status": BASE_DIR / "paper_bot_candidate_handoff_status.json",
    "score": BASE_DIR / "paper_bot_score_cache.json",
    "classify": BASE_DIR / "paper_bot_classify_cache.json",
    "trade_review": BASE_DIR / "paper_bot_trade_review_cache.json",
    "open_alert_trace": BASE_DIR / "paper_bot_open_alert_trace.jsonl",
    "open_backup": BASE_DIR / "paper_bot_open_backup.json",
    "open_quarantine": BASE_DIR / "paper_bot_open_quarantine.jsonl",
    "open_loss_trace": BASE_DIR / "paper_bot_open_loss_trace.jsonl",
    "close_alert_trace": BASE_DIR / "paper_bot_close_alert_trace.jsonl",
    "hot_rank": BASE_DIR / "clean_scanner_hot_rank_cache.json",
    "error": BASE_DIR / "paper_bot_error.log",
    "log": BASE_DIR / "paper_bot.log",
}

DEFAULT_CONTROL: Dict[str, Any] = {
    "running": True,
    "loop_seconds": 8,
    "open_monitor_interval_sec": 2.0,
    "max_open_strict": 0,
    "max_new_per_cycle": 0,
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_on_s1_decision_summary": True,
    "notify_s1_decision_summary_interval_sec": 3600,
    "notify_s1_decision_summary_min_interval_sec": 3600,  # backward compat
    "notify_open_min_score": 4.45,
    "notify_open_require_micro_fresh": True,
    "notify_open_require_ws_fresh": False,
    "preopen_micro_recheck": True,
    "preopen_micro_urgent_ttl_sec": 35,
    "paper_final_reaction_proof_enabled": True,
    "paper_final_reaction_proof_mode": "recheck_hold",
    "paper_final_reaction_proof_min_windows": 2,
    "paper_final_reaction_proof_min_flow_pct": 0.01,
    "block_same_ticker_open": True,
    "candidate_ttl_sec": 120,
    "candidate_read_max_lines": 800,
    "consume_latest_scan_only": True,
    "write_score_cache": True,
    "latest_scan_window_sec": 8,
    "fee_pct_roundtrip": 0.10,
    "take_profit_pct": 1.20,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.35,
    "protect_strong_trigger_pct": 1.00,
    "protect_strong_floor_pct": 0.50,
    "protect_big_trigger_pct": 1.40,
    "protect_big_floor_pct": 0.75,
    "protect_giveback_pct": 0.55,
    "stop_loss_pct": -0.55,
    "fast_fail_after_min": 2.5,
    "fast_fail_peak_under_pct": 0.20,
    "fast_fail_loss_pct": -0.35,
    "fast_fail_after_min_late": 5.0,
    "fast_fail_loss_pct_late": -0.25,
    "slow_minutes": 20,
    "slow_peak_under_pct": 0.25,
    "time_exit_minutes": 15,
    # v486: 손실은 빠르게, 수익권은 조건부로 길게 본다.
    "profit_soft_protect_trigger_pct": 0.45,
    "profit_soft_protect_floor_pct": 0.10,
    "profit_soft_protect_giveback_pct": 0.45,
    "profit_run_extend_enabled": True,
    "profit_run_extend_minutes": 15,
    "profit_run_extend_max_count": 1,
    "profit_run_extend_min_net_pct": 0.20,
    "profit_run_extend_min_peak_pct": 0.25,
    "profit_run_extend_max_giveback_pct": 0.25,
    "profit_run_strategy_keywords": ["주도", "유동보유", "leader", "momentum"],
    "notify_market_hot_alert": True,
    "notify_market_hot_immediate_enabled": False,
    "notify_market_hot_summary_interval_sec": 3600,
    "notify_market_hot_immediate_min_interval_sec": 3600,  # backward compat
    "notify_market_hot_global_min_interval_sec": 3600,
    "notify_market_hot_ticker_cooldown_sec": 3600,
    "notify_market_hot_1m_pct": 0.80,
    "notify_market_hot_3m_pct": 1.50,
    "notify_market_hot_immediate_1m_pct": 1.50,
    "notify_market_hot_immediate_3m_pct": 2.50,
    "notify_market_hot_rank_top_n": 5,
    "notify_market_hot_max_items": 4,
    "notify_market_hot_cache_ttl_sec": 90,
    "notify_entry_timing_trace": True,
}

TOKEN = os.getenv("PAPER_BOT_TOKEN", os.getenv("TELEGRAM_TOKEN", "")).strip()
ALLOWED_CHAT_ID = (
    os.getenv("PAPER_BOT_ALLOWED_CHAT_ID", "").strip()
    or os.getenv("PAPER_BOT_CHAT_ID", "").strip()
    or os.getenv("CHAT_ID", "").strip()
    or os.getenv("GUARD_CHAT_ID", "").strip()
)
NOTIFY_CHAT_ID = os.getenv("PAPER_BOT_NOTIFY_CHAT_ID", "").strip() or ALLOWED_CHAT_ID

_STOP = False
_STOP_REASON = "running"
_STARTED_TS = time.time()
_LAST_PRICE_CACHE: Dict[str, Any] = {"ts": 0.0, "prices": {}}
_LAST_STATUS: Dict[str, Any] = {}
_LAST_CLOSED_COUNT_CACHE: Dict[str, Any] = {"ts": 0.0, "count": 0}
_TG_OFFSET = 0
_LAST_S1_DECISION_NOTIFY: Dict[str, Any] = {"ts": 0.0, "key": ""}
_S1_DECISION_SUMMARY_BUCKET: Dict[str, Any] = {}
_HOT_MARKET_NOTIFY_BUCKET: Dict[str, Any] = {}


def now_ts() -> float:
    return time.time()


KST_OFFSET_SEC = 9 * 60 * 60

def _kst_datetime(ts: Optional[float] = None):
    import datetime as _dt
    return _dt.datetime.fromtimestamp(ts or now_ts(), tz=_dt.timezone(_dt.timedelta(hours=9)))

def _kst_day_key(ts: Optional[float] = None) -> str:
    return _kst_datetime(ts).strftime("%Y-%m-%d")

def iso_ts(ts: Optional[float] = None) -> str:
    return _kst_datetime(ts).strftime("%Y-%m-%d %H:%M:%S KST")


def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            if isinstance(v, str):
                v = v.replace(",", "").replace("%", "").strip()
            return float(v)
        except Exception:
            continue
    return default


num = fnum  # v607 compatibility for legacy review helpers

def log(msg: str) -> None:
    try:
        with FILES["log"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {msg}\n")
    except Exception:
        pass


def log_error(where: str, exc: BaseException) -> None:
    try:
        with FILES["error"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {where}: {type(exc).__name__}: {exc}\n")
            f.write(traceback.format_exc() + "\n")
    except Exception:
        pass


def atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def save_json(path: Path, obj: Any) -> None:
    try:
        atomic_write_text(path, json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    except Exception as exc:
        log_error(f"save_json:{path.name}", exc)


def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception as exc:
        log_error(f"load_json:{path.name}", exc)
        return default


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    try:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception as exc:
        log_error(f"append_jsonl:{path.name}", exc)


def tail_lines(path: Path, max_lines: int) -> List[str]:
    if not path.exists():
        return []
    dq: deque[str] = deque(maxlen=max_lines)
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.strip():
                    dq.append(line.rstrip("\n"))
    except Exception as exc:
        log_error(f"tail_lines:{path.name}", exc)
    return list(dq)


def read_jsonl_tail(path: Path, max_lines: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for line in tail_lines(path, max_lines):
        try:
            row = json.loads(line)
            if isinstance(row, dict):
                out.append(row)
        except Exception:
            continue
    return out


def line_count_cached(path: Path, ttl: float = 60.0) -> int:
    ts = now_ts()
    if ts - float(_LAST_CLOSED_COUNT_CACHE.get("ts") or 0.0) < ttl:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)
    try:
        if not path.exists():
            cnt = 0
        else:
            with path.open("rb") as f:
                cnt = sum(1 for _ in f)
        _LAST_CLOSED_COUNT_CACHE.update({"ts": ts, "count": cnt})
        return cnt
    except Exception:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)


def normalize_ticker(v: Any) -> str:
    if v is None:
        return ""
    t = str(v).strip().upper().replace("/", "-").replace("_", "-")
    if not t:
        return ""
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        return (non[-1] if non else parts[-1]).strip().upper()
    if t.endswith("KRW") and len(t) > 3:
        return t[:-3].strip().upper()
    return t


def row_ts(row: Dict[str, Any], *keys: str) -> float:
    for k in keys:
        v = row.get(k)
        x = fnum(v, default=0.0)
        if x > 1000000000:
            return x
        if isinstance(v, str) and v:
            try:
                import datetime as _dt
                return _dt.datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
            except Exception:
                pass
    return 0.0


def event_time(row: Dict[str, Any]) -> float:
    return row_ts(row, "expires_at", "candidate_expires_at", "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def event_created_ts(row: Dict[str, Any]) -> float:
    return row_ts(row, "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def load_control() -> Dict[str, Any]:
    saved = load_json(FILES["control"], {})
    ctrl = dict(DEFAULT_CONTROL)
    if isinstance(saved, dict):
        ctrl.update(saved)
    # v400: paper 실행기는 기본 ON. 사용자가 명시적으로 running=false로 저장한 경우만 정지한다.
    if "running" not in ctrl:
        ctrl["running"] = True
    return ctrl


def write_pid() -> None:
    try:
        FILES["pid"].write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass


def _v740_open_pos_key(row: Dict[str, Any], idx: int) -> str:
    for k in ("pos_id", "position_id", "event_id", "id", "hold_key"):
        v = str(row.get(k) or "").strip()
        if v:
            return v
    t = normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol"))
    ts = str(row.get("opened_ts") or row.get("entry_ts") or row.get("created_at") or row.get("ts") or idx)
    return f"{t or 'malformed'}:{ts}:{idx}"


def _v740_normalize_open_obj(obj: Any) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, dict):
        list_rows = None
        for k in ("rows", "positions", "open", "OPEN"):
            if isinstance(obj.get(k), list):
                list_rows = obj.get(k)
                break
        if isinstance(list_rows, list):
            for i, row in enumerate(list_rows):
                if isinstance(row, dict):
                    out[_v740_open_pos_key(row, i)] = dict(row)
            return out
        for k, row in obj.items():
            if isinstance(row, dict):
                rr = dict(row)
                rr.setdefault("pos_id", str(k))
                out[str(k)] = rr
        return out
    if isinstance(obj, list):
        for i, row in enumerate(obj):
            if isinstance(row, dict):
                out[_v740_open_pos_key(row, i)] = dict(row)
    return out


def load_open() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES["open"], {})
    return _v740_normalize_open_obj(obj)


def save_open(open_pos: Dict[str, Dict[str, Any]]) -> None:
    # v740: active OPEN is always a normalized dict. Legacy rows-list shape is not written back.
    save_json(FILES["open"], open_pos if isinstance(open_pos, dict) else {})



def open_tickers(open_pos: Dict[str, Dict[str, Any]]) -> set[str]:
    return {normalize_ticker(p.get("ticker")) for p in open_pos.values() if isinstance(p, dict) and normalize_ticker(p.get("ticker"))}


def _v734_is_malformed_open(pos: Dict[str, Any]) -> bool:
    if not isinstance(pos, dict):
        return True
    t = normalize_ticker(pos.get("ticker") or pos.get("market") or pos.get("symbol"))
    price = fnum(pos.get("entry_price"), pos.get("entry"), default=0.0)
    return (not t) or price <= 0


def _v734_is_legacy_experiment_open(pos: Dict[str, Any]) -> bool:
    if not isinstance(pos, dict):
        return False
    if str(pos.get("paper_experiment_lane") or "") == FAST_EXPERIMENT_LANE_V669:
        return True
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    hay = " ".join(str(pos.get(k) or "") for k in ("strategy_key", "strategy_label", "strategy", "lane", "entry_reason", "paper_entry_action"))
    if isinstance(diag, dict):
        hay += " " + " ".join(str(diag.get(k) or "") for k in ("strategy_key", "strategy_label", "strategy", "lane"))
    return ("fast_quality_paper" in hay) or ("고품질 빠른진입 paper 실험" in hay)


def _v734_strict_open_count(open_pos: Dict[str, Dict[str, Any]]) -> int:
    """S1 hold 신규 OPEN 상한에는 정상 strict OPEN만 계산한다.

    구 실험 잔여와 malformed row는 장부에는 보존하지만, 새 정식 S1 진입을 막는 strict OPEN으로 보지 않는다.
    """
    n = 0
    for pos in (open_pos or {}).values():
        if not isinstance(pos, dict):
            continue
        if _v734_is_malformed_open(pos) or _v734_is_legacy_experiment_open(pos):
            continue
        n += 1
    return n


def _v734_hold_status(ev: Dict[str, Any]) -> str:
    return str(ev.get("s1_hold_status_v738") or ev.get("s1_hold_status_v737") or ev.get("s1_hold_status_v736") or ev.get("s1_hold_status_v735") or ev.get("s1_hold_status_v734") or ev.get("s1_hold_status_v732") or "")


def _v734_is_hold(ev: Dict[str, Any]) -> bool:
    return bool(ev.get("s1_hold_v738") or ev.get("s1_hold_v737") or ev.get("s1_hold_v736") or ev.get("s1_hold_v735") or ev.get("s1_hold_v734") or ev.get("s1_hold_v732"))


def _v734_trace_hold(ev: Dict[str, Any], status: str, reason: Any = None, extra: Optional[Dict[str, Any]] = None) -> None:
    try:
        obj = {
            "ts": now_ts(),
            "ticker": normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")),
            "status": status,
            "reason": reason if reason not in (None, "", []) else "-",
            "event_id": event_id(ev, "strict"),
            "hold_status": _v734_hold_status(ev),
            "open_ready": bool(ev.get("s1_hold_open_ready_v738") or ev.get("s1_hold_open_ready_v737") or ev.get("s1_hold_open_ready_v736") or ev.get("s1_hold_open_ready_v735") or ev.get("s1_hold_open_ready_v734") or ev.get("s1_hold_open_ready_v732")),
            "paper_version": VERSION,
        }
        if isinstance(extra, dict):
            obj.update(extra)
        append_jsonl(FILES.get("s1_hold_trace", BASE_DIR / "paper_s1_hold_consume_trace.jsonl"), obj)
    except Exception as exc:
        log_error("v734_trace_hold", exc)


def closed_recent_ids(limit: int = 2000) -> set[str]:
    ids: set[str] = set()
    for r in read_jsonl_tail(FILES["closed"], limit):
        for k in ("pos_id", "event_id", "trace_id", "handoff_id", "candidate_uid"):
            v = str(r.get(k) or "").strip()
            if v:
                ids.add(v)
    return ids


def event_id(ev: Dict[str, Any], lane: str = "strict") -> str:
    for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "id"):
        v = str(ev.get(k) or "").strip()
        if v:
            return v
    t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    scan = str(ev.get("scan_id") or ev.get("source_scan_id") or ev.get("strategy_scan_id") or "")[:40]
    created = int(event_created_ts(ev) or now_ts())
    score = fnum(ev.get("score"), ev.get("leader_score"), default=0.0)
    return f"{lane}:{t}:{scan}:{created}:{score:.3f}"




def candidate_brief(ev: Dict[str, Any], status: str = "", reason: str = "") -> Dict[str, Any]:
    """paper handoff 상태판용 짧은 후보 요약.

    OPEN 여부를 바꾸지 않고, S1이 paper까지 왔는지/왜 막혔는지만 남긴다.
    """
    try:
        ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
        diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    except Exception:
        diag = {}
    return {
        "ticker": normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")),
        "event_id": event_id(ev, "strict"),
        "stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade"),
        "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "status": status or "seen",
        "reason": reason or "-",
        "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
        "seen_at": now_ts(),
        "seen_at_text": iso_ts(),
        "price_reaction_pct": fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0,
        "spread_pct": fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_ratio": fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_sustain_1m": fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "block_reasons": list(ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons") or [])[:8] if isinstance((ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons")), list) else [],
    }


def _record_decision(stats: Dict[str, Any], key: str, ev: Dict[str, Any], status: str, reason: str = "") -> None:
    brief = candidate_brief(ev, status=status, reason=reason)
    stats[key] = brief
    rows = stats.get("recent_s1_decisions")
    if not isinstance(rows, list):
        rows = []
    rows.append(brief)
    stats["recent_s1_decisions"] = rows[-12:]

def get_event_price(ev: Dict[str, Any]) -> float:
    for k in ("live_price", "current_price", "price", "trade_price", "close", "last_price", "entry_price", "detected_price"):
        x = fnum(ev.get(k), default=0.0)
        if x > 0:
            return x
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for k in ("live_price", "current_price", "price", "close"):
        x = fnum(ctx.get(k), default=0.0)
        if x > 0:
            return x
    return 0.0


def fetch_all_prices_cached(ttl: float = 4.0) -> Dict[str, float]:
    ts = now_ts()
    if ts - float(_LAST_PRICE_CACHE.get("ts") or 0.0) < ttl:
        return dict(_LAST_PRICE_CACHE.get("prices") or {})
    prices: Dict[str, float] = {}
    try:
        req = urllib.request.Request(
            "https://api.bithumb.com/public/ticker/ALL_KRW",
            headers={"Accept": "application/json", "User-Agent": VERSION},
        )
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        raw = data.get("data") if isinstance(data, dict) else {}
        if isinstance(raw, dict):
            for k, v in raw.items():
                if not isinstance(v, dict):
                    continue
                t = normalize_ticker(k)
                p = fnum(v.get("closing_price"), v.get("close"), default=0.0)
                if t and p > 0:
                    prices[t] = p
    except Exception as exc:
        log_error("fetch_all_prices", exc)
    if prices:
        _LAST_PRICE_CACHE.update({"ts": ts, "prices": prices})
    return prices


def live_price(ticker: str, fallback: float = 0.0) -> float:
    t = normalize_ticker(ticker)
    prices = fetch_all_prices_cached()
    return float(prices.get(t) or fallback or 0.0)


def candidate_is_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    nowv = now_ts()
    exp = row_ts(ev, "expires_at", "candidate_expires_at")
    if exp > 0:
        return exp >= nowv
    created = event_created_ts(ev)
    if created > 0:
        return (nowv - created) <= fnum(ctrl.get("candidate_ttl_sec"), default=120.0)
    # latest 파일 자체가 방금 갱신된 경우에만 timestamp 없는 후보를 관찰 대상으로 둔다. OPEN은 하지 않는다.
    return False


def micro_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    vals = [ev, ctx]
    for obj in vals:
        if bool(obj.get("micro_fresh")):
            return True
        if str(obj.get("micro_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        age = fnum(obj.get("micro_age_sec"), default=999999.0)
        if age <= fnum(ctrl.get("preopen_micro_urgent_ttl_sec"), default=35.0):
            return True
    return False


def ws_fresh(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for obj in (ev, ctx):
        if bool(obj.get("ws_fresh")):
            return True
        if str(obj.get("ws_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        if fnum(obj.get("ws_age_sec"), default=999999.0) <= 30:
            return True
    return False


def _pressure_is_bad(v: Any) -> bool:
    if v in (None, ""):
        return False
    if isinstance(v, bool):
        return bool(v)
    try:
        # 숫자형 압력값은 보수적으로 0.60 이상이면 부담으로 본다.
        return float(v) >= 0.60
    except Exception:
        s = str(v).strip().lower()
        if s in {"false", "0", "none", "no", "ok", "good", "low", "정상", "없음"}:
            return False
        return any(x in s for x in ("bad", "high", "pressure", "wall", "부담", "압력", "매도"))


def _version_from_text(txt: Any) -> str:
    s = str(txt or "").strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_\.]13[_\.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    return ""


_ACTIVE_MAIN_VERSION_CACHE: Dict[str, Any] = {"ts": 0.0, "version": "", "source": ""}


def _deployed_main_version_detail() -> Tuple[str, str]:
    """실제 적용된 메인봇 버전과 출처.

    v460 단일 본선:
    - DEPLOY_TARGET.txt는 구값(v2.13.320)이 남는 경우가 있어 마지막 fallback으로만 쓴다.
    - paper 성과판은 현재 실행 중인 메인봇 상태파일/실제 배포파일을 우선한다.
    - CLOSED 장부 원본은 수정하지 않고, score cache 집계 시점에만 보정한다.
    """
    candidates: List[Tuple[str, str]] = []

    # 1) 메인봇 heartbeat/status. 실제 실행 중인 BOT_VERSION이 가장 안전하다.
    for name in ("clean_brain_status.json", "clean_resource_status.json"):
        try:
            obj = json.loads((BASE_DIR / name).read_text(encoding="utf-8", errors="ignore"))
            if isinstance(obj, dict):
                for key in ("version", "bot_version", "main_version", "BOT_VERSION"):
                    v = _version_from_text(obj.get(key))
                    if v:
                        candidates.append((v, f"{name}:{key}"))
        except Exception:
            pass

    # 2) guard가 실제 배포 완료 후 남기는 단일 진실값 후보들.
    for name in (".deployed_target", ".deployed_main_target", ".active_main_target", "deployed_target.txt"):
        try:
            txt = (BASE_DIR / name).read_text(encoding="utf-8", errors="ignore").strip()
            v = _version_from_text(txt)
            if v:
                candidates.append((v, name))
        except Exception:
            pass

    # 3) 현재 bundle main 항목. paper-only bundle이면 main이 없을 수 있으므로 보조로만 사용.
    try:
        obj = json.loads((BASE_DIR / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8", errors="ignore"))
        if isinstance(obj, dict):
            for key in ("main", "target", "deploy_target", "main_file"):
                v = _version_from_text(obj.get(key))
                if v:
                    candidates.append((v, f"DEPLOY_BUNDLE.json:{key}"))
    except Exception:
        pass

    # 4) bot.py/메인 파일 내부 BOT_VERSION. 짧은 앞부분만 읽어서 무거운 경로를 피한다.
    for name in ("bot.py",):
        try:
            path = BASE_DIR / name
            if path.exists():
                txt = path.read_text(encoding="utf-8", errors="ignore")[:20000]
                v = _version_from_text(txt)
                if v:
                    candidates.append((v, f"{name}:BOT_VERSION"))
        except Exception:
            pass

    # 5) 서버에 놓인 최신 coinbot_main 파일명.
    try:
        best = 0
        for f in BASE_DIR.glob("coinbot_main_v2_13_*.py"):
            m = re.search(r"coinbot_main_v2_13_(\d+)\.py$", f.name)
            if m:
                best = max(best, int(m.group(1)))
        if best:
            candidates.append((f"v2.13.{best}", "latest_coinbot_main_file"))
    except Exception:
        pass

    # 6) 마지막 fallback: 구 DEPLOY_TARGET. 단독으로만 쓴다.
    legacy = _legacy_deploy_target_version()
    if candidates:
        # paper-only bundle/구파일 혼재 시 가장 높은 v2.13.xxx를 실제 적용 후보로 본다.
        def _n(item: Tuple[str, str]) -> int:
            m = re.search(r"v2\.13\.(\d+)", item[0])
            return int(m.group(1)) if m else 0
        best = max(candidates, key=_n)
        return best
    if legacy:
        return legacy, "DEPLOY_TARGET.txt:fallback"
    return "", ""


def _deployed_main_version() -> str:
    v, _src = _deployed_main_version_detail()
    return v


def _legacy_deploy_target_version() -> str:
    try:
        txt = (BASE_DIR / "DEPLOY_TARGET.txt").read_text(encoding="utf-8", errors="ignore").strip()
        return _version_from_text(txt)
    except Exception:
        return ""


def active_main_version_detail(ttl: float = 3.0) -> Tuple[str, str]:
    ts = now_ts()
    if ts - float(_ACTIVE_MAIN_VERSION_CACHE.get("ts") or 0.0) < ttl:
        return str(_ACTIVE_MAIN_VERSION_CACHE.get("version") or ""), str(_ACTIVE_MAIN_VERSION_CACHE.get("source") or "")
    v, src = _deployed_main_version_detail()
    _ACTIVE_MAIN_VERSION_CACHE.update({"ts": ts, "version": v, "source": src})
    return v, src


def active_main_version() -> str:
    """성과판용 현재 메인봇 파일 버전.

    실제 실행/배포값을 우선하고, 오래된 DEPLOY_TARGET.txt는 마지막 fallback으로만 사용한다.
    """
    v, _src = active_main_version_detail()
    return v


_ACTIVE_PATCH_VERSION_CACHE: Dict[str, Any] = {"ts": 0.0, "version": "", "source": ""}

def _patch_version_from_text(txt: Any) -> str:
    s = str(txt or "").strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])v(\d{3,4})(?:[^0-9]|$)", s)
    if m:
        n = int(m.group(1))
        if 300 <= n <= 9999:
            return f"v{n}"
    return ""

def active_patch_version_detail(ttl: float = 3.0) -> Tuple[str, str]:
    ts = now_ts()
    if ts - float(_ACTIVE_PATCH_VERSION_CACHE.get("ts") or 0.0) < ttl:
        return str(_ACTIVE_PATCH_VERSION_CACHE.get("version") or ""), str(_ACTIVE_PATCH_VERSION_CACHE.get("source") or "")
    candidates: List[Tuple[str, str]] = []
    # 1) 현재 배포 묶음의 version이 사용자가 보는 수정판 기준이다.
    try:
        obj = json.loads((BASE_DIR / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8", errors="ignore"))
        if isinstance(obj, dict):
            for key in ("version", "patch_version", "bundle_version"):
                v = _patch_version_from_text(obj.get(key))
                if v:
                    candidates.append((v, f"DEPLOY_BUNDLE.json:{key}"))
    except Exception:
        pass
    # 2) 메인 status/build label 보조.
    for name in ("clean_brain_status.json", "clean_resource_status.json"):
        try:
            obj = json.loads((BASE_DIR / name).read_text(encoding="utf-8", errors="ignore"))
            if isinstance(obj, dict):
                for key in ("build", "restore_build", "patch_version", "deploy_version", "version"):
                    v = _patch_version_from_text(obj.get(key))
                    if v:
                        candidates.append((v, f"{name}:{key}"))
        except Exception:
            pass
    best = candidates[0] if candidates else ("", "")
    _ACTIVE_PATCH_VERSION_CACHE.update({"ts": ts, "version": best[0], "source": best[1]})
    return best

def active_patch_version() -> str:
    v, _src = active_patch_version_detail()
    return v or _patch_version_from_text(BUILD_LABEL) or 'v607'



def _paper_v488_reason_kind(text: Any) -> Tuple[str, str, str]:
    raw = str(text or '').strip()
    compact = raw.replace(' ', '').replace('_', '').replace('-', '').lower()
    if not raw:
        return ('ignore', '', '')
    if '전략조건 재확인 보류' in raw:
        return ('entry_decision', 'entry_decision', raw)
    if any(k in raw for k in ('스프레드 과다', '스프레드과다', '스프레드 부담', '스프레드부담', '진입 직전 스프레드')):
        return ('exec', 'spread', raw)
    if any(k in raw for k in ('미끄러짐', '슬리피지')):
        return ('exec', 'slippage', raw)
    if any(k in raw for k in ('매도압력', '매도벽')):
        return ('exec', 'sell_pressure', '진입 직전 매도벽/매도압력 부담')
    if '무반응' in raw:
        return ('exec', 'no_reaction', raw)
    if '호가·체결' in raw or 'micro' in compact:
        return ('fresh', 'micro_fresh', raw)
    if '실시간 시세' in raw or 'ws' in compact:
        return ('fresh', 'ws_fresh', raw)
    if '매수체결' in raw:
        return ('legacy', 'buy_ratio', raw)
    if '1분' in raw:
        return ('legacy', 'buy_sustain_1m', raw)
    if '가격반응' in raw:
        return ('legacy', 'price_reaction', raw)
    return ('other', raw, raw)


def _paper_v488_dedupe_reasons(reasons: Any, limit: int = 10) -> List[str]:
    arr = reasons if isinstance(reasons, list) else ([] if reasons is None else [reasons])
    order = {'entry_decision': 0, 'fresh': 1, 'exec': 2, 'legacy': 3, 'other': 4}
    buf: List[Tuple[int, str, str]] = []
    seen = set()
    for x in arr:
        b, k, disp = _paper_v488_reason_kind(x)
        if not k or b == 'ignore' or k in seen:
            continue
        seen.add(k)
        buf.append((order.get(b, 9), k, str(disp or x).strip()))
    return [txt for _o, _k, txt in sorted(buf, key=lambda z: z[0])[:limit]]


def _paper_v484_canonical_entry_decision(ev: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    # v533: paper OPEN gate reads only the strategy canonical decision.
    dec = ev.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or ev.get("common_entry_decision") or ctx.get("common_entry_decision")
    return dec if isinstance(dec, dict) else {}

def _paper_v537_profile_from_diag(diag: Dict[str, Any]) -> str:
    dec = diag.get("canonical_entry_decision") if isinstance(diag.get("canonical_entry_decision"), dict) else {}
    p = str(diag.get("entry_profile") or dec.get("entry_profile") or "").strip()
    if p in {"spike_fast_early", "spike_runner"}:
        return "spike"
    if p in {"spike_fast_watch", "normal_watch"}:
        return "watch"
    return p or "normal_common"


def _paper_v484_exec_safety_reasons(diag: Dict[str, Any], ctrl: Dict[str, Any]) -> List[str]:
    """v537 profile-aware last-mile safety.
    Strategy canonical_entry_decision is the entry source. Paper only checks last-mile execution,
    and uses the same profile family so spike is not re-blocked by normal spread/slippage defaults.
    """
    reasons: List[str] = []
    profile = _paper_v537_profile_from_diag(diag)
    if profile == "spike":
        max_spread = fnum(ctrl.get("paper_final_spike_max_spread_pct"), default=0.85)
        max_slip = fnum(ctrl.get("paper_final_spike_max_slippage_pct"), default=0.85)
        reaction_proof_enabled = bool(ctrl.get("paper_final_spike_reaction_proof_enabled", False))
    else:
        max_spread = fnum(ctrl.get("paper_final_max_spread_pct"), default=0.18)
        max_slip = fnum(ctrl.get("paper_final_max_slippage_pct"), default=0.20)
        reaction_proof_enabled = bool(ctrl.get("paper_final_reaction_proof_enabled", True))
    spread = fnum(diag.get("spread_pct"), default=-1.0)
    slip_raw = fnum(diag.get("slippage_pct"), default=-1.0)
    slip = slip_raw if slip_raw >= 0 else spread
    diag["paper_final_profile"] = profile
    diag["paper_final_max_spread_pct_used"] = max_spread
    diag["paper_final_max_slippage_pct_used"] = max_slip
    if spread >= 0 and spread > max_spread:
        reasons.append(f"진입 직전 스프레드 부담({spread:.2f}% > {max_spread:.2f}%)")
    if slip >= 0 and slip > max_slip:
        reasons.append(f"진입 직전 미끄러짐 부담({slip:.2f}% > {max_slip:.2f}%)")
    if reaction_proof_enabled:
        no_reaction_reason = _paper_v144_reaction_proof_block(diag, ctrl)
        if no_reaction_reason:
            reasons.append(no_reaction_reason)
    if _pressure_is_bad(diag.get("sell_pressure")):
        reasons.append("진입 직전 매도벽/매도압력 부담")
    return reasons[:10]



def _paper_v602_final_trade_state(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """strategy_worker가 봉인한 최종 매수판정만 읽는다. paper는 새 판단을 하지 않는다."""
    ctx = ctx if isinstance(ctx, dict) else {}
    sources: List[Tuple[str, Dict[str, Any]]] = []
    if isinstance(ev, dict):
        sources.append(("event", ev))
        cm = ev.get("canonical_metric_row")
        if isinstance(cm, dict):
            sources.append(("event.canonical_metric_row", cm))
    if isinstance(ctx, dict):
        sources.append(("entry_context", ctx))
        cm = ctx.get("canonical_metric_row")
        if isinstance(cm, dict):
            sources.append(("entry_context.canonical_metric_row", cm))
    for src, obj in sources:
        state = str(obj.get("final_trade_state") or "").strip()
        if state:
            return {
                "state": state,
                "allowed": state == "S1_PASS" or bool(obj.get("final_trade_allowed") is True and state == "S1_PASS"),
                "label": obj.get("final_trade_label") or obj.get("final_decision") or state,
                "reasons": obj.get("final_trade_reasons") if isinstance(obj.get("final_trade_reasons"), list) else [],
                "source": src,
                "schema": obj.get("final_decision_schema") or obj.get("schema") or "final_trade_state_v602",
            }
    return {"state": "", "allowed": False, "label": "전략 최종판정 없음", "reasons": [], "source": "missing", "schema": "missing_final_trade_state_v602"}

def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    """v602: paper는 strategy final_trade_state만 최종 OPEN 기준으로 읽는다.
    canonical_entry_decision은 보조 진단으로만 확인하고, 새 매수 판단은 paper에 추가하지 않는다.
    """
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    final = _paper_v602_final_trade_state(ev, ctx)
    diag["final_trade_state"] = final.get("state")
    diag["final_trade_label"] = final.get("label")
    diag["final_trade_reasons"] = final.get("reasons") or []
    diag["final_trade_state_source"] = final.get("source")
    dec = _paper_v484_canonical_entry_decision(ev, ctx)
    is_s1_hold_v738 = _v734_is_hold(ev)
    reasons: List[str] = []
    if final.get("state") != "S1_PASS":
        why = final.get("reasons") if isinstance(final.get("reasons"), list) else []
        reasons.append("전략 최종판정 보류: " + str(final.get("label") or final.get("state") or "없음") + ((" / " + " / ".join(str(x) for x in why[:3])) if why else ""))

    trigger_gate = _v620_trigger_gate_from_sources(ev, diag)
    diag["trigger_gate"] = trigger_gate
    diag["trigger_reached"] = bool(trigger_gate.get("trigger_reached"))
    diag["trigger_gap_pct"] = trigger_gate.get("trigger_gap_pct")
    if trigger_gate.get("trigger_price") and trigger_gate.get("entry_price") and not bool(trigger_gate.get("trigger_reached")):
        reasons.append(str(trigger_gate.get("reason") or "방아쇠 미도달"))

    preopen_plan_reasons_v739 = _v739_preopen_plan_safety_reasons(ev, diag, ctrl)
    if preopen_plan_reasons_v739:
        diag["preopen_plan_safety_reasons_v739"] = preopen_plan_reasons_v739
        reasons.extend(preopen_plan_reasons_v739)

    if not isinstance(dec, dict) or not dec:
        diag["entry_decision_schema"] = "missing_canonical_entry_decision_v533"
        if is_s1_hold_v738 and final.get("state") == "S1_PASS":
            diag["s1_hold_canonical_gate_bypass_v738"] = True
            diag["s1_hold_canonical_mismatch_v738"] = "missing_decision_bypassed"
        else:
            reasons.append("전략판단 원천 없음: canonical_entry_decision 누락")
    else:
        diag["canonical_entry_decision"] = dec
        diag["entry_decision_schema"] = dec.get("schema")
        diag["entry_profile"] = ev.get("entry_profile") or ctx.get("entry_profile") or dec.get("entry_profile")
        diag["exit_profile"] = ev.get("exit_profile") or ctx.get("exit_profile") or dec.get("exit_profile")
        diag["profile_family"] = ev.get("profile_family") or ctx.get("profile_family") or dec.get("profile_family")
        if not bool(dec.get("gate_pass") or dec.get("s1_allowed")):
            rs = dec.get("display_reasons") if isinstance(dec.get("display_reasons"), list) else []
            if is_s1_hold_v738 and final.get("state") == "S1_PASS":
                diag["s1_hold_canonical_gate_bypass_v738"] = True
                diag["s1_hold_canonical_mismatch_v738"] = "canonical_false_bypassed"
                diag["s1_hold_canonical_false_reasons_v738"] = rs[:6]
            else:
                reasons.append("전략조건 재확인 보류: " + " / ".join(str(x) for x in rs[:4]))
        # last-mile execution safety only; do not duplicate strategy buy/sustain/reaction gates.
        reasons.extend(_paper_v484_exec_safety_reasons(diag, ctrl))

    if not micro_fresh(ev, ctrl):
        reasons.append("호가·체결 신선정보 없음")
    if bool(ctrl.get("paper_final_require_ws_fresh", False)) and not ws_fresh(ev):
        reasons.append("실시간 시세 신선정보 없음")

    try:
        age_ok, stale, ages = _v508_age_reasons(ev)
        diag["paper_preopen_age_values_v533"] = ages
        diag["paper_preopen_stale_reasons_v533"] = stale
        if not age_ok:
            reasons.append("preopen 신선도 실패: " + " / ".join(stale[:5]))
    except Exception as exc:
        diag["paper_preopen_age_error"] = exc.__class__.__name__

    for k in ("s1_missing_conditions", "s1_passed_conditions", "s1_distance", "s1_near_miss", "s1_short_reason", "canonical_lane", "matched_strategy_labels", "common_entry_pass", "common_entry_schema", "strategy_role", "entry_profile", "exit_profile", "profile_family", "profile_decisions"):
        val = ev.get(k) if ev.get(k) not in (None, "", [], {}) else ctx.get(k)
        if val not in (None, "", [], {}):
            diag[k] = val

    reasons = _paper_v488_dedupe_reasons(reasons, 10)
    diag["paper_final_safety_reasons"] = reasons
    diag["paper_final_safety_schema"] = "paper_final_safety_v739_preopen_late_chase_guard"
    return (len(reasons) == 0), reasons, diag



# =============================================================================
# paper_bot v0.233 / v669: paper-only fast quality experiment lane
# - strategy_worker가 paper_experiment_open=True로 봉인한 고품질 후보만 별도 paper 실험 OPEN한다.
# - 실제 자동매수/BUY_READY/real_eligible은 항상 false로 유지한다.
# - 기존 S1 OPEN 경로는 그대로 유지하고, 실험 성과는 strategy_key=fast_quality_paper_v669로 분리된다.
# =============================================================================
FAST_EXPERIMENT_LANE_V669 = "fast_quality_paper_v669"
FAST_EXPERIMENT_MAX_NEW_PER_CYCLE = 2
FAST_EXPERIMENT_MAX_OPEN = 5


def is_paper_experiment_candidate_v669(ev: Dict[str, Any]) -> bool:
    if not isinstance(ev, dict):
        return False
    if ev.get('paper_experiment_open') is not True:
        return False
    if str(ev.get('paper_experiment_lane') or '') != FAST_EXPERIMENT_LANE_V669:
        return False
    if ev.get('real_eligible') is True or ev.get('auto_buy_ready') is True or ev.get('buy_ready') is True:
        return False
    diag = ev.get('fast_quality_paper_v669') if isinstance(ev.get('fast_quality_paper_v669'), dict) else {}
    q = fnum(diag.get('q'), ev.get('coin_quality_score'), default=0.0)
    risk = fnum(diag.get('risk'), ev.get('execution_risk_score'), default=99.0)
    gap = fnum(diag.get('gap'), ev.get('trigger_gap_pct'), default=-999.0)
    if q < 70 or risk > 25 or gap < -0.35 or gap > 0.08:
        return False
    return True


def paper_experiment_safety_v669(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    fast = ev.get('fast_quality_paper_v669') if isinstance(ev.get('fast_quality_paper_v669'), dict) else {}
    reasons: List[str] = []
    diag['paper_experiment_lane'] = FAST_EXPERIMENT_LANE_V669
    diag['paper_experiment_fast_quality'] = fast
    diag['final_trade_state'] = 'PAPER_EXPERIMENT_FAST_QUALITY'
    diag['final_trade_label'] = '고품질 빠른진입 paper 실험'
    # last-mile safety remains. Trigger reached is intentionally not required for this paper experiment.
    if not micro_fresh(ev, ctrl):
        reasons.append('호가·체결 신선정보 없음')
    if bool(ctrl.get('paper_final_require_ws_fresh', False)) and not ws_fresh(ev):
        reasons.append('실시간 시세 신선정보 없음')
    spread = fnum(fast.get('spread_pct'), diag.get('spread_pct'), default=0.0)
    slip = fnum(fast.get('slippage_pct'), diag.get('slippage_pct'), default=0.0)
    if spread > 0.75:
        reasons.append(f'실험 스프레드 부담 {spread:.2f}%')
    if slip > 0.75:
        reasons.append(f'실험 미끄러짐 부담 {slip:.2f}%')
    if fnum(fast.get('risk'), ev.get('execution_risk_score'), default=99.0) > 25:
        reasons.append('실험 위험점수 초과')
    diag['paper_final_safety_reasons'] = reasons
    diag['paper_final_safety_schema'] = 'paper_experiment_fast_quality_v669'
    return (len(reasons) == 0), reasons, diag

def is_s1_candidate(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    final = _paper_v602_final_trade_state(ev, ctx)
    if final.get("state") != "S1_PASS":
        return False
    if ev.get("fresh_gate_ok") is False:
        return False
    if ev.get("paper_bot_open") is False or ev.get("open_eligible") is False or ev.get("trade_ready") is False:
        return False
    stage = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade") or "").upper()
    return stage == "S1"


def candidate_sources(ctrl: Dict[str, Any]) -> List[Tuple[str, Path, List[Dict[str, Any]]]]:
    """v734 runtime OPEN source: strategy_worker S1 hold cache only.

    paper_latest는 상태/추적 참고 파일이고, 신규 OPEN 소비는 paper_s1_hold_cache.json만 사용한다.
    이렇게 해야 한 cycle짜리 S1을 놓치지 않으면서 S2/S3 실험 경로가 다시 열리지 않는다.
    """
    obj = load_json(FILES.get("s1_hold", BASE_DIR / "paper_s1_hold_cache.json"), {}) or {}
    rows = obj.get("rows") if isinstance(obj, dict) and isinstance(obj.get("rows"), list) else []
    out: List[Dict[str, Any]] = []
    for r in rows:
        if not isinstance(r, dict):
            continue
        rr = dict(r)
        rr["_source_file"] = "s1_hold"
        out.append(rr)
    return [("s1_hold", FILES.get("s1_hold", BASE_DIR / "paper_s1_hold_cache.json"), out)]


def latest_scan_filter(rows: List[Dict[str, Any]], ctrl: Dict[str, Any]) -> List[Dict[str, Any]]:
    hold_rows = [r for r in (rows or []) if isinstance(r, dict) and _v734_is_hold(r)]
    if hold_rows:
        return hold_rows
    if not rows or not bool(ctrl.get("consume_latest_scan_only", True)):
        return rows
    scan_ids = [str(r.get("scan_id") or r.get("source_scan_id") or "").strip() for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip()]
    if scan_ids:
        latest = scan_ids[-1]
        same = [r for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip() == latest]
        if same:
            return same
    latest_ts = max((event_created_ts(r) for r in rows), default=0.0)
    if latest_ts > 0:
        win = fnum(ctrl.get("latest_scan_window_sec"), default=8.0)
        return [r for r in rows if event_created_ts(r) >= latest_ts - win]
    return rows


def build_trace(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], picked_ids: set[str], opened_ids: set[str]) -> Dict[str, Any]:
    out: List[Dict[str, Any]] = []
    open_ids = set(open_pos.keys())
    open_ticks = open_tickers(open_pos)
    for ev in rows[-160:]:
        if not isinstance(ev, dict):
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        eid = event_id(ev, "strict")
        reason: List[str] = []
        status = "observed"
        if eid in opened_ids:
            status = "open"
        elif eid in picked_ids:
            status = "selected_for_open"
        elif eid in open_ids or t in open_ticks:
            status = "already_open"
        elif not candidate_is_fresh(ev, ctrl):
            status = "expired"
            reason.append("후보오래됨")
        elif _v734_is_hold(ev) and _v734_hold_status(ev) == "stale_hold":
            status = "s1_hold_stale"
            reason.extend([str(x) for x in (ev.get("stale_reasons") or [])[:4]] or ["신선도 재확인 대기"])
        elif _v734_is_hold(ev) and _v734_hold_status(ev) == "trigger_wait":
            status = "s1_hold_trigger_wait"
            tg = ev.get("trigger_gate_v738") if isinstance(ev.get("trigger_gate_v738"), dict) else (ev.get("trigger_gate_v737") if isinstance(ev.get("trigger_gate_v737"), dict) else (ev.get("trigger_gate_v736") if isinstance(ev.get("trigger_gate_v736"), dict) else (ev.get("trigger_gate_v735") if isinstance(ev.get("trigger_gate_v735"), dict) else (ev.get("trigger_gate_v734") if isinstance(ev.get("trigger_gate_v734"), dict) else (ev.get("trigger_gate_v732") if isinstance(ev.get("trigger_gate_v732"), dict) else {})))))
            reason.append(str(tg.get("reason") or "방아쇠 미도달"))
        elif not is_s1_candidate(ev):
            status = "not_s1"
            reason.append("S1아님")
        elif ctrl.get("preopen_micro_recheck", True) and not micro_fresh(ev, ctrl):
            status = "micro_wait"
            reason.append("micro미확인")
        elif ev.get("paper_entry_hold_reasons"):
            status = "paper_entry_hold"
            reason.extend([str(x) for x in (ev.get("paper_entry_hold_reasons") or [])[:4]])
        elif ev.get("paper_final_block_reasons"):
            status = "paper_entry_hold"
            reason.extend([str(x) for x in (ev.get("paper_final_block_reasons") or [])[:4]])
        else:
            status = "merged_waiting_pick"
        out.append({
            "event_id": eid,
            "trace_id": eid,
            "ticker": t,
            "status": status,
            "reason": ",".join(reason) if reason else "-",
            "s_stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade"),
            "score": ev.get("score") or ev.get("leader_score"),
            "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
            "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema")),
            "entry_reasons": _diag_list(ev, ("entry_reasons", "final_entry_reasons", "trade_ready_reasons"), limit=6),
            "entry_structure_tags": _diag_list(ev, ("entry_structure_tags", "structure_tags", "matched_strategy_labels"), limit=8),
            "confirm_signals": _diag_list(ev, ("confirm_signals", "s1_passed_conditions"), limit=8),
            "structure_levels": ev.get("structure_levels") if isinstance(ev.get("structure_levels"), dict) else {},
            "entry_plan": ev.get("entry_plan") if isinstance(ev.get("entry_plan"), dict) else {},
            "risk_reward": ev.get("risk_reward") if isinstance(ev.get("risk_reward"), dict) else {},
            "entry_timing_spine": ev.get("entry_timing_spine") if isinstance(ev.get("entry_timing_spine"), dict) else {},
            "late_chase_flag": bool(ev.get("late_chase_flag")),
            "execution_risk_tags": _diag_list(ev, ("execution_risk_tags", "risk_tags", "structure_risk_tags"), limit=8),
            "recheck_reasons": _diag_list(ev, ("recheck_reasons", "s2_recheck_reasons"), limit=8),
            "missing_info": (list(ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons") or [])[:6] or _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "s1_missing", "unmet_conditions", "block_reasons"), limit=6)),
            "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
            "updated_at": nowv,
        })
    obj = {"version": VERSION, "trace_version": VERSION, "build": BUILD_LABEL, "updated_at": now_ts(), "updated_at_text": iso_ts(), "rows": out}
    save_json(FILES["trace"], obj)
    return obj




def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:
    stats: Dict[str, Any] = Counter()
    all_rows: List[Dict[str, Any]] = []
    latest_count = 0
    for name, _path, rows in candidate_sources(ctrl):
        stats[f"{name}_read"] = int(stats.get(f"{name}_read", 0)) + len(rows)
        if name in ("paper_latest", "s1_hold"):
            latest_count = len(rows)
        for r in rows:
            if isinstance(r, dict):
                rr = dict(r)
                rr.setdefault("_source_file", name)
                all_rows.append(rr)
    filtered = latest_scan_filter(all_rows, ctrl)
    stats["latest_scan_before"] = len(all_rows)
    stats["latest_scan_after"] = len(filtered)
    existing_ids = set(open_pos.keys()) | closed_recent_ids()
    blocked_tickers = open_tickers(open_pos) if ctrl.get("block_same_ticker_open", True) else set()
    picked: List[Tuple[str, Dict[str, Any]]] = []
    max_new = int(fnum(ctrl.get("max_new_per_cycle"), default=0))
    max_open = int(fnum(ctrl.get("max_open_strict"), default=0))
    strict_open_now = _v734_strict_open_count(open_pos)
    stats["open_total_raw"] = len(open_pos or {})
    stats["strict_open_count_v734"] = strict_open_now
    stats["legacy_or_bad_open_ignored_v734"] = max(0, len(open_pos or {}) - strict_open_now)

    for ev in filtered:
        if not isinstance(ev, dict):
            continue
        stats["last_seen_candidate"] = candidate_brief(ev, status="seen")
        is_hold = _v734_is_hold(ev)
        hold_status = _v734_hold_status(ev)
        if is_hold:
            stats["s1_hold_seen"] = int(stats.get("s1_hold_seen", 0)) + 1
            stats[f"s1_hold_{hold_status or 'unknown'}"] = int(stats.get(f"s1_hold_{hold_status or 'unknown'}", 0)) + 1
            _v734_trace_hold(ev, "hold_read", {"hold_status": hold_status, "strict_open_count": strict_open_now, "raw_open_count": len(open_pos or {})})

        is_s1 = is_s1_candidate(ev)
        is_exp = is_paper_experiment_candidate_v669(ev)
        if is_exp:
            stats["fast_quality_paper_seen"] = int(stats.get("fast_quality_paper_seen", 0)) + 1
        if is_s1:
            stats["s1_seen"] = int(stats.get("s1_seen", 0)) + 1
            _record_decision(stats, "last_s1_seen", ev, "s1_seen")

        if is_hold and hold_status == "stale_hold":
            _record_decision(stats, "last_skip", ev, "s1_hold_stale", "S1 hold 신선도 재확인 대기")
            _v734_trace_hold(ev, "stale_hold", ev.get("stale_reasons") or [], {"strict_open_count": strict_open_now})
            continue
        if is_hold and hold_status == "trigger_wait":
            tg = ev.get("trigger_gate_v738") if isinstance(ev.get("trigger_gate_v738"), dict) else (ev.get("trigger_gate_v737") if isinstance(ev.get("trigger_gate_v737"), dict) else (ev.get("trigger_gate_v736") if isinstance(ev.get("trigger_gate_v736"), dict) else (ev.get("trigger_gate_v735") if isinstance(ev.get("trigger_gate_v735"), dict) else (ev.get("trigger_gate_v734") if isinstance(ev.get("trigger_gate_v734"), dict) else (ev.get("trigger_gate_v732") if isinstance(ev.get("trigger_gate_v732"), dict) else {})))))
            _record_decision(stats, "last_skip", ev, "s1_hold_trigger_wait", str(tg.get("reason") or "방아쇠 미도달"))
            _v734_trace_hold(ev, "trigger_wait", str(tg.get("reason") or "방아쇠 미도달"), {"trigger": tg, "strict_open_count": strict_open_now})
            continue

        if max_new > 0 and len(picked) >= max_new:
            stats["limit_skip"] = int(stats.get("limit_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "limit_skip", "cycle 신규 OPEN 상한")
            if is_hold:
                _v734_trace_hold(ev, "limit_skip", "cycle 신규 OPEN 상한", {"max_new": max_new, "picked": len(picked)})
            continue

        if max_open > 0 and strict_open_now + len(picked) >= max_open:
            stats["limit_skip"] = int(stats.get("limit_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "limit_skip", "OPEN 상한")
            if is_hold:
                _v734_trace_hold(ev, "open_limit_skip", "정상 strict OPEN 상한", {"max_open_strict": max_open, "strict_open_count": strict_open_now, "raw_open_count": len(open_pos or {}), "ignored_legacy_bad": max(0, len(open_pos or {}) - strict_open_now)})
            continue

        if ctrl.get("new_open_paused", False):
            stats["new_open_paused"] = int(stats.get("new_open_paused", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "new_open_paused", "신규 OPEN 일시정지")
            if is_hold:
                _v734_trace_hold(ev, "new_open_paused", "신규 OPEN 일시정지")
            continue

        if not candidate_is_fresh(ev, ctrl):
            stats["stale_skip"] = int(stats.get("stale_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "stale_skip", "후보 TTL 만료")
            if is_hold:
                _v734_trace_hold(ev, "candidate_expired", "후보 TTL 만료", {"expires_at": ev.get("expires_at"), "created_at": event_created_ts(ev)})
            continue

        if ctrl.get("open_trade_ready_only", True) and not (is_s1 or is_exp):
            stats["not_s1_skip"] = int(stats.get("not_s1_skip", 0)) + 1
            if is_hold:
                _v734_trace_hold(ev, "not_s1_skip", "S1 판정 아님")
            continue

        if is_exp and not is_s1:
            exp_open_now = sum(1 for _pid, _pos in open_pos.items() if isinstance(_pos, dict) and str(_pos.get("paper_experiment_lane") or "") == FAST_EXPERIMENT_LANE_V669)
            exp_picked_now = sum(1 for _eid, _ev in picked if isinstance(_ev, dict) and str(_ev.get("paper_experiment_lane") or "") == FAST_EXPERIMENT_LANE_V669)
            if exp_open_now + exp_picked_now >= FAST_EXPERIMENT_MAX_OPEN or exp_picked_now >= FAST_EXPERIMENT_MAX_NEW_PER_CYCLE:
                stats["fast_quality_paper_limit_skip"] = int(stats.get("fast_quality_paper_limit_skip", 0)) + 1
                continue

        if ctrl.get("preopen_micro_recheck", True) and ctrl.get("notify_open_require_micro_fresh", True) and not micro_fresh(ev, ctrl):
            stats["micro_preopen_wait"] = int(stats.get("micro_preopen_wait", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "micro_preopen_wait", "OPEN 직전 micro 신선정보 없음")
            if is_hold:
                _v734_trace_hold(ev, "micro_preopen_wait", "OPEN 직전 micro 신선정보 없음")
            continue

        if ctrl.get("notify_open_require_ws_fresh", False) and not ws_fresh(ev):
            stats["ws_preopen_wait"] = int(stats.get("ws_preopen_wait", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "ws_preopen_wait", "OPEN 직전 WS 신선정보 없음")
            if is_hold:
                _v734_trace_hold(ev, "ws_preopen_wait", "OPEN 직전 WS 신선정보 없음")
            continue

        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        price = get_event_price(ev)
        if not t:
            stats["ticker_missing_skip"] = int(stats.get("ticker_missing_skip", 0)) + 1
            stats["bad_skip"] = int(stats.get("bad_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "ticker_missing_skip", "ticker 필수값 없음")
            if is_hold:
                _v734_trace_hold(ev, "ticker_missing_skip", "ticker 필수값 없음")
            continue

        if price <= 0:
            stats["price_missing_skip"] = int(stats.get("price_missing_skip", 0)) + 1
            stats["bad_skip"] = int(stats.get("bad_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "price_missing_skip", "가격 필수값 없음")
            if is_hold:
                _v734_trace_hold(ev, "price_missing_skip", "가격 필수값 없음", {"price": price})
            continue

        eid = event_id(ev, "strict")
        if eid in existing_ids:
            stats["dup_skip"] = int(stats.get("dup_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "dup_skip", "이미 OPEN/CLOSED 처리한 후보")
            if is_hold:
                _v734_trace_hold(ev, "dup_skip", "이미 OPEN/CLOSED 처리한 후보", {"event_id": eid})
            continue

        if ctrl.get("block_same_ticker_open", True) and t in blocked_tickers:
            stats["same_ticker_skip"] = int(stats.get("same_ticker_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "same_ticker_skip", "동일 종목 OPEN 보유중")
            if is_hold:
                _v734_trace_hold(ev, "same_ticker_skip", "동일 종목 OPEN 보유중", {"ticker": t})
            continue

        ok_final, final_reasons, final_diag = (paper_experiment_safety_v669(ev, ctrl) if (is_exp and not is_s1) else paper_final_safety(ev, ctrl))
        if not ok_final:
            ev["paper_entry_hold_reasons"] = final_reasons
            ev["paper_final_block_reasons"] = final_reasons
            ev["paper_final_safety_diagnostics"] = final_diag
            ev["paper_entry_action"] = "recheck_hold"
            stats["paper_entry_hold"] = int(stats.get("paper_entry_hold", 0)) + 1
            stats["paper_final_block"] = int(stats.get("paper_final_block", 0)) + 1
            if is_exp and not is_s1:
                stats["fast_quality_paper_final_hold"] = int(stats.get("fast_quality_paper_final_hold", 0)) + 1
                _record_decision(stats, "last_fast_quality_paper_hold", ev, "fast_quality_paper_final_hold", " / ".join(final_reasons[:5]))
            if is_s1:
                _record_decision(stats, "last_paper_entry_hold", ev, "paper_entry_hold", " / ".join(final_reasons[:5]))
                _record_decision(stats, "last_paper_final_block", ev, "paper_entry_hold", " / ".join(final_reasons[:5]))
            if is_hold:
                _v734_trace_hold(ev, "paper_final_hold", final_reasons[:8], {"diag_schema": final_diag.get("paper_final_safety_schema") if isinstance(final_diag, dict) else "-"})
            continue

        ev = dict(ev)
        if is_exp and not is_s1:
            ev["lane"] = FAST_EXPERIMENT_LANE_V669
            ev["paper_experiment_lane"] = FAST_EXPERIMENT_LANE_V669
            ev["strategy_key"] = FAST_EXPERIMENT_LANE_V669
            ev["strategy_label"] = "고품질 빠른진입 paper 실험"
            ev["candidate_grade"] = ev.get("candidate_grade") or ev.get("s_stage") or "S2"
            ev["final_entry_action"] = "paper_experiment_open"
            ev["final_entry_label"] = "고품질 빠른진입 paper 실험"
            stats["selected_fast_quality_paper"] = int(stats.get("selected_fast_quality_paper", 0)) + 1
        else:
            ev["lane"] = "strict"
        ev["paper_final_safety_passed"] = True
        ev["paper_final_safety_diagnostics"] = final_diag
        _record_decision(stats, "last_open_try", ev, "selected_for_open", "paper 최종안전문 통과")
        if is_hold:
            _v734_trace_hold(ev, "selected_for_open", "paper 최종안전문 통과", {"strict_open_count": strict_open_now, "raw_open_count": len(open_pos or {})})
        picked.append((eid, ev))
        existing_ids.add(eid)
        blocked_tickers.add(t)
        if is_s1:
            stats["selected_s1"] = int(stats.get("selected_s1", 0)) + 1

    stats["latest_count"] = latest_count
    stats["merged_fresh"] = sum(1 for r in filtered if candidate_is_fresh(r, ctrl))
    return picked, dict(stats), filtered


def copy_entry_context(ev: Dict[str, Any]) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {}
    if isinstance(ev.get("entry_context"), dict):
        ctx.update(ev["entry_context"])
    for k, v in ev.items():
        if k.startswith("_"):
            continue
        if k not in ctx and k not in {"raw"}:
            ctx[k] = v
    return ctx


def _diag_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ctx, ev.get("entry_context"), ev.get("entry_snapshot"), ev.get("profile"), ev.get("raw")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for kk in (
                "flat", "strategy", "strategy_context", "metrics", "entry_metrics", "recheck_metrics",
                "orderflow", "orderflow_summary", "feature", "features", "price_flow", "price_context",
                "money_flow", "position", "risk", "micro", "micro_summary", "ws", "quote",
                "market", "market_context", "standard_values", "candidate_values", "score_context", "ticker_state",
            ):
                vv = obj.get(kk)
                if isinstance(vv, dict):
                    srcs.append(vv)
    return srcs


def _diag_first(ev: Dict[str, Any], keys: Iterable[str], default: Any = None, ctx: Optional[Dict[str, Any]] = None) -> Any:
    for src in _diag_sources(ev, ctx):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default


def _diag_list(ev: Dict[str, Any], keys: Iterable[str], ctx: Optional[Dict[str, Any]] = None, limit: int = 8) -> List[str]:
    out: List[str] = []
    for src in _diag_sources(ev, ctx):
        for k in keys:
            v = src.get(k)
            if v in (None, "", [], {}):
                continue
            vals: List[Any]
            if isinstance(v, list):
                vals = v
            elif isinstance(v, dict):
                vals = [f"{kk}:{vv}" for kk, vv in list(v.items())[:limit]]
            else:
                vals = [v]
            for item in vals:
                txt = str(item).strip()
                if txt and txt not in out:
                    out.append(txt)
                    if len(out) >= limit:
                        return out
    return out


def _fmt_bool(v: Any) -> str:
    if isinstance(v, str):
        if v.lower() in {"fresh", "ok", "true", "1", "yes"}:
            return "OK"
        if v.lower() in {"stale", "old", "false", "0", "no"}:
            return "부족"
    if v is True:
        return "OK"
    if v is False:
        return "부족"
    return "-" if v in (None, "") else str(v)


def _fmt_pct_value(v: Any, suffix: str = "%") -> str:
    if v in (None, ""):
        return "-"
    try:
        return f"{fnum(v):.2f}{suffix}"
    except Exception:
        return str(v)



def _paper_v143_num_if_present(obj: Any, key: str) -> Optional[float]:
    if not isinstance(obj, dict) or obj.get(key) in (None, ""):
        return None
    try:
        return float(str(obj.get(key)).replace(",", "").replace("%", "").strip())
    except Exception:
        return None


def _paper_v143_all_present(srcs: List[Dict[str, Any]], keys: List[str], group: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                out.append({"group": group, "source": k, "value": round(float(v), 4)})
    return out


def _paper_v143_first_present(srcs: List[Dict[str, Any]], keys: List[str]) -> Tuple[Optional[float], str]:
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                return v, k
    return None, ""


def _paper_v143_price_delta_candidate(srcs: List[Dict[str, Any]]) -> Dict[str, Any]:
    cur, cur_src = _paper_v143_first_present(srcs, [
        "current_price", "price", "last_price", "close", "trade_price", "quote_price", "ws_price", "micro_price"
    ])
    ref, ref_src = _paper_v143_first_present(srcs, [
        "detected_price", "watch_price", "first_seen_price", "s3_price", "s2_price",
        "candidate_price", "base_price", "entry_signal_price", "signal_price", "recheck_start_price"
    ])
    if cur is not None and ref is not None and cur > 0 and ref > 0:
        return {"group": "price_delta", "source": f"{cur_src}/{ref_src}", "value": round((cur - ref) / ref * 100.0, 4)}
    return {}




def _paper_v144_flow_window_candidates(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Return actually-present short-flow windows for the final no-reaction proof.

    This deliberately does not treat missing values as 0. Missing information is not
    silently converted into a block signal; only explicit 0/negative short-flow rows
    are used to prevent VIRTUAL-style no-reaction entries.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    groups = [
        ("1m", ["flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"]),
        ("3m", ["flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"]),
        ("5m", ["flow_5m_pct", "change_5m", "chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct", "price_change_5m"]),
        ("15m", ["flow_15m_pct", "change_15m", "chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct", "price_change_15m"]),
    ]
    out: List[Dict[str, Any]] = []
    for label, keys in groups:
        val, src = _paper_v143_first_present(srcs, keys)
        if val is not None:
            out.append({"window": label, "value": round(float(val), 4), "source": src})
    return out


def _paper_v144_reaction_proof_block(diag: Dict[str, Any], ctrl: Dict[str, Any]) -> str:
    """Hold confirmed no-reaction S1 entries right before OPEN.

    This is not an S1/S2/S3 threshold change and not a discard rule. If enough
    short-flow windows are present and all are flat/negative below the tiny proof
    threshold, paper only skips this OPEN attempt and leaves the candidate to the
    next recheck/strategy cycle.
    """
    if not bool(ctrl.get("paper_final_reaction_proof_enabled", True)):
        return ""
    flows = diag.get("flow_window_candidates") if isinstance(diag.get("flow_window_candidates"), list) else []
    min_windows = int(fnum(ctrl.get("paper_final_reaction_proof_min_windows"), default=2.0))
    min_flow = fnum(ctrl.get("paper_final_reaction_proof_min_flow_pct"), default=0.01)
    usable = []
    for x in flows:
        if isinstance(x, dict) and x.get("value") is not None:
            try:
                usable.append((str(x.get("window") or "?"), float(x.get("value") or 0.0)))
            except Exception:
                pass
    if len(usable) < max(1, min_windows):
        return ""
    best = max(v for _w, v in usable)
    if best < min_flow:
        flow_txt = " / ".join(f"{w} {v:+.2f}%" for w, v in usable[:4])
        return f"진입 직전 무반응 재확인 보류({flow_txt} / 최고흐름 {best:+.2f}% < +{min_flow:.2f}%)"
    return ""

def paper_price_reaction_spine(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """paper final safety가 strategy recheck와 같은 가격반응 spine을 보게 한다.

    명시 0값이 있더라도 실제 non-zero short-flow/price-delta가 있으면 그 값을 사용한다.
    이것은 최종 안전문 기준 완화가 아니라 구 0.00 경로 제거다.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    explicit_keys = ["price_reaction_pct", "reaction_pct", "price_response_pct", "price_recheck_pct"]
    flow_keys = [
        "flow_1m_pct", "change_1m", "chg_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m",
        "flow_3m_pct", "change_3m", "chg_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m",
    ]
    candidates: List[Dict[str, Any]] = []
    candidates.extend(_paper_v143_all_present(srcs, explicit_keys, "explicit"))
    candidates.extend(_paper_v143_all_present(srcs, flow_keys, "short_flow"))
    pd = _paper_v143_price_delta_candidate(srcs)
    if pd:
        candidates.append(pd)
    explicit = [c for c in candidates if c.get("group") == "explicit"]
    nonzero_explicit = [c for c in explicit if abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_explicit:
        c = nonzero_explicit[0]
        return {"known": True, "value": float(c["value"]), "source": c.get("source"), "method": "explicit", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    nonzero_alt = [c for c in candidates if c.get("group") in ("short_flow", "price_delta") and abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_alt:
        c = nonzero_alt[0]
        zero_src = explicit[0].get("source") if explicit else ""
        method = "explicit_zero_overridden" if explicit else str(c.get("group") or "alternate")
        return {"known": True, "value": float(c["value"]), "source": f"{c.get('source')}" + (f"; explicit0={zero_src}" if zero_src else ""), "method": method, "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if explicit:
        c = explicit[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": "explicit_zero", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if candidates:
        c = candidates[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": str(c.get("group") or "candidate"), "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    return {"known": False, "value": 0.0, "source": "missing", "method": "missing", "candidates": [], "schema": "paper_price_reaction_spine_v143"}

def build_entry_diagnostics(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctx = ctx if isinstance(ctx, dict) else {}
    # v553: 진입근거는 strategy_worker가 분리 봉인한 entry_reasons만 우선 사용한다.
    # s_stage_reasons/reason은 위험·부족·재확인 문구가 섞일 수 있으므로 진입근거 fallback에서 제외한다.
    reasons = _diag_list(ev, ("entry_reasons", "final_entry_reasons", "trade_ready_reasons"), ctx, 10)
    structure_tags = _diag_list(ev, ("entry_structure_tags", "structure_tags", "matched_strategy_labels"), ctx, 10)
    confirm_signals = _diag_list(ev, ("confirm_signals", "s1_passed_conditions", "condition_pass_summary"), ctx, 10)
    risk_tags = _diag_list(ev, ("execution_risk_tags", "risk_tags", "structure_risk_tags"), ctx, 10)
    recheck_reasons = _diag_list(ev, ("recheck_reasons", "s2_recheck_reasons", "freshness_flags"), ctx, 10)
    block_reasons = _diag_list(ev, ("block_reasons", "s1_missing_conditions", "unmet_conditions"), ctx, 10)
    missing = _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "need_info", "entry_missing_info", "s1_missing"), ctx, 10)
    if not missing:
        missing = []
    matched = _diag_list(ev, ("matched_strategies", "strategy_matches", "strategy_tags", "tags"), ctx, 8)
    structure_levels = _diag_first(ev, ("structure_levels",), ctx=ctx)
    if not isinstance(structure_levels, dict):
        structure_levels = {}
    entry_plan = _diag_first(ev, ("entry_plan",), ctx=ctx)
    if not isinstance(entry_plan, dict):
        entry_plan = {}
    risk_reward = _diag_first(ev, ("risk_reward",), ctx=ctx)
    if not isinstance(risk_reward, dict):
        risk_reward = {}
    entry_timing_spine = _diag_first(ev, ("entry_timing_spine",), ctx=ctx)
    if not isinstance(entry_timing_spine, dict):
        entry_timing_spine = {}
    diag = {
        "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema"), ctx=ctx),
        "stage": _diag_first(ev, ("s_stage", "candidate_stage", "candidate_grade", "grade"), ctx=ctx),
        "strategy_key": _diag_first(ev, ("strategy_key", "paper_strategy_key", "strategy", "route", "section"), ctx=ctx),
        "strategy_label": _diag_first(ev, ("strategy_label", "paper_strategy_label", "final_entry_label"), ctx=ctx),
        "entry_reasons": reasons,
        "entry_structure_tags": structure_tags,
        "confirm_signals": confirm_signals,
        "execution_risk_tags": risk_tags,
        "recheck_reasons": recheck_reasons,
        "block_reasons": block_reasons,
        "missing_info": missing,
        "matched_strategies": matched,
        "reason_taxonomy_schema": _diag_first(ev, ("reason_taxonomy_schema",), ctx=ctx),
        "structure_levels": structure_levels,
        "entry_plan": entry_plan,
        "risk_reward": risk_reward,
        "entry_timing_spine": entry_timing_spine,
        "late_chase_flag": bool(_diag_first(ev, ("late_chase_flag",), ctx=ctx)),
        "micro_fresh": _fmt_bool(_diag_first(ev, ("micro_fresh", "micro_row_status", "micro_status"), ctx=ctx)),
        "ws_fresh": _fmt_bool(_diag_first(ev, ("ws_fresh", "ws_row_status", "quote_fresh", "quote_status"), ctx=ctx)),
        "buy_ratio": fnum(_diag_first(ev, ("buy_ratio", "buy_ratio_30s", "buy_trade_ratio", "micro_buy_ratio"), ctx=ctx), default=-1.0),
        "buy_sustain_1m": fnum(_diag_first(ev, ("micro_buy_ratio_sustain_1m", "buy_ratio_1m", "buy_sustain_1m"), ctx=ctx), default=-1.0),
        "spread_pct": fnum(_diag_first(ev, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"), ctx=ctx), default=-1.0),
        "slippage_pct": fnum(_diag_first(ev, ("slippage_est_pct", "expected_slippage_pct", "slippage_pct"), ctx=ctx), default=-1.0),
        "price_reaction_pct": fnum(_diag_first(ev, ("price_reaction_pct", "price_reaction", "reaction_pct", "price_recheck_pct"), ctx=ctx), default=0.0),
        "flow_1m_pct": fnum(_diag_first(ev, ("flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"), ctx=ctx), default=0.0),
        "flow_3m_pct": fnum(_diag_first(ev, ("flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"), ctx=ctx), default=0.0),
        "flow_5m_pct": fnum(_diag_first(ev, ("chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct"), ctx=ctx), default=0.0),
        "flow_15m_pct": fnum(_diag_first(ev, ("chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct"), ctx=ctx), default=0.0),
        "flow_30m_pct": fnum(_diag_first(ev, ("chg_30m", "flow_30m", "change_30m_pct", "ret_30m_pct"), ctx=ctx), default=0.0),
        "vwap_pos_pct": fnum(_diag_first(ev, ("vwap_pos_pct", "vwap_gap_pct", "vwap_position_pct", "vwap"), ctx=ctx), default=0.0),
        "ema5_pos_pct": fnum(_diag_first(ev, ("ema5_pos_pct", "ema5_gap_pct", "ema5_position_pct", "ema5"), ctx=ctx), default=0.0),
        "relative_strength": fnum(_diag_first(ev, ("relative_strength", "relative", "market_relative_strength"), ctx=ctx), default=0.0),
        "turnover_krw": fnum(_diag_first(ev, ("turnover_krw", "trade_amount_krw", "value_krw", "acc_trade_price_24h"), ctx=ctx), default=0.0),
        "sell_pressure": _diag_first(ev, ("sell_pressure", "ask_wall_pressure", "sell_trade_pressure"), ctx=ctx),
    }
    diag["flow_window_candidates"] = _paper_v144_flow_window_candidates(ev, ctx)
    diag["flow_window_source_schema"] = "paper_final_reaction_proof_v479_recheck_hold"
    diag["flow_window_map"] = {str(x.get("window")): x for x in diag["flow_window_candidates"] if isinstance(x, dict) and x.get("window")}
    pr_spine = paper_price_reaction_spine(ev, ctx)
    diag["price_reaction_pct"] = fnum(pr_spine.get("value"), default=0.0)
    diag["price_reaction_source"] = pr_spine.get("source")
    diag["price_reaction_method"] = pr_spine.get("method")
    diag["price_reaction_spine_schema"] = pr_spine.get("schema")
    diag["price_reaction_candidates"] = pr_spine.get("candidates") or []
    passed: List[str] = []
    if diag["micro_fresh"] == "OK": passed.append("micro신선")
    if diag["ws_fresh"] == "OK": passed.append("WS신선")
    if diag["buy_ratio"] >= 0: passed.append(f"매수체결 {diag['buy_ratio']:.2f}")
    if diag["buy_sustain_1m"] >= 0: passed.append(f"1분지속 {diag['buy_sustain_1m']:.2f}")
    if diag["spread_pct"] >= 0: passed.append(f"스프레드 {diag['spread_pct']:.2f}%")
    if diag["slippage_pct"] >= 0: passed.append(f"슬리피지 {diag['slippage_pct']:.2f}%")
    if diag["price_reaction_pct"]: passed.append(f"가격반응 {diag['price_reaction_pct']:+.2f}%")
    diag["condition_pass_summary"] = passed[:8]
    return diag


def _v494_first_ts_from_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]], keys: Iterable[str]) -> Tuple[float, str]:
    """Trace helper only. It must not change entry/exit decisions."""
    ctx = ctx if isinstance(ctx, dict) else {}
    for src in _diag_sources(ev, ctx):
        if not isinstance(src, dict):
            continue
        for k in keys:
            if k in src:
                ts = row_ts(src, k)
                if ts > 0:
                    return ts, k
    return 0.0, ""


def build_entry_timing_trace(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """진입이 늦었는지 확인하기 위한 trace. 조건/청산 변경에 쓰지 않는다."""
    ctx = copy_entry_context(ev)
    diag = diag if isinstance(diag, dict) else build_entry_diagnostics(ev, ctx)
    source_ts, src_key = _v494_first_ts_from_sources(ev, ctx, (
        "first_detected_ts", "first_seen_ts", "detected_ts", "candidate_created_at",
        "source_created_at", "created_at", "event_ts", "ts", "timestamp",
    ))
    promotion_ts, promotion_key = _v494_first_ts_from_sources(ev, ctx, (
        "s1_promotion_ts", "recheck_promotion_ts", "promoted_ts", "paper_handoff_ts",
        "handoff_ts", "updated_ts", "updated_at",
    ))
    nowv = now_ts()
    source_age_sec = max(0.0, nowv - source_ts) if source_ts > 0 else 0.0
    promotion_age_sec = max(0.0, nowv - promotion_ts) if promotion_ts > 0 else 0.0
    source_to_promotion_sec = max(0.0, promotion_ts - source_ts) if source_ts > 0 and promotion_ts > 0 else 0.0
    hot1 = _diag_first(ev, ("hot_rank_1m", "scanner_hot_rank_1m"), ctx=ctx)
    hot3 = _diag_first(ev, ("hot_rank_3m", "scanner_hot_rank_3m"), ctx=ctx)
    change_1m_source = _diag_first(ev, ("change_1m_source", "scanner_change_1m_source"), ctx=ctx)
    change_3m_source = _diag_first(ev, ("change_3m_source", "scanner_change_3m_source"), ctx=ctx)
    flags: List[str] = []
    f1 = fnum(diag.get("flow_1m_pct"), default=0.0)
    f3 = fnum(diag.get("flow_3m_pct"), default=0.0)
    react = fnum(diag.get("price_reaction_pct"), default=0.0)
    pr_src = str(diag.get("price_reaction_source") or "")
    if source_age_sec >= 120:
        flags.append(f"후보오래됨({source_age_sec/60.0:.1f}분)")
    if source_to_promotion_sec >= 60:
        flags.append(f"S1승격지연({source_to_promotion_sec:.0f}초)")
    if promotion_age_sec >= 45:
        flags.append(f"paper읽기지연({promotion_age_sec:.0f}초)")
    if f1 <= 0.01 and max(react, f3) >= 0.15:
        flags.append("현재1m약함/과거반응주의")
    if pr_src and ("3m" in pr_src or "5m" in pr_src or "15m" in pr_src) and f1 <= 0.01:
        flags.append("반응원천이현재1m아님")
    return {
        "schema": "entry_timing_trace_v494",
        "source_ts": source_ts, "source_key": src_key or "-",
        "s1_promotion_ts": promotion_ts, "s1_promotion_key": promotion_key or "-",
        "source_age_sec": round(source_age_sec, 1), "source_age_min": round(source_age_sec / 60.0, 2),
        "source_to_promotion_sec": round(source_to_promotion_sec, 1),
        "paper_read_delay_sec": round(promotion_age_sec, 1),
        "price_reaction_pct": round(react, 4),
        "price_reaction_source": diag.get("price_reaction_source") or "-",
        "price_reaction_method": diag.get("price_reaction_method") or "-",
        "flow_1m_pct": round(f1, 4), "flow_3m_pct": round(f3, 4),
        "hot_rank_1m": hot1, "hot_rank_3m": hot3,
        "change_1m_source": change_1m_source or "-", "change_3m_source": change_3m_source or "-",
        "flags": flags,
    }


def format_entry_timing_line(trace: Any, prefix: str = "- ") -> str:
    if not isinstance(trace, dict) or not trace:
        return prefix + "진입시점: trace 없음"
    age = fnum(trace.get("source_age_min"), default=0.0)
    promo_delay = fnum(trace.get("source_to_promotion_sec"), default=0.0)
    paper_delay = fnum(trace.get("paper_read_delay_sec"), default=0.0)
    f1 = fnum(trace.get("flow_1m_pct"), default=0.0)
    f3 = fnum(trace.get("flow_3m_pct"), default=0.0)
    hot1 = trace.get("hot_rank_1m") or "-"
    hot3 = trace.get("hot_rank_3m") or "-"
    flags = trace.get("flags") if isinstance(trace.get("flags"), list) else []
    tail = (" / 주의 " + ", ".join(str(x) for x in flags[:2])) if flags else ""
    delay_part = f" / S1까지 {promo_delay:.0f}s / paper {paper_delay:.0f}s" if promo_delay or paper_delay else ""
    return prefix + f"진입시점: 감지후 {age:.1f}분{delay_part} / 1m {f1:+.2f}% · 3m {f3:+.2f}% / hot {hot1}/{hot3}{tail}"


def _paper_v479_flow_display(diag: Dict[str, Any], window: str) -> str:
    """Display only canonical/present short-flow values.

    Missing short-flow information is shown as '-' rather than being displayed as
    +0.00%. This is display hygiene, not a stricter entry condition.
    """
    fmap = diag.get("flow_window_map") if isinstance(diag.get("flow_window_map"), dict) else {}
    item = fmap.get(window) if isinstance(fmap, dict) else None
    if isinstance(item, dict) and item.get("value") is not None:
        try:
            return f"{float(item.get('value')):+.2f}%"
        except Exception:
            return "-"
    return "-"


def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = "- ") -> List[str]:
    lines: List[str] = []
    reasons = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
    structures = diag.get("entry_structure_tags") if isinstance(diag.get("entry_structure_tags"), list) else []
    confirms = diag.get("confirm_signals") if isinstance(diag.get("confirm_signals"), list) else []
    risks = diag.get("execution_risk_tags") if isinstance(diag.get("execution_risk_tags"), list) else []
    rechecks = diag.get("recheck_reasons") if isinstance(diag.get("recheck_reasons"), list) else []
    blocks = diag.get("block_reasons") if isinstance(diag.get("block_reasons"), list) else []
    missing = diag.get("missing_info") if isinstance(diag.get("missing_info"), list) else []
    passed = diag.get("condition_pass_summary") if isinstance(diag.get("condition_pass_summary"), list) else []
    if structures:
        lines.append(prefix + "진입구조: " + " / ".join(str(x) for x in structures[:5]))
    if reasons:
        lines.append(prefix + "진입근거: " + " / ".join(str(x) for x in reasons[:5]))
    if confirms:
        lines.append(prefix + "확인통과: " + " / ".join(str(x) for x in confirms[:5]))
    elif passed:
        lines.append(prefix + "통과정보: " + " / ".join(str(x) for x in passed[:5]))
    levels = diag.get("structure_levels") if isinstance(diag.get("structure_levels"), dict) else {}
    plan = diag.get("entry_plan") if isinstance(diag.get("entry_plan"), dict) else {}
    rr = diag.get("risk_reward") if isinstance(diag.get("risk_reward"), dict) else {}
    timing_spine = diag.get("entry_timing_spine") if isinstance(diag.get("entry_timing_spine"), dict) else {}
    if levels and levels.get("available", True):
        lines.append(prefix + "구조선: 지지 " + fmt_price(levels.get("support_price")) + " / 방아쇠 " + fmt_price(levels.get("trigger_price")) + " / 무효 " + fmt_price(levels.get("invalid_price")) + " / 목표 " + fmt_price(levels.get("target1_price")) + "→" + fmt_price(levels.get("target2_price")))
    if plan:
        lines.append(prefix + "진입계획: " + str(plan.get("plan_type") or "-") + " / " + str(plan.get("trigger_reason") or "-"))
    if rr:
        up = fnum(rr.get("expected_upside_pct"), default=0.0); dn = fnum(rr.get("expected_downside_pct"), default=0.0); ratio = fnum(rr.get("rr_ratio"), default=0.0)
        lines.append(prefix + f"손익비: 기대상승 {up:+.2f}% / 무효손실 {-abs(dn):+.2f}% / RR {ratio:.2f}")
    if timing_spine:
        d1 = timing_spine.get("first_to_now_delay_sec"); d2 = timing_spine.get("s2_to_now_delay_sec"); r1 = fnum(timing_spine.get("first_to_now_return_pct"), default=0.0); r2 = fnum(timing_spine.get("s2_to_now_return_pct"), default=0.0)
        lines.append(prefix + f"진입타이밍: 최초→현재 {fnum(d1, default=0.0):.0f}s/{r1:+.2f}% · S2→현재 {fnum(d2, default=0.0):.0f}s/{r2:+.2f}%")
    if diag.get("late_chase_flag") or (levels and levels.get("late_chase_flag")):
        basis = diag.get("late_chase_basis") if isinstance(diag.get("late_chase_basis"), dict) else (levels.get("late_chase_basis") if isinstance(levels.get("late_chase_basis"), dict) else {})
        reason = str(diag.get("late_chase_reason") or levels.get("late_chase_reason") or "")
        if basis:
            lines.append(prefix + f"늦은추격: ⚠️ 주의 / 반응 {fnum(basis.get('reaction'), default=0.0):+.2f}% · 스프 {fnum(basis.get('spread'), default=0.0):.2f}%")
        else:
            lines.append(prefix + "늦은추격: ⚠️ 주의")
    if risks:
        lines.append(prefix + "위험태그: " + " / ".join(str(x) for x in risks[:5]))
    flow = (
        f"1m {_paper_v479_flow_display(diag, '1m')} · "
        f"3m {_paper_v479_flow_display(diag, '3m')} · "
        f"5m {_paper_v479_flow_display(diag, '5m')} · "
        f"15m {_paper_v479_flow_display(diag, '15m')}"
    )
    lines.append(prefix + "흐름: " + flow)
    pos = f"VWAP {diag.get('vwap_pos_pct',0):+.2f}% · EMA5 {diag.get('ema5_pos_pct',0):+.2f}% · 상대강도 {diag.get('relative_strength',0):+.2f}"
    lines.append(prefix + "위치: " + pos)
    caution = []
    for group in (rechecks, blocks, missing):
        for x in group:
            txt = str(x)
            if txt and txt not in caution:
                caution.append(txt)
    if caution:
        lines.append(prefix + "재확인/주의: " + " / ".join(str(x) for x in caution[:5]))
    else:
        lines.append(prefix + "최종판정: S1 통과")
    return lines


def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:
    ticker = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    detected = get_event_price(ev)
    price = live_price(ticker, detected) or detected
    ts = now_ts()
    ctx = copy_entry_context(ev)
    diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    timing_trace = build_entry_timing_trace(ev, diag)
    diag["entry_timing_trace"] = timing_trace
    grade = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade") or "S1").upper()
    current_main_version = active_main_version()
    current_patch_version = active_patch_version()
    event_main_version = ev.get("main_version") or ev.get("deploy_version") or ev.get("opened_main_version") or ""
    event_patch_version = ev.get("score_patch_version") or ev.get("patch_version") or ev.get("run_patch_version") or ev.get("deploy_patch_version") or ""
    stamped_main_version = current_main_version if current_main_version else event_main_version
    stamped_patch_version = current_patch_version if current_patch_version else event_patch_version
    raw_main_version = str(event_main_version or "").strip()
    raw_patch_version = str(event_patch_version or "").strip()
    return {
        "pos_id": pos_id,
        "event_id": pos_id,
        "ticker": ticker,
        "lane": ev.get("lane") or "strict",
        "paper_experiment_lane": ev.get("paper_experiment_lane"),
        "real_eligible": False if ev.get("paper_experiment_lane") == FAST_EXPERIMENT_LANE_V669 else ev.get("real_eligible", False),
        "auto_buy_ready": False,
        "buy_ready": False,
        "opened_at": ts,
        "opened_at_text": iso_ts(ts),
        "opened_paper_version": VERSION,
        # 성과판용 버전은 현재 DEPLOY_TARGET 기준으로 단일화한다.
        # 후보/worker 원본의 구버전 표기는 추적용 raw 필드에만 남긴다.
        "score_main_version": stamped_main_version,
        "opened_main_version": stamped_main_version,
        "main_version": stamped_main_version,
        "deploy_version": stamped_main_version,
        "source_main_version_raw": raw_main_version,
        "entry_build_key": stamped_patch_version,
        "open_build_key": stamped_patch_version,
        "entry_patch_version": stamped_patch_version,
        "score_patch_version": stamped_patch_version,
        "opened_patch_version": stamped_patch_version,
        "patch_version": stamped_patch_version,
        "run_patch_version": stamped_patch_version,
        "deploy_patch_version": stamped_patch_version,
        "source_patch_version_raw": raw_patch_version,
        "score_file_version": stamped_main_version,
        "strategy_worker_version": ev.get("strategy_worker_version") or ev.get("source_version") or ev.get("brain_version") or "",
        "paper_final_safety_passed": bool(ev.get("paper_final_safety_passed")),
        "entry_price": price,
        "detected_price": detected,
        "current_price": price,
        "peak_pct": 0.0,
        "trough_pct": 0.0,
        "last_pnl_pct": -fnum(DEFAULT_CONTROL.get("fee_pct_roundtrip"), default=0.10),
        "last_update": ts,
        "strategy": ev.get("strategy") or ev.get("strategy_key") or ev.get("route") or ev.get("section") or "unknown",
        "strategy_key": ev.get("strategy_key") or ev.get("paper_strategy_key") or ev.get("route") or ev.get("strategy"),
        "strategy_label": ev.get("strategy_label") or ev.get("paper_strategy_label") or ev.get("final_entry_label"),
        "candidate_grade": grade,
        "candidate_grade_label": ev.get("candidate_grade_label") or ev.get("s_stage_label") or ev.get("final_trade_label") or "✅ 최종 매수 가능",
        "final_trade_state": ev.get("final_trade_state") or ctx.get("final_trade_state"),
        "final_trade_label": ev.get("final_trade_label") or ctx.get("final_trade_label"),
        "final_trade_reasons": ev.get("final_trade_reasons") or ctx.get("final_trade_reasons") or [],
        "trade_ready": bool((ev.get("final_trade_state") or ctx.get("final_trade_state")) == "S1_PASS"),
        "trade_ready_label": ev.get("trade_ready_label") or ev.get("final_trade_label") or ev.get("final_entry_label") or "최종 매수 가능",
        "final_entry_action": ev.get("final_entry_action") or "paper_open",
        "final_entry_label": ev.get("final_entry_label") or ev.get("final_trade_label") or ev.get("trade_ready_label") or "최종 매수 가능",
        "final_entry_reasons": ev.get("final_entry_reasons") or ev.get("final_trade_reasons") or ev.get("trade_ready_reasons") or [],
        "scan_id": ev.get("scan_id") or ev.get("source_scan_id") or "",
        "brain_version": ev.get("brain_version") or ev.get("source_version") or "",
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "edge": fnum(ev.get("edge"), ev.get("edge_score"), default=0.0),
        "reason": ev.get("reason") or ev.get("why") or ev.get("hold_reason") or "",
        "source_created_at": event_created_ts(ev),
        "source_created_at_text": ev.get("created_at_text") or ev.get("source_created_at_text") or "",
        "entry_context": ctx,
        "entry_diagnostics": diag,
        "entry_timing_trace": timing_trace,
        "structure_levels": diag.get("structure_levels") or {},
        "entry_plan": diag.get("entry_plan") or {},
        "risk_reward": diag.get("risk_reward") or {},
        "entry_timing_spine": diag.get("entry_timing_spine") or {},
        "trigger_gate": diag.get("trigger_gate") or _v620_trigger_gate_from_sources(ev, diag),
        "trigger_reached": bool((diag.get("trigger_gate") or {}).get("trigger_reached")) if isinstance(diag.get("trigger_gate"), dict) else False,
        "trigger_gap_pct": (diag.get("trigger_gate") or {}).get("trigger_gap_pct") if isinstance(diag.get("trigger_gate"), dict) else None,
        "late_chase_flag": bool(diag.get("late_chase_flag")),
        "entry_condition_reasons": diag.get("entry_reasons") or [],
        "entry_structure_tags": diag.get("entry_structure_tags") or [],
        "confirm_signals": diag.get("confirm_signals") or [],
        "execution_risk_tags": diag.get("execution_risk_tags") or [],
        "recheck_reasons": diag.get("recheck_reasons") or [],
        "block_reasons": diag.get("block_reasons") or [],
        "entry_missing_info": diag.get("missing_info") or [],
        "entry_condition_pass_summary": diag.get("condition_pass_summary") or [],
        "raw": ev,
    }


EXIT_ICONS = {
    "take_profit": "✅",
    "stop_loss": "❌",
    "protect_stop_after_tp": "🛡️",
    "slow_no_progress": "⚠️",
    "fast_fail_stop": "📉",
    "time_exit": "⏱️",
    "spike_fast_fail_stop": "⚡",
    "spike_runner_trailing": "🏃",
    "spike_time_exit": "⏱️",
}

EXIT_LABELS = {
    "take_profit": "✅ 익절 종료",
    "stop_loss": "❌ 손절 종료",
    "protect_stop_after_tp": "🛡️ 익절 후 보호청산",
    "slow_no_progress": "⚠️ 지지부진 종료",
    "fast_fail_stop": "📉 빠른실패 정리",
    "time_exit": "⏱️ 시간 종료",
    "spike_fast_fail_stop": "⚡ 급등형 빠른실패",
    "spike_runner_trailing": "🏃 급등형 추적청산",
    "spike_time_exit": "⏱️ 급등형 시간청산",
}

EXIT_TITLES = {
    "take_profit": "✅ paper 익절 CLOSED",
    "stop_loss": "❌ paper 손절 CLOSED",
    "protect_stop_after_tp": "🛡️ paper 보호익절 CLOSED",
    "slow_no_progress": "⚠️ paper 지지부진 CLOSED",
    "fast_fail_stop": "📉 paper 빠른실패 CLOSED",
    "time_exit": "⏱️ paper 시간청산 CLOSED",
    "spike_fast_fail_stop": "⚡ paper 급등형 빠른실패 CLOSED",
    "spike_runner_trailing": "🏃 paper 급등형 추적청산 CLOSED",
    "spike_time_exit": "⏱️ paper 급등형 시간청산 CLOSED",
}


def closed_title(row: Dict[str, Any]) -> str:
    reason = str(row.get("exit_reason") or row.get("exit_rule") or "").strip()
    return EXIT_TITLES.get(reason, "🔴 paper CLOSED")



def adaptive_protect_floor(peak: float, ctrl: Dict[str, Any]) -> float:
    """수익권 진입 후 되돌림 방어선.

    숫자 하나로 고정하지 않고 최고수익 구간에 따라 최소 보존선을 올린다.
    잘 가는 후보는 take_profit/추가보유 여지를 남기되, +0.7~1.0% 갔다가
    음전까지 방치되는 흐름을 먼저 막는 목적이다.
    """
    base = fnum(ctrl.get("protect_floor_pct"), default=0.35)
    if peak >= fnum(ctrl.get("protect_big_trigger_pct"), default=1.40):
        return max(base, fnum(ctrl.get("protect_big_floor_pct"), default=0.75))
    if peak >= fnum(ctrl.get("protect_strong_trigger_pct"), default=1.00):
        return max(base, fnum(ctrl.get("protect_strong_floor_pct"), default=0.50))
    return base


def should_fast_fail(age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> bool:
    """진입 후 반응이 없으면 기본 손절선까지 기다리지 않고 정리한다."""
    peak_limit = fnum(ctrl.get("fast_fail_peak_under_pct"), default=0.20)
    if peak >= peak_limit:
        return False
    early_min = fnum(ctrl.get("fast_fail_after_min"), default=2.5)
    early_loss = fnum(ctrl.get("fast_fail_loss_pct"), default=-0.35)
    late_min = fnum(ctrl.get("fast_fail_after_min_late"), default=5.0)
    late_loss = fnum(ctrl.get("fast_fail_loss_pct_late"), default=-0.25)
    return (age_min >= early_min and net <= early_loss) or (age_min >= late_min and net <= late_loss)


def _strategy_text_for_exit(pos: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in ("strategy", "strategy_key", "strategy_label", "final_entry_label", "candidate_grade_label"):
        v = pos.get(k)
        if v:
            parts.append(str(v))
    raw = pos.get("raw") if isinstance(pos.get("raw"), dict) else {}
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    for obj in (raw, ctx, diag):
        for k in ("strategy", "strategy_key", "strategy_label", "paper_strategy_label", "final_entry_label"):
            v = obj.get(k) if isinstance(obj, dict) else None
            if v:
                parts.append(str(v))
    return " ".join(parts)


def _is_profit_run_strategy(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    text = _strategy_text_for_exit(pos).lower()
    keys = ctrl.get("profit_run_strategy_keywords")
    if not isinstance(keys, list) or not keys:
        keys = ["주도", "유동보유", "leader", "momentum"]
    return any(str(k).lower() in text for k in keys if str(k).strip())


def _should_extend_profit_run(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Tuple[bool, str]:
    """v486: 수익권에서 살아있는 주도흐름은 15분 고정 종료하지 않고 1회 연장한다.

    조건을 새로 조이는 용도가 아니라 time_exit 직전의 청산 판단을 한곳에서 정리한다.
    무반응/손실 후보는 fast_fail/stop_loss가 먼저 처리한다.
    """
    if not bool(ctrl.get("profit_run_extend_enabled", True)):
        return False, "연장 비활성"
    max_count = int(fnum(ctrl.get("profit_run_extend_max_count"), default=1))
    done = int(fnum(pos.get("time_exit_extension_count"), default=0))
    if done >= max_count:
        return False, "연장횟수 소진"
    if not _is_profit_run_strategy(pos, ctrl):
        return False, "연장대상 전략 아님"
    min_net = fnum(ctrl.get("profit_run_extend_min_net_pct"), default=0.20)
    min_peak = fnum(ctrl.get("profit_run_extend_min_peak_pct"), default=0.25)
    max_giveback = fnum(ctrl.get("profit_run_extend_max_giveback_pct"), default=0.25)
    giveback = max(0.0, peak - net)
    if net < min_net:
        return False, f"현재수익 부족 {net:+.2f}% < {min_net:+.2f}%"
    if peak < min_peak:
        return False, f"최고수익 부족 {peak:+.2f}% < {min_peak:+.2f}%"
    if giveback > max_giveback:
        return False, f"반납 큼 {giveback:+.2f}% > {max_giveback:+.2f}%"
    return True, f"수익권 유동보유 연장: 현재 {net:+.2f}% / 최고 {peak:+.2f}% / 반납 {giveback:+.2f}%"


def _exit_decision_spine(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Dict[str, Any]:
    """v486 exit decision spine.

    청산 조건을 여러 if에 흩뜨리지 않고 우선순위별로 한곳에서 결정한다.
    우선순위: 하드손절 → 빠른실패 → 익절선 → 보호익절 → 수익권 연장 → 지지부진 → 시간종료.
    """
    protect_trigger = fnum(ctrl.get("protect_trigger_pct"), default=0.70)
    protect_floor = adaptive_protect_floor(peak, ctrl)
    protect_giveback = fnum(ctrl.get("protect_giveback_pct"), default=0.55)
    giveback = max(0.0, peak - net)
    entry_profile = str(pos.get("entry_profile") or (pos.get("canonical_entry_decision") if isinstance(pos.get("canonical_entry_decision"), dict) else {}).get("entry_profile") or "normal_common")
    exit_profile = str(pos.get("exit_profile") or (pos.get("canonical_entry_decision") if isinstance(pos.get("canonical_entry_decision"), dict) else {}).get("exit_profile") or "normal_exit")
    d: Dict[str, Any] = {
        "schema": "exit_decision_spine_v535_profiles",
        "action": "hold",
        "reason": "",
        "detail": "보유",
        "age_min": round(age_min, 4),
        "net_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "giveback_pct": round(giveback, 4),
        "protect_floor_pct": round(protect_floor, 4),
        "entry_profile": entry_profile,
        "exit_profile": exit_profile,
    }

    # v535) 급등형 paper-test 전용 빠른실패/보호/추적. 일반 후보는 기존 청산 유지.
    if entry_profile == "spike":
        spike_stop = fnum(ctrl.get("spike_stop_loss_pct"), default=-0.60)
        if net <= spike_stop:
            d.update({"action": "close", "reason": "stop_loss", "detail": f"급등형 손절선 도달: 현재 {net:+.2f}%"})
            return d
        # 60~90초 안에 +0.20~0.30도 못 찍으면 빠른 실패.
        if entry_profile == "spike" and age_min >= fnum(ctrl.get("spike_fast_fail_after_min"), default=1.5) and peak < fnum(ctrl.get("spike_fast_fail_peak_under_pct"), default=0.25) and net <= fnum(ctrl.get("spike_fast_fail_net_under_pct"), default=0.05):
            d.update({"action": "close", "reason": "spike_fast_fail_stop", "detail": f"급등형 빠른실패: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
            return d
        # 수익권 진입 후 보호익절.
        if peak >= fnum(ctrl.get("spike_protect_trigger_pct"), default=0.70):
            spike_floor = fnum(ctrl.get("spike_protect_floor_pct"), default=0.30)
            spike_giveback = fnum(ctrl.get("spike_protect_giveback_pct"), default=0.55)
            if net <= spike_floor or giveback >= spike_giveback:
                d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"급등형 보호익절: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호 {spike_floor:+.2f}% / 반납 {giveback:+.2f}%"})
                return d
        # 더 가는 놈은 고정익절보다 최고수익 trailing 우선.
        if peak >= 3.00 and giveback >= 0.95:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if peak >= 2.00 and giveback >= 0.70:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if peak >= 1.20 and giveback >= 0.45:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if entry_profile == "spike" and age_min >= fnum(ctrl.get("spike_fast_time_exit_min"), default=8.0) and peak < 0.70:
            d.update({"action": "close", "reason": "spike_time_exit", "detail": f"급등형 시간청산: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
            return d

    # 1) 하드 손절은 최우선이다.
    stop_loss = fnum(ctrl.get("stop_loss_pct"), default=-0.55)
    if net <= stop_loss:
        d.update({"action": "close", "reason": "stop_loss", "detail": f"손절선 도달: 현재 {net:+.2f}%"})
        return d

    # 2) 진입 후 반응 없는 후보는 빨리 정리한다.
    if should_fast_fail(age_min, peak, net, ctrl):
        d.update({"action": "close", "reason": "fast_fail_stop", "detail": f"빠른실패 정리: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
        return d

    # 3) 명시 익절선 도달.
    take_profit = fnum(ctrl.get("take_profit_pct"), default=1.20)
    if net >= take_profit:
        d.update({"action": "close", "reason": "take_profit", "detail": f"익절선 도달: 현재 {net:+.2f}%"})
        return d

    # 4) 수익권 보호. +0.70% 이상은 기존 보호익절보다 더 먼저 본다.
    if peak >= protect_trigger and (net <= protect_floor or giveback >= protect_giveback):
        d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"수익권 보호: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호선 {protect_floor:+.2f}% / 반납 {giveback:+.2f}%"})
        return d

    # 4-1) +0.45~0.70% 갔다가 거의 본전까지 반납하는 케이스 방지.
    soft_trigger = fnum(ctrl.get("profit_soft_protect_trigger_pct"), default=0.45)
    soft_floor = fnum(ctrl.get("profit_soft_protect_floor_pct"), default=0.10)
    soft_giveback = fnum(ctrl.get("profit_soft_protect_giveback_pct"), default=0.45)
    if peak >= soft_trigger and (net <= soft_floor or giveback >= soft_giveback):
        d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"수익권 소프트 보호: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호선 {soft_floor:+.2f}% / 반납 {giveback:+.2f}%"})
        return d

    # 5) 15분 time_exit 직전, 살아있는 수익권 주도흐름은 1회 연장한다.
    time_exit_min = fnum(ctrl.get("time_exit_minutes"), default=15.0)
    if age_min >= time_exit_min:
        ok_extend, why = _should_extend_profit_run(pos, age_min, peak, net, ctrl)
        if ok_extend:
            d.update({"action": "extend", "reason": "time_exit_extend", "detail": why})
            return d

    # 6) 지지부진.
    if age_min >= fnum(ctrl.get("slow_minutes"), default=20.0) and peak < fnum(ctrl.get("slow_peak_under_pct"), default=0.25) and net <= 0.10:
        d.update({"action": "close", "reason": "slow_no_progress", "detail": f"지지부진: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
        return d

    # 7) 일반 time_exit.
    if age_min >= time_exit_min:
        d.update({"action": "close", "reason": "time_exit", "detail": f"시간종료: 보유 {age_min:.1f}분"})
        return d
    return d




def _v494_fast_fail_cause(row: Dict[str, Any]) -> Dict[str, Any]:
    """fast_fail 원인 표시용. 청산조건은 변경하지 않는다."""
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    trace = row.get("entry_timing_trace") if isinstance(row.get("entry_timing_trace"), dict) else {}
    if not trace and isinstance(diag, dict) and isinstance(diag.get("entry_timing_trace"), dict):
        trace = diag.get("entry_timing_trace")
    peak = fnum(row.get("peak_pct"), default=0.0)
    pnl = fnum(row.get("pnl_pct"), default=fnum(row.get("last_pnl_pct"), default=0.0))
    age_min = fnum(row.get("age_min"), default=0.0)
    source_age = fnum(trace.get("source_age_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    source_to_promo = fnum(trace.get("source_to_promotion_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    paper_delay = fnum(trace.get("paper_read_delay_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    react = fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0
    buy = fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0
    sustain = fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0
    spread = fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    slip = fnum(diag.get("slippage_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    reasons: List[str] = []
    label = "진입후반응없음"
    if source_to_promo >= 60 or source_age >= 120 or paper_delay >= 45:
        label = "늦은진입 의심"
        if source_age >= 120: reasons.append(f"감지후 {source_age/60.0:.1f}분")
        if source_to_promo >= 60: reasons.append(f"S1승격까지 {source_to_promo:.0f}초")
        if paper_delay >= 45: reasons.append(f"paper읽기 {paper_delay:.0f}초")
    elif react < 0.10:
        label = "진입반응 약함"
        reasons.append(f"가격반응 {react:+.2f}%")
    elif buy >= 0.70 and sustain >= 0.70 and peak <= 0.02:
        label = "체결은 좋지만 가격 안 감"
        reasons.append(f"매수 {buy:.2f} / 지속 {sustain:.2f} / 최고 {peak:+.2f}%")
    elif spread >= 0.20 or slip >= 0.20:
        label = "스프레드·미끄러짐 부담"
        if spread >= 0: reasons.append(f"스프 {spread:.2f}%")
        if slip >= 0: reasons.append(f"미끄러짐 {slip:.2f}%")
    else:
        reasons.append(f"최고 {peak:+.2f}% / 최종 {pnl:+.2f}% / 보유 {age_min:.1f}분")
    return {
        "schema": "fast_fail_cause_v494",
        "label": label,
        "reasons": reasons[:5],
        "source_age_sec": round(source_age, 1),
        "source_to_promotion_sec": round(source_to_promo, 1),
        "paper_read_delay_sec": round(paper_delay, 1),
        "price_reaction_pct": round(react, 4),
        "buy_ratio": round(buy, 4) if buy >= 0 else None,
        "buy_sustain_1m": round(sustain, 4) if sustain >= 0 else None,
        "spread_pct": round(spread, 4) if spread >= 0 else None,
        "slippage_pct": round(slip, 4) if slip >= 0 else None,
    }


def _v494_fast_fail_cause_line(row: Dict[str, Any]) -> str:
    obj = row.get("fast_fail_cause") if isinstance(row.get("fast_fail_cause"), dict) else {}
    if not obj:
        return ""
    rs = obj.get("reasons") if isinstance(obj.get("reasons"), list) else []
    tail = " / " + " / ".join(str(x) for x in rs[:3]) if rs else ""
    return f"- 빠른실패원인: {obj.get('label','-')}{tail}"

def close_review_tag(peak: float, pnl: float, reason: str) -> str:
    giveback = peak - pnl
    if peak >= 0.70 and pnl < 0:
        return "보호익절 필요 후보"
    if peak >= 0.70 and giveback >= 0.55:
        return "수익 되돌림 큼"
    if reason == "fast_fail_stop":
        return "빠른실패 정리 작동"
    if pnl <= -0.60 and peak < 0.25:
        return "빠른실패 정리 후보"
    if reason == "protect_stop_after_tp":
        return "보호익절 작동"
    if pnl > 0 and peak - pnl <= 0.35:
        return "수익 보존 양호"
    return "관찰"

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    ticker = normalize_ticker(pos.get("ticker"))
    entry = fnum(pos.get("entry_price"), default=0.0)
    if not ticker or entry <= 0:
        return pos, None
    price = live_price(ticker, fnum(pos.get("current_price"), default=entry))
    gross = ((price / entry) - 1.0) * 100.0 if entry else 0.0
    net = gross - fnum(ctrl.get("fee_pct_roundtrip"), default=0.10)
    pos["current_price"] = price
    pos["last_pnl_pct"] = round(net, 4)
    pos["peak_pct"] = max(fnum(pos.get("peak_pct"), default=0.0), net)
    pos["trough_pct"] = min(fnum(pos.get("trough_pct"), default=0.0), net)
    pos["last_update"] = now_ts()
    opened_at = fnum(pos.get("opened_at"), default=now_ts())
    age_min = (now_ts() - opened_at) / 60.0
    peak = fnum(pos.get("peak_pct"), default=0.0)
    decision = _exit_decision_spine(pos, age_min, peak, net, ctrl)
    pos["exit_decision_spine"] = decision
    pos["last_exit_decision"] = decision.get("action")
    pos["last_exit_decision_reason"] = decision.get("reason") or "hold"
    pos["last_exit_decision_detail"] = decision.get("detail") or "보유"
    if decision.get("action") == "extend":
        ext_count = int(fnum(pos.get("time_exit_extension_count"), default=0)) + 1
        extend_min = fnum(ctrl.get("profit_run_extend_minutes"), default=15.0)
        pos["time_exit_extension_count"] = ext_count
        pos["time_exit_extended_at"] = now_ts()
        pos["time_exit_extended_until_age_min"] = round(age_min + extend_min, 4)
        pos["time_exit_extension_reason"] = decision.get("detail") or "수익권 유동보유 연장"
        return pos, None
    if decision.get("action") != "close":
        return pos, None
    reason = str(decision.get("reason") or "").strip()
    detail = str(decision.get("detail") or reason).strip()
    if not reason:
        return pos, None
    closed_ts = now_ts()
    hold_sec = max(0, int(closed_ts - opened_at))
    closed = dict(pos)
    current_main_version = active_main_version()
    current_patch_version = active_patch_version()
    if current_main_version:
        # 파일 버전은 참고값으로 유지한다. 성과판의 주 기준은 아래 score_patch_version이다.
        raw_version_before_close = closed.get("score_main_version") or closed.get("closed_main_version") or closed.get("main_version") or closed.get("deploy_version") or closed.get("opened_main_version")
        if raw_version_before_close and not closed.get("source_main_version_raw"):
            closed["source_main_version_raw"] = raw_version_before_close
        for key in ("score_main_version", "closed_main_version", "opened_main_version", "main_version", "deploy_version", "score_file_version"):
            closed[key] = current_main_version
    if current_patch_version:
        # v634: 성과 기준은 OPEN 당시 entry_build_key/score_patch_version으로 고정한다.
        # CLOSED 시점 버전은 close_patch_version/closed_patch_version 참고값으로만 남긴다.
        entry_patch = closed.get("entry_build_key") or closed.get("score_patch_version") or closed.get("opened_patch_version") or closed.get("patch_version") or closed.get("run_patch_version") or closed.get("deploy_patch_version")
        if entry_patch and not closed.get("source_patch_version_raw"):
            closed["source_patch_version_raw"] = entry_patch
        if entry_patch:
            for key in ("entry_build_key", "open_build_key", "entry_patch_version", "score_patch_version", "opened_patch_version", "patch_version", "run_patch_version", "deploy_patch_version"):
                closed.setdefault(key, entry_patch)
        closed["closed_patch_version"] = current_patch_version
        closed["close_patch_version"] = current_patch_version
    closed.update({
        "closed_at": closed_ts,
        "closed_at_text": iso_ts(closed_ts),
        "exit_price": price,
        "pnl_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "trough_pct": round(fnum(pos.get("trough_pct"), default=0.0), 4),
        "missed_profit_pct": round(max(0.0, peak - net), 4),
        "giveback_pct": round(max(0.0, peak - net), 4),
        "went_negative_after_profit": bool(peak >= 0.70 and net < 0),
        "close_review_tag": close_review_tag(peak, net, reason),
        "age_min": round(age_min, 2),
        "hold_sec": hold_sec,
        "exit_reason": reason,
        "exit_rule": reason,
        "exit_rule_label": EXIT_LABELS.get(reason, reason),
        "exit_rule_reason": detail,
        "exit_decision_schema": "exit_decision_spine_v486",
        "exit_decision_spine": decision,
        "time_exit_extension_count": int(fnum(pos.get("time_exit_extension_count"), default=0)),
        "time_exit_extension_reason": pos.get("time_exit_extension_reason") or "",
        "closed_paper_version": VERSION,
        "close_source": "paper_bot_v0.174_profile_final_gate_aligned",
    })
    if reason == "fast_fail_stop":
        try:
            cause = _v494_fast_fail_cause(closed)
            closed["fast_fail_cause"] = cause
            closed["fast_fail_cause_label"] = cause.get("label")
            closed["fast_fail_cause_reasons"] = cause.get("reasons") or []
        except Exception as exc:
            log_error("v494_fast_fail_cause", exc)
    return pos, closed


def fmt_price(v: Any) -> str:
    x = fnum(v, default=0.0)
    if x >= 1000:
        return f"{x:,.0f}"
    if x >= 1:
        return f"{x:,.4f}"
    return f"{x:,.8f}"


def send_message(text: str) -> bool:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return False
    try:
        data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": text[:3900], "disable_web_page_preview": "true"}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data=data)
        urllib.request.urlopen(req, timeout=5).read()
        return True
    except Exception as exc:
        log_error("send_message", exc)
        return False


def notify_opened(pos: Dict[str, Any]) -> None:
    t = normalize_ticker(pos.get("ticker"))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ""
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(pos.get("entry_timing_trace") or (diag.get("entry_timing_trace") if isinstance(diag, dict) else {})) if bool(load_control().get("notify_entry_timing_trace", True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    text = (
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )
    ok = send_message(text)
    append_jsonl(FILES.get("open_alert_trace", BASE_DIR / "paper_bot_open_alert_trace.jsonl"), {
        "ts": now_ts(),
        "type": "open",
        "ticker": t,
        "event_id": pos.get("event_id") or pos.get("pos_id"),
        "alert_sent": bool(ok),
        "status": "sent" if ok else "send_failed_or_disabled",
        "paper_version": VERSION,
        "source": "notify_opened_v734",
    })


def notify_closed(row: Dict[str, Any]) -> None:
    t = normalize_ticker(row.get("ticker"))
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get("entry_timing_trace") or (diag.get("entry_timing_trace") if isinstance(diag, dict) else {})) if bool(load_control().get("notify_entry_timing_trace", True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    send_message(
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )




def _decision_line(obj: Any, label: str) -> str:
    if not isinstance(obj, dict):
        return f"- {label}: -"
    t = obj.get("ticker") or "-"
    status = obj.get("status") or "-"
    reason = str(obj.get("reason") or "-")
    react = fnum(obj.get("price_reaction_pct"), default=0.0)
    buy = fnum(obj.get("buy_ratio"), default=-1.0)
    sustain = fnum(obj.get("buy_sustain_1m"), default=-1.0)
    spread = fnum(obj.get("spread_pct"), default=-1.0)
    nums = []
    nums.append(f"반응 {react:+.2f}%")
    if buy >= 0:
        nums.append(f"매수 {buy:.2f}")
    if sustain >= 0:
        nums.append(f"지속 {sustain:.2f}")
    if spread >= 0:
        nums.append(f"스프 {spread:.2f}%")
    return f"- {label}: {t} / {status} / {' · '.join(nums)} / {reason[:180]}"


def _summary_reason_text(obj: Any) -> str:
    if not isinstance(obj, dict):
        return "-"
    reason = str(obj.get("reason") or "").strip()
    if not reason:
        reasons = obj.get("block_reasons") or obj.get("missing_info") or []
        if isinstance(reasons, list) and reasons:
            reason = str(reasons[0]).strip()
    return reason[:160] if reason else "-"


def _summary_counter_add(counter: Counter, text: str, amount: int = 1) -> None:
    text = str(text or "").strip()
    if not text or text == "-":
        return
    # 너무 긴 종목별 수치가 TOP을 어지럽히지 않도록 앞부분만 묶는다.
    key = text.split("/")[0].strip()[:90]
    if key:
        counter[key] += max(1, int(amount))


def _summary_top(counter: Counter, limit: int = 5) -> str:
    if not isinstance(counter, Counter) or not counter:
        return "-"
    return " / ".join(f"{k} {v}" for k, v in counter.most_common(limit))


def _reset_s1_summary_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "cycles": 0,
        "s1_seen": 0,
        "selected_s1": 0,
        "paper_final_block": 0,  # legacy counter name
        "paper_entry_hold": 0,
        "micro_preopen_wait": 0,
        "opened": 0,
        "closed": 0,
        "latest_count_max": 0,
        "fresh_count_max": 0,
        "final_block_reasons": Counter(),
        "skip_reasons": Counter(),
        "last_paper_final_block": None,
        "last_skip": None,
        "last_open_try": None,
        "last_s1_seen": None,
    }
    _S1_DECISION_SUMMARY_BUCKET.clear()
    _S1_DECISION_SUMMARY_BUCKET.update(bucket)
    return _S1_DECISION_SUMMARY_BUCKET


def _ensure_s1_summary_bucket() -> Dict[str, Any]:
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET, dict) or not _S1_DECISION_SUMMARY_BUCKET.get("start_ts"):
        return _reset_s1_summary_bucket(now_ts())
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("final_block_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["final_block_reasons"] = Counter()
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("skip_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["skip_reasons"] = Counter()
    return _S1_DECISION_SUMMARY_BUCKET


def notify_s1_decision_summary(pick_stats: Dict[str, Any], opened_count: int = 0, closed_count: int = 0, ctrl: Optional[Dict[str, Any]] = None) -> None:
    """S1/final block 흐름은 30분 단위로 묶어 보낸다.

    OPEN/CLOSED 즉시 알림은 유지한다. 후보/OPEN보류/무반응 재확인은 매 cycle마다
    보내지 않고, 1시간 동안 누적해서 가장 많은 보류 사유와 마지막 사례만 보여준다.
    조건/전략/장부는 건드리지 않는 알림 안정화 계층이다.
    """
    if not isinstance(pick_stats, dict):
        return
    ctrl = ctrl if isinstance(ctrl, dict) else {}
    if not bool(ctrl.get("notify_on_s1_decision_summary", True)):
        return

    now = now_ts()
    interval = fnum(
        ctrl.get("notify_s1_decision_summary_interval_sec", ctrl.get("notify_s1_decision_summary_min_interval_sec", 3600)),
        default=3600.0,
    )
    interval = max(3600.0, interval)  # v513: 후보요약은 최소 1시간. 조건/전략 판단은 유지.
    bucket = _ensure_s1_summary_bucket()

    s1_seen = int(fnum(pick_stats.get("s1_seen"), default=0.0))
    selected = int(fnum(pick_stats.get("selected_s1"), default=0.0))
    final_block = int(fnum(pick_stats.get("paper_final_block"), default=0.0))
    entry_hold = int(fnum(pick_stats.get("paper_entry_hold"), default=final_block))
    micro_wait = int(fnum(pick_stats.get("micro_preopen_wait"), default=0.0))

    bucket["cycles"] = int(bucket.get("cycles", 0)) + 1
    bucket["s1_seen"] = int(bucket.get("s1_seen", 0)) + s1_seen
    bucket["selected_s1"] = int(bucket.get("selected_s1", 0)) + selected
    bucket["paper_final_block"] = int(bucket.get("paper_final_block", 0)) + final_block
    bucket["paper_entry_hold"] = int(bucket.get("paper_entry_hold", 0)) + entry_hold
    bucket["micro_preopen_wait"] = int(bucket.get("micro_preopen_wait", 0)) + micro_wait
    bucket["opened"] = int(bucket.get("opened", 0)) + int(opened_count or 0)
    bucket["closed"] = int(bucket.get("closed", 0)) + int(closed_count or 0)
    bucket["latest_count_max"] = max(int(bucket.get("latest_count_max", 0)), int(fnum(pick_stats.get("latest_count"), default=0.0)))
    bucket["fresh_count_max"] = max(int(bucket.get("fresh_count_max", 0)), int(fnum(pick_stats.get("merged_fresh"), default=0.0)))

    last_block = pick_stats.get("last_paper_entry_hold") or pick_stats.get("last_paper_final_block")
    last_skip = pick_stats.get("last_skip")
    last_open = pick_stats.get("last_open_try")
    last_seen = pick_stats.get("last_s1_seen")

    if isinstance(last_block, dict):
        bucket["last_paper_final_block"] = last_block
        _summary_counter_add(bucket["final_block_reasons"], _summary_reason_text(last_block), amount=max(1, final_block))
    if isinstance(last_skip, dict):
        bucket["last_skip"] = last_skip
        _summary_counter_add(bucket["skip_reasons"], _summary_reason_text(last_skip), amount=1)
    if isinstance(last_open, dict):
        bucket["last_open_try"] = last_open
    if isinstance(last_seen, dict):
        bucket["last_s1_seen"] = last_seen

    elapsed = now - fnum(bucket.get("start_ts"), default=now)
    if elapsed < interval:
        return

    meaningful = (
        int(bucket.get("s1_seen", 0))
        + int(bucket.get("selected_s1", 0))
        + int(bucket.get("paper_entry_hold", bucket.get("paper_final_block", 0)))
        + int(bucket.get("opened", 0))
        + int(bucket.get("closed", 0))
    )
    if meaningful <= 0:
        _reset_s1_summary_bucket(now)
        return

    final_top = _summary_top(bucket.get("final_block_reasons"), limit=5)
    skip_top = _summary_top(bucket.get("skip_reasons"), limit=5)
    title = "🧭 paper S1 1시간 재확인/보류 요약"
    if "무반응" in final_top:
        title = "🧭 paper 1시간 무반응 재확인 보류 요약"

    minutes = max(1, int(round(elapsed / 60.0)))
    lines = [
        title,
        f"- 기간: 약 {minutes}분 / cycle {bucket.get('cycles', 0)}회",
        f"- S1감지 {bucket.get('s1_seen', 0)} / OPEN선택 {bucket.get('selected_s1', 0)} / OPEN보류 {bucket.get('paper_entry_hold', bucket.get('paper_final_block', 0))}",
        f"- OPEN {bucket.get('opened', 0)} / CLOSED {bucket.get('closed', 0)} / micro대기 {bucket.get('micro_preopen_wait', 0)}",
        f"- 후보 max latest {bucket.get('latest_count_max', 0)} / fresh {bucket.get('fresh_count_max', 0)}",
        f"- 보류 TOP: {final_top}",
        f"- 스킵 TOP: {skip_top}",
        _decision_line(bucket.get("last_paper_final_block"), "마지막 OPEN보류"),
        _decision_line(bucket.get("last_open_try"), "마지막 OPEN시도"),
        _decision_line(bucket.get("last_s1_seen"), "마지막 S1감지"),
        f"- paper: {VERSION}",
    ]
    send_message("\n".join(lines))
    _reset_s1_summary_bucket(now)


def _reset_hot_market_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "last_immediate_ts": 0.0,
        "cycles": 0,
        "hot_seen": 0,
        "best_by_ticker": {},
        "last_cache_age": None,
        "last_by_ticker": {},
    }
    _HOT_MARKET_NOTIFY_BUCKET.clear(); _HOT_MARKET_NOTIFY_BUCKET.update(bucket); return _HOT_MARKET_NOTIFY_BUCKET


def _ensure_hot_market_bucket() -> Dict[str, Any]:
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET, dict) or not _HOT_MARKET_NOTIFY_BUCKET.get("start_ts"):
        return _reset_hot_market_bucket(now_ts())
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("best_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["best_by_ticker"] = {}
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("last_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["last_by_ticker"] = {}
    return _HOT_MARKET_NOTIFY_BUCKET


def _load_hot_rank_rows(ctrl: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], float, Dict[str, Any]]:
    obj = load_json(FILES.get("hot_rank", BASE_DIR / "clean_scanner_hot_rank_cache.json"), {}) or {}
    if not isinstance(obj, dict): return [], 999999.0, {}
    updated = fnum(obj.get("updated_ts"), default=0.0)
    age = now_ts() - updated if updated > 0 else 999999.0
    rows = obj.get("rows") if isinstance(obj.get("rows"), list) else []
    ttl = fnum(ctrl.get("notify_market_hot_cache_ttl_sec"), default=90.0)
    if age > max(10.0, ttl): return [], age, obj
    return [r for r in rows if isinstance(r, dict)], age, obj


def _hot_row_score(row: Dict[str, Any]) -> float:
    c1=fnum(row.get("scanner_change_1m_pct"),default=0.0); c3=fnum(row.get("scanner_change_3m_pct"),default=0.0)
    r1=fnum(row.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(row.get("scanner_hot_rank_3m"),default=9999.0)
    return max(0.0,c1)*4.0 + max(0.0,c3)*2.0 + max(0.0,12.0-min(r1,r3))


def _hot_candidate_stage_index() -> Dict[str, Dict[str, Any]]:
    """hot-rank 알림에 후보판정 단계만 붙인다. OPEN/조건 판단은 바꾸지 않는다."""
    idx: Dict[str, Dict[str, Any]] = {}
    try:
        for r in read_jsonl_tail(FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 300):
            if not isinstance(r, dict):
                continue
            t = normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if not t:
                continue
            idx[t] = r
    except Exception:
        pass
    return idx


def _candidate_stage_label_for_hot(ticker: str, idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    if not ticker or not isinstance(idx, dict):
        return "후보 -"
    r = idx.get(ticker)
    if not isinstance(r, dict):
        return "후보없음"
    st = str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
    if st not in {"S1", "S2", "S3", "X"}:
        st = "-"
    return f"후보 {st}"




def _v514_short_text(value: Any, limit: int = 38) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        parts = [str(x).strip() for x in value if str(x).strip()]
        txt = " / ".join(parts[:3])
    elif isinstance(value, dict):
        parts = []
        for k, v in value.items():
            if v in (None, "", [], {}):
                continue
            parts.append(f"{k}:{v}")
        txt = " / ".join(parts[:3])
    else:
        txt = str(value).strip()
    txt = re.sub(r"\s+", " ", txt)
    if len(txt) > limit:
        txt = txt[:limit-1] + "…"
    return txt

def _v514_first_text(row: Dict[str, Any], keys: Iterable[str], limit: int = 38) -> str:
    if not isinstance(row, dict):
        return ""
    for k in keys:
        if k in row and row.get(k) not in (None, "", [], {}):
            txt = _v514_short_text(row.get(k), limit=limit)
            if txt:
                return txt
    return ""

def _v514_candidate_stage_detail_for_hot(ticker: str, idx: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[str, str, str, str]:
    """hot-rank 1시간 요약용. 후보단계/막힘/부족/paper상태를 canonical latest row에서만 읽는다."""
    if not ticker or not isinstance(idx, dict):
        return "후보 -", "", "", "paper -"
    r = idx.get(ticker)
    if not isinstance(r, dict):
        return "후보없음", "", "", "paper not_seen"
    st = str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
    if st not in {"S1", "S2", "S3", "X"}:
        st = "-"
    block = _v514_first_text(r, (
        "s1_block_reason", "final_block_reason", "block_reason", "main_block_reason",
        "reject_reason", "entry_block_reason", "reason", "candidate_reason",
        "막힘", "block_reasons", "reasons"
    ), limit=44)
    missing = _v514_first_text(r, (
        "missing_reason", "missing_info", "missing_tags", "lack_reason", "info_missing", "부족",
    ), limit=34)
    risk = _v514_first_text(r, (
        "risk_tags", "risk_reason", "structure_risk_tags", "spike_guard_reasons", "stale_reasons", "위험"
    ), limit=34)
    reason_parts = []
    if block: reason_parts.append(block)
    if risk: reason_parts.append("위험 " + risk)
    if missing: reason_parts.append("부족 " + missing)
    reason = " / ".join(reason_parts[:3])
    # paper 상태는 OPEN 판단이 아니라, paper가 볼 수 있는 후보인지 확인하기 위한 표시만 한다.
    if st == "S1":
        pstate = "paper open대상"
    elif st in {"S2", "S3"}:
        pstate = "paper not_s1"
    elif st == "X":
        pstate = "paper 제외"
    else:
        pstate = "paper not_seen"
    seen = _v514_first_text(r, ("paper_state", "paper_status", "handoff_status", "paper_trace_status"), limit=24)
    if seen:
        pstate = "paper " + seen
    return f"후보 {st}", reason, pstate, str(r.get("strategy_label") or r.get("strategy_key") or r.get("strategy") or "")

def _v514_time_label_from_row(row: Dict[str, Any]) -> str:
    ts = fnum(row.get("detected_ts"), row.get("first_seen_ts"), row.get("created_at"), row.get("updated_ts"), row.get("ts"), default=0.0)
    if ts <= 0:
        return "포착 -"
    try:
        return "포착 " + time.strftime("%H:%M:%S", time.localtime(ts))
    except Exception:
        return "포착 -"

def _format_hot_row(row: Dict[str, Any], stage_idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    t=normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol")) or "-"
    c1=fnum(row.get("scanner_change_1m_pct"),default=0.0); c3=fnum(row.get("scanner_change_3m_pct"),default=0.0)
    r1=row.get("scanner_hot_rank_1m") or "-"; r3=row.get("scanner_hot_rank_3m") or "-"
    price=row.get("current_price") or row.get("price") or row.get("trade_price")
    stage, reason, pstate, strat = _v514_candidate_stage_detail_for_hot(t, stage_idx)
    base = f"{t} {fmt_price(price)} / 1m {c1:+.2f}% #{r1} · 3m {c3:+.2f}% #{r3} / {stage}"
    extras = []
    tl = _v514_time_label_from_row(row)
    if tl != "포착 -":
        extras.append(tl)
    if strat:
        extras.append(strat)
    if reason:
        extras.append("이유 " + reason)
    if pstate:
        extras.append(pstate)
    if extras:
        return base + " / " + " / ".join(extras[:4])
    return base


def notify_market_hot_summary(ctrl: Optional[Dict[str, Any]] = None) -> None:
    # 시장 급등 관찰 알림. 매수/진입 조건은 바꾸지 않고, 실시간 알림만 강한 급등 중심으로 줄인다.
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    if not bool(ctrl.get("notify_market_hot_alert", True)): return
    bucket=_ensure_hot_market_bucket(); rows, age, meta=_load_hot_rank_rows(ctrl); now=now_ts()
    interval=max(3600.0,fnum(ctrl.get("notify_market_hot_summary_interval_sec"),default=3600.0))
    immediate_interval=max(3600.0,fnum(ctrl.get("notify_market_hot_global_min_interval_sec"),default=3600.0))
    ticker_cooldown=max(3600.0,fnum(ctrl.get("notify_market_hot_ticker_cooldown_sec", ctrl.get("notify_market_hot_immediate_min_interval_sec")),default=3600.0))
    max_items=max(1,int(fnum(ctrl.get("notify_market_hot_max_items"),default=4)))
    top_n=max(1,int(fnum(ctrl.get("notify_market_hot_rank_top_n"),default=5)))
    weak_th1=fnum(ctrl.get("notify_market_hot_1m_pct"),default=0.80); weak_th3=fnum(ctrl.get("notify_market_hot_3m_pct"),default=1.50)
    strong_th1=fnum(ctrl.get("notify_market_hot_immediate_1m_pct"),default=1.50); strong_th3=fnum(ctrl.get("notify_market_hot_immediate_3m_pct"),default=2.50)
    stage_idx = _hot_candidate_stage_index()
    good=[]
    strong=[]
    for r in rows:
        c1=fnum(r.get("scanner_change_1m_pct"),default=0.0); c3=fnum(r.get("scanner_change_3m_pct"),default=0.0)
        r1=fnum(r.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(r.get("scanner_hot_rank_3m"),default=9999.0)
        is_good = c1>=weak_th1 or c3>=weak_th3 or (r1<=top_n and c1>=0.20) or (r3<=top_n and c3>=0.40)
        is_strong = c1>=strong_th1 or c3>=strong_th3 or (r1<=3 and c1>=weak_th1) or (r3<=3 and c3>=weak_th3)
        if is_good:
            rr=dict(r); rr["_hot_score"]=_hot_row_score(rr); good.append(rr)
            if is_strong:
                strong.append(rr)
    good.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    strong.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    bucket["cycles"]=int(bucket.get("cycles",0))+1
    bucket["hot_seen"]=int(bucket.get("hot_seen",0))+len(good)
    bucket["strong_seen"]=int(bucket.get("strong_seen",0))+len(strong)
    bucket["last_cache_age"]=round(age,1) if age<999999 else None
    best=bucket.get("best_by_ticker") if isinstance(bucket.get("best_by_ticker"),dict) else {}
    for r in good[:max_items*3]:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if t and (t not in best or _hot_row_score(r)>_hot_row_score(best[t])):
            best[t]=r
    bucket["best_by_ticker"]=best

    last_by_ticker=bucket.get("last_by_ticker") if isinstance(bucket.get("last_by_ticker"),dict) else {}
    fresh_strong=[]
    for r in strong:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t:
            continue
        if now-fnum(last_by_ticker.get(t),default=0.0) >= ticker_cooldown:
            fresh_strong.append(r)
    if bool(ctrl.get("notify_market_hot_immediate_enabled", False)) and fresh_strong and now-fnum(bucket.get("last_immediate_ts"),default=0.0)>=immediate_interval:
        lines=[
            "⚡ 강한 급등 감지 / hot-rank",
            f"- 즉시 기준 1m +{strong_th1:.2f}% 또는 3m +{strong_th3:.2f}% / 약한 급등은 1시간 요약",
            f"- 신규/쿨다운 통과 {min(len(fresh_strong), max_items)}개 · 같은 종목 {int(round(ticker_cooldown/60.0))}분 쿨다운 · 전체 {int(round(immediate_interval/60.0))}분 묶음",
            "- 매수 알림 아님 · S1/OPEN 여부는 별도 판단",
        ]
        for r in fresh_strong[:max_items]:
            lines.append("- "+_format_hot_row(r, stage_idx))
            t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if t:
                last_by_ticker[t]=now
        bucket["last_by_ticker"]=last_by_ticker
        lines.append(f"- paper: {VERSION}")
        send_message("\n".join(lines))
        bucket["last_immediate_ts"]=now
    elapsed=now-fnum(bucket.get("start_ts"),default=now)
    if elapsed<interval:
        return
    best_rows=list(best.values()); best_rows.sort(key=lambda x:_hot_row_score(x), reverse=True)
    if not best_rows:
        _reset_hot_market_bucket(now); return
    minutes=max(1,int(round(elapsed/60.0)))
    lines=["🧭 시장 hot-rank 1시간 요약", f"- 기간 약 {minutes}분 / cycle {bucket.get('cycles',0)}회 / 감지누적 {bucket.get('hot_seen',0)} / 강한급등 {bucket.get('strong_seen',0)}", f"- cache age {bucket.get('last_cache_age','-')}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}", "- 매수 알림 아님 · 많이 오른 종목/포착시간/후보단계 연결 확인용"]
    for r in best_rows[:max_items]:
        lines.append("- "+_format_hot_row(r, stage_idx))
    lines.append(f"- paper: {VERSION}")
    send_message("\n".join(lines))
    _reset_hot_market_bucket(now)


def _score_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) > 0)
    losses = max(0, n - wins)
    total = sum(fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows)
    return {"n": n, "wins": wins, "losses": losses, "win_rate": (wins / n * 100.0 if n else 0.0), "total": total, "avg": (total / n if n else 0.0)}


def _score_bucket(row: Dict[str, Any]) -> str:
    stage = str(row.get("candidate_grade") or row.get("s_stage") or row.get("stage") or row.get("grade") or "S1").upper()
    if stage in {"S", "STRICT", "OPEN"}:
        return "S1"
    if stage not in {"S1", "S2", "S3", "X"}:
        return "S1"
    return stage


def _strategy_key(row: Dict[str, Any]) -> str:
    for k in ("strategy_primary", "strategy_bucket_primary", "strategy_key", "strategy", "strategy_name"):
        v = row.get(k)
        if v:
            return str(v)
    return "unknown"



# v606: 성과판의 '버전'은 파일명(v2.13.xxx)이 아니라 사용자가 적용한 수정판(v605/v606)을 우선한다.
_PATCH_VERSION_FIELDS = (
    "entry_build_key", "open_build_key", "entry_patch_version",
    "score_patch_version", "opened_patch_version",
    "patch_version", "run_patch_version", "deploy_patch_version", "bundle_version",
    "closed_patch_version", "close_patch_version",
)

def _normalize_patch_version_key(v: Any, field: str = "") -> str:
    return _patch_version_from_text(v)

def _patch_version_key(row: Dict[str, Any]) -> str:
    for k in _PATCH_VERSION_FIELDS:
        v = row.get(k)
        key = _normalize_patch_version_key(v, k)
        if key:
            return key
    for parent_key in ("raw", "entry_context", "entry_diagnostics", "source_event", "meta", "metadata"):
        obj = row.get(parent_key)
        if isinstance(obj, dict):
            for k in _PATCH_VERSION_FIELDS:
                key = _normalize_patch_version_key(obj.get(k), f"{parent_key}.{k}")
                if key:
                    return key
    return ""

# v434: 성과판 집계용 key는 score_main_version → closed_main_version만 우선한다.
# 후보/worker의 source_version/brain_version은 실제 실행 메인버전이 아니므로
# version_summary 집계 원천에서 제거한다. 필요 시 raw 필드로만 추적한다.
_MAIN_VERSION_FIELDS = (
    "score_main_version", "closed_main_version",
    "main_version", "deploy_version", "opened_main_version",
    "entry_main_version", "source_main_version", "main_bot_version", "main_file",
    "deploy_target", "target", "source_file", "restore_build", "main_build",
    "deploy_build", "source_build",
)
_RAW_VERSION_TRACE_FIELDS = ("source_version", "brain_version", "source_main_version_raw")


def _normalize_main_version_key(v: Any, field: str = "") -> str:
    """main/deploy version 표기를 v2.13.xxx 단일 key로 맞춘다.

    v432에서 단순 v2.13.xxx만 정규화해도 score가 0전으로 남았다.
    원인은 과거 CLOSED가 v390, v427_v390_main..., coinbot_main_v2_13_390.py
    같은 단축/빌드 표기를 갖고 있을 수 있기 때문이다.

    단, paper_bot_v0.132 같은 paper/worker 버전을 main 버전으로 오인하지 않도록
    vNNN 단축 표기는 field 이름이나 값에 main/deploy/수익형 단서가 있을 때만 허용한다.
    """
    if v is None:
        return ""
    s = str(v).strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_.]13[_.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    field_l = str(field or "").lower()
    value_l = s.lower()
    mainish = any(x in field_l for x in ("main", "deploy", "target", "brain")) or any(
        x in value_l for x in ("main", "deploy", "target", "수익형", "coinbot_main")
    )
    if mainish:
        hits = re.findall(r"(?:^|[^0-9])v(\d{3,4})(?:[^0-9]|$)", s)
        # v390/v391 같은 main shorthand만 허용한다. v0.132/paper version은 여기 걸리지 않는다.
        if hits:
            n = int(hits[-1])
            if 300 <= n <= 9999:
                return f"v2.13.{n}"
    return ""


def _iter_version_source_values(row: Dict[str, Any]) -> Iterable[Tuple[str, Any]]:
    for k in _MAIN_VERSION_FIELDS:
        if k in row:
            yield k, row.get(k)
    # 과거 CLOSED는 원본 후보(raw)나 entry_context 안에 main/deploy 표기가 남는 경우가 있다.
    # 장부를 다시 계산하지 않고, 이미 CLOSED row 안에 들어 있는 값만 살핀다.
    for parent_key in ("raw", "entry_context", "entry_diagnostics", "source_event", "meta", "metadata"):
        obj = row.get(parent_key)
        if isinstance(obj, dict):
            for k in _MAIN_VERSION_FIELDS:
                if k in obj:
                    yield f"{parent_key}.{k}", obj.get(k)
            nested = obj.get("entry_context")
            if isinstance(nested, dict):
                for k in _MAIN_VERSION_FIELDS:
                    if k in nested:
                        yield f"{parent_key}.entry_context.{k}", nested.get(k)


def _paper_version_num(v: Any) -> int:
    m = re.search(r"paper_bot_v0\.(\d+)", str(v or ""))
    return int(m.group(1)) if m else 0


def _version_num_from_key(key: str) -> int:
    m = re.search(r"v2\.13\.(\d+)", str(key or ""))
    return int(m.group(1)) if m else 0


def _is_stale_main_key(key: str, active: str, legacy: str, recent_paper: bool) -> bool:
    if not key or not active or not recent_paper:
        return False
    if legacy and key == legacy and key != active:
        return True
    # 현재 실행 메인보다 현저히 오래된 key는 후보 raw/구 DEPLOY_TARGET 오염으로 본다.
    # 장부 원본은 그대로 두고 성과 cache 집계에서만 보정한다.
    kn = _version_num_from_key(key)
    an = _version_num_from_key(active)
    return bool(kn and an and kn < an - 20)


def _main_version_key(row: Dict[str, Any]) -> str:
    # v606 본선: score/version_score의 버전 기준은 수정판(v605/v606)이다.
    # 파일 버전(v2.13.xxx)은 score_file_version/main_version 참고값으로만 남긴다.
    patch_key = _patch_version_key(row)
    if patch_key:
        return patch_key

    active = active_main_version()
    legacy = _legacy_deploy_target_version()
    recent_paper = _paper_version_num(row.get("closed_paper_version") or row.get("opened_paper_version")) >= 128

    candidate_keys: List[str] = []
    for field in ("score_main_version", "closed_main_version"):
        key = _normalize_main_version_key(row.get(field), field)
        if key:
            candidate_keys.append(key)
            if _is_stale_main_key(key, active, legacy, recent_paper):
                continue
            return key

    for field, val in _iter_version_source_values(row):
        if field in {"score_main_version", "closed_main_version"}:
            continue
        key = _normalize_main_version_key(val, field)
        if not key:
            continue
        candidate_keys.append(key)
        if _is_stale_main_key(key, active, legacy, recent_paper):
            continue
        return key

    if candidate_keys:
        return candidate_keys[0]
    return "unknown"





def _v463_as_list(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, dict):
        return [f"{k}:{val}" for k, val in list(v.items())[:6]]
    if isinstance(v, str) and v.strip():
        parts = [p.strip() for p in re.split(r"[/,|]", v) if p.strip()]
        return parts or [v.strip()]
    return []


def _v463_entry_source(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for key in ("entry_diagnostics", "entry_context", "raw"):
        obj = row.get(key)
        if isinstance(obj, dict):
            out.append(obj)
            for sub in ("entry_diagnostics", "entry_context", "structure", "orderflow", "micro", "feature"):
                vv = obj.get(sub)
                if isinstance(vv, dict):
                    out.append(vv)
    out.append(row)
    return out


def _v463_first(row: Dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    for src in _v463_entry_source(row):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default


def _v463_entry_summary(row: Dict[str, Any]) -> Dict[str, Any]:
    tags: List[str] = []
    risks: List[str] = []
    for src in _v463_entry_source(row):
        for k in ("structure_tags", "structure_good_tags", "matched_strategies", "strategy_tags"):
            tags.extend(_v463_as_list(src.get(k)))
        for k in ("structure_risk_tags", "risk_tags", "entry_missing_info", "missing_info"):
            risks.extend(_v463_as_list(src.get(k)))
    seen: set[str] = set()
    tags = [x for x in tags if not (x in seen or seen.add(x))][:5]
    seen = set()
    risks = [x for x in risks if not (x in seen or seen.add(x))][:5]
    reaction = fnum(_v463_first(row, ("price_reaction_pct", "price_reaction", "reaction_pct")), default=0.0)
    buy = fnum(_v463_first(row, ("buy_ratio", "buy_trade_ratio", "micro_buy_ratio")), default=-1.0)
    sustain = fnum(_v463_first(row, ("buy_sustain_1m", "micro_buy_ratio_sustain_1m", "buy_ratio_1m")), default=-1.0)
    spread = fnum(_v463_first(row, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct")), default=-1.0)
    metrics_parts = [f"반응 {reaction:+.2f}%"]
    if buy >= 0:
        metrics_parts.append(f"매수 {buy:.2f}")
    if sustain >= 0:
        metrics_parts.append(f"지속 {sustain:.2f}")
    if spread >= 0:
        metrics_parts.append(f"스프 {spread:.2f}%")
    return {
        "structure_tags": tags,
        "risk_tags": risks,
        "metrics": {"price_reaction_pct": reaction, "buy_ratio": buy, "buy_sustain_1m": sustain, "spread_pct": spread},
        "metrics_text": " · ".join(metrics_parts),
    }


def _recent_closed_summary(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ticker": normalize_ticker(row.get("ticker")),
        "pnl_pct": round(fnum(row.get("pnl_pct"), row.get("profit_pct"), default=0.0), 4),
        "peak_pct": round(fnum(row.get("peak_pct"), default=0.0), 4),
        "trough_pct": round(fnum(row.get("trough_pct"), default=0.0), 4),
        "exit_reason": row.get("exit_reason") or row.get("exit_rule") or "-",
        "exit_rule_label": row.get("exit_rule_label") or row.get("exit_reason") or "-",
        "age_min": row.get("age_min"),
        "hold_sec": row.get("hold_sec"),
        "closed_at": fnum(row.get("closed_at"), default=0.0),
        "closed_at_text": row.get("closed_at_text") or "",
        "opened_at_text": row.get("opened_at_text") or "",
        "close_review_tag": row.get("close_review_tag") or "-",
        "strategy": row.get("strategy_label") or row.get("strategy") or row.get("strategy_key") or "-",
        "version": _main_version_key(row),
        "score_main_version_raw": row.get("score_main_version") or "",
        "closed_main_version_raw": row.get("closed_main_version") or "",
        "source_main_version_raw": row.get("source_main_version_raw") or "",
        "entry_summary": _v463_entry_summary(row),
    }


def _build_recent_12h(rows: List[Dict[str, Any]], hours: float = 12.0) -> Dict[str, Any]:
    cutoff = now_ts() - hours * 3600.0
    recent = [r for r in rows if fnum(r.get("closed_at"), default=0.0) >= cutoff]
    by_version: Dict[str, List[Dict[str, Any]]] = {}
    by_reason = Counter()
    for r in recent:
        by_version.setdefault(_main_version_key(r), []).append(r)
        by_reason[str(r.get("exit_reason") or r.get("exit_rule") or "unknown")] += 1
    return {
        "schema": "paper_recent_12h_v467_score_key_strict",
        "window_hours": hours,
        "since_ts": cutoff,
        "since_text": iso_ts(cutoff),
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "global": _score_stat(recent),
        "by_version": {k: _score_stat(v) for k, v in by_version.items()},
        "version_keys": sorted(by_version.keys()),
        "exit_reason_counts": dict(by_reason.most_common(8)),
        "recent_closed": [_recent_closed_summary(r) for r in recent[-10:]],
        "active_main_version": active_main_version(),
        "active_main_version_source": active_main_version_detail()[1],
        "legacy_deploy_target_version": _legacy_deploy_target_version(),
    }



# v543: 전략별 승리군/손실군 비교 분석 캐시
# 조건/청산/paper 장부는 변경하지 않고 score cache에 분석용 요약만 추가한다.
def _v543_median(xs: List[float]) -> float:
    vals = sorted(float(x) for x in xs if x is not None)
    if not vals:
        return 0.0
    m = len(vals) // 2
    if len(vals) % 2:
        return vals[m]
    return (vals[m - 1] + vals[m]) / 2.0


def _v543_avg(xs: List[float]) -> float:
    vals = [float(x) for x in xs if x is not None]
    return sum(vals) / len(vals) if vals else 0.0


def _v543_metric(row: Dict[str, Any], names: Tuple[str, ...], default: float = 0.0) -> float:
    return fnum(_v463_first(row, names), default=default)


def _v543_metric_summary(rows: List[Dict[str, Any]], names: Tuple[str, ...]) -> Dict[str, Any]:
    vals: List[float] = []
    for r in rows:
        val = _v463_first(r, names)
        if val in (None, "", [], {}):
            continue
        vals.append(fnum(val, default=0.0))
    if not vals:
        return {"n": 0, "avg": 0.0, "median": 0.0, "min": 0.0, "max": 0.0}
    return {
        "n": len(vals),
        "avg": round(_v543_avg(vals), 4),
        "median": round(_v543_median(vals), 4),
        "min": round(min(vals), 4),
        "max": round(max(vals), 4),
    }


def _v543_counter_tags(rows: List[Dict[str, Any]], keys: Tuple[str, ...], limit: int = 6) -> Dict[str, int]:
    """v544: risk/structure tag counts are per-trade, not per-source.

    The v543 producer scanned several nested sources for each CLOSED row. If the same
    tag was present in row + context + diagnostics, it was counted multiple times,
    making values such as `스프레드부담 675` appear from only 110 losing trades.
    This keeps one vote per tag per CLOSED trade.
    """
    c: Counter = Counter()
    for r in rows:
        row_seen = set()
        for src in _v463_entry_source(r):
            for key in keys:
                for x in _v463_as_list(src.get(key)):
                    sx = str(x).strip()
                    if sx and sx not in {"-", "None", "unknown"}:
                        row_seen.add(sx)
        for sx in row_seen:
            c[sx] += 1
    return dict(c.most_common(limit))


def _v544_tag_rate_map(counts: Dict[str, int], denom: int) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    d = max(int(denom or 0), 1)
    for k, v in (counts or {}).items():
        n = int(v or 0)
        out[str(k)] = {"count": n, "rate": round(n * 100.0 / d, 1)}
    return out


def _v544_loss_combo_counter(rows: List[Dict[str, Any]], limit: int = 6) -> Dict[str, int]:
    """Loss-pattern combos for S2 recheck design.

    This is a diagnostic producer only. It does not change S1/S2/S3 criteria.
    Each CLOSED row contributes at most one count per combo.
    """
    combo_c: Counter = Counter()
    for r in rows:
        tags = set()
        for src in _v463_entry_source(r):
            for key in ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info"):
                for x in _v463_as_list(src.get(key)):
                    sx = str(x).strip()
                    if sx and sx not in {"-", "None", "unknown"}:
                        tags.add(sx)
        react = _v543_metric(r, ("price_reaction_pct", "price_reaction", "reaction_pct"), 0.0)
        buy = _v543_metric(r, ("buy_ratio", "buy_trade_ratio", "micro_buy_ratio"), 0.0)
        sustain = _v543_metric(r, ("buy_sustain_1m", "micro_buy_ratio_sustain_1m", "buy_ratio_1m"), 0.0)
        spread = _v543_metric(r, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"), 0.0)
        slip = _v543_metric(r, ("slippage_pct", "expected_slippage_pct", "micro_slippage_pct"), spread)
        comps = set()
        if react >= 0.30:
            comps.add("가격반응높음/추격")
        if buy < 0.70:
            comps.add("매수체결약함")
        if sustain < 0.70:
            comps.add("1분지속약함")
        if spread >= 0.45 or "스프레드부담" in tags:
            comps.add("스프레드부담")
        if slip >= 0.45 or "미끄러짐부담" in tags:
            comps.add("미끄러짐부담")
        for risk in ("윗꼬리위험", "되돌림위험", "고점권가격반응약함", "채널상단과열", "거래량없는돌파", "매도압력부담"):
            if risk in tags:
                comps.add(risk)
        if len(comps) >= 2:
            # Most useful for strategy design: a compact 2~3 factor signature.
            priority = ["가격반응높음/추격", "스프레드부담", "미끄러짐부담", "1분지속약함", "매수체결약함", "윗꼬리위험", "되돌림위험", "거래량없는돌파", "매도압력부담"]
            ordered = [x for x in priority if x in comps]
            key = " + ".join(ordered[:3])
            if key:
                combo_c[key] += 1
    return dict(combo_c.most_common(limit))


def _v544_peak_summary(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    peaks: List[float] = []
    finals: List[float] = []
    givebacks: List[float] = []
    for r in rows:
        final = fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0)
        peak_raw = _v463_first(r, ("max_profit_pct", "peak_profit_pct", "highest_profit_pct", "best_profit_pct", "max_unrealized_pct", "mfe_pct"))
        peak = fnum(peak_raw, default=final)
        peaks.append(peak)
        finals.append(final)
        givebacks.append(peak - final)
    return {
        "n": len(rows),
        "peak_avg": round(_v543_avg(peaks), 4),
        "peak_median": round(_v543_median(peaks), 4),
        "final_avg": round(_v543_avg(finals), 4),
        "giveback_avg": round(_v543_avg(givebacks), 4),
        "giveback_median": round(_v543_median(givebacks), 4),
    }


def _v543_outcome_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    return _score_stat(rows)


def _v543_build_strategy_outcome_analysis(by_strategy: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
    metric_defs: Dict[str, Tuple[str, ...]] = {
        "price_reaction_pct": ("price_reaction_pct", "price_reaction", "reaction_pct"),
        "buy_ratio": ("buy_ratio", "buy_trade_ratio", "micro_buy_ratio"),
        "buy_sustain_1m": ("buy_sustain_1m", "micro_buy_ratio_sustain_1m", "buy_ratio_1m"),
        "spread_pct": ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"),
        "slippage_pct": ("slippage_pct", "expected_slippage_pct", "micro_slippage_pct"),
        "fresh_age_sec": ("micro_age_sec", "orderflow_age_sec", "fresh_age_sec", "quote_age_sec"),
    }
    out: Dict[str, Any] = {}
    for strategy, rows in by_strategy.items():
        if not rows:
            continue
        wins = [r for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) > 0]
        losses = [r for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) <= 0]
        win_pnls = [fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in wins]
        loss_pnls = [fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in losses]
        gain = sum(x for x in win_pnls if x > 0)
        loss_abs = abs(sum(x for x in loss_pnls if x < 0))
        metric_obj: Dict[str, Any] = {}
        for name, keys in metric_defs.items():
            win_sum = _v543_metric_summary(wins, keys)
            loss_sum = _v543_metric_summary(losses, keys)
            metric_obj[name] = {
                "win": win_sum,
                "loss": loss_sum,
                "gap_loss_minus_win": round(fnum(loss_sum.get("avg"), default=0.0) - fnum(win_sum.get("avg"), default=0.0), 4),
            }
        out[strategy] = {
            "all": _v543_outcome_stat(rows),
            "wins": _v543_outcome_stat(wins),
            "losses": _v543_outcome_stat(losses),
            "avg_win_pct": round(_v543_avg(win_pnls), 4),
            "avg_loss_pct": round(_v543_avg(loss_pnls), 4),
            "payoff_ratio": round((_v543_avg(win_pnls) / abs(_v543_avg(loss_pnls))) if loss_pnls and _v543_avg(loss_pnls) != 0 else 0.0, 4),
            "profit_factor": round((gain / loss_abs) if loss_abs > 0 else (gain if gain > 0 else 0.0), 4),
            "expectancy_pct": round(_v543_avg([fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows]), 4),
            "metrics": metric_obj,
            "win_top_risks": _v543_counter_tags(wins, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")),
            "loss_top_risks": _v543_counter_tags(losses, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")),
            "win_top_structures": _v543_counter_tags(wins, ("structure_tags", "structure_good_tags", "matched_strategies", "strategy_tags")),
            "loss_top_structures": _v543_counter_tags(losses, ("structure_tags", "structure_good_tags", "matched_strategies", "strategy_tags")),
            "win_top_risk_rates": _v544_tag_rate_map(_v543_counter_tags(wins, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")), len(wins)),
            "loss_top_risk_rates": _v544_tag_rate_map(_v543_counter_tags(losses, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")), len(losses)),
            "loss_pattern_combos": _v544_loss_combo_counter(losses),
            "win_peak_summary": _v544_peak_summary(wins),
            "loss_peak_summary": _v544_peak_summary(losses),
        }
    return out



# =============================================================================
# paper_bot v0.185 / v557: today strategy score cache
# - CLOSED 장부는 삭제하지 않는다.
# - 기본 성과판이 오늘 전략 성과를 먼저 볼 수 있게 today_* cache만 추가한다.
# =============================================================================
def _v557_row_ts(row: Dict[str, Any]) -> float:
    for k in ("closed_at", "closed_ts", "exit_ts", "exited_at", "timestamp", "ts", "updated_at", "created_at"):
        v = row.get(k)
        if v not in (None, "", [], {}):
            try:
                if isinstance(v, str):
                    vv = v.replace("T", " ").replace("Z", "").strip()
                    if vv.replace(".", "", 1).isdigit():
                        return float(vv)
                    import datetime as _dt
                    try:
                        return _dt.datetime.fromisoformat(vv).timestamp()
                    except Exception:
                        pass
                return float(v)
            except Exception:
                continue
    return 0.0


def _v557_today_start_ts(nowv: Optional[float] = None) -> float:
    import datetime as _dt
    tz = _dt.timezone(_dt.timedelta(hours=9))
    n = _dt.datetime.fromtimestamp(nowv or now_ts(), tz=tz)
    start = _dt.datetime(n.year, n.month, n.day, tzinfo=tz)
    return start.timestamp()


def _v557_filter_today(rows: List[Dict[str, Any]], nowv: Optional[float] = None) -> List[Dict[str, Any]]:
    start = _v557_today_start_ts(nowv)
    end = (nowv or now_ts()) + 5
    out=[]
    for r in rows:
        ts = _v557_row_ts(r)
        if ts <= 0:
            # Active CLOSED tail may contain legacy rows without timestamp. Do not include in today.
            continue
        if start <= ts <= end:
            out.append(r)
    return out


def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:
    """현재 활성 CLOSED tail만 읽어 메인봇 cache 성과판을 만든다.

    전체 장부 재계산은 하지 않는다. 가드봇이 활성 CLOSED를 최근분으로 줄이는 정책과 맞춘다.
    """
    try:
        rows = read_jsonl_tail(FILES["closed"], 300)
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        by_grade: Dict[str, List[Dict[str, Any]]] = {}
        by_strategy: Dict[str, List[Dict[str, Any]]] = {}
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        by_strategy_version: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        by_profile: Dict[str, List[Dict[str, Any]]] = {}
        by_profile_exit: Dict[str, List[Dict[str, Any]]] = {}
        by_strategy_exit: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            strategy_key = _strategy_key(r)
            version_key = _main_version_key(r)
            by_grade.setdefault(_score_bucket(r), []).append(r)
            by_strategy.setdefault(strategy_key, []).append(r)
            by_version.setdefault(version_key, []).append(r)
            by_version_strategy.setdefault(version_key, {}).setdefault(strategy_key, []).append(r)
            by_strategy_version.setdefault(strategy_key, {}).setdefault(version_key, []).append(r)
            prof = str(r.get("entry_profile") or "unknown")
            if prof in {"spike_fast_early", "spike_runner"}:
                prof = "spike"
            elif prof in {"spike_fast_watch", "normal_watch"}:
                prof = "watch"
            by_profile.setdefault(prof, []).append(r)
            ex = str(r.get("exit_reason") or r.get("exit_rule") or "-")
            by_profile_exit.setdefault(f"{prof}:{ex}", []).append(r)
            by_strategy_exit.setdefault(f"{strategy_key}:{ex}", []).append(r)
        grade_stats = {k: _score_stat(v) for k, v in by_grade.items()}
        grade_stats["ALL"] = _score_stat(rows)
        strategy_stats = {k: _score_stat(v) for k, v in by_strategy.items()}
        strategy_exit_stats = {k: _score_stat(v) for k, v in by_strategy_exit.items()}
        strategy_outcome_analysis = _v543_build_strategy_outcome_analysis(by_strategy)
        version_summary = {k: _score_stat(v) for k, v in by_version.items()}
        version_strategy_stats = {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in by_version_strategy.items()}
        strategy_version_stats = {sk: {vk: _score_stat(vrows) for vk, vrows in vmap.items()} for sk, vmap in by_strategy_version.items()}
        today_by_strategy: Dict[str, List[Dict[str, Any]]] = {}
        today_by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        for tr in today_rows:
            tsk = _strategy_key(tr)
            tvk = _main_version_key(tr)
            today_by_strategy.setdefault(tsk, []).append(tr)
            today_by_version_strategy.setdefault(tvk, {}).setdefault(tsk, []).append(tr)
        today_strategy_stats = {k: _score_stat(v) for k, v in today_by_strategy.items()}
        today_version_strategy_stats = {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in today_by_version_strategy.items()}
        entry_profile_stats = {k: _score_stat(v) for k, v in by_profile.items()}
        profile_exit_stats = {k: _score_stat(v) for k, v in by_profile_exit.items()}
        obj = {
            "schema": "paper_score_cache_v098_today_strategy",
            "version": VERSION,
            "paper_version": VERSION,
            "build": BUILD_LABEL,
            "score_scope": "active_closed_tail_cache_only",
            "updated_at": nowv,
            "updated_at_text": iso_ts(),
            "current_closed_count": len(rows),
            "closed_count": len(rows),
            "source": "paper_bot_active_closed_tail",
            "global_stats": _score_stat(rows),
            "today_scope": "Asia/Seoul_day_midnight_to_now_cache_only",
            "today_timezone": "Asia/Seoul",
            "today_day_key": _kst_day_key(nowv),
            "today_start_ts": _v557_today_start_ts(nowv),
            "today_start_text": iso_ts(_v557_today_start_ts(nowv)),
            "today_closed_count": len(today_rows),
            "today_global_stats": _score_stat(today_rows),
            "today_strategy_stats": today_strategy_stats,
            "today_version_strategy_stats": today_version_strategy_stats,
            "grade_stats": grade_stats,
            "strategy_primary_stats": strategy_stats,
            "strategy_stats": strategy_stats,
            "strategy_exit_stats": strategy_exit_stats,
            "strategy_primary_exit_stats": strategy_exit_stats,
            "strategy_outcome_analysis": strategy_outcome_analysis,
            "entry_profile_stats": entry_profile_stats,
            "profile_exit_stats": profile_exit_stats,
            # v433 단일 본선: 메인 /version_score는 이 key만 읽는다.
            "version_summary": version_summary,
            # v549: 같은 score cache 안에서 버전별 × 전략별 성과를 봉인한다.
            # 메인봇은 CLOSED 장부를 직접 보지 않고 이 캐시만 읽는다.
            "version_strategy_stats": version_strategy_stats,
            "strategy_version_stats": strategy_version_stats,
            "version_strategy_schema": "v549_version_x_strategy_cache_only",
            "version_summary_schema": "v549_strict_score_main_version_key_with_strategy",
            "version_summary_keys": sorted(version_summary.keys()),
            "recent_12h": _build_recent_12h(rows, 12.0),
            "active_main_version": active_main_version(),
            "active_main_version_source": active_main_version_detail()[1],
            "active_patch_version": active_patch_version(),
            "active_patch_version_source": active_patch_version_detail()[1],
            "version_key_policy": "v606_patch_version_first_file_version_reference",
            "legacy_deploy_target_version": _legacy_deploy_target_version(),
            # 아래 두 key는 full/구독자가 남아 있을 수 있어 같은 내용을 복제하지만,
            # /version_score 기본 명령은 version_summary만 읽는다.
            "version_stats": version_summary,
            "main_version_stats": version_summary,
            "status_open_count": (status or {}).get("open_count") if isinstance(status, dict) else None,
        }
        save_json(FILES["score"], obj)
    except Exception as exc:
        log_error("write_score_cache", exc)

def write_status(status: Dict[str, Any]) -> None:
    global _LAST_STATUS
    base = {
        "version": VERSION,
        "active_reader_version": VERSION,
        "build": BUILD_LABEL,
        "pid": os.getpid(),
        "self_pid": os.getpid(),
        "process_pid": os.getpid(),
        "process_alive": True,
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "running": True,
        "stop_reason": "running",
        "paper_open_policy": "strategy final_trade_state == S1_PASS only",
        "runtime_reapply_marker": "v603",
    }
    base.update(status)
    _LAST_STATUS = base
    write_pid()
    save_json(FILES["status"], base)





def _format_last_pick_line(key: str, pick: Dict[str, Any]) -> str:
    obj = pick.get(key) if isinstance(pick, dict) else None
    if not isinstance(obj, dict):
        label = {
            "last_s1_seen": "마지막 S1감지",
            "last_open_try": "마지막 OPEN시도",
            "last_paper_final_block": "마지막 OPEN보류",
            "last_skip": "마지막 스킵",
        }.get(key, key)
        return f"- {label}: -"
    label = {
        "last_s1_seen": "마지막 S1감지",
        "last_open_try": "마지막 OPEN시도",
        "last_paper_final_block": "마지막 OPEN보류",
        "last_skip": "마지막 스킵",
    }.get(key, key)
    t = obj.get("ticker") or "-"
    status = obj.get("status") or "-"
    reason = obj.get("reason") or "-"
    return f"- {label}: {t} / {status} / {reason}"



# v561: /pstatus는 _LAST_STATUS.pick_stats 단독값 대신 paper status/handoff/trace/open/alert spine을 읽는다.
def _v561_age_from(obj: Any) -> str:
    try:
        if not isinstance(obj, dict):
            return '-'
        ts = fnum(obj.get('updated_at') or obj.get('ts'), default=0.0)
        if ts <= 0:
            return '-'
        return f"{max(0.0, now_ts() - ts):.1f}s"
    except Exception:
        return '-'


def _v561_latest_open_alert_trace() -> Dict[str, Any]:
    try:
        rows = read_jsonl_tail(FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl'), 80)
        for r in reversed(rows):
            if isinstance(r, dict):
                return r
    except Exception as exc:
        log_error('v561_latest_open_alert_trace', exc)
    return {}


def _v561_pick_spine(status: Dict[str, Any], handoff: Dict[str, Any]) -> Dict[str, Any]:
    pick: Dict[str, Any] = {}
    if isinstance(status, dict) and isinstance(status.get('pick_stats'), dict):
        pick.update(status.get('pick_stats') or {})
    if isinstance(handoff, dict) and isinstance(handoff.get('pick_stats'), dict):
        # handoff_status는 v560부터 현재 paper_latest 기준 heartbeat이므로 최종 source로 우선한다.
        pick.update(handoff.get('pick_stats') or {})
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        for dst, keys in {
            'latest_count': ('latest_count', 'paper_latest_count'),
            'merged_fresh': ('merged_fresh', 'fresh_count'),
            's1_seen': ('s1_seen',),
            'selected_s1': ('selected_s1',),
            'paper_entry_hold': ('paper_entry_hold', 'paper_final_block'),
            'micro_preopen_wait': ('micro_preopen_wait',),
        }.items():
            if dst in pick and pick.get(dst) not in (None, ''):
                continue
            for k in keys:
                if k in src and src.get(k) not in (None, ''):
                    pick[dst] = src.get(k)
                    break
    return pick


def _v561_current_open_lines(op: Dict[str, Dict[str, Any]], limit: int = 3) -> List[str]:
    out: List[str] = []
    try:
        vals = list(op.values()) if isinstance(op, dict) else []
        for p in vals[:limit]:
            if not isinstance(p, dict):
                continue
            opened_at = fnum(p.get('opened_at'), default=0.0)
            age_min = ((now_ts() - opened_at) / 60.0) if opened_at > 0 else 0.0
            out.append(
                f"  · {normalize_ticker(p.get('ticker'))} / {p.get('candidate_grade','S1')} / "
                f"{fnum(p.get('last_pnl_pct'), default=0.0):+.2f}% / "
                f"보유 {age_min:.1f}분 / {p.get('strategy_label') or p.get('strategy') or '-'}"
            )
    except Exception as exc:
        log_error('v561_current_open_lines', exc)
    return out


def _v561_alert_line(alert: Dict[str, Any]) -> str:
    if not isinstance(alert, dict) or not alert:
        return '- 마지막 OPEN알림: -'
    ts = fnum(alert.get('ts'), default=0.0)
    age = f"{max(0.0, now_ts() - ts):.1f}s" if ts > 0 else '-'
    ok = alert.get('sent_ok')
    err = str(alert.get('error') or '').strip()
    state = 'sent_ok' if ok is True else 'error' if err else 'unknown'
    tail = f" / {err[:80]}" if err else ''
    return f"- 마지막 OPEN알림: {alert.get('ticker') or '-'} / {state} / age {age}{tail}"


def _v561_format_last_pick_line(key: str, pick: Dict[str, Any]) -> str:
    try:
        return _format_last_pick_line(key, pick)
    except Exception:
        label = {
            'last_s1_seen': '마지막 S1감지',
            'last_open_try': '마지막 OPEN시도',
            'last_paper_final_block': '마지막 OPEN보류',
            'last_skip': '마지막 스킵',
        }.get(key, key)
        return f"- {label}: -"

def pstatus_text() -> str:
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    handoff = load_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}
    trace = load_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), {}) or {}
    if not isinstance(status, dict):
        status = {}
    if not isinstance(handoff, dict):
        handoff = {}
    if not isinstance(trace, dict):
        trace = {}
    op = load_open()
    pick = _v561_pick_spine(status, handoff)
    latest = pick.get('latest_count', status.get('latest_count', handoff.get('latest_count', '-')))
    fresh = pick.get('merged_fresh', status.get('merged_fresh', handoff.get('merged_fresh', '-')))
    open_lines = _v561_current_open_lines(op)
    alert = _v561_latest_open_alert_trace()
    lines = [
        f"🧪 paper 상태 /pstatus ({VERSION})",
        f"- running: {status.get('running', True)} / open {len(op)} / status age {_v561_age_from(status)} / handoff age {_v561_age_from(handoff)} / trace age {_v561_age_from(trace)}",
        f"- 이번 cycle: OPEN {status.get('opened_this_cycle',0)} / CLOSED {status.get('closed_this_cycle',0)} / elapsed {status.get('elapsed_sec','-')}s",
        f"- 후보: latest {latest} / fresh {fresh} / S1감지 {pick.get('s1_seen',0)} / S1선택 {pick.get('selected_s1',0)} / OPEN보류 {pick.get('paper_entry_hold', pick.get('paper_final_block',0))} / micro대기 {pick.get('micro_preopen_wait',0)}",
        f"- source: status+handoff+trace+open_alert_trace 단일판독 / handoff {handoff.get('version','-')} / trace {trace.get('version') or trace.get('trace_version') or '-'}",
        f"- 시장hot: 알림 {'ON' if load_control().get('notify_market_hot_alert', True) else 'OFF'} / cache age {max(0.0, now_ts()-fnum((load_json(FILES.get('hot_rank', BASE_DIR/'clean_scanner_hot_rank_cache.json'), {}) or {}).get('updated_ts'), default=now_ts())):.1f}s",
    ]
    if open_lines:
        lines.append('- 현재 OPEN:')
        lines.extend(open_lines)
    else:
        lines.append('- 현재 OPEN: -')
    lines.extend([
        _v561_format_last_pick_line('last_s1_seen', pick),
        _v561_format_last_pick_line('last_open_try', pick),
        _v561_format_last_pick_line('last_paper_final_block', pick),
        _v561_format_last_pick_line('last_skip', pick),
        _v561_alert_line(alert),
        '- 엔진: light_runner / legacy loop 사용 안 함',
    ])
    return "\n".join(lines)

def popen_text() -> str:
    op = load_open()
    lines = [f"📂 paper OPEN /popen ({VERSION})", f"- OPEN {len(op)}개"]
    for p in list(op.values())[:20]:
        if not isinstance(p, dict):
            continue
        diag = p.get("entry_diagnostics") if isinstance(p.get("entry_diagnostics"), dict) else {}
        rs = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
        lines.append(f"- {normalize_ticker(p.get('ticker'))} / {fnum(p.get('last_pnl_pct'), default=0):+.2f}% / 진입 {fmt_price(p.get('entry_price'))} / 최고 {fnum(p.get('peak_pct'), default=0):+.2f}% / {p.get('strategy_label') or p.get('strategy') or '-'}")
        if rs:
            lines.append("  · 근거: " + " / ".join(str(x) for x in rs[:3]))
    return "\n".join(lines)


def perror_text() -> str:
    lines = tail_lines(FILES["error"], 40)
    recent = "\n".join(lines[-40:])[-3500:]
    return "🧯 paper 오류 /perror\n\n" + (recent if recent else "✅ 오류로그 없음")


def plog_text() -> str:
    return "🧾 paper 로그 /plog\n\n" + ("\n".join(tail_lines(FILES["log"], 50))[-3500:] or "로그 없음")




def hot_summary_text() -> str:
    ctrl = load_control()
    rows, age, meta = _load_hot_rank_rows(ctrl)
    stage_idx = _hot_candidate_stage_index()
    max_items = max(5, int(fnum(ctrl.get("notify_market_hot_max_items"), default=4)))
    top_n = max(5, int(fnum(ctrl.get("notify_market_hot_rank_top_n"), default=5)))
    weak_th1=fnum(ctrl.get("notify_market_hot_1m_pct"),default=0.80); weak_th3=fnum(ctrl.get("notify_market_hot_3m_pct"),default=1.50)
    good=[]
    for r in rows:
        c1=fnum(r.get("scanner_change_1m_pct"),default=0.0); c3=fnum(r.get("scanner_change_3m_pct"),default=0.0)
        r1=fnum(r.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(r.get("scanner_hot_rank_3m"),default=9999.0)
        if c1>=weak_th1 or c3>=weak_th3 or (r1<=top_n and c1>=0.20) or (r3<=top_n and c3>=0.40):
            rr=dict(r); rr["_hot_score"]=_hot_row_score(rr); good.append(rr)
    good.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    lines=["🧭 시장 hot-rank 현재 요약 /hot_summary", f"- cache age {age:.1f}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}", "- 매수 알림 아님 · 많이 오른 종목/포착시간/후보단계/못 올라온 이유 확인용"]
    if not good:
        lines.append("- 표시할 급등 후보 없음")
    for r in good[:max_items]:
        lines.append("- "+_format_hot_row(r, stage_idx))
    lines.append(f"- paper: {VERSION}")
    return "\n".join(lines)

def candidate_summary_text() -> str:
    rows = read_jsonl_tail(FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 300)
    fresh = [r for r in rows if isinstance(r, dict) and candidate_is_fresh(r, load_control())]
    cnt=Counter()
    reasons=Counter()
    for r in fresh:
        st=str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
        if st not in {"S1","S2","S3","X"}: st="-"
        cnt[st]+=1
        reason = _v514_first_text(r, ("s1_block_reason","final_block_reason","block_reason","reason","risk_tags","stale_reasons","missing_reason","missing_info"), limit=40)
        if reason:
            reasons[reason]+=1
    lines=["🧭 후보요약 현재 보기 /candidate_summary", f"- latest {len(rows)} / fresh {len(fresh)} / S1 {cnt.get('S1',0)} / S2 {cnt.get('S2',0)} / S3 {cnt.get('S3',0)} / 제외 {cnt.get('X',0)}"]
    if reasons:
        top = " / ".join(f"{k} {v}" for k,v in reasons.most_common(5))
        lines.append("- 못 올라온 이유 TOP: "+top)
    show=sorted(fresh, key=lambda r:fnum(r.get("score"), r.get("candidate_score"), default=0.0), reverse=True)[:5]
    if show:
        lines.append("[상위 후보]")
    for r in show:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol")) or "-"
        st=str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
        strat=str(r.get("strategy_label") or r.get("strategy_key") or r.get("strategy") or "-")
        reason=_v514_first_text(r, ("s1_block_reason","final_block_reason","block_reason","reason","risk_tags","stale_reasons","missing_reason","missing_info"), limit=46) or "-"
        lines.append(f"- {t} · {st} · {strat} · 이유 {reason}")
    return "\n".join(lines)

def paper_hourly_text() -> str:
    return "\n\n".join([pstatus_text(), hot_summary_text(), candidate_summary_text()])

def handle_command(cmd: str) -> str:
    c = cmd.strip().split()[0].lower()
    if c in {"/pstatus", "/status"}:
        return pstatus_text()
    if c in {"/popen", "/open"}:
        return popen_text()
    if c in {"/perror", "/error"}:
        return perror_text()
    if c in {"/plog", "/log"}:
        return plog_text()
    if c in {"/pbatch", "/batch"}:
        return "\n\n".join([pstatus_text(), popen_text(), perror_text()])
    if c in {"/hot_summary", "/hot", "/phot"}:
        return hot_summary_text()
    if c in {"/candidate_summary", "/candidate", "/pcandidate"}:
        return candidate_summary_text()
    if c in {"/paper_hourly", "/hourly", "/phourly"}:
        return paper_hourly_text()
    if c in {"/pversion", "/version"}:
        return f"{VERSION} / {BUILD_LABEL}"
    if c in {"/ponce"}:
        st = run_cycle()
        return f"✅ run once: opened {st.get('opened_this_cycle')} closed {st.get('closed_this_cycle')} elapsed {st.get('elapsed_sec')}s"
    return "명령: /pstatus /popen /hot_summary /candidate_summary /paper_hourly /perror /plog /pbatch /pversion /ponce"


def poll_telegram_once() -> None:
    global _TG_OFFSET
    if not TOKEN or not ALLOWED_CHAT_ID:
        return
    try:
        params = urllib.parse.urlencode({"timeout": 0, "offset": _TG_OFFSET + 1})
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/getUpdates?{params}")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        for upd in data.get("result", []) if isinstance(data, dict) else []:
            _TG_OFFSET = max(_TG_OFFSET, int(upd.get("update_id") or 0))
            msg = upd.get("message") or upd.get("edited_message") or {}
            chat = msg.get("chat") or {}
            chat_id = str(chat.get("id") or "")
            text = str(msg.get("text") or "")
            if not text.startswith("/"):
                continue
            if ALLOWED_CHAT_ID and chat_id != str(ALLOWED_CHAT_ID):
                continue
            ans = handle_command(text)
            old_notify = globals().get("NOTIFY_CHAT_ID")
            try:
                globals()["NOTIFY_CHAT_ID"] = chat_id
                send_message(ans)
            finally:
                globals()["NOTIFY_CHAT_ID"] = old_notify
    except Exception as exc:
        log_error("poll_telegram_once", exc)


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP, _STOP_REASON
    _STOP = True
    _STOP_REASON = f"signal_{signum}"
    try:
        st = dict(_LAST_STATUS) if _LAST_STATUS else {}
        st.update({
            "version": VERSION,
            "running": False,
            "process_alive": False,
            "stop_reason": _STOP_REASON,
            "updated_at": nowv,
            "updated_at_text": iso_ts(),
            "open_count": len(load_open()),
        })
        save_json(FILES["status"], st)
        log(f"stop requested: {_STOP_REASON}")
    except Exception:
        pass


def _v682_exit_sweep(ctrl: Optional[Dict[str, Any]] = None, owner: str = 'v682_open_exit_priority_sweep') -> Dict[str, Any]:
    """OPEN 청산 우선 루프.

    전체시장 후보선별/리뷰/알림 작업과 별개로 현재 OPEN만 빠르게 검사한다.
    손절/청산 기준값은 바꾸지 않고, 기존 update_position 한곳만 호출한다.
    """
    started = now_ts()
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    open_pos = load_open()
    closed_items: List[Dict[str, Any]] = []
    checked = 0
    if not open_pos:
        return {'schema': 'paper_exit_sweep_v682', 'owner': owner, 'open_count': 0, 'checked': 0, 'closed': 0, 'elapsed_sec': 0.0}
    for pid, pos in list(open_pos.items()):
        checked += 1
        try:
            updated, closed = update_position(pos, ctrl)
            if closed:
                closed['exit_sweep_owner_v682'] = owner
                closed_items.append(closed)
                open_pos.pop(pid, None)
                append_jsonl(FILES['closed'], closed)
                _LAST_CLOSED_COUNT_CACHE.update({'ts': 0.0, 'count': 0})
            else:
                open_pos[pid] = updated
        except Exception as exc:
            log_error('v682_exit_sweep_update', exc)
    save_open(open_pos)
    for row in closed_items:
        try:
            notify_closed(row)
        except Exception as exc:
            log_error('v682_exit_sweep_notify_closed', exc)
            try:
                _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'v682 exit sweep notify_closed raised')
            except Exception:
                pass
    status = {
        'schema': 'paper_exit_sweep_v682',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'running': bool(ctrl.get('running', True)),
        'owner': owner,
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'checked': checked,
        'closed_this_sweep': len(closed_items),
        'closed_total': line_count_cached(FILES['closed'], ttl=0 if closed_items else 60.0),
        'elapsed_sec': round(now_ts() - started, 3),
        'updated_at': now_ts(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'policy': 'OPEN 청산은 전체시장/strategy/review보다 우선한다. 조건값 변경 없음.',
    }
    try:
        if ctrl.get('write_score_cache', True) and closed_items:
            write_score_cache(status)
    except Exception as exc:
        log_error('v682_exit_sweep_write_score_cache', exc)
    try:
        prev = load_json(FILES['status'], {}) or {}
        if isinstance(prev, dict):
            prev.update(status)
            prev['last_exit_sweep'] = status
            write_status(prev)
        else:
            write_status(status)
    except Exception as exc:
        log_error('v682_exit_sweep_status', exc)
    return status


def main() -> None:
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    startup_status = {
        "running": True,
        "startup_status": True,
        "open_count": len(load_open()),
        "open_total": len(load_open()),
        "closed_total": line_count_cached(FILES["closed"], ttl=0),
        "engine": "light_runner",
        "legacy_loop": False,
    }
    write_score_cache(startup_status)
    write_status(startup_status)
    log(f"{VERSION} started pid={os.getpid()} build={BUILD_LABEL} token={'yes' if TOKEN else 'no'} chat={'yes' if ALLOWED_CHAT_ID else 'no'}")
    last_cycle = 0.0
    last_poll = 0.0
    last_exit_sweep = 0.0
    while not _STOP:
        try:
            ctrl = load_control()
            loop_sec = max(2.0, fnum(ctrl.get("loop_seconds"), default=8.0))
            sweep_sec = max(0.5, fnum(ctrl.get("open_monitor_interval_sec"), default=1.0))
            if now_ts() - last_exit_sweep >= sweep_sec:
                _v682_exit_sweep(ctrl, owner='v701_main_open_exit_priority')
                last_exit_sweep = now_ts()
            if now_ts() - last_cycle >= loop_sec:
                run_cycle()
                last_cycle = now_ts()
            elif now_ts() - fnum(_LAST_STATUS.get("updated_at"), default=0.0) >= 10:
                hb = dict(_LAST_STATUS)
                hb.update({"heartbeat": True})
                write_status(hb)
            if now_ts() - last_poll >= 3.0:
                poll_telegram_once()
                last_poll = now_ts()
        except Exception as exc:
            log_error("main_loop", exc)
            write_status({"running": True, "last_error": f"{type(exc).__name__}: {exc}", "engine": "light_runner"})
        time.sleep(0.5)
    log(f"{VERSION} stopped reason={_STOP_REASON}")


# =============================================================================
# paper_bot v0.157 / v500: OPEN exit_plan 봉인 + 전략별 표시
# - 청산조건 숫자를 바꾸지 않고, 현재 control 기준을 entry_price 기준 가격표로 저장/알림한다.
# - 급등 진행형/눌림 재가속도 같은 paper 장부를 쓰고 strategy_key로만 분리한다.
# =============================================================================


def _v500_price_by_pct(entry: float, pct: float) -> float:
    try:
        return float(entry) * (1.0 + float(pct) / 100.0)
    except Exception:
        return 0.0


def _v500_build_exit_plan(pos: Dict[str, Any], ctrl: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    entry = fnum(pos.get('entry_price'), default=0.0)
    tp = fnum(ctrl.get('take_profit_pct'), default=1.20)
    strong_tp = max(tp, fnum(ctrl.get('protect_big_trigger_pct'), default=1.40))
    stop = fnum(ctrl.get('stop_loss_pct'), default=-0.55)
    protect_tr = fnum(ctrl.get('protect_trigger_pct'), default=0.70)
    protect_floor = fnum(ctrl.get('protect_floor_pct'), default=0.35)
    fast_min = fnum(ctrl.get('fast_fail_after_min'), default=2.5)
    fast_peak = fnum(ctrl.get('fast_fail_peak_under_pct'), default=0.20)
    fast_loss = fnum(ctrl.get('fast_fail_loss_pct'), default=-0.35)
    time_exit = fnum(ctrl.get('time_exit_minutes'), default=15.0)
    strat = str(pos.get('strategy_key') or pos.get('strategy') or '')
    # 급등 진행형은 기존 청산조건을 바꾸지 않는다. 다만 plan 설명에서 빠른 증명 필요를 표시한다.
    style = '급등 진행형: 초반 증명 필수' if 'spike_momentum_ride' in strat else ('급등 눌림재가속: 재가속 유지 확인' if 'spike_pullback_reaccel' in strat else '기존 paper 청산 기준')
    return {
        'schema': 'paper_exit_plan_v500', 'paper_version': VERSION, 'created_at': now_ts(), 'created_at_text': iso_ts(),
        'strategy_key': strat, 'strategy_label': pos.get('strategy_label') or pos.get('strategy') or '-', 'plan_style': style,
        'entry_price': entry,
        'take_profit_pct': tp, 'take_profit_price': _v500_price_by_pct(entry, tp),
        'strong_target_pct': strong_tp, 'strong_target_price': _v500_price_by_pct(entry, strong_tp),
        'stop_loss_pct': stop, 'stop_loss_price': _v500_price_by_pct(entry, stop),
        'protect_trigger_pct': protect_tr, 'protect_trigger_price': _v500_price_by_pct(entry, protect_tr),
        'protect_floor_pct': protect_floor, 'protect_floor_price': _v500_price_by_pct(entry, protect_floor),
        'fast_fail_after_min': fast_min, 'fast_fail_peak_under_pct': fast_peak, 'fast_fail_loss_pct': fast_loss,
        'time_exit_minutes': time_exit,
        'fee_pct_roundtrip': fnum(ctrl.get('fee_pct_roundtrip'), default=0.10),
        'note': '청산조건 변경 아님. OPEN 시점에 기존 기준을 가격표로 봉인한 복기용 계획.',
    }


def _v500_exit_plan_open_lines(plan: Any, prefix: str='- ') -> List[str]:
    if not isinstance(plan, dict) or not plan:
        return [prefix + '진입계획: exit_plan 없음']
    return [
        prefix + '진입계획: ' + str(plan.get('plan_style') or '-'),
        prefix + f"목표가: 1차 {fmt_price(plan.get('take_profit_price'))}({fnum(plan.get('take_profit_pct'), default=0.0):+.2f}%) / 강한흐름 {fmt_price(plan.get('strong_target_price'))}({fnum(plan.get('strong_target_pct'), default=0.0):+.2f}%)",
        prefix + f"손절가: {fmt_price(plan.get('stop_loss_price'))}({fnum(plan.get('stop_loss_pct'), default=0.0):+.2f}%)",
        prefix + f"보호익절: 발동 {fmt_price(plan.get('protect_trigger_price'))}({fnum(plan.get('protect_trigger_pct'), default=0.0):+.2f}%) → 방어 {fmt_price(plan.get('protect_floor_price'))}({fnum(plan.get('protect_floor_pct'), default=0.0):+.2f}%)",
        prefix + f"빠른실패: {fnum(plan.get('fast_fail_after_min'), default=0.0):.1f}분 뒤 최고<{fnum(plan.get('fast_fail_peak_under_pct'), default=0.0):+.2f}% & 현재≤{fnum(plan.get('fast_fail_loss_pct'), default=0.0):+.2f}%",
        prefix + f"시간청산: {fnum(plan.get('time_exit_minutes'), default=0.0):.0f}분 / 수수료왕복 {fnum(plan.get('fee_pct_roundtrip'), default=0.0):.2f}% 반영",
    ]


def _v500_exit_plan_result_lines(row: Dict[str, Any], prefix: str='- ') -> List[str]:
    plan = row.get('exit_plan') if isinstance(row.get('exit_plan'), dict) else {}
    if not plan:
        return [prefix + '계획대비: exit_plan 없음']
    peak = fnum(row.get('peak_pct'), default=0.0); pnl = fnum(row.get('pnl_pct'), default=0.0)
    tp = fnum(plan.get('take_profit_pct'), default=0.0); ptr = fnum(plan.get('protect_trigger_pct'), default=0.0)
    stop = fnum(plan.get('stop_loss_pct'), default=0.0)
    res = []
    res.append(prefix + f"계획대비: 목표 {'도달' if peak >= tp else '미도달'} / 보호익절 {'발동권' if peak >= ptr else '미발동'} / 손절선 {'도달' if pnl <= stop else '전 종료'}")
    res.append(prefix + f"계획가격: 목표 {fmt_price(plan.get('take_profit_price'))} / 손절 {fmt_price(plan.get('stop_loss_price'))} / 보호 {fmt_price(plan.get('protect_trigger_price'))}→{fmt_price(plan.get('protect_floor_price'))}")
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    levels = diag.get('structure_levels') if isinstance(diag.get('structure_levels'), dict) else row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    if levels and levels.get('available', True):
        t1p = fnum(levels.get('expected_upside_pct'), default=0.0)
        res.append(prefix + f"구조목표: 1차 {fmt_price(levels.get('target1_price'))}({t1p:+.2f}%) / 무효 {fmt_price(levels.get('invalid_price'))} / RR {fnum(levels.get('rr_ratio'), default=0.0):.2f}")
    return res


_v500_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v500_prev_open_position(pos_id, ev)
    try:
        plan = _v500_build_exit_plan(pos, load_control())
        pos['exit_plan'] = plan
        pos['exit_plan_schema'] = plan.get('schema')
        # strategy_key가 비어 있는 구 row도 알림/성과 구분 가능하게 보강한다.
        if not pos.get('strategy_key'):
            pos['strategy_key'] = pos.get('strategy') or (ev.get('strategy_key') if isinstance(ev, dict) else '') or 'unknown'
        if not pos.get('strategy_label'):
            pos['strategy_label'] = ev.get('strategy_label') if isinstance(ev, dict) else pos.get('strategy_key')
    except Exception as exc:
        log_error('v500_exit_plan_open_position', exc)
    return pos


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ""
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(pos.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    plan_lines = "\n".join(_v500_exit_plan_open_lines(pos.get('exit_plan')))
    send_message(
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy_key') or pos.get('strategy') or '-'}\n"
        f"{plan_lines}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker'))
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    result_lines = "\n".join(_v500_exit_plan_result_lines(row))
    send_message(
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{result_lines}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-'}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )



# =============================================================================
# paper_bot v0.158 / v503: OPEN→CLOSED context 봉인 보강
# - 청산조건/장부 삭제 없음.
# - strategy_key, structure/risk tags, spike late-entry guard, timing trace를 OPEN row에 고정해
#   CLOSED/version_score에서 구조 '-' 또는 위험 '-'로 빠지는 문제를 줄인다.
# =============================================================================


def _v503_list_any(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, dict):
        return [f"{k}:{val}" for k, val in list(v.items())[:8]]
    if isinstance(v, str) and v.strip():
        return [x.strip() for x in re.split(r"[/,|]", v) if x.strip()] or [v.strip()]
    return []


def _v503_sources(ev: Dict[str, Any], pos: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for obj in (ev, pos, ev.get('entry_context') if isinstance(ev, dict) else None, ev.get('strategy_context') if isinstance(ev, dict) else None, ev.get('canonical_entry_decision') if isinstance(ev, dict) else None, ev.get('metrics') if isinstance(ev, dict) else None, ev.get('raw') if isinstance(ev, dict) else None):
        if isinstance(obj, dict):
            out.append(obj)
            for sub in ('entry_context','strategy_context','metrics','structure','feature','orderflow','micro','canonical_entry_decision','spike_late_entry_guard','late_entry_guard'):
                vv = obj.get(sub)
                if isinstance(vv, dict):
                    out.append(vv)
    return out


def _v503_first_from_sources(sources: List[Dict[str, Any]], keys: Iterable[str], default: Any = None) -> Any:
    for src in sources:
        for k in keys:
            if k in src and src.get(k) not in (None, '', [], {}):
                return src.get(k)
    return default


def _v503_collect_context(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    srcs = _v503_sources(ev, pos)
    tags: List[str] = []
    risks: List[str] = []
    for src in srcs:
        for k in ('structure_tags','structure_good_tags','matched_strategies','strategy_tags','tags'):
            tags.extend(_v503_list_any(src.get(k)))
        for k in ('structure_risk_tags','risk_tags','entry_missing_info','missing_info','spike_guard_reasons'):
            risks.extend(_v503_list_any(src.get(k)))
    seen=set(); tags=[x for x in tags if not (x in seen or seen.add(x))][:8]
    seen=set(); risks=[x for x in risks if not (x in seen or seen.add(x))][:8]
    guard = _v503_first_from_sources(srcs, ('spike_late_entry_guard','late_entry_guard'), {})
    if not isinstance(guard, dict):
        guard = {}
    strat_key = _v503_first_from_sources(srcs, ('strategy_key','paper_strategy_key','strategy','route','section'), pos.get('strategy_key') or 'unknown')
    strat_label = _v503_first_from_sources(srcs, ('strategy_label','paper_strategy_label','final_entry_label'), pos.get('strategy_label') or strat_key)
    ctx = {
        'schema': 'paper_entry_context_v503',
        'strategy_key': strat_key,
        'strategy_label': strat_label,
        'structure_tags': tags,
        'structure_risk_tags': risks,
        'risk_tags': risks,
        'spike_late_entry_guard': guard,
        'spike_guard_reasons': guard.get('reasons') or [],
        'drawdown_from_high_pct': _v503_first_from_sources(srcs, ('drawdown_from_high_pct','pullback_from_high_pct'), None),
        'recent_high_price': _v503_first_from_sources(srcs, ('recent_high_price','high_price'), None),
        'hot_signal_age_sec': _v503_first_from_sources(srcs, ('hot_signal_age_sec','spike_signal_age_sec','signal_age_sec'), None),
        'price_reaction_pct': _v503_first_from_sources(srcs, ('price_reaction_pct','reaction_pct','price_recheck_pct'), None),
        'buy_ratio': _v503_first_from_sources(srcs, ('buy_ratio','buy_trade_ratio','micro_buy_ratio'), None),
        'buy_sustain_1m': _v503_first_from_sources(srcs, ('buy_sustain_1m','buy_ratio_1m','micro_buy_ratio_sustain_1m'), None),
        'spread_pct': _v503_first_from_sources(srcs, ('spread_pct','micro_spread_pct','orderbook_spread_pct'), None),
        'slippage_pct': _v503_first_from_sources(srcs, ('slippage_pct','expected_slippage_pct','slippage_est_pct'), None),
        'structure_levels': _v503_first_from_sources(srcs, ('structure_levels',), {}),
        'entry_plan': _v503_first_from_sources(srcs, ('entry_plan',), {}),
        'risk_reward': _v503_first_from_sources(srcs, ('risk_reward',), {}),
        'entry_timing_spine': _v503_first_from_sources(srcs, ('entry_timing_spine',), {}),
        'late_chase_flag': _v503_first_from_sources(srcs, ('late_chase_flag',), False),
    }
    return ctx


_v503_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v503_prev_open_position(pos_id, ev)
    try:
        ctx = _v503_collect_context(ev, pos)
        pos['paper_entry_context_v503'] = ctx
        pos['strategy_key'] = ctx.get('strategy_key') or pos.get('strategy_key') or 'unknown'
        pos['strategy_label'] = ctx.get('strategy_label') or pos.get('strategy_label') or pos.get('strategy_key')
        for key in ('structure_tags','structure_risk_tags','risk_tags','spike_late_entry_guard','spike_guard_reasons','drawdown_from_high_pct','recent_high_price','hot_signal_age_sec','structure_levels','entry_plan','risk_reward','entry_timing_spine','late_chase_flag'):
            if ctx.get(key) not in (None, '', [], {}):
                pos[key] = ctx.get(key)
        # 기존 entry_context/diagnostics에도 복기 key를 병합해 version_score 요약에서 '-'로 빠지지 않게 한다.
        ec = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
        ec.update({k: v for k, v in ctx.items() if v not in (None, '', [], {})})
        pos['entry_context'] = ec
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag.setdefault('strategy_key', ctx.get('strategy_key'))
        diag.setdefault('strategy_label', ctx.get('strategy_label'))
        diag.setdefault('matched_strategies', ctx.get('structure_tags') or [])
        for _k in ('structure_levels','entry_plan','risk_reward','entry_timing_spine','late_chase_flag'):
            if ctx.get(_k) not in (None, '', [], {}):
                diag[_k] = ctx.get(_k)
        diag.setdefault('missing_info', ctx.get('risk_tags') or [])
        for k in ('price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct'):
            if ctx.get(k) is not None:
                diag[k] = ctx.get(k)
        if ctx.get('spike_guard_reasons'):
            diag['spike_guard_reasons'] = ctx.get('spike_guard_reasons')
        pos['entry_diagnostics'] = diag
        if isinstance(pos.get('exit_plan'), dict):
            pos['exit_plan']['strategy_key'] = pos.get('strategy_key')
            pos['exit_plan']['strategy_label'] = pos.get('strategy_label')
            pos['exit_plan']['hot_signal_age_sec'] = ctx.get('hot_signal_age_sec')
            pos['exit_plan']['spike_guard_reasons'] = ctx.get('spike_guard_reasons') or []
    except Exception as exc:
        log_error('v503_entry_context_seal', exc)
    return pos


def _v503_context_lines(row: Dict[str, Any], prefix: str='- ') -> List[str]:
    ctx = row.get('paper_entry_context_v503') if isinstance(row.get('paper_entry_context_v503'), dict) else {}
    if not ctx:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    out: List[str] = []
    tags = _v503_list_any(row.get('structure_tags') or ctx.get('structure_tags'))
    risks = _v503_list_any(row.get('risk_tags') or row.get('structure_risk_tags') or ctx.get('risk_tags') or ctx.get('structure_risk_tags'))
    if tags:
        out.append(prefix + '구조태그: ' + ' / '.join(tags[:5]))
    if risks:
        out.append(prefix + '위험태그: ' + ' / '.join(risks[:5]))
    guard = row.get('spike_late_entry_guard') if isinstance(row.get('spike_late_entry_guard'), dict) else ctx.get('spike_late_entry_guard') if isinstance(ctx.get('spike_late_entry_guard'), dict) else {}
    if isinstance(guard, dict) and guard:
        rs = guard.get('reasons') or []
        dd = guard.get('drawdown_from_high_pct')
        if rs or dd not in (None, ''):
            out.append(prefix + '급등진입검사: ' + (' / '.join(str(x) for x in rs[:3]) if rs else f'고점대비 {fnum(dd, default=0.0):+.2f}%'))
    return out[:4]


_v503_prev_notify_opened = notify_opened

def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    # v500 알림을 유지하되 context가 비면 아래 줄은 생략된다.
    _v503_prev_notify_opened(pos)


_v503_prev_notify_closed = notify_closed

def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    # v500 CLOSED 알림은 유지. context는 row/score cache에 봉인되어 /version_score에서도 확인 가능.
    _v503_prev_notify_closed(row)


# =============================================================================
# paper_bot v0.159 / v504: 급등 urgent timing 봉인
# - OPEN row에 hot/micro/orderflow/price age와 paper_read_delay를 보존한다.
# - 알림 포맷은 v500 exit_plan을 그대로 쓰고, entry_timing_trace에 값이 들어가게 한다.
# =============================================================================


def _v504_first(src: Dict[str, Any], keys: tuple, default=None):
    if not isinstance(src, dict):
        return default
    for k in keys:
        v = src.get(k)
        if v not in (None, '', [], {}):
            return v
    return default


def _v504_build_timing_from_event(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    ec = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    timing = ev.get('entry_timing_trace') if isinstance(ev.get('entry_timing_trace'), dict) else ec.get('entry_timing_trace') if isinstance(ec.get('entry_timing_trace'), dict) else {}
    urgent = ev.get('urgent_timing_trace_v504') if isinstance(ev.get('urgent_timing_trace_v504'), dict) else ec.get('urgent_timing_trace_v504') if isinstance(ec.get('urgent_timing_trace_v504'), dict) else {}
    out = dict(timing) if isinstance(timing, dict) else {}
    out.setdefault('schema', 'paper_entry_timing_trace_v504')
    for k in ('hot_signal_age_sec','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','quote_age_sec'):
        v = _v504_first(urgent, (k,), _v504_first(ev, (k,), _v504_first(ec, (k,), None)))
        if v not in (None, ''):
            out[k] = v
    nowv = now_ts()
    source_ts = fnum(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('source_created_at'), ec.get('strategy_decision_ts'), default=0.0)
    if source_ts > 1000000000:
        out['paper_read_delay_sec'] = round(max(0.0, nowv - source_ts), 3)
    dec_ts = fnum(ec.get('strategy_decision_ts'), out.get('strategy_decision_ts'), default=0.0)
    if dec_ts > 1000000000:
        out['strategy_to_paper_delay_sec'] = round(max(0.0, nowv - dec_ts), 3)
    stale = []
    for k, label, lim in (('hot_signal_age_sec','hot',45),('micro_age_sec','micro',5),('orderflow_age_sec','orderflow',5),('price_reaction_age_sec','price',10),('paper_read_delay_sec','paper',5)):
        vv = fnum(out.get(k), default=-1.0)
        if vv >= 0 and vv > lim:
            stale.append(f'{label} {vv:.1f}s')
    out['stale_reasons'] = stale[:8]
    out['fresh_for_spike_momentum'] = len(stale) == 0
    return out


def _v529_copy_s1_context(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(ev, dict) or not isinstance(pos, dict):
        return pos
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    keys = (
        'canonical_lane','matched_strategy_keys','matched_strategy_labels',
        's1_checklist','s1_passed_conditions','s1_missing_conditions','s1_missing_names',
        's1_block_count','s1_block_score','s1_distance','s1_near_miss','s1_near_miss_level','s1_short_reason','common_entry_pass','common_entry_schema','strategy_role','entry_profile','exit_profile','profile_family','profile_decisions','canonical_entry_decision','common_entry_decision',
        'price_chg_10s','price_chg_20s','price_chg_30s','price_chg_60s','price_accel_10s','buy_ratio_10s','buy_sustain_20s','spread_widening_10s',
        'buy_sustain_1m_source','buy_sustain_1m_real','buy_sustain_1m_is_fallback','fresh_gate_ok',
        'structure_levels','entry_plan','risk_reward','entry_timing_spine','late_chase_flag','late_chase_basis'
    )
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    for k in keys:
        val = ev.get(k) if ev.get(k) not in (None, '', [], {}) else ctx.get(k)
        if val not in (None, '', [], {}):
            pos[k] = val
            diag[k] = val
    gate = ev.get('v510_final_entry_gate') or ctx.get('v510_final_entry_gate') or ev.get('v508_final_entry_gate') or ctx.get('v508_final_entry_gate')
    if isinstance(gate, dict):
        pos['v510_final_entry_gate'] = gate
        diag['v510_final_entry_gate'] = gate
        pos['paper_entry_gate_schema'] = 'v529_v510_final_entry_gate'
    pos['entry_diagnostics'] = diag
    pos['paper_s1_diagnostic_schema'] = 'paper_s1_context_v529_inline'
    return pos

_v504_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v504_prev_open_position(pos_id, ev)
    try:
        timing = _v504_build_timing_from_event(ev, pos)
        pos['entry_timing_trace'] = timing
        pos['urgent_timing_trace_v504'] = timing
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag['entry_timing_trace'] = timing
        for k in ('hot_signal_age_sec','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','quote_age_sec','paper_read_delay_sec','strategy_to_paper_delay_sec'):
            if timing.get(k) not in (None, ''):
                pos[k] = timing.get(k)
                diag[k] = timing.get(k)
        if timing.get('stale_reasons'):
            diag['urgent_stale_reasons_v504'] = timing.get('stale_reasons')
            pos['urgent_stale_reasons_v504'] = timing.get('stale_reasons')
        pos['entry_diagnostics'] = diag
        if isinstance(pos.get('exit_plan'), dict):
            pos['exit_plan']['entry_timing_trace'] = timing
            pos['exit_plan']['paper_read_delay_sec'] = timing.get('paper_read_delay_sec')
    except Exception as exc:
        log_error('v504_entry_timing_seal', exc)
    try:
        pos = _v529_copy_s1_context(ev, pos)
    except Exception as exc:
        log_error('v529_s1_context_seal', exc)
    return pos

# v504: notify_opened/closed는 v500/v503 포맷을 그대로 사용한다. entry_timing_trace에 값만 보강한다.

# =============================================================================
# paper_bot v0.160 / v505: CLOSED score context source widening
# - OPEN/CLOSED already works. This only makes version_score/recent CLOSED summaries
#   read the sealed paper_entry_context/exit_plan/timing fields so structure/risk
#   does not fall back to '-'.
# =============================================================================

_v505_prev_entry_source = _v463_entry_source

def _v463_entry_source(row: Dict[str, Any]) -> List[Dict[str, Any]]:  # type: ignore[override]
    out: List[Dict[str, Any]] = []
    try:
        for key in (
            'paper_entry_context_v503', 'entry_context', 'entry_diagnostics', 'entry_timing_trace',
            'exit_plan', 'raw', 'source_event', 'meta', 'metadata'
        ):
            obj = row.get(key)
            if isinstance(obj, dict):
                out.append(obj)
                for sub in ('paper_entry_context_v503','entry_context','entry_diagnostics','canonical_entry_decision','metrics','structure','feature','orderflow','micro','spike_late_entry_guard','urgent_timing_trace_v504','structure_levels','entry_plan','risk_reward','entry_timing_spine'):
                    vv = obj.get(sub)
                    if isinstance(vv, dict):
                        out.append(vv)
        out.extend(_v505_prev_entry_source(row))
    except Exception:
        try:
            out.extend(_v505_prev_entry_source(row))
        except Exception:
            pass
    dedup: List[Dict[str, Any]] = []
    seen: set[int] = set()
    for obj in out:
        if isinstance(obj, dict) and id(obj) not in seen:
            seen.add(id(obj)); dedup.append(obj)
    return dedup

_v505_prev_entry_summary = _v463_entry_summary

def _v463_entry_summary(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    sm = _v505_prev_entry_summary(row)
    try:
        tags = list(sm.get('structure_tags') or [])
        risks = list(sm.get('risk_tags') or [])
        srcs = _v463_entry_source(row)
        for src in srcs:
            for k in ('structure_tags','structure_good_tags','matched_strategies','strategy_tags','tags'):
                tags.extend(_v463_as_list(src.get(k)))
            for k in ('structure_risk_tags','risk_tags','spike_guard_reasons','urgent_stale_reasons_v504','entry_missing_info','missing_info'):
                risks.extend(_v463_as_list(src.get(k)))
        if not tags:
            label = row.get('strategy_label') or row.get('paper_strategy_label') or row.get('strategy') or row.get('strategy_key')
            sk = str(row.get('strategy_key') or row.get('strategy') or '')
            if label and ('spike' in sk or '급등' in str(label)):
                tags.append(str(label))
        seen=set(); tags=[x for x in tags if str(x).strip() and not (x in seen or seen.add(x))][:5]
        seen=set(); risks=[x for x in risks if str(x).strip() and not (x in seen or seen.add(x))][:5]
        sm['structure_tags'] = tags
        sm['risk_tags'] = risks
    except Exception:
        pass
    return sm



# =============================================================================
# paper_bot v0.162 / v509: canonical latest only + hard pre-open freshness gate
# - Deletes legacy consumer sources from the runtime OPEN path.
#   Runtime OPEN reads only paper_candidates_latest.jsonl.
# - Paper opens only rows from paper_candidates_latest.jsonl that carry the canonical
#   final gate and pass fresh/open_eligible checks.
# =============================================================================


def _v508_num(*vals: Any, default: float = 999999.0) -> float:
    for v in vals:
        try:
            if v is None or v == "" or v == [] or v == {}:
                continue
            return float(v)
        except Exception:
            continue
    return default


def _v508_srcs(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    def add(v: Any):
        if isinstance(v, dict): out.append(v)
    add(ev)
    for k in ("entry_context", "canonical_entry_decision", "entry_snapshot", "entry_timing_trace", "urgent_timing_trace_v508", "urgent_timing_trace_v504", "v510_final_entry_gate", "v508_final_entry_gate", "v507_final_entry_gate", "paper_final_safety_diagnostics", "raw"):
        add((ev or {}).get(k))
    ctx = (ev or {}).get("entry_context") if isinstance((ev or {}).get("entry_context"), dict) else {}
    for k in ("urgent_timing_trace_v508", "urgent_timing_trace_v504", "entry_timing_trace", "v510_final_entry_gate", "v508_final_entry_gate", "v507_final_entry_gate"):
        add(ctx.get(k))
    for src in list(out):
        add(src.get("age_values"))
    seen=set(); clean=[]
    for d in out:
        if id(d) not in seen:
            seen.add(id(d)); clean.append(d)
    return clean


def _v508_first(ev: Dict[str, Any], keys: Tuple[str, ...], default: float = 999999.0) -> float:
    for src in _v508_srcs(ev):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                v = _v508_num(src.get(k), default=default)
                if v != default:
                    return v
    return default


def _v508_strategy_key(ev: Dict[str, Any]) -> str:
    return str(ev.get("strategy_key") or ev.get("paper_strategy_key") or ev.get("strategy") or ev.get("route") or "")


def _v508_is_spike(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    dec = ev.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or ev.get("common_entry_decision") or ctx.get("common_entry_decision")
    if not isinstance(dec, dict):
        dec = {}
    p = str(ev.get("entry_profile") or ctx.get("entry_profile") or dec.get("entry_profile") or "").strip()
    if p in {"spike", "spike_fast_early", "spike_runner"}:
        return True
    sk = _v508_strategy_key(ev)
    label = str(ev.get("strategy_label") or ev.get("strategy") or "")
    return sk in {"spike_momentum_ride", "spike_pullback_reaccel"} or "급등" in label or "spike" in sk


def _v508_age_reasons(ev: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, float]]:
    nowv = now_ts()
    hot = _v508_first(ev, ("hot_signal_age_sec", "signal_age_sec", "hot"))
    micro = _v508_first(ev, ("micro_age_sec", "trade_age_sec", "micro", "trade"))
    orderflow = _v508_first(ev, ("orderflow_age_sec", "orderflow", "trade_age_sec", "micro_age_sec"), default=micro)
    price = _v508_first(ev, ("price_reaction_age_sec", "price_age_sec", "feature_age_sec", "price", "reaction_age_sec"))
    quote = _v508_first(ev, ("quote_age_sec", "ws_age_sec", "quote", "ws"))
    # paper delay is computed from the row creation timestamp.
    src_ts = event_created_ts(ev)
    paper_delay = max(0.0, nowv - src_ts) if src_ts > 0 else 999999.0
    ages = {"hot": hot, "micro": micro, "orderflow": orderflow, "price": price, "quote": quote, "paper": paper_delay}
    stale: List[str] = []
    if _v508_is_spike(ev):
        if hot > 45.0: stale.append(f"hot {hot:.1f}s")
        if micro > 5.0: stale.append(f"micro {micro:.1f}s")
        if orderflow > 5.0: stale.append(f"orderflow {orderflow:.1f}s")
        if price > 10.0: stale.append(f"price {price:.1f}s")
        if quote > 5.0: stale.append(f"quote {quote:.1f}s")
        if paper_delay > 20.0: stale.append(f"paper {paper_delay:.1f}s")
    else:
        if price >= 999998.0: stale.append("price_age_missing")
        elif price > 30.0: stale.append(f"price {price:.1f}s")
        if micro >= 999998.0: stale.append("micro_age_missing")
        elif micro > 20.0: stale.append(f"micro {micro:.1f}s")
        if paper_delay > 45.0: stale.append(f"paper {paper_delay:.1f}s")
    return len(stale) == 0, stale, ages


# v532: is_s1_candidate/paper_final_safety tail overrides removed; main bodies read canonical_entry_decision.



# =============================================================================
# v540/paper v0.176: 전략명 canonical score cache producer
# - 장부/OPEN/CLOSED/청산조건은 변경하지 않는다.
# - score cache 집계 key만 같은 전략의 구영문키/한글명/S suffix를 canonical 한글명으로 묶는다.
# =============================================================================

def _v540_clean_strategy_raw(raw: Any) -> str:
    s = str(raw or "").strip()
    if not s or s in {"-", "None", "null", "unknown"}:
        return ""
    s = s.replace("_KRW", "").replace("KRW-", "")
    s = re.sub(r"\s+", " ", s).strip()
    s = re.sub(r"\s+[SABCX]$", "", s).strip()
    return s


def _v540_strategy_label(raw: Any) -> str:
    s = _v540_clean_strategy_raw(raw)
    if not s:
        return "구버전/미분류"
    low = s.lower()
    if "hot-rank" in low or "hot_rank" in low or "hot rank" in low:
        return "hot-rank 급등 재확인"
    if "surge_rebreak" in low or "급등 후 재돌파" in s:
        return "급등 후 재돌파"
    if "breakout_early" in low or "돌파 초입" in s:
        return "돌파 초입"
    if "leader_flow_adaptive_hold" in low or "주도흐름 유동보유" in s:
        return "주도흐름 유동보유"
    if "leader_momentum" in low or "leader_momentum_continuation" in low or "주도추세" in s or "주도 추세" in s:
        return "주도추세 지속"
    if "sweep_vwap" in low or "저점 vwap" in low or "저점 VWAP" in s:
        return "저점 VWAP 회복"
    if "money_reaccel" in low or "money_flow_reaccel" in low or "pullback_reaccel" in low or "돈흐름 재가속" in s:
        return "돈흐름 재가속"
    if "공통상승조건" in s:
        return "공통상승조건"
    if s in {"구버전/미분류", "미분류"}:
        return "구버전/미분류"
    if any("가" <= ch <= "힣" for ch in s):
        return s
    return "구버전/미분류"


def _v540_strategy_candidates(row: Dict[str, Any]) -> List[Any]:
    out: List[Any] = []
    for k in (
        "strategy_primary", "strategy_bucket_primary", "strategy_bucket_primary_label",
        "primary_strategy_key", "representative_strategy_key", "paper_strategy_key",
        "strategy_key", "strategy_label", "strategy_name", "strategy",
    ):
        v = row.get(k)
        if v not in (None, "", [], {}):
            out.append(v)
    for parent in ("entry_context", "raw", "source_event", "entry_diagnostics"):
        obj = row.get(parent)
        if isinstance(obj, dict):
            for k in (
                "strategy_primary", "strategy_bucket_primary", "strategy_bucket_primary_label",
                "primary_strategy_key", "representative_strategy_key", "paper_strategy_key",
                "strategy_key", "strategy_label", "strategy_name", "strategy",
            ):
                v = obj.get(k)
                if v not in (None, "", [], {}):
                    out.append(v)
    return out


def _strategy_key(row: Dict[str, Any]) -> str:  # type: ignore[override]
    for v in _v540_strategy_candidates(row):
        lab = _v540_strategy_label(v)
        if lab != "구버전/미분류":
            return lab
    return "구버전/미분류"



# =============================================================================
# paper_bot v0.186 / v558: cache heartbeat + OPEN alert trace
# - run_cycle이 정상적으로 도는지 handoff/score/status를 같은 cycle에서 계속 갱신한다.
# - OPEN 알림 누락 의심을 추적하기 위해 OPEN 알림 시도 로그를 별도 JSONL로 남긴다.
# - 장부/조건/청산 기준은 변경하지 않는다.
# =============================================================================
def _v558_append_open_alert_trace(pos: Dict[str, Any], ok: bool, err: str = "") -> None:
    try:
        append_jsonl(FILES.get("open_alert_trace", BASE_DIR / "paper_bot_open_alert_trace.jsonl"), {
            "schema": "paper_open_alert_trace_v558",
            "version": VERSION,
            "ts": now_ts(),
            "ts_text": iso_ts(),
            "ticker": normalize_ticker(pos.get("ticker")),
            "pos_id": pos.get("pos_id") or pos.get("event_id"),
            "opened_at": pos.get("opened_at"),
            "entry_price": pos.get("entry_price"),
            "strategy": pos.get("strategy_label") or pos.get("strategy_key") or pos.get("strategy"),
            "sent_ok": bool(ok),
            "error": str(err or ""),
        })
    except Exception as exc:
        log_error("v558_open_alert_trace", exc)


def _v558_send_message_with_result(text: str) -> bool:
    ok, _err = _v561_send_message_with_result(text)
    return ok


def _v561_send_message_with_result(text: str) -> Tuple[bool, str]:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return False, 'telegram_disabled: TOKEN or NOTIFY_CHAT_ID missing'
    try:
        data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": text[:3900], "disable_web_page_preview": "true"}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data=data)
        urllib.request.urlopen(req, timeout=5).read()
        return True, ''
    except Exception as exc:
        log_error('send_message', exc)
        return False, f"{type(exc).__name__}: {exc}"


def send_message(text: str) -> None:  # type: ignore[override]
    _v561_send_message_with_result(text)


def _v561_open_message_text(pos: Dict[str, Any]) -> str:
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ''
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    timing_line = format_entry_timing_line(pos.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ''
    if timing_line:
        extra = extra + "\n" + timing_line
    return (
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    # OPEN 알림 본문 생성 -> 실제 send 결과 -> open_alert_trace 기록을 한곳에서 처리한다.
    text = _v561_open_message_text(pos)
    ok, err = _v561_send_message_with_result(text)
    _v558_append_open_alert_trace(pos, ok, err)
    if not ok:
        log_error('notify_opened_send_result', Exception(err or 'send_message returned false'))

def _v558_latest_file_count() -> int:
    try:
        p = FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl")
        return len(read_jsonl_tail(p, 1000))
    except Exception:
        return 0






# =============================================================================

# [v582 cleanup] removed stale duplicate writer block.

# paper_bot v0.190 / v562: OPEN 생성과 알림 trace를 같은 거래로 추적
# - OPEN 장부가 생겼는데 알림 trace가 비는 상태를 막기 위해 notify_opened 시작 시점부터 JSONL에 남긴다.
# - notify_on_strict_open 비활성/notify 경로 미도달도 cycle 종료 후 open_without_alert_trace로 남긴다.
# - 조건/S등급/청산/장부는 변경하지 않는다.
# =============================================================================
def _v562_alert_trace_path() -> Path:
    return FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl')


def _v562_append_open_alert_trace(pos: Dict[str, Any], phase: str, ok: bool = False, err: str = '', note: str = '') -> None:
    try:
        append_jsonl(_v562_alert_trace_path(), {
            'schema': 'paper_open_alert_trace_v562',
            'version': VERSION,
            'build': BUILD_LABEL,
            'phase': phase,
            'ts': now_ts(),
            'ts_text': iso_ts(),
            'ticker': normalize_ticker(pos.get('ticker')),
            'pos_id': pos.get('pos_id') or pos.get('event_id'),
            'event_id': pos.get('event_id') or pos.get('pos_id'),
            'opened_at': pos.get('opened_at'),
            'opened_at_text': pos.get('opened_at_text'),
            'entry_price': pos.get('entry_price'),
            'strategy': pos.get('strategy_label') or pos.get('strategy_key') or pos.get('strategy'),
            'candidate_grade': pos.get('candidate_grade'),
            'sent_ok': bool(ok),
            'error': str(err or ''),
            'note': str(note or ''),
        })
    except Exception as exc:
        log_error('v562_open_alert_trace_append', exc)


def _v562_recent_alert_exists(pos: Dict[str, Any], since_ts: float) -> bool:
    try:
        pid = str(pos.get('pos_id') or pos.get('event_id') or '')
        ticker = normalize_ticker(pos.get('ticker'))
        for r in read_jsonl_tail(_v562_alert_trace_path(), 160):
            if not isinstance(r, dict):
                continue
            rts = fnum(r.get('ts'), default=0.0)
            if rts and rts < since_ts - 5:
                continue
            rpid = str(r.get('pos_id') or r.get('event_id') or '')
            rticker = normalize_ticker(r.get('ticker'))
            if pid and rpid == pid:
                return True
            if ticker and rticker == ticker and abs(fnum(r.get('opened_at'), default=0.0) - fnum(pos.get('opened_at'), default=0.0)) <= 5:
                return True
    except Exception as exc:
        log_error('v562_recent_alert_exists', exc)
    return False


# notify_opened 최종 override: 본문 생성 실패/텔레그램 실패도 숨기지 않고 trace에 남긴다.
def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    _v562_append_open_alert_trace(pos, 'attempt_start', False, '', 'OPEN created; alert send started')
    try:
        text = _v561_open_message_text(pos)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v562_append_open_alert_trace(pos, 'message_build_error', False, err, 'OPEN alert text build failed')
        log_error('notify_opened_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v562_append_open_alert_trace(pos, phase, ok, err, 'OPEN alert send result')
    if not ok:
        log_error('notify_opened_send_result', Exception(err or 'send_message returned false'))








# =============================================================================
# paper_bot v0.192 / v565: paper 후보 snapshot 생산부 단일화
# - latest/fresh/S1감지/S1선택/OPEN보류/micro대기는 paper_bot이 후보파일을 읽는 순간 1회 snapshot으로 확정한다.
# - run_cycle 중간 handoff write와 cycle-end heartbeat가 서로 다른 fresh를 쓰는 이중쓰기/race를 제거한다.
# - 출력부에서 보정하지 않고, handoff/status/trace/pstatus가 같은 paper_candidate_snapshot 값을 복사한다.
# - 전략 조건, S1/S2/S3 기준, 청산, OPEN/CLOSED 장부, 자동매수, BUY_READY는 변경하지 않는다.
# =============================================================================
_V565_LAST_CANDIDATE_SNAPSHOT: Dict[str, Any] = {}


def _v565_int(v: Any, default: int = 0) -> int:
    try:
        if v is None or v == '':
            return default
        return int(float(v))
    except Exception:
        return default


def _v565_latest_rows(ctrl: Optional[Dict[str, Any]] = None, max_rows: int = 800) -> List[Dict[str, Any]]:
    """paper_candidates_latest를 읽고 paper_bot 소비 기준 latest_scan_filter까지 적용한 active row snapshot."""
    try:
        ctrl = ctrl or load_control()
        limit = int(fnum(ctrl.get('candidate_read_max_lines'), default=max_rows))
        limit = max(100, min(max_rows, limit))
        rows = read_jsonl_tail(FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl'), limit)
        rows = [dict(r) for r in rows if isinstance(r, dict)]
        try:
            return latest_scan_filter(rows, ctrl)
        except Exception as exc:
            log_error('v565_latest_scan_filter', exc)
            return rows
    except Exception as exc:
        log_error('v565_latest_rows', exc)
        return []


def _v565_fresh_count(rows: List[Dict[str, Any]], ctrl: Optional[Dict[str, Any]] = None) -> int:
    ctrl = ctrl or load_control()
    n = 0
    for r in rows:
        try:
            if candidate_is_fresh(r, ctrl):
                n += 1
        except Exception:
            continue
    return n


def _v565_stage_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    out: Dict[str, int] = {'S1': 0, 'S2': 0, 'S3': 0, 'X': 0}
    for r in rows:
        try:
            g = str(r.get('s_stage') or r.get('candidate_grade') or r.get('grade') or r.get('stage') or '').upper()
            if is_s1_candidate(r):
                g = 'S1'
            elif g not in {'S1', 'S2', 'S3'}:
                if g in {'X', 'EXCLUDED', '제외'}:
                    g = 'X'
                else:
                    continue
            out[g] = int(out.get(g, 0)) + 1
        except Exception:
            continue
    return out


def _v565_make_snapshot(rows: List[Dict[str, Any]], ctrl: Optional[Dict[str, Any]] = None, pick_stats: Optional[Dict[str, Any]] = None, open_pos: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    global _V565_LAST_CANDIDATE_SNAPSHOT
    ctrl = ctrl or load_control()
    pick_stats = pick_stats if isinstance(pick_stats, dict) else {}
    open_pos = open_pos if isinstance(open_pos, dict) else load_open()
    nowv = now_ts()
    latest_count = len(rows)
    fresh_count = _v565_fresh_count(rows, ctrl)
    stages = _v565_stage_counts(rows)
    snapshot = {
        'schema': 'paper_candidate_snapshot_v565',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'source': 'paper_bot.select_candidates.latest_scan_filter.paper_candidates_latest',
        'latest_count': latest_count,
        'paper_latest_count': latest_count,
        'active_latest_count': latest_count,
        'latest_lines': latest_count,
        'merged_fresh': fresh_count,
        'fresh_count': fresh_count,
        'fresh_source': 'v565_paper_candidate_snapshot_candidate_is_fresh_once',
        's1_seen': _v565_int(pick_stats.get('s1_seen'), stages.get('S1', 0)),
        'selected_s1': _v565_int(pick_stats.get('selected_s1'), 0),
        'paper_entry_hold': _v565_int(pick_stats.get('paper_entry_hold', pick_stats.get('paper_final_block')), 0),
        'paper_final_block': _v565_int(pick_stats.get('paper_final_block', pick_stats.get('paper_entry_hold')), 0),
        'micro_preopen_wait': _v565_int(pick_stats.get('micro_preopen_wait'), 0),
        'stale_skip': _v565_int(pick_stats.get('stale_skip'), 0),
        'not_s1_skip': _v565_int(pick_stats.get('not_s1_skip'), 0),
        'stage_counts': stages,
        'open_count': len(open_pos),
        'open_total': len(open_pos),
    }
    for k in ('last_s1_seen', 'last_open_try', 'last_paper_entry_hold', 'last_paper_final_block', 'last_skip'):
        if k in pick_stats:
            snapshot[k] = pick_stats.get(k)
    _V565_LAST_CANDIDATE_SNAPSHOT = dict(snapshot)
    return snapshot


def _v565_apply_snapshot_to_pick(pick_stats: Dict[str, Any], snapshot: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(pick_stats, dict):
        pick_stats = {}
    for k in (
        'latest_count', 'paper_latest_count', 'active_latest_count', 'latest_lines',
        'merged_fresh', 'fresh_count', 'fresh_source', 's1_seen', 'selected_s1',
        'paper_entry_hold', 'paper_final_block', 'micro_preopen_wait', 'stale_skip', 'not_s1_skip',
    ):
        pick_stats[k] = snapshot.get(k, pick_stats.get(k))
    pick_stats['paper_candidate_snapshot'] = snapshot
    pick_stats['snapshot_schema'] = snapshot.get('schema')
    return pick_stats


_v565_prev_select_candidates = select_candidates

def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:  # type: ignore[override]
    picked, pick_stats, latest_rows = _v565_prev_select_candidates(ctrl, open_pos)
    # latest_rows는 기존 select_candidates가 실제 소비 대상으로 삼은 filtered rows다. 이 순간 한 번만 fresh/latest를 봉인한다.
    snapshot = _v565_make_snapshot(latest_rows, ctrl, pick_stats, open_pos)
    pick_stats = _v565_apply_snapshot_to_pick(pick_stats, snapshot)
    return picked, pick_stats, latest_rows


def _v565_pick_from_snapshot_or_rows(pick_stats: Optional[Dict[str, Any]] = None, rows: Optional[List[Dict[str, Any]]] = None, ctrl: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    ctrl = ctrl or load_control()
    pick_stats = pick_stats if isinstance(pick_stats, dict) else {}
    snapshot = pick_stats.get('paper_candidate_snapshot') if isinstance(pick_stats.get('paper_candidate_snapshot'), dict) else None
    if not snapshot:
        if rows is None:
            rows = _v565_latest_rows(ctrl)
        snapshot = _v565_make_snapshot(rows, ctrl, pick_stats, load_open())
    else:
        rows = rows if rows is not None else _v565_latest_rows(ctrl)
    pick = dict(pick_stats)
    pick = _v565_apply_snapshot_to_pick(pick, snapshot)
    return snapshot, pick, rows or []




def _v560_refresh_trace_status(st: Dict[str, Any]) -> None:  # type: ignore[override]
    """cycle-end heartbeat도 v565 snapshot만 복사한다. 중간/마지막 write의 fresh 값이 달라지면 안 된다."""
    ctrl = load_control()
    pick_stats = st.get('pick_stats') if isinstance(st, dict) and isinstance(st.get('pick_stats'), dict) else {}
    snapshot, pick, rows = _v565_pick_from_snapshot_or_rows(pick_stats, ctrl=ctrl)
    open_pos = load_open()
    nowv = now_ts()
    try:
        trace_obj = build_trace(rows, ctrl, open_pos, set(), set())
    except Exception as exc:
        log_error('v565_build_trace', exc)
        trace_obj = _v560_minimal_trace(rows, ctrl, open_pos, f'{type(exc).__name__}: {exc}')
    trace_rows = trace_obj.get('rows') if isinstance(trace_obj.get('rows'), list) else []
    # trace에도 snapshot 메타를 붙여 소비처가 별도 계산하지 않게 한다.
    try:
        trace_obj['paper_candidate_snapshot'] = snapshot
        trace_obj['latest_count'] = snapshot.get('latest_count', 0)
        trace_obj['merged_fresh'] = snapshot.get('merged_fresh', 0)
        trace_obj['fresh_count'] = snapshot.get('fresh_count', 0)
        trace_obj['fresh_source'] = snapshot.get('fresh_source')
        save_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), trace_obj)
    except Exception as exc:
        log_error('v565_trace_snapshot_save', exc)
    handoff_obj = {
        'schema': 'paper_handoff_status_v565_candidate_snapshot',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', 0),
        'active_latest_count': snapshot.get('active_latest_count', 0),
        'latest_lines': snapshot.get('latest_lines', 0),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'stage_counts': snapshot.get('stage_counts', {}),
        'cache_spine': 'v565 paper_candidate_snapshot same-cycle heartbeat',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
    }
    save_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), handoff_obj)
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    if not isinstance(status, dict):
        status = {}
    status.update({
        'version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', 0),
        'active_latest_count': snapshot.get('active_latest_count', 0),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'cache_spine_version': 'v565',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
    })
    save_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), status)


def _v561_pick_spine(status: Dict[str, Any], handoff: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    """/pstatus는 status/handoff의 개별 fresh가 아니라 snapshot을 최우선으로 읽는다."""
    pick: Dict[str, Any] = {}
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        snap = src.get('paper_candidate_snapshot')
        if isinstance(snap, dict):
            pick.update(snap)
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        if isinstance(src.get('pick_stats'), dict):
            ps = src.get('pick_stats') or {}
            # last_* 같은 상세 추적은 pick_stats에서 보존하되 fresh/latest는 snapshot 값이 우선이다.
            for k, v in ps.items():
                if k in {'latest_count', 'paper_latest_count', 'merged_fresh', 'fresh_count'} and k in pick:
                    continue
                pick.setdefault(k, v)
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        for dst, keys in {
            'latest_count': ('latest_count', 'paper_latest_count', 'active_latest_count'),
            'merged_fresh': ('merged_fresh', 'fresh_count'),
            's1_seen': ('s1_seen',),
            'selected_s1': ('selected_s1',),
            'paper_entry_hold': ('paper_entry_hold', 'paper_final_block'),
            'micro_preopen_wait': ('micro_preopen_wait',),
        }.items():
            if dst in pick and pick.get(dst) not in (None, ''):
                continue
            for k in keys:
                if k in src and src.get(k) not in (None, ''):
                    pick[dst] = src.get(k)
                    break
    return pick


# =============================================================================
# paper_bot v0.193 / v566: handoff writer 최종 단일화 + OPEN 당시 snapshot 봉인
# - handoff_status를 run_cycle 중간에 쓰지 않는다. cycle-end heartbeat에서 status/trace/handoff를 같은 snapshot으로 같이 쓴다.
# - latest/fresh/S1감지/S1선택/micro대기는 paper_candidate_snapshot 값만 쓴다.
# - OPEN 포지션에는 당시 snapshot과 S1->paper 지연/first->open 변화를 보존한다.
# - 조건/S등급/청산/장부 삭제/자동매수/BUY_READY 변경 없음.
# =============================================================================


def _v566_to_float(v: Any, default: float = 0.0) -> float:
    try:
        if v in (None, '', [], {}):
            return default
        return float(str(v).replace(',', '').replace('%', '').strip())
    except Exception:
        return default


def _v566_find_ts(ev: Dict[str, Any], *keys: str) -> float:
    try:
        srcs = _diag_sources(ev) if '_diag_sources' in globals() else [ev]
    except Exception:
        srcs = [ev]
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            ts = _v566_to_float(src.get(k), 0.0)
            if ts > 0:
                return ts
    return 0.0


def _v566_find_price(ev: Dict[str, Any], *keys: str) -> float:
    try:
        srcs = _diag_sources(ev) if '_diag_sources' in globals() else [ev]
    except Exception:
        srcs = [ev]
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            px = _v566_to_float(src.get(k), 0.0)
            if px > 0:
                return px
    return 0.0


def _v566_snapshot_for_cycle(pick_stats: Optional[Dict[str, Any]] = None, rows: Optional[List[Dict[str, Any]]] = None, ctrl: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    """v566 단일 snapshot. 기존 v565 helper를 쓰되 schema/build만 현재판으로 봉인한다."""
    snapshot, pick, out_rows = _v565_pick_from_snapshot_or_rows(pick_stats, rows=rows, ctrl=ctrl)
    snapshot = dict(snapshot or {})
    nowv = now_ts()
    snapshot.update({
        'schema': 'paper_candidate_snapshot_v566',
        'version': VERSION,
        'build': BUILD_LABEL,
        'snapshot_owner': 'paper_bot',
        'snapshot_rule': 'paper_bot reads paper_candidates once, then status/handoff/trace copy this snapshot only',
        'updated_at': snapshot.get('updated_at') or nowv,
        'updated_at_text': snapshot.get('updated_at_text') or iso_ts(nowv),
    })
    pick = _v565_apply_snapshot_to_pick(dict(pick or {}), snapshot)
    pick['paper_candidate_snapshot'] = snapshot
    pick['snapshot_schema'] = snapshot.get('schema')
    return snapshot, pick, out_rows or []


# run_cycle 내부 중간 write 차단: handoff는 cycle-end _v560_refresh_trace_status에서만 쓴다.
def write_handoff_status(latest_count: int, merged_fresh: int, pick_stats: Dict[str, Any]) -> None:  # type: ignore[override]
    try:
        snapshot, pick, _rows = _v566_snapshot_for_cycle(pick_stats)
        pick_stats.clear()
        pick_stats.update(pick)
        # 파일 쓰기 금지. 중간 handoff write가 /paper_handoff fresh 0 race를 만들었다.
        return None
    except Exception as exc:
        log_error('v566_write_handoff_status_noop', exc)
        return None


_v566_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v566_prev_open_position(pos_id, ev)
    try:
        opened_at = _v566_to_float(pos.get('opened_at'), now_ts())
        entry_px = _v566_to_float(pos.get('entry_price'), 0.0)
        s1_ts = _v566_find_ts(ev, 's1_seen_at', 's1_seen_ts', 's1_at', 'promoted_at', 'promoted_ts', 'paper_handoff_ts', 'handoff_ts')
        first_ts = _v566_find_ts(ev, 'first_seen_at', 'first_seen_ts', 'first_seen_time', 'detected_at', 'detected_ts')
        first_px = _v566_find_price(ev, 'first_seen_price', 'detected_price', 'watch_price', 'structure_seen_price', 's2_price', 'candidate_price')
        snapshot = dict(_V565_LAST_CANDIDATE_SNAPSHOT) if isinstance(globals().get('_V565_LAST_CANDIDATE_SNAPSHOT'), dict) else {}
        open_spine = {
            'schema': 'paper_open_spine_v566',
            'version': VERSION,
            'opened_at': opened_at,
            'opened_at_text': iso_ts(opened_at),
            'snapshot_schema': snapshot.get('schema'),
            'snapshot_latest': snapshot.get('latest_count'),
            'snapshot_fresh': snapshot.get('merged_fresh', snapshot.get('fresh_count')),
            'snapshot_source': snapshot.get('fresh_source'),
            's1_seen_at': s1_ts or None,
            's1_to_paper_delay_sec': round(opened_at - s1_ts, 3) if s1_ts > 0 else None,
            'first_seen_at': first_ts or None,
            'first_to_paper_delay_sec': round(opened_at - first_ts, 3) if first_ts > 0 else None,
            'first_seen_price': first_px or None,
            'entry_price': entry_px or None,
            'first_to_open_return_pct': round((entry_px - first_px) / first_px * 100.0, 4) if first_px > 0 and entry_px > 0 else None,
        }
        pos['paper_open_spine_v566'] = open_spine
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag['paper_open_spine_v566'] = open_spine
        pos['entry_diagnostics'] = diag
    except Exception as exc:
        log_error('v566_open_spine', exc)
    return pos


def _v560_refresh_trace_status(st: Dict[str, Any]) -> None:  # type: ignore[override]
    """cycle-end 단일 writer. status/trace/handoff를 같은 snapshot으로 동시에 갱신한다."""
    ctrl = load_control()
    pick_stats = st.get('pick_stats') if isinstance(st, dict) and isinstance(st.get('pick_stats'), dict) else {}
    snapshot, pick, rows = _v566_snapshot_for_cycle(pick_stats, ctrl=ctrl)
    open_pos = load_open()
    nowv = now_ts()
    try:
        trace_obj = build_trace(rows, ctrl, open_pos, set(), set())
    except Exception as exc:
        log_error('v566_build_trace', exc)
        trace_obj = _v560_minimal_trace(rows, ctrl, open_pos, f'{type(exc).__name__}: {exc}')
    trace_rows = trace_obj.get('rows') if isinstance(trace_obj.get('rows'), list) else []
    trace_obj.update({
        'schema': trace_obj.get('schema') or 'paper_candidate_handoff_trace_v566',
        'version': VERSION,
        'trace_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'paper_candidate_snapshot': snapshot,
        'writer': 'v566_cycle_end_single_writer',
    })
    handoff_obj = {
        'schema': 'paper_handoff_status_v566_candidate_snapshot',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', snapshot.get('latest_count', 0)),
        'active_latest_count': snapshot.get('active_latest_count', snapshot.get('latest_count', 0)),
        'latest_lines': snapshot.get('latest_lines', snapshot.get('latest_count', 0)),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'stage_counts': snapshot.get('stage_counts', {}),
        'cache_spine': 'v566 cycle-end single writer: handoff/status/trace copy paper_candidate_snapshot',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
        'writer': 'v566_cycle_end_single_writer',
    }
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    if not isinstance(status, dict):
        status = {}
    status.update({
        'version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'running': True,
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', snapshot.get('latest_count', 0)),
        'active_latest_count': snapshot.get('active_latest_count', snapshot.get('latest_count', 0)),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'cache_spine_version': 'v566',
        'cache_spine': 'v566 cycle-end single writer: handoff/status/trace copy paper_candidate_snapshot',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
        'writer': 'v566_cycle_end_single_writer',
    })
    save_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), trace_obj)
    save_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), handoff_obj)
    save_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), status)

# =============================================================================
# paper_bot v0.194 / v567: main entrypoint 위치 수정 + OPEN/CLOSED 매매알림 trace 단일화
# - v566 블록이 __main__ 아래에 붙어 실제 서비스에서는 paper_bot_v0.192로 도는 문제를 제거한다.
# - OPEN/CLOSED 발생 시 장부/score와 별개로 알림 시도/성공/실패 trace를 반드시 남긴다.
# - 알림 플래그가 꺼졌거나 경로가 미도달해도 cycle 종료 후 without_alert_trace를 남기고, 가능하면 한 번 보낸다.
# - 조건/S등급/청산/장부 삭제/자동매수/BUY_READY 변경 없음.
# =============================================================================


def _v567_trade_alert_path(kind: str) -> Path:
    if str(kind).lower() == 'closed':
        return BASE_DIR / 'paper_bot_close_alert_trace.jsonl'
    return FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl')


def _v567_trade_id(row: Dict[str, Any]) -> str:
    return str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or '')


def _v567_append_trade_alert_trace(kind: str, row: Dict[str, Any], phase: str, ok: bool = False, err: str = '', note: str = '') -> None:
    try:
        payload = {
            'schema': f'paper_{kind}_alert_trace_v567',
            'version': VERSION,
            'build': BUILD_LABEL,
            'kind': kind,
            'phase': phase,
            'ts': now_ts(),
            'ts_text': iso_ts(),
            'ticker': normalize_ticker(row.get('ticker')),
            'pos_id': row.get('pos_id') or row.get('event_id') or row.get('entry_id'),
            'event_id': row.get('event_id') or row.get('pos_id') or row.get('entry_id'),
            'opened_at': row.get('opened_at'),
            'opened_at_text': row.get('opened_at_text'),
            'closed_at': row.get('closed_at'),
            'closed_at_text': row.get('closed_at_text'),
            'entry_price': row.get('entry_price'),
            'exit_price': row.get('exit_price'),
            'pnl_pct': row.get('pnl_pct'),
            'strategy': row.get('strategy_label') or row.get('strategy_key') or row.get('strategy'),
            'candidate_grade': row.get('candidate_grade'),
            'exit_reason': row.get('exit_reason') or row.get('exit_rule'),
            'entry_build_key': row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or row.get('patch_version'),
            'score_patch_version': row.get('score_patch_version') or row.get('entry_build_key') or row.get('opened_patch_version') or row.get('patch_version'),
            'opened_patch_version': row.get('opened_patch_version') or row.get('entry_build_key') or row.get('score_patch_version'),
            'closed_patch_version': row.get('closed_patch_version') or row.get('close_patch_version'),
            'close_patch_version': row.get('close_patch_version') or row.get('closed_patch_version'),
            'sent_ok': bool(ok),
            'error': str(err or ''),
            'note': str(note or ''),
        }
        append_jsonl(_v567_trade_alert_path(kind), payload)
    except Exception as exc:
        log_error(f'v567_{kind}_alert_trace_append', exc)


def _v567_recent_trade_alert_exists(kind: str, row: Dict[str, Any], since_ts: float, phases: Optional[set] = None) -> bool:
    try:
        tid = _v567_trade_id(row)
        ticker = normalize_ticker(row.get('ticker'))
        opened_at = fnum(row.get('opened_at'), default=0.0)
        closed_at = fnum(row.get('closed_at'), default=0.0)
        for r in read_jsonl_tail(_v567_trade_alert_path(kind), 240):
            if not isinstance(r, dict):
                continue
            rts = fnum(r.get('ts'), default=0.0)
            if rts and rts < since_ts - 10:
                continue
            if phases and str(r.get('phase') or '') not in phases:
                continue
            rtid = str(r.get('pos_id') or r.get('event_id') or r.get('entry_id') or '')
            rticker = normalize_ticker(r.get('ticker'))
            if tid and rtid == tid:
                return True
            if ticker and rticker == ticker:
                ropen = fnum(r.get('opened_at'), default=0.0)
                rclose = fnum(r.get('closed_at'), default=0.0)
                if opened_at and ropen and abs(ropen - opened_at) <= 5:
                    return True
                if closed_at and rclose and abs(rclose - closed_at) <= 5:
                    return True
    except Exception as exc:
        log_error(f'v567_recent_{kind}_alert_exists', exc)
    return False


def _v567_closed_message_text(row: Dict[str, Any]) -> str:
    t = normalize_ticker(row.get('ticker'))
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ''
    if timing_line:
        extra = extra + "\n" + timing_line
    return (
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    _v567_append_trade_alert_trace('open', pos, 'attempt_start', False, '', 'OPEN created; alert send started')
    try:
        text = _v561_open_message_text(pos)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('open', pos, 'message_build_error', False, err, 'OPEN alert text build failed')
        log_error('v567_notify_opened_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('open', pos, phase, ok, err, 'OPEN alert send result')
    if not ok:
        log_error('v567_notify_opened_send_result', Exception(err or 'send_message returned false'))


def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    _v567_append_trade_alert_trace('closed', row, 'attempt_start', False, '', 'CLOSED created; alert send started')
    try:
        text = _v567_closed_message_text(row)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, err, 'CLOSED alert text build failed')
        log_error('v567_notify_closed_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('closed', row, phase, ok, err, 'CLOSED alert send result')
    if not ok:
        log_error('v567_notify_closed_send_result', Exception(err or 'send_message returned false'))


def _v567_read_closed_tail_count() -> int:
    try:
        return line_count_cached(FILES['closed'], ttl=0)
    except Exception:
        return 0


def _v567_recent_closed_rows(before_count: int, max_rows: int = 20) -> List[Dict[str, Any]]:
    try:
        after_count = _v567_read_closed_tail_count()
        n = max(0, min(max_rows, after_count - int(before_count or 0)))
        if n <= 0:
            return []
        rows = read_jsonl_tail(FILES['closed'], max(n, 1))
        return [r for r in rows if isinstance(r, dict)][-n:]
    except Exception as exc:
        log_error('v567_recent_closed_rows', exc)
        return []





def _v567_latest_trade_alert(kind: str) -> Dict[str, Any]:
    try:
        rows = read_jsonl_tail(_v567_trade_alert_path(kind), 80)
        for r in reversed(rows):
            if isinstance(r, dict):
                return r
    except Exception as exc:
        log_error(f'v567_latest_{kind}_alert', exc)
    return {}


def _v567_trade_alert_line(kind: str, label: str) -> str:
    r = _v567_latest_trade_alert(kind)
    if not r:
        return f'- 마지막 {label}알림: -'
    age = max(0.0, now_ts() - fnum(r.get('ts'), default=now_ts()))
    phase = str(r.get('phase') or '-')
    ok = r.get('sent_ok')
    err = str(r.get('error') or '').strip()
    state = '✅ sent_ok' if bool(ok) else f'⚠️ {phase}'
    tail = f" / err {err[:60]}" if err else ''
    return f"- 마지막 {label}알림: {r.get('ticker') or '-'} / {state} / age {age:.1f}s{tail}"





# =============================================================================
# paper_bot v0.195 / v568: light_runner OPEN/CLOSED 매매알림 강제 연결
# - OPEN/CLOSED 장부가 생겼는데 notify_on_strict_* 설정 또는 경로 문제로 알림이 빠지는 것을 막는다.
# - light_runner cycle 종료 후 새 OPEN/CLOSED를 확인하고, send 결과 trace가 없으면 반드시 notify_opened/notify_closed를 호출한다.
# - 알림 실패도 send_error/message_build_error로 남긴다. 조건/S등급/청산/장부/자동매수/BUY_READY 변경 없음.
# =============================================================================


def _v568_event_match(kind: str, row: Dict[str, Any], trace: Dict[str, Any]) -> bool:
    try:
        tid = str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or '')
        rtid = str(trace.get('pos_id') or trace.get('event_id') or trace.get('entry_id') or '')
        if tid and rtid and tid == rtid:
            return True
        ticker = normalize_ticker(row.get('ticker'))
        rticker = normalize_ticker(trace.get('ticker'))
        if not ticker or not rticker or ticker != rticker:
            return False
        opened_at = fnum(row.get('opened_at'), default=0.0)
        ropened_at = fnum(trace.get('opened_at'), default=0.0)
        if opened_at and ropened_at and abs(opened_at - ropened_at) <= 5:
            return True
        if str(kind).lower() == 'closed':
            closed_at = fnum(row.get('closed_at'), default=0.0)
            rclosed_at = fnum(trace.get('closed_at'), default=0.0)
            if closed_at and rclosed_at and abs(closed_at - rclosed_at) <= 5:
                return True
    except Exception:
        return False
    return False


def _v568_has_send_result(kind: str, row: Dict[str, Any], since_ts: float) -> bool:
    """True면 이미 성공/실패/본문생성실패 중 하나가 남아 있어 추가 발송하지 않는다."""
    try:
        phases = {'send_ok', 'send_error', 'message_build_error'}
        for r in read_jsonl_tail(_v567_trade_alert_path(kind), 320):
            if not isinstance(r, dict):
                continue
            rts = fnum(r.get('ts'), default=0.0)
            if rts and rts < since_ts - 20:
                continue
            if str(r.get('phase') or '') not in phases:
                continue
            if _v568_event_match(kind, row, r):
                return True
    except Exception as exc:
        log_error(f'v568_has_{kind}_send_result', exc)
    return False


def _v568_closed_rows_since(before_count: int, max_rows: int = 50) -> List[Dict[str, Any]]:
    try:
        after_count = line_count_cached(FILES['closed'], ttl=0)
        n = max(0, min(max_rows, int(after_count) - int(before_count or 0)))
        if n <= 0:
            return []
        rows = read_jsonl_tail(FILES['closed'], max(n, 1))
        return [r for r in rows if isinstance(r, dict)][-n:]
    except Exception as exc:
        log_error('v568_closed_rows_since', exc)
        return []










# =============================================================================
# paper_bot v0.196 / v569: 후반 손실군 복기 cache 생산
# - CLOSED/trade_log/score cache 주인은 paper_bot이다.
# - 조건/S1/S2/S3/청산/장부는 변경하지 않는다.
# - 최근 성과 급락을 진입 당시 snapshot/위험태그/청산사유 기준으로 비교할 cache만 만든다.
# =============================================================================


def _v569_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    try:
        return _score_stat(rows)
    except Exception:
        n=len(rows); wins=sum(1 for r in rows if fnum(r.get('pnl_pct'), default=0.0)>0); total=sum(fnum(r.get('pnl_pct'), default=0.0) for r in rows)
        return {'n':n,'wins':wins,'losses':max(0,n-wins),'win_rate':(wins/n*100 if n else 0.0),'total':total,'avg':(total/n if n else 0.0)}


def _v569_stat_line(rows: List[Dict[str, Any]]) -> str:
    st=_v569_stat(rows); n=int(st.get('n',0) or 0); w=int(st.get('wins',0) or 0); l=int(st.get('losses', max(0,n-w)) or 0)
    return f"{n}전 {w}승 {l}패 / 승률 {fnum(st.get('win_rate'), default=0.0):.1f}% / 합산 {fnum(st.get('total'), default=0.0):+.2f}% / 평균 {fnum(st.get('avg'), default=0.0):+.2f}%"


def _v569_nested_sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out=[row]
    for k in ('paper_open_spine_v566','paper_open_spine','entry_context','entry_snapshot','candidate_snapshot','source','raw','diagnostics','open_context'):
        v=row.get(k)
        if isinstance(v, dict): out.append(v)
    return out


def _v569_get(row: Dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    for src in _v569_nested_sources(row):
        for k in keys:
            if k in src and src.get(k) not in (None, '', [], {}):
                return src.get(k)
    return default


def _v569_num(row: Dict[str, Any], keys: Iterable[str], default: float = 0.0) -> float:
    return fnum(_v569_get(row, keys, default), default=default)


def _v569_text_blob(row: Dict[str, Any]) -> str:
    vals=[]
    for src in _v569_nested_sources(row):
        for k,v in src.items():
            if k in {'raw','source','entry_context','candidate_snapshot','diagnostics'}: continue
            if isinstance(v, (str,int,float,bool)):
                vals.append(f"{k}:{v}")
            elif isinstance(v, list):
                vals.append(f"{k}:{','.join(str(x) for x in v[:8])}")
    return ' | '.join(vals)


def _v569_loss_issue_counter(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c: Counter = Counter()
    for r in rows:
        blob=_v569_text_blob(r)
        low=blob.lower()
        exit_reason=str(_v569_get(r, ('exit_reason','exit_rule','close_reason'), '-') or '-')
        c[f"청산:{exit_reason}"] += 1
        tag=str(_v569_get(r, ('close_review_tag','review_tag','result_tag'), '') or '')
        if tag and tag != '-': c[f"복기:{tag}"] += 1
        spread=_v569_num(r, ('spread_pct','entry_spread_pct','spread','best_spread_pct'), 0.0)
        slip=_v569_num(r, ('slippage_pct','expected_slippage_pct','entry_slippage_pct','slip_pct'), 0.0)
        reaction=_v569_num(r, ('price_reaction_pct','reaction_pct','entry_price_reaction_pct','reaction'), 999.0)
        buy=_v569_num(r, ('buy_ratio','buy_trade_ratio','entry_buy_ratio','buy_strength'), 999.0)
        persist=_v569_num(r, ('buy_persist_1m','one_min_buy_persist','entry_buy_persist_1m','persist_1m'), 999.0)
        first_ret=_v569_num(r, ('first_to_open_return_pct','first_to_paper_return_pct','first_to_now_return','first_to_now_return_pct'), 0.0)
        s1_delay=_v569_num(r, ('s1_to_paper_delay_sec','s1_to_open_delay_sec'), 0.0)
        fresh=_v569_num(r, ('snapshot_fresh','fresh_count','candidate_fresh_count'), -1.0)
        latest=_v569_num(r, ('snapshot_latest','latest_count','candidate_latest_count'), -1.0)
        if spread >= 0.30 or '스프레드부담' in blob or '스프레드 과다' in blob: c['진입부담:스프레드'] += 1
        if slip >= 0.25 or '미끄러짐부담' in blob: c['진입부담:미끄러짐'] += 1
        if reaction != 999.0 and reaction < 0.35: c['확인신호:가격반응 약함'] += 1
        if buy != 999.0 and buy < 0.70: c['확인신호:매수체결 약함'] += 1
        if persist != 999.0 and persist < 0.75: c['확인신호:1분지속 부족'] += 1
        if first_ret >= 1.0 or '늦은추격' in blob or 'late_chase' in low: c['타이밍:늦은추격 의심'] += 1
        if s1_delay >= 10.0: c['타이밍:S1→OPEN 지연'] += 1
        if latest > 0 and fresh <= 0: c['배관:OPEN 당시 fresh 0'] += 1
        if 'freshness' in low or '신선' in blob: c['배관:신선도 관련'] += 1
    return dict(c)


def _v569_top(counter: Dict[str, int], limit: int = 6) -> str:
    items=sorted(counter.items(), key=lambda kv:(-kv[1], kv[0]))[:limit]
    return ' / '.join(f"{k} {v}" for k,v in items) if items else '-'


def _v569_pick_primary_strategy(today_rows: List[Dict[str, Any]]) -> str:
    c: Counter = Counter(_strategy_key(r) for r in today_rows)
    if c.get('주도흐름 유동보유',0) > 0:
        return '주도흐름 유동보유'
    return c.most_common(1)[0][0] if c else '-'


def write_trade_review_cache_v569(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 500) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        for r in primary_rows:
            by_version.setdefault(_main_version_key(r), []).append(r)
        version_lines=[]
        for vk, arr in sorted(by_version.items(), key=lambda kv: str(kv[0]), reverse=True)[:5]:
            version_lines.append(f"- {vk}: {_v569_stat_line(arr)}")
        issue = _v569_loss_issue_counter(late_losses or last16_losses)
        last_issue = _v569_loss_issue_counter(last16_losses)
        summary_lines = [
            '📉 후반 손실군 복기 /trade_review · v569 cache-only',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[초반 vs 후반]',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근 16전: {_v569_stat_line(last16)}" if last16 else '- 최근 16전: 표본부족',
            '',
            '[후반 손실군 공통 원인 TOP]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(issue)}",
            f"- 최근16 손실 {len(last16_losses)}개: {_v569_top(last_issue)}",
            '',
            '[오늘 버전별 · 주분석 전략]',
            *(version_lines or ['- 표본부족']),
            '',
            '[판독]',
            '- 후반 손실군이 초반 승리군과 다르면 조건 변경 전 진입타이밍/정보지연/스프레드/미끄러짐을 먼저 분리한다.',
            '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v569',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'late_loss_count': len(late_losses),
            'last16_loss_count': len(last16_losses),
            'late_loss_issue_top': issue,
            'last16_loss_issue_top': last_issue,
            'primary_version_stats': {vk: _v569_stat(arr) for vk, arr in by_version.items()},
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v569', exc)









# =============================================================================
# paper_bot v0.197 / v570: 신선도×늦은추격 세분화 복기
# - v569에서 후반 손실군 공통 원인을 찾았고, v570은 그중 "신선도 관련"을 숫자/문구/타이밍/실행위험으로 분리한다.
# - 조건/S1/S2/S3/청산/장부/자동매수/BUY_READY 변경 없음.
# - paper_bot은 CLOSED/trade_log/score/review cache 주인이다. 메인봇은 이 cache만 읽는다.
# =============================================================================


def _v570_boolish(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    return s in {'1','true','yes','y','ok','on','맞음','있음'}


def _v570_max_num(row: Dict[str, Any], keys: Iterable[str], default: float = -1.0) -> float:
    vals: List[float] = []
    for src in _v569_nested_sources(row):
        if not isinstance(src, dict):
            continue
        for k in keys:
            if k in src and src.get(k) not in (None, '', [], {}):
                vals.append(fnum(src.get(k), default=default))
    vals = [x for x in vals if x != default]
    return max(vals) if vals else default


def _v570_any_text(row: Dict[str, Any], words: Iterable[str]) -> bool:
    blob = _v569_text_blob(row)
    low = blob.lower()
    return any((w.lower() in low) for w in words)


def _v570_case(row: Dict[str, Any]) -> Dict[str, Any]:
    """후반 손실 원인을 바로 차단조건으로 쓰지 않고, 복기용 분류만 만든다."""
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    latest = _v569_num(row, ('snapshot_latest','latest_count','candidate_latest_count','active_latest_count'), -1.0)
    fresh = _v569_num(row, ('snapshot_fresh','fresh_count','candidate_fresh_count','merged_fresh'), -1.0)
    # 개별 정보 나이. 없으면 -1로 두고, 문구만 있는 신선도와 분리한다.
    fresh_age = _v570_max_num(row, (
        'freshness_age_sec','candidate_age_sec','candidate_fresh_age_sec','row_age_sec',
        'price_age_sec','ticker_age_sec','orderflow_age_sec','micro_age_sec','ws_age_sec',
        'snapshot_age_sec','paper_candidate_age_sec'
    ), -1.0)
    price_age = _v570_max_num(row, ('price_age_sec','ticker_age_sec','ws_price_age_sec'), -1.0)
    order_age = _v570_max_num(row, ('orderflow_age_sec','trade_age_sec','buy_ratio_age_sec','one_min_age_sec'), -1.0)
    micro_age = _v570_max_num(row, ('micro_age_sec','orderbook_age_sec','slippage_age_sec','spread_age_sec'), -1.0)
    spread = _v569_num(row, ('spread_pct','entry_spread_pct','spread','best_spread_pct'), 0.0)
    slip = _v569_num(row, ('slippage_pct','expected_slippage_pct','entry_slippage_pct','slip_pct'), 0.0)
    first_ret = _v569_num(row, ('first_to_open_return_pct','first_to_paper_return_pct','first_to_now_return','first_to_now_return_pct'), 0.0)
    s1_delay = _v569_num(row, ('s1_to_paper_delay_sec','s1_to_open_delay_sec'), 0.0)
    first_delay = _v569_num(row, ('first_to_paper_delay_sec','first_to_open_delay_sec'), 0.0)
    reaction = _v569_num(row, ('price_reaction_pct','reaction_pct','entry_price_reaction_pct','reaction'), 999.0)
    buy = _v569_num(row, ('buy_ratio','buy_trade_ratio','entry_buy_ratio','buy_strength'), 999.0)
    persist = _v569_num(row, ('buy_persist_1m','one_min_buy_persist','entry_buy_persist_1m','persist_1m'), 999.0)
    late_flag = _v570_any_text(row, ('늦은추격', 'late_chase', 'late chase')) or first_ret >= 1.0
    fresh_word = _v570_any_text(row, ('freshness', '신선', 'fresh_delay', 'freshness_delay'))
    spread_bad = spread >= 0.30 or _v570_any_text(row, ('스프레드부담','스프레드 과다'))
    slip_bad = slip >= 0.25 or _v570_any_text(row, ('미끄러짐부담',))
    numeric_fresh_bad = (latest > 0 and fresh <= 0) or fresh_age >= 10.0 or price_age >= 10.0 or order_age >= 10.0 or micro_age >= 10.0
    info_late = numeric_fresh_bad
    # 신선도 문구만 있고 숫자 근거가 없으면 바로 차단 근거가 아니라 "추가확인"으로 둔다.
    fresh_text_only = fresh_word and not numeric_fresh_bad
    chase_after_wait = late_flag and (s1_delay >= 5.0 or first_delay >= 60.0 or spread_bad or slip_bad)
    weak_confirm = (reaction != 999.0 and reaction < 0.35) or (buy != 999.0 and buy < 0.70) or (persist != 999.0 and persist < 0.75)
    cats: List[str] = []
    if latest > 0 and fresh <= 0: cats.append('신선도:OPEN당시 fresh0')
    if fresh_age >= 10.0 or price_age >= 10.0 or order_age >= 10.0 or micro_age >= 10.0: cats.append('신선도:핵심정보나이과다')
    if fresh_text_only: cats.append('신선도:문구만있음_숫자확인필요')
    if late_flag: cats.append('타이밍:늦은추격')
    if chase_after_wait: cats.append('타이밍:대기후추격')
    if spread_bad: cats.append('실행위험:스프레드')
    if slip_bad: cats.append('실행위험:미끄러짐')
    if weak_confirm: cats.append('확인신호:체결반응약함')
    # 복기용 권고. 실제 조건 변경은 별도 승인 후.
    if info_late and late_flag:
        action = 'S1제외후보:신선도지연+늦은추격'
    elif info_late and (spread_bad or slip_bad):
        action = 'S2보류후보:신선도지연+실행위험'
    elif late_flag and (spread_bad or slip_bad):
        action = 'S2보류후보:늦은추격+실행위험'
    elif fresh_text_only:
        action = '추가확인:신선도문구_숫자근거부족'
    else:
        action = '조건외원인확인필요'
    return {
        'ticker': row.get('ticker') or row.get('symbol') or '-',
        'pnl_pct': pnl,
        'exit_reason': _v569_get(row, ('exit_reason','exit_rule','close_reason'), '-'),
        'latest': latest,
        'fresh': fresh,
        'fresh_age_sec': fresh_age,
        'price_age_sec': price_age,
        'orderflow_age_sec': order_age,
        'micro_age_sec': micro_age,
        'first_to_open_return_pct': first_ret,
        's1_to_paper_delay_sec': s1_delay,
        'first_to_paper_delay_sec': first_delay,
        'spread_pct': spread,
        'slippage_pct': slip,
        'late_chase_flag': bool(late_flag),
        'numeric_fresh_bad': bool(numeric_fresh_bad),
        'fresh_text_only': bool(fresh_text_only),
        'spread_bad': bool(spread_bad),
        'slip_bad': bool(slip_bad),
        'weak_confirm': bool(weak_confirm),
        'categories': cats or ['분류없음'],
        'review_action': action,
    }


def _v570_counter(cases: List[Dict[str, Any]], key: str = 'categories') -> Dict[str, int]:
    c: Counter = Counter()
    for case in cases:
        vals = case.get(key)
        if isinstance(vals, list):
            for x in vals:
                c[str(x)] += 1
        elif vals:
            c[str(vals)] += 1
    return dict(c)


def _v570_action_counter(cases: List[Dict[str, Any]]) -> Dict[str, int]:
    c: Counter = Counter()
    for case in cases:
        c[str(case.get('review_action') or '-')] += 1
    return dict(c)


def _v570_filter_safe(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """가상 참고용. 조건을 바꾸는 것이 아니라, 문제 조합 제외 시 성과가 어땠는지 복기만 한다."""
    out: List[Dict[str, Any]] = []
    for r in rows:
        c = _v570_case(r)
        # 숫자 신선도 지연+늦은추격은 가장 강한 의심군.
        if c.get('numeric_fresh_bad') and c.get('late_chase_flag'):
            continue
        # 늦은추격+스프레드/미끄러짐은 S2보류 의심군.
        if c.get('late_chase_flag') and (c.get('spread_bad') or c.get('slip_bad')):
            continue
        out.append(r)
    return out


def _v570_case_line(case: Dict[str, Any]) -> str:
    t = str(case.get('ticker') or '-')
    pnl = fnum(case.get('pnl_pct'), default=0.0)
    ret = fnum(case.get('first_to_open_return_pct'), default=0.0)
    s1d = fnum(case.get('s1_to_paper_delay_sec'), default=0.0)
    sp = fnum(case.get('spread_pct'), default=0.0)
    fr = case.get('fresh')
    cats = ','.join(str(x) for x in (case.get('categories') or [])[:3])
    return f"- {t}: {pnl:+.2f}% / first→open {ret:+.2f}% / S1→OPEN {s1d:.1f}s / fresh {fr} / 스프 {sp:.2f}% / {case.get('review_action')} / {cats}"


def write_trade_review_cache_v570(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 700) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        late_cases = [_v570_case(r) for r in late_losses]
        last_cases = [_v570_case(r) for r in last16_losses]
        safe_all = _v570_filter_safe(primary_rows)
        safe_late = _v570_filter_safe(late)
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        for r in primary_rows:
            by_version.setdefault(_main_version_key(r), []).append(r)
        version_lines=[]
        for vk, arr in sorted(by_version.items(), key=lambda kv: str(kv[0]), reverse=True)[:5]:
            version_lines.append(f"- {vk}: {_v569_stat_line(arr)}")
        summary_lines = [
            '📉 후반 손실군 복기 /trade_review · v570 신선도×늦은추격 세분화',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[초반 vs 후반]',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근 16전: {_v569_stat_line(last16)}" if last16 else '- 최근 16전: 표본부족',
            '',
            '[후반 손실군 원인 세분화]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(_v570_counter(late_cases), 8)}",
            f"- 최근16 손실 {len(last16_losses)}개: {_v569_top(_v570_counter(last_cases), 8)}",
            f"- 복기판정: {_v569_top(_v570_action_counter(late_cases), 6)}",
            '',
            '[가상 제외 참고 · 조건 변경 아님]',
            f"- 전체 주분석 전략 원본: {_v569_stat_line(primary_rows)}" if primary_rows else '- 원본: 표본부족',
            f"- 숫자 신선도지연+늦은추격/실행위험 의심 제외 시: {_v569_stat_line(safe_all)}" if primary_rows else '- 제외 참고: 표본부족',
            f"- 후반만 같은 기준 제외 시: {_v569_stat_line(safe_late)}" if late else '- 후반 제외 참고: 표본부족',
            '',
            '[후반 손실 샘플]',
            *(_v570_case_line(c) for c in late_cases[:5]),
            '',
            '[오늘 버전별 · 주분석 전략]',
            *(version_lines or ['- 표본부족']),
            '',
            '[판독]',
            '- 신선도 관련을 바로 차단하지 않고, 숫자 지연 / 문구만 있음 / 늦은추격 / 스프레드·미끄러짐 회복대기로 나눠 본다.',
            '- 숫자 신선도지연+늦은추격 조합이 반복 손실이면 S1 제외 또는 S2 보류 후보로 설계 검토한다.',
            '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v570_fresh_late_split',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'safe_all_stat_reference_only': _v569_stat(safe_all),
            'safe_late_stat_reference_only': _v569_stat(safe_late),
            'late_loss_count': len(late_losses),
            'last16_loss_count': len(last16_losses),
            'late_loss_split_top': _v570_counter(late_cases),
            'last16_loss_split_top': _v570_counter(last_cases),
            'late_review_action_top': _v570_action_counter(late_cases),
            'late_loss_cases_sample': late_cases[:20],
            'primary_version_stats': {vk: _v569_stat(arr) for vk, arr in by_version.items()},
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v570', exc)









# =============================================================================

# [v582 cleanup] removed stale duplicate writer block.

# paper_bot v0.199 / v572: 좋았던 구간 vs 나빠진 구간 복기 비교
# - 조건/S1/S2/S3/청산/장부/자동매수/BUY_READY 변경 없음.
# - paper_bot은 CLOSED/trade_log/review cache 주인이다.
# - 목적: v2.13.461 승리구간과 v2.13.462~463 손실구간의 진입 당시 fresh/late/실행위험 차이를 숫자로 비교한다.
# =============================================================================


def _v572_version_rows(rows: List[Dict[str, Any]], versions: Iterable[str]) -> List[Dict[str, Any]]:
    wanted = set(str(v) for v in versions)
    out: List[Dict[str, Any]] = []
    for r in rows:
        if _main_version_key(r) in wanted:
            out.append(r)
    return out


def _v572_case_flags(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    cases = [_v570_case(r) for r in rows]
    n = len(cases)
    losses = [c for c in cases if fnum(c.get('pnl_pct'), default=0.0) <= 0]
    def cnt(pred):
        return sum(1 for c in cases if pred(c))
    def losscnt(pred):
        return sum(1 for c in losses if pred(c))
    return {
        'n': n,
        'loss_n': len(losses),
        'late_chase': cnt(lambda c: bool(c.get('late_chase_flag'))),
        'numeric_fresh_bad': cnt(lambda c: bool(c.get('numeric_fresh_bad'))),
        'fresh_text_only': cnt(lambda c: bool(c.get('fresh_text_only'))),
        'spread_bad': cnt(lambda c: bool(c.get('spread_bad'))),
        'slip_bad': cnt(lambda c: bool(c.get('slip_bad'))),
        'weak_confirm': cnt(lambda c: bool(c.get('weak_confirm'))),
        'late_loss': losscnt(lambda c: bool(c.get('late_chase_flag'))),
        'fresh_bad_loss': losscnt(lambda c: bool(c.get('numeric_fresh_bad'))),
        'fresh_text_loss': losscnt(lambda c: bool(c.get('fresh_text_only'))),
        'spread_loss': losscnt(lambda c: bool(c.get('spread_bad'))),
        'slip_loss': losscnt(lambda c: bool(c.get('slip_bad'))),
        'weak_confirm_loss': losscnt(lambda c: bool(c.get('weak_confirm'))),
        'action_top': _v570_action_counter(cases),
        'category_top': _v570_counter(cases),
        'loss_category_top': _v570_counter(losses),
    }


def _v572_rate_line(flags: Dict[str, Any]) -> str:
    n = int(flags.get('n') or 0)
    if n <= 0:
        return '표본부족'
    def pct(k):
        return f"{int(flags.get(k) or 0)}/{n}({(float(flags.get(k) or 0)/n*100.0):.0f}%)"
    return ' / '.join([
        f"늦은추격 {pct('late_chase')}",
        f"숫자신선도지연 {pct('numeric_fresh_bad')}",
        f"문구만신선도 {pct('fresh_text_only')}",
        f"스프레드 {pct('spread_bad')}",
        f"미끄러짐 {pct('slip_bad')}",
        f"확인약함 {pct('weak_confirm')}",
    ])


def _v572_delta_lines(good_flags: Dict[str, Any], bad_flags: Dict[str, Any]) -> List[str]:
    keys = [
        ('late_chase', '늦은추격'),
        ('numeric_fresh_bad', '숫자신선도지연'),
        ('fresh_text_only', '문구만신선도'),
        ('spread_bad', '스프레드위험'),
        ('slip_bad', '미끄러짐위험'),
        ('weak_confirm', '확인신호약함'),
    ]
    gn = max(1, int(good_flags.get('n') or 0))
    bn = max(1, int(bad_flags.get('n') or 0))
    scored=[]
    for k,name in keys:
        gr=float(good_flags.get(k) or 0)/gn
        br=float(bad_flags.get(k) or 0)/bn
        scored.append((br-gr,name,gr,br))
    scored.sort(reverse=True, key=lambda x:x[0])
    out=[]
    for diff,name,gr,br in scored[:4]:
        out.append(f"- {name}: 좋았던구간 {gr*100:.0f}% → 나빠진구간 {br*100:.0f}% / 차이 {diff*100:+.0f}%p")
    return out or ['- 표본부족']


def write_trade_review_cache_v572(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 900) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        # 현재 복기상 가장 깨끗했던 구간과 급락 구간을 명시 비교한다.
        good_rows = _v572_version_rows(primary_rows, ('v2.13.461',))
        bad_rows = _v572_version_rows(primary_rows, ('v2.13.462','v2.13.463'))
        if not good_rows:
            # fallback: 앞 절반
            half = len(primary_rows)//2
            good_rows = primary_rows[:half]
        if not bad_rows:
            half = len(primary_rows)//2
            bad_rows = primary_rows[half:]
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        late_cases = [_v570_case(r) for r in late_losses]
        last_cases = [_v570_case(r) for r in last16_losses]
        safe_all = _v570_filter_safe(primary_rows)
        safe_late = _v570_filter_safe(late)
        good_flags = _v572_case_flags(good_rows)
        bad_flags = _v572_case_flags(bad_rows)
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        for r in primary_rows:
            by_version.setdefault(_main_version_key(r), []).append(r)
        version_lines=[]
        for vk, arr in sorted(by_version.items(), key=lambda kv: str(kv[0]), reverse=True)[:6]:
            version_lines.append(f"- {vk}: {_v569_stat_line(arr)}")
        summary_lines = [
            '📉 후반 손실군 복기 /trade_review · v572 구간비교+신선도 보강판',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[초반 vs 후반]',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근 16전: {_v569_stat_line(last16)}" if last16 else '- 최근 16전: 표본부족',
            '',
            '[좋았던 구간 vs 나빠진 구간]',
            f"- 좋았던 구간(v2.13.461 중심): {_v569_stat_line(good_rows)}",
            f"- 나빠진 구간(v2.13.462~463 중심): {_v569_stat_line(bad_rows)}",
            f"- 좋았던 구간 위험률: {_v572_rate_line(good_flags)}",
            f"- 나빠진 구간 위험률: {_v572_rate_line(bad_flags)}",
            '[차이 TOP]',
            *_v572_delta_lines(good_flags, bad_flags),
            '',
            '[후반 손실군 원인 세분화]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(_v570_counter(late_cases), 8)}",
            f"- 최근16 손실 {len(last16_losses)}개: {_v569_top(_v570_counter(last_cases), 8)}",
            f"- 복기판정: {_v569_top(_v570_action_counter(late_cases), 6)}",
            '',
            '[가상 제외 참고 · 조건 변경 아님]',
            f"- 전체 주분석 전략 원본: {_v569_stat_line(primary_rows)}" if primary_rows else '- 원본: 표본부족',
            f"- 숫자 신선도지연+늦은추격/실행위험 의심 제외 시: {_v569_stat_line(safe_all)}" if primary_rows else '- 제외 참고: 표본부족',
            f"- 후반만 같은 기준 제외 시: {_v569_stat_line(safe_late)}" if late else '- 후반 제외 참고: 표본부족',
            '',
            '[후반 손실 샘플]',
            *(_v570_case_line(c) for c in late_cases[:5]),
            '',
            '[오늘 버전별 · 주분석 전략]',
            *(version_lines or ['- 표본부족']),
            '',
            '[판독]',
            '- 좋았던 구간과 나빠진 구간의 차이가 신선도/늦은추격/실행위험에 몰리면 조건 변경보다 정보 사전보강 루프를 우선한다.',
            '- 보강 방향: S2가 방아쇠 근접하면 target_router/orderflow/micro 긴급갱신 → 갱신값으로 재판정 → 실패+늦은추격이면 S1 금지/S2 보류.',
            '- 이 cache는 복기/설계용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v572_good_bad_compare',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'good_window_versions': ['v2.13.461'],
            'bad_window_versions': ['v2.13.462','v2.13.463'],
            'good_window_stat': _v569_stat(good_rows),
            'bad_window_stat': _v569_stat(bad_rows),
            'good_window_flags': good_flags,
            'bad_window_flags': bad_flags,
            'safe_all_stat_reference_only': _v569_stat(safe_all),
            'safe_late_stat_reference_only': _v569_stat(safe_late),
            'late_loss_count': len(late_losses),
            'last16_loss_count': len(last16_losses),
            'late_loss_split_top': _v570_counter(late_cases),
            'last16_loss_split_top': _v570_counter(last_cases),
            'late_review_action_top': _v570_action_counter(late_cases),
            'late_loss_cases_sample': late_cases[:20],
            'primary_version_stats': {vk: _v569_stat(arr) for vk, arr in by_version.items()},
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v572', exc)








# =============================================================================
# paper_bot v0.200 / v578: 최고수익 대비 최종수익 복기 cache
# - 청산조건 변경 없음. 보호익절 강화 여부를 결정하기 위한 복기 전용이다.
# - paper_bot은 CLOSED/trade_log/review cache 주인이다.
# - 목적: AZTEC처럼 +1% 이상 갔다가 거의 못 먹은 케이스를 따로 집계한다.
# =============================================================================


def _v578_peak_bucket(row: Dict[str, Any]) -> str:
    peak = fnum(row.get('peak_pct'), default=fnum(row.get('pnl_pct'), default=0.0))
    if peak >= 1.30:
        return 'peak_1_30_plus'
    if peak >= 1.00:
        return 'peak_1_00_plus'
    if peak >= 0.70:
        return 'peak_0_70_plus'
    if peak >= 0.35:
        return 'peak_0_35_plus'
    return 'peak_under_0_35'


def _v578_floor_for_peak(peak: float) -> Optional[float]:
    # 복기용 가상 계단. 실제 청산조건은 변경하지 않는다.
    if peak >= 1.30:
        return 0.80
    if peak >= 1.00:
        return 0.55
    if peak >= 0.70:
        return 0.30
    return None


def _v578_giveback_case(row: Dict[str, Any]) -> Dict[str, Any]:
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    peak = fnum(row.get('peak_pct'), default=pnl)
    giveback = max(0.0, peak - pnl)
    floor = _v578_floor_for_peak(peak)
    floor_gap = 0.0 if floor is None else max(0.0, floor - pnl)
    reason = str(row.get('exit_reason') or row.get('reason') or row.get('close_reason') or '-')
    ticker = normalize_ticker(row.get('ticker') or row.get('symbol') or '-')
    return {
        'ticker': ticker,
        'strategy': _strategy_key(row),
        'version': _main_version_key(row),
        'pnl_pct': round(pnl, 4),
        'peak_pct': round(peak, 4),
        'giveback_pct': round(giveback, 4),
        'peak_bucket': _v578_peak_bucket(row),
        'protect_floor_reference': floor,
        'floor_gap_reference': round(floor_gap, 4),
        'reason': reason,
        'close_review_tag': row.get('close_review_tag') or '',
        'age_min': round(fnum(row.get('age_min') or row.get('hold_minutes'), default=0.0), 3),
        'entry_price': row.get('entry_price'),
        'exit_price': row.get('exit_price') or row.get('close_price'),
    }


def _v578_avg(vals: List[float]) -> float:
    vals=[float(v) for v in vals if v is not None]
    return round(sum(vals)/len(vals), 4) if vals else 0.0


def _v578_peak_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    cases=[_v578_giveback_case(r) for r in rows]
    peak70=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 0.70]
    peak100=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 1.00]
    heavy=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 0.70 and fnum(c.get('giveback_pct'), default=0.0) >= 0.55]
    severe=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 1.00 and fnum(c.get('pnl_pct'), default=0.0) <= 0.20]
    floor_miss=[c for c in cases if c.get('protect_floor_reference') is not None and fnum(c.get('floor_gap_reference'), default=0.0) > 0.0]
    return {
        'n': len(cases),
        'peak70_n': len(peak70),
        'peak100_n': len(peak100),
        'heavy_giveback_n': len(heavy),
        'peak100_low_final_n': len(severe),
        'floor_miss_n': len(floor_miss),
        'avg_peak_pct': _v578_avg([fnum(c.get('peak_pct'), default=0.0) for c in cases]),
        'avg_pnl_pct': _v578_avg([fnum(c.get('pnl_pct'), default=0.0) for c in cases]),
        'avg_giveback_pct': _v578_avg([fnum(c.get('giveback_pct'), default=0.0) for c in cases]),
        'peak70_avg_giveback_pct': _v578_avg([fnum(c.get('giveback_pct'), default=0.0) for c in peak70]),
        'top_giveback_cases': sorted(cases, key=lambda c: fnum(c.get('giveback_pct'), default=0.0), reverse=True)[:12],
        'floor_miss_cases': sorted(floor_miss, key=lambda c: fnum(c.get('floor_gap_reference'), default=0.0), reverse=True)[:12],
    }


def _v578_case_line(c: Dict[str, Any]) -> str:
    floor = c.get('protect_floor_reference')
    floor_txt = '-' if floor is None else f"+{float(floor):.2f}%"
    return (
        f"- {c.get('ticker','-')}: 최종 {fnum(c.get('pnl_pct'), default=0.0):+.2f}% / "
        f"최고 {fnum(c.get('peak_pct'), default=0.0):+.2f}% / "
        f"반납 {fnum(c.get('giveback_pct'), default=0.0):+.2f}% / "
        f"가상보호 {floor_txt} / {c.get('reason','-')}"
    )


def _v578_short_stat_line(st: Dict[str, Any]) -> str:
    n = int(st.get('n') or 0)
    if n <= 0:
        return '표본부족'
    return (
        f"표본 {n} / +0.7%도달 {int(st.get('peak70_n') or 0)} / +1.0%도달 {int(st.get('peak100_n') or 0)} / "
        f"큰반납 {int(st.get('heavy_giveback_n') or 0)} / +1%→최종+0.2%이하 {int(st.get('peak100_low_final_n') or 0)} / "
        f"평균최고 {fnum(st.get('avg_peak_pct'), default=0.0):+.2f}% / 평균최종 {fnum(st.get('avg_pnl_pct'), default=0.0):+.2f}% / 평균반납 {fnum(st.get('avg_giveback_pct'), default=0.0):+.2f}%"
    )


def write_trade_review_cache_v578(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        # 기존 v572 신선도/타이밍 복기도 같이 유지한다.
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        late_cases = [_v570_case(r) for r in late_losses]
        safe_all = _v570_filter_safe(primary_rows)
        all_peak = _v578_peak_stats(primary_rows)
        late_peak = _v578_peak_stats(late)
        last16_peak = _v578_peak_stats(last16)
        top_cases = all_peak.get('top_giveback_cases') or []
        floor_cases = all_peak.get('floor_miss_cases') or []
        summary_lines = [
            '📉 복기 /trade_review · v578 최고수익 반납 확인판',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건·청산 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[성과 흐름]',
            f"- 전체: {_v569_stat_line(primary_rows)}" if primary_rows else '- 전체: 표본부족',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근16: {_v569_stat_line(last16)}" if last16 else '- 최근16: 표본부족',
            '',
            '[최고수익 반납]',
            f"- 전체: {_v578_short_stat_line(all_peak)}",
            f"- 후반: {_v578_short_stat_line(late_peak)}",
            f"- 최근16: {_v578_short_stat_line(last16_peak)}",
            '',
            '[수익 돌려준 상위]',
            *( [_v578_case_line(c) for c in top_cases[:5]] or ['- 표본부족'] ),
            '',
            '[가상 보호계단 참고 · 청산 변경 아님]',
            '- 기준 예시: 최고 +0.70%→최소 +0.30%, 최고 +1.00%→최소 +0.55%, 최고 +1.30%→최소 +0.80%',
            f"- 보호계단보다 낮게 끝난 후보: {int(all_peak.get('floor_miss_n') or 0)}개",
            *( [_v578_case_line(c) for c in floor_cases[:5]] or ['- 해당 없음'] ),
            '',
            '[후반 손실 원인 참고]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(_v570_counter(late_cases), 8)}",
            f"- 신선도지연+늦은추격 의심 제외 시: {_v569_stat_line(safe_all)}" if primary_rows else '- 제외 참고: 표본부족',
            '',
            '[판독]',
            '- +0.7~1.0% 이상 갔다가 거의 못 먹는 케이스가 반복되면 다음 단계에서 보호익절 계단 강화를 검토한다.',
            '- PHA 같은 최고수익 0 근처 빠른실패는 청산 방어가 맞고, AZTEC처럼 +1% 이상 갔다가 +0.1% 근처 종료된 케이스는 보호익절 복기 대상이다.',
            '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v578_peak_giveback',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'overall_stat': _v569_stat(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'overall_peak_giveback': all_peak,
            'late_peak_giveback': late_peak,
            'last16_peak_giveback': last16_peak,
            'safe_all_stat_reference_only': _v569_stat(safe_all),
            'late_loss_split_top': _v570_counter(late_cases),
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v578', exc)






# =============================================================================

# [v582 cleanup] removed stale duplicate writer block.


# =============================================================================
# paper_bot v0.205 / v582: paper spine final surgery
# - No new strategy/exit condition changes.
# - One cycle reads active paper rows once and writes status/handoff/trace from the same snapshot.
# - Startup/heartbeat also overwrites stale handoff with current VERSION so old handoff cannot survive.
# =============================================================================


def _v582_stage_key(ev: Dict[str, Any]) -> str:
    v = str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('stage') or ev.get('grade') or '').upper().strip()
    if v in {'S1','S2','S3'}:
        return v
    if v in {'X','EXCLUDE','EXCLUDED','BLOCK','BLOCKED'}:
        return 'X'
    return v or '-'


def _v582_active_rows(ctrl: Optional[Dict[str, Any]] = None, max_rows: int = 800) -> List[Dict[str, Any]]:
    try:
        ctrl = ctrl or load_control()
        limit = int(fnum(ctrl.get('candidate_read_max_lines'), default=max_rows))
        limit = max(100, min(max_rows, limit))
        rows = [dict(r) for r in read_jsonl_tail(FILES['paper_latest'], limit) if isinstance(r, dict)]
        try:
            return latest_scan_filter(rows, ctrl)
        except Exception as exc:
            log_error('v582_latest_scan_filter', exc)
            return rows
    except Exception as exc:
        log_error('v582_active_rows', exc)
        return []


def _v582_make_snapshot(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], pick_stats: Optional[Dict[str, Any]], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    pick = dict(pick_stats or {})
    fresh_n = 0
    for r in rows:
        try:
            if candidate_is_fresh(r, ctrl):
                fresh_n += 1
        except Exception:
            pass
    stage_counts = Counter(_v582_stage_key(r) for r in rows)
    nowv = now_ts()
    snapshot = {
        'schema': 'paper_candidate_snapshot_v584_direct_rows',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'snapshot_id': f"v584-{int(nowv*1000)}",
        'snapshot_owner': 'paper_bot',
        'snapshot_rule': 'direct active rows -> one status/handoff/trace writer; paper reads strategy canonical_metric_row',
        'latest_count': len(rows),
        'paper_latest_count': len(rows),
        'active_latest_count': len(rows),
        'latest_lines': len(rows),
        'merged_fresh': fresh_n,
        'fresh_count': fresh_n,
        'fresh_source': 'v584_direct_active_rows_candidate_is_fresh',
        'stage_counts': dict(stage_counts),
        's1_count': int(stage_counts.get('S1', 0)),
        's2_count': int(stage_counts.get('S2', 0)),
        's3_count': int(stage_counts.get('S3', 0)),
        'x_count': int(stage_counts.get('X', 0)),
        'open_count': len(open_pos) if isinstance(open_pos, dict) else 0,
        'open_total': len(open_pos) if isinstance(open_pos, dict) else 0,
        'writer': 'v584_direct_spine_writer',
    }
    # Mirror snapshot values into pick_stats so /pstatus and main bot readers do not borrow stale handoff values.
    pick.update({
        'latest_count': snapshot['latest_count'],
        'paper_latest_count': snapshot['paper_latest_count'],
        'active_latest_count': snapshot['active_latest_count'],
        'merged_fresh': snapshot['merged_fresh'],
        'fresh_count': snapshot['fresh_count'],
        'fresh_source': snapshot['fresh_source'],
        'stage_counts': snapshot['stage_counts'],
        's1_seen': int(pick.get('s1_seen') or snapshot['s1_count']),
        'paper_candidate_snapshot': snapshot,
        'snapshot_schema': snapshot['schema'],
        'snapshot_id': snapshot['snapshot_id'],
        'writer': 'v584_direct_spine_writer',
    })
    return snapshot, pick


def _v582_minimal_trace(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], err: str = '') -> Dict[str, Any]:
    out = []
    for ev in (rows or [])[:120]:
        if not isinstance(ev, dict):
            continue
        try:
            eid = event_id(ev)
            out.append({
                'trace_id': eid,
                'ticker': normalize_ticker(ev.get('ticker') or ev.get('symbol') or ev.get('market')),
                'stage': _v582_stage_key(ev),
                'fresh': candidate_is_fresh(ev, ctrl),
                'open': eid in open_pos,
                'strategy': ev.get('strategy_label') or ev.get('strategy') or ev.get('strategy_key'),
                'status': 'open' if eid in open_pos else 'observed',
            })
        except Exception:
            continue
    return {
        'schema': 'paper_candidate_handoff_trace_v584_minimal',
        'version': VERSION,
        'trace_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'rows': out,
        'fallback_reason': err,
    }


def _v582_write_spine(status: Dict[str, Any], trace_obj: Dict[str, Any], snapshot: Dict[str, Any], pick_stats: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> None:
    nowv = now_ts()
    trace_rows = trace_obj.get('rows') if isinstance(trace_obj.get('rows'), list) else []
    common = {
        'version': VERSION,
        'paper_version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', snapshot.get('latest_count', 0)),
        'active_latest_count': snapshot.get('active_latest_count', snapshot.get('latest_count', 0)),
        'latest_lines': snapshot.get('latest_lines', snapshot.get('latest_count', 0)),
        'merged_fresh': snapshot.get('merged_fresh', snapshot.get('fresh_count', 0)),
        'fresh_count': snapshot.get('fresh_count', snapshot.get('merged_fresh', 0)),
        'fresh_source': snapshot.get('fresh_source'),
        'open_count': len(open_pos) if isinstance(open_pos, dict) else 0,
        'open_total': len(open_pos) if isinstance(open_pos, dict) else 0,
        'stage_counts': snapshot.get('stage_counts', {}),
        'snapshot_id': snapshot.get('snapshot_id'),
        'snapshot_schema': snapshot.get('schema'),
        'paper_candidate_snapshot': snapshot,
        'pick_stats': pick_stats,
        'writer': 'v584_direct_spine_writer',
        'cache_spine': 'v584 direct single writer: status/handoff/trace + canonical metric row review',
    }
    trace_out = dict(trace_obj or {})
    trace_out.update(common)
    trace_out.update({
        'schema': 'paper_candidate_handoff_trace_v584_direct_spine',
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
    })
    handoff = dict(common)
    handoff.update({
        'schema': 'paper_handoff_status_v584_direct_spine',
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
    })
    # v745: handoff/status가 같은 runtime trace summary를 보게 한다.
    # main_bot은 계산하지 않고 paper_bot이 봉인한 값만 표시한다.
    for _k in (
        'hold_trace_summary_v736',
        'hold_trace_summary_v743',
        'stop_overrun_summary_v745',
        'exit_loop_probe_v745',
    ):
        if _k in (status or {}):
            handoff[_k] = (status or {}).get(_k)
    status_out = dict(status or {})
    status_out.update(common)
    status_out.update({
        'schema': 'paper_status_v584_direct_spine',
        'running': bool(status_out.get('running', True)),
        'process_alive': True,
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
        'cache_spine_version': 'v584',
    })
    # Direct writes only. Do not call old write_status here; that path only owns process heartbeat.
    save_json(FILES['trace'], trace_out)
    save_json(FILES['handoff_status'], handoff)
    save_json(FILES['status'], status_out)
    globals()['_LAST_STATUS'] = status_out
    try:
        write_pid()
    except Exception:
        pass




# =============================================================================
# paper_bot v0.207 / v584: canonical metric row reader
# - paper_bot은 strategy_worker가 봉인한 canonical_metric_row를 읽기만 한다.
# - 구조/fresh/실행위험을 paper에서 재판정하지 않는다.
# - OPEN/CLOSED/score/review 기능 유지.
# =============================================================================

def _v584_get_canonical_metric(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    cm = row.get('canonical_metric_row')
    if isinstance(cm, dict):
        return cm
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    cm = ctx.get('canonical_metric_row')
    return cm if isinstance(cm, dict) else {}


def _v584_metric_counter(rows: List[Dict[str, Any]], path: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows or []:
        cm = _v584_get_canonical_metric(r)
        v: Any = cm
        for k in path:
            if isinstance(v, dict):
                v = v.get(k)
            else:
                v = None
                break
        if v:
            c[str(v)] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v584_entry_reaction_bucket(row: Dict[str, Any]) -> str:
    peak = num(row.get('peak_profit_pct'), row.get('max_profit_pct'), default=0.0)
    final = num(row.get('pnl_pct'), row.get('profit_pct'), default=0.0)
    low = num(row.get('max_loss_pct'), row.get('min_profit_pct'), default=0.0)
    reason = str(row.get('close_reason') or row.get('exit_reason') or '')
    if peak < 0.15 and final <= -0.20:
        return '진입후무반응/빠른실패'
    if peak >= 0.70 and (peak - final) >= 0.50:
        return '최고수익반납'
    if 'stop' in reason or '손절' in reason:
        return '손절정리'
    if final > 0:
        return '수익청산'
    return '기타/표본'


def _v584_canonical_review_block(rows: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    with_canon = [r for r in rows if _v584_get_canonical_metric(r)]
    react_counter: Counter = Counter(_v584_entry_reaction_bucket(r) for r in rows)
    data = {
        'schema': 'paper_trade_review_canonical_metric_row_v584',
        'row_count': len(rows),
        'with_canonical_metric_row': len(with_canon),
        'structure_state_top': _v584_metric_counter(with_canon, ('structure','state'), 5),
        'freshness_top': _v584_metric_counter(with_canon, ('freshness_map','overall'), 5),
        'execution_risk_top': _v584_metric_counter(with_canon, ('execution_risk','state'), 5),
        'decision_top': _v584_metric_counter(with_canon, ('decision_reference',), 5),
        'entry_reaction_top': ' / '.join(f'{k} {v}' for k, v in react_counter.most_common(5)) if react_counter else '-',
    }
    lines = ['[canonical row 복기 · v584]']
    if not rows:
        lines.append('- 오늘 CLOSED 없음 또는 표본부족')
    elif not with_canon:
        lines.append('- 신규 v584 이후 CLOSED부터 canonical_metric_row가 누적됩니다.')
    else:
        lines += [
            f"- canonical 보유 {len(with_canon)}/{len(rows)}개",
            f"- 구조 TOP: {data['structure_state_top']}",
            f"- fresh TOP: {data['freshness_top']}",
            f"- 실행위험 TOP: {data['execution_risk_top']}",
            f"- 판정 TOP: {data['decision_top']}",
        ]
    lines.append(f"- 진입반응 TOP: {data['entry_reaction_top']}")
    return lines, data

_v582_base_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v582_base_write_score_cache(status)
    try:
        write_trade_review_cache_v578(status)
        obj = load_json(FILES['trade_review'], {}) or {}
        if isinstance(obj, dict):
            try:
                rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
                today_rows = _v557_filter_today(rows, now_ts())
                block_lines, block_data = _v584_canonical_review_block(today_rows)
                summary = str(obj.get('summary_text') or '')
                if '[구조×신선도 복기]' not in summary:
                    obj['summary_text'] = summary + ('\n\n' if summary else '') + '\n'.join(block_lines)
                obj['canonical_metric_row_review'] = block_data
            except Exception as exc:
                log_error('v584_canonical_metric_review', exc)
            obj['schema'] = 'paper_trade_review_cache_v584_canonical_metric_row'
            obj['version'] = VERSION
            obj['paper_version'] = VERSION
            obj['build'] = BUILD_LABEL
            obj['writer'] = 'v584_direct_spine_writer'
            save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v584', exc)


_v582_base_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    """Heartbeat/status writes cannot leave stale handoff behind.
    When called outside run_cycle, it still writes a light same-version handoff/trace snapshot.
    """
    try:
        st = dict(status or {})
        st.update({"version": VERSION, "paper_version": VERSION, "active_reader_version": VERSION, "build": BUILD_LABEL, "build_owner_v736": "paper_bot_v736_single_status_spine"})
        ctrl = load_control()
        open_pos = load_open()
        rows = _v582_active_rows(ctrl)
        snapshot, pick = _v582_make_snapshot(rows, ctrl, st.get('pick_stats') if isinstance(st.get('pick_stats'), dict) else {}, open_pos)
        trace_obj = _v582_minimal_trace(rows, ctrl, open_pos, 'status_heartbeat')
        st.setdefault('engine', 'light_runner')
        st.setdefault('running', True)
        _v582_write_spine(st, trace_obj, snapshot, pick, open_pos)
    except Exception as exc:
        log_error('v584_write_status_spine', exc)
        _v582_base_write_status(status)



def _v736_hold_trace_summary(limit: int = 240) -> Dict[str, Any]:
    rows = read_jsonl_tail(FILES.get("s1_hold_trace", BASE_DIR / "paper_s1_hold_consume_trace.jsonl"), limit)
    status = Counter()
    reason = Counter()
    final_hold_reason = Counter()
    expired_reason = Counter()
    for r in rows:
        if not isinstance(r, dict):
            continue
        s = str(r.get("status") or "-")
        status[s] += 1
        raw = r.get("reason")
        vals = raw if isinstance(raw, list) else [raw]
        for x in vals:
            if x in (None, "", [], {}):
                continue
            tx = str(x)[:160]
            reason[tx] += 1
            if s == "paper_final_hold":
                final_hold_reason[tx] += 1
            if s in ("candidate_expired", "expired"):
                expired_reason[tx] += 1
    return {
        "schema": "paper_hold_trace_summary_v736",
        "version": VERSION,
        "build": BUILD_LABEL,
        "tail": len(rows),
        "status_counts": dict(status.most_common(12)),
        "reason_top": dict(reason.most_common(10)),
        "paper_final_hold_reason_top": dict(final_hold_reason.most_common(10)),
        "candidate_expired_reason_top": dict(expired_reason.most_common(10)),
    }



def _v743_counter_dict(counter: Counter, limit: int = 10) -> Dict[str, int]:
    return {str(k): int(v) for k, v in counter.most_common(limit)}


def _v743_hold_trace_summary(cycle_started_at: float = 0.0, limit: int = 300) -> Dict[str, Any]:
    rows = [r for r in read_jsonl_tail(FILES.get("s1_hold_trace", BASE_DIR / "paper_s1_hold_consume_trace.jsonl"), limit) if isinstance(r, dict)]
    nowv = now_ts()
    windows = {
        "cycle": float(cycle_started_at or 0.0),
        "last60s": nowv - 60.0,
        "last5m": nowv - 300.0,
        "tail": 0.0,
    }
    status_counts: Dict[str, Dict[str, int]] = {}
    final_reasons: Dict[str, Dict[str, int]] = {}
    expired_reasons: Dict[str, Dict[str, int]] = {}
    preopen_reasons: Dict[str, Dict[str, int]] = {}
    recent_rows: Dict[str, List[Dict[str, Any]]] = {}

    for label, cutoff in windows.items():
        sc = Counter()
        fc = Counter()
        ec = Counter()
        pc = Counter()
        rlist: List[Dict[str, Any]] = []
        for r in rows:
            ts = fnum(r.get("ts"), r.get("created_at"), default=0.0)
            if cutoff > 0 and ts < cutoff:
                continue
            st = str(r.get("status") or "-")
            sc[st] += 1
            raw = r.get("reason")
            vals = raw if isinstance(raw, list) else [raw]
            for x in vals:
                if x in (None, "", [], {}):
                    continue
                tx = str(x)[:140]
                if st == "paper_final_hold":
                    fc[tx] += 1
                if st in ("candidate_expired", "expired"):
                    ec[tx] += 1
                if "OPEN 직전" in tx or "늦은추격" in tx or "목표초과" in tx or "오래된 진입계획" in tx:
                    pc[tx] += 1
            if len(rlist) < 8:
                rlist.append({
                    "ts": ts,
                    "age_sec": round(max(0.0, nowv - ts), 1) if ts else None,
                    "ticker": normalize_ticker(r.get("ticker")),
                    "status": st,
                    "reason": raw if raw not in (None, "", []) else "-",
                    "hold_status": r.get("hold_status"),
                    "open_ready": bool(r.get("open_ready")),
                })
        status_counts[label] = _v743_counter_dict(sc, 12)
        final_reasons[label] = _v743_counter_dict(fc, 6)
        expired_reasons[label] = _v743_counter_dict(ec, 4)
        preopen_reasons[label] = _v743_counter_dict(pc, 4)
        recent_rows[label] = rlist

    return {
        "schema": "paper_hold_trace_summary_v743_current_cycle",
        "version": VERSION,
        "build": BUILD_LABEL,
        "cycle_started_at": cycle_started_at,
        "cycle_age_sec": round(max(0.0, nowv - float(cycle_started_at or nowv)), 1),
        "tail_rows": len(rows),
        "status_counts": status_counts,
        "final_hold_reason_top": final_reasons,
        "expired_reason_top": expired_reasons,
        "preopen_guard_top": preopen_reasons,
        "recent_rows": recent_rows,
        "updated_at": nowv,
        "updated_at_text": iso_ts(),
    }


def _v736_reseal_status_snapshot(status: Dict[str, Any], pick_stats: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], latest_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    st = dict(status or {})
    strict_n = _v734_strict_open_count(open_pos) if isinstance(open_pos, dict) else 0
    raw_n = len(open_pos) if isinstance(open_pos, dict) else 0
    st.update({
        "version": VERSION,
        "paper_version": VERSION,
        "active_reader_version": VERSION,
        "build": BUILD_LABEL,
        "build_owner_v736": "paper_bot_v736_single_status_spine",
        "status_spine_schema": "paper_status_spine_v736",
        "writer": "paper_v736_single_status_handoff_writer",
        "pick_stats": pick_stats if isinstance(pick_stats, dict) else {},
        "hold_trace_summary_v736": _v736_hold_trace_summary(),
        "hold_trace_summary_v743": _v743_hold_trace_summary(fnum(st.get("cycle_started_at"), default=0.0)),
        "open_total_raw_v736": raw_n,
        "strict_open_count_v736": strict_n,
        "legacy_or_bad_open_ignored_v736": max(0, raw_n - strict_n),
        "quarantine_total_v740": len(read_jsonl_tail(FILES.get("open_quarantine", BASE_DIR / "paper_bot_open_quarantine.jsonl"), 500)),
        "latest_rows_seen_v736": len(latest_rows or []),
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
    })
    return st

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    started = now_ts()
    ctrl = load_control()
    open_pos = load_open()
    quarantined_items = _v739_quarantine_open_positions(open_pos)
    if quarantined_items:
        save_open(open_pos)
    opened_items: List[Dict[str, Any]] = []
    closed_items: List[Dict[str, Any]] = []
    picked_ids: set[str] = set()
    opened_ids: set[str] = set()
    pick_stats: Dict[str, Any] = {}
    latest_rows: List[Dict[str, Any]] = []
    before_closed_count = line_count_cached(FILES['closed'], ttl=0)

    if ctrl.get('running', True):
        picked, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        latest_rows = [r for r in (latest_rows or []) if isinstance(r, dict)]
        for pid, ev in picked:
            picked_ids.add(pid)
            if pid in open_pos:
                continue
            try:
                pos = open_position(pid, ev)
                open_pos[pid] = pos
                opened_items.append(pos)
                opened_ids.add(pid)
                if _v734_is_hold(ev):
                    _v734_trace_hold(ev, "opened", "paper OPEN 등록", {"pos_id": pid, "ticker": pos.get("ticker"), "entry_price": pos.get("entry_price")})
            except Exception as exc:
                log_error('open_position', exc)
        for pid, pos in list(open_pos.items()):
            try:
                updated, closed = update_position(pos, ctrl)
                if closed:
                    closed_items.append(closed)
                    open_pos.pop(pid, None)
                    append_jsonl(FILES['closed'], closed)
                    _LAST_CLOSED_COUNT_CACHE.update({'ts': 0.0, 'count': 0})
                else:
                    open_pos[pid] = updated
            except Exception as exc:
                log_error('update_position', exc)
        save_open(open_pos)
    else:
        latest_rows = _v582_active_rows(ctrl)
        pick_stats['paused'] = 1

    # If an older select path returns no rows but the active paper file has rows, use the active file for status/trace only.
    if not latest_rows:
        latest_rows = _v582_active_rows(ctrl)

    snapshot, pick_stats = _v582_make_snapshot(latest_rows, ctrl, pick_stats, open_pos)
    try:
        trace_obj = build_trace(latest_rows, ctrl, open_pos, picked_ids, opened_ids)
    except Exception as exc:
        log_error('v584_build_trace', exc)
        trace_obj = _v582_minimal_trace(latest_rows, ctrl, open_pos, f'{type(exc).__name__}: {exc}')

    status = {
        'running': bool(ctrl.get('running', True)),
        'loop_seconds': ctrl.get('loop_seconds'),
        'opened_this_cycle': len(opened_items),
        'quarantined_this_cycle_v740': len(quarantined_items),
        'quarantined_this_cycle_v739': len(quarantined_items),
        'closed_this_cycle': len(closed_items),
        'open_total': len(open_pos),
        'open_count': len(open_pos),
        'open_strict': len(open_pos),
        'closed_total': line_count_cached(FILES['closed'], ttl=0 if closed_items else 60.0),
        'pick_stats': pick_stats,
        'quarantine_owner_v742': 'v678_direct_run_cycle_start',
        's1_hold_source': 'paper_s1_hold_cache.json',
        'elapsed_sec': round(now_ts() - started, 3),
        'engine': 'light_runner',
        'legacy_loop': False,
        'before_closed_count': before_closed_count,
        'writer': 'v584_direct_spine_writer',
    }

    status = _v736_reseal_status_snapshot(status, pick_stats, open_pos, latest_rows)
    if ctrl.get('write_score_cache', True):
        write_score_cache(status)
    _v582_write_spine(status, trace_obj, snapshot, pick_stats, open_pos)

    for pos in opened_items:
        try:
            notify_opened(pos)
        except Exception as exc:
            log_error('v584_notify_opened', exc)
            try:
                _v567_append_trade_alert_trace('open', pos, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'v584 notify_opened raised')
            except Exception:
                pass
    for row in closed_items:
        try:
            notify_closed(row)
        except Exception as exc:
            log_error('v584_notify_closed', exc)
            try:
                _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'v584 notify_closed raised')
            except Exception:
                pass

    notify_s1_decision_summary(pick_stats, opened_count=len(opened_items), closed_count=len(closed_items), ctrl=ctrl)
    notify_market_hot_summary(ctrl)
    try:
        log(f"{VERSION} cycle opened={len(opened_items)} quarantined={len(quarantined_items)} closed={len(closed_items)} open={len(open_pos)} elapsed={status['elapsed_sec']}s latest={snapshot.get('latest_count')} fresh={snapshot.get('merged_fresh')} snapshot={snapshot.get('snapshot_id')} writer=v584")
    except Exception:
        pass
    return status


_v582_base_pstatus_text = pstatus_text

def pstatus_text() -> str:  # type: ignore[override]
    status = load_json(FILES['status'], {}) or {}
    handoff = load_json(FILES['handoff_status'], {}) or {}
    trace = load_json(FILES['trace'], {}) or {}
    op = load_open()
    snap = status.get('paper_candidate_snapshot') if isinstance(status.get('paper_candidate_snapshot'), dict) else {}
    latest = status.get('latest_count', snap.get('latest_count', '-'))
    fresh = status.get('merged_fresh', snap.get('merged_fresh', '-'))
    lines = [
        f"🧪 paper 상태 /pstatus ({VERSION})",
        f"- running: {status.get('running', True)} / open {len(op)} / status age {_v561_age_from(status)} / handoff age {_v561_age_from(handoff)} / trace age {_v561_age_from(trace)}",
        f"- 이번 cycle: OPEN {status.get('opened_this_cycle',0)} / CLOSED {status.get('closed_this_cycle',0)} / elapsed {status.get('elapsed_sec','-')}s",
        f"- 후보: latest {latest} / fresh {fresh} / S1감지 {(status.get('pick_stats') or {}).get('s1_seen', snap.get('s1_count',0))} / S1선택 {(status.get('pick_stats') or {}).get('selected_s1',0)} / OPEN보류 {(status.get('pick_stats') or {}).get('paper_entry_hold', (status.get('pick_stats') or {}).get('paper_final_block',0))} / micro대기 {(status.get('pick_stats') or {}).get('micro_preopen_wait',0)}",
        f"- spine: status {status.get('version','-')} / handoff {handoff.get('version','-')} / trace {trace.get('version') or trace.get('trace_version') or '-'} / snapshot {status.get('snapshot_id') or snap.get('snapshot_id') or '-'}",
        "- writer: v584 direct_spine_writer / paper reads strategy canonical_metric_row only",
    ]
    return '\n'.join(lines)




# =============================================================================
# paper_bot v0.208 / v586: OPEN/CLOSED alert formatter source cleanup
# - 기능 삭제 없음. 알림에 표시하는 값의 source만 canonical_metric_row/entry_diagnostics로 통일한다.
# - 누락값을 +0.00으로 보정하지 않고 "정보없음" 또는 "-"로 표시한다.
# - 구 entry_timing_trace와 canonical timing_spine을 동시에 보여주는 중복 표시를 제거한다.
# - 조건/S등급/청산/OPEN/CLOSED/장부/score/cache는 변경하지 않는다.
# =============================================================================

def _v586_present(v: Any) -> bool:
    if v is None:
        return False
    if isinstance(v, str) and not v.strip():
        return False
    return True


def _v586_to_float(v: Any) -> Optional[float]:
    if not _v586_present(v):
        return None
    try:
        return float(str(v).replace(',', '').replace('%', '').strip())
    except Exception:
        return None


def _v586_first_present_from(obj: Any, keys: Iterable[str]) -> Tuple[Any, str]:
    if not isinstance(obj, dict):
        return None, ''
    for k in keys:
        if k in obj and _v586_present(obj.get(k)):
            return obj.get(k), k
    return None, ''


def _v586_nested(obj: Any, path: Iterable[str]) -> Any:
    cur = obj
    for k in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(k)
    return cur


def _v586_get_canonical_metric(row: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    sources: List[Any] = []
    if isinstance(row, dict):
        sources.append(row)
        if isinstance(row.get('entry_context'), dict):
            sources.append(row.get('entry_context'))
        if isinstance(row.get('entry_diagnostics'), dict):
            sources.append(row.get('entry_diagnostics'))
    if isinstance(diag, dict):
        sources.append(diag)
    for src in sources:
        cm = src.get('canonical_metric_row') if isinstance(src, dict) else None
        if isinstance(cm, dict):
            return cm
    return {}


def _v586_metric(row: Dict[str, Any], diag: Dict[str, Any], canonical: Dict[str, Any], metric_key: str, fallback_keys: Iterable[str] = ()) -> Tuple[Optional[float], str]:
    mv = _v586_nested(canonical, ('metrics', metric_key))
    # canonical v584 metrics may contain 0.0 defaults, so only trust it when the original row/diag also had the key
    for src_name, src in (('diag', diag), ('row', row), ('ctx', row.get('entry_context') if isinstance(row, dict) else {})):
        if not isinstance(src, dict):
            continue
        v, k = _v586_first_present_from(src, [metric_key, *fallback_keys])
        fv = _v586_to_float(v)
        if fv is not None:
            return fv, f'{src_name}.{k}'
    fv = _v586_to_float(mv)
    if fv is not None and abs(fv) > 0.000001:
        return fv, f'canonical.metrics.{metric_key}'
    return None, ''


def _v586_pct(v: Optional[float], *, signed: bool = True, missing: str = '정보없음') -> str:
    if v is None:
        return missing
    return f'{v:+.2f}%' if signed else f'{v:.2f}%'


def _v586_num(v: Optional[float], *, missing: str = '정보없음', digits: int = 2) -> str:
    if v is None:
        return missing
    return f'{v:.{digits}f}'


def _v586_label_list(values: Any, limit: int = 5) -> str:
    if not isinstance(values, list):
        return ''
    vals = [str(x).strip() for x in values if str(x).strip()]
    return ' / '.join(vals[:limit])


def _v586_flow_value(row: Dict[str, Any], diag: Dict[str, Any], window: str) -> str:
    # Prefer the existing flow_window_map because it preserves missing-vs-zero.
    val = _paper_v479_flow_display(diag, window)
    if val != '-':
        return val
    keysets = {
        '1m': ('flow_1m_pct','change_1m','chg_1m','ret_1m_pct','price_change_1m'),
        '3m': ('flow_3m_pct','change_3m','chg_3m','ret_3m_pct','price_change_3m'),
        '5m': ('flow_5m_pct','change_5m','chg_5m','ret_5m_pct','price_change_5m'),
        '15m': ('flow_15m_pct','change_15m','chg_15m','ret_15m_pct','price_change_15m'),
    }
    for src in (diag, row, row.get('entry_context') if isinstance(row, dict) else {}):
        if not isinstance(src, dict):
            continue
        v, _ = _v586_first_present_from(src, keysets.get(window, ()))
        fv = _v586_to_float(v)
        if fv is not None:
            return f'{fv:+.2f}%'
    return '-'



# =============================================================================
# paper_bot v0.224 / v620: trigger gate display + last-mile consistency check
# - paper는 새 매수 판단을 만들지 않는다. strategy canonical trigger_gate를 읽어
#   S1_PASS와 실제 entry/current price가 어긋난 경우만 실행 직전 차단한다.
# - CLOSED 알림의 "진입 당시 확인값" 이모지를 손절/결과 이모지와 분리한다.
# =============================================================================
def _v620_first_dict(*items: Any) -> Dict[str, Any]:
    for item in items:
        if isinstance(item, dict) and item:
            return item
    return {}


def _v620_trigger_gate_from_sources(row: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    diag = diag if isinstance(diag, dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    canonical = _v586_get_canonical_metric(row, diag) if '_v586_get_canonical_metric' in globals() else {}
    cm_struct = canonical.get('structure') if isinstance(canonical.get('structure'), dict) else {}
    levels = _v620_first_dict(
        row.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'),
        cm_struct.get('levels') if isinstance(cm_struct, dict) else {},
    )
    plan = _v620_first_dict(row.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'), canonical.get('entry_plan') if isinstance(canonical, dict) else {})
    sealed = _v620_first_dict(row.get('trigger_gate'), diag.get('trigger_gate'), ctx.get('trigger_gate'), canonical.get('trigger_gate') if isinstance(canonical, dict) else {})
    price = fnum(row.get('entry_price'), row.get('current_price'), row.get('detected_price'), diag.get('entry_price'), default=0.0)
    trigger = fnum(sealed.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), row.get('trigger_price'), default=0.0)
    reached = bool(sealed.get('trigger_reached')) if sealed else False
    if price and trigger:
        reached = bool(price >= trigger * 0.999)
    gap = None
    try:
        if price and trigger:
            gap = round((price - trigger) / trigger * 100.0, 3)
    except Exception:
        gap = None
    reason = '방아쇠 도달 확인' if reached else ('방아쇠 가격 없음' if not trigger else f'방아쇠 미도달: 진입 {fmt_price(price)} < 방아쇠 {fmt_price(trigger)}')
    return {
        'schema': 'paper_trigger_gate_v620',
        'entry_price': price or None,
        'trigger_price': trigger or None,
        'trigger_reached': reached,
        'trigger_gap_pct': gap,
        'reason': reason,
        'source_schema': sealed.get('schema') if sealed else 'derived_from_structure_levels',
    }



def _v739_pick_first_num(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        x = fnum(v, default=0.0)
        if x:
            return x
    return default


def _v751_candidate_source_age(ev: Dict[str, Any]) -> float:
    """Freshness of the current sealed event, not legacy first_seen/S2 timing."""
    ts = _v739_pick_first_num(
        ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("event_ts"),
        ev.get("detected_ts"), ev.get("created_at"), ev.get("updated_ts"), default=0.0,
    )
    if ts <= 0:
        return 999999.0
    return max(0.0, now_ts() - ts)


def _v751_official_candle_age_from_event(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> float:
    diag = diag if isinstance(diag, dict) else {}
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    raw = ev.get("official_structure_inputs_raw") if isinstance(ev.get("official_structure_inputs_raw"), dict) else {}
    return _v739_pick_first_num(
        ev.get("official_candle_age"), raw.get("official_candle_age"), ctx.get("official_candle_age"),
        diag.get("official_candle_age"), default=0.0,
    )


def _v739_preopen_plan_safety_reasons(ev: Dict[str, Any], diag: Dict[str, Any], ctrl: Dict[str, Any]) -> List[str]:
    """OPEN 직전 실행 안전문.

    전략 조건을 다시 판단하지 않고, 이미 S1 hold로 통과한 후보가
    목표를 넘어서거나 오래된 진입계획으로 늦게 추격되는지만 차단한다.
    """
    reasons: List[str] = []
    diag = diag if isinstance(diag, dict) else {}
    levels = diag.get("structure_levels") if isinstance(diag.get("structure_levels"), dict) else {}
    plan = diag.get("entry_plan") if isinstance(diag.get("entry_plan"), dict) else {}
    rr = diag.get("risk_reward") if isinstance(diag.get("risk_reward"), dict) else {}
    trigger_gate = diag.get("trigger_gate") if isinstance(diag.get("trigger_gate"), dict) else _v620_trigger_gate_from_sources(ev, diag)

    entry_price = _v739_pick_first_num(
        trigger_gate.get("entry_price") if isinstance(trigger_gate, dict) else None,
        ev.get("entry_price"),
        ev.get("current_price"),
        ev.get("price"),
        default=0.0,
    )

    target_high = _v739_pick_first_num(
        levels.get("target2_price"),
        levels.get("target_high"),
        levels.get("target_price"),
        levels.get("target1_price"),
        plan.get("target_price"),
        plan.get("target2_price"),
        rr.get("target_price"),
        default=0.0,
    )

    if entry_price > 0 and target_high > 0:
        max_over = fnum(ctrl.get("paper_final_max_target_overrun_pct"), default=0.0)
        limit = target_high * (1.0 + max_over / 100.0)
        if entry_price > limit:
            reasons.append(f"OPEN 직전 목표초과: 진입 {fmt_price(entry_price)} > 목표상단 {fmt_price(target_high)}")

    gap = fnum(trigger_gate.get("trigger_gap_pct") if isinstance(trigger_gate, dict) else None, default=0.0)
    max_gap = fnum(ctrl.get("paper_final_max_trigger_gap_pct"), default=1.20)
    if gap > max_gap:
        reasons.append(f"OPEN 직전 늦은추격: 방아쇠 gap {gap:+.2f}% > {max_gap:.2f}%")

    timing = diag.get("entry_timing_spine") if isinstance(diag.get("entry_timing_spine"), dict) else {}
    max_age = fnum(ctrl.get("paper_final_max_entry_timing_age_sec"), default=300.0)
    if timing:
        first_age = fnum(timing.get("first_to_now_delay_sec"), default=0.0)
        s2_age = fnum(timing.get("s2_to_now_delay_sec"), default=0.0)
        max_seen = max(first_age, s2_age)
        source_age = _v751_candidate_source_age(ev)
        diag["preopen_source_age_v750"] = source_age
        diag["preopen_timing_max_age_v750"] = max_seen
        if max_seen > max_age:
            if source_age <= max_age:
                # 새 후보 row에 구 first_seen/S2_seen만 섞인 오염 케이스.
                # 막아서 조건을 조이는 대신 timing 오염으로 분류하고 source age 기준으로 판단한다.
                diag["entry_timing_contamination_v750"] = True
                diag["entry_timing_contamination_reason_v750"] = f"fresh source {source_age:.0f}s but legacy timing {max_seen:.0f}s"
            else:
                reasons.append(f"OPEN 직전 후보원천 오래됨: source age {source_age:.0f}s > {max_age:.0f}s")

    ca = _v751_official_candle_age_from_event(ev, diag)
    if ca > 0:
        diag["official_candle_age_v750"] = ca
        if ca >= fnum(ctrl.get("paper_final_candle_stale_warn_sec"), default=300.0):
            diag["structure_candle_stale_v750"] = True
            diag["structure_candle_stale_reason_v750"] = f"official candle age {ca:.0f}s"
    else:
        diag["official_candle_missing_v750"] = True

    return reasons[:8]


def _v739_open_quarantine_reason(pos: Dict[str, Any]) -> str:
    if _v734_is_malformed_open(pos):
        return "장부 이상 row: ticker/entry_price 없음"
    if _v734_is_legacy_experiment_open(pos):
        return "구 실험 OPEN 잔여: active OPEN에서 격리"
    return ""


def _v739_quarantine_open_positions(open_pos: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not isinstance(open_pos, dict) or not open_pos:
        return []
    moved: List[Dict[str, Any]] = []
    for pid, pos in list(open_pos.items()):
        if not isinstance(pos, dict):
            continue
        reason = _v739_open_quarantine_reason(pos)
        if not reason:
            continue
        row = dict(pos)
        row.update({
            "quarantine_ts": now_ts(),
            "quarantine_text": iso_ts(),
            "quarantine_reason": reason,
            "original_pos_id": pid,
            "paper_version": VERSION,
            "schema": "paper_open_quarantine_v742",
        })
        append_jsonl(FILES.get("open_quarantine", BASE_DIR / "paper_bot_open_quarantine.jsonl"), row)
        moved.append(row)
        open_pos.pop(pid, None)
    return moved


def _v620_trigger_gate_line(row: Dict[str, Any], diag: Dict[str, Any], prefix: str = '- ') -> str:
    gate = _v620_trigger_gate_from_sources(row, diag)
    if not gate.get('trigger_price'):
        return prefix + '방아쇠확인: 정보없음'
    status = '도달' if gate.get('trigger_reached') else '미도달'
    gap = gate.get('trigger_gap_pct')
    gap_txt = f" / gap {gap:+.2f}%" if isinstance(gap, (int, float)) else ''
    return prefix + f"방아쇠확인: {status} / 진입 {fmt_price(gate.get('entry_price'))} vs 방아쇠 {fmt_price(gate.get('trigger_price'))}{gap_txt}"

def _v586_timing_line(row: Dict[str, Any], diag: Dict[str, Any], canonical: Dict[str, Any], prefix: str = '- ') -> str:
    timing = _v586_nested(canonical, ('timing_spine',))
    if not isinstance(timing, dict):
        timing = diag.get('entry_timing_spine') if isinstance(diag.get('entry_timing_spine'), dict) else {}
    if not isinstance(timing, dict) or not timing:
        return prefix + '진입타이밍: 정보없음'
    first_ts = _v586_to_float(timing.get('first_seen_ts'))
    nowv = _v586_to_float(timing.get('now_ts'))
    f_delay = _v586_to_float(timing.get('first_to_now_delay_sec'))
    if f_delay is None and first_ts is not None and nowv is not None and nowv >= first_ts:
        f_delay = nowv - first_ts
    s_delay = _v586_to_float(timing.get('s1_to_paper_delay_sec') or timing.get('paper_read_delay_sec'))
    first_ret = _v586_to_float(timing.get('first_to_now_return_pct') or timing.get('first_to_open_return_pct'))
    s2_ret = _v586_to_float(timing.get('s2_to_now_return_pct') or timing.get('s2_to_open_return_pct'))
    parts = []
    if first_ret is not None:
        delay_txt = f'{f_delay:.0f}s' if f_delay is not None else '시간정보없음'
        parts.append(f'최초→현재 {delay_txt}/{first_ret:+.2f}%')
    if s2_ret is not None:
        parts.append(f'S2→현재 {s2_ret:+.2f}%')
    if s_delay is not None:
        parts.append(f'S1→paper {s_delay:.0f}s')
    if bool(timing.get('late_chase_flag')):
        parts.append('늦은추격주의')
    return prefix + '진입타이밍: ' + (' · '.join(parts) if parts else '정보없음')


def format_entry_timing_line(trace: Any, prefix: str = '- ') -> str:  # type: ignore[override]
    """Legacy timing trace display is deprecated for alerts.
    Kept for compatibility, but it no longer prints misleading +0.00/hot -/- lines.
    """
    if not isinstance(trace, dict) or not trace:
        return ''
    f1 = _v586_to_float(trace.get('flow_1m_pct'))
    f3 = _v586_to_float(trace.get('flow_3m_pct'))
    hot1 = trace.get('hot_rank_1m')
    hot3 = trace.get('hot_rank_3m')
    if (f1 is None or abs(f1) < 0.000001) and (f3 is None or abs(f3) < 0.000001) and not _v586_present(hot1) and not _v586_present(hot3):
        return ''
    flow = f"1m {_v586_pct(f1)} · 3m {_v586_pct(f3)}"
    hot = f"hot {hot1 if _v586_present(hot1) else '정보없음'}/{hot3 if _v586_present(hot3) else '정보없음'}"
    return prefix + f"진입시점 참고: {flow} / {hot}"


def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = '- ') -> List[str]:  # type: ignore[override]
    diag = diag if isinstance(diag, dict) else {}
    # When only diagnostics are passed, canonical may still be embedded inside it.
    row: Dict[str, Any] = diag.get('_source_row') if isinstance(diag.get('_source_row'), dict) else {}
    canonical = _v586_get_canonical_metric(row, diag)
    lines: List[str] = []
    structures = diag.get('entry_structure_tags') if isinstance(diag.get('entry_structure_tags'), list) else []
    reasons = diag.get('entry_reasons') if isinstance(diag.get('entry_reasons'), list) else []
    confirms = diag.get('confirm_signals') if isinstance(diag.get('confirm_signals'), list) else []
    risks = diag.get('execution_risk_tags') if isinstance(diag.get('execution_risk_tags'), list) else []
    rechecks = diag.get('recheck_reasons') if isinstance(diag.get('recheck_reasons'), list) else []
    blocks = diag.get('block_reasons') if isinstance(diag.get('block_reasons'), list) else []
    missing = diag.get('missing_info') if isinstance(diag.get('missing_info'), list) else []
    cm_struct = canonical.get('structure') if isinstance(canonical.get('structure'), dict) else {}
    cm_exec = canonical.get('execution_risk') if isinstance(canonical.get('execution_risk'), dict) else {}
    cm_fresh = canonical.get('freshness_map') if isinstance(canonical.get('freshness_map'), dict) else {}
    cm_metrics = canonical.get('metrics') if isinstance(canonical.get('metrics'), dict) else {}
    if not structures and isinstance(cm_struct.get('tags'), list):
        structures = cm_struct.get('tags')
    if structures:
        lines.append(prefix + '진입구조: ' + _v586_label_list(structures, 5))
    if reasons:
        lines.append(prefix + '진입근거: ' + _v586_label_list(reasons, 5))
    if confirms:
        lines.append(prefix + '확인통과: ' + _v586_label_list(confirms, 6))
    else:
        react, _ = _v586_metric(row, diag, canonical, 'price_reaction_pct', ('price_reaction_pct','price_reaction'))
        buy, _ = _v586_metric(row, diag, canonical, 'buy_ratio', ('buy_ratio','buy_trade_ratio'))
        sustain, _ = _v586_metric(row, diag, canonical, 'buy_sustain_1m', ('buy_sustain_1m','buy_ratio_1m'))
        spread, _ = _v586_metric(row, diag, canonical, 'spread_pct', ('spread_pct','micro_spread_pct'))
        fresh = cm_fresh.get('overall') if isinstance(cm_fresh, dict) else None
        passed = []
        if fresh: passed.append(f'신선도 {fresh}')
        if react is not None: passed.append(f'가격반응 {_v586_pct(react)}')
        if buy is not None: passed.append(f'매수체결 {_v586_num(buy)}')
        if sustain is not None: passed.append(f'1분지속 {_v586_num(sustain)}')
        if spread is not None: passed.append(f'스프레드 {_v586_pct(spread, signed=False)}')
        if passed:
            lines.append(prefix + '확인값: ' + ' / '.join(passed))
    levels = cm_struct.get('levels') if isinstance(cm_struct.get('levels'), dict) else (diag.get('structure_levels') if isinstance(diag.get('structure_levels'), dict) else {})
    plan = canonical.get('entry_plan') if isinstance(canonical.get('entry_plan'), dict) else (diag.get('entry_plan') if isinstance(diag.get('entry_plan'), dict) else {})
    rr = canonical.get('risk_reward') if isinstance(canonical.get('risk_reward'), dict) else (diag.get('risk_reward') if isinstance(diag.get('risk_reward'), dict) else {})
    if levels and levels.get('available', True):
        lines.append(prefix + '구조선: 지지 ' + fmt_price(levels.get('support_price')) + ' / 방아쇠 ' + fmt_price(levels.get('trigger_price')) + ' / 무효 ' + fmt_price(levels.get('invalid_price')) + ' / 목표 ' + fmt_price(levels.get('target1_price')) + '→' + fmt_price(levels.get('target2_price')))
    if plan:
        lines.append(prefix + '진입계획: ' + str(plan.get('plan_type') or '정보없음') + ' / ' + str(plan.get('trigger_reason') or '정보없음'))
    if rr:
        up = _v586_to_float(rr.get('expected_upside_pct'))
        dn = _v586_to_float(rr.get('expected_downside_pct'))
        ratio = _v586_to_float(rr.get('rr_ratio'))
        lines.append(prefix + f"손익비: 기대상승 {_v586_pct(up)} / 무효손실 {_v586_pct(-abs(dn) if dn is not None else None)} / RR {_v586_num(ratio)}")
    lines.append(_v620_trigger_gate_line(row, diag, prefix))
    lines.append(_v586_timing_line(row, diag, canonical, prefix))
    if cm_struct.get('state'):
        lines.append(prefix + '구조판정: ' + str(cm_struct.get('state')))
    if cm_fresh.get('overall'):
        lines.append(prefix + f"신선도: {cm_fresh.get('overall')} / core age {cm_fresh.get('max_core_age_sec', '정보없음')}s")
    if risks or (isinstance(cm_exec, dict) and cm_exec.get('tags')):
        risk_list = risks if risks else cm_exec.get('tags')
        lines.append(prefix + '위험태그: ' + _v586_label_list(risk_list, 5))
    flow = f"1m {_v586_flow_value(row, diag, '1m')} · 3m {_v586_flow_value(row, diag, '3m')} · 5m {_v586_flow_value(row, diag, '5m')} · 15m {_v586_flow_value(row, diag, '15m')}"
    lines.append(prefix + '흐름: ' + flow)
    vwap, _ = _v586_metric(row, diag, canonical, 'vwap_pos_pct', ('vwap_pos_pct','vwap_gap_pct','vwap_position_pct'))
    ema, _ = _v586_metric(row, diag, canonical, 'ema5_pos_pct', ('ema5_pos_pct','ema5_gap_pct','ema5_position_pct'))
    rel, _ = _v586_metric(row, diag, canonical, 'relative_strength', ('relative_strength','market_relative_strength'))
    if vwap is None and ema is None and rel is None:
        lines.append(prefix + '위치: 정보없음')
    else:
        lines.append(prefix + f"위치: VWAP {_v586_pct(vwap)} · EMA5 {_v586_pct(ema)} · 상대강도 {_v586_num(rel)}")
    decision = canonical.get('decision_reference') if isinstance(canonical, dict) else None
    caution = []
    for group in (rechecks, blocks, missing):
        for x in group or []:
            sx = str(x).strip()
            if sx and sx not in caution:
                caution.append(sx)
    if caution:
        lines.append(prefix + '재확인/주의: ' + ' / '.join(caution[:5]))
    else:
        lines.append(prefix + '최종판정: ' + str(decision or 'S1 통과'))
    return [ln for ln in lines if isinstance(ln, str) and ln.strip()]


def _v586_diag_from_trade(row: Dict[str, Any]) -> Dict[str, Any]:
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    diag = dict(diag)
    diag['_source_row'] = row
    return diag


def _v561_open_message_text(pos: Dict[str, Any]) -> str:  # type: ignore[override]
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ''
    diag = _v586_diag_from_trade(pos)
    extra = '\n'.join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    return (
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def _v567_closed_message_text(row: Dict[str, Any]) -> str:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker'))
    diag = _v586_diag_from_trade(row)
    extra = '\n'.join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    return (
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )



# =============================================================================
# paper_bot v0.209 / v587: hourly summary + hot-rank review spine
# - 기능/조건 변경 없음. 1시간 요약과 hot-rank 요약의 source 표시만 현재 paper spine 기준으로 맞춘다.
# - hot-rank 급등이 후보없음/not_seen일 때 무근거로 끝내지 않고 scanner→strategy 매칭 상태를 남긴다.
# =============================================================================

def _v587_status_spine() -> Dict[str, Any]:
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    handoff = load_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}
    trace = load_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), {}) or {}
    if not isinstance(status, dict): status = {}
    if not isinstance(handoff, dict): handoff = {}
    if not isinstance(trace, dict): trace = {}
    snap = status.get('paper_candidate_snapshot') if isinstance(status.get('paper_candidate_snapshot'), dict) else {}
    latest = status.get('latest_count', snap.get('latest_count', '-'))
    fresh = status.get('merged_fresh', status.get('fresh_count', snap.get('merged_fresh', snap.get('fresh_count', '-'))))
    return {
        'version': status.get('version') or status.get('paper_version') or VERSION,
        'build': status.get('build') or BUILD_LABEL,
        'latest': latest,
        'fresh': fresh,
        'snapshot_id': status.get('snapshot_id') or snap.get('snapshot_id') or handoff.get('snapshot_id') or trace.get('snapshot_id') or '-',
        'status_age': _v561_age_from(status),
        'handoff_age': _v561_age_from(handoff),
        'trace_age': _v561_age_from(trace),
    }


def _v587_paper_spine_label() -> str:
    sp = _v587_status_spine()
    return f"{sp.get('version','-')} / latest {sp.get('latest','-')} / fresh {sp.get('fresh','-')} / snapshot {sp.get('snapshot_id','-')}"


def _v587_tick_distortion_reason(row: Dict[str, Any]) -> str:
    price = _v586_to_float(row.get('current_price') or row.get('price') or row.get('trade_price'))
    c1 = _v586_to_float(row.get('scanner_change_1m_pct')) or 0.0
    c3 = _v586_to_float(row.get('scanner_change_3m_pct')) or 0.0
    t = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    if price is not None and price <= 0.001 and (abs(c1) >= 10.0 or abs(c3) >= 10.0):
        return '초저가/틱단위 급등 왜곡 의심'
    if t in {'BTT','NFT'} and (abs(c1) >= 10.0 or abs(c3) >= 10.0):
        return '초저가/틱단위 급등 왜곡 의심'
    return ''


def _v587_candidate_stage_detail_for_hot(row: Dict[str, Any], idx: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[str, str, str, str]:
    """hot-rank 발견 → strategy 최신 후보 매칭 → paper 상태를 한 줄로 남긴다.
    매수 판단은 바꾸지 않고, not_seen의 원인 범주만 표시한다.
    """
    ticker = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    tick_reason = _v587_tick_distortion_reason(row)
    if not ticker or not isinstance(idx, dict):
        reason = 'scanner 발견 / strategy 매칭확인 불가'
        if tick_reason: reason += ' / ' + tick_reason
        return '후보확인불가', reason, 'paper not_seen', ''
    r = idx.get(ticker)
    if not isinstance(r, dict):
        reason = 'scanner 발견 / strategy latest 후보 매칭 없음'
        if tick_reason: reason += ' / ' + tick_reason
        # 후보없음은 사라지는 상태가 아니라 복기 가능한 not_candidate 상태로 표시한다.
        return '후보없음(not_candidate)', reason, 'paper not_seen', ''

    st = str(r.get('candidate_grade') or r.get('s_stage') or r.get('stage') or r.get('grade') or '-').upper()
    if st not in {'S1', 'S2', 'S3', 'X'}:
        st = '-'
    block = _v514_first_text(r, (
        's1_block_reason', 'final_block_reason', 'block_reason', 'main_block_reason',
        'reject_reason', 'entry_block_reason', 'reason', 'candidate_reason',
        '막힘', 'block_reasons', 'reasons'
    ), limit=44)
    missing = _v514_first_text(r, (
        'missing_reason', 'missing_info', 'missing_tags', 'lack_reason', 'info_missing', '부족',
    ), limit=34)
    risk = _v514_first_text(r, (
        'risk_tags', 'risk_reason', 'structure_risk_tags', 'spike_guard_reasons', 'stale_reasons', '위험'
    ), limit=34)
    reason_parts = []
    if block: reason_parts.append(block)
    if risk: reason_parts.append('위험 ' + risk)
    if missing: reason_parts.append('부족 ' + missing)
    if tick_reason: reason_parts.append(tick_reason)
    reason = ' / '.join(reason_parts[:4])
    if st == 'S1':
        pstate = 'paper open대상'
    elif st in {'S2','S3'}:
        pstate = 'paper not_s1'
    elif st == 'X':
        pstate = 'paper 제외'
    else:
        pstate = 'paper not_candidate'
    seen = _v514_first_text(r, ('paper_state', 'paper_status', 'handoff_status', 'paper_trace_status'), limit=24)
    if seen:
        pstate = 'paper ' + seen
    strat = str(r.get('strategy_label') or r.get('strategy_key') or r.get('strategy') or '')
    return f'후보 {st}', reason, pstate, strat


def _format_hot_row(row: Dict[str, Any], stage_idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'
    c1 = fnum(row.get('scanner_change_1m_pct'), default=0.0)
    c3 = fnum(row.get('scanner_change_3m_pct'), default=0.0)
    r1 = row.get('scanner_hot_rank_1m') or '-'
    r3 = row.get('scanner_hot_rank_3m') or '-'
    price = row.get('current_price') or row.get('price') or row.get('trade_price')
    stage, reason, pstate, strat = _v587_candidate_stage_detail_for_hot(row, stage_idx)
    base = f"{t} {fmt_price(price)} / 1m {c1:+.2f}% #{r1} · 3m {c3:+.2f}% #{r3} / {stage}"
    extras = []
    tl = _v514_time_label_from_row(row)
    if tl != '포착 -': extras.append(tl)
    if strat: extras.append(strat)
    if reason: extras.append('이유 ' + reason)
    if pstate: extras.append(pstate)
    return base + (' / ' + ' / '.join(extras[:5]) if extras else '')


_v587_base_notify_s1_decision_summary = notify_s1_decision_summary

def notify_s1_decision_summary(pick_stats: Dict[str, Any], opened_count: int = 0, closed_count: int = 0, ctrl: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    """v587: 기존 1시간 S1 요약 기능을 유지하되 paper label은 현재 status spine으로 표시한다."""
    # 원본 함수의 로직을 유지하기 위해 같은 bucket을 사용하되, 발송 직전 label만 바꾼다.
    # 원본 함수 내부가 send_message를 직접 호출하므로 여기서는 짧은 monkey-patch 방식으로 message text만 보정한다.
    original_send = globals().get('send_message')
    def _send_with_spine(text: str) -> Any:
        if isinstance(text, str) and 'paper S1 1시간' in text:
            text = re.sub(r'- paper: .*$', '- paper spine: ' + _v587_paper_spine_label(), text, flags=re.MULTILINE)
        return original_send(text) if callable(original_send) else None
    globals()['send_message'] = _send_with_spine
    try:
        return _v587_base_notify_s1_decision_summary(pick_stats, opened_count=opened_count, closed_count=closed_count, ctrl=ctrl)
    finally:
        globals()['send_message'] = original_send


_v587_base_notify_market_hot_summary = notify_market_hot_summary

def notify_market_hot_summary(ctrl: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    """v587: hot-rank 요약 기능은 유지하고, 마지막 paper label을 현재 paper spine으로 보정한다.
    _format_hot_row override가 scanner→strategy 매칭 상태를 함께 표시한다.
    """
    original_send = globals().get('send_message')
    def _send_with_spine(text: str) -> Any:
        if isinstance(text, str) and ('시장 hot-rank' in text or '강한 급등 감지' in text):
            text = re.sub(r'- paper: .*$', '- paper spine: ' + _v587_paper_spine_label(), text, flags=re.MULTILINE)
        return original_send(text) if callable(original_send) else None
    globals()['send_message'] = _send_with_spine
    try:
        return _v587_base_notify_market_hot_summary(ctrl)
    finally:
        globals()['send_message'] = original_send


def hot_summary_text() -> str:  # type: ignore[override]
    ctrl = load_control(); rows, age, meta = _load_hot_rank_rows(ctrl)
    stage_idx = _hot_candidate_stage_index()
    top_n = max(5, int(fnum(ctrl.get('notify_market_hot_rank_top_n'), default=5)))
    good = []
    for r in rows:
        c1 = fnum(r.get('scanner_change_1m_pct'), default=0.0); c3 = fnum(r.get('scanner_change_3m_pct'), default=0.0)
        r1 = fnum(r.get('scanner_hot_rank_1m'), default=9999.0); r3 = fnum(r.get('scanner_hot_rank_3m'), default=9999.0)
        if c1 >= 0.2 or c3 >= 0.4 or r1 <= top_n or r3 <= top_n:
            rr = dict(r); rr['_hot_score'] = _hot_row_score(rr); good.append(rr)
    good.sort(key=lambda x: fnum(x.get('_hot_score'), default=0.0), reverse=True)
    lines = [
        '🧭 시장 hot-rank 현재 요약 /hot_summary · v587 scanner→strategy 연결표',
        f"- cache age {age:.1f}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}",
        '- 매수 알림 아님 · 급등 발견→strategy 검토→paper 상태 확인용',
        '- not_seen은 매수누락 확정이 아니라 strategy latest row 매칭 없음 표시',
    ]
    for r in good[:max(5, top_n)]:
        lines.append('- ' + _format_hot_row(r, stage_idx))
    lines.append('- paper spine: ' + _v587_paper_spine_label())
    return '\n'.join(lines)


def paper_hourly_text() -> str:  # type: ignore[override]
    return '\n\n'.join([pstatus_text(), hot_summary_text(), candidate_summary_text()])



# =============================================================================
# paper_bot v0.210 / v588: OPEN 장부 canonical_entry_snapshot 본선화
# - 새 복기 기능을 또 붙이는 것이 아니라, OPEN 순간의 strategy canonical row를
#   paper OPEN row에 필수 snapshot으로 봉인한다.
# - CLOSED row는 OPEN row를 그대로 복사하므로 canonical_entry_snapshot을 보존한다.
# - trade_review는 알림/summary 구경로가 아니라 CLOSED row의 snapshot만 읽는다.
# - 전략 조건, S등급, 청산, 자동매수, BUY_READY, 기존 장부 삭제 없음.
# =============================================================================

def _v588_json_safe(obj: Any) -> Any:
    try:
        return json.loads(json.dumps(obj, ensure_ascii=False, default=str))
    except Exception:
        return {}


def _v588_first_nonempty(*vals: Any) -> Any:
    for v in vals:
        if v is None:
            continue
        if isinstance(v, str) and not v.strip():
            continue
        if isinstance(v, (list, tuple, dict)) and len(v) == 0:
            continue
        return v
    return None


def _v588_path(obj: Any, path: Tuple[str, ...]) -> Any:
    cur = obj
    for k in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(k)
    return cur


def _v588_paths(sources: List[Dict[str, Any]], *paths: Tuple[str, ...]) -> Any:
    for src in sources:
        if not isinstance(src, dict):
            continue
        for path in paths:
            v = _v588_path(src, path)
            if _v588_first_nonempty(v) is not None:
                return v
    return None


def _v588_first_dict(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}


def _v588_first_list(*vals: Any) -> List[Any]:
    for v in vals:
        if isinstance(v, list) and v:
            return v
        if isinstance(v, tuple) and v:
            return list(v)
    return []


def _v588_num_value(v: Any) -> Optional[float]:
    if v is None or v == '':
        return None
    try:
        return float(v)
    except Exception:
        return None


def _v588_fmt_pct(v: Any) -> str:
    x = _v588_num_value(v)
    return '-' if x is None else f"{x:+.2f}%"


def _v588_fmt_float(v: Any, nd: int = 2) -> str:
    x = _v588_num_value(v)
    return '-' if x is None else f"{x:.{nd}f}"


def _v588_metric_value(sources: List[Dict[str, Any]], keys: Tuple[str, ...]) -> Any:
    paths = []
    for k in keys:
        paths.extend([
            (k,),
            ('metrics', k),
            ('feature', k),
            ('orderflow', k),
            ('micro', k),
            ('execution_risk', k),
            ('freshness_map', k),
            ('entry_diagnostics', k),
        ])
    return _v588_paths(sources, *paths)


def _v588_build_canonical_entry_snapshot(ev: Dict[str, Any], pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ev = ev if isinstance(ev, dict) else {}
    pos = pos if isinstance(pos, dict) else {}
    ctx = _v588_first_dict(
        pos.get('entry_context'), ev.get('entry_context'), ev.get('strategy_context'), ev.get('raw') if isinstance(ev.get('raw'), dict) else {}
    )
    raw = _v588_first_dict(pos.get('raw'), ev.get('raw'))
    diag = _v588_first_dict(pos.get('entry_diagnostics'), ev.get('paper_final_safety_diagnostics'), ev.get('entry_diagnostics'), ctx.get('entry_diagnostics'))
    cm = _v588_first_dict(
        pos.get('canonical_metric_row'), ev.get('canonical_metric_row'), ctx.get('canonical_metric_row'), diag.get('canonical_metric_row'), raw.get('canonical_metric_row') if isinstance(raw, dict) else {}
    )
    dec = _v588_first_dict(pos.get('canonical_entry_decision'), ev.get('canonical_entry_decision'), ctx.get('canonical_entry_decision'), diag.get('canonical_entry_decision'))
    sources = [pos, ev, diag, cm, ctx, raw]

    structure = _v588_first_dict(cm.get('structure'), diag.get('structure'), ctx.get('structure'))
    freshness = _v588_first_dict(cm.get('freshness_map'), diag.get('freshness_map'), ctx.get('freshness_map'))
    exec_risk = _v588_first_dict(cm.get('execution_risk'), diag.get('execution_risk'), ctx.get('execution_risk'))
    timing = _v588_first_dict(cm.get('timing_spine'), pos.get('entry_timing_spine'), diag.get('entry_timing_spine'), diag.get('entry_timing_trace'), ctx.get('entry_timing_spine'))
    levels = _v588_first_dict(cm.get('structure_levels'), pos.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'))
    plan = _v588_first_dict(cm.get('entry_plan'), pos.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'))
    rr = _v588_first_dict(cm.get('risk_reward'), pos.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'))

    metrics = {
        'price_reaction_pct': _v588_metric_value(sources, ('price_reaction_pct','reaction_pct','reaction','price_reaction','response_pct','price_response_pct')),
        'buy_trade_ratio': _v588_metric_value(sources, ('buy_trade_ratio','buy_ratio','buy_strength','buy_aggr_ratio','buy_exec_ratio','buy_pressure_ratio')),
        'one_min_sustain': _v588_metric_value(sources, ('one_min_sustain','one_min_buy_sustain','buy_sustain_1m','sustain_1m','one_min_persist','one_min_persistence')),
        'spread_pct': _v588_metric_value(sources, ('spread_pct','orderbook_spread_pct','spread_rate_pct')),
        'slippage_pct': _v588_metric_value(sources, ('slippage_pct','expected_slippage_pct','est_slippage_pct')),
        'sell_pressure': _v588_metric_value(sources, ('sell_pressure','sell_pressure_score','ask_wall_pressure','sell_wall_pressure')),
        'flow_1m_pct': _v588_metric_value(sources, ('flow_1m_pct','change_1m_pct','rate_1m','return_1m_pct')),
        'flow_3m_pct': _v588_metric_value(sources, ('flow_3m_pct','change_3m_pct','rate_3m','return_3m_pct')),
        'flow_5m_pct': _v588_metric_value(sources, ('flow_5m_pct','change_5m_pct','rate_5m','return_5m_pct')),
        'flow_15m_pct': _v588_metric_value(sources, ('flow_15m_pct','change_15m_pct','rate_15m','return_15m_pct')),
    }
    ages = {
        'micro_age_sec': _v588_metric_value(sources, ('micro_age_sec','micro_age','micro_fresh_age_sec')),
        'orderflow_age_sec': _v588_metric_value(sources, ('orderflow_age_sec','orderflow_age','orderflow_fresh_age_sec')),
        'price_age_sec': _v588_metric_value(sources, ('price_age_sec','price_age','ticker_age_sec')),
        'feature_age_sec': _v588_metric_value(sources, ('feature_age_sec','feature_age')),
        'paper_age_sec': _v588_metric_value(sources, ('paper_age_sec','paper_fresh_age_sec')),
    }
    snapshot = {
        'schema': 'canonical_entry_snapshot_v588',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'created_at': now_ts(),
        'created_at_text': iso_ts(),
        'event_id': pos.get('event_id') or pos.get('pos_id') or event_id(ev) if ev else pos.get('pos_id'),
        'ticker': normalize_ticker(pos.get('ticker') or ev.get('ticker') or ev.get('symbol') or ev.get('market')),
        'strategy': pos.get('strategy') or ev.get('strategy') or ev.get('strategy_key'),
        'strategy_key': pos.get('strategy_key') or ev.get('strategy_key') or ev.get('strategy'),
        'candidate_grade': pos.get('candidate_grade') or ev.get('candidate_grade') or ev.get('s_stage') or 'S1',
        'entry_price': pos.get('entry_price') or get_event_price(ev),
        'detected_price': pos.get('detected_price') or get_event_price(ev),
        'metrics': _v588_json_safe(metrics),
        'freshness': {
            'overall': freshness.get('overall') or freshness.get('state') or diag.get('fresh_state') or diag.get('freshness_state'),
            'ages': _v588_json_safe(ages),
            'raw': _v588_json_safe(freshness),
        },
        'structure': {
            'state': structure.get('state') or cm.get('structure_state') or diag.get('structure_state'),
            'tags': _v588_first_list(structure.get('tags'), cm.get('structure_tags'), diag.get('entry_structure_tags'), pos.get('entry_structure_tags')),
            'levels': _v588_json_safe(levels),
        },
        'execution_risk': {
            'state': exec_risk.get('state') or cm.get('execution_risk_state') or diag.get('execution_risk_state'),
            'tags': _v588_first_list(exec_risk.get('tags'), cm.get('execution_risk_tags'), diag.get('execution_risk_tags'), pos.get('execution_risk_tags')),
            'raw': _v588_json_safe(exec_risk),
        },
        'timing_spine': _v588_json_safe(timing),
        'entry_plan': _v588_json_safe(plan),
        'risk_reward': _v588_json_safe(rr),
        'decision': {
            'reference': cm.get('decision_reference') or diag.get('decision_reference') or pos.get('final_entry_label') or ev.get('final_entry_label'),
            'entry_reasons': _v588_first_list(cm.get('entry_reasons'), diag.get('entry_reasons'), pos.get('entry_condition_reasons')),
            'block_reasons': _v588_first_list(cm.get('block_reasons'), diag.get('block_reasons'), pos.get('block_reasons')),
            'confirm_signals': _v588_first_list(diag.get('confirm_signals'), pos.get('confirm_signals'), cm.get('confirm_signals')),
            'late_chase_flag': bool(_v588_first_nonempty(cm.get('late_chase_flag'), diag.get('late_chase_flag'), pos.get('late_chase_flag'), False)),
        },
        'paper_preopen': {
            'paper_final_safety_passed': bool(pos.get('paper_final_safety_passed') or ev.get('paper_final_safety_passed')),
            'diagnostics_schema': diag.get('schema') or diag.get('entry_decision_schema'),
            'canonical_entry_decision': _v588_json_safe(dec),
        },
        'source_snapshot': _v588_json_safe(_v588_first_dict(cm.get('source_snapshot'), diag.get('source_snapshot'), ctx.get('source_snapshot'))),
    }
    return _v588_json_safe(snapshot)


_v588_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v588_prev_open_position(pos_id, ev)
    try:
        snap = _v588_build_canonical_entry_snapshot(ev, pos)
        pos['canonical_entry_snapshot'] = snap
        pos['canonical_entry_snapshot_schema'] = snap.get('schema')
        pos['canonical_entry_snapshot_version'] = VERSION
        # 호환: 기존 review가 canonical_metric_row만 찾는 경로도 살린다. 새 판단은 하지 않는다.
        if isinstance(snap.get('source_snapshot'), dict) and snap['source_snapshot']:
            pos['canonical_entry_source_snapshot'] = snap['source_snapshot']
    except Exception as exc:
        log_error('v588_open_canonical_entry_snapshot', exc)
    return pos


_v588_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    try:
        if isinstance(pos, dict) and not isinstance(pos.get('canonical_entry_snapshot'), dict):
            pos['canonical_entry_snapshot'] = _v588_build_canonical_entry_snapshot(pos.get('raw') if isinstance(pos.get('raw'), dict) else {}, pos)
            pos['canonical_entry_snapshot_schema'] = 'canonical_entry_snapshot_v588_backfilled_open'
    except Exception as exc:
        log_error('v588_update_open_snapshot_backfill', exc)
    updated, closed = _v588_prev_update_position(pos, ctrl)
    try:
        if isinstance(closed, dict) and not isinstance(closed.get('canonical_entry_snapshot'), dict):
            closed['canonical_entry_snapshot'] = _v588_build_canonical_entry_snapshot(closed.get('raw') if isinstance(closed.get('raw'), dict) else {}, closed)
            closed['canonical_entry_snapshot_schema'] = 'canonical_entry_snapshot_v588_backfilled_closed'
        if isinstance(closed, dict):
            closed['closed_keeps_canonical_entry_snapshot'] = True
    except Exception as exc:
        log_error('v588_closed_snapshot_preserve', exc)
    return updated, closed


def _v588_snapshot_line(row: Dict[str, Any]) -> str:
    snap = row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}
    t = normalize_ticker(row.get('ticker') or (snap.get('ticker') if isinstance(snap, dict) else '')) or '-'
    pnl = _v588_fmt_pct(row.get('pnl_pct'))
    reason = str(row.get('exit_reason') or row.get('exit_rule') or '-')
    if not snap:
        return f"- {t}: {pnl} / {reason} / OPEN snapshot 없음(구 OPEN 또는 v588 전 장부)"
    m = snap.get('metrics') if isinstance(snap.get('metrics'), dict) else {}
    fr = snap.get('freshness') if isinstance(snap.get('freshness'), dict) else {}
    ages = fr.get('ages') if isinstance(fr.get('ages'), dict) else {}
    st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
    er = snap.get('execution_risk') if isinstance(snap.get('execution_risk'), dict) else {}
    timing = snap.get('timing_spine') if isinstance(snap.get('timing_spine'), dict) else {}
    return (
        f"- {t}: {pnl} / {reason} / "
        f"반응 {_v588_fmt_pct(m.get('price_reaction_pct'))} · 매수 {_v588_fmt_float(m.get('buy_trade_ratio'))} · "
        f"1분 {_v588_fmt_float(m.get('one_min_sustain'))} · 스프 {_v588_fmt_pct(m.get('spread_pct'))} · "
        f"미끄 {_v588_fmt_pct(m.get('slippage_pct'))} / fresh {fr.get('overall') or '-'} "
        f"micro { _v588_fmt_float(ages.get('micro_age_sec'), 1) }s · orderflow { _v588_fmt_float(ages.get('orderflow_age_sec'), 1) }s / "
        f"구조 {st.get('state') or '-'} / 실행 {er.get('state') or '-'} / "
        f"늦추 { 'Y' if (snap.get('decision') or {}).get('late_chase_flag') else 'N' } / "
        f"first→S1 { _v588_fmt_float(_v588_first_nonempty(timing.get('first_to_s1_delay_sec'), timing.get('first_to_now_delay_sec')), 0) }s"
    )


def _v588_entry_snapshot_review_block(rows: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    with_snap = [r for r in rows if isinstance(r.get('canonical_entry_snapshot'), dict)]
    fast = [r for r in rows if str(r.get('exit_reason') or r.get('exit_rule') or '').find('fast_fail') >= 0]
    show = (fast + [r for r in reversed(rows) if r not in fast])[:5]
    c_struct: Counter = Counter()
    c_exec: Counter = Counter()
    c_fresh: Counter = Counter()
    for r in with_snap:
        s = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else {}
        st = s.get('structure') if isinstance(s.get('structure'), dict) else {}
        er = s.get('execution_risk') if isinstance(s.get('execution_risk'), dict) else {}
        fr = s.get('freshness') if isinstance(s.get('freshness'), dict) else {}
        if st.get('state'): c_struct[str(st.get('state'))] += 1
        if er.get('state'): c_exec[str(er.get('state'))] += 1
        if fr.get('overall'): c_fresh[str(fr.get('overall'))] += 1
    data = {
        'schema': 'paper_trade_review_open_snapshot_v588',
        'row_count': len(rows),
        'with_canonical_entry_snapshot': len(with_snap),
        'fast_fail_count': len(fast),
        'structure_top': ' / '.join(f'{k} {v}' for k, v in c_struct.most_common(5)) if c_struct else '-',
        'execution_top': ' / '.join(f'{k} {v}' for k, v in c_exec.most_common(5)) if c_exec else '-',
        'fresh_top': ' / '.join(f'{k} {v}' for k, v in c_fresh.most_common(5)) if c_fresh else '-',
    }
    lines = ['[OPEN snapshot 복기 · v588]']
    if not rows:
        lines.append('- 오늘 CLOSED 없음')
    else:
        lines.append(f"- snapshot 보유 {len(with_snap)}/{len(rows)}개 / 빠른실패 {len(fast)}개")
        lines.append(f"- 구조 TOP: {data['structure_top']}")
        lines.append(f"- fresh TOP: {data['fresh_top']}")
        lines.append(f"- 실행위험 TOP: {data['execution_top']}")
        for r in show:
            lines.append(_v588_snapshot_line(r))
    return lines, data


_v588_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v588_prev_write_score_cache(status)
    try:
        obj = load_json(FILES['trade_review'], {}) or {}
        if not isinstance(obj, dict):
            return
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
        today_rows = _v557_filter_today(rows, now_ts())
        lines, data = _v588_entry_snapshot_review_block(today_rows)
        summary = str(obj.get('summary_text') or '')
        block = '\n'.join(lines)
        pattern = r"\n?\[OPEN snapshot 복기 · v588\][\s\S]*?(?=\n\[[^\n]+\]|\Z)"
        if '[OPEN snapshot 복기 · v588]' in summary:
            summary = re.sub(pattern, '\n' + block, summary).strip()
        else:
            summary = (summary.rstrip() + '\n\n' + block).strip() if summary else block
        obj['summary_text'] = summary
        obj['open_entry_snapshot_review_v588'] = data
        obj['schema'] = 'paper_trade_review_cache_v588_open_entry_snapshot'
        obj['version'] = VERSION
        obj['paper_version'] = VERSION
        obj['build'] = BUILD_LABEL
        obj['writer'] = 'v588_canonical_entry_snapshot_ledger'
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v588', exc)



# =============================================================================
# paper_bot v0.212 / v590: paper 복기 writer/reader 단일 spine
# =============================================================================
# 목적:
# - trade_review cache가 v569/v578/v588 writer 사이에서 덮이는 문제를 끊는다.
# - CLOSED tail을 한 번 읽고, 최고수익 반납/빠른실패/후반손실/OPEN snapshot 복기를
#   paper_review_spine_v589 하나에 합쳐 저장한다.
# - 기능은 유지하되 구 writer/reader가 마지막에 이기지 못하게 모든 legacy review writer를 이 본선으로 연결한다.

V589_REVIEW_SCHEMA = 'paper_review_spine_v590'


def _v589_stat_text(rows: List[Dict[str, Any]]) -> str:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if not rows:
        return '표본부족'
    st = _score_stat(rows)
    n = int(st.get('n', 0) or 0)
    w = int(st.get('wins', 0) or 0)
    l = int(st.get('losses', max(0, n-w)) or 0)
    return f"{n}전 {w}승 {l}패 / 승률 {fnum(st.get('win_rate'), default=0.0):.1f}% / 합산 {fnum(st.get('total'), default=0.0):+.2f}% / 평균 {fnum(st.get('avg'), default=0.0):+.2f}%"


def _v589_primary_strategy(rows: List[Dict[str, Any]]) -> str:
    c: Counter = Counter()
    for r in rows or []:
        if isinstance(r, dict):
            c[_strategy_key(r)] += 1
    return c.most_common(1)[0][0] if c else '-'


def _v589_split_early_late(rows: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if len(rows) < 2:
        return [], rows
    mid = max(1, len(rows)//2)
    return rows[:mid], rows[mid:]


def _v589_loss_reason_counter(rows: List[Dict[str, Any]]) -> Counter:
    c: Counter = Counter()
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        pnl = fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)
        if pnl > 0:
            continue
        exit_reason = str(r.get('exit_reason') or r.get('exit_rule') or '')
        if 'fast_fail' in exit_reason:
            c['복기:빠른실패 정리 작동'] += 1
        if 'stop_loss' in exit_reason:
            c['청산:stop_loss'] += 1
        snap = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else {}
        decision = snap.get('decision') if isinstance(snap.get('decision'), dict) else {}
        timing = snap.get('timing_spine') if isinstance(snap.get('timing_spine'), dict) else {}
        fresh = snap.get('freshness') if isinstance(snap.get('freshness'), dict) else {}
        if bool(r.get('late_chase_flag') or decision.get('late_chase_flag') or timing.get('late_chase_flag')):
            c['타이밍:늦은추격'] += 1
        # snapshot이 없거나 신선도 원천 age가 없으면 과거 장부/구 writer 영향으로 숫자 확인이 부족한 상태로 표시한다.
        ages = fresh.get('ages') if isinstance(fresh.get('ages'), dict) else {}
        if not snap or not ages:
            c['신선도:문구만있음_숫자확인필요'] += 1
        elif any(fnum(ages.get(k), default=0.0) > 12.0 for k in ('micro_age_sec','orderflow_age_sec','price_age_sec','feature_age_sec')):
            c['신선도:핵심정보나이과다'] += 1
    return c


def _v589_counter_text(c: Counter, limit: int = 6) -> str:
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v589_peak_section(rows: List[Dict[str, Any]], late: List[Dict[str, Any]], last16: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    all_peak = _v578_peak_stats(rows)
    late_peak = _v578_peak_stats(late)
    last16_peak = _v578_peak_stats(last16)
    cases = [_v578_giveback_case(r) for r in rows]
    top_cases = sorted(cases, key=lambda x: fnum(x.get('giveback_pct'), default=0.0), reverse=True)
    floor_cases = [c for c in cases if c.get('virtual_floor_pct') is not None and fnum(c.get('pnl_pct'), default=0.0) < fnum(c.get('virtual_floor_pct'), default=999.0)]
    lines = [
        '[최고수익 반납]',
        f"- 전체: {_v578_short_stat_line(all_peak)}",
        f"- 후반: {_v578_short_stat_line(late_peak)}",
        f"- 최근16: {_v578_short_stat_line(last16_peak)}",
        '',
        '[수익 돌려준 상위]',
    ]
    lines += ([_v578_case_line(c) for c in top_cases[:5]] or ['- 표본부족'])
    lines += [
        '',
        '[가상 보호계단 참고 · 청산 변경 아님]',
        '- 기준 예시: 최고 +0.70%→최소 +0.30%, 최고 +1.00%→최소 +0.55%, 최고 +1.30%→최소 +0.80%',
        f"- 보호계단보다 낮게 끝난 후보: {len(floor_cases)}개",
    ]
    lines += ([_v578_case_line(c) for c in floor_cases[:5]] or ['- 해당 없음'])
    return lines, {
        'overall_peak_giveback': all_peak,
        'late_peak_giveback': late_peak,
        'last16_peak_giveback': last16_peak,
        'top_giveback_cases': top_cases[:10],
        'below_virtual_floor_cases': floor_cases[:10],
    }


def _v589_build_paper_review_spine(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
    today_rows = _v557_filter_today(rows, nowv)
    primary = _v589_primary_strategy(today_rows)
    primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
    early, late = _v589_split_early_late(primary_rows)
    last16 = primary_rows[-16:]

    peak_lines, peak_data = _v589_peak_section(primary_rows, late, last16)
    canon_lines, canon_data = _v584_canonical_review_block(primary_rows)
    snap_lines, snap_data = _v588_entry_snapshot_review_block(primary_rows)

    late_losses = [r for r in late if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) <= 0]
    last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) <= 0]
    late_loss_counter = _v589_loss_reason_counter(late_losses)
    last16_loss_counter = _v589_loss_reason_counter(last16_losses)

    summary_lines = [
        '📉 복기 /trade_review · v590 paper review spine',
        '- 기준: paper_bot CLOSED tail + OPEN canonical_entry_snapshot + score cache 보조. 조건·청산 재계산 없음.',
        f'- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개',
        '',
        '[성과 흐름]',
        f'- 전체: {_v589_stat_text(primary_rows)}',
        f'- 초반: {_v589_stat_text(early)}',
        f'- 후반: {_v589_stat_text(late)}',
        f'- 최근16: {_v589_stat_text(last16)}',
        '',
    ]
    summary_lines += peak_lines
    summary_lines += [
        '',
        '[후반 손실 원인 참고]',
        f"- 후반 손실 {len(late_losses)}개: {_v589_counter_text(late_loss_counter)}",
        f"- 최근16 손실 {len(last16_losses)}개: {_v589_counter_text(last16_loss_counter)}",
        '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        '',
    ]
    summary_lines += canon_lines
    summary_lines += ['', *snap_lines]

    obj = {
        'schema': V589_REVIEW_SCHEMA,
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v590_paper_review_spine_single_writer',
        'source': 'paper_bot_closed_tail_cache_only',
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'summary_text': '\n'.join(summary_lines).strip(),
        'status_open_count': (status or {}).get('open_count') if isinstance(status, dict) else None,
        'today_closed_count': len(today_rows),
        'primary_strategy': primary,
        'primary_rows_count': len(primary_rows),
        'performance': {
            'overall': _score_stat(primary_rows),
            'early': _score_stat(early),
            'late': _score_stat(late),
            'last16': _score_stat(last16),
        },
        'peak_giveback': peak_data,
        'late_loss_reason_top': dict(late_loss_counter.most_common(10)),
        'last16_loss_reason_top': dict(last16_loss_counter.most_common(10)),
        'canonical_metric_row_review': canon_data,
        'open_entry_snapshot_review_v588': snap_data,
        'spine_policy': 'single paper review writer; legacy v569/v570/v572/v578/v588/v589 writers routed here',
    }
    return obj


def write_paper_review_spine_cache_v589(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        save_json(FILES['trade_review'], _v589_build_paper_review_spine(status))
    except Exception as exc:
        log_error('write_paper_review_spine_cache_v589', exc)


# Legacy review writer names are kept for compatibility, but all now route to one spine.
def write_trade_review_cache_v569(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


def write_trade_review_cache_v570(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


def write_trade_review_cache_v572(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


def write_trade_review_cache_v578(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


# v590 hard lock: any legacy-named review writer call is forced to the v590 spine.
def write_trade_review_cache_v588(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)

def write_trade_review_cache_v589(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


_v589_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    # Score cache 기능은 그대로 유지하고, 마지막에 review spine을 반드시 v589 단일본으로 덮는다.
    _v589_prev_write_score_cache(status)
    write_paper_review_spine_cache_v589(status)

# v584 final entrypoint. The file deliberately has one runtime entrypoint at the end.


# =============================================================================
# paper_bot v0.213 / v591: review spine live-cycle hard lock
# =============================================================================
# 목적:
# - v590에서 main reader는 잠겼지만 live paper loop가 v590 spine을 즉시 쓰지 못한 문제 차단.
# - score/write_status/run_cycle 어디로 지나가도 마지막에 paper_review_spine_v591을 직접 저장한다.
# - 새 복기 기능 추가가 아니라 CLOSED 복기 cache writer 위치를 live 본선에 고정한다.
V591_REVIEW_SCHEMA = 'paper_review_spine_v591'


def _v591_build_paper_review_spine(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    try:
        obj = _v589_build_paper_review_spine(status) if '_v589_build_paper_review_spine' in globals() else {}
        if not isinstance(obj, dict):
            obj = {}
    except Exception as exc:
        log_error('v591_build_base_spine', exc)
        obj = {}
    # fallback minimal object if prior builder failed
    if not obj:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
        today_rows = _v557_filter_today(rows, now_ts()) if '_v557_filter_today' in globals() else rows
        obj = {
            'summary_text': '\n'.join([
                '📉 복기 /trade_review · v591 paper review spine',
                f'- 기준: paper CLOSED tail + OPEN canonical_entry_snapshot 단일 spine',
                f'- 오늘 CLOSED {len(today_rows)}개',
                '[판독]',
                '- v591 live-cycle writer가 생성한 최소 spine입니다.',
            ]),
            'today_closed_count': len(today_rows),
        }
    txt = str(obj.get('summary_text') or '').strip()
    if txt:
        # title/schema label normalize
        txt = re.sub(r'📉 복기 /trade_review · v\d+[^\n]*', '📉 복기 /trade_review · v591 paper review spine', txt, count=1)
        txt = txt.replace('v590 paper review spine', 'v591 paper review spine')
        if '📉 복기 /trade_review · v591 paper review spine' not in txt.splitlines()[0]:
            txt = '📉 복기 /trade_review · v591 paper review spine\n' + txt
    else:
        txt = '📉 복기 /trade_review · v591 paper review spine\n- summary_text 준비 중'
    obj.update({
        'schema': V591_REVIEW_SCHEMA,
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v591_live_cycle_review_spine_writer',
        'source': 'paper_bot_closed_tail_cache_only_live_cycle',
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'summary_text': txt,
        'spine_policy': 'v594 stable restore: exact v591 successful live-cycle writer restored; schema kept as paper_review_spine_v591 for main reader compatibility; no v592/v593 detail builder',
    })
    return obj


def write_paper_review_spine_cache_v591(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        save_json(FILES['trade_review'], _v591_build_paper_review_spine(status))
    except Exception as exc:
        log_error('write_paper_review_spine_cache_v591', exc)


# Legacy review writer names are compatibility aliases only; all route to v591.
def write_trade_review_cache_v569(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v570(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v572(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v578(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v588(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v589(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v590(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


_v591_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v591_prev_write_score_cache(status)
    write_paper_review_spine_cache_v591(status)


_v591_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    _v591_prev_write_status(status)
    write_paper_review_spine_cache_v591(status)


_v591_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v591_prev_run_cycle()
    write_paper_review_spine_cache_v591(st if isinstance(st, dict) else None)
    return st


# =============================================================================
# paper_bot v0.219 / v604: OPEN disappearance guard + CLOSED cache heartbeat
# - OPEN 파일은 paper_bot 소유 장부다. save_open 때 backup도 같이 남긴다.
# - 재시작/배포 뒤 OPEN이 0으로 보이는데 직전 backup에는 OPEN이 있으면 status/trace에 경고를 남긴다.
# - 자동 복원은 120초 이내 backup에만 제한한다. 오래된 포지션을 임의로 되살리지 않는다.
# - 청산조건/자동매수/BUY_READY 변경 없음.
# =============================================================================
def _v604_open_backup_path() -> Path:
    return FILES.get('open_backup', BASE_DIR / 'paper_bot_open_backup.json')

def _v604_open_loss_trace_path() -> Path:
    return FILES.get('open_loss_trace', BASE_DIR / 'paper_bot_open_loss_trace.jsonl')

def _v604_open_count_from_obj(obj: Any) -> int:
    return len(obj) if isinstance(obj, dict) else 0

def _v604_backup_open(open_pos: Dict[str, Dict[str, Any]], source: str = 'save_open') -> None:
    try:
        obj = {
            'schema': 'paper_open_backup_v604',
            'version': VERSION,
            'updated_ts': now_ts(),
            'updated_text': iso_ts() if 'iso_ts' in globals() else now_text(),
            'source': source,
            'open_count': _v604_open_count_from_obj(open_pos),
            'positions': open_pos if isinstance(open_pos, dict) else {},
        }
        save_json(_v604_open_backup_path(), obj)
    except Exception as exc:
        log_error('v604_backup_open', exc)

def _v604_load_open_backup() -> Dict[str, Any]:
    obj = load_json(_v604_open_backup_path(), {}) or {}
    return obj if isinstance(obj, dict) else {}

def _v604_trace_open_loss(phase: str, info: Dict[str, Any]) -> None:
    try:
        row = {
            'schema': 'paper_open_loss_trace_v604',
            'version': VERSION,
            'phase': phase,
            'updated_ts': now_ts(),
            'updated_text': iso_ts() if 'iso_ts' in globals() else now_text(),
            **(info if isinstance(info, dict) else {}),
        }
        append_jsonl(_v604_open_loss_trace_path(), row)
    except Exception as exc:
        log_error('v604_trace_open_loss', exc)

_v604_base_load_open = load_open
# v741: legacy v604 backup-restore load_open override removed.
# Active OPEN owner is the normalized load_open/save_open defined above.
_v604_base_save_open = save_open
# v741: legacy v604 save_open wrapper removed to avoid resurrecting/quarantine-bypassing old OPEN rows.

_v604_base_run_cycle = run_cycle
def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    before_open = _v604_base_load_open()
    before_closed = line_count_cached(FILES['closed'], ttl=0)
    st = _v604_base_run_cycle()
    after_open = _v604_base_load_open()
    after_closed = line_count_cached(FILES['closed'], ttl=0)
    lost_open = bool(before_open and not after_open and after_closed <= before_closed)
    if lost_open:
        info = {
            'before_open_count': len(before_open),
            'after_open_count': len(after_open),
            'before_closed_total': before_closed,
            'after_closed_total': after_closed,
            'tickers': [str((v or {}).get('ticker') or k) for k, v in before_open.items() if isinstance(v, dict)][:20],
            'action': 'warning_only_no_old_position_resurrection',
        }
        _v604_trace_open_loss('open_disappeared_without_closed', info)
        if isinstance(st, dict):
            st['open_closed_spine_warning'] = 'OPEN disappeared but CLOSED did not increase'
            st['open_loss_trace_file'] = str(_v604_open_loss_trace_path())
            try:
                status = load_json(FILES['status'], {}) or {}
                if isinstance(status, dict):
                    status.update(st)
                    status['open_closed_spine_warning'] = st['open_closed_spine_warning']
                    status['open_loss_trace_file'] = st['open_loss_trace_file']
                    save_json(FILES['status'], status)
            except Exception as exc:
                log_error('v604_status_open_loss_warning', exc)
    return st

_v604_base_write_score_cache = write_score_cache
def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    # CLOSED cache 주인은 paper_bot. run_cycle에서 closed_this_cycle이 있으면 즉시 score/review heartbeat를 남긴다.
    _v604_base_write_score_cache(status)
    try:
        status = status if isinstance(status, dict) else {}
        obj = load_json(FILES['score'], {}) or {}
        if isinstance(obj, dict):
            obj['paper_open_closed_spine_v604'] = {
                'version': VERSION,
                'status_closed_total': status.get('closed_total'),
                'closed_this_cycle': status.get('closed_this_cycle'),
                'open_count': status.get('open_count'),
                'updated_ts': now_ts(),
                'policy': 'score cache is written immediately from paper closed tail; main does not read ledger directly.',
            }
            save_json(FILES['score'], obj)
    except Exception as exc:
        log_error('v604_score_spine_mark', exc)



# =============================================================================
# paper_bot v0.221 / v607: CLOSED 알림 원천 ↔ CLOSED 장부 ↔ score/review cache 단일화
# - paper OPEN/CLOSED 판단·청산조건은 변경하지 않는다.
# - paper_bot이 만든 CLOSED 장부와 close_alert_trace를 paper 공장 내부에서 대조한다.
# - main_bot은 여전히 paper score/review/status cache만 읽는다.
# - 알림은 왔지만 CLOSED tail cache에 없는 row는 score/review cache에서 reconcile source로 표시한다.
# =============================================================================

def _v607_close_alert_trace_path() -> Path:
    return FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl')


def _v607_row_key(row: Dict[str, Any]) -> str:
    tid = str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or '').strip()
    if tid:
        return 'id:' + tid
    ticker = normalize_ticker(row.get('ticker'))
    opened = fnum(row.get('opened_at'), default=0.0)
    closed = fnum(row.get('closed_at'), row.get('ts'), default=0.0)
    if ticker and (opened or closed):
        return f'tc:{ticker}:{round(opened or 0.0,1)}:{round(closed or 0.0,1)}'
    return ''


def _v607_alert_to_closed_row(row: Dict[str, Any]) -> Dict[str, Any]:
    ts = fnum(row.get('closed_at'), row.get('ts'), default=0.0)
    out = {
        'schema': 'paper_closed_reconciled_from_close_alert_trace_v607',
        'reconciled_from_close_alert_trace': True,
        'source': 'paper_bot_close_alert_trace',
        'source_alert_phase': row.get('phase'),
        'source_alert_version': row.get('version'),
        'source_alert_build': row.get('build'),
        'ticker': normalize_ticker(row.get('ticker')),
        'pos_id': row.get('pos_id') or row.get('event_id') or row.get('entry_id'),
        'event_id': row.get('event_id') or row.get('pos_id') or row.get('entry_id'),
        'opened_at': fnum(row.get('opened_at'), default=0.0),
        'opened_at_text': row.get('opened_at_text'),
        'closed_at': ts,
        'closed_at_text': row.get('closed_at_text') or (iso_ts(ts) if ts else ''),
        'entry_price': fnum(row.get('entry_price'), default=0.0),
        'exit_price': fnum(row.get('exit_price'), default=0.0),
        'pnl_pct': fnum(row.get('pnl_pct'), default=0.0),
        'profit_pct': fnum(row.get('pnl_pct'), default=0.0),
        'strategy_label': row.get('strategy') or row.get('strategy_label') or row.get('strategy_key') or '-',
        'strategy': row.get('strategy') or row.get('strategy_label') or row.get('strategy_key') or '-',
        'candidate_grade': row.get('candidate_grade') or row.get('grade') or '-',
        'exit_reason': row.get('exit_reason') or row.get('exit_rule') or '-',
        'closed_paper_version': row.get('version') or VERSION,
        'opened_paper_version': row.get('version') or VERSION,
        'entry_build_key': row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or row.get('patch_version') or active_patch_version(),
        'open_build_key': row.get('open_build_key') or row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or active_patch_version(),
        'entry_patch_version': row.get('entry_patch_version') or row.get('entry_build_key') or row.get('score_patch_version') or row.get('opened_patch_version') or active_patch_version(),
        'score_patch_version': row.get('score_patch_version') or row.get('entry_build_key') or row.get('opened_patch_version') or active_patch_version(),
        'opened_patch_version': row.get('opened_patch_version') or row.get('entry_build_key') or row.get('score_patch_version') or active_patch_version(),
        'patch_version': row.get('patch_version') or row.get('entry_build_key') or row.get('score_patch_version') or active_patch_version(),
        'closed_patch_version': row.get('closed_patch_version') or row.get('close_patch_version') or active_patch_version(),
        'close_patch_version': row.get('close_patch_version') or row.get('closed_patch_version') or active_patch_version(),
        'score_main_version': active_main_version(),
        'closed_main_version': active_main_version(),
    }
    return out


def _v607_reconciled_closed_rows(limit_closed: int = 1200, limit_alert: int = 1200) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    ledger = [r for r in read_jsonl_tail(FILES['closed'], limit_closed) if isinstance(r, dict)]
    ledger_keys = set()
    for r in ledger:
        k = _v607_row_key(r)
        if k:
            ledger_keys.add(k)
    raw_alerts = [r for r in read_jsonl_tail(_v607_close_alert_trace_path(), limit_alert) if isinstance(r, dict) and str(r.get('kind') or '').lower() == 'closed']
    # 같은 CLOSED 알림은 attempt_start/send_ok 두 줄이 남을 수 있다. send_ok를 우선한다.
    best: Dict[str, Dict[str, Any]] = {}
    phase_rank = {'send_ok': 3, 'attempt_start': 2, 'without_alert_trace': 1, 'send_error': 0, 'message_build_error': 0}
    for r in raw_alerts:
        k = _v607_row_key(r)
        if not k:
            continue
        cur = best.get(k)
        if not cur or phase_rank.get(str(r.get('phase') or ''), 0) >= phase_rank.get(str(cur.get('phase') or ''), 0):
            best[k] = r
    recovered = []
    for k, r in best.items():
        if k not in ledger_keys:
            cr = _v607_alert_to_closed_row(r)
            if cr.get('ticker') and fnum(cr.get('closed_at'), default=0.0) > 0:
                recovered.append(cr)
    rows = ledger + recovered
    rows.sort(key=lambda x: fnum(x.get('closed_at'), x.get('ts'), default=0.0))
    meta = {
        'schema': 'paper_closed_source_reconcile_v607',
        'version': VERSION,
        'ledger_count': len(ledger),
        'alert_trace_count': len(raw_alerts),
        'alert_unique_count': len(best),
        'alert_recovered_count': len(recovered),
        'source_policy': 'paper cache producer reads CLOSED ledger plus paper close_alert_trace reconciliation; main still reads cache only',
        'recovered_tail': [
            {
                'ticker': r.get('ticker'), 'pnl_pct': r.get('pnl_pct'), 'closed_at_text': r.get('closed_at_text'),
                'source_alert_version': r.get('source_alert_version'), 'strategy': r.get('strategy_label') or r.get('strategy')
            } for r in recovered[-10:]
        ],
    }
    return rows, meta


def _v607_build_score_cache_obj(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v557_filter_today(rows, nowv)
    by_grade: Dict[str, List[Dict[str, Any]]] = {}
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    by_version: Dict[str, List[Dict[str, Any]]] = {}
    by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    by_strategy_version: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    by_profile: Dict[str, List[Dict[str, Any]]] = {}
    by_profile_exit: Dict[str, List[Dict[str, Any]]] = {}
    by_strategy_exit: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        strategy_key = _strategy_key(r)
        version_key = _main_version_key(r)
        by_grade.setdefault(_score_bucket(r), []).append(r)
        by_strategy.setdefault(strategy_key, []).append(r)
        by_version.setdefault(version_key, []).append(r)
        by_version_strategy.setdefault(version_key, {}).setdefault(strategy_key, []).append(r)
        by_strategy_version.setdefault(strategy_key, {}).setdefault(version_key, []).append(r)
        prof = str(r.get('entry_profile') or 'unknown')
        if prof in {'spike_fast_early', 'spike_runner'}:
            prof = 'spike'
        elif prof in {'spike_fast_watch', 'normal_watch'}:
            prof = 'watch'
        by_profile.setdefault(prof, []).append(r)
        ex = str(r.get('exit_reason') or r.get('exit_rule') or '-')
        by_profile_exit.setdefault(f'{prof}:{ex}', []).append(r)
        by_strategy_exit.setdefault(f'{strategy_key}:{ex}', []).append(r)
    today_by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    today_by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    for tr in today_rows:
        today_by_strategy.setdefault(_strategy_key(tr), []).append(tr)
        today_by_version_strategy.setdefault(_main_version_key(tr), {}).setdefault(_strategy_key(tr), []).append(tr)
    version_summary = {k: _score_stat(v) for k, v in by_version.items()}
    version_strategy_stats = {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in by_version_strategy.items()}
    strategy_version_stats = {sk: {vk: _score_stat(vrows) for vk, vrows in vmap.items()} for sk, vmap in by_strategy_version.items()}
    return {
        'schema': 'paper_score_cache_v607_closed_source_reconciled',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'score_scope': 'paper_closed_ledger_plus_close_alert_trace_reconciled_cache_only',
        'updated_at': nowv,
        'updated_at_text': iso_ts(),
        'current_closed_count': len(rows),
        'closed_count': len(rows),
        'source': 'paper_bot_closed_source_reconciled_v607',
        'closed_source_reconcile': reconcile,
        'global_stats': _score_stat(rows),
        'today_scope': 'Asia/Seoul_day_midnight_to_now_cache_only',
        'today_timezone': 'Asia/Seoul',
        'today_day_key': _kst_day_key(nowv),
        'today_start_ts': _v557_today_start_ts(nowv),
        'today_start_text': iso_ts(_v557_today_start_ts(nowv)),
        'today_closed_count': len(today_rows),
        'today_global_stats': _score_stat(today_rows),
        'today_strategy_stats': {k: _score_stat(v) for k, v in today_by_strategy.items()},
        'today_version_strategy_stats': {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in today_by_version_strategy.items()},
        'grade_stats': {**{k: _score_stat(v) for k, v in by_grade.items()}, 'ALL': _score_stat(rows)},
        'strategy_primary_stats': {k: _score_stat(v) for k, v in by_strategy.items()},
        'strategy_stats': {k: _score_stat(v) for k, v in by_strategy.items()},
        'strategy_exit_stats': {k: _score_stat(v) for k, v in by_strategy_exit.items()},
        'strategy_primary_exit_stats': {k: _score_stat(v) for k, v in by_strategy_exit.items()},
        'strategy_outcome_analysis': _v543_build_strategy_outcome_analysis(by_strategy),
        'entry_profile_stats': {k: _score_stat(v) for k, v in by_profile.items()},
        'profile_exit_stats': {k: _score_stat(v) for k, v in by_profile_exit.items()},
        'version_summary': version_summary,
        'version_strategy_stats': version_strategy_stats,
        'strategy_version_stats': strategy_version_stats,
        'version_strategy_schema': 'v607_patch_x_strategy_closed_reconciled_cache_only',
        'version_summary_schema': 'v607_patch_version_key_with_close_alert_reconcile',
        'version_summary_keys': sorted(version_summary.keys()),
        'recent_3h': _build_recent_12h(rows, 3.0),
        'recent_3h_stats': _build_recent_12h(rows, 3.0).get('global'),
        'recent_6h': _build_recent_12h(rows, 6.0),
        'recent_6h_stats': _build_recent_12h(rows, 6.0).get('global'),
        'recent_12h': _build_recent_12h(rows, 12.0),
        'active_main_version': active_main_version(),
        'active_main_version_source': active_main_version_detail()[1],
        'active_patch_version': active_patch_version(),
        'active_patch_version_source': active_patch_version_detail()[1],
        'version_key_policy': 'v634_entry_build_key_first_open_time_patch_closed_source_reconciled',
        'legacy_deploy_target_version': _legacy_deploy_target_version(),
        'version_stats': version_summary,
        'main_version_stats': version_summary,
        'status_open_count': (status or {}).get('open_count') if isinstance(status, dict) else None,
    }


def _v607_build_trade_review_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v557_filter_today(rows, nowv)
    recovered = [r for r in today_rows if r.get('reconciled_from_close_alert_trace')]
    lines = [
        '📉 복기 /trade_review · v607 CLOSED source 단일화',
        '- 기준: paper CLOSED 원장 + paper close_alert_trace 대조 cache. main은 장부 직접조회 없음.',
        f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 알림원천 보강 {len(recovered)}개",
    ]
    if today_rows:
        lines.append('[오늘 CLOSED 최근]')
        for r in today_rows[-8:]:
            src = '알림원천보강' if r.get('reconciled_from_close_alert_trace') else '장부'
            lines.append(f"- {r.get('ticker','-')} {fnum(r.get('pnl_pct'), default=0.0):+.2f}% / {r.get('strategy_label') or r.get('strategy') or '-'} / {src}")
    else:
        lines.append('- 오늘 CLOSED 없음')
    lines += [
        '[source 대조]',
        f"- CLOSED 장부 {reconcile.get('ledger_count')} / close_alert unique {reconcile.get('alert_unique_count')} / cache 보강 {reconcile.get('alert_recovered_count')}",
        '- 조건/S등급/청산/장부는 변경하지 않는다.',
    ]
    block_lines, block_data = _v584_canonical_review_block(today_rows)
    lines.append('')
    lines.extend(block_lines)
    return {
        'schema': 'paper_review_spine_v607_closed_source_reconciled',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v607_closed_source_reconcile_writer',
        'source': 'paper_closed_ledger_plus_close_alert_trace_cache_only_v607',
        'updated_at': nowv,
        'updated_at_text': iso_ts(),
        'today_closed_count': len(today_rows),
        'closed_source_reconcile': reconcile,
        'canonical_metric_row_review': block_data,
        'summary_text': '\n'.join(lines),
    }


_v607_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    try:
        rows, reconcile = _v607_reconciled_closed_rows()
        save_json(FILES['score'], _v607_build_score_cache_obj(rows, status, reconcile))
        save_json(FILES['trade_review'], _v607_build_trade_review_cache(rows, status, reconcile))
    except Exception as exc:
        log_error('v607_write_score_cache_reconciled', exc)
        _v607_prev_write_score_cache(status)


_v607_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    _v607_prev_write_status(status)
    try:
        write_score_cache(status)
    except Exception as exc:
        log_error('v607_write_status_score_cache_reconciled', exc)


# =============================================================================
# paper_bot v0.222 / v608: paper 알림·1시간 요약 가독성 정리
# - OPEN/CLOSED/청산/장부/score/review 계산은 변경하지 않는다.
# - 알림 문구만 결과/진입/복기/주의 구간으로 나눠 읽기 쉽게 만든다.
# - 1시간 요약은 hot-rank, 후보상태, CLOSED 요약을 cache만 읽어 정리한다.
# =============================================================================
def _v608_strategy_name(row: Dict[str, Any]) -> str:
    return str(row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-')

def _v608_grade(row: Dict[str, Any]) -> str:
    return str(row.get('candidate_grade') or row.get('s_stage') or row.get('grade') or 'S1')

def _v608_section(title: str, lines: List[str]) -> List[str]:
    clean=[x for x in lines if isinstance(x,str) and x.strip()]
    return ([title] + clean) if clean else []

def _v561_open_message_text(pos: Dict[str, Any]) -> str:  # type: ignore[override]
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ''
    diag = _v586_diag_from_trade(pos)
    extra_lines = format_entry_diag_lines(diag) if diag else ['- 진입근거: strategy 상세값 미전달']
    header = [
        '🟢 paper OPEN',
        f"- 종목: {t}",
        f"- 진입가: {fmt_price(pos.get('entry_price'))}",
        f"- 등급: {_v608_grade(pos)} / 점수 {fnum(pos.get('score'), default=0.0):.2f}",
    ]
    info = [
        f"- 전략: {_v608_strategy_name(pos)}",
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}",
    ]
    bottom = [f"- 바로보기: {link}" if link else '', f"- paper: {VERSION}"]
    return '\n'.join(header + [''] + _v608_section('📌 진입 정보', info) + [''] + _v608_section('✅ 확인/구조', extra_lines) + [''] + bottom)

def _v567_closed_message_text(row: Dict[str, Any]) -> str:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker'))
    diag = _v586_diag_from_trade(row)
    extra_lines = format_entry_diag_lines(diag) if diag else ['- 진입근거: strategy 상세값 미전달']
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    result_icon = '✅' if pnl > 0 else ('❌' if pnl < 0 else '⚠️')
    header = [
        f"{closed_title(row)}",
        f"- 종목: {t}",
        f"- 손익: {pnl:+.2f}%",
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}",
    ]
    prices = [
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}",
        f"- 보유: {row.get('age_min','-')}분",
    ]
    review = [
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%",
        f"- 최종/놓친수익: {pnl:+.2f}% / {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}%",
        f"- 평가: {row.get('close_review_tag','관찰')}",
    ]
    ff = _v494_fast_fail_cause_line(row) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''
    if ff:
        review.append(ff)
    info = [
        f"- 전략: {_v608_strategy_name(row)}",
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}",
    ]
    return '\n'.join(header + [''] + _v608_section(f'{result_icon} 결과', prices) + [''] + _v608_section('📉 청산 복기', review) + [''] + _v608_section('📌 진입 정보', info) + [''] + _v608_section('🧾 진입 당시 확인값', extra_lines) + ['', f"- paper: {VERSION}"])

def _v608_closed_hourly_lines() -> List[str]:
    score = load_json(FILES.get('score', BASE_DIR / 'paper_bot_score_cache.json'), {}) or {}
    if not isinstance(score, dict):
        return ['📉 CLOSED 요약', '- score cache 준비중']
    today = score.get('today_global_stats') if isinstance(score.get('today_global_stats'), dict) else {}
    recent = score.get('recent_12h') if isinstance(score.get('recent_12h'), dict) else {}
    rec = score.get('closed_source_reconcile') if isinstance(score.get('closed_source_reconcile'), dict) else {}
    lines = ['📉 CLOSED 요약']
    lines.append(f"- 오늘: {int(today.get('n') or today.get('count') or 0)}전 / 합산 {fnum(today.get('sum_pct'), today.get('total_pct'), default=0.0):+.2f}% / 평균 {fnum(today.get('avg_pct'), default=0.0):+.2f}%")
    if recent:
        lines.append(f"- 최근 12시간: {int(recent.get('count') or recent.get('n') or 0)}전 / 합산 {fnum(recent.get('sum_pct'), recent.get('total_pct'), default=0.0):+.2f}%")
    if rec:
        lines.append(f"- CLOSED source: 장부 {rec.get('ledger_count')} / 알림보강 {rec.get('alert_recovered_count')}")
    return lines

def paper_hourly_text() -> str:  # type: ignore[override]
    lines = ['🧭 paper 1시간 요약 · v608 readable']
    lines += ['', '🧪 현재 상태', pstatus_text()]
    lines += ['', * _v608_closed_hourly_lines()]
    lines += ['', '🔥 hot-rank / 후보 흐름', hot_summary_text()]
    lines += ['', '📌 S1/S2/S3 후보 상태', candidate_summary_text()]
    return '\n'.join(lines)



# =============================================================================
# paper_bot v0.223 / v612: paper 명령어 가독성 정리
# - OPEN/CLOSED/청산/장부/score 계산 변경 없음.
# - paper 명령은 paper_bot이 만든 cache/status만 읽어 보기 좋은 섹션으로 표시한다.
# =============================================================================

def paper_guide_text() -> str:
    return "\n".join([
        "🧭 paper 명령어 가이드 /pguide",
        "",
        "✅ 현재 상태",
        "- /pstatus : paper ON/OFF, OPEN 수, 후보선별",
        "- /popen : 현재 진행 중인 OPEN만 보기",
        "",
        "📌 후보/시장",
        "- /candidate_summary : paper가 받은 S1/S2/S3 후보",
        "- /hot_summary : 1시간 hot-rank 요약",
        "- /paper_hourly : 후보·hot-rank·CLOSED를 1시간 요약",
        "",
        "🧯 점검",
        "- /perror : paper 오류",
        "- /plog : 최근 로그",
        "- /pversion : paper 버전",
        "",
        "고정: paper 명령은 cache/status만 읽고 장부를 고치지 않습니다.",
    ])

_v612_prev_pstatus_text = pstatus_text
_v612_prev_popen_text = popen_text
_v612_prev_candidate_summary_text = candidate_summary_text
_v612_prev_hot_summary_text = hot_summary_text
_v612_prev_paper_hourly_text = paper_hourly_text
_v612_prev_handle_command = handle_command

def pstatus_text() -> str:  # type: ignore[override]
    base = _v612_prev_pstatus_text()
    return base.replace('/pstatus', '/pstatus · 현재상태').replace('paper 상태', 'paper 상태').replace('v605 reader-spine', 'v612 readable cache') + "\n\n[읽는 법]\n- OPEN 0이면 진행 중인 모의매매 없음\n- S1선택 0이면 strategy가 아직 paper 진입 후보를 안 넘김\n- 이 명령은 cache만 읽고 장부를 수정하지 않음"

def popen_text() -> str:  # type: ignore[override]
    base = _v612_prev_popen_text()
    return base.replace('/popen', '/popen · 진행중 OPEN').replace('v605 reader-spine', 'v612 readable cache')

def candidate_summary_text() -> str:  # type: ignore[override]
    base = _v612_prev_candidate_summary_text()
    return base.replace('/candidate_summary', '/candidate_summary · paper 후보') + "\n\n[뜻]\n- S1: paper 진입 후보\n- S2: 재확인 대기\n- S3: 관찰 후보"

def paper_hourly_text() -> str:  # type: ignore[override]
    return "\n\n".join([
        "🧭 paper 1시간 요약 · v612",
        "✅ 현재 상태",
        _v612_prev_pstatus_text(),
        "📉 CLOSED 요약",
        "\n".join(_v608_closed_hourly_lines()) if '_v608_closed_hourly_lines' in globals() else "- score cache 준비중",
        "🔥 hot-rank",
        _v612_prev_hot_summary_text(),
        "📌 paper 후보",
        _v612_prev_candidate_summary_text(),
        "고정: 1시간 요약은 cache/status만 읽습니다.",
    ])

def handle_command(cmd: str) -> str:  # type: ignore[override]
    c = cmd.strip().split()[0].lower()
    if c in {"/pguide", "/guide", "/help", "/commands"}:
        return paper_guide_text()
    if c in {"/pstatus", "/status"}:
        return pstatus_text()
    if c in {"/popen", "/open"}:
        return popen_text()
    if c in {"/candidate_summary", "/candidate", "/pcandidate"}:
        return candidate_summary_text()
    if c in {"/paper_hourly", "/hourly", "/phourly"}:
        return paper_hourly_text()
    if c in {"/pversion", "/version"}:
        return f"{VERSION} / {BUILD_LABEL}"
    return _v612_prev_handle_command(cmd)



# =============================================================================
# paper_bot v0.225 / v621: OPEN/status + score/review cache source 단일화
# - OPEN 주인은 paper_bot_open.json이다. status/handoff는 open file 개수를 따라간다.
# - score/review는 같은 CLOSED reconciled rows로 한 번에 생성한다.
# - 조건/S등급/청산/장부 삭제/자동매수 변경 없음.
# =============================================================================
try:
    BUILD_LABEL = 'v621_open_score_review_source_spine_20260601'
except Exception:
    pass


def _v621_raw_open_positions() -> Dict[str, Dict[str, Any]]:
    try:
        obj = _v604_base_load_open() if '_v604_base_load_open' in globals() else load_json(FILES['open'], {})
    except Exception:
        obj = load_json(FILES['open'], {}) or {}
    if not isinstance(obj, dict):
        return {}
    out: Dict[str, Dict[str, Any]] = {}
    for k, v in obj.items():
        if isinstance(v, dict):
            out[str(k)] = v
    return out


def _v621_sync_open_source_status(status: Optional[Dict[str, Any]] = None, phase: str = 'sync') -> Dict[str, Any]:
    """Synchronize status/handoff/trace counters to the authoritative open file.
    This does not resurrect or delete positions. It only fixes displayed cache counters.
    """
    open_pos = _v621_raw_open_positions()
    open_count = len(open_pos)
    nowv = now_ts()
    st = load_json(FILES['status'], {}) or {}
    if not isinstance(st, dict):
        st = {}
    if isinstance(status, dict):
        st.update(status)
    raw_before = st.get('open_count')
    st.update({
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'open_count': open_count,
        'open_total': open_count,
        'open_strict': open_count,
        'open_file_count': open_count,
        'open_source': 'paper_bot_open.json',
        'open_source_policy_v621': 'paper_bot_open.json is authoritative; status/handoff mirror it after each cycle.',
        'open_source_raw_status_before_v621': raw_before,
        'open_source_sync_phase': phase,
        'open_source_sync_at': nowv,
        'open_source_sync_text': iso_ts(nowv) if 'iso_ts' in globals() else now_text(),
    })
    snap = st.get('paper_candidate_snapshot') if isinstance(st.get('paper_candidate_snapshot'), dict) else {}
    if isinstance(snap, dict):
        snap = dict(snap)
        snap.update({'open_count': open_count, 'open_total': open_count})
        st['paper_candidate_snapshot'] = snap
    save_json(FILES['status'], st)
    for key in ('handoff_status', 'trace'):
        try:
            obj = load_json(FILES[key], {}) or {}
            if isinstance(obj, dict):
                obj['open_count'] = open_count
                obj['open_total'] = open_count
                obj['open_file_count'] = open_count
                obj['open_source_policy_v621'] = 'mirrors paper_bot_open.json'
                obj['open_source_sync_at'] = nowv
                snap2 = obj.get('paper_candidate_snapshot') if isinstance(obj.get('paper_candidate_snapshot'), dict) else {}
                if isinstance(snap2, dict):
                    snap2 = dict(snap2)
                    snap2.update({'open_count': open_count, 'open_total': open_count})
                    obj['paper_candidate_snapshot'] = snap2
                save_json(FILES[key], obj)
        except Exception as exc:
            log_error(f'v621_sync_{key}', exc)
    return st


def _v621_stat_local(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) > 0)
    total = sum(fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) for r in rows)
    return {'n': n, 'wins': wins, 'losses': max(0, n-wins), 'total_pct': round(total, 4), 'sum_pct': round(total, 4), 'avg_pct': round(total/n, 4) if n else 0.0, 'win_rate_pct': round(wins/n*100.0, 2) if n else 0.0}


def _v621_build_trade_review_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v557_filter_today(rows, nowv) if '_v557_filter_today' in globals() else rows
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    for r in today_rows:
        by_strategy.setdefault(_strategy_key(r) if '_strategy_key' in globals() else str(r.get('strategy_label') or r.get('strategy') or '-'), []).append(r)
    lines = [
        '📉 복기 /trade_review · v621 score/review source spine',
        '- 기준: paper CLOSED 원장 + close_alert_trace 보강 rows. score cache와 같은 rows를 사용합니다.',
        f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 전체 cache {len(rows)}개 / 알림원천 보강 {reconcile.get('alert_recovered_count',0)}개",
        '', '[오늘 전략별 복기]',
    ]
    if by_strategy:
        for sk, rs in sorted(by_strategy.items(), key=lambda kv: (len(kv[1]), str(kv[0])), reverse=True)[:10]:
            st = _v621_stat_local(rs)
            mark = '⚠️' if st['n'] >= 3 and (st['win_rate_pct'] < 35 or st['total_pct'] < 0) else '✅'
            lines.append(f"- {mark} {sk}: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['win_rate_pct']:.1f}% / 합산 {st['total_pct']:+.2f}% / 평균 {st['avg_pct']:+.2f}%")
    else:
        lines.append('- 오늘 CLOSED 없음')
    if today_rows:
        lines += ['', '[최근 CLOSED]']
        for r in today_rows[-8:]:
            src = '알림보강' if r.get('reconciled_from_close_alert_trace') else '장부'
            lines.append(f"- {r.get('ticker','-')} {fnum(r.get('pnl_pct'), default=0.0):+.2f}% / {r.get('strategy_label') or r.get('strategy') or '-'} / {src}")
    lines += ['', '[source 대조]', f"- CLOSED 장부 {reconcile.get('ledger_count')} / close_alert unique {reconcile.get('alert_unique_count')} / cache 보강 {reconcile.get('alert_recovered_count')}", '- 조건/S등급/청산/장부는 변경하지 않습니다.']
    try:
        block_lines, block_data = _v584_canonical_review_block(today_rows)
        lines.append('')
        lines.extend(block_lines)
    except Exception:
        block_data = {}
    return {
        'schema': 'paper_review_spine_v621_score_review_source_spine',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v621_score_review_same_rows_writer',
        'source': 'same_reconciled_rows_as_paper_score_cache_v621',
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv) if 'iso_ts' in globals() else now_text(),
        'today_closed_count': len(today_rows),
        'closed_count': len(rows),
        'closed_source_reconcile': reconcile,
        'canonical_metric_row_review': block_data,
        'today_strategy_stats': {k: _v621_stat_local(v) for k, v in by_strategy.items()},
        'summary_text': '\n'.join(lines),
    }


_v621_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    try:
        rows, reconcile = _v607_reconciled_closed_rows() if '_v607_reconciled_closed_rows' in globals() else (read_jsonl(FILES['closed'], max_lines=5000), {})
        save_json(FILES['score'], _v607_build_score_cache_obj(rows, status, reconcile) if '_v607_build_score_cache_obj' in globals() else {'schema':'paper_score_cache_v621_minimal','closed_count':len(rows),'updated_at':now_ts()})
        save_json(FILES['trade_review'], _v621_build_trade_review_cache(rows, status, reconcile))
    except Exception as exc:
        log_error('v621_write_score_review_same_rows', exc)
        _v621_prev_write_score_cache(status)


_v621_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    _v621_prev_write_status(status)
    try:
        st = _v621_sync_open_source_status(status, phase='write_status')
        write_score_cache(st)
    except Exception as exc:
        log_error('v621_write_status_open_score_spine', exc)


_v621_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v621_prev_run_cycle()
    try:
        st = _v621_sync_open_source_status(st if isinstance(st, dict) else {}, phase='run_cycle')
        write_score_cache(st)
    except Exception as exc:
        log_error('v621_run_cycle_open_score_spine', exc)
    return st if isinstance(st, dict) else {}


def pstatus_text() -> str:  # type: ignore[override]
    _v621_sync_open_source_status({}, phase='pstatus_read')
    base = _v612_prev_pstatus_text() if '_v612_prev_pstatus_text' in globals() else ''
    return base.replace('v605 reader-spine', 'v621 open-source spine') + "\n\n[v621]\n- OPEN 기준은 paper_bot_open.json입니다. status/handoff는 이 파일을 따라갑니다."


def popen_text() -> str:  # type: ignore[override]
    _v621_sync_open_source_status({}, phase='popen_read')
    base = _v612_prev_popen_text() if '_v612_prev_popen_text' in globals() else ''
    return base.replace('v605 reader-spine', 'v621 open-source spine') + "\n\n[v621]\n- 진행중 OPEN은 paper_bot_open.json 기준입니다."



# =============================================================================
# paper_bot v0.226 / v622: 전략별 승리군·패배군 원인분해 복구
# - v621과 같은 CLOSED reconciled rows를 사용한다.
# - 조건/S등급/청산/장부/자동매수 변경 없음.
# - main은 paper_bot_trade_review_cache.json summary_text만 읽는다.
# =============================================================================
try:
    BUILD_LABEL = 'v622_strategy_win_loss_review_2026-06-01'
except Exception:
    pass


def _v622_f(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        try:
            v = row.get(k)
            if v is None or v == '':
                continue
            return float(str(v).replace('%','').replace(',',''))
        except Exception:
            continue
    return default


def _v622_s(row: Dict[str, Any], *keys: str) -> str:
    for k in keys:
        v = row.get(k)
        if v is not None and str(v).strip():
            return str(v)
    return ''


def _v622_strategy_name(row: Dict[str, Any]) -> str:
    return _v622_s(row, 'strategy_label', 'strategy_primary', 'strategy_key', 'strategy') or '-'


def _v622_text_blob(row: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in ('entry_structure','entry_reason','entry_confirm','structure_tags','risk_tags','canonical_structure','structure_judgement','final_reason','close_review_tag','exit_reason','exit_rule','trigger_reason'):
        v = row.get(k)
        if isinstance(v, list):
            parts.extend(str(x) for x in v)
        elif v is not None:
            parts.append(str(v))
    snap = row.get('canonical_entry_snapshot') or row.get('entry_snapshot') or row.get('entry_context')
    if isinstance(snap, dict):
        for k in ('entry_structure','entry_reason','structure_tags','risk_tags','canonical_structure','structure_judgement','final_reason','trigger_reason'):
            v = snap.get(k)
            if isinstance(v, list):
                parts.extend(str(x) for x in v)
            elif v is not None:
                parts.append(str(v))
    return ' / '.join(parts)


def _v622_get_metric(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    # row 우선, snapshot/context 보조. 출력부 보정이 아니라 복기용 읽기만 한다.
    v = _v622_f(row, *keys, default=None)  # type: ignore[arg-type]
    if v is not None:
        return v
    for parent in ('canonical_entry_snapshot','entry_snapshot','entry_context','canonical_metric_row'):
        obj = row.get(parent)
        if isinstance(obj, dict):
            vv = _v622_f(obj, *keys, default=None)  # type: ignore[arg-type]
            if vv is not None:
                return vv
    return default


def _v622_metric_bool(row: Dict[str, Any], *keys: str) -> Optional[bool]:
    for k in keys:
        if k in row:
            v = row.get(k)
            if isinstance(v, bool):
                return v
            if str(v).lower() in ('true','1','yes','y','도달'):
                return True
            if str(v).lower() in ('false','0','no','n','미도달'):
                return False
    for parent in ('canonical_entry_snapshot','entry_snapshot','entry_context','canonical_metric_row'):
        obj = row.get(parent)
        if isinstance(obj, dict):
            b = _v622_metric_bool(obj, *keys)
            if b is not None:
                return b
    return None


def _v622_reason_tags(row: Dict[str, Any], win: bool) -> List[str]:
    tags: List[str] = []
    blob = _v622_text_blob(row)
    pnl = _v622_get_metric(row, 'pnl_pct', 'profit_pct')
    peak = _v622_get_metric(row, 'peak_pct', 'max_profit_pct', 'best_pct')
    trough = _v622_get_metric(row, 'trough_pct', 'min_profit_pct', 'worst_pct')
    entry = _v622_get_metric(row, 'entry_price', 'open_price')
    trigger = _v622_get_metric(row, 'trigger_price')
    reached = _v622_metric_bool(row, 'trigger_reached', 'trigger_touched', 'trigger_ok')
    buy_ratio = _v622_get_metric(row, 'buy_trade_ratio', 'buy_ratio', 'buy_strength')
    persist = _v622_get_metric(row, 'one_min_persist', 'one_min_buy_persist', 'persist_1m')
    reaction = _v622_get_metric(row, 'price_reaction_pct', 'reaction_pct', 'price_change_1m_pct')
    spread = _v622_get_metric(row, 'spread_pct', 'spread')
    slip = _v622_get_metric(row, 'slippage_pct', 'expected_slippage_pct', 'slip_pct')
    rel = _v622_get_metric(row, 'relative_strength', 'rel_strength', 'rs_score')
    flow15 = _v622_get_metric(row, 'flow_15m_pct', 'ret_15m_pct', 'change_15m_pct')
    vwap_gap = _v622_get_metric(row, 'vwap_gap_pct', 'price_vs_vwap_pct')

    if trigger > 0 and entry > 0 and entry < trigger:
        tags.append('방아쇠 전 진입')
    elif reached is True or (trigger > 0 and entry >= trigger):
        tags.append('방아쇠 확인 후 진입')
    elif reached is False:
        tags.append('방아쇠 미확인')

    if peak <= 0.05:
        tags.append('진입 후 무반응')
    elif peak >= 0.70:
        tags.append('진입 후 빠른 수익반응')
    elif peak >= 0.30:
        tags.append('초반 반응 있음')

    if 'fast_fail' in blob or '빠른실패' in blob:
        tags.append('빠른실패')
    if 'time_exit' in blob or '시간' in blob:
        tags.append('시간청산')
    if 'stop' in blob or '손절' in blob:
        tags.append('손절정리')

    if buy_ratio >= 0.70 and persist >= 0.65 and peak <= 0.10:
        tags.append('체결은 좋은데 가격 안 감')
    elif buy_ratio >= 0.70 and persist >= 0.65 and peak >= 0.30:
        tags.append('체결이 가격상승으로 연결')

    if reaction >= 0.70 and peak <= 0.10:
        tags.append('가격반응 후 추종매수 약함')
    if reaction >= 1.20 or '늦은추격' in blob or vwap_gap >= 1.8:
        tags.append('늦은추격/높은위치')

    if rel <= 0.0 and flow15 <= 0.0:
        tags.append('상대강도/15분흐름 약함')
    elif rel > 0.0 or flow15 > 0.0:
        tags.append('상대강도/상위흐름 양호')

    if spread >= 0.25 or slip >= 0.25:
        tags.append('스프레드/미끄러짐 부담')
    elif spread > 0 or slip > 0:
        tags.append('스프레드/미끄러짐 정상')

    if '가짜돌파' in blob or '방어실패' in blob:
        tags.append('가짜돌파/방어실패')
    if '저항돌파' in blob or '돌파' in blob:
        if peak <= 0.10 and not win:
            tags.append('고점 재돌파 실패')
        else:
            tags.append('돌파 구조 작동')
    if 'VWAP방어' in blob or 'EMA방어' in blob or 'VWAP 방어' in blob or 'EMA 방어' in blob:
        tags.append('VWAP/EMA 방어 구조')
    if '돈흐름재유입' in blob or '거래량확장' in blob:
        tags.append('돈흐름/거래량 확인')

    if win:
        # 승리군은 살릴 조건 중심으로 압축
        keep = [t for t in tags if t not in ('진입 후 무반응','빠른실패','손절정리','방아쇠 전 진입','방아쇠 미확인')]
        return keep[:8] or tags[:5]
    return tags[:10]


def _v622_counter_lines(title: str, counter: Counter, max_items: int = 5) -> List[str]:
    if not counter:
        return [f"- {title}: 표본부족"]
    bits = [f"{k} {v}" for k, v in counter.most_common(max_items)]
    return [f"- {title}: " + ' / '.join(bits)]


def _v622_build_strategy_win_loss_review(rows: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_strategy.setdefault(_v622_strategy_name(r), []).append(r)
    lines: List[str] = ['📊 전략별 승리군/패배군 비교 · v622']
    data: Dict[str, Any] = {}
    if not by_strategy:
        return ['📊 전략별 승리군/패배군 비교 · v622', '- 오늘 CLOSED 없음'], {}

    for sk, rs in sorted(by_strategy.items(), key=lambda kv: (len(kv[1]), str(kv[0])), reverse=True)[:8]:
        wins = [r for r in rs if _v622_get_metric(r, 'pnl_pct', 'profit_pct') > 0]
        losses = [r for r in rs if _v622_get_metric(r, 'pnl_pct', 'profit_pct') <= 0]
        st = _v621_stat_local(rs) if '_v621_stat_local' in globals() else {'n':len(rs),'wins':len(wins),'losses':len(losses),'total_pct':sum(_v622_get_metric(r,'pnl_pct','profit_pct') for r in rs),'avg_pct':0.0,'win_rate_pct':0.0}
        win_counter: Counter = Counter()
        loss_counter: Counter = Counter()
        for r in wins:
            win_counter.update(_v622_reason_tags(r, True))
        for r in losses:
            loss_counter.update(_v622_reason_tags(r, False))
        lines.append('')
        lines.append(f"[{sk}]")
        lines.append(f"- 성과: {st.get('n',0)}전 {st.get('wins',0)}승 {st.get('losses',0)}패 / 승률 {float(st.get('win_rate_pct') or 0):.1f}% / 합산 {float(st.get('total_pct') or 0):+.2f}% / 평균 {float(st.get('avg_pct') or 0):+.2f}%")
        lines.extend(_v622_counter_lines('승리군 공통점', win_counter, 4))
        lines.extend(_v622_counter_lines('패배군 원인', loss_counter, 6))
        # 최근 패배 샘플은 3개만, 조건 변경 없이 복기용
        recent_losses = losses[-3:]
        if recent_losses:
            sample = []
            for r in recent_losses:
                sample.append(f"{str(r.get('ticker') or '-')}/{_v622_get_metric(r,'pnl_pct','profit_pct'):+.2f}%")
            lines.append('- 최근 패배: ' + ' / '.join(sample))
        data[sk] = {
            'stats': st,
            'win_top': dict(win_counter.most_common(8)),
            'loss_top': dict(loss_counter.most_common(10)),
            'win_count': len(wins),
            'loss_count': len(losses),
        }
    lines.append('')
    lines.append('- 해석: 승리군 공통점은 살릴 재료, 패배군 원인은 다음 설계 검토 재료입니다. 조건/S등급/청산은 여기서 바꾸지 않습니다.')
    return lines, data


def _v622_build_trade_review_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v557_filter_today(rows, nowv) if '_v557_filter_today' in globals() else rows
    # v621 source spine 기본 정보 유지
    base = _v621_build_trade_review_cache(rows, status, reconcile) if '_v621_build_trade_review_cache' in globals() else {'summary_text':'', 'today_closed_count': len(today_rows)}
    wl_lines, wl_data = _v622_build_strategy_win_loss_review(today_rows)
    old = str(base.get('summary_text') or '').strip()
    # 기존 최근 CLOSED/source 대조는 보존하고, 승패 비교를 앞쪽에 둔다.
    summary = '\n'.join(wl_lines)
    if old:
        # 기존 v621 제목은 중복이므로 source 대조/최근 CLOSED 파트만 뒤에 붙인다.
        tail = re.sub(r'^📉 복기 /trade_review · v\d+[^\n]*\n?', '', old, count=1)
        summary += '\n\n' + tail
    obj = dict(base)
    obj.update({
        'schema': 'paper_review_spine_v622_strategy_win_loss_compare',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v622_strategy_win_loss_same_closed_rows_writer',
        'source': 'same_reconciled_rows_as_paper_score_cache_v622',
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv) if 'iso_ts' in globals() else now_text(),
        'today_closed_count': len(today_rows),
        'strategy_win_loss_analysis': wl_data,
        'summary_text': summary,
    })
    return obj


_v622_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    try:
        rows, reconcile = _v607_reconciled_closed_rows() if '_v607_reconciled_closed_rows' in globals() else (read_jsonl(FILES['closed'], max_lines=5000), {})
        # score cache는 기존 v607/v621 형식을 유지하고 review만 승패 비교를 추가한다.
        save_json(FILES['score'], _v607_build_score_cache_obj(rows, status, reconcile) if '_v607_build_score_cache_obj' in globals() else {'schema':'paper_score_cache_v622_minimal','closed_count':len(rows),'updated_at':now_ts()})
        save_json(FILES['trade_review'], _v622_build_trade_review_cache(rows, status, reconcile))
    except Exception as exc:
        log_error('v622_write_strategy_win_loss_review', exc)
        _v622_prev_write_score_cache(status)


_v622_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    _v622_prev_write_status(status)
    try:
        st = _v621_sync_open_source_status(status, phase='v622_write_status') if '_v621_sync_open_source_status' in globals() else status
        write_score_cache(st)
    except Exception as exc:
        log_error('v622_write_status_review', exc)


_v622_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v622_prev_run_cycle()
    try:
        st = _v621_sync_open_source_status(st if isinstance(st, dict) else {}, phase='v622_run_cycle') if '_v621_sync_open_source_status' in globals() else st
        write_score_cache(st if isinstance(st, dict) else None)
    except Exception as exc:
        log_error('v622_run_cycle_review', exc)
    return st if isinstance(st, dict) else {}



# =============================================================================
# paper_bot v0.227 / v623: 전략별 승리군·패배군 비교 cache 강제 writer
# - v622에서 main 제목은 바뀌었지만 review cache summary가 v621/v607로 남는 문제를 차단한다.
# - CLOSED reconciled rows → strategy_win_loss_analysis → summary_text를 paper 공장에서 직접 저장한다.
# - 조건/S등급/청산/자동매수/장부 삭제 변경 없음.
# =============================================================================
try:
    BUILD_LABEL = 'v623_strategy_win_loss_force_writer_20260602'
except Exception:
    pass


def _v623_row_strategy(row: Dict[str, Any]) -> str:
    try:
        if '_strategy_key' in globals():
            v = _strategy_key(row)
            if v and str(v) != '-':
                return str(v)
    except Exception:
        pass
    return str(row.get('strategy_label') or row.get('strategy') or row.get('strategy_key') or '-')


def _v623_row_pnl(row: Dict[str, Any]) -> float:
    return fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), row.get('result_pct'), default=0.0)


def _v623_row_text(row: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in ('exit_reason','exit_rule','exit_rule_label','close_review_tag','fast_fail_cause','entry_structure','entry_reason','entry_reasons','confirm_text','structure_tags','raw_text','message','alert_text'):
        v = row.get(k)
        if isinstance(v, list):
            parts.extend(str(x) for x in v)
        elif isinstance(v, dict):
            parts.extend(str(x) for x in v.values())
        elif v is not None:
            parts.append(str(v))
    for parent in ('canonical_entry_snapshot','entry_snapshot','canonical_metric_row','entry_context'):
        obj = row.get(parent)
        if isinstance(obj, dict):
            for k in ('entry_structure','entry_reason','entry_reasons','structure_tags','final_reason','trigger_reason'):
                v = obj.get(k)
                if isinstance(v, list):
                    parts.extend(str(x) for x in v)
                elif v is not None:
                    parts.append(str(v))
    return ' / '.join(parts)


def _v623_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        if k in row:
            return fnum(row.get(k), default=default)
    for parent in ('canonical_entry_snapshot','entry_snapshot','canonical_metric_row','entry_context'):
        obj = row.get(parent)
        if isinstance(obj, dict):
            for k in keys:
                if k in obj:
                    return fnum(obj.get(k), default=default)
    return default


def _v623_bool(row: Dict[str, Any], *keys: str) -> Optional[bool]:
    for k in keys:
        if k in row:
            v = row.get(k)
            if isinstance(v, bool):
                return v
            s = str(v).lower()
            if s in ('true','1','yes','y','도달','reached'):
                return True
            if s in ('false','0','no','n','미도달','not_reached'):
                return False
    for parent in ('canonical_entry_snapshot','entry_snapshot','canonical_metric_row','entry_context'):
        obj = row.get(parent)
        if isinstance(obj, dict):
            b = _v623_bool(obj, *keys)
            if b is not None:
                return b
    return None


def _v623_tags(row: Dict[str, Any], win: bool) -> List[str]:
    tags: List[str] = []
    blob = _v623_row_text(row)
    pnl = _v623_row_pnl(row)
    peak = _v623_num(row, 'peak_pct','max_profit_pct','best_pct')
    entry = _v623_num(row, 'entry_price','open_price')
    trigger = _v623_num(row, 'trigger_price')
    buy = _v623_num(row, 'buy_trade_ratio','buy_ratio','buy_strength')
    persist = _v623_num(row, 'one_min_persist','one_min_buy_persist','persist_1m')
    reaction = _v623_num(row, 'price_reaction_pct','reaction_pct','price_change_1m_pct')
    rel = _v623_num(row, 'relative_strength','rel_strength','rs_score')
    flow15 = _v623_num(row, 'flow_15m_pct','ret_15m_pct','change_15m_pct')
    vwap_gap = _v623_num(row, 'vwap_gap_pct','price_vs_vwap_pct')
    spread = _v623_num(row, 'spread_pct','spread')
    slip = _v623_num(row, 'slippage_pct','expected_slippage_pct','slip_pct')
    reached = _v623_bool(row, 'trigger_reached','trigger_touched','trigger_ok')

    if trigger > 0 and entry > 0 and entry < trigger:
        tags.append('방아쇠 전 진입')
    elif reached is True or (trigger > 0 and entry >= trigger):
        tags.append('방아쇠 확인 후 진입')
    elif reached is False:
        tags.append('방아쇠 미확인')

    if peak <= 0.05 and pnl <= 0:
        tags.append('진입 후 무반응')
    elif peak >= 0.70:
        tags.append('진입 후 강한 수익반응')
    elif peak >= 0.30:
        tags.append('초반 반응 있음')

    if '빠른실패' in blob or 'fast_fail' in blob:
        tags.append('빠른실패')
    if '손절' in blob or 'stop' in blob:
        tags.append('손절정리')
    if '시간' in blob or 'time_exit' in blob:
        tags.append('시간청산')
    if '보호' in blob or 'protect' in blob:
        tags.append('보호익절/반납관리')

    if buy >= 0.70 and persist >= 0.65 and peak <= 0.10 and pnl <= 0:
        tags.append('체결은 좋은데 가격 안 감')
    elif buy >= 0.70 and persist >= 0.65 and peak >= 0.30:
        tags.append('체결이 가격상승으로 연결')

    if reaction >= 0.70 and peak <= 0.10 and pnl <= 0:
        tags.append('가격반응 후 추종매수 약함')
    if reaction >= 1.20 or vwap_gap >= 1.8 or '늦은추격' in blob:
        tags.append('늦은추격/높은위치')
    if rel <= 0.0 and flow15 <= 0.0:
        tags.append('상대강도/15분흐름 약함')
    elif rel > 0.0 or flow15 > 0.0:
        tags.append('상대강도/상위흐름 양호')
    if spread >= 0.25 or slip >= 0.25:
        tags.append('스프레드/미끄러짐 부담')
    elif spread > 0 or slip > 0:
        tags.append('스프레드/미끄러짐 정상')

    if '가짜돌파' in blob or '방어실패' in blob:
        tags.append('가짜돌파/방어실패')
    if '저항돌파' in blob or '돌파' in blob:
        tags.append('돌파 구조 작동' if win else '고점 재돌파 실패')
    if 'VWAP' in blob or 'EMA' in blob:
        tags.append('VWAP/EMA 구조')
    if '돈흐름' in blob or '거래량' in blob:
        tags.append('돈흐름/거래량 확인')

    if row.get('reconciled_from_close_alert_trace'):
        tags.append('알림원천보강 row')
    if not tags:
        tags.append('상세원인 부족')
    if win:
        bad = {'진입 후 무반응','빠른실패','손절정리','방아쇠 전 진입','방아쇠 미확인','고점 재돌파 실패'}
        keep = [t for t in tags if t not in bad]
        return keep[:8] or tags[:5]
    return tags[:10]


def _v623_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if _v623_row_pnl(r) > 0)
    total = sum(_v623_row_pnl(r) for r in rows)
    return {'n': n, 'wins': wins, 'losses': max(0,n-wins), 'total_pct': round(total, 4), 'avg_pct': round(total/n, 4) if n else 0.0, 'win_rate_pct': round(wins/n*100, 2) if n else 0.0}


def _v623_counter_line(label: str, c: Counter, n: int) -> str:
    if not c:
        return f"- {label}: 표본부족"
    return f"- {label}: " + ' / '.join(f"{k} {v}" for k, v in c.most_common(n))


def _v623_strategy_win_loss_lines(today_rows: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    by: Dict[str, List[Dict[str, Any]]] = {}
    for r in today_rows:
        by.setdefault(_v623_row_strategy(r), []).append(r)
    lines = ['📊 전략별 승리군/패배군 비교 · v623']
    data: Dict[str, Any] = {}
    if not by:
        return lines + ['- 오늘 CLOSED 없음'], data
    for sk, rs in sorted(by.items(), key=lambda kv: (len(kv[1]), str(kv[0])), reverse=True)[:10]:
        wins = [r for r in rs if _v623_row_pnl(r) > 0]
        losses = [r for r in rs if _v623_row_pnl(r) <= 0]
        st = _v623_stat(rs)
        wc: Counter = Counter()
        lc: Counter = Counter()
        for r in wins:
            wc.update(_v623_tags(r, True))
        for r in losses:
            lc.update(_v623_tags(r, False))
        lines.append('')
        lines.append(f"[{sk}]")
        lines.append(f"- 성과: {st['n']}전 {st['wins']}승 {st['losses']}패 / 승률 {st['win_rate_pct']:.1f}% / 합산 {st['total_pct']:+.2f}% / 평균 {st['avg_pct']:+.2f}%")
        lines.append(_v623_counter_line('승리군 공통점', wc, 5))
        lines.append(_v623_counter_line('패배군 원인', lc, 7))
        recent_losses = losses[-3:]
        if recent_losses:
            lines.append('- 최근 패배: ' + ' / '.join(f"{r.get('ticker','-')} {_v623_row_pnl(r):+.2f}%" for r in recent_losses))
        data[sk] = {'stats': st, 'win_top': dict(wc.most_common(10)), 'loss_top': dict(lc.most_common(12)), 'win_count': len(wins), 'loss_count': len(losses)}
    lines.append('')
    lines.append('- 해석: 승리군 공통점은 살릴 재료, 패배군 원인은 다음 설계 검토 재료입니다. 조건/S등급/청산은 여기서 바꾸지 않습니다.')
    return lines, data


def _v623_build_trade_review_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v557_filter_today(rows, nowv) if '_v557_filter_today' in globals() else rows
    base = _v621_build_trade_review_cache(rows, status, reconcile) if '_v621_build_trade_review_cache' in globals() else {'today_closed_count': len(today_rows), 'summary_text': ''}
    lines, data = _v623_strategy_win_loss_lines(today_rows)
    old = str(base.get('summary_text') or '').strip()
    tail = ''
    if old:
        tail = re.sub(r'^(📉|📊) [^\n]*?v\d+[^\n]*\n?', '', old, count=1)
    summary = '\n'.join(lines) + ('\n\n' + tail if tail else '')
    obj = dict(base)
    obj.update({
        'schema': 'paper_review_spine_v623_strategy_win_loss_compare',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v623_force_strategy_win_loss_writer',
        'source': 'same_reconciled_rows_as_paper_score_cache_v623',
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv) if 'iso_ts' in globals() else now_text(),
        'today_closed_count': len(today_rows),
        'closed_count': len(rows),
        'strategy_win_loss_analysis': data,
        'summary_text': summary,
    })
    return obj


def _v623_write_review_cache(status: Optional[Dict[str, Any]] = None) -> None:
    rows, reconcile = _v607_reconciled_closed_rows() if '_v607_reconciled_closed_rows' in globals() else (read_jsonl_tail(FILES['closed'], 1200), {})
    save_json(FILES['trade_review'], _v623_build_trade_review_cache(rows, status, reconcile))

_v623_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    try:
        rows, reconcile = _v607_reconciled_closed_rows() if '_v607_reconciled_closed_rows' in globals() else (read_jsonl_tail(FILES['closed'], 1200), {})
        save_json(FILES['score'], _v607_build_score_cache_obj(rows, status, reconcile) if '_v607_build_score_cache_obj' in globals() else {'schema':'paper_score_cache_v623_minimal','closed_count':len(rows),'updated_at':now_ts()})
        save_json(FILES['trade_review'], _v623_build_trade_review_cache(rows, status, reconcile))
    except Exception as exc:
        log_error('v623_write_strategy_win_loss_review', exc)
        _v623_prev_write_score_cache(status)

_v623_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    _v623_prev_write_status(status)
    try:
        st = _v621_sync_open_source_status(status, phase='v623_write_status') if '_v621_sync_open_source_status' in globals() else status
        write_score_cache(st)
    except Exception as exc:
        log_error('v623_write_status_review', exc)

_v623_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v623_prev_run_cycle()
    try:
        st2 = _v621_sync_open_source_status(st if isinstance(st, dict) else {}, phase='v623_run_cycle') if '_v621_sync_open_source_status' in globals() else st
        write_score_cache(st2 if isinstance(st2, dict) else None)
    except Exception as exc:
        log_error('v623_run_cycle_review', exc)
    return st if isinstance(st, dict) else {}

try:
    _v623_write_review_cache(None)
except Exception as exc:
    log_error('v623_startup_review_cache', exc)

# =============================================================================
# paper_bot v0.223 / v625: runtime registration fix for trigger hard gate + KST hourly raw pack
# - TON/MVC 유형: 표시 trigger보다 낮은 entry_price로 OPEN되는 경로를 paper 직전에서 다시 차단한다.
# - paper 1시간 원문 묶음집은 KST 기준으로 닫힌 시간대에 매매/보류 이벤트가 있을 때만 전송한다.
# - 전송용 txt는 Telegram 전송 후 즉시 삭제한다. OPEN/CLOSED/trade_log 원장은 삭제하지 않는다.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
FILES['hourly_event_trace'] = BASE_DIR / 'paper_bot_hourly_event_trace.jsonl'
FILES['hourly_state'] = BASE_DIR / 'paper_bot_hourly_raw_state.json'


def _v624_kst_dt(ts: Optional[float] = None):
    import datetime as _dt
    return _dt.datetime.fromtimestamp(ts or now_ts(), tz=_dt.timezone(_dt.timedelta(hours=9)))


def _v624_hour_key(ts: Optional[float] = None) -> str:
    return _v624_kst_dt(ts).strftime('%Y%m%d_%H')


def _v624_hour_range_text(hour_key: str) -> str:
    try:
        import datetime as _dt
        st = _dt.datetime.strptime(hour_key, '%Y%m%d_%H').replace(tzinfo=_dt.timezone(_dt.timedelta(hours=9)))
        en = st + _dt.timedelta(hours=1)
        return f"{st.strftime('%Y-%m-%d %H:00')}~{en.strftime('%H:00')} KST"
    except Exception:
        return hour_key + ' KST'


def _v624_prev_hour_key(ts: Optional[float] = None) -> str:
    import datetime as _dt
    return (_v624_kst_dt(ts).replace(minute=0, second=0, microsecond=0) - _dt.timedelta(hours=1)).strftime('%Y%m%d_%H')


def _v624_start_end_ts(hour_key: str) -> Tuple[float, float]:
    import datetime as _dt
    st = _dt.datetime.strptime(hour_key, '%Y%m%d_%H').replace(tzinfo=_dt.timezone(_dt.timedelta(hours=9)))
    en = st + _dt.timedelta(hours=1)
    return st.timestamp(), en.timestamp()


def _v624_deep_find_first(obj: Any, keys: Tuple[str, ...], max_depth: int = 6) -> Any:
    if max_depth < 0:
        return None
    if isinstance(obj, dict):
        for k in keys:
            if k in obj and obj.get(k) not in (None, ''):
                return obj.get(k)
        for v in obj.values():
            found = _v624_deep_find_first(v, keys, max_depth - 1)
            if found not in (None, ''):
                return found
    elif isinstance(obj, list):
        for v in obj[:20]:
            found = _v624_deep_find_first(v, keys, max_depth - 1)
            if found not in (None, ''):
                return found
    return None


def _v624_trigger_gate_strict(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    diag = diag if isinstance(diag, dict) else {}
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    # Use the same displayed structure trigger first, then sealed trigger. The displayed trigger must match OPEN gate.
    trigger = fnum(
        _v624_deep_find_first(ev, ('trigger_price',), 5),
        _v624_deep_find_first(diag, ('trigger_price',), 5),
        _v624_deep_find_first(ctx, ('trigger_price',), 5),
        default=0.0,
    )
    entry = fnum(
        ev.get('entry_price'), ev.get('current_price'), ev.get('live_price'), ev.get('price'), ev.get('trade_price'), ev.get('detected_price'),
        diag.get('entry_price'), diag.get('current_price'), diag.get('price'),
        default=0.0,
    )
    if entry <= 0:
        entry = get_event_price(ev)
    reached = False
    gap = None
    if entry > 0 and trigger > 0:
        # no tolerance here: if alert says trigger 2.1850, entry below it is not S1 OPEN.
        reached = entry >= trigger
        try:
            gap = round((entry - trigger) / trigger * 100.0, 3)
        except Exception:
            gap = None
    elif trigger <= 0:
        reached = False
    return {
        'schema': 'paper_trigger_gate_v624_strict',
        'entry_price': entry or None,
        'trigger_price': trigger or None,
        'trigger_reached': bool(reached),
        'trigger_gap_pct': gap,
        'reason': '방아쇠 도달 확인' if reached else ('방아쇠 정보 없음' if trigger <= 0 else f'방아쇠 미도달: 진입 {fmt_price(entry)} < 방아쇠 {fmt_price(trigger)}'),
    }


def _v624_append_hourly_event(kind: str, row: Dict[str, Any], message_text: str = '', phase: str = '', note: str = '') -> None:
    try:
        ts = now_ts()
        payload = {
            'schema': 'paper_hourly_raw_event_v624',
            'version': VERSION,
            'build': BUILD_LABEL,
            'kind': str(kind or ''),
            'phase': str(phase or ''),
            'ts': ts,
            'ts_text': iso_ts(ts),
            'kst_hour': _v624_hour_key(ts),
            'ticker': normalize_ticker(row.get('ticker')),
            'pos_id': row.get('pos_id') or row.get('event_id') or row.get('entry_id'),
            'event_id': row.get('event_id') or row.get('pos_id') or row.get('entry_id'),
            'entry_price': row.get('entry_price'),
            'trigger_price': _v624_deep_find_first(row, ('trigger_price',), 5),
            'pnl_pct': row.get('pnl_pct'),
            'strategy': row.get('strategy_label') or row.get('strategy_key') or row.get('strategy'),
            'exit_reason': row.get('exit_reason') or row.get('exit_rule'),
            'note': str(note or ''),
            'message_text': str(message_text or '')[:8000],
        }
        append_jsonl(FILES['hourly_event_trace'], payload)
    except Exception as exc:
        log_error('v624_append_hourly_event', exc)


_v624_prev_paper_final_safety = paper_final_safety



def _v746_first_positive_num_from_nested(*objs: Any, keys: Tuple[str, ...]) -> float:
    for obj in objs:
        if not isinstance(obj, (dict, list)):
            continue
        for key in keys:
            try:
                for v in _v628_deep_values(obj, key, depth=5):
                    x = fnum(v, default=0.0)
                    if x > 0:
                        return x
            except Exception:
                pass
    return 0.0


def _v746_preopen_freshness_reasons(ev: Dict[str, Any], diag: Dict[str, Any], ctrl: Dict[str, Any]) -> List[str]:
    """v746: OPEN 직전 최신성/진입위치 안전문.
    - S1/S2/S3 기준값, 익절/손절값은 변경하지 않는다.
    - 오래된 hold/목표가 근처 진입/방아쇠 과다 gap을 paper OPEN 직전 보류로만 막는다.
    """
    reasons: List[str] = []
    nowv = now_ts()
    diag = diag if isinstance(diag, dict) else {}
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    timing = diag.get('entry_timing_spine') if isinstance(diag.get('entry_timing_spine'), dict) else (ev.get('entry_timing_spine') if isinstance(ev.get('entry_timing_spine'), dict) else {})
    gate = diag.get('trigger_gate') if isinstance(diag.get('trigger_gate'), dict) else {}
    levels = diag.get('structure_levels') if isinstance(diag.get('structure_levels'), dict) else (ctx.get('structure_levels') if isinstance(ctx.get('structure_levels'), dict) else {})
    rr = diag.get('risk_reward') if isinstance(diag.get('risk_reward'), dict) else (ctx.get('risk_reward') if isinstance(ctx.get('risk_reward'), dict) else {})
    # 1) 후보 row 자체가 오래됐으면 보류. expires_at은 candidate_is_fresh에서 이미 보지만, 여기서 OPEN 직전 trace까지 봉인한다.
    created = event_created_ts(ev)
    max_event_age = fnum(ctrl.get('paper_preopen_max_event_age_sec'), default=180.0)
    if created > 0:
        age = max(0.0, nowv - created)
        diag['paper_preopen_event_age_sec_v746'] = round(age, 3)
        if age > max_event_age:
            reasons.append(f'OPEN직전 후보 오래됨: {age:.0f}s > {max_event_age:.0f}s')
    else:
        diag['paper_preopen_event_age_sec_v746'] = None
        reasons.append('OPEN직전 후보 생성시각 없음')
    # 2) first/S2 timing spine이 없거나 비정상적으로 오래되면 보류.
    if not isinstance(timing, dict) or not timing:
        reasons.append('OPEN직전 진입타이밍 spine 없음')
    else:
        max_timing = fnum(ctrl.get('paper_preopen_max_stage_delay_sec'), default=300.0)
        first_delay = fnum(timing.get('first_to_now_delay_sec'), default=0.0)
        s2_delay = fnum(timing.get('s2_to_now_delay_sec'), default=0.0)
        diag['paper_preopen_timing_check_v746'] = {'first_to_now_delay_sec': first_delay, 's2_to_now_delay_sec': s2_delay, 'max_stage_delay_sec': max_timing}
        if first_delay > max_timing:
            reasons.append(f'OPEN직전 최초신호 오래됨: {first_delay:.0f}s > {max_timing:.0f}s')
        if s2_delay > max_timing:
            reasons.append(f'OPEN직전 S2신호 오래됨: {s2_delay:.0f}s > {max_timing:.0f}s')
    # 3) 현재가가 목표가에 이미 닿았거나 위면 추격 OPEN 금지.
    entry = fnum(gate.get('entry_price'), diag.get('entry_price'), ev.get('entry_price'), ev.get('current_price'), default=0.0)
    target1 = _v746_first_positive_num_from_nested(levels, rr, diag, ctx, ev, keys=('target1_price','target_price','tp1_price','first_target_price'))
    trigger_gap = fnum(gate.get('trigger_gap_pct'), diag.get('trigger_gap_pct'), default=0.0)
    max_gap = fnum(ctrl.get('paper_preopen_max_trigger_gap_pct'), default=0.60)
    if trigger_gap > max_gap:
        reasons.append(f'OPEN직전 방아쇠 과다이탈: gap {trigger_gap:+.2f}% > {max_gap:+.2f}%')
    if entry > 0 and target1 > 0:
        remain = (target1 / entry - 1.0) * 100.0
        diag['paper_preopen_target_room_pct_v746'] = round(remain, 4)
        if entry >= target1:
            reasons.append(f'OPEN직전 목표가 이상 진입: 진입 {fmt_price(entry)} ≥ 목표1 {fmt_price(target1)}')
        elif remain < fnum(ctrl.get('paper_preopen_min_target_room_pct'), default=0.15):
            reasons.append(f'OPEN직전 목표여유 부족: +{remain:.2f}% < +0.15%')
    # 4) RR이 이미 무너진 row는 보류. 값이 없으면 기존 판단을 존중한다.
    rr_ratio = fnum(rr.get('rr_ratio'), default=0.0) if isinstance(rr, dict) else 0.0
    upside = fnum(rr.get('expected_upside_pct'), default=0.0) if isinstance(rr, dict) else 0.0
    if rr_ratio > 0 and rr_ratio < fnum(ctrl.get('paper_preopen_min_rr_ratio'), default=1.0):
        reasons.append(f'OPEN직전 손익비 부족: RR {rr_ratio:.2f} < 1.00')
    if upside > 0 and upside < fnum(ctrl.get('paper_preopen_min_expected_upside_pct'), default=0.20):
        reasons.append(f'OPEN직전 기대상승 부족: +{upside:.2f}% < +0.20%')
    if reasons:
        diag['paper_preopen_block_v746'] = True
        diag['paper_preopen_block_reasons_v746'] = reasons[:10]
    else:
        diag['paper_preopen_block_v746'] = False
    diag['paper_preopen_guard_schema_v746'] = 'paper_preopen_freshness_position_guard_v746'
    return reasons[:10]
def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:  # type: ignore[override]
    ok, reasons, diag = _v624_prev_paper_final_safety(ev, ctrl)
    diag = diag if isinstance(diag, dict) else {}
    strict = _v624_trigger_gate_strict(ev, diag)
    diag['trigger_gate_v624'] = strict
    # Mirror into legacy names so alert/review can read one source.
    diag['trigger_gate'] = strict
    diag['trigger_reached'] = bool(strict.get('trigger_reached'))
    diag['trigger_gap_pct'] = strict.get('trigger_gap_pct')
    if strict.get('trigger_price') and strict.get('entry_price') and not bool(strict.get('trigger_reached')):
        reason = 'trigger_not_reached_v624: ' + str(strict.get('reason') or '방아쇠 미도달')
        if reason not in reasons:
            reasons = list(reasons) + [reason]
        try:
            ev2 = dict(ev)
            ev2['paper_entry_hold_reason'] = reason
            ev2['paper_entry_action'] = 'trigger_not_reached_hold'
            ev2['entry_price'] = strict.get('entry_price')
            ev2['trigger_price'] = strict.get('trigger_price')
            _v624_append_hourly_event('open_block', ev2, '', 'trigger_not_reached', reason)
        except Exception:
            pass
        return False, reasons, diag
    return ok, reasons, diag


def _v624_trigger_gate_line(row: Dict[str, Any], diag: Dict[str, Any], prefix: str = '- ') -> str:
    gate = _v624_trigger_gate_strict(row, diag)
    if not gate.get('trigger_price'):
        return prefix + '방아쇠확인: 정보없음'
    status = '도달' if gate.get('trigger_reached') else '미도달'
    gap = gate.get('trigger_gap_pct')
    gap_txt = f" / gap {gap:+.2f}%" if isinstance(gap, (int, float)) else ''
    return prefix + f"방아쇠확인: {status} / 진입 {fmt_price(gate.get('entry_price'))} vs 방아쇠 {fmt_price(gate.get('trigger_price'))}{gap_txt}"


_v624_prev_format_entry_diag_lines = format_entry_diag_lines

def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = '- ') -> List[str]:  # type: ignore[override]
    lines = _v624_prev_format_entry_diag_lines(diag, prefix)
    row = diag.get('_source_row') if isinstance(diag, dict) and isinstance(diag.get('_source_row'), dict) else {}
    line = _v624_trigger_gate_line(row, diag if isinstance(diag, dict) else {}, prefix)
    # Replace older trigger line if present, otherwise insert before timing.
    out: List[str] = []
    inserted = False
    for ln in lines:
        if isinstance(ln, str) and ln.startswith(prefix + '방아쇠확인:'):
            if not inserted:
                out.append(line)
                inserted = True
            continue
        if (not inserted) and isinstance(ln, str) and ln.startswith(prefix + '진입타이밍:'):
            out.append(line)
            inserted = True
        out.append(ln)
    if not inserted:
        out.append(line)
    return out


_v624_prev_open_message_text = _v561_open_message_text

def _v561_open_message_text(pos: Dict[str, Any]) -> str:  # type: ignore[override]
    text = _v624_prev_open_message_text(pos)
    # Ensure version/build is visible in raw hourly pack and Telegram message.
    if BUILD_LABEL not in text:
        text = text.replace(f'- paper: {VERSION}', f'- paper: {VERSION} / {BUILD_LABEL}')
    return text


_v624_prev_closed_message_text = _v567_closed_message_text

def _v567_closed_message_text(row: Dict[str, Any]) -> str:  # type: ignore[override]
    text = _v624_prev_closed_message_text(row)
    if BUILD_LABEL not in text:
        text = text.replace(f'- paper: {VERSION}', f'- paper: {VERSION} / {BUILD_LABEL}')
    return text


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    _v567_append_trade_alert_trace('open', pos, 'attempt_start', False, '', 'OPEN created; alert send started')
    try:
        text = _v561_open_message_text(pos)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('open', pos, 'message_build_error', False, err, 'OPEN alert text build failed')
        _v624_append_hourly_event('open', pos, '', 'message_build_error', err)
        log_error('v624_notify_opened_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('open', pos, phase, ok, err, 'OPEN alert send result')
    _v624_append_hourly_event('open', pos, text, phase, err)
    if not ok:
        log_error('v624_notify_opened_send_result', Exception(err or 'send_message returned false'))


def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    _v567_append_trade_alert_trace('closed', row, 'attempt_start', False, '', 'CLOSED created; alert send started')
    try:
        text = _v567_closed_message_text(row)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, err, 'CLOSED alert text build failed')
        _v624_append_hourly_event('closed', row, '', 'message_build_error', err)
        log_error('v624_notify_closed_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('closed', row, phase, ok, err, 'CLOSED alert send result')
    _v624_append_hourly_event('closed', row, text, phase, err)
    if not ok:
        log_error('v624_notify_closed_send_result', Exception(err or 'send_message returned false'))


def _v624_send_document(path: Path, caption: str = '') -> Tuple[bool, str]:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return False, 'telegram_disabled'
    try:
        import uuid
        boundary = '----coinbot' + uuid.uuid4().hex
        data_parts: List[bytes] = []
        def add_field(name: str, value: str) -> None:
            data_parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8'))
        add_field('chat_id', str(NOTIFY_CHAT_ID))
        if caption:
            add_field('caption', caption[:900])
        filename = path.name
        data_parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n').encode('utf-8'))
        data_parts.append(path.read_bytes())
        data_parts.append(f'\r\n--{boundary}--\r\n'.encode('utf-8'))
        body = b''.join(data_parts)
        req = urllib.request.Request(f'https://api.telegram.org/bot{TOKEN}/sendDocument', data=body, headers={'Content-Type': 'multipart/form-data; boundary=' + boundary})
        urllib.request.urlopen(req, timeout=12).read()
        return True, ''
    except Exception as exc:
        log_error('v624_send_document', exc)
        return False, f'{type(exc).__name__}: {exc}'


def _v624_build_hourly_raw_pack(hour_key: str, events: List[Dict[str, Any]]) -> str:
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    score = load_json(FILES.get('score', BASE_DIR / 'paper_bot_score_cache.json'), {}) or {}
    review = load_json(FILES.get('trade_review', BASE_DIR / 'paper_bot_trade_review_cache.json'), {}) or {}
    main_ver = ''
    try:
        main_status = load_json(BASE_DIR / 'clean_brain_status.json', {}) or {}
        main_ver = str(main_status.get('bot_version') or main_status.get('version') or '')
    except Exception:
        main_ver = ''
    open_events = [e for e in events if e.get('kind') == 'open']
    closed_events = [e for e in events if e.get('kind') == 'closed']
    block_events = [e for e in events if str(e.get('kind') or '').endswith('block') or 'block' in str(e.get('kind') or '')]
    lines = [
        '📦 paper 1시간 원문 묶음집 · v625',
        f'- 기간: {_v624_hour_range_text(hour_key)}',
        f'- main: {main_ver or status.get("main_version") or "-"}',
        f'- paper: {VERSION} / {BUILD_LABEL}',
        f'- strategy: {status.get("strategy_worker_version") or status.get("strategy_version") or "strategy_worker_v0.148"}',
        f'- 생성: {iso_ts()}',
        '',
        '[요약]',
        f'- OPEN 원문 {len(open_events)} / CLOSED 원문 {len(closed_events)} / 보류·차단 {len(block_events)}',
        f'- score CLOSED {score.get("closed_count", score.get("total_closed", "-")) if isinstance(score, dict) else "-"} / 오늘 {((score.get("today_global_stats") or {}).get("n") if isinstance(score.get("today_global_stats"), dict) else score.get("today_closed_count")) if isinstance(score, dict) else "-"}',
        f'- review schema {review.get("schema", "-") if isinstance(review, dict) else "-"}',
    ]
    def add_event_section(title: str, rows: List[Dict[str, Any]]) -> None:
        lines.append('')
        lines.append(title)
        if not rows:
            lines.append('- 없음')
            return
        for i, e in enumerate(rows, 1):
            lines.append('')
            lines.append(f'--- {i}. {e.get("ticker") or "-"} / {e.get("phase") or "-"} / {e.get("ts_text") or "-"} ---')
            msg = str(e.get('message_text') or '').strip()
            if msg:
                lines.append(msg)
            else:
                lines.append(f"- ticker: {e.get('ticker') or '-'}")
                lines.append(f"- strategy: {e.get('strategy') or '-'}")
                lines.append(f"- entry: {fmt_price(e.get('entry_price'))} / trigger: {fmt_price(e.get('trigger_price'))}")
                if e.get('pnl_pct') not in (None, ''):
                    lines.append(f"- pnl: {fnum(e.get('pnl_pct'), default=0.0):+.2f}%")
                if e.get('note'):
                    lines.append(f"- note: {e.get('note')}")
    add_event_section('[OPEN 원문]', open_events)
    add_event_section('[CLOSED 원문]', closed_events)
    add_event_section('[OPEN 보류/차단]', block_events)
    lines.append('')
    lines.append('[고정]')
    lines.append('- 이 txt는 Telegram 전송용 임시파일이며 전송 뒤 서버에서 삭제한다.')
    lines.append('- paper OPEN/CLOSED/trade_log 원장은 삭제하지 않는다.')
    return '\n'.join(lines) + '\n'


def _v625_send_due_hourly_raw_pack() -> None:
    try:
        state = load_json(FILES['hourly_state'], {}) or {}
        if not isinstance(state, dict):
            state = {}
        hour_key = _v624_prev_hour_key()
        if state.get('last_sent_hour') == hour_key:
            return
        start, end = _v624_start_end_ts(hour_key)
        rows = []
        for e in read_jsonl_tail(FILES['hourly_event_trace'], 1200):
            if not isinstance(e, dict):
                continue
            ts = fnum(e.get('ts'), default=0.0)
            if start <= ts < end:
                rows.append(e)
        # 매매/보류 없으면 만들지 않고 sent marker만 남겨 반복 검사 방지.
        if not rows:
            state['last_sent_hour'] = hour_key
            state['last_sent_note'] = 'no_events_skip'
            state['updated_ts'] = now_ts()
            save_json(FILES['hourly_state'], state)
            return
        text = _v624_build_hourly_raw_pack(hour_key, rows)
        tmp = BASE_DIR / f'paper_hourly_raw_pack_{hour_key}_KST.txt'
        tmp.write_text(text, encoding='utf-8')
        ok, err = _v624_send_document(tmp, caption=f'paper 1시간 원문 묶음집 { _v624_hour_range_text(hour_key) }')
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        state['last_sent_hour'] = hour_key if ok else state.get('last_sent_hour')
        state['last_send_ok'] = bool(ok)
        state['last_error'] = err
        state['last_event_count'] = len(rows)
        state['updated_ts'] = now_ts()
        save_json(FILES['hourly_state'], state)
    except Exception as exc:
        log_error('v625_send_due_hourly_raw_pack', exc)


_v624_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v624_prev_run_cycle()
    try:
        _v625_send_due_hourly_raw_pack()
    except Exception as exc:
        log_error('v625_run_cycle_hourly_raw_pack', exc)
    if isinstance(st, dict):
        st['build'] = BUILD_LABEL
        st['hourly_raw_pack_schema'] = 'paper_hourly_raw_pack_v625_kst'
    return st



# =============================================================================
# paper_bot v0.223 / v626: trigger hard gate + review writer runtime spine fix
# - 이전 v624/v625는 일부 등록/표시 경로가 main/handler 순서와 섞여 실제 확인이 어려웠다.
# - 여기서는 paper 공장 안에서 최종 writer/run_cycle을 마지막으로 다시 봉인한다.
# - 조건/S등급/청산/자동매수/장부 삭제 변경 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
FILES['hourly_event_trace'] = BASE_DIR / 'paper_bot_hourly_event_trace.jsonl'
FILES['hourly_state'] = BASE_DIR / 'paper_bot_hourly_raw_state.json'


def _v626_reconciled_rows() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    try:
        if '_v607_reconciled_closed_rows' in globals():
            rows, rec = _v607_reconciled_closed_rows()  # type: ignore[name-defined]
            return rows if isinstance(rows, list) else [], rec if isinstance(rec, dict) else {}
    except Exception as exc:
        log_error('v626_reconciled_rows_v607', exc)
    try:
        return read_jsonl_tail(FILES['closed'], 1500), {'source': 'closed_tail_fallback_v626'}
    except Exception as exc:
        log_error('v626_reconciled_rows_tail', exc)
        return [], {'source': 'empty_error_v626'}


def _v626_today_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        if '_v557_filter_today' in globals():
            return _v557_filter_today(rows, now_ts())  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v626_today_rows_filter', exc)
    return rows


def _v626_build_review_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v626_today_rows(rows)
    try:
        if '_v623_strategy_win_loss_lines' in globals():
            wl_lines, wl_data = _v623_strategy_win_loss_lines(today_rows)  # type: ignore[name-defined]
        elif '_v622_build_strategy_win_loss_review' in globals():
            wl_lines, wl_data = _v622_build_strategy_win_loss_review(today_rows)  # type: ignore[name-defined]
        else:
            wl_lines, wl_data = ['📊 전략별 승리군/패배군 비교 · v626', f'- 오늘 CLOSED {len(today_rows)}개'], {}
    except Exception as exc:
        log_error('v626_strategy_win_loss_lines', exc)
        wl_lines, wl_data = ['📊 전략별 승리군/패배군 비교 · v626', f'- 전략별 비교 생성 오류: {type(exc).__name__}: {exc}', f'- 오늘 CLOSED {len(today_rows)}개'], {}

    recent_lines = ['[오늘 CLOSED 최근]']
    if today_rows:
        for r in today_rows[-8:]:
            try:
                ticker = str(r.get('ticker') or r.get('symbol') or '-')
                strat = str(r.get('strategy_label') or r.get('strategy') or r.get('strategy_key') or '-')
                pnl = fnum(r.get('pnl_pct'), r.get('profit_pct'), r.get('return_pct'), default=0.0)
                src = '알림원천보강' if r.get('reconciled_from_close_alert_trace') else '장부'
                recent_lines.append(f'- {ticker} {pnl:+.2f}% / {strat} / {src}')
            except Exception:
                continue
    else:
        recent_lines.append('- 오늘 CLOSED 없음')

    summary_lines = []
    # Ensure title is v626 even if reused helper returned v623/v622 title
    if wl_lines:
        first = str(wl_lines[0])
        if '/trade_review' in first or '전략별 승리군/패배군 비교' in first:
            summary_lines.append('📊 전략별 승리군/패배군 비교 /trade_review · v626')
            summary_lines.extend([str(x) for x in wl_lines[1:]])
        else:
            summary_lines.append('📊 전략별 승리군/패배군 비교 /trade_review · v626')
            summary_lines.extend([str(x) for x in wl_lines])
    else:
        summary_lines = ['📊 전략별 승리군/패배군 비교 /trade_review · v626', '- 오늘 CLOSED 없음']
    summary_lines += ['', *recent_lines]
    summary_lines += [
        '',
        '[source 대조]',
        f'- CLOSED 장부 {line_count_cached(FILES["closed"], ttl=0) if "line_count_cached" in globals() else len(rows)} / close_alert unique {reconcile.get("alert_unique", reconcile.get("close_alert_unique", "-")) if isinstance(reconcile, dict) else "-"} / cache 보강 {reconcile.get("reconciled_added", reconcile.get("cache_added", "-")) if isinstance(reconcile, dict) else "-"}',
        '- 조건/S등급/청산/장부는 변경하지 않는다.',
    ]
    obj = {
        'schema': 'paper_review_spine_v626_strategy_win_loss_compare',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v626_final_review_writer_same_reconciled_rows',
        'source': 'same_reconciled_rows_as_paper_score_cache_v626',
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv) if 'iso_ts' in globals() else now_text(nowv),
        'closed_count': len(rows),
        'today_closed_count': len(today_rows),
        'strategy_win_loss_analysis': wl_data if isinstance(wl_data, dict) else {},
        'summary_text': '\n'.join(summary_lines).strip(),
        'reconcile': reconcile if isinstance(reconcile, dict) else {},
    }
    return obj


def _v626_write_score_review_cache(status: Optional[Dict[str, Any]] = None) -> None:
    rows, reconcile = _v626_reconciled_rows()
    try:
        if '_v607_build_score_cache_obj' in globals():
            score_obj = _v607_build_score_cache_obj(rows, status, reconcile)  # type: ignore[name-defined]
        else:
            today = _v626_today_rows(rows)
            score_obj = {'schema': 'paper_score_cache_v626_minimal', 'closed_count': len(rows), 'today_closed_count': len(today), 'updated_at': now_ts(), 'build': BUILD_LABEL}
        if isinstance(score_obj, dict):
            score_obj['build'] = BUILD_LABEL
        save_json(FILES['score'], score_obj)
    except Exception as exc:
        log_error('v626_score_write', exc)
        try:
            _v626_prev_write_score_cache(status)  # type: ignore[name-defined]
        except Exception as exc2:
            log_error('v626_score_fallback', exc2)
    try:
        save_json(FILES['trade_review'], _v626_build_review_cache(rows, status, reconcile))
    except Exception as exc:
        log_error('v626_review_write', exc)


_v626_prev_paper_final_safety = paper_final_safety

def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:  # type: ignore[override]
    ok, reasons, diag = _v626_prev_paper_final_safety(ev, ctrl)
    try:
        strict = _v624_trigger_gate_strict(ev, diag) if '_v624_trigger_gate_strict' in globals() else {'ok': True, 'reason': 'no_v624_gate'}
        diag['trigger_gate_v626'] = strict
        if strict.get('ok') is False:
            reason = 'trigger_not_reached_v626: ' + str(strict.get('reason') or '방아쇠 미도달')
            if reason not in reasons:
                reasons.append(reason)
            try:
                ev2 = dict(ev)
                ev2['paper_entry_action'] = 'trigger_not_reached_hold'
                ev2['paper_entry_block_reason'] = reason
                if '_v624_append_hourly_event' in globals():
                    _v624_append_hourly_event('open_block', ev2, '', 'trigger_not_reached_v626', reason)  # type: ignore[name-defined]
            except Exception as exc:
                log_error('v626_trigger_block_trace', exc)
            return False, reasons, diag
    except Exception as exc:
        log_error('v626_trigger_gate', exc)
    return ok, reasons, diag


_v626_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v626_write_score_review_cache(status)


_v626_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    _v626_prev_write_status(status)
    try:
        st = _v621_sync_open_source_status(status, phase='v626_write_status') if '_v621_sync_open_source_status' in globals() else status
        _v626_write_score_review_cache(st if isinstance(st, dict) else status)
    except Exception as exc:
        log_error('v626_write_status_spine', exc)


_v626_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v626_prev_run_cycle()
    try:
        _v626_write_score_review_cache(st if isinstance(st, dict) else None)
    except Exception as exc:
        log_error('v626_run_cycle_review_spine', exc)
    try:
        if '_v625_send_due_hourly_raw_pack' in globals():
            _v625_send_due_hourly_raw_pack()  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v626_run_cycle_hourly_pack', exc)
    if isinstance(st, dict):
        st['build'] = BUILD_LABEL
        st['review_schema'] = 'paper_review_spine_v626_strategy_win_loss_compare'
        st['trigger_gate_schema'] = 'paper_trigger_gate_v626_strict'
    return st if isinstance(st, dict) else {}

try:
    _v626_write_score_review_cache(None)
except Exception as exc:
    log_error('v626_startup_review_cache', exc)



# =============================================================================
# paper_bot v0.223 / v627: final review cache writer lock
# - v626에서도 live cache가 paper_review_spine_v591로 되돌아갔다.
# - 원인은 구 review writer가 마지막에 paper_bot_trade_review_cache.json을 덮거나
#   active paper file이 최신 writer를 확실히 타지 않는 문제로 본다.
# - 여기서는 최종 write_status/write_score_cache/run_cycle 뒤에 같은 CLOSED rows로
#   score + trade_review cache를 직접 다시 쓰고 status에 build/schema를 남긴다.
# - 조건/S등급/청산/자동매수/장부 삭제 변경 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp


def _v627_safe_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    for k in keys:
        try:
            v = row.get(k) if isinstance(row, dict) else None
            if v is None or v == '':
                continue
            return float(str(v).replace(',', ''))
        except Exception:
            continue
    return default


def _v627_row_strategy(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return 'unknown'
    for k in ('strategy_label','strategy_name','strategy','strategy_key'):
        v = row.get(k)
        if v:
            return str(v)
    snap = row.get('canonical_entry_snapshot') or row.get('entry_snapshot') or row.get('entry_context')
    if isinstance(snap, dict):
        for k in ('strategy_label','strategy_name','strategy','strategy_key'):
            if snap.get(k):
                return str(snap.get(k))
    return 'unknown'


def _v627_row_pnl(row: Dict[str, Any]) -> float:
    return _v627_safe_num(row, 'pnl_pct','profit_pct','return_pct','net_pct','pnl', default=0.0)


def _v627_row_text(row: Dict[str, Any]) -> str:
    try:
        return json.dumps(row, ensure_ascii=False, default=str)
    except Exception:
        return str(row)


def _v627_first_bool(row: Dict[str, Any], *keys: str) -> Optional[bool]:
    stack = [row]
    seen = 0
    while stack and seen < 160:
        seen += 1
        obj = stack.pop()
        if isinstance(obj, dict):
            for k in keys:
                if k in obj:
                    v = obj.get(k)
                    if isinstance(v, bool):
                        return v
                    if isinstance(v, (int, float)):
                        return bool(v)
                    if isinstance(v, str):
                        s = v.strip().lower()
                        if s in ('true','yes','y','1','ok','reached','도달'):
                            return True
                        if s in ('false','no','n','0','miss','missing','미도달'):
                            return False
            stack.extend(obj.values())
        elif isinstance(obj, list):
            stack.extend(obj[:30])
    return None


def _v627_first_num(row: Dict[str, Any], *keys: str, default: float = 0.0) -> float:
    stack = [row]
    seen = 0
    while stack and seen < 160:
        seen += 1
        obj = stack.pop()
        if isinstance(obj, dict):
            for k in keys:
                if k in obj:
                    try:
                        v = obj.get(k)
                        if v is not None and v != '':
                            return float(str(v).replace(',', ''))
                    except Exception:
                        pass
            stack.extend(obj.values())
        elif isinstance(obj, list):
            stack.extend(obj[:30])
    return default


def _v627_reason_tags(row: Dict[str, Any], win: bool) -> List[str]:
    txt = _v627_row_text(row)
    pnl = _v627_row_pnl(row)
    peak = _v627_first_num(row, 'peak_pct','max_profit_pct','highest_profit_pct','best_pct', default=0.0)
    entry = _v627_first_num(row, 'entry_price','open_price', default=0.0)
    trigger = _v627_first_num(row, 'trigger_price', default=0.0)
    reached = _v627_first_bool(row, 'trigger_reached','trigger_touched','trigger_ok')
    buy = _v627_first_num(row, 'buy_trade_ratio','buy_ratio','buy_strength', default=0.0)
    persist = _v627_first_num(row, 'one_min_persist','one_min_buy_persist','persist_1m', default=0.0)
    reaction = _v627_first_num(row, 'price_reaction_pct','reaction_pct','price_change_1m_pct', default=0.0)
    rel = _v627_first_num(row, 'relative_strength','rel_strength','rs_score', default=0.0)
    flow15 = _v627_first_num(row, 'flow_15m_pct','ret_15m_pct','change_15m_pct', default=0.0)
    spread = _v627_first_num(row, 'spread_pct','spread', default=0.0)
    slip = _v627_first_num(row, 'slippage_pct','expected_slippage_pct','slip_pct', default=0.0)
    tags: List[str] = []
    if entry and trigger and entry < trigger:
        tags.append('방아쇠 전 진입')
    elif reached is True or (entry and trigger and entry >= trigger):
        tags.append('방아쇠 확인 후 진입')
    if peak <= 0.05 and pnl <= 0:
        tags.append('진입후무반응/빠른실패')
    if buy >= 0.70 and persist >= 0.70 and peak <= 0.10 and pnl <= 0:
        tags.append('체결은 좋지만 가격 안 감')
    if reaction >= 0.50 and pnl <= 0:
        tags.append('초반반응 후 지속실패')
    if rel <= 0.0 and ('상대강도' in txt or 'relative' in txt.lower()):
        tags.append('상대강도 약함')
    if flow15 <= 0.0 and ('15m' in txt or '15분' in txt):
        tags.append('15분 흐름 약함')
    if spread >= 0.20 or slip >= 0.20:
        tags.append('스프레드/미끄러짐 부담')
    if any(s in txt for s in ('가짜돌파','방어실패','재돌파 실패','윗꼬리')) and pnl <= 0:
        tags.append('돌파/방어 실패')
    if any(s in txt for s in ('늦은추격','late_chase')):
        tags.append('늦은추격')
    if win:
        if peak >= 0.50 or pnl > 0:
            tags.append('초반 반응 수익 연결')
        if any(s in txt for s in ('VWAP방어','EMA방어','돈흐름재유입','저항돌파후재테스트')):
            tags.append('구조 방어 유지')
    if not tags:
        tags.append('기타/표본')
    return tags[:8]


def _v627_reconciled_rows() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    try:
        if '_v607_reconciled_closed_rows' in globals():
            rows, rec = _v607_reconciled_closed_rows()  # type: ignore[name-defined]
            return rows if isinstance(rows, list) else [], rec if isinstance(rec, dict) else {}
    except Exception as exc:
        log_error('v627_reconciled_rows_v607', exc)
    try:
        return read_jsonl_tail(FILES['closed'], 2000), {'source': 'closed_tail_fallback_v627'}
    except Exception as exc:
        log_error('v627_reconciled_rows_tail', exc)
        return [], {'source': 'empty_error_v627'}


def _v627_today_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        if '_v557_filter_today' in globals():
            return _v557_filter_today(rows, now_ts())  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v627_today_rows_filter', exc)
    return rows


def _v627_counter_line(label: str, counter: Counter, limit: int) -> str:
    if not counter:
        return f'- {label}: -'
    return f"- {label}: " + ' / '.join(f'{k} {v}' for k, v in counter.most_common(limit))


def _v627_strategy_lines(today_rows: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    by: Dict[str, List[Dict[str, Any]]] = {}
    for r in today_rows:
        by.setdefault(_v627_row_strategy(r), []).append(r)
    lines: List[str] = ['📊 전략별 승리군/패배군 비교 /trade_review · v627']
    data: Dict[str, Any] = {}
    if not by:
        lines.append('- 오늘 CLOSED 없음')
        return lines, data
    for strat, rs in sorted(by.items(), key=lambda kv: len(kv[1]), reverse=True):
        wins = [r for r in rs if _v627_row_pnl(r) > 0]
        losses = [r for r in rs if _v627_row_pnl(r) <= 0]
        total = sum(_v627_row_pnl(r) for r in rs)
        avg = total / len(rs) if rs else 0.0
        winrate = len(wins) / len(rs) * 100.0 if rs else 0.0
        wc: Counter = Counter()
        lc: Counter = Counter()
        for r in wins:
            wc.update(_v627_reason_tags(r, True))
        for r in losses:
            lc.update(_v627_reason_tags(r, False))
        recent_losses = losses[-5:]
        lines.append('')
        lines.append(f'[{strat}]')
        lines.append(f'- 성과: {len(rs)}전 {len(wins)}승 {len(losses)}패 / 승률 {winrate:.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%')
        lines.append(_v627_counter_line('승리군 공통점', wc, 5))
        lines.append(_v627_counter_line('패배군 원인', lc, 7))
        if recent_losses:
            lines.append('- 최근 패배: ' + ' / '.join(f"{r.get('ticker', r.get('symbol','-'))} {_v627_row_pnl(r):+.2f}%" for r in recent_losses))
        data[strat] = {
            'total': len(rs), 'wins': len(wins), 'losses': len(losses),
            'sum_pct': round(total, 4), 'avg_pct': round(avg, 4), 'winrate': round(winrate, 2),
            'win_tags': dict(wc), 'loss_tags': dict(lc),
        }
    return lines, data


def _v627_build_review_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v627_today_rows(rows)
    strategy_lines, data = _v627_strategy_lines(today_rows)
    recent_lines = ['[오늘 CLOSED 최근]']
    for r in today_rows[-10:]:
        ticker = str(r.get('ticker') or r.get('symbol') or '-')
        strat = _v627_row_strategy(r)
        src = '알림원천보강' if r.get('reconciled_from_close_alert_trace') else '장부'
        recent_lines.append(f'- {ticker} {_v627_row_pnl(r):+.2f}% / {strat} / {src}')
    if len(recent_lines) == 1:
        recent_lines.append('- 오늘 CLOSED 없음')
    source_lines = [
        '[source 대조]',
        f'- CLOSED 장부 {line_count_cached(FILES["closed"], ttl=0) if "line_count_cached" in globals() else len(rows)} / close_alert unique {reconcile.get("alert_unique", reconcile.get("close_alert_unique", "-")) if isinstance(reconcile, dict) else "-"} / cache 보강 {reconcile.get("reconciled_added", reconcile.get("cache_added", "-")) if isinstance(reconcile, dict) else "-"}',
        '- 조건/S등급/청산/장부는 변경하지 않는다.',
    ]
    summary = '\n'.join(strategy_lines + ['', *recent_lines, '', *source_lines]).strip()
    return {
        'schema': 'paper_review_spine_v627_strategy_win_loss_compare',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v627_final_review_writer_lock',
        'source': 'same_reconciled_rows_as_paper_score_cache_v627',
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv) if 'iso_ts' in globals() else now_text(nowv),
        'closed_count': len(rows),
        'today_closed_count': len(today_rows),
        'strategy_win_loss_analysis': data,
        'summary_text': summary,
        'reconcile': reconcile if isinstance(reconcile, dict) else {},
    }


def _v627_write_score_review_cache(status: Optional[Dict[str, Any]] = None) -> None:
    rows, reconcile = _v627_reconciled_rows()
    try:
        if '_v607_build_score_cache_obj' in globals():
            score_obj = _v607_build_score_cache_obj(rows, status, reconcile)  # type: ignore[name-defined]
        else:
            today = _v627_today_rows(rows)
            score_obj = {'schema': 'paper_score_cache_v627_minimal', 'closed_count': len(rows), 'today_closed_count': len(today), 'updated_at': now_ts()}
        if isinstance(score_obj, dict):
            score_obj['build'] = BUILD_LABEL
            score_obj['review_schema'] = 'paper_review_spine_v627_strategy_win_loss_compare'
        save_json(FILES['score'], score_obj)
    except Exception as exc:
        log_error('v627_score_write', exc)
    try:
        obj = _v627_build_review_cache(rows, status, reconcile)
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('v627_review_write', exc)


_v627_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    try:
        _v627_prev_write_score_cache(status)
    except Exception as exc:
        log_error('v627_prev_score_write', exc)
    _v627_write_score_review_cache(status)


_v627_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    try:
        _v627_prev_write_status(status)
    except Exception as exc:
        log_error('v627_prev_write_status', exc)
    try:
        st = _v621_sync_open_source_status(status, phase='v627_write_status') if '_v621_sync_open_source_status' in globals() else status
        if isinstance(st, dict):
            st['build'] = BUILD_LABEL
            st['review_schema'] = 'paper_review_spine_v627_strategy_win_loss_compare'
            st['score_review_writer'] = 'v627_final_lock'
            save_json(FILES['status'], st)
        _v627_write_score_review_cache(st if isinstance(st, dict) else status)
    except Exception as exc:
        log_error('v627_write_status_final', exc)


_v627_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v627_prev_run_cycle()
    try:
        _v627_write_score_review_cache(st if isinstance(st, dict) else None)
    except Exception as exc:
        log_error('v627_run_cycle_review_final', exc)
    try:
        if '_v625_send_due_hourly_raw_pack' in globals():
            _v625_send_due_hourly_raw_pack()  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v627_run_cycle_hourly_pack', exc)
    if isinstance(st, dict):
        st['build'] = BUILD_LABEL
        st['review_schema'] = 'paper_review_spine_v627_strategy_win_loss_compare'
        st['score_review_writer'] = 'v627_final_lock'
    return st if isinstance(st, dict) else {}

try:
    _v627_write_score_review_cache(None)
except Exception as exc:
    log_error('v627_startup_review_cache', exc)



# =============================================================================
# paper_bot v0.223 / v628: 단일 paper 실행본선 재배선
# - 이전 꼬리 override 체인을 더 이상 호출하지 않는다.
# - candidate -> final_gate -> OPEN/보류 -> 단일 알림 -> CLOSED -> 단일 review/hourly writer.
# - 조건/S1/S2/S3/청산/자동매수/장부 삭제 변경 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
FILES.setdefault('hourly_event_trace', BASE_DIR / 'paper_bot_hourly_raw_event_trace.jsonl')
FILES.setdefault('hourly_sent_state', BASE_DIR / 'paper_bot_hourly_raw_pack_sent.json')


def _v628_now() -> float:
    return now_ts()


def _v628_deep_values(obj: Any, key: str, depth: int = 5) -> List[Any]:
    out: List[Any] = []
    if depth < 0:
        return out
    if isinstance(obj, dict):
        if key in obj and obj.get(key) not in (None, '', [], {}):
            out.append(obj.get(key))
        for v in obj.values():
            if isinstance(v, (dict, list)):
                out.extend(_v628_deep_values(v, key, depth-1))
    elif isinstance(obj, list):
        for v in obj[:80]:
            if isinstance(v, (dict, list)):
                out.extend(_v628_deep_values(v, key, depth-1))
    return out


def _v628_first_num(*objs: Any, keys: Tuple[str, ...], default: float = 0.0) -> float:
    for obj in objs:
        for key in keys:
            for v in _v628_deep_values(obj, key, depth=5):
                x = fnum(v, default=0.0)
                if x > 0:
                    return x
    return default


def _v628_trigger_gate(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, entry_override: Optional[float] = None) -> Dict[str, Any]:
    diag = diag if isinstance(diag, dict) else {}
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    ticker = normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    base_price = fnum(entry_override, ev.get('entry_price'), ev.get('current_price'), ev.get('live_price'), ev.get('price'), ev.get('trade_price'), ev.get('detected_price'), default=0.0)
    if base_price <= 0:
        base_price = get_event_price(ev)
    entry = live_price(ticker, base_price) if ticker else base_price
    trigger = _v628_first_num(
        ev, diag, ctx,
        keys=('trigger_price','entry_trigger_price','breakout_trigger_price','s1_trigger_price'),
        default=0.0,
    )
    reached = bool(trigger > 0 and entry > 0 and entry >= trigger)
    gap = None
    if trigger > 0 and entry > 0:
        try:
            gap = round((entry-trigger)/trigger*100.0, 4)
        except Exception:
            gap = None
    if trigger <= 0:
        reason = 'trigger_missing_v628: 방아쇠 가격 없음'
    elif not reached:
        reason = f'trigger_not_reached_v628: 진입 {fmt_price(entry)} < 방아쇠 {fmt_price(trigger)}'
    else:
        reason = 'trigger_reached_v628: 방아쇠 도달 확인'
    return {
        'schema':'paper_trigger_gate_v628_strict_single_spine',
        'entry_price': entry or None,
        'trigger_price': trigger or None,
        'trigger_reached': reached,
        'trigger_gap_pct': gap,
        'reason': reason,
        'ticker': ticker,
    }


def _v628_apply_gate_to_diag(diag: Dict[str, Any], gate: Dict[str, Any]) -> Dict[str, Any]:
    diag = diag if isinstance(diag, dict) else {}
    diag['trigger_gate'] = gate
    diag['trigger_gate_v628'] = gate
    diag['trigger_reached'] = bool(gate.get('trigger_reached'))
    diag['trigger_gap_pct'] = gate.get('trigger_gap_pct')
    diag['trigger_price'] = gate.get('trigger_price')
    diag['entry_price'] = gate.get('entry_price') or diag.get('entry_price')
    return diag


def _v628_append_hourly_event(kind: str, row: Dict[str, Any], message_text: str = '', phase: str = '', note: str = '') -> None:
    try:
        ts = _v628_now()
        item = {
            'schema':'paper_hourly_raw_event_v628',
            'version':VERSION,
            'build':BUILD_LABEL,
            'kind':str(kind or ''),
            'phase':str(phase or ''),
            'ts':ts,
            'ts_text':iso_ts(ts),
            'kst_hour':_v628_hour_key(ts),
            'ticker':normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')),
            'event_id':row.get('event_id') or row.get('pos_id') or row.get('entry_id'),
            'pos_id':row.get('pos_id') or row.get('event_id') or row.get('entry_id'),
            'strategy':row.get('strategy_label') or row.get('strategy_key') or row.get('strategy'),
            'entry_price':row.get('entry_price'),
            'trigger_price':_v628_first_num(row, keys=('trigger_price',), default=0.0) or None,
            'pnl_pct':row.get('pnl_pct'),
            'exit_reason':row.get('exit_reason') or row.get('exit_rule'),
            'note':str(note or ''),
            'message_text':str(message_text or '')[:16000],
            'raw':row,
        }
        append_jsonl(FILES['hourly_event_trace'], item)
    except Exception as exc:
        log_error('v628_append_hourly_event', exc)


def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:  # type: ignore[override]
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    reasons: List[str] = []
    # strategy final state only; paper does not create a new buy signal.
    try:
        final = _paper_v602_final_trade_state(ev, ctx) if '_paper_v602_final_trade_state' in globals() else {'state': ev.get('final_trade_state'), 'allowed': ev.get('final_trade_state') == 'S1_PASS', 'reasons': []}
    except Exception as exc:
        log_error('v628_final_state_read', exc)
        final = {'state':'', 'allowed':False, 'label':'final_state_error', 'reasons':[str(exc)]}
    diag['final_trade_state'] = final.get('state')
    diag['final_trade_label'] = final.get('label')
    diag['final_trade_state_source'] = final.get('source')
    if final.get('state') != 'S1_PASS':
        why = final.get('reasons') if isinstance(final.get('reasons'), list) else []
        reasons.append('전략 최종판정 보류: ' + str(final.get('label') or final.get('state') or '없음') + ((' / ' + ' / '.join(str(x) for x in why[:3])) if why else ''))
    # strict displayed trigger gate. If the alert would display trigger X, paper entry must be >= X.
    gate = _v628_trigger_gate(ev, diag)
    _v628_apply_gate_to_diag(diag, gate)
    if not gate.get('trigger_reached'):
        reasons.append(str(gate.get('reason') or 'trigger_not_reached_v628'))
    # canonical entry decision remains a diagnostic/execution-safety source.
    try:
        dec = _paper_v484_canonical_entry_decision(ev, ctx) if '_paper_v484_canonical_entry_decision' in globals() else {}
    except Exception as exc:
        log_error('v628_canonical_decision', exc)
        dec = {}
    if isinstance(dec, dict) and dec:
        diag['canonical_entry_decision'] = dec
        diag['entry_decision_schema'] = dec.get('schema')
        diag['entry_profile'] = ev.get('entry_profile') or ctx.get('entry_profile') or dec.get('entry_profile')
        diag['exit_profile'] = ev.get('exit_profile') or ctx.get('exit_profile') or dec.get('exit_profile')
        if not bool(dec.get('gate_pass') or dec.get('s1_allowed')):
            rs = dec.get('display_reasons') if isinstance(dec.get('display_reasons'), list) else []
            reasons.append('전략조건 재확인 보류: ' + ' / '.join(str(x) for x in rs[:4]))
        try:
            reasons.extend(_paper_v484_exec_safety_reasons(diag, ctrl))
        except Exception as exc:
            log_error('v628_exec_safety', exc)
    else:
        diag['entry_decision_schema'] = 'missing_canonical_entry_decision_v628'
        reasons.append('전략판단 원천 없음: canonical_entry_decision 누락')
    if not micro_fresh(ev, ctrl):
        reasons.append('호가·체결 신선정보 없음')
    if bool(ctrl.get('paper_final_require_ws_fresh', False)) and not ws_fresh(ev):
        reasons.append('실시간 시세 신선정보 없음')
    try:
        preopen_reasons = _v746_preopen_freshness_reasons(ev, diag, ctrl)
        if preopen_reasons:
            reasons.extend(preopen_reasons)
    except Exception as exc:
        log_error('v746_preopen_freshness_guard', exc)
        reasons.append('OPEN직전 최신성 검사 오류')
    # de-dupe
    clean=[]
    for r in reasons:
        s=str(r or '').strip()
        if s and s not in clean:
            clean.append(s)
    ok = not clean
    if not ok:
        try:
            ev2 = dict(ev)
            ev2['paper_entry_action'] = 'trigger_not_reached_hold' if any('trigger_' in x for x in clean) else 'recheck_hold'
            ev2['paper_entry_hold_reasons'] = clean
            ev2['paper_final_safety_diagnostics'] = diag
            _v628_append_hourly_event('open_block', ev2, '', ev2.get('paper_entry_action'), ' / '.join(clean[:5]))
        except Exception as exc:
            log_error('v628_safety_block_hourly', exc)
    return ok, clean[:12], diag


def _v628_trigger_gate_line(row: Dict[str, Any], diag: Dict[str, Any], prefix: str = '- ') -> str:
    gate = diag.get('trigger_gate_v628') if isinstance(diag.get('trigger_gate_v628'), dict) else (diag.get('trigger_gate') if isinstance(diag.get('trigger_gate'), dict) else _v628_trigger_gate(row, diag))
    if not gate.get('trigger_price'):
        return prefix + '방아쇠확인: ❔ 정보없음 / S1 불가'
    status = '✅ 도달' if gate.get('trigger_reached') else '❌ 미도달'
    gap = gate.get('trigger_gap_pct')
    gap_txt = f' / gap {gap:+.2f}%' if isinstance(gap, (int, float)) else ''
    return prefix + f"방아쇠확인: {status} / 진입 {fmt_price(gate.get('entry_price'))} vs 방아쇠 {fmt_price(gate.get('trigger_price'))}{gap_txt}"


def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = '- ') -> List[str]:  # type: ignore[override]
    # Direct formatter: no previous formatter chain.
    diag = diag if isinstance(diag, dict) else {}
    row = diag.get('_source_row') if isinstance(diag.get('_source_row'), dict) else {}
    lines: List[str] = []
    structures = diag.get('entry_structure_tags') if isinstance(diag.get('entry_structure_tags'), list) else []
    reasons = diag.get('entry_reasons') if isinstance(diag.get('entry_reasons'), list) else []
    confirms = diag.get('confirm_signals') if isinstance(diag.get('confirm_signals'), list) else []
    risks = diag.get('execution_risk_tags') if isinstance(diag.get('execution_risk_tags'), list) else []
    levels = diag.get('structure_levels') if isinstance(diag.get('structure_levels'), dict) else {}
    plan = diag.get('entry_plan') if isinstance(diag.get('entry_plan'), dict) else {}
    rr = diag.get('risk_reward') if isinstance(diag.get('risk_reward'), dict) else {}
    timing = diag.get('entry_timing_spine') if isinstance(diag.get('entry_timing_spine'), dict) else {}
    if structures:
        lines.append(prefix + '진입구조: ' + ' / '.join(str(x) for x in structures[:6]))
    if reasons:
        lines.append(prefix + '진입근거: ' + ' / '.join(str(x) for x in reasons[:6]))
    if confirms:
        lines.append(prefix + '확인통과: ' + ' / '.join(str(x) for x in confirms[:6]))
    if levels:
        lines.append(prefix + '구조선: 지지 ' + fmt_price(levels.get('support_price')) + ' / 방아쇠 ' + fmt_price(levels.get('trigger_price')) + ' / 무효 ' + fmt_price(levels.get('invalid_price')) + ' / 목표 ' + fmt_price(levels.get('target1_price')) + '→' + fmt_price(levels.get('target2_price')))
    lines.append(_v628_trigger_gate_line(row, diag, prefix))
    if plan:
        lines.append(prefix + '진입계획: ' + str(plan.get('plan_type') or '-') + ' / ' + str(plan.get('trigger_reason') or '-'))
    if rr:
        up=fnum(rr.get('expected_upside_pct'), default=0.0); dn=fnum(rr.get('expected_downside_pct'), default=0.0); ratio=fnum(rr.get('rr_ratio'), default=0.0)
        lines.append(prefix + f'손익비: 기대상승 {up:+.2f}% / 무효손실 {-abs(dn):+.2f}% / RR {ratio:.2f}')
    if timing:
        d1=fnum(timing.get('first_to_now_delay_sec'), default=0.0); r1=fnum(timing.get('first_to_now_return_pct'), default=0.0)
        d2=fnum(timing.get('s2_to_now_delay_sec'), default=0.0); r2=fnum(timing.get('s2_to_now_return_pct'), default=0.0)
        lines.append(prefix + f'진입타이밍: 최초→현재 {d1:.0f}s/{r1:+.2f}% · S2→현재 {d2:.0f}s/{r2:+.2f}%')
    else:
        lines.append(prefix + '진입타이밍: ❔ 정보없음')
    if risks:
        lines.append(prefix + '위험태그: ' + ' / '.join(str(x) for x in risks[:6]))
    flow = f"1m {_paper_v479_flow_display(diag,'1m')} · 3m {_paper_v479_flow_display(diag,'3m')} · 5m {_paper_v479_flow_display(diag,'5m')} · 15m {_paper_v479_flow_display(diag,'15m')}"
    lines.append(prefix + '흐름: ' + flow)
    lines.append(prefix + f"위치: VWAP {fnum(diag.get('vwap_pos_pct'), default=0.0):+.2f}% · EMA5 {fnum(diag.get('ema5_pos_pct'), default=0.0):+.2f}% · 상대강도 {fnum(diag.get('relative_strength'), default=0.0):+.2f}")
    if diag.get('late_chase_flag'):
        lines.append(prefix + '늦은추격: ⚠️ 주의')
    lines.append(prefix + '최종판정: ' + str(diag.get('final_trade_label') or diag.get('final_trade_state') or 'S1 통과'))
    return lines


def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    ticker = normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
    detected = get_event_price(ev)
    price = live_price(ticker, detected) if ticker else detected
    ts = _v628_now()
    ctx = copy_entry_context(ev)
    diag = ev.get('paper_final_safety_diagnostics') if isinstance(ev.get('paper_final_safety_diagnostics'), dict) else build_entry_diagnostics(ev, ctx)
    gate = _v628_trigger_gate(ev, diag, price)
    _v628_apply_gate_to_diag(diag, gate)
    if not gate.get('trigger_reached'):
        # This must not happen because select_candidates should have held it. Keep a hard fail here too.
        raise RuntimeError(str(gate.get('reason') or 'trigger_not_reached_v628'))
    diag['_source_row'] = {'entry_price': price, 'ticker': ticker, 'trigger_price': gate.get('trigger_price')}
    timing_trace = build_entry_timing_trace(ev, diag) if 'build_entry_timing_trace' in globals() else {}
    diag['entry_timing_trace'] = timing_trace
    grade = str(ev.get('s_stage') or ev.get('candidate_stage') or ev.get('candidate_grade') or ev.get('grade') or 'S1').upper()
    current_main_version = active_main_version()
    current_patch_version = active_patch_version()
    pos = {
        'pos_id':pos_id, 'event_id':pos_id, 'ticker':ticker, 'lane':'strict',
        'opened_at':ts, 'opened_at_text':iso_ts(ts), 'opened_paper_version':VERSION,
        'paper_build_label':BUILD_LABEL, 'entry_price':price, 'detected_price':detected, 'current_price':price,
        'peak_pct':0.0, 'trough_pct':0.0, 'last_pnl_pct':-fnum(DEFAULT_CONTROL.get('fee_pct_roundtrip'), default=0.10), 'last_update':ts,
        'strategy':ev.get('strategy') or ev.get('strategy_key') or ev.get('route') or 'unknown',
        'strategy_key':ev.get('strategy_key') or ev.get('paper_strategy_key') or ev.get('route') or ev.get('strategy'),
        'strategy_label':ev.get('strategy_label') or ev.get('paper_strategy_label') or ev.get('final_entry_label'),
        'candidate_grade':grade, 'score':fnum(ev.get('score'), ev.get('leader_score'), default=0.0),
        'entry_profile':ev.get('entry_profile') or ctx.get('entry_profile') or diag.get('entry_profile') or 'normal_common',
        'exit_profile':ev.get('exit_profile') or ctx.get('exit_profile') or diag.get('exit_profile') or 'normal_exit',
        'entry_context':ctx, 'raw':ev, 'entry_diagnostics':diag,
        'canonical_entry_snapshot': ev.get('canonical_metric_row') or ctx.get('canonical_metric_row') or {},
        'trigger_gate':gate, 'trigger_reached':True, 'trigger_price':gate.get('trigger_price'), 'trigger_gap_pct':gate.get('trigger_gap_pct'),
        'score_main_version':current_main_version, 'opened_main_version':current_main_version, 'main_version':current_main_version, 'deploy_version':current_main_version,
        'entry_build_key':current_patch_version, 'open_build_key':current_patch_version, 'entry_patch_version':current_patch_version,
        'score_patch_version':current_patch_version, 'opened_patch_version':current_patch_version, 'patch_version':current_patch_version, 'run_patch_version':current_patch_version,
        'strategy_worker_version':ev.get('strategy_worker_version') or ev.get('source_version') or ev.get('brain_version') or '',
        'final_trade_state':ev.get('final_trade_state') or ctx.get('final_trade_state'),
        'final_trade_label':ev.get('final_trade_label') or ctx.get('final_trade_label'),
        'trade_ready':True,
        'open_source':'paper_single_spine_v628',
    }
    return pos


def _v628_open_message_text(pos: Dict[str, Any]) -> str:
    t = normalize_ticker(pos.get('ticker'))
    link = f'https://www.bithumb.com/trade/order/{t}_KRW' if t else ''
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    extra = '\n'.join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    return (
        '🟢 paper OPEN\n'
        f'- 종목: {t}\n'
        f'- 진입가: {fmt_price(pos.get("entry_price"))}\n'
        f'- 등급: {pos.get("candidate_grade","S1")} / 점수 {fnum(pos.get("score"), default=0.0):.2f}\n'
        f'\n📌 진입 정보\n- 전략: {pos.get("strategy_label") or pos.get("strategy") or "-"}\n- profile: {pos.get("entry_profile","-")} / exit {pos.get("exit_profile","-")}\n'
        f'\n✅ 확인/구조\n{extra}\n'
        f'- 바로보기: {link}\n'
        f'- paper: {VERSION} / {BUILD_LABEL}'
    )


def _v628_closed_message_text(row: Dict[str, Any]) -> str:
    t = normalize_ticker(row.get('ticker'))
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    extra = '\n'.join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    return (
        f'{closed_title(row)}\n'
        f'- 종목: {t}\n'
        f'- 손익: {fnum(row.get("pnl_pct"), default=0.0):+.2f}%\n'
        f'- 이유: {row.get("exit_rule_label") or row.get("exit_reason")}\n\n'
        f'❌ 결과\n- 진입/청산: {fmt_price(row.get("entry_price"))} → {fmt_price(row.get("exit_price"))}\n- 보유: {row.get("age_min","-")}분\n\n'
        f'📉 청산 복기\n- 최고/최저: {fnum(row.get("peak_pct"), default=0.0):+.2f}% / {fnum(row.get("trough_pct"), default=0.0):+.2f}%\n'
        f'- 최종/놓친수익: {fnum(row.get("pnl_pct"), default=0.0):+.2f}% / {fnum(row.get("missed_profit_pct"), default=0.0):+.2f}%\n'
        f'- 평가: {row.get("close_review_tag","관찰")}\n\n'
        f'📌 진입 정보\n- 전략: {row.get("strategy_label") or row.get("strategy") or "-"}\n- profile: {row.get("entry_profile","-")} / exit {row.get("exit_profile","-")}\n\n'
        f'🧾 진입 당시 확인값\n{extra}\n\n'
        f'- paper: {VERSION} / {BUILD_LABEL}'
    )


def _v628_send_with_result(text: str) -> Tuple[bool, str]:
    if '_v561_send_message_with_result' in globals():
        try:
            return _v561_send_message_with_result(text)  # type: ignore[name-defined]
        except Exception as exc:
            log_error('v628_send_with_result_prev', exc)
    try:
        send_message(text)
        return True, ''
    except Exception as exc:
        return False, f'{type(exc).__name__}: {exc}'


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    text = _v628_open_message_text(pos)
    ok, err = _v628_send_with_result(text)
    try:
        if '_v567_append_trade_alert_trace' in globals():
            _v567_append_trade_alert_trace('open', pos, 'send_ok' if ok else 'send_error', ok, err, 'v628_single_message_builder')  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v628_open_trace', exc)
    _v628_append_hourly_event('open', pos, text, 'send_ok' if ok else 'send_error', err)
    if not ok:
        log_error('v628_notify_opened', Exception(err or 'send failed'))


def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    text = _v628_closed_message_text(row)
    ok, err = _v628_send_with_result(text)
    try:
        if '_v567_append_trade_alert_trace' in globals():
            _v567_append_trade_alert_trace('closed', row, 'send_ok' if ok else 'send_error', ok, err, 'v628_single_message_builder')  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v628_closed_trace', exc)
    _v628_append_hourly_event('closed', row, text, 'send_ok' if ok else 'send_error', err)
    if not ok:
        log_error('v628_notify_closed', Exception(err or 'send failed'))


def _v628_reconciled_rows() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    try:
        if '_v607_reconciled_closed_rows' in globals():
            rows, rec = _v607_reconciled_closed_rows()  # type: ignore[name-defined]
            return rows if isinstance(rows, list) else [], rec if isinstance(rec, dict) else {'source':'v607'}
    except Exception as exc:
        log_error('v628_reconcile_v607', exc)
    try:
        return read_jsonl_tail(FILES['closed'], 2000), {'source':'closed_tail_v628'}
    except Exception as exc:
        log_error('v628_reconcile_tail', exc)
        return [], {'source':'empty_v628'}


def _v628_row_ts(row: Dict[str, Any]) -> float:
    try:
        if '_v557_row_ts' in globals():
            ts = _v557_row_ts(row)  # type: ignore[name-defined]
            if ts > 0:
                return ts
    except Exception:
        pass
    for k in ('closed_at','closed_ts','exit_ts','exited_at','timestamp','ts','updated_at','created_at'):
        v=row.get(k)
        if v not in (None,'',[],{}):
            try:
                return float(v)
            except Exception:
                pass
    return 0.0


def _v628_today_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    start = _v557_today_start_ts(now_ts()) if '_v557_today_start_ts' in globals() else (now_ts() - 86400)
    end = now_ts() + 10
    out=[]
    today_key=_kst_day_key(now_ts())
    for r in rows:
        ts=_v628_row_ts(r)
        if ts > 0 and start <= ts <= end:
            out.append(r); continue
        txt=str(r.get('closed_at_text') or r.get('exit_at_text') or r.get('updated_at_text') or '')
        if today_key and today_key in txt:
            out.append(r)
    return out


def _v628_row_strategy(r: Dict[str, Any]) -> str:
    return str(r.get('strategy_label') or r.get('strategy_key') or r.get('strategy') or 'unknown')


def _v628_row_pnl(r: Dict[str, Any]) -> float:
    return fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)


def _v628_reason_tags(r: Dict[str, Any], win: bool) -> List[str]:
    tags=[]
    pnl=_v628_row_pnl(r); peak=fnum(r.get('peak_pct'), r.get('max_profit_pct'), default=pnl)
    if not win:
        if peak <= 0.05: tags.append('진입후무반응')
        if 'trigger_not_reached' in json.dumps(r, ensure_ascii=False): tags.append('방아쇠전진입/보류대상')
        buy=fnum(_v628_first_num(r, keys=('buy_ratio','buy_trade_ratio','micro_buy_ratio'), default=-1), default=-1)
        sustain=fnum(_v628_first_num(r, keys=('buy_sustain_1m','micro_buy_ratio_sustain_1m','buy_ratio_1m'), default=-1), default=-1)
        reaction=fnum(_v628_first_num(r, keys=('price_reaction_pct','price_reaction','reaction_pct'), default=0), default=0)
        rel=fnum(_v628_first_num(r, keys=('relative_strength','relative_strength_score'), default=0), default=0)
        if buy >= 0.70 and sustain >= 0.70 and peak <= 0.10: tags.append('체결은좋지만가격안감')
        if reaction >= 0.80: tags.append('늦은추격/반응과다')
        if rel <= 0.01: tags.append('상대강도약함')
        if str(r.get('exit_reason') or r.get('exit_rule')) == 'fast_fail_stop': tags.append('빠른실패')
        if pnl <= -0.50: tags.append('손실확대')
    else:
        if peak >= 0.70: tags.append('초반수익확보')
        if pnl > 0: tags.append('최종플러스')
        if str(r.get('exit_reason') or '').find('protect') >= 0: tags.append('보호익절성공')
    # structure tags
    for src in (r, r.get('entry_diagnostics') if isinstance(r.get('entry_diagnostics'), dict) else {}, r.get('entry_context') if isinstance(r.get('entry_context'), dict) else {}):
        if not isinstance(src, dict): continue
        for k in ('entry_structure_tags','structure_tags','entry_reasons','risk_tags','execution_risk_tags'):
            v=src.get(k)
            if isinstance(v, list):
                tags.extend(str(x) for x in v[:5] if str(x).strip())
    if not tags:
        tags.append('기타/표본')
    # de-dupe
    out=[]
    for x in tags:
        sx=str(x).strip()
        if sx and sx not in out:
            out.append(sx)
    return out[:12]


def _v628_strategy_review_lines(today: List[Dict[str, Any]]) -> Tuple[str, Dict[str, Any]]:
    by: Dict[str, List[Dict[str, Any]]] = {}
    for r in today:
        by.setdefault(_v628_row_strategy(r), []).append(r)
    lines=['📊 전략별 승리군/패배군 비교 /trade_review · v628']
    data={}
    if not by:
        lines.append('- 오늘 CLOSED 없음')
        return '\n'.join(lines), data
    for strat, rows in sorted(by.items(), key=lambda kv: len(kv[1]), reverse=True):
        wins=[r for r in rows if _v628_row_pnl(r) > 0]
        losses=[r for r in rows if _v628_row_pnl(r) <= 0]
        total=sum(_v628_row_pnl(r) for r in rows); avg=total/len(rows) if rows else 0.0
        wc=Counter(); lc=Counter()
        for r in wins: wc.update(_v628_reason_tags(r, True))
        for r in losses: lc.update(_v628_reason_tags(r, False))
        lines.append('')
        lines.append(f'[{strat}]')
        lines.append(f'- 성과: {len(rows)}전 {len(wins)}승 {len(losses)}패 / 승률 {(len(wins)/len(rows)*100.0 if rows else 0.0):.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%')
        lines.append('- 승리군 공통점: ' + (' / '.join(f'{k} {v}' for k,v in wc.most_common(6)) if wc else '-'))
        lines.append('- 패배군 원인: ' + (' / '.join(f'{k} {v}' for k,v in lc.most_common(8)) if lc else '-'))
        if losses:
            lines.append('- 최근 패배: ' + ' / '.join(f"{r.get('ticker', r.get('symbol','-'))} {_v628_row_pnl(r):+.2f}%" for r in losses[-5:]))
        data[strat]={'total':len(rows),'wins':len(wins),'losses':len(losses),'sum_pct':round(total,4),'avg_pct':round(avg,4),'win_tags':dict(wc),'loss_tags':dict(lc)}
    return '\n'.join(lines), data


def _v628_write_score_review_cache(status: Optional[Dict[str, Any]] = None) -> None:
    rows, rec = _v628_reconciled_rows()
    today = _v628_today_rows(rows)
    try:
        if '_v607_build_score_cache_obj' in globals():
            score = _v607_build_score_cache_obj(rows, status, rec)  # type: ignore[name-defined]
        else:
            score = {'schema':'paper_score_cache_v628_minimal','closed_count':len(rows),'today_closed_count':len(today),'updated_at':now_ts()}
        if isinstance(score, dict):
            score['build']=BUILD_LABEL; score['review_schema']='paper_review_spine_v628_single_spine'; score['score_review_writer']='v628_single_spine'
        save_json(FILES['score'], score)
    except Exception as exc:
        log_error('v628_score_write', exc)
    try:
        summary, data = _v628_strategy_review_lines(today)
        recent=['[오늘 CLOSED 최근]']
        for r in today[-10:]:
            src='알림원천보강' if r.get('reconciled_from_close_alert_trace') else '장부'
            recent.append(f"- {r.get('ticker', r.get('symbol','-'))} {_v628_row_pnl(r):+.2f}% / {_v628_row_strategy(r)} / {src}")
        if len(recent)==1: recent.append('- 오늘 CLOSED 없음')
        obj={
            'schema':'paper_review_spine_v628_single_spine', 'version':VERSION, 'paper_version':VERSION, 'build':BUILD_LABEL,
            'writer':'v628_single_spine_review_writer', 'source':'same_reconciled_rows_as_score_v628',
            'updated_at':now_ts(), 'updated_at_text':iso_ts(), 'closed_count':len(rows), 'today_closed_count':len(today),
            'strategy_win_loss_analysis':data,
            'summary_text': summary + '\n\n' + '\n'.join(recent) + '\n\n[source 대조]\n- score/review same rows · 조건/S등급/청산/장부 변경 없음',
            'reconcile':rec if isinstance(rec, dict) else {},
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('v628_review_write', exc)


def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v628_write_score_review_cache(status)


def _v628_hour_key(ts: Optional[float] = None) -> str:
    return _kst_datetime(ts or now_ts()).strftime('%Y-%m-%d_%H')


def _v628_event_rows() -> List[Dict[str, Any]]:
    return read_jsonl_tail(FILES['hourly_event_trace'], 5000)


def _v628_send_document(path: Path, caption: str = '') -> Tuple[bool, str]:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return False, 'telegram_disabled'
    try:
        import uuid
        boundary='----coinbot'+uuid.uuid4().hex
        parts=[]
        def field(name: str, value: str):
            parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8'))
        field('chat_id', str(NOTIFY_CHAT_ID))
        if caption: field('caption', caption[:900])
        parts.append((f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{path.name}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n').encode('utf-8'))
        parts.append(path.read_bytes()); parts.append(f'\r\n--{boundary}--\r\n'.encode('utf-8'))
        req=urllib.request.Request(f'https://api.telegram.org/bot{TOKEN}/sendDocument', data=b''.join(parts), headers={'Content-Type':'multipart/form-data; boundary='+boundary})
        urllib.request.urlopen(req, timeout=15).read()
        return True,''
    except Exception as exc:
        log_error('v628_send_document', exc)
        return False, f'{type(exc).__name__}: {exc}'


def _v628_send_due_hourly_raw_pack() -> None:
    try:
        rows=_v628_event_rows()
        if not rows: return
        cur=_v628_hour_key(now_ts())
        state=load_json(FILES['hourly_sent_state'], {}) or {}
        sent=set(state.get('sent_hours') or []) if isinstance(state, dict) else set()
        hours=sorted({str(r.get('kst_hour')) for r in rows if r.get('kst_hour') and str(r.get('kst_hour')) < cur})
        for hour in hours:
            if hour in sent: continue
            evs=[r for r in rows if str(r.get('kst_hour')) == hour]
            if not evs: continue
            text=[]
            text.append(f'paper 1시간 원문 묶음집 · {hour} KST')
            text.append(f'- paper: {VERSION} / {BUILD_LABEL}')
            text.append(f'- main: {active_main_version()} / patch {active_patch_version()}')
            text.append(f'- events: {len(evs)} / OPEN {sum(1 for e in evs if e.get("kind")=="open")} / CLOSED {sum(1 for e in evs if e.get("kind")=="closed")} / 보류 {sum(1 for e in evs if e.get("kind")=="open_block")}')
            text.append('')
            for i,e in enumerate(evs,1):
                text.append(f'[{i}] {e.get("kind")} / {e.get("ticker")} / {e.get("phase")} / {e.get("ts_text")}')
                if e.get('note'): text.append('- note: '+str(e.get('note')))
                msg=str(e.get('message_text') or '').strip()
                if msg:
                    text.append(msg)
                else:
                    text.append(json.dumps(e.get('raw') or e, ensure_ascii=False, indent=2)[:6000])
                text.append('\n---\n')
            path=BASE_DIR / f'paper_hourly_raw_pack_{hour}.txt'
            path.write_text('\n'.join(text), encoding='utf-8')
            ok,err=_v628_send_document(path, f'paper hourly raw pack {hour} / {BUILD_LABEL}')
            try: path.unlink()
            except Exception: pass
            if ok:
                sent.add(hour)
            else:
                log_error('v628_hourly_pack_send', Exception(err))
        save_json(FILES['hourly_sent_state'], {'schema':'paper_hourly_sent_v628','sent_hours':sorted(sent)[-96:], 'updated_at':now_ts(), 'updated_at_text':iso_ts()})
        # prune event trace to recent 2 days/5000 lines
        keep=[]; cutoff=now_ts()-2*86400
        for r in rows:
            if fnum(r.get('ts'), default=0.0) >= cutoff:
                keep.append(r)
        keep=keep[-5000:]
        try:
            tmp=FILES['hourly_event_trace'].with_suffix('.jsonl.tmp')
            tmp.write_text('\n'.join(json.dumps(r, ensure_ascii=False) for r in keep)+'\n', encoding='utf-8')
            os.replace(tmp, FILES['hourly_event_trace'])
        except Exception as exc:
            log_error('v628_hourly_prune', exc)
    except Exception as exc:
        log_error('v628_send_due_hourly_raw_pack', exc)


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    started=now_ts(); ctrl=load_control(); open_pos=load_open()
    opened_items=[]; closed_items=[]; picked_ids=set(); opened_ids=set(); pick_stats={}; latest_rows=[]; before_closed=line_count_cached(FILES['closed'], ttl=0)
    if ctrl.get('running', True):
        picked, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        latest_rows=[r for r in (latest_rows or []) if isinstance(r, dict)]
        for pid, ev in picked:
            picked_ids.add(pid)
            if pid in open_pos: continue
            try:
                pos=open_position(pid, ev)
                open_pos[pid]=pos; opened_items.append(pos); opened_ids.add(pid)
            except Exception as exc:
                log_error('v628_open_position', exc)
                try:
                    ev2=dict(ev); ev2['paper_entry_action']='open_exception'; ev2['paper_entry_hold_reasons']=[f'{type(exc).__name__}: {exc}']
                    _v628_append_hourly_event('open_block', ev2, '', 'open_exception', f'{type(exc).__name__}: {exc}')
                except Exception: pass
        for pid,pos in list(open_pos.items()):
            try:
                updated, closed = update_position(pos, ctrl)
                if closed:
                    closed_items.append(closed); open_pos.pop(pid, None); append_jsonl(FILES['closed'], closed); _LAST_CLOSED_COUNT_CACHE.update({'ts':0.0,'count':0})
                else:
                    open_pos[pid]=updated
            except Exception as exc:
                log_error('v628_update_position', exc)
        save_open(open_pos)
    else:
        latest_rows = _v582_active_rows(ctrl) if '_v582_active_rows' in globals() else []
        pick_stats['paused']=1
    if not latest_rows:
        latest_rows = _v582_active_rows(ctrl) if '_v582_active_rows' in globals() else []
    try:
        snapshot, pick_stats = _v582_make_snapshot(latest_rows, ctrl, pick_stats, open_pos) if '_v582_make_snapshot' in globals() else ({'latest_count':len(latest_rows),'merged_fresh':len(latest_rows)}, pick_stats)
    except Exception as exc:
        log_error('v628_snapshot', exc); snapshot={'latest_count':len(latest_rows),'merged_fresh':len(latest_rows)}
    try:
        trace_obj = build_trace(latest_rows, ctrl, open_pos, picked_ids, opened_ids)
    except Exception as exc:
        log_error('v628_build_trace', exc); trace_obj={'version':VERSION,'build':BUILD_LABEL,'updated_at':now_ts(),'rows':[]}
    status={'running':bool(ctrl.get('running', True)), 'loop_seconds':ctrl.get('loop_seconds'), 'opened_this_cycle':len(opened_items), 'closed_this_cycle':len(closed_items), 'open_total':len(open_pos), 'open_count':len(open_pos), 'open_strict':len(open_pos), 'closed_total':line_count_cached(FILES['closed'], ttl=0 if closed_items else 60.0), 'pick_stats':pick_stats, 'elapsed_sec':round(now_ts()-started,3), 'engine':'paper_single_spine_v628', 'legacy_loop':False, 'before_closed_count':before_closed, 'writer':'v628_single_spine_writer', 'build':BUILD_LABEL, 'review_schema':'paper_review_spine_v628_single_spine', 'trigger_gate_schema':'paper_trigger_gate_v628_strict_single_spine'}
    _v628_write_score_review_cache(status)
    try:
        if '_v582_write_spine' in globals():
            _v582_write_spine(status, trace_obj, snapshot, pick_stats, open_pos)
        else:
            save_json(FILES['status'], status); save_json(FILES['trace'], trace_obj); save_json(FILES['handoff_status'], status)
    except Exception as exc:
        log_error('v628_write_spine', exc); save_json(FILES['status'], status)
    for pos in opened_items:
        try: notify_opened(pos)
        except Exception as exc: log_error('v628_notify_opened_call', exc)
    for row in closed_items:
        try: notify_closed(row)
        except Exception as exc: log_error('v628_notify_closed_call', exc)
    try: notify_s1_decision_summary(pick_stats, opened_count=len(opened_items), closed_count=len(closed_items), ctrl=ctrl)
    except Exception as exc: log_error('v628_s1_summary', exc)
    try: notify_market_hot_summary(ctrl)
    except Exception as exc: log_error('v628_hot_summary', exc)
    try: _v628_send_due_hourly_raw_pack()
    except Exception as exc: log_error('v628_hourly_due', exc)
    try: log(f"{VERSION} cycle opened={len(opened_items)} quarantined={len(quarantined_items)} closed={len(closed_items)} open={len(open_pos)} elapsed={status['elapsed_sec']}s writer=v628")
    except Exception: pass
    return status

try:
    _v628_write_score_review_cache({'startup_status': True, 'build': BUILD_LABEL})
except Exception as exc:
    log_error('v628_startup_score_review', exc)


# =============================================================================
# paper_bot v0.223 / v629: review writer owner lock + no-legacy write_status
# - v628에서 run_cycle은 최신이었지만 heartbeat/write_status 경로가 구 writer 체인을 타며
#   paper_bot_trade_review_cache.json을 paper_review_spine_v591로 되돌렸다.
# - v629는 write_status/write_score_cache/run_cycle의 마지막 writer를 모두 같은 v629 writer로 잠그고,
#   write_status는 더 이상 구 write_status 체인을 호출하지 않는다.
# - 조건/S등급/청산/자동매수/장부 삭제 변경 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp


def _v629_reconciled_rows() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    try:
        if '_v607_reconciled_closed_rows' in globals():
            rows, rec = _v607_reconciled_closed_rows()  # type: ignore[name-defined]
            return rows if isinstance(rows, list) else [], rec if isinstance(rec, dict) else {}
    except Exception as exc:
        log_error('v629_reconciled_rows_v607', exc)
    try:
        return read_jsonl_tail(FILES['closed'], 2000), {'source': 'closed_tail_fallback_v629'}
    except Exception as exc:
        log_error('v629_reconciled_rows_tail', exc)
        return [], {'source': 'empty_error_v629'}


def _v629_today_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        if '_v557_filter_today' in globals():
            return _v557_filter_today(rows, now_ts())  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v629_today_filter', exc)
    return rows


def _v629_row_pnl(row: Dict[str, Any]) -> float:
    if '_v628_row_pnl' in globals():
        try: return _v628_row_pnl(row)  # type: ignore[name-defined]
        except Exception: pass
    for k in ('pnl_pct','profit_pct','return_pct','net_pct','pnl'):
        try:
            v=row.get(k) if isinstance(row,dict) else None
            if v not in (None,''):
                return float(str(v).replace(',',''))
        except Exception: pass
    return 0.0


def _v629_row_strategy(row: Dict[str, Any]) -> str:
    if '_v628_row_strategy' in globals():
        try: return _v628_row_strategy(row)  # type: ignore[name-defined]
        except Exception: pass
    if not isinstance(row, dict): return 'unknown'
    for k in ('strategy_label','strategy_name','strategy','strategy_key'):
        if row.get(k): return str(row.get(k))
    snap = row.get('canonical_entry_snapshot') or row.get('entry_snapshot') or row.get('entry_context')
    if isinstance(snap, dict):
        for k in ('strategy_label','strategy_name','strategy','strategy_key'):
            if snap.get(k): return str(snap.get(k))
    return 'unknown'


def _v629_reason_tags(row: Dict[str, Any], win: bool) -> List[str]:
    if '_v628_reason_tags' in globals():
        try: return _v628_reason_tags(row, win)  # type: ignore[name-defined]
        except Exception: pass
    return ['기타/표본']


def _v629_strategy_review_lines(today_rows: List[Dict[str, Any]]) -> Tuple[str, Dict[str, Any]]:
    by: Dict[str, List[Dict[str, Any]]] = {}
    for r in today_rows:
        if isinstance(r, dict):
            by.setdefault(_v629_row_strategy(r), []).append(r)
    lines = ['📊 전략별 승리군/패배군 비교 /trade_review · v629']
    data: Dict[str, Any] = {}
    if not by:
        lines.append('- 오늘 CLOSED 없음')
        return '\n'.join(lines), data
    from collections import Counter
    for strat, rows in sorted(by.items(), key=lambda kv: len(kv[1]), reverse=True):
        wins=[r for r in rows if _v629_row_pnl(r) > 0]
        losses=[r for r in rows if _v629_row_pnl(r) <= 0]
        total=sum(_v629_row_pnl(r) for r in rows)
        avg=total/len(rows) if rows else 0.0
        wc=Counter(); lc=Counter()
        for r in wins: wc.update(_v629_reason_tags(r, True))
        for r in losses: lc.update(_v629_reason_tags(r, False))
        lines.append('')
        lines.append(f'[{strat}]')
        lines.append(f'- 성과: {len(rows)}전 {len(wins)}승 {len(losses)}패 / 승률 {(len(wins)/len(rows)*100.0 if rows else 0):.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%')
        lines.append('- 승리군 공통점: ' + (' / '.join(f'{k} {v}' for k,v in wc.most_common(6)) if wc else '-'))
        lines.append('- 패배군 원인: ' + (' / '.join(f'{k} {v}' for k,v in lc.most_common(8)) if lc else '-'))
        if losses:
            lines.append('- 최근 패배: ' + ' / '.join(f"{r.get('ticker', r.get('symbol','-'))} {_v629_row_pnl(r):+.2f}%" for r in losses[-5:]))
        data[strat]={'total':len(rows),'wins':len(wins),'losses':len(losses),'sum_pct':round(total,4),'avg_pct':round(avg,4),'win_tags':dict(wc),'loss_tags':dict(lc)}
    return '\n'.join(lines), data


def _v629_write_score_review_cache(status: Optional[Dict[str, Any]] = None) -> None:
    rows, rec = _v629_reconciled_rows()
    today = _v629_today_rows(rows)
    try:
        if '_v607_build_score_cache_obj' in globals():
            score = _v607_build_score_cache_obj(rows, status, rec)  # type: ignore[name-defined]
        else:
            score = {'schema':'paper_score_cache_v629_minimal','closed_count':len(rows),'today_closed_count':len(today),'updated_at':now_ts()}
        if isinstance(score, dict):
            score['build'] = BUILD_LABEL
            score['review_schema'] = 'paper_review_spine_v629_writer_owner_lock'
            score['score_review_writer'] = 'v629_writer_owner_lock'
        save_json(FILES['score'], score)
    except Exception as exc:
        log_error('v629_score_write', exc)
    try:
        summary, data = _v629_strategy_review_lines(today)
        recent = ['[오늘 CLOSED 최근]']
        for r in today[-10:]:
            src = '알림원천보강' if r.get('reconciled_from_close_alert_trace') else '장부'
            recent.append(f"- {r.get('ticker', r.get('symbol','-'))} {_v629_row_pnl(r):+.2f}% / {_v629_row_strategy(r)} / {src}")
        if len(recent) == 1:
            recent.append('- 오늘 CLOSED 없음')
        obj = {
            'schema': 'paper_review_spine_v629_writer_owner_lock',
            'version': VERSION,
            'paper_version': VERSION,
            'build': BUILD_LABEL,
            'writer': 'v629_no_legacy_write_status_review_writer',
            'source': 'same_reconciled_rows_as_score_v629',
            'updated_at': now_ts(),
            'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
            'closed_count': len(rows),
            'today_closed_count': len(today),
            'strategy_win_loss_analysis': data,
            'summary_text': summary + '\n\n' + '\n'.join(recent) + '\n\n[source 대조]\n- score/review same CLOSED reconciled rows · 조건/S등급/청산/장부 변경 없음',
            'reconcile': rec if isinstance(rec, dict) else {},
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('v629_review_write', exc)


def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v629_write_score_review_cache(status)


def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    """v629 heartbeat writer: do not call legacy write_status chain that rewrites review cache as v591."""
    try:
        st = dict(status or {})
        st.update({
            'version': VERSION,
            'paper_version': VERSION,
            'build': BUILD_LABEL,
            'review_schema': 'paper_review_spine_v629_writer_owner_lock',
            'score_review_writer': 'v629_no_legacy_write_status',
            'running': bool(st.get('running', True)),
            'process_alive': True,
            'updated_at': now_ts(),
            'updated_at_text': iso_ts(),
            'open_count': len(load_open()),
            'open_total': len(load_open()),
        })
        ctrl = load_control()
        open_pos = load_open()
        rows = _v582_active_rows(ctrl) if '_v582_active_rows' in globals() else []
        try:
            snapshot, pick = _v582_make_snapshot(rows, ctrl, st.get('pick_stats') if isinstance(st.get('pick_stats'), dict) else {}, open_pos) if '_v582_make_snapshot' in globals() else ({'latest_count':len(rows),'merged_fresh':len(rows),'stage_counts':{}}, {})
            trace_obj = _v582_minimal_trace(rows, ctrl, open_pos, 'v629_write_status') if '_v582_minimal_trace' in globals() else {'schema':'paper_trace_v629_minimal','rows':[],'updated_at':now_ts()}
            if '_v582_write_spine' in globals():
                _v582_write_spine(st, trace_obj, snapshot, pick, open_pos)  # type: ignore[name-defined]
            else:
                save_json(FILES['status'], st)
        except Exception as exc:
            log_error('v629_write_status_spine', exc)
            save_json(FILES['status'], st)
        _v629_write_score_review_cache(st)
    except Exception as exc:
        log_error('v629_write_status', exc)


_v629_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v629_prev_run_cycle()
    try:
        if isinstance(st, dict):
            st['build'] = BUILD_LABEL
            st['review_schema'] = 'paper_review_spine_v629_writer_owner_lock'
            st['score_review_writer'] = 'v629_run_cycle_final_writer'
        _v629_write_score_review_cache(st if isinstance(st, dict) else None)
        # Rewrite status through non-legacy writer after v628 run_cycle to prevent later stale metadata.
        if isinstance(st, dict):
            write_status(st)
    except Exception as exc:
        log_error('v629_run_cycle_final_review', exc)
    return st

try:
    _v629_write_score_review_cache({'startup_status': True, 'build': BUILD_LABEL})
except Exception as exc:
    log_error('v629_startup_score_review', exc)



# =============================================================================
# paper_bot v0.230 / v630: review writer hard cut + legacy v591 quarantine
# =============================================================================
# 목적:
# - v591 review writer가 score/review cache를 다시 0건으로 덮는 경로를 실제로 끊는다.
# - 모든 legacy review writer 이름은 v630 writer로만 연결한다.
# - paper OPEN/CLOSED/trade_log 원장, 조건, 청산, S등급은 변경하지 않는다.
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
V630_REVIEW_SCHEMA = 'paper_review_spine_v630_writer_quarantine'


def _v630_log_note(where: str, msg: str) -> None:
    try:
        log_error(where, RuntimeError(msg))
    except Exception:
        pass


def _v630_reconciled_rows() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    try:
        if '_v629_reconciled_rows' in globals():
            return _v629_reconciled_rows()  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v630_reconciled_rows_v629', exc)
    try:
        if '_v628_reconciled_rows' in globals():
            return _v628_reconciled_rows()  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v630_reconciled_rows_v628', exc)
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 2000) if isinstance(r, dict)]
        return rows, {'source': 'closed_tail_v630_fallback', 'ledger_count': len(rows)}
    except Exception as exc:
        log_error('v630_reconciled_rows_tail', exc)
        return [], {'source': 'empty_error_v630'}


def _v630_today_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        if '_v557_filter_today' in globals():
            return _v557_filter_today(rows, now_ts())  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v630_today_filter', exc)
    return rows


def _v630_row_pnl(row: Dict[str, Any]) -> float:
    for fn in ('_v629_row_pnl', '_v628_row_pnl'):
        try:
            if fn in globals():
                return globals()[fn](row)
        except Exception:
            pass
    for k in ('pnl_pct','profit_pct','return_pct','net_pct','pnl'):
        try:
            v = row.get(k) if isinstance(row, dict) else None
            if v not in (None, ''):
                return float(str(v).replace(',', '').replace('%',''))
        except Exception:
            pass
    return 0.0


def _v630_row_strategy(row: Dict[str, Any]) -> str:
    for fn in ('_v629_row_strategy', '_v628_row_strategy'):
        try:
            if fn in globals():
                return globals()[fn](row)
        except Exception:
            pass
    if not isinstance(row, dict):
        return 'unknown'
    for k in ('strategy_label','strategy_name','strategy','strategy_key'):
        if row.get(k):
            return str(row.get(k))
    snap = row.get('canonical_entry_snapshot') or row.get('entry_snapshot') or row.get('entry_context')
    if isinstance(snap, dict):
        for k in ('strategy_label','strategy_name','strategy','strategy_key'):
            if snap.get(k):
                return str(snap.get(k))
    return 'unknown'


def _v630_reason_tags(row: Dict[str, Any], win: bool) -> List[str]:
    for fn in ('_v629_reason_tags', '_v628_reason_tags'):
        try:
            if fn in globals():
                tags = globals()[fn](row, win)
                if tags:
                    return list(tags)
        except Exception:
            pass
    text = ' '.join(str(row.get(k,'')) for k in ('exit_reason','close_review_tag','review_tag','trigger_state','entry_timing_note'))
    tags: List[str] = []
    if 'trigger_not_reached' in text or '방아쇠' in text:
        tags.append('방아쇠/진입타이밍 확인')
    if '빠른실패' in text or '무반응' in text:
        tags.append('진입후무반응/빠른실패')
    if '보호' in text:
        tags.append('보호익절/반납')
    if not tags:
        tags.append('기타/표본')
    return tags


def _v630_strategy_review_lines(today_rows: List[Dict[str, Any]]) -> Tuple[str, Dict[str, Any]]:
    by: Dict[str, List[Dict[str, Any]]] = {}
    for r in today_rows:
        if isinstance(r, dict):
            by.setdefault(_v630_row_strategy(r), []).append(r)
    lines = ['📊 전략별 승리군/패배군 비교 /trade_review · v630']
    data: Dict[str, Any] = {}
    if not by:
        lines.append('- 오늘 CLOSED 없음')
        return '\n'.join(lines), data
    from collections import Counter
    for strat, rows in sorted(by.items(), key=lambda kv: len(kv[1]), reverse=True):
        wins = [r for r in rows if _v630_row_pnl(r) > 0]
        losses = [r for r in rows if _v630_row_pnl(r) <= 0]
        total = sum(_v630_row_pnl(r) for r in rows)
        avg = total / len(rows) if rows else 0.0
        wc = Counter(); lc = Counter()
        for r in wins: wc.update(_v630_reason_tags(r, True))
        for r in losses: lc.update(_v630_reason_tags(r, False))
        lines.append('')
        lines.append(f'[{strat}]')
        lines.append(f'- 성과: {len(rows)}전 {len(wins)}승 {len(losses)}패 / 승률 {(len(wins)/len(rows)*100.0 if rows else 0):.1f}% / 합산 {total:+.2f}% / 평균 {avg:+.2f}%')
        lines.append('- 승리군 공통점: ' + (' / '.join(f'{k} {v}' for k, v in wc.most_common(6)) if wc else '-'))
        lines.append('- 패배군 원인: ' + (' / '.join(f'{k} {v}' for k, v in lc.most_common(8)) if lc else '-'))
        if losses:
            lines.append('- 최근 패배: ' + ' / '.join(f"{r.get('ticker', r.get('symbol','-'))} {_v630_row_pnl(r):+.2f}%" for r in losses[-5:]))
        data[strat] = {
            'total': len(rows), 'wins': len(wins), 'losses': len(losses),
            'sum_pct': round(total, 4), 'avg_pct': round(avg, 4),
            'win_tags': dict(wc), 'loss_tags': dict(lc),
        }
    return '\n'.join(lines), data


def _v630_build_review_cache(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    rows, rec = _v630_reconciled_rows()
    today = _v630_today_rows(rows)
    summary, data = _v630_strategy_review_lines(today)
    recent = ['[오늘 CLOSED 최근]']
    for r in today[-10:]:
        src = '알림원천보강' if isinstance(r, dict) and r.get('reconciled_from_close_alert_trace') else '장부'
        recent.append(f"- {r.get('ticker', r.get('symbol','-'))} {_v630_row_pnl(r):+.2f}% / {_v630_row_strategy(r)} / {src}")
    if len(recent) == 1:
        recent.append('- 오늘 CLOSED 없음')
    return {
        'schema': V630_REVIEW_SCHEMA,
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v630_legacy_v591_quarantine_writer',
        'source': 'same_reconciled_rows_as_score_v630',
        'updated_at': now_ts(),
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'closed_count': len(rows),
        'today_closed_count': len(today),
        'strategy_win_loss_analysis': data,
        'summary_text': summary + '\n\n' + '\n'.join(recent) + '\n\n[source 대조]\n- score/review same CLOSED reconciled rows · v591 writer quarantined · 조건/S등급/청산/장부 변경 없음',
        'reconcile': rec if isinstance(rec, dict) else {},
        'legacy_v591_quarantined': True,
    }



def _v741_closed_ts(row: Dict[str, Any]) -> float:
    if not isinstance(row, dict):
        return 0.0
    return fnum(
        row.get("closed_at"), row.get("closed_ts"), row.get("exit_ts"), row.get("closed_time"),
        row.get("updated_at"), row.get("ts"), row.get("timestamp"),
        default=0.0,
    )


def _v741_recent_rows(rows: List[Dict[str, Any]], hours: float) -> List[Dict[str, Any]]:
    cutoff = now_ts() - float(hours) * 3600.0
    return [r for r in (rows or []) if isinstance(r, dict) and _v741_closed_ts(r) >= cutoff]


def _v741_reseal_score_windows(score: Dict[str, Any], rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(score, dict):
        score = {}
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    for hours in (3, 6, 24):
        recent = _v741_recent_rows(rows, float(hours))
        stat = _score_stat(recent)
        score[f"recent_{hours}h_stats"] = stat
        score[f"last_{hours}h_stats"] = stat
        score[f"rolling_{hours}h_stats"] = stat
        score[f"stats_{hours}h"] = stat
        score[f"recent_{hours}h"] = {"global": stat, "source": "same_reconciled_closed_rows_v741"}
    score["score_window_source_v741"] = "same_reconciled_rows_as_score_review"
    score["score_window_resealed_at_v741"] = now_ts()
    return score



# =============================================================================
# paper_bot v0.748: classify board cache owner
# - 분류표는 paper_bot이 CLOSED tail/cache 기준으로 생성한다.
# - main_bot /classify는 이 cache만 읽는다.
# - 조건/청산값 변경 없음.
# =============================================================================
def _v747_closed_bucket(row: Dict[str, Any]) -> str:
    pnl = fnum(row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)
    reason = str(row.get('exit_reason') or row.get('exit_rule') or row.get('close_reason') or '').lower()
    if pnl >= 2.0:
        return 'big_profit'
    if pnl > 0:
        return 'normal_profit'
    if 'fast_fail' in reason or '빠른실패' in reason:
        return 'fast_fail'
    if 'time' in reason or '시간' in reason:
        return 'time_exit'
    if 'stop' in reason or pnl <= -0.50:
        return 'stop_loss'
    return 'other_loss'


def _v747_stat_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    return _score_stat([r for r in (rows or []) if isinstance(r, dict)])


def _v747_bucket_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    buckets: Dict[str, List[Dict[str, Any]]] = {k: [] for k in ('big_profit','normal_profit','stop_loss','fast_fail','time_exit','other_loss')}
    for r in rows or []:
        if isinstance(r, dict):
            buckets.setdefault(_v747_closed_bucket(r), []).append(r)
    return {k: _v747_stat_rows(v) for k, v in buckets.items()}


def _v747_pick_num(*vals: Any) -> Tuple[bool, float]:
    """값 없음과 0.0을 구분한다. classify 과분류 방지용."""
    for v in vals:
        if v is None:
            continue
        if isinstance(v, str) and not v.strip():
            continue
        try:
            x = fnum(v, default=None)  # type: ignore[arg-type]
        except Exception:
            x = None
        if x is not None:
            return True, float(x)
    return False, 0.0


def _v747_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    snap = row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}
    mat = snap.get('materials') if isinstance(snap.get('materials'), dict) else {}
    ctx = snap.get('entry_context') if isinstance(snap.get('entry_context'), dict) else {}
    return raw, snap, mat, ctx


def _v747_reaction_info(row: Dict[str, Any]) -> Tuple[bool, float]:
    raw, snap, mat, ctx = _v747_nested(row)
    return _v747_pick_num(
        row.get('entry_price_reaction_pct'), row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'),
        raw.get('entry_price_reaction_pct'), raw.get('price_reaction_pct'), raw.get('change_1m_pct'), raw.get('price_chg_60s'),
        mat.get('price_reaction_pct'), mat.get('change_1m_pct'), mat.get('price_chg_60s'),
        ctx.get('price_reaction_pct'), ctx.get('change_1m_pct'), ctx.get('price_chg_60s'),
    )


def _v747_reaction_pct(row: Dict[str, Any]) -> float:
    return _v747_reaction_info(row)[1]


def _v747_timing_age(row: Dict[str, Any]) -> float:
    snap = row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}
    timing = snap.get('timing_spine') if isinstance(snap.get('timing_spine'), dict) else {}
    vals = [
        row.get('entry_age_sec'), row.get('candidate_age_sec'), row.get('first_to_now_delay_sec'), row.get('s2_to_now_delay_sec'),
        timing.get('first_to_now_delay_sec'), timing.get('s2_to_now_delay_sec'), timing.get('first_to_s1_delay_sec'),
    ]
    nums = []
    for v in vals:
        ok, x = _v747_pick_num(v)
        if ok:
            nums.append(x)
    return max(nums or [0.0])


def _v751_source_age_for_closed(row: Dict[str, Any]) -> float:
    raw, snap, mat, ctx = _v747_nested(row)
    ok, ts = _v747_pick_num(
        row.get('candidate_created_at'), row.get('source_created_at'), row.get('event_ts'), row.get('detected_ts'), row.get('created_at'), row.get('entry_ts'), row.get('opened_at'),
        raw.get('candidate_created_at'), raw.get('source_created_at'), raw.get('event_ts'), raw.get('detected_ts'), raw.get('created_at'),
        snap.get('candidate_created_at'), snap.get('source_created_at'), snap.get('event_ts'), snap.get('detected_ts'), snap.get('created_at'),
        ctx.get('candidate_created_at'), ctx.get('source_created_at'), ctx.get('event_ts'), ctx.get('detected_ts'), ctx.get('created_at'),
    )
    if not ok or ts <= 0:
        return 999999.0
    base_ts = fnum(row.get('entry_ts'), row.get('opened_at'), row.get('created_at'), default=0.0) or now_ts()
    return max(0.0, base_ts - ts)


def _v751_timing_contaminated(row: Dict[str, Any]) -> bool:
    return _v747_timing_age(row) >= 600 and _v751_source_age_for_closed(row) <= 300


def _v747_target_price(row: Dict[str, Any]) -> float:
    return _v747_target_info(row)[1]


def _v747_target_info(row: Dict[str, Any]) -> Tuple[bool, float]:
    raw, snap, mat, ctx = _v747_nested(row)
    plan = snap.get('entry_plan') if isinstance(snap.get('entry_plan'), dict) else {}
    return _v747_pick_num(
        row.get('target_price'), row.get('target1'), row.get('take_profit_price'), row.get('tp1'),
        raw.get('target_price'), raw.get('target1'), raw.get('take_profit_price'), raw.get('tp1'),
        mat.get('target_price'), mat.get('target1'), mat.get('take_profit_price'), mat.get('tp1'),
        ctx.get('target_price'), ctx.get('target1'), ctx.get('take_profit_price'), ctx.get('tp1'),
        plan.get('target_price'), plan.get('target1'), plan.get('take_profit_price'), plan.get('tp1'),
    )


def _v747_entry_price(row: Dict[str, Any]) -> float:
    return fnum(row.get('entry_price'), row.get('open_price'), row.get('buy_price'), row.get('price'), default=0.0)


def _v747_trigger_gap(row: Dict[str, Any]) -> float:
    raw, snap, mat, ctx = _v747_nested(row)
    ok, gap = _v747_pick_num(row.get('trigger_gap_pct'), raw.get('trigger_gap_pct'), row.get('entry_trigger_gap_pct'), ctx.get('trigger_gap_pct'))
    if ok:
        return gap
    entry = _v747_entry_price(row)
    trig_ok, trig = _v747_pick_num(row.get('trigger_price'), raw.get('trigger_price'), ctx.get('trigger_price'))
    if entry > 0 and trig_ok and trig > 0:
        return ((entry - trig) / trig) * 100.0
    return 0.0


def _v747_stop_info(row: Dict[str, Any]) -> Tuple[bool, float]:
    raw, snap, mat, ctx = _v747_nested(row)
    plan = snap.get('entry_plan') if isinstance(snap.get('entry_plan'), dict) else {}
    return _v747_pick_num(
        row.get('invalid_price'), row.get('stop_price'), row.get('stop_loss_price'), row.get('loss_cut_price'),
        raw.get('invalid_price'), raw.get('stop_price'), raw.get('stop_loss_price'), raw.get('loss_cut_price'),
        mat.get('invalid_price'), mat.get('stop_price'), mat.get('stop_loss_price'), mat.get('loss_cut_price'),
        ctx.get('invalid_price'), ctx.get('stop_price'), ctx.get('stop_loss_price'), ctx.get('loss_cut_price'),
        plan.get('invalid_price'), plan.get('stop_price'), plan.get('stop_loss_price'), plan.get('loss_cut_price'),
    )


def _v747_rr_info(row: Dict[str, Any]) -> Tuple[bool, float, str]:
    raw, snap, mat, ctx = _v747_nested(row)
    ok, rr = _v747_pick_num(
        row.get('rr'), row.get('rr_ratio'), row.get('risk_reward'), row.get('risk_reward_ratio'),
        raw.get('rr'), raw.get('rr_ratio'), raw.get('risk_reward'), raw.get('risk_reward_ratio'),
        mat.get('rr'), mat.get('rr_ratio'), mat.get('risk_reward'), mat.get('risk_reward_ratio'),
        ctx.get('rr'), ctx.get('rr_ratio'), ctx.get('risk_reward'), ctx.get('risk_reward_ratio'),
    )
    if ok:
        return True, rr, 'explicit'
    entry = _v747_entry_price(row)
    tok, target = _v747_target_info(row)
    sok, stop = _v747_stop_info(row)
    if entry > 0 and tok and sok:
        reward = target - entry
        risk = entry - stop
        if risk > 0 and reward > 0:
            return True, reward / risk, 'calculated'
    return False, 0.0, 'missing'


def _v747_rr(row: Dict[str, Any]) -> float:
    return _v747_rr_info(row)[1]


def _v747_candle_age(row: Dict[str, Any]) -> float:
    raw, snap, mat, ctx = _v747_nested(row)
    osi = row.get('official_structure_inputs_raw') if isinstance(row.get('official_structure_inputs_raw'), dict) else {}
    return fnum(
        row.get('official_candle_age'), raw.get('official_candle_age'), osi.get('official_candle_age'),
        mat.get('official_candle_age'), ctx.get('official_candle_age'), default=0.0,
    )


def _v747_entry_quality(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    c: Counter = Counter()
    examples: Dict[str, List[str]] = {}
    def mark(key: str, row: Dict[str, Any]) -> None:
        c[key] += 1
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(row.get('ticker') or row.get('symbol') or '-'))
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        age = _v747_timing_age(r)
        source_age = _v751_source_age_for_closed(r)
        if age >= 600 and source_age <= 300:
            mark('timing_field_contaminated', r)
        elif age >= 600:
            mark('old_candidate_entry', r)
        if source_age >= 300 and source_age < 999999:
            mark('old_source_entry', r)
        entry = _v747_entry_price(r)
        tok, target = _v747_target_info(r)
        if entry > 0 and tok and target > 0 and entry >= target * 0.995:
            mark('target_near_or_above_entry', r)
        if _v747_trigger_gap(r) >= 0.60:
            mark('trigger_gap_high', r)
        rr_ok, rr, rr_src = _v747_rr_info(r)
        if rr_ok:
            if rr < 1.20:
                mark('rr_bad_or_missing', r)   # 기존 분류키 유지: 실제 bad만 카운트
                mark('rr_bad', r)
            if rr_src == 'calculated':
                mark('rr_calculated', r)
        else:
            mark('rr_missing', r)
        reac_ok, reac = _v747_reaction_info(r)
        if reac_ok:
            if reac < 0.15:
                mark('reaction_off_before_entry', r)  # 기존 분류키 유지: 실제 반응꺼짐만 카운트
                mark('reaction_off', r)
        else:
            mark('reaction_missing', r)
        ca = _v747_candle_age(r)
        if ca >= 120:
            mark('official_candle_stale_120s', r)
        elif ca <= 0:
            # 구조재료가 아예 없는 케이스. 조건값 변경은 아니고 분류만 한다.
            mark('official_candle_missing', r)
    out = dict(c)
    out['top'] = dict(c.most_common(12))
    out['examples'] = examples
    out['precision_policy_v750'] = 'missing values are separated; timing contamination and candle stale are classified separately; old timing does not equal old candidate without source-age proof'
    return out


def _v749_loss_split(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """최근 손실군을 전략/진입품질/구조 stale로 한 번에 분해한다."""
    loss_rows = [r for r in (rows or []) if isinstance(r, dict) and _v747_closed_bucket(r) in ('stop_loss', 'fast_fail', 'time_exit', 'other_loss')]
    strategy = Counter()
    issues = Counter()
    examples: Dict[str, List[str]] = {}
    def ex(key: str, row: Dict[str, Any]) -> None:
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(row.get('ticker') or row.get('symbol') or '-'))
    for r in loss_rows:
        sk = str(r.get('strategy') or r.get('strategy_label') or r.get('paper_strategy_key') or r.get('strategy_key') or 'unknown')
        strategy[sk] += 1
        if _v751_timing_contaminated(r):
            issues['timing필드오염'] += 1; ex('timing필드오염', r)
        elif _v747_timing_age(r) >= 600:
            issues['오래된후보진입'] += 1; ex('오래된후보진입', r)
        entry = _v747_entry_price(r)
        tok, target = _v747_target_info(r)
        if entry > 0 and tok and target > 0 and entry >= target * 0.995:
            issues['목표근처진입'] += 1; ex('목표근처진입', r)
        if _v747_trigger_gap(r) >= 0.60:
            issues['방아쇠gap과다'] += 1; ex('방아쇠gap과다', r)
        rr_ok, rr, _ = _v747_rr_info(r)
        if rr_ok and rr < 1.20:
            issues['RR불량'] += 1; ex('RR불량', r)
        elif not rr_ok:
            issues['RR확인불가'] += 1; ex('RR확인불가', r)
        reac_ok, reac = _v747_reaction_info(r)
        if reac_ok and reac < 0.15:
            issues['진입직전반응꺼짐'] += 1; ex('진입직전반응꺼짐', r)
        elif not reac_ok:
            issues['진입반응확인불가'] += 1; ex('진입반응확인불가', r)
        ca = _v747_candle_age(r)
        if ca >= 120:
            issues['공식캔들stale'] += 1; ex('공식캔들stale', r)
        elif ca <= 0:
            issues['공식캔들없음'] += 1; ex('공식캔들없음', r)
    return {
        'n': len(loss_rows),
        'strategy_top': dict(strategy.most_common(10)),
        'issue_top': dict(issues.most_common(12)),
        'examples': examples,
    }

def _v747_exit_issue_trace() -> Dict[str, Any]:
    c: Counter = Counter()
    rows = read_jsonl_tail(BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl', 160)
    for r in rows:
        if not isinstance(r, dict):
            continue
        c['손절초과'] += 1
        if fnum(r.get('position_update_gap_sec'), default=0.0) >= 10:
            c['loopgap 의심'] += 1
        if fnum(r.get('price_cache_age_sec'), default=0.0) >= 10:
            c['가격조회 지연'] += 1
    return {'tail_count': len(rows), 'top': dict(c.most_common(10))}


def _v747_lifecycle_from_status(status: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    c: Counter = Counter()
    if isinstance(status, dict):
        ht = status.get('hold_trace_summary_v746') if isinstance(status.get('hold_trace_summary_v746'), dict) else {}
        counts = ht.get('status_counts') if isinstance(ht.get('status_counts'), dict) else {}
        tail = counts.get('tail') if isinstance(counts.get('tail'), dict) else {}
        for k, v in tail.items():
            c[str(k)] += int(v or 0)
        pre = ht.get('preopen_guard_top') if isinstance(ht.get('preopen_guard_top'), dict) else {}
        last5 = pre.get('last5m') if isinstance(pre.get('last5m'), dict) else {}
        for k, v in last5.items():
            c[f'OPEN직전:{k}'] += int(v or 0)
    return {'top': dict(c.most_common(10))}


def _v747_build_classify_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    r3 = _v741_recent_rows(rows, 3.0)
    r6 = _v741_recent_rows(rows, 6.0)
    r24 = _v741_recent_rows(rows, 24.0)
    return {
        'schema': 'paper_classify_board_v754',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'source': 'paper_bot_reconciled_closed_tail_plus_status_trace_cache_only',
        'policy': 'classification board is persistent; add new categories here instead of deleting/recreating scattered panels',
        'performance_breakdown': {
            'recent_3h': {'global': _v747_stat_rows(r3), 'buckets': _v747_bucket_stats(r3)},
            'recent_6h': {'global': _v747_stat_rows(r6), 'buckets': _v747_bucket_stats(r6)},
            'recent_24h': {'global': _v747_stat_rows(r24), 'buckets': _v747_bucket_stats(r24)},
        },
        'entry_quality': _v747_entry_quality(r24),
        'loss_split': {
            'recent_3h': _v749_loss_split(r3),
            'recent_6h': _v749_loss_split(r6),
            'recent_24h': _v749_loss_split(r24),
        },
        'exit_issues': _v747_exit_issue_trace(),
        'lifecycle': _v747_lifecycle_from_status(status),
        'notes': ['성과분해', '진입품질', '청산문제', '후보생애주기', 'worker age는 main_bot /classify에서 합성 표시', 'v754: pre-main active entry_snapshot spine; legacy rows separated from missing materials'],
    }

def _v630_write_score_review_cache(status: Optional[Dict[str, Any]] = None) -> None:
    rows, rec = _v630_reconciled_rows()
    today = _v630_today_rows(rows)
    try:
        if '_v607_build_score_cache_obj' in globals():
            score = _v607_build_score_cache_obj(rows, status, rec)  # type: ignore[name-defined]
        else:
            score = {'schema': 'paper_score_cache_v630_minimal', 'closed_count': len(rows), 'today_closed_count': len(today), 'updated_at': now_ts()}
        if isinstance(score, dict):
            score['build'] = BUILD_LABEL
            score['review_schema'] = V630_REVIEW_SCHEMA
            score['score_review_writer'] = 'v741_open_spine_score_window_owner'
            score['review_today_closed_count'] = len(today)
            score = _v741_reseal_score_windows(score, rows)
        save_json(FILES['score'], score)
    except Exception as exc:
        log_error('v630_score_write', exc)
    try:
        save_json(FILES['trade_review'], _v630_build_review_cache(status))
    except Exception as exc:
        log_error('v630_review_write', exc)
    try:
        save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
    except Exception as exc:
        log_error('v747_classify_cache_write', exc)


# 핵심: v591 이름 자체를 v630 writer로 격리한다. 구 wrapper가 이 이름을 불러도 v591 cache를 쓸 수 없다.
def _v591_build_paper_review_spine(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    return _v630_build_review_cache(status)


def write_paper_review_spine_cache_v591(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v630_write_score_review_cache(status)


for _name in (
    'write_trade_review_cache_v569', 'write_trade_review_cache_v570', 'write_trade_review_cache_v572',
    'write_trade_review_cache_v578', 'write_trade_review_cache_v588', 'write_trade_review_cache_v589',
    'write_trade_review_cache_v590', 'write_trade_review_cache_v621', 'write_trade_review_cache_v622',
    'write_trade_review_cache_v623', 'write_trade_review_cache_v626', 'write_trade_review_cache_v627',
    'write_trade_review_cache_v628', 'write_trade_review_cache_v629',
):
    globals()[_name] = write_paper_review_spine_cache_v591


def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v630_write_score_review_cache(status)


def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    """v630 heartbeat writer: no legacy write_status chain, no v591 review writer."""
    try:
        st = dict(status or {})
        st.update({
            'version': VERSION,
            'paper_version': VERSION,
            'build': BUILD_LABEL,
            'review_schema': V630_REVIEW_SCHEMA,
            'score_review_writer': 'v630_write_status_no_legacy',
            'legacy_v591_quarantined': True,
            'running': bool(st.get('running', True)),
            'process_alive': True,
            'updated_at': now_ts(),
            'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
            'open_count': len(load_open()),
            'open_total': len(load_open()),
        })
        try:
            ctrl = load_control()
            open_pos = load_open()
            rows = _v582_active_rows(ctrl) if '_v582_active_rows' in globals() else []
            if '_v582_make_snapshot' in globals() and '_v582_minimal_trace' in globals() and '_v582_write_spine' in globals():
                snapshot, pick = _v582_make_snapshot(rows, ctrl, st.get('pick_stats') if isinstance(st.get('pick_stats'), dict) else {}, open_pos)  # type: ignore[name-defined]
                trace_obj = _v582_minimal_trace(rows, ctrl, open_pos, 'v630_write_status')  # type: ignore[name-defined]
                _v582_write_spine(st, trace_obj, snapshot, pick, open_pos)  # type: ignore[name-defined]
            else:
                save_json(FILES['status'], st)
        except Exception as exc:
            log_error('v630_write_status_spine', exc)
            save_json(FILES['status'], st)
        _v630_write_score_review_cache(st)
    except Exception as exc:
        log_error('v630_write_status', exc)


_v630_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v630_prev_run_cycle()
    try:
        if isinstance(st, dict):
            st['build'] = BUILD_LABEL
            st['review_schema'] = V630_REVIEW_SCHEMA
            st['score_review_writer'] = 'v630_run_cycle_final_writer'
            st['legacy_v591_quarantined'] = True
        _v630_write_score_review_cache(st if isinstance(st, dict) else None)
        if isinstance(st, dict):
            write_status(st)
    except Exception as exc:
        log_error('v630_run_cycle_final_review', exc)
    return st


try:
    _v630_write_score_review_cache({'startup_status': True, 'build': BUILD_LABEL, 'legacy_v591_quarantined': True})
except Exception as exc:
    log_error('v630_startup_score_review', exc)



# =============================================================================
# paper_bot v0.224 / v631: paper 1시간 요약 txt 전송 + 서버삭제 + trace 단일 본선
# - 주인 공장: paper_bot. OPEN/CLOSED/후보선별 상태를 1시간 단위 txt로 묶어 Telegram sendDocument 전송.
# - 전송 성공 시 임시 txt는 즉시 삭제한다. 실패 시 원인 확인용 latest txt 1개만 남긴다.
# - 조건/S1·S2·S3/청산/장부/자동매수 변경 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
FILES.setdefault('hourly_summary_trace', BASE_DIR / 'paper_bot_hourly_summary_trace.json')
FILES.setdefault('hourly_summary_tmp', BASE_DIR / 'paper_bot_latest_hourly_summary.txt')

_V631_HOURLY_SCHEMA = 'paper_hourly_summary_v631_file_send_delete'
_V631_HOURLY_BUCKET: Dict[str, Any] = {}


def _v631_trim_text(s: Any, limit: int = 5000) -> str:
    txt = str(s or '').strip()
    if len(txt) <= limit:
        return txt
    return txt[:limit] + '\n…(1시간 요약집에서 일부 절단)'


def _v631_bucket_reset(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    obj = {
        'start_ts': ts,
        'start_text': iso_ts(ts),
        'cycles': 0,
        's1_seen': 0,
        'selected_s1': 0,
        'paper_entry_hold': 0,
        'paper_final_block': 0,
        'micro_preopen_wait': 0,
        'opened': 0,
        'closed': 0,
        'latest_count_max': 0,
        'fresh_count_max': 0,
        'last_s1_seen': None,
        'last_paper_entry_hold': None,
        'last_open_try': None,
        'last_skip': None,
    }
    _V631_HOURLY_BUCKET.clear()
    _V631_HOURLY_BUCKET.update(obj)
    return _V631_HOURLY_BUCKET


def _v631_bucket() -> Dict[str, Any]:
    if not isinstance(_V631_HOURLY_BUCKET, dict) or not _V631_HOURLY_BUCKET.get('start_ts'):
        return _v631_bucket_reset(now_ts())
    return _V631_HOURLY_BUCKET


def _v631_pick_int(pick: Dict[str, Any], *keys: str) -> int:
    for k in keys:
        if k in pick:
            return int(fnum(pick.get(k), default=0.0))
    return 0


def _v631_bucket_collect(status: Dict[str, Any]) -> Dict[str, Any]:
    b = _v631_bucket()
    pick = status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {}
    b['cycles'] = int(b.get('cycles') or 0) + 1
    b['s1_seen'] = int(b.get('s1_seen') or 0) + _v631_pick_int(pick, 's1_seen')
    b['selected_s1'] = int(b.get('selected_s1') or 0) + _v631_pick_int(pick, 'selected_s1')
    hold = _v631_pick_int(pick, 'paper_entry_hold', 'paper_final_block')
    b['paper_entry_hold'] = int(b.get('paper_entry_hold') or 0) + hold
    b['paper_final_block'] = int(b.get('paper_final_block') or 0) + _v631_pick_int(pick, 'paper_final_block')
    b['micro_preopen_wait'] = int(b.get('micro_preopen_wait') or 0) + _v631_pick_int(pick, 'micro_preopen_wait')
    b['opened'] = int(b.get('opened') or 0) + int(fnum(status.get('opened_this_cycle'), default=0.0))
    b['closed'] = int(b.get('closed') or 0) + int(fnum(status.get('closed_this_cycle'), default=0.0))
    b['latest_count_max'] = max(int(b.get('latest_count_max') or 0), int(fnum(pick.get('latest_count', status.get('latest_count')), default=0.0)))
    b['fresh_count_max'] = max(int(b.get('fresh_count_max') or 0), int(fnum(pick.get('merged_fresh', status.get('merged_fresh')), default=0.0)))
    for src_key, dst_key in (('last_s1_seen','last_s1_seen'), ('last_paper_entry_hold','last_paper_entry_hold'), ('last_paper_final_block','last_paper_entry_hold'), ('last_open_try','last_open_try'), ('last_skip','last_skip')):
        obj = pick.get(src_key)
        if isinstance(obj, dict):
            b[dst_key] = obj
    return b


def _v631_row_ts(row: Dict[str, Any]) -> float:
    for k in ('closed_at', 'close_ts', 'closed_ts', 'exit_ts', 'updated_at', 'ts', 'time'):
        v = row.get(k)
        if isinstance(v, (int, float)) and v > 1_000_000_000:
            return float(v)
        if isinstance(v, str):
            try:
                return float(v)
            except Exception:
                pass
    return 0.0


def _v631_recent_closed_rows(hours: float = 1.0, max_lines: int = 800) -> List[Dict[str, Any]]:
    cutoff = now_ts() - max(0.2, hours) * 3600.0
    rows: List[Dict[str, Any]] = []
    try:
        if not FILES['closed'].exists():
            return []
        lines = FILES['closed'].read_text(encoding='utf-8', errors='ignore').splitlines()[-max_lines:]
        for line in lines:
            try:
                obj = json.loads(line)
            except Exception:
                continue
            if not isinstance(obj, dict):
                continue
            ts = _v631_row_ts(obj)
            if ts and ts >= cutoff:
                rows.append(obj)
    except Exception as exc:
        log_error('v631_recent_closed_rows', exc)
    return rows[-80:]


def _v631_row_pnl(row: Dict[str, Any]) -> float:
    return fnum(row.get('net_pct'), row.get('pnl_pct'), row.get('profit_pct'), row.get('return_pct'), default=0.0)


def _v631_row_strategy(row: Dict[str, Any]) -> str:
    return str(row.get('strategy_label') or row.get('strategy') or row.get('strategy_key') or '미분류')


def _v631_closed_lines(rows: List[Dict[str, Any]], limit: int = 20) -> List[str]:
    if not rows:
        return ['- 최근 1시간 CLOSED 없음']
    out: List[str] = []
    total = sum(_v631_row_pnl(r) for r in rows)
    wins = sum(1 for r in rows if _v631_row_pnl(r) > 0)
    out.append(f"- 최근 1시간 CLOSED {len(rows)}전 / {wins}승 {len(rows)-wins}패 / 합산 {total:+.2f}% / 평균 {(total/len(rows)):+.2f}%")
    for r in rows[-limit:]:
        t = str(r.get('ticker') or r.get('symbol') or '-').replace('KRW-','').replace('_KRW','')
        reason = str(r.get('exit_reason') or r.get('exit_rule_label') or r.get('reason') or '-')
        out.append(f"- {t} {_v631_row_pnl(r):+.2f}% / {_v631_row_strategy(r)} / {reason}")
    return out


def _v631_open_lines(limit: int = 20) -> List[str]:
    try:
        rows = list(load_open().values())
    except Exception:
        rows = []
    if not rows:
        return ['- 현재 OPEN 없음']
    out = [f'- 현재 OPEN {len(rows)}개']
    for r in rows[:limit]:
        if not isinstance(r, dict):
            continue
        t = str(r.get('ticker') or r.get('symbol') or '-').replace('KRW-','').replace('_KRW','')
        entry = fmt_price(r.get('entry_price'))
        out.append(f"- {t} / 진입 {entry} / {_v631_row_strategy(r)} / {r.get('candidate_grade', r.get('grade','S1'))}")
    return out


def _v631_short_decision(obj: Any, label: str) -> str:
    if not isinstance(obj, dict):
        return f'- {label}: -'
    t = str(obj.get('ticker') or obj.get('symbol') or '-').replace('KRW-','').replace('_KRW','')
    reason = str(obj.get('reason') or obj.get('block_reason') or obj.get('status') or '-')[:160]
    return f'- {label}: {t} / {reason}'


def _v631_build_hourly_summary_text(status: Dict[str, Any], bucket: Dict[str, Any], closed_rows: List[Dict[str, Any]]) -> str:
    start_ts = fnum(bucket.get('start_ts'), default=now_ts())
    elapsed_min = max(1, int(round((now_ts() - start_ts) / 60.0)))
    pick = status.get('pick_stats') if isinstance(status.get('pick_stats'), dict) else {}
    sections: List[str] = [
        'paper 매매 1시간 요약집 v631',
        f'- 생성: {iso_ts()}',
        f'- 기간: {bucket.get("start_text") or iso_ts(start_ts)} ~ {iso_ts()} / 약 {elapsed_min}분',
        f'- paper: {VERSION} / {BUILD_LABEL}',
        '',
        '[1시간 집계]',
        f"- cycle {bucket.get('cycles',0)} / S1감지 {bucket.get('s1_seen',0)} / 선택 {bucket.get('selected_s1',0)} / OPEN보류 {bucket.get('paper_entry_hold',0)} / micro대기 {bucket.get('micro_preopen_wait',0)}",
        f"- OPEN {bucket.get('opened',0)} / CLOSED {bucket.get('closed',0)} / 후보 max latest {bucket.get('latest_count_max',0)} / fresh {bucket.get('fresh_count_max',0)}",
        _v631_short_decision(bucket.get('last_paper_entry_hold'), '마지막 OPEN보류'),
        _v631_short_decision(bucket.get('last_open_try'), '마지막 OPEN시도'),
        _v631_short_decision(bucket.get('last_s1_seen'), '마지막 S1감지'),
        '',
        '[현재 OPEN]',
        *_v631_open_lines(),
        '',
        '[최근 1시간 CLOSED]',
        *_v631_closed_lines(closed_rows),
        '',
        '[paper 상태 /pstatus]',
        _v631_trim_text(pstatus_text() if 'pstatus_text' in globals() else '', 4500),
        '',
        '[시장 hot-rank 요약]',
        _v631_trim_text(hot_summary_text() if 'hot_summary_text' in globals() else '', 3500),
        '',
        '[후보 요약]',
        _v631_trim_text(candidate_summary_text() if 'candidate_summary_text' in globals() else '', 3500),
    ]
    try:
        review = load_json(FILES['trade_review'], {}) or {}
        rv = str(review.get('summary_text') or '').strip()
        if rv:
            sections += ['', '[전략 승리군/패배군 요약]', _v631_trim_text(rv, 6000)]
    except Exception as exc:
        log_error('v631_hourly_review_section', exc)
    sections += ['', '[trace]', '- 전송 성공 시 이 txt는 서버에서 즉시 삭제됩니다.', '- 조건/S등급/청산/자동매수/장부 변경 없음.']
    return '\n'.join(sections)


def _v631_send_document_file(path: Path, filename: str, caption: str) -> Tuple[bool, str]:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return False, 'telegram_disabled: TOKEN or NOTIFY_CHAT_ID missing'
    try:
        boundary = '----coinbotpaperhourlyv631%08x' % int(now_ts())
        chunks: List[bytes] = []
        def field(name: str, value: str) -> None:
            chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8'))
        field('chat_id', str(NOTIFY_CHAT_ID))
        field('caption', caption[:1000])
        field('disable_web_page_preview', 'true')
        data = path.read_bytes()
        chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n').encode('utf-8'))
        chunks.append(data)
        chunks.append(f'\r\n--{boundary}--\r\n'.encode('utf-8'))
        body = b''.join(chunks)
        req = urllib.request.Request(
            f'https://api.telegram.org/bot{TOKEN}/sendDocument',
            data=body,
            headers={'Content-Type': f'multipart/form-data; boundary={boundary}'},
        )
        urllib.request.urlopen(req, timeout=20).read()
        return True, ''
    except Exception as exc:
        log_error('v631_send_hourly_document', exc)
        return False, f'{type(exc).__name__}: {exc}'


def _v631_save_hourly_trace(trace: Dict[str, Any]) -> None:
    try:
        save_json(FILES['hourly_summary_trace'], trace)
    except Exception as exc:
        log_error('v631_save_hourly_trace', exc)
    try:
        st = load_json(FILES['status'], {}) or {}
        if isinstance(st, dict):
            st['version'] = VERSION
            st['paper_version'] = VERSION
            st['build'] = BUILD_LABEL
            st['paper_hourly_summary_trace'] = trace
            st['hourly_summary_schema'] = _V631_HOURLY_SCHEMA
            st['hourly_summary_updated_at'] = now_ts()
            save_json(FILES['status'], st)
    except Exception as exc:
        log_error('v631_status_hourly_trace', exc)


def _v631_hourly_trace_result(result: str, bucket: Dict[str, Any], extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    obj = {
        'schema': _V631_HOURLY_SCHEMA,
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'window_start_ts': fnum(bucket.get('start_ts'), default=now_ts()),
        'window_start_text': bucket.get('start_text') or '',
        'result': result,
        'cycles': int(bucket.get('cycles') or 0),
        's1_seen': int(bucket.get('s1_seen') or 0),
        'selected_s1': int(bucket.get('selected_s1') or 0),
        'paper_entry_hold': int(bucket.get('paper_entry_hold') or 0),
        'micro_preopen_wait': int(bucket.get('micro_preopen_wait') or 0),
        'opened': int(bucket.get('opened') or 0),
        'closed': int(bucket.get('closed') or 0),
    }
    if isinstance(extra, dict):
        obj.update(extra)
    return obj


def _v631_maybe_send_paper_hourly_summary(status: Dict[str, Any]) -> None:
    try:
        ctrl = load_control()
        if not bool(ctrl.get('notify_paper_hourly_summary_enabled', True)):
            return
        interval = max(3600.0, fnum(ctrl.get('notify_paper_hourly_summary_interval_sec'), default=3600.0))
        b = _v631_bucket_collect(status if isinstance(status, dict) else {})
        now = now_ts()
        elapsed = now - fnum(b.get('start_ts'), default=now)
        if elapsed < interval:
            _v631_save_hourly_trace(_v631_hourly_trace_result('waiting_interval', b, {'next_in_sec': round(interval - elapsed, 1)}))
            return
        closed_rows = _v631_recent_closed_rows(hours=max(1.0, elapsed / 3600.0))
        meaningful = int(b.get('s1_seen') or 0) + int(b.get('paper_entry_hold') or 0) + int(b.get('opened') or 0) + int(b.get('closed') or 0) + len(closed_rows)
        if meaningful <= 0 and not bool(ctrl.get('notify_paper_hourly_summary_send_idle', False)):
            trace = _v631_hourly_trace_result('skipped_no_activity', b, {'skip_reason': '1시간 내 S1/OPEN/CLOSED/보류 없음', 'temp_deleted': True})
            _v631_save_hourly_trace(trace)
            _v631_bucket_reset(now)
            return
        text = _v631_build_hourly_summary_text(status if isinstance(status, dict) else {}, b, closed_rows)
        filename = f"paper_hourly_summary_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        tmp = FILES['hourly_summary_tmp']
        tmp.write_text(text, encoding='utf-8')
        ok, err = _v631_send_document_file(tmp, filename, f'🧾 paper 1시간 요약 · {iso_ts()}')
        deleted = False
        if ok:
            try:
                tmp.unlink(missing_ok=True)
                deleted = True
            except Exception as exc:
                log_error('v631_hourly_tmp_delete', exc)
        trace = _v631_hourly_trace_result('sent_ok' if ok else 'send_error', b, {
            'sent_ok': bool(ok),
            'error': err,
            'filename': filename,
            'temp_deleted': bool(deleted),
            'temp_path': str(tmp if not deleted else ''),
            'closed_recent': len(closed_rows),
            'text_chars': len(text),
        })
        _v631_save_hourly_trace(trace)
        _v631_bucket_reset(now)
    except Exception as exc:
        log_error('v631_maybe_send_paper_hourly_summary', exc)
        try:
            _v631_save_hourly_trace({'schema': _V631_HOURLY_SCHEMA, 'version': VERSION, 'build': BUILD_LABEL, 'updated_at': now_ts(), 'updated_at_text': iso_ts(), 'result': 'internal_error', 'error': f'{type(exc).__name__}: {exc}'})
        except Exception:
            pass


_v631_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v631_prev_run_cycle()
    try:
        if isinstance(st, dict):
            st['build'] = BUILD_LABEL
            st['paper_hourly_summary_schema'] = _V631_HOURLY_SCHEMA
        _v631_maybe_send_paper_hourly_summary(st if isinstance(st, dict) else {})
    except Exception as exc:
        log_error('v631_run_cycle_hourly_summary', exc)
    return st

try:
    _v631_save_hourly_trace({'schema': _V631_HOURLY_SCHEMA, 'version': VERSION, 'build': BUILD_LABEL, 'updated_at': now_ts(), 'updated_at_text': iso_ts(), 'result': 'loaded_waiting_first_interval'})
except Exception as exc:
    log_error('v631_hourly_startup_trace', exc)


# =============================================================================
# paper_bot v0.225 / v632: hourly summary/raw pack dual-room sender
# - paper_bot이 만든 1시간 요약 txt를 paper방 + main방으로 같이 전송한다.
# - main방 chat id는 PAPER_BOT_MAIN_NOTIFY_CHAT_ID / MAIN_BOT_CHAT_ID / MAIN_CHAT_ID / COINBOT_MAIN_CHAT_ID / CHAT_ID 순서로 찾는다.
# - 전송 결과는 paper/main 각각 trace에 남긴다. 성공 시 임시 txt는 삭제한다.
# - 조건/S1·S2·S3/청산/장부/자동매수 변경 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
_V632_HOURLY_SCHEMA = 'paper_hourly_summary_v632_dual_room_send_delete'
FILES.setdefault('hourly_summary_trace', BASE_DIR / 'paper_bot_hourly_summary_trace.json')
FILES.setdefault('hourly_summary_tmp', BASE_DIR / 'paper_bot_latest_hourly_summary.txt')
FILES.setdefault('hourly_raw_pack_trace', BASE_DIR / 'paper_bot_hourly_raw_pack_trace.json')


def _v632_env_first(*names: str) -> str:
    for name in names:
        try:
            val = os.getenv(name, '').strip()
        except Exception:
            val = ''
        if val:
            return val
    return ''


def _v632_main_notify_chat_id() -> str:
    return _v632_env_first(
        'PAPER_BOT_MAIN_NOTIFY_CHAT_ID',
        'PAPER_BOT_MAIN_CHAT_ID',
        'MAIN_BOT_CHAT_ID',
        'MAIN_CHAT_ID',
        'COINBOT_MAIN_CHAT_ID',
        'CHAT_ID',
    )


def _v632_send_targets() -> List[Dict[str, Any]]:
    targets: List[Dict[str, Any]] = []
    seen = set()
    def add(name: str, chat_id: str, required: bool) -> None:
        cid = str(chat_id or '').strip()
        if not cid:
            targets.append({'name': name, 'chat_id_present': False, 'required': required, 'skip_reason': 'missing_chat_id'})
            return
        if cid in seen:
            targets.append({'name': name, 'chat_id_present': True, 'required': required, 'skip_reason': 'duplicate_chat_id'})
            return
        seen.add(cid)
        targets.append({'name': name, 'chat_id': cid, 'chat_id_present': True, 'required': required})
    add('paper', str(NOTIFY_CHAT_ID or ALLOWED_CHAT_ID or ''), True)
    add('main', _v632_main_notify_chat_id(), False)
    return targets


def _v632_send_document_to_chat(path: Path, filename: str, caption: str, chat_id: str) -> Tuple[bool, str]:
    if not TOKEN:
        return False, 'telegram_disabled: TOKEN missing'
    if not chat_id:
        return False, 'telegram_disabled: chat_id missing'
    try:
        import uuid
        boundary = '----coinbotpaperhourlyv632' + uuid.uuid4().hex
        chunks: List[bytes] = []
        def field(name: str, value: str) -> None:
            chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n').encode('utf-8'))
        field('chat_id', str(chat_id))
        field('caption', caption[:1000])
        field('disable_web_page_preview', 'true')
        chunks.append((f'--{boundary}\r\nContent-Disposition: form-data; name="document"; filename="{filename}"\r\nContent-Type: text/plain; charset=utf-8\r\n\r\n').encode('utf-8'))
        chunks.append(path.read_bytes())
        chunks.append(f'\r\n--{boundary}--\r\n'.encode('utf-8'))
        req = urllib.request.Request(
            f'https://api.telegram.org/bot{TOKEN}/sendDocument',
            data=b''.join(chunks),
            headers={'Content-Type': f'multipart/form-data; boundary={boundary}'},
        )
        urllib.request.urlopen(req, timeout=20).read()
        return True, ''
    except Exception as exc:
        log_error('v632_send_document_to_chat', exc)
        return False, f'{type(exc).__name__}: {exc}'


def _v632_send_document_dual(path: Path, filename: str, caption: str) -> Dict[str, Any]:
    results: Dict[str, Any] = {}
    targets = _v632_send_targets()
    for target in targets:
        name = str(target.get('name') or 'unknown')
        if target.get('skip_reason'):
            results[name] = {
                'sent_ok': False,
                'skipped': True,
                'reason': target.get('skip_reason'),
                'chat_id_present': bool(target.get('chat_id_present')),
            }
            continue
        ok, err = _v632_send_document_to_chat(path, filename, caption, str(target.get('chat_id') or ''))
        results[name] = {'sent_ok': bool(ok), 'error': err, 'chat_id_present': True}
    paper_ok = bool(results.get('paper', {}).get('sent_ok'))
    main = results.get('main', {})
    main_ok = bool(main.get('sent_ok'))
    main_required_for_delete = bool(main.get('chat_id_present')) and not bool(main.get('skipped'))
    all_configured_ok = paper_ok and (main_ok if main_required_for_delete else True)
    return {
        'paper_sent_ok': paper_ok,
        'main_sent_ok': main_ok,
        'all_configured_sent_ok': all_configured_ok,
        'targets': results,
    }


def _v632_save_hourly_trace(trace: Dict[str, Any]) -> None:
    try:
        trace = dict(trace or {})
        trace.setdefault('schema', _V632_HOURLY_SCHEMA)
        trace.setdefault('version', VERSION)
        trace.setdefault('build', BUILD_LABEL)
        trace.setdefault('updated_at', now_ts())
        trace.setdefault('updated_at_text', iso_ts())
        save_json(FILES['hourly_summary_trace'], trace)
    except Exception as exc:
        log_error('v632_save_hourly_trace', exc)
    try:
        st = load_json(FILES['status'], {}) or {}
        if isinstance(st, dict):
            st['version'] = VERSION
            st['paper_version'] = VERSION
            st['build'] = BUILD_LABEL
            st['paper_hourly_summary_trace'] = trace
            st['hourly_summary_schema'] = _V632_HOURLY_SCHEMA
            st['hourly_summary_updated_at'] = now_ts()
            save_json(FILES['status'], st)
    except Exception as exc:
        log_error('v632_status_hourly_trace', exc)


def _v632_hourly_trace_result(result: str, bucket: Dict[str, Any], extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    obj = {
        'schema': _V632_HOURLY_SCHEMA,
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'window_start_ts': fnum(bucket.get('start_ts'), default=now_ts()) if isinstance(bucket, dict) else now_ts(),
        'window_start_text': bucket.get('start_text') if isinstance(bucket, dict) else '',
        'result': result,
        'cycles': int(bucket.get('cycles') or 0) if isinstance(bucket, dict) else 0,
        's1_seen': int(bucket.get('s1_seen') or 0) if isinstance(bucket, dict) else 0,
        'selected_s1': int(bucket.get('selected_s1') or 0) if isinstance(bucket, dict) else 0,
        'paper_entry_hold': int(bucket.get('paper_entry_hold') or 0) if isinstance(bucket, dict) else 0,
        'micro_preopen_wait': int(bucket.get('micro_preopen_wait') or 0) if isinstance(bucket, dict) else 0,
        'opened': int(bucket.get('opened') or 0) if isinstance(bucket, dict) else 0,
        'closed': int(bucket.get('closed') or 0) if isinstance(bucket, dict) else 0,
    }
    if isinstance(extra, dict):
        obj.update(extra)
    return obj


def _v632_maybe_send_paper_hourly_summary(status: Dict[str, Any]) -> None:
    try:
        ctrl = load_control()
        if not bool(ctrl.get('notify_paper_hourly_summary_enabled', True)):
            return
        interval = max(3600.0, fnum(ctrl.get('notify_paper_hourly_summary_interval_sec'), default=3600.0))
        b = _v631_bucket_collect(status if isinstance(status, dict) else {})
        now = now_ts()
        elapsed = now - fnum(b.get('start_ts'), default=now)
        if elapsed < interval:
            _v632_save_hourly_trace(_v632_hourly_trace_result('waiting_interval', b, {'next_in_sec': round(interval - elapsed, 1), 'targets': _v632_send_document_dual.__name__}))
            return
        closed_rows = _v631_recent_closed_rows(hours=max(1.0, elapsed / 3600.0))
        meaningful = int(b.get('s1_seen') or 0) + int(b.get('paper_entry_hold') or 0) + int(b.get('opened') or 0) + int(b.get('closed') or 0) + len(closed_rows)
        if meaningful <= 0 and not bool(ctrl.get('notify_paper_hourly_summary_send_idle', False)):
            trace = _v632_hourly_trace_result('skipped_no_activity', b, {
                'skip_reason': '1시간 내 S1/OPEN/CLOSED/보류 없음',
                'paper_sent_ok': False,
                'main_sent_ok': False,
                'temp_deleted': True,
            })
            _v632_save_hourly_trace(trace)
            _v631_bucket_reset(now)
            return
        text = _v631_build_hourly_summary_text(status if isinstance(status, dict) else {}, b, closed_rows)
        filename = f"paper_hourly_summary_{time.strftime('%Y%m%d_%H%M%S')}.txt"
        tmp = FILES['hourly_summary_tmp']
        tmp.write_text(text, encoding='utf-8')
        send = _v632_send_document_dual(tmp, filename, f'🧾 paper 1시간 요약 · {iso_ts()}')
        deleted = False
        if bool(send.get('all_configured_sent_ok')):
            try:
                tmp.unlink(missing_ok=True)
                deleted = True
            except Exception as exc:
                log_error('v632_hourly_tmp_delete', exc)
        trace = _v632_hourly_trace_result('sent_ok' if bool(send.get('all_configured_sent_ok')) else 'send_partial_or_error', b, {
            'sent_ok': bool(send.get('all_configured_sent_ok')),
            'paper_sent_ok': bool(send.get('paper_sent_ok')),
            'main_sent_ok': bool(send.get('main_sent_ok')),
            'send_targets': send.get('targets'),
            'filename': filename,
            'temp_deleted': bool(deleted),
            'temp_path': str(tmp if not deleted else ''),
            'closed_recent': len(closed_rows),
            'text_chars': len(text),
        })
        _v632_save_hourly_trace(trace)
        _v631_bucket_reset(now)
    except Exception as exc:
        log_error('v632_maybe_send_paper_hourly_summary', exc)
        try:
            _v632_save_hourly_trace({'schema': _V632_HOURLY_SCHEMA, 'version': VERSION, 'build': BUILD_LABEL, 'updated_at': now_ts(), 'updated_at_text': iso_ts(), 'result': 'internal_error', 'error': f'{type(exc).__name__}: {exc}'})
        except Exception:
            pass


# v631 run_cycle은 global name을 호출하므로 함수 이름만 교체하면 중복 wrapper 없이 새 본선으로 바뀐다.
_v631_maybe_send_paper_hourly_summary = _v632_maybe_send_paper_hourly_summary  # type: ignore[assignment]
_v631_save_hourly_trace = _v632_save_hourly_trace  # type: ignore[assignment]


# v628 raw pack도 같은 전송 본선을 쓰게 한다. 이미 도착하던 raw pack을 main방에도 같이 보낸다.
def _v628_send_document(path: Path, caption: str = '') -> Tuple[bool, str]:  # type: ignore[override]
    try:
        filename = path.name
        send = _v632_send_document_dual(path, filename, caption or f'paper hourly raw pack / {BUILD_LABEL}')
        trace = {
            'schema': 'paper_hourly_raw_pack_v632_dual_room_send',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': now_ts(),
            'updated_at_text': iso_ts(),
            'filename': filename,
            'paper_sent_ok': bool(send.get('paper_sent_ok')),
            'main_sent_ok': bool(send.get('main_sent_ok')),
            'sent_ok': bool(send.get('all_configured_sent_ok')),
            'send_targets': send.get('targets'),
        }
        try:
            save_json(FILES['hourly_raw_pack_trace'], trace)
        except Exception as exc:
            log_error('v632_raw_pack_trace', exc)
        return bool(send.get('all_configured_sent_ok')), '' if bool(send.get('all_configured_sent_ok')) else json.dumps(send.get('targets'), ensure_ascii=False)[:500]
    except Exception as exc:
        log_error('v632_v628_send_document_override', exc)
        return False, f'{type(exc).__name__}: {exc}'


try:
    _v632_save_hourly_trace({
        'schema': _V632_HOURLY_SCHEMA,
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'result': 'loaded_waiting_first_interval',
        'paper_sent_ok': False,
        'main_sent_ok': False,
        'send_targets_hint': 'paper + main if main chat id configured',
    })
except Exception as exc:
    log_error('v632_hourly_startup_trace', exc)




# =============================================================================
# paper_bot v0.228 / v635: score version key + snapshot spine renewal 1차
# - 성과판 버전 key는 OPEN 당시 entry_build_key/score_patch_version만 쓴다.
# - close_alert_trace 보강 row에 현재 실행 patch를 주입하지 않는다.
# - 과거 row에 OPEN 당시 key가 없으면 legacy_unknown으로 묶는다.
# - 조건/S등급/청산/장부 삭제 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
V635_SCORE_SCHEMA = 'paper_score_cache_v635_entry_build_key_snapshot_spine'

_V635_OPEN_PATCH_FIELDS = (
    'entry_build_key','open_build_key','entry_patch_version','score_patch_version','opened_patch_version'
)

def _v635_patch_from_any(v: Any) -> str:
    try:
        if str(v or '').strip() == 'legacy_unknown':
            return 'legacy_unknown'
        return _patch_version_from_text(v)
    except Exception:
        return ''

def _v635_entry_patch_key(row: Dict[str, Any]) -> str:
    if not isinstance(row, dict):
        return 'legacy_unknown'
    for k in _V635_OPEN_PATCH_FIELDS:
        key = _v635_patch_from_any(row.get(k))
        if key:
            return key
    for parent_key in ('raw','entry_context','entry_diagnostics','source_event','meta','metadata','canonical_entry_snapshot'):
        obj = row.get(parent_key)
        if isinstance(obj, dict):
            for k in _V635_OPEN_PATCH_FIELDS:
                key = _v635_patch_from_any(obj.get(k))
                if key:
                    return key
    # close_alert_trace로 보강된 row는 CLOSED 알림 시점 build를 성과버전으로 쓰지 않는다.
    if row.get('reconciled_from_close_alert_trace'):
        return 'legacy_unknown'
    # 과거 원장 중 OPEN patch가 없던 row만 main/file version 참고 분류로 남긴다.
    try:
        mv = _main_version_key(row)
        if mv and mv != active_main_version():
            return mv
    except Exception:
        pass
    return 'legacy_unknown'

_v635_prev_alert_to_closed_row = _v607_alert_to_closed_row if '_v607_alert_to_closed_row' in globals() else None

def _v607_alert_to_closed_row(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    if callable(_v635_prev_alert_to_closed_row):
        out = _v635_prev_alert_to_closed_row(row)
    else:
        out = dict(row or {})
    explicit = False
    if isinstance(row, dict):
        for k in _V635_OPEN_PATCH_FIELDS:
            if _v635_patch_from_any(row.get(k)):
                explicit = True; break
    if not explicit:
        for k in ('entry_build_key','open_build_key','entry_patch_version','score_patch_version','opened_patch_version','patch_version','run_patch_version','deploy_patch_version'):
            out.pop(k, None)
        out['entry_build_key'] = 'legacy_unknown'
        out['score_patch_version'] = 'legacy_unknown'
        out['version_key_note'] = 'v635: close_alert_trace had no OPEN-time patch key; current patch was not injected'
    out['closed_patch_version'] = row.get('closed_patch_version') or row.get('close_patch_version') or active_patch_version()
    out['close_patch_version'] = out['closed_patch_version']
    return out

def _v635_build_score_cache_obj(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    today_rows = _v557_filter_today(rows, nowv)
    by_grade: Dict[str, List[Dict[str, Any]]] = {}
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    by_version: Dict[str, List[Dict[str, Any]]] = {}
    by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    by_strategy_version: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    by_profile: Dict[str, List[Dict[str, Any]]] = {}
    by_profile_exit: Dict[str, List[Dict[str, Any]]] = {}
    by_strategy_exit: Dict[str, List[Dict[str, Any]]] = {}
    missing_key_count = 0
    for r in rows:
        strategy_key = _strategy_key(r)
        version_key = _v635_entry_patch_key(r)
        if version_key == 'legacy_unknown':
            missing_key_count += 1
        by_grade.setdefault(_score_bucket(r), []).append(r)
        by_strategy.setdefault(strategy_key, []).append(r)
        by_version.setdefault(version_key, []).append(r)
        by_version_strategy.setdefault(version_key, {}).setdefault(strategy_key, []).append(r)
        by_strategy_version.setdefault(strategy_key, {}).setdefault(version_key, []).append(r)
        prof = str(r.get('entry_profile') or 'unknown')
        if prof in {'spike_fast_early', 'spike_runner'}:
            prof = 'spike'
        elif prof in {'spike_fast_watch', 'normal_watch'}:
            prof = 'watch'
        by_profile.setdefault(prof, []).append(r)
        ex = str(r.get('exit_reason') or r.get('exit_rule') or '-')
        by_profile_exit.setdefault(f'{prof}:{ex}', []).append(r)
        by_strategy_exit.setdefault(f'{strategy_key}:{ex}', []).append(r)
    today_by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    today_by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    for tr in today_rows:
        today_by_strategy.setdefault(_strategy_key(tr), []).append(tr)
        today_by_version_strategy.setdefault(_v635_entry_patch_key(tr), {}).setdefault(_strategy_key(tr), []).append(tr)
    version_summary = {k: _score_stat(v) for k, v in by_version.items()}
    version_strategy_stats = {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in by_version_strategy.items()}
    strategy_version_stats = {sk: {vk: _score_stat(vrows) for vk, vrows in vmap.items()} for sk, vmap in by_strategy_version.items()}
    recent_3h = _build_recent_12h(rows, 3.0)
    recent_6h = _build_recent_12h(rows, 6.0)
    recent_12h = _build_recent_12h(rows, 12.0)
    return {
        'schema': V635_SCORE_SCHEMA,
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'score_scope': 'paper_closed_ledger_plus_close_alert_trace_reconciled_cache_only',
        'updated_at': nowv,
        'updated_at_text': iso_ts(),
        'current_closed_count': len(rows),
        'closed_count': len(rows),
        'source': 'paper_bot_closed_source_reconciled_v635_entry_build_key',
        'closed_source_reconcile': reconcile,
        'global_stats': _score_stat(rows),
        'today_scope': 'Asia/Seoul_day_midnight_to_now_cache_only',
        'today_timezone': 'Asia/Seoul',
        'today_day_key': _kst_day_key(nowv),
        'today_start_ts': _v557_today_start_ts(nowv),
        'today_start_text': iso_ts(_v557_today_start_ts(nowv)),
        'today_closed_count': len(today_rows),
        'today_global_stats': _score_stat(today_rows),
        'today_strategy_stats': {k: _score_stat(v) for k, v in today_by_strategy.items()},
        'today_version_strategy_stats': {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in today_by_version_strategy.items()},
        'grade_stats': {**{k: _score_stat(v) for k, v in by_grade.items()}, 'ALL': _score_stat(rows)},
        'strategy_primary_stats': {k: _score_stat(v) for k, v in by_strategy.items()},
        'strategy_stats': {k: _score_stat(v) for k, v in by_strategy.items()},
        'strategy_exit_stats': {k: _score_stat(v) for k, v in by_strategy_exit.items()},
        'strategy_primary_exit_stats': {k: _score_stat(v) for k, v in by_strategy_exit.items()},
        'strategy_outcome_analysis': _v543_build_strategy_outcome_analysis(by_strategy),
        'entry_profile_stats': {k: _score_stat(v) for k, v in by_profile.items()},
        'profile_exit_stats': {k: _score_stat(v) for k, v in by_profile_exit.items()},
        'version_summary': version_summary,
        'version_strategy_stats': version_strategy_stats,
        'strategy_version_stats': strategy_version_stats,
        'version_strategy_schema': 'v635_entry_build_key_x_strategy_closed_reconciled_cache_only',
        'version_summary_schema': 'v635_entry_build_key_only_no_current_patch_injection',
        'version_summary_keys': sorted(version_summary.keys()),
        'version_key_policy': 'v635_open_time_entry_build_key_only; missing_open_key=legacy_unknown; close_patch_reference_only',
        'version_key_missing_count': missing_key_count,
        'recent_3h': recent_3h,
        'recent_3h_stats': recent_3h.get('global'),
        'recent_6h': recent_6h,
        'recent_6h_stats': recent_6h.get('global'),
        'recent_12h': recent_12h,
        'active_main_version': active_main_version(),
        'active_main_version_source': active_main_version_detail()[1],
        'active_patch_version': active_patch_version(),
        'active_patch_version_source': active_patch_version_detail()[1],
        'legacy_deploy_target_version': _legacy_deploy_target_version(),
        'version_stats': version_summary,
        'main_version_stats': version_summary,
        'status_open_count': (status or {}).get('open_count') if isinstance(status, dict) else None,
    }

_v607_build_score_cache_obj = _v635_build_score_cache_obj  # type: ignore[assignment]

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v630_write_score_review_cache(status)

try:
    _v630_write_score_review_cache({'startup_status': True, 'build': BUILD_LABEL, 'v635_score_key_policy': 'entry_build_key_only'})
except Exception as exc:
    log_error('v635_startup_score_review', exc)


# =============================================================================
# paper_bot v0.229 / v638: main방 알림 X trace 보정 + chat_id 탐색 확장
# - paper방 전송 성공인데 main방 chat_id가 없거나 paper방과 같은 경우를 실패 X로 보지 않는다.
# - main방 chat_id는 env + txt/json 상태파일에서 찾는다.
# - 조건/S등급/청산/장부/자동매수 변경 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
_V638_HOURLY_SCHEMA = 'paper_hourly_summary_v638_dual_room_trace_refine'


def _v638_env_or_file_chat_id() -> str:
    names = (
        'PAPER_BOT_MAIN_NOTIFY_CHAT_ID', 'PAPER_BOT_MAIN_CHAT_ID',
        'MAIN_BOT_CHAT_ID', 'MAIN_CHAT_ID', 'COINBOT_MAIN_CHAT_ID',
    )
    for name in names:
        try:
            val = os.getenv(name, '').strip()
            if val:
                return val
        except Exception:
            pass
    for fn in ('MAIN_BOT_CHAT_ID.txt', 'main_chat_id.txt', 'coinbot_main_chat_id.txt'):
        try:
            p = BASE_DIR / fn
            if p.exists():
                val = p.read_text(encoding='utf-8', errors='ignore').strip().splitlines()[0].strip()
                if val:
                    return val
        except Exception:
            pass
    for fn in ('clean_brain_status.json', 'main_bot_status.json', 'coinbot_main_status.json'):
        try:
            p = BASE_DIR / fn
            obj = load_json(p, {}) if p.exists() else {}
            if isinstance(obj, dict):
                for k in ('main_chat_id','notify_chat_id','chat_id','allowed_chat_id','telegram_chat_id'):
                    val = str(obj.get(k) or '').strip()
                    if val:
                        return val
        except Exception:
            pass
    return ''


def _v632_main_notify_chat_id() -> str:  # type: ignore[override]
    return _v638_env_or_file_chat_id()


def _v638_send_document_dual(path: Path, filename: str, caption: str) -> Dict[str, Any]:
    results: Dict[str, Any] = {}
    paper_chat = str(NOTIFY_CHAT_ID or ALLOWED_CHAT_ID or '').strip()
    main_chat = _v638_env_or_file_chat_id()
    # paper target: required
    if not paper_chat:
        results['paper'] = {'sent_ok': False, 'skipped': True, 'reason': 'paper_chat_id_missing', 'chat_id_present': False}
    else:
        ok, err = _v632_send_document_to_chat(path, filename, caption, paper_chat)
        results['paper'] = {'sent_ok': bool(ok), 'error': err, 'chat_id_present': True}
    # main target: optional but visible
    if not main_chat:
        results['main'] = {'sent_ok': None, 'skipped': True, 'reason': 'missing_chat_id', 'chat_id_present': False, 'required': False}
    elif main_chat == paper_chat:
        results['main'] = {'sent_ok': True, 'skipped': True, 'reason': 'same_as_paper_chat_id', 'chat_id_present': True, 'required': False}
    else:
        ok, err = _v632_send_document_to_chat(path, filename, caption, main_chat)
        results['main'] = {'sent_ok': bool(ok), 'error': err, 'chat_id_present': True, 'required': False}
    paper_ok = bool(results.get('paper', {}).get('sent_ok'))
    main_val = results.get('main', {}).get('sent_ok')
    all_configured_ok = paper_ok and (main_val is not False)
    return {
        'paper_sent_ok': paper_ok,
        'main_sent_ok': main_val,
        'all_configured_sent_ok': all_configured_ok,
        'targets': results,
        'schema': _V638_HOURLY_SCHEMA,
    }


_v632_send_document_dual = _v638_send_document_dual  # type: ignore[assignment]

try:
    # 기존 trace가 main방 missing/duplicate 때문에 X로 보이는 것을 줄이기 위한 startup trace.
    _v632_save_hourly_trace({
        'schema': _V638_HOURLY_SCHEMA,
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'result': 'loaded_waiting_first_interval',
        'paper_sent_ok': None,
        'main_sent_ok': None,
        'send_targets_hint': 'paper required / main optional; missing main chat id is warning, not paper send failure',
    })
except Exception as exc:
    log_error('v638_hourly_startup_trace', exc)



# =============================================================================
# paper_bot v0.230 / v640: S1 drop trace + CLOSED source/alert provenance + rolling window trace
# - 조건/S등급/청산/자동매수/장부 원본 변경 없음.
# - score cache에 최근 3h/6h 변동 원인과 CLOSED 원천(ledger/alert_trace)을 표시한다.
# - S1 감지 후 선택/보류/OPEN으로 이어지지 않는 경우 drop trace를 pick_stats에 남긴다.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
V640_SCORE_SCHEMA = 'paper_score_cache_v640_source_trace_window'


def _v640_row_key(row: Dict[str, Any]) -> str:
    try:
        if '_v607_row_key' in globals():
            return _v607_row_key(row)  # type: ignore[name-defined]
    except Exception:
        pass
    tid = str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or '').strip()
    if tid:
        return 'id:' + tid
    ticker = normalize_ticker(row.get('ticker'))
    opened = fnum(row.get('opened_at'), default=0.0)
    closed = fnum(row.get('closed_at'), row.get('ts'), default=0.0)
    return f'tc:{ticker}:{round(opened,1)}:{round(closed,1)}' if ticker and (opened or closed) else ''


def _v640_recent_alert_status(kind: str, row: Dict[str, Any]) -> Dict[str, Any]:
    """Return best recent Telegram alert trace for a paper row. Lightweight: recent tail only."""
    out = {'sent': None, 'phase': '-', 'error': '', 'build': '-', 'source': 'trace_missing'}
    try:
        path = _v567_trade_alert_path(kind) if '_v567_trade_alert_path' in globals() else (BASE_DIR / f'paper_bot_{kind}_alert_trace.jsonl')
        key = _v640_row_key(row)
        if not key:
            return out
        rank = {'send_ok': 5, 'send_error': 4, 'message_build_error': 3, 'attempt_start': 2, 'without_alert_trace': 1}
        best = None; best_rank = -1
        for tr in read_jsonl_tail(path, 500):
            if not isinstance(tr, dict) or str(tr.get('kind') or kind).lower() != str(kind).lower():
                continue
            if _v640_row_key(tr) != key:
                continue
            ph = str(tr.get('phase') or '')
            rr = rank.get(ph, 0)
            if rr >= best_rank:
                best, best_rank = tr, rr
        if isinstance(best, dict):
            out.update({'sent': bool(best.get('sent_ok')), 'phase': best.get('phase') or '-', 'error': str(best.get('error') or ''), 'build': best.get('build') or '-', 'source': 'alert_trace'})
    except Exception as exc:
        try: log_error(f'v640_recent_alert_status_{kind}', exc)
        except Exception: pass
    return out


def _v640_closed_source_label(row: Dict[str, Any]) -> str:
    if row.get('reconciled_from_close_alert_trace'):
        return 'alert_trace_recovered'
    return 'ledger'


def _v640_closed_trace_row(row: Dict[str, Any]) -> Dict[str, Any]:
    close_alert = _v640_recent_alert_status('closed', row)
    open_alert = _v640_recent_alert_status('open', row)
    return {
        'ticker': normalize_ticker(row.get('ticker')),
        'pnl_pct': fnum(row.get('pnl_pct'), row.get('profit_pct'), default=0.0),
        'strategy': row.get('strategy_label') or row.get('strategy') or row.get('strategy_key') or '-',
        'entry_build_key': row.get('entry_build_key') or row.get('score_patch_version') or row.get('open_build_key') or row.get('version_key') or '-',
        'closed_at': fnum(row.get('closed_at'), row.get('ts'), default=0.0),
        'closed_at_text': row.get('closed_at_text') or (iso_ts(fnum(row.get('closed_at'), row.get('ts'), default=0.0)) if fnum(row.get('closed_at'), row.get('ts'), default=0.0) else ''),
        'source': _v640_closed_source_label(row),
        'reconciled_from_close_alert_trace': bool(row.get('reconciled_from_close_alert_trace')),
        'open_alert_sent': open_alert.get('sent'),
        'open_alert_phase': open_alert.get('phase'),
        'open_alert_error': open_alert.get('error'),
        'close_alert_sent': True if row.get('reconciled_from_close_alert_trace') and row.get('source_alert_phase') == 'send_ok' else close_alert.get('sent'),
        'close_alert_phase': row.get('source_alert_phase') or close_alert.get('phase'),
        'close_alert_error': close_alert.get('error'),
    }


def _v640_source_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    d = {'ledger': 0, 'alert_trace_recovered': 0}
    for r in rows:
        d[_v640_closed_source_label(r)] = d.get(_v640_closed_source_label(r), 0) + 1
    return d


def _v640_recent_rows(rows: List[Dict[str, Any]], hours: float) -> List[Dict[str, Any]]:
    cutoff = now_ts() - hours * 3600.0
    return [r for r in rows if fnum(r.get('closed_at'), r.get('ts'), default=0.0) >= cutoff]


def _v640_stat_n_total(obj: Any) -> Tuple[int, float]:
    if not isinstance(obj, dict):
        return 0, 0.0
    try:
        n = int(float(obj.get('n', obj.get('count', obj.get('closed_count', obj.get('total', 0)))) or 0))
    except Exception:
        n = 0
    total = fnum(obj.get('sum_pct'), obj.get('total_pct'), obj.get('pnl_sum'), obj.get('profit_sum'), obj.get('total_pnl_pct'), obj.get('total_profit_pct'), default=0.0)
    if abs(total) < 1e-12 and n:
        avg = fnum(obj.get('avg_pct'), obj.get('avg'), obj.get('mean_pct'), obj.get('mean'), default=0.0)
        total = avg * n
    return n, total


_v640_prev_build_score_cache_obj = _v607_build_score_cache_obj if '_v607_build_score_cache_obj' in globals() else None

def _v607_build_score_cache_obj(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    prior = {}
    try:
        prior = load_json(FILES.get('score', BASE_DIR / 'paper_bot_score_cache.json'), {}) or {}
    except Exception:
        prior = {}
    if callable(_v640_prev_build_score_cache_obj):
        obj = _v640_prev_build_score_cache_obj(rows, status, reconcile)  # type: ignore[misc]
    else:
        obj = {'closed_count': len(rows), 'today_closed_count': len(_v557_filter_today(rows, now_ts())) if '_v557_filter_today' in globals() else len(rows), 'updated_at': now_ts()}
    if not isinstance(obj, dict):
        obj = {}
    nowv = now_ts()
    today_rows = _v557_filter_today(rows, nowv) if '_v557_filter_today' in globals() else rows
    recent_trace = []
    for r in today_rows[-12:]:
        if isinstance(r, dict):
            recent_trace.append(_v640_closed_trace_row(r))
    source_counts_all = _v640_source_counts(rows)
    source_counts_today = _v640_source_counts(today_rows)
    window_trace = {}
    for hours in (3, 6):
        key = f'recent_{hours}h'.replace('.0','')
        cur_obj = obj.get(f'recent_{hours}h_stats'.replace('.0','')) or ((obj.get(key) or {}).get('global') if isinstance(obj.get(key), dict) else {})
        prior_obj = prior.get(f'recent_{hours}h_stats'.replace('.0','')) or ((prior.get(key) or {}).get('global') if isinstance(prior.get(key), dict) else {})
        cur_n, cur_total = _v640_stat_n_total(cur_obj)
        prev_n, prev_total = _v640_stat_n_total(prior_obj)
        prev_today = int(float(prior.get('today_closed_count') or 0)) if isinstance(prior, dict) else 0
        cur_today = len(today_rows)
        if cur_today > prev_today:
            reason = 'new_today_closed_added'
        elif cur_today == prev_today and (cur_n != prev_n or abs(cur_total - prev_total) > 1e-9):
            reason = 'rolling_window_changed_without_new_today_closed'
        else:
            reason = 'no_count_change_or_first_cache'
        recent_rows = _v640_recent_rows(rows, float(hours))
        window_trace[f'{int(hours)}h'] = {
            'current_count': cur_n,
            'current_total_pct': round(cur_total, 6),
            'previous_count': prev_n,
            'previous_total_pct': round(prev_total, 6),
            'today_count_current': cur_today,
            'today_count_previous': prev_today,
            'reason': reason,
            'source_counts': _v640_source_counts(recent_rows),
            'oldest_closed_at_text': (iso_ts(fnum(recent_rows[0].get('closed_at'), recent_rows[0].get('ts'), default=0.0)) if recent_rows else ''),
            'newest_closed_at_text': (iso_ts(fnum(recent_rows[-1].get('closed_at'), recent_rows[-1].get('ts'), default=0.0)) if recent_rows else ''),
        }
    obj.update({
        'schema': V640_SCORE_SCHEMA,
        'build': BUILD_LABEL,
        'source_trace_schema': 'closed_source_alert_trace_v640',
        'closed_source_counts': source_counts_all,
        'today_source_counts': source_counts_today,
        'recent_closed_source_trace': recent_trace,
        'recent_window_trace': window_trace,
        'score_source_note': 'ledger rows plus close_alert_trace recovered rows; each recent closed row has source/alert sent fields',
    })
    return obj

# keep the active builder alias on the v640 wrapper
try:
    _v607_build_score_cache_obj = _v607_build_score_cache_obj  # type: ignore[assignment,self-assign]
except Exception:
    pass


_v640_prev_run_cycle = run_cycle

def _v640_pick_int(pick: Dict[str, Any], *keys: str) -> int:
    for k in keys:
        try:
            if k in pick and pick.get(k) not in (None, ''):
                return int(float(pick.get(k) or 0))
        except Exception:
            pass
    return 0


def _v640_reason_from_s1_rows(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    try:
        s1_rows = []
        for r in rows or []:
            if not isinstance(r, dict):
                continue
            st = str(r.get('stage') or r.get('candidate_stage') or r.get('s_stage') or r.get('grade') or r.get('candidate_grade') or '').upper()
            if st == 'S1':
                s1_rows.append(r)
        if not s1_rows:
            return {'reason': 's1_seen_from_snapshot_but_no_s1_detail_row', 'ticker': '-', 'detail': '-'}
        r = s1_rows[0]
        reasons = []
        for k in ('paper_entry_hold_reasons','s1_block_reasons','s_stage_reasons','reasons','risk_tags','stale_reasons'):
            v = r.get(k)
            if isinstance(v, list):
                reasons += [str(x) for x in v if str(x).strip()]
            elif isinstance(v, str) and v.strip():
                reasons.append(v.strip())
        return {
            'reason': ' / '.join(reasons[:4]) or 's1_detected_but_not_selected_without_reason',
            'ticker': normalize_ticker(r.get('ticker')),
            'detail': {
                'strategy': r.get('strategy_label') or r.get('strategy') or r.get('strategy_key') or '-',
                'trigger_price': r.get('trigger_price'),
                'entry_price': r.get('entry_price') or r.get('current_price') or r.get('price'),
                'spread_pct': r.get('spread_pct'),
                'buy_ratio': r.get('buy_ratio'),
                'buy_sustain_1m': r.get('buy_sustain_1m') or r.get('buy_sustain'),
            },
        }
    except Exception as exc:
        try: log_error('v640_reason_from_s1_rows', exc)
        except Exception: pass
        return {'reason': 'trace_build_error', 'ticker': '-', 'detail': str(exc)}


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v640_prev_run_cycle()
    try:
        if not isinstance(st, dict):
            return st
        pick = st.get('pick_stats') if isinstance(st.get('pick_stats'), dict) else {}
        s1_seen = _v640_pick_int(pick, 's1_seen', 'v640_s1_seen')
        selected = _v640_pick_int(pick, 'selected_s1', 'v369_s1_selected', 'selected_for_open')
        hold = _v640_pick_int(pick, 'paper_entry_hold', 'paper_final_block', 'trigger_not_reached_hold', 'open_block')
        micro = _v640_pick_int(pick, 'micro_preopen_wait', 'micro_wait')
        opened = int(float(st.get('opened_this_cycle') or 0))
        drop = max(0, s1_seen - selected - hold - micro - opened)
        rows = _v582_active_rows(load_control()) if '_v582_active_rows' in globals() else []
        reason_obj = _v640_reason_from_s1_rows(rows) if drop else {'reason': '-', 'ticker': '-', 'detail': '-'}
        pick.update({
            'v640_s1_seen': s1_seen,
            'v640_selected_s1': selected,
            'v640_hold': hold,
            'v640_micro_wait': micro,
            'v640_opened': opened,
            's1_drop_count': drop,
            's1_drop_reason_top': {str(reason_obj.get('reason') or '-'): drop} if drop else {},
            'last_s1_drop': reason_obj if drop else None,
            's1_flow_schema': 's1_detect_select_hold_drop_trace_v640',
        })
        st['pick_stats'] = pick
        st['s1_flow_trace'] = {
            'schema': 's1_detect_select_hold_drop_trace_v640',
            's1_seen': s1_seen,
            'selected': selected,
            'hold': hold,
            'micro_wait': micro,
            'opened': opened,
            'drop': drop,
            'last_drop': reason_obj if drop else None,
            'updated_at': now_ts(),
            'updated_at_text': iso_ts(),
        }
        st['build'] = BUILD_LABEL
        st['version'] = VERSION
        try:
            save_json(FILES['status'], st)
            save_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {**(load_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}), 'pick_stats': pick, 's1_flow_trace': st['s1_flow_trace'], 'build': BUILD_LABEL, 'updated_at': now_ts(), 'updated_at_text': iso_ts()})
        except Exception as exc:
            log_error('v640_save_s1_flow_status', exc)
        try:
            write_score_cache(st)
        except Exception as exc:
            log_error('v640_rewrite_score_after_s1_flow', exc)
    except Exception as exc:
        log_error('v640_run_cycle_trace', exc)
    return st

try:
    write_score_cache({'startup_status': True, 'build': BUILD_LABEL, 'v640_source_trace': True})
except Exception as exc:
    log_error('v640_startup_score_trace', exc)


# =============================================================================
# paper_bot v0.232 / v654: score-review same CLOSED rows owner
# - v653에서 today_global_stats와 today_strategy_stats가 서로 다른 rows를 볼 수 있던 문제를 제거한다.
# - score today / review today / strategy today / recent CLOSED trace를 같은 reconciled CLOSED rows에서 한 번에 봉인한다.
# - 조건/S등급/청산/자동매수/paper 장부 삭제 없음.
# =============================================================================
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
V630_REVIEW_SCHEMA = 'paper_review_spine_v654_score_review_same_rows'

_v654_prev_build_score_cache_obj = _v607_build_score_cache_obj if '_v607_build_score_cache_obj' in globals() else None


def _v654_row_ts(row: Dict[str, Any]) -> float:
    try:
        if '_v628_row_ts' in globals():
            ts = _v628_row_ts(row)  # type: ignore[name-defined]
            if ts > 0:
                return ts
    except Exception:
        pass
    for k in ('closed_at', 'closed_ts', 'close_ts', 'exit_ts', 'exited_at', 'timestamp', 'ts', 'updated_at', 'created_at'):
        try:
            v = row.get(k)
            if v not in (None, '', [], {}):
                ts = float(v)
                if ts > 0:
                    return ts
        except Exception:
            pass
    return 0.0


def _v654_row_text(row: Dict[str, Any]) -> str:
    parts = []
    for k in ('closed_at_text', 'exit_at_text', 'exited_at_text', 'updated_at_text', 'created_at_text', 'ts_text', 'time_text'):
        try:
            v = str(row.get(k) or '').strip()
            if v:
                parts.append(v)
        except Exception:
            pass
    return ' '.join(parts)


def _v654_day_key(ts: Optional[float] = None, offset: int = 0) -> str:
    try:
        d = _kst_datetime(ts or now_ts()).date() + _dt.timedelta(days=offset)
        return d.strftime('%Y-%m-%d')
    except Exception:
        return ''


def _v654_day_rows(rows: List[Dict[str, Any]], day_offset: int = 0) -> List[Dict[str, Any]]:
    target = _v654_day_key(now_ts(), day_offset)
    if not target:
        return []
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        ts = _v654_row_ts(r)
        if ts > 0:
            try:
                if _kst_datetime(ts).date().strftime('%Y-%m-%d') == target:
                    out.append(r)
                    continue
            except Exception:
                pass
        # alert_trace recovered rows can lack numeric closed_at but keep KST text.
        txt = _v654_row_text(r)
        if target and target in txt:
            out.append(r)
    return out


def _v654_today_rows(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    return _v654_day_rows(rows, 0)


# Review cache writer already uses _v630_today_rows at runtime. Repoint it to the same day-row owner.
_v630_today_rows = _v654_today_rows  # type: ignore[assignment]
try:
    _v628_today_rows = _v654_today_rows  # type: ignore[assignment]
except Exception:
    pass


def _v654_recent_rows(rows: List[Dict[str, Any]], hours: float) -> List[Dict[str, Any]]:
    cutoff = now_ts() - hours * 3600.0
    out: List[Dict[str, Any]] = []
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        ts = _v654_row_ts(r)
        if ts > 0 and ts >= cutoff:
            out.append(r)
    return out


def _v654_closed_source_label(row: Dict[str, Any]) -> str:
    return 'alert_trace_recovered' if bool(row.get('reconciled_from_close_alert_trace') or row.get('source') == 'alert_trace_recovered') else 'ledger'


def _v654_source_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    d = {'ledger': 0, 'alert_trace_recovered': 0}
    for r in rows or []:
        if isinstance(r, dict):
            label = _v654_closed_source_label(r)
            d[label] = d.get(label, 0) + 1
    return d


def _v654_first(row: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        try:
            v = row.get(k)
            if v not in (None, '', [], {}):
                return v
        except Exception:
            pass
    return default


def _v654_strategy_key(row: Dict[str, Any]) -> str:
    try:
        if '_strategy_key' in globals():
            return str(_strategy_key(row))  # type: ignore[name-defined]
    except Exception:
        pass
    return str(row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or 'unknown')


def _v654_version_key(row: Dict[str, Any]) -> str:
    try:
        if '_main_version_key' in globals():
            return str(_main_version_key(row))  # type: ignore[name-defined]
    except Exception:
        pass
    return str(row.get('entry_build_key') or row.get('score_patch_version') or row.get('open_build_key') or 'legacy_unknown')


def _v654_group_stats(rows: List[Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, Dict[str, Any]]]:
    by_strategy: Dict[str, List[Dict[str, Any]]] = {}
    by_ver_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        sk = _v654_strategy_key(r)
        vk = _v654_version_key(r)
        by_strategy.setdefault(sk, []).append(r)
        by_ver_strategy.setdefault(vk, {}).setdefault(sk, []).append(r)
    return (
        {k: _score_stat(v) for k, v in by_strategy.items()},
        {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in by_ver_strategy.items()},
    )


def _v654_trace_row(r: Dict[str, Any]) -> Dict[str, Any]:
    try:
        closed_ts = _v654_row_ts(r)
        return {
            'ticker': normalize_ticker(r.get('ticker') or r.get('symbol') or r.get('market')),
            'pnl_pct': fnum(r.get('pnl_pct'), r.get('profit_pct'), r.get('net_pct'), default=0.0),
            'strategy': r.get('strategy_label') or r.get('strategy') or r.get('strategy_key') or '-',
            'entry_build_key': _v654_version_key(r),
            'source': _v654_closed_source_label(r),
            'open_alert_sent': r.get('open_alert_sent'),
            'close_alert_sent': r.get('close_alert_sent'),
            'closed_at': closed_ts,
            'closed_at_text': iso_ts(closed_ts) if closed_ts > 0 else (_v654_row_text(r) or ''),
            'entry_price': _v654_first(r, 'entry_price', 'open_price'),
            'exit_price': _v654_first(r, 'exit_price', 'close_price'),
            'max_profit_pct': _v654_first(r, 'max_profit_pct', 'peak_profit_pct', 'peak_pct', 'best_pct'),
            'min_profit_pct': _v654_first(r, 'min_profit_pct', 'trough_pct', 'worst_pct'),
            'hold_sec': _v654_first(r, 'hold_sec', 'duration_sec'),
            'age_min': _v654_first(r, 'age_min', 'hold_min'),
            'exit_reason': _v654_first(r, 'exit_reason', 'exit_rule', 'exit_rule_label'),
            'post_close_5m_pct': r.get('post_close_5m_pct'),
            'post_close_10m_pct': r.get('post_close_10m_pct'),
            'post_close_20m_pct': r.get('post_close_20m_pct'),
        }
    except Exception:
        return dict(r or {})


def _v607_build_score_cache_obj(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]], reconcile: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    if callable(_v654_prev_build_score_cache_obj):
        obj = _v654_prev_build_score_cache_obj(rows, status, reconcile)  # type: ignore[misc]
    else:
        obj = {'closed_count': len(rows or []), 'updated_at': now_ts()}
    if not isinstance(obj, dict):
        obj = {}
    rows = [r for r in list(rows or []) if isinstance(r, dict)]
    nowv = now_ts()
    today_rows = _v654_today_rows(rows)
    yesterday_rows = _v654_day_rows(rows, -1)
    recent24_rows = _v654_recent_rows(rows, 24.0)
    recent3_rows = _v654_recent_rows(rows, 3.0)
    recent6_rows = _v654_recent_rows(rows, 6.0)
    today_strategy_stats, today_version_strategy_stats = _v654_group_stats(today_rows)
    recent_trace = [_v654_trace_row(r) for r in rows[-12:]]
    obj.update({
        'schema': 'paper_score_cache_v654_score_review_same_rows',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(),
        'score_window_owner': 'paper_bot_v654',
        'score_review_rows_owner': 'paper_bot_v654_same_reconciled_closed_rows',
        'review_schema': V630_REVIEW_SCHEMA,
        'score_review_writer': 'v654_same_rows_owner',
        'today_scope': 'Asia/Seoul_day_by_same_reconciled_rows',
        'today_timezone': 'Asia/Seoul',
        'today_day_key': _v654_day_key(nowv, 0),
        'today_closed_count': len(today_rows),
        'today_global_stats': _score_stat(today_rows),
        'today_strategy_stats': today_strategy_stats,
        'today_version_strategy_stats': today_version_strategy_stats,
        'review_today_closed_count': len(today_rows),
        'yesterday_closed_count': len(yesterday_rows),
        'yesterday_global_stats': _score_stat(yesterday_rows),
        'recent_24h': {'global': _score_stat(recent24_rows), 'hours': 24, 'source_counts': _v654_source_counts(recent24_rows)},
        'recent_24h_stats': _score_stat(recent24_rows),
        'rolling_24h_stats': _score_stat(recent24_rows),
        'last_24h_stats': _score_stat(recent24_rows),
        'recent_3h': {'global': _score_stat(recent3_rows), 'hours': 3, 'source_counts': _v654_source_counts(recent3_rows)},
        'recent_3h_stats': _score_stat(recent3_rows),
        'recent_6h': {'global': _score_stat(recent6_rows), 'hours': 6, 'source_counts': _v654_source_counts(recent6_rows)},
        'recent_6h_stats': _score_stat(recent6_rows),
        'closed_source_counts': _v654_source_counts(rows),
        'today_source_counts': _v654_source_counts(today_rows),
        'recent_closed_source_trace': recent_trace,
        'recent_closed_source': recent_trace,
        'recent_closed_rows': recent_trace,
        'source_trace_schema': 'paper_score_review_source_owner_v654',
    })
    return obj


try:
    write_score_cache({'startup_status': True, 'build': BUILD_LABEL, 'v654_score_review_same_rows': True})
except Exception as exc:
    try:
        log_error('v654_startup_score_review_same_rows', exc)
    except Exception:
        pass


# =============================================================================
# paper_bot v0.234 / v670: fast-quality paper lane owner marker
# - v669 실험 lane 수신부는 기존 select_candidates 본선에 이미 연결되어 있다.
# - v654 score/review 같은 CLOSED rows owner는 유지한다.
# - VERSION/BUILD_LABEL 최종값을 v0.234/v670으로 고정해 guard/main 상태판 혼선을 제거한다.
# - 자동매수/BUY_READY/청산조건/장부 삭제 없음.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_FAST_QUALITY_LANE_OWNER_V672 = True

try:
    # startup/status cache hint only; run_cycle 본선은 기존 paper cycle을 그대로 탄다.
    _st = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    if isinstance(_st, dict):
        _st['version'] = VERSION
        _st['paper_version'] = VERSION
        _st['build'] = BUILD_LABEL
        _st['fast_quality_paper_lane_owner'] = 'v672'
        _st['fast_quality_paper_lane'] = FAST_EXPERIMENT_LANE_V669 if 'FAST_EXPERIMENT_LANE_V669' in globals() else 'fast_quality_paper_v669'
        _st['updated_at'] = now_ts()
        _st['updated_at_text'] = iso_ts()
        save_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), _st)
except Exception as exc:
    try:
        log_error('v670_paper_status_marker', exc)
    except Exception:
        pass


# =============================================================================
# paper_bot v0.235 / v672: fast paper experiment final-trace + paper-only relaxed gate
# - The strategy worker now marks paper-only experimental candidates more realistically.
# - This consumer must not re-apply the old S1-like q/risk/gap gate.
# - Final block reasons are stored for /pstatus and /candidate_reason display.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_FAST_QUALITY_LANE_OWNER_V672 = True

def is_paper_experiment_candidate_v669(ev: Dict[str, Any]) -> bool:  # type: ignore[override]
    if not isinstance(ev, dict):
        return False
    if ev.get('paper_experiment_open') is not True:
        return False
    if str(ev.get('paper_experiment_lane') or '') != FAST_EXPERIMENT_LANE_V669:
        return False
    if ev.get('real_eligible') is True or ev.get('auto_buy_ready') is True or ev.get('buy_ready') is True:
        return False
    # strategy_worker owns q/risk/trigger acceptance.  Paper only checks the marker.
    return True

def paper_experiment_safety_v669(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:  # type: ignore[override]
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    fast = ev.get('fast_quality_paper_v672') if isinstance(ev.get('fast_quality_paper_v672'), dict) else (ev.get('fast_quality_paper_v669') if isinstance(ev.get('fast_quality_paper_v669'), dict) else {})
    reasons: List[str] = []
    diag['paper_experiment_lane'] = FAST_EXPERIMENT_LANE_V669
    diag['paper_experiment_fast_quality'] = fast
    diag['final_trade_state'] = 'PAPER_EXPERIMENT_FAST_QUALITY_V672'
    diag['final_trade_label'] = '고품질 빠른진입 paper 실험'
    # Paper experiment still requires fresh execution info and blocks obvious execution danger.
    if not micro_fresh(ev, ctrl):
        reasons.append('호가·체결 신선정보 없음')
    if bool(ctrl.get('paper_final_require_ws_fresh', False)) and not ws_fresh(ev):
        reasons.append('실시간 시세 신선정보 없음')
    spread = fnum(fast.get('spread_pct'), diag.get('spread_pct'), default=0.0)
    slip = fnum(fast.get('slippage_pct'), diag.get('slippage_pct'), default=0.0)
    risk = fnum(fast.get('risk'), ev.get('execution_risk_score'), default=99.0)
    if spread > 0.85:
        reasons.append(f'실험 스프레드 부담 {spread:.2f}%')
    if slip > 0.85:
        reasons.append(f'실험 미끄러짐 부담 {slip:.2f}%')
    if risk > 50:
        reasons.append(f'실험 위험점수 초과 {risk:.1f}>50')
    diag['paper_final_safety_reasons'] = reasons
    diag['paper_final_safety_schema'] = 'paper_experiment_fast_quality_v672'
    return (len(reasons) == 0), reasons, diag




# =============================================================================
# paper_bot v0.236 / v673: fast paper profit guard + late/risk trace
# - v672 created experiment OPENs; VVV showed +1% peak but closed negative under protective stop.
# - For paper-only fast lane, model the protective exit at the protective floor rather than
#   the delayed polling price, and keep final safety trace visible.
# - This does not affect real trading, BUY_READY, or the main S1 rules.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_FAST_QUALITY_LANE_OWNER_V673 = True

_v673_prev_exit_decision_spine = _exit_decision_spine

def _exit_decision_spine(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    d = _v673_prev_exit_decision_spine(pos, age_min, peak, net, ctrl)
    try:
        is_fast = str(pos.get('paper_experiment_lane') or '') == FAST_EXPERIMENT_LANE_V669 or str(pos.get('strategy_key') or '') == FAST_EXPERIMENT_LANE_V669
        if is_fast and d.get('reason') == 'protect_stop_after_tp':
            # Stronger, explicit paper-only protect ladder.
            if peak >= 1.40:
                floor = 0.75
            elif peak >= 1.00:
                floor = 0.50
            elif peak >= 0.70:
                floor = 0.35
            elif peak >= 0.45:
                floor = 0.12
            else:
                floor = 0.0
            if floor > 0:
                d['paper_fast_protect_floor_pct'] = round(floor, 4)
                d['paper_fast_protect_model'] = 'v673_floor_fill'
                d['detail'] = f"fast paper 보호익절: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호모델 {floor:+.2f}%"
        return d
    except Exception:
        return d

_v673_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    pos2, closed = _v673_prev_update_position(pos, ctrl)
    try:
        if isinstance(closed, dict) and str(closed.get('paper_experiment_lane') or '') == FAST_EXPERIMENT_LANE_V669 and str(closed.get('exit_reason') or '') == 'protect_stop_after_tp':
            floor = fnum((closed.get('exit_decision_spine') if isinstance(closed.get('exit_decision_spine'), dict) else {}).get('paper_fast_protect_floor_pct'), default=0.0)
            pnl = fnum(closed.get('pnl_pct'), default=0.0)
            entry = fnum(closed.get('entry_price'), default=0.0)
            if floor > 0 and pnl < floor and entry > 0:
                modeled_exit = entry * (1.0 + (floor + fnum(ctrl.get('fee_pct_roundtrip'), default=0.10))/100.0)
                old_pnl = pnl
                closed['paper_model_raw_exit_price'] = closed.get('exit_price')
                closed['paper_model_raw_pnl_pct'] = old_pnl
                closed['exit_price'] = round(modeled_exit, 8)
                closed['pnl_pct'] = round(floor, 4)
                closed['missed_profit_pct'] = round(max(0.0, fnum(closed.get('peak_pct'), default=0.0) - floor), 4)
                closed['giveback_pct'] = round(max(0.0, fnum(closed.get('peak_pct'), default=0.0) - floor), 4)
                closed['went_negative_after_profit'] = False
                closed['close_review_tag'] = close_review_tag(fnum(closed.get('peak_pct'), default=0.0), floor, 'protect_stop_after_tp')
                closed['exit_rule_reason'] = str(closed.get('exit_rule_reason') or '') + f" / v673 보호모델: 실제 polling {old_pnl:+.2f}% → floor {floor:+.2f}%"
    except Exception as exc:
        try: log_error('v673_fast_protect_floor_fill', exc)
        except Exception: pass
    return pos2, closed



# =============================================================================
# paper_bot v0.237 / v674: fast handoff seen trace
# - v673/v672 proved paper OPEN can happen, but v673 showed strategy accepted > 0
#   while paper seen stayed 0.  This wrapper does not change entry conditions.
# - It records raw paper_latest fast rows, latest-filtered fast rows, and why seen
#   can be zero.  The strategy v674 stamp should make filtered fast rows visible.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_FAST_QUALITY_LANE_OWNER_V674 = True

_v674_prev_select_candidates = select_candidates

def _v674_fast_rows_from(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    out=[]
    for r in rows or []:
        if isinstance(r, dict) and r.get('paper_experiment_open') is True and str(r.get('paper_experiment_lane') or '') == FAST_EXPERIMENT_LANE_V669:
            out.append(r)
    return out

def _v674_brief(ev: Dict[str, Any], status: str, reason: str='') -> Dict[str, Any]:
    b = candidate_brief(ev, status=status, reason=reason)
    b['paper_experiment_lane'] = ev.get('paper_experiment_lane')
    b['scan_id'] = ev.get('scan_id') or ev.get('source_scan_id')
    b['handoff_ready_v674'] = bool(ev.get('paper_experiment_handoff_ready_v674'))
    b['event_id'] = ev.get('event_id') or b.get('event_id')
    return b

def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:  # type: ignore[override]
    try:
        raw = [dict(r) for r in read_jsonl_tail(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl'), 2000) if isinstance(r, dict)]
    except Exception:
        raw = []
    raw_fast = _v674_fast_rows_from(raw)
    try:
        filtered_probe = latest_scan_filter(raw, ctrl)
    except Exception:
        filtered_probe = raw
    filtered_fast = _v674_fast_rows_from(filtered_probe)
    picked, stats, filtered = _v674_prev_select_candidates(ctrl, open_pos)
    stats = dict(stats or {})
    stats['fast_quality_paper_raw_rows'] = len(raw_fast)
    stats['fast_quality_paper_filtered_rows'] = len(filtered_fast)
    stats['fast_quality_paper_handoff_source'] = 'paper_candidates_latest_actual_v674'
    if raw_fast:
        stats['last_fast_quality_paper_raw'] = _v674_brief(raw_fast[-1], 'raw_fast_handoff')
    if filtered_fast:
        stats['last_fast_quality_paper_filtered'] = _v674_brief(filtered_fast[-1], 'filtered_fast_handoff')
    if raw_fast and int(stats.get('fast_quality_paper_seen', 0)) <= 0:
        reason = 'fast row exists in paper_latest but not seen after paper filters'
        if not filtered_fast:
            reason = 'latest_scan_filter filtered out fast row'
        stats['fast_quality_paper_final_hold'] = int(stats.get('fast_quality_paper_final_hold', 0)) + len(raw_fast)
        stats['last_fast_quality_paper_hold'] = _v674_brief(raw_fast[-1], 'fast_handoff_not_seen', reason)
    return picked, stats, filtered

# =============================================================================
# paper_bot v0.238 / v675: selected -> OPEN/hold reason consistency
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_FAST_TRIGGER_HOLD_V675 = True

_v675_prev_paper_experiment_safety = paper_experiment_safety_v669

def paper_experiment_safety_v669(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:  # type: ignore[override]
    ok, reasons, diag = _v675_prev_paper_experiment_safety(ev, ctrl)
    reasons=list(reasons or []); diag=dict(diag or {})
    try:
        ctx=copy_entry_context(ev)
        if not diag: diag=build_entry_diagnostics(ev, ctx)
        price=get_event_price(ev); ticker=normalize_ticker(ev.get('ticker') or ev.get('market') or ev.get('symbol'))
        if ticker and price>0: price=live_price(ticker, price)
        gate=_v628_trigger_gate(ev, diag, price) if '_v628_trigger_gate' in globals() else {'trigger_reached': True}
        diag['trigger_gate_v675']=gate; diag['trigger_gate']=gate; diag['trigger_reached']=bool(gate.get('trigger_reached')); diag['trigger_gap_pct']=gate.get('trigger_gap_pct')
        if not bool(gate.get('trigger_reached')): reasons.append(str(gate.get('reason') or 'trigger_not_reached_v675'))
    except Exception as exc:
        reasons.append(f'trigger_gate_error_v675:{exc.__class__.__name__}')
    clean=[]
    for r in reasons:
        if r and str(r) not in clean: clean.append(str(r))
    diag['paper_final_safety_reasons']=clean; diag['paper_final_safety_schema']='paper_experiment_fast_quality_v675_trigger_consistent'
    return (ok and not clean), clean, diag

_v675_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st=_v675_prev_run_cycle()
    try:
        if isinstance(st, dict):
            st['paper_fast_trigger_hold_v675']=True; st['build']=BUILD_LABEL; save_json(FILES['status'], st)
    except Exception: pass
    return st


# =============================================================================
# paper_bot v0.239 / v676: paper-only near-trigger pre-entry support
# - Only for strategy-stamped paper_experiment_allow_pretrigger_v676 candidates.
# - Does not affect S1/real/BUY_READY.  Normal candidates still require trigger reached.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_NEAR_TRIGGER_PREENTRY_V676 = True

_v676_prev_trigger_gate = _v628_trigger_gate

def _v676_pretrigger_allowed(ev: Dict[str, Any], gate: Dict[str, Any]) -> bool:
    if not isinstance(ev, dict) or ev.get('paper_experiment_allow_pretrigger_v676') is not True:
        return False
    if str(ev.get('paper_experiment_lane') or '') != FAST_EXPERIMENT_LANE_V669:
        return False
    if gate.get('trigger_price') in (None, 0, 0.0):
        return False
    gap = fnum(gate.get('trigger_gap_pct'), default=-999.0)
    return bool(-0.40 <= gap <= 0.05)

def _v628_trigger_gate(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, entry_override: Optional[float] = None) -> Dict[str, Any]:  # type: ignore[override]
    gate = _v676_prev_trigger_gate(ev, diag, entry_override)
    try:
        if not bool(gate.get('trigger_reached')) and _v676_pretrigger_allowed(ev, gate):
            gate = dict(gate)
            gate['trigger_reached'] = True
            gate['paper_pretrigger_allowed_v676'] = True
            gate['paper_pretrigger_reason_v676'] = 'paper-only near-trigger preentry allowed; real/BUY_READY false'
            gate['reason'] = f"near_trigger_preentry_v676: 방아쇠 전 paper 실험 허용 / gap {fnum(gate.get('trigger_gap_pct'), default=0.0):+.2f}%"
        return gate
    except Exception:
        return gate

_v676_prev_trigger_gate_line = _v628_trigger_gate_line

def _v628_trigger_gate_line(row: Dict[str, Any], diag: Dict[str, Any], prefix: str = '- ') -> str:  # type: ignore[override]
    gate = diag.get('trigger_gate_v628') if isinstance(diag.get('trigger_gate_v628'), dict) else (diag.get('trigger_gate') if isinstance(diag.get('trigger_gate'), dict) else _v628_trigger_gate(row, diag))
    if gate.get('paper_pretrigger_allowed_v676'):
        gap = gate.get('trigger_gap_pct')
        gap_txt = f' / gap {gap:+.2f}%' if isinstance(gap, (int,float)) else ''
        return prefix + f"방아쇠확인: ⚠️ paper 선진입 / 진입 {fmt_price(gate.get('entry_price'))} vs 방아쇠 {fmt_price(gate.get('trigger_price'))}{gap_txt}"
    return _v676_prev_trigger_gate_line(row, diag, prefix)

_v676_prev_status_extra = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v676_prev_status_extra()
    try:
        if isinstance(st, dict):
            st['paper_near_trigger_preentry_v676'] = True
            st['build'] = BUILD_LABEL
            save_json(FILES['status'], st)
    except Exception:
        pass
    return st




# =============================================================================
# paper_bot v0.240 / v677: fast/near paper row must survive latest_scan_filter
# - v676 showed strategy handoff rows WLD/TON, but paper seen stayed 0.
# - Root cause: latest_scan_filter can select the newest normal scan_id and drop
#   paper_experiment rows that strategy stamped with a separate fast handoff scan_id.
# - This keeps fresh paper_experiment_open rows in the same consumed set, then lets
#   the existing paper safety/OPEN/hold logic decide. No S1/BUY_READY/real trading change.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_FAST_NEAR_FILTER_OWNER_V677 = True


def _v677_is_exp_row(ev: Dict[str, Any]) -> bool:
    return isinstance(ev, dict) and ev.get('paper_experiment_open') is True and str(ev.get('paper_experiment_lane') or '') == FAST_EXPERIMENT_LANE_V669


def _v677_event_key(ev: Dict[str, Any]) -> str:
    try:
        return str(ev.get('event_id') or ev.get('event_key') or ev.get('handoff_id') or ev.get('candidate_uid') or event_id(ev, 'strict'))
    except Exception:
        return str(id(ev))


_v677_prev_latest_scan_filter = latest_scan_filter

def latest_scan_filter(rows: List[Dict[str, Any]], ctrl: Dict[str, Any]) -> List[Dict[str, Any]]:  # type: ignore[override]
    base = _v677_prev_latest_scan_filter(rows, ctrl)
    try:
        if not rows:
            return base
        nowv = time.time()
        latest_ts = max((event_created_ts(r) for r in rows if isinstance(r, dict)), default=0.0)
        # Paper experiment rows are strategy-owned handoff rows.  They must not be
        # dropped just because their scan_id differs from the latest normal scan.
        win = max(45.0, fnum(ctrl.get('latest_scan_window_sec'), default=8.0) * 8.0)
        exp_rows: List[Dict[str, Any]] = []
        for r in rows:
            if not _v677_is_exp_row(r):
                continue
            ts = event_created_ts(r)
            if ts <= 0:
                ts = fnum(r.get('paper_handoff_ts'), r.get('updated_ts'), default=0.0)
            # Keep fresh fast/near rows either by absolute age or by latest scan proximity.
            fresh_by_now = ts > 0 and (nowv - ts) <= win
            fresh_by_scan = latest_ts > 0 and ts >= latest_ts - win
            if fresh_by_now or fresh_by_scan:
                exp_rows.append(r)
        if not exp_rows:
            return base
        merged: Dict[str, Dict[str, Any]] = {}
        for r in list(base or []) + exp_rows:
            if isinstance(r, dict):
                merged[_v677_event_key(r)] = r
        return list(merged.values())
    except Exception as exc:
        try: log_error('v677_latest_scan_filter', exc)
        except Exception: pass
        return base


_v677_prev_is_paper_experiment_candidate = is_paper_experiment_candidate_v669

def is_paper_experiment_candidate_v669(ev: Dict[str, Any]) -> bool:  # type: ignore[override]
    # Strategy owns acceptance.  Paper should not re-drop accepted fast/near rows
    # at the recognition stage; final safety below still blocks stale/micro/risk.
    if not _v677_is_exp_row(ev):
        return False
    if ev.get('real_eligible') is True or ev.get('auto_buy_ready') is True or ev.get('buy_ready') is True:
        return False
    return True


_v677_prev_select_candidates = select_candidates

def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:  # type: ignore[override]
    try:
        raw = [dict(r) for r in read_jsonl_tail(FILES.get('paper_latest', BASE_DIR/'paper_candidates_latest.jsonl'), 2000) if isinstance(r, dict)]
    except Exception:
        raw = []
    raw_fast = [r for r in raw if _v677_is_exp_row(r)]
    try:
        filtered_probe = latest_scan_filter(raw, ctrl)
    except Exception:
        filtered_probe = raw
    filtered_fast = [r for r in filtered_probe if _v677_is_exp_row(r)]
    picked, stats, filtered = _v677_prev_select_candidates(ctrl, open_pos)
    stats = dict(stats or {})
    stats['fast_quality_paper_raw_rows_v677'] = len(raw_fast)
    stats['fast_quality_paper_filtered_rows_v677'] = len(filtered_fast)
    # keep legacy keys so existing /candidate_reason and /pstatus show the corrected values
    stats['fast_quality_paper_raw_rows'] = max(int(stats.get('fast_quality_paper_raw_rows', 0) or 0), len(raw_fast))
    stats['fast_quality_paper_filtered_rows'] = max(int(stats.get('fast_quality_paper_filtered_rows', 0) or 0), len(filtered_fast))
    stats['fast_quality_paper_handoff_filter_owner'] = 'v677_latest_scan_filter_keep_exp_rows'
    if raw_fast:
        stats['last_fast_quality_paper_raw'] = _v674_brief(raw_fast[-1], 'raw_fast_handoff_v677') if '_v674_brief' in globals() else candidate_brief(raw_fast[-1], status='raw_fast_handoff_v677')
    if filtered_fast:
        stats['last_fast_quality_paper_filtered'] = _v674_brief(filtered_fast[-1], 'filtered_fast_handoff_v677') if '_v674_brief' in globals() else candidate_brief(filtered_fast[-1], status='filtered_fast_handoff_v677')
    if raw_fast and int(stats.get('fast_quality_paper_seen', 0) or 0) <= 0:
        reason = 'v677: fast row kept by filter but not recognized by paper experiment marker' if filtered_fast else 'v677: fast row still filtered out before selection'
        stats['last_fast_quality_paper_hold'] = (_v674_brief(raw_fast[-1], 'fast_handoff_not_seen_v677', reason) if '_v674_brief' in globals() else candidate_brief(raw_fast[-1], status='fast_handoff_not_seen_v677', reason=reason))
    return picked, stats, filtered


_v677_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v677_prev_run_cycle()
    try:
        if isinstance(st, dict):
            st['paper_fast_near_filter_owner_v677'] = True
            st['version'] = VERSION
            st['paper_version'] = VERSION
            st['build'] = BUILD_LABEL
            save_json(FILES['status'], st)
    except Exception:
        pass
    return st


# =============================================================================
# paper_bot v0.241 / v678: exit + cleanup single runtime owner
# - 구 run_cycle wrapper chain을 더 타지 않고, paper_bot 실행 루프를 이 단일 본선이 직접 소유한다.
# - 손절/익절/시간청산 조건값은 변경하지 않는다. 손절 초과 CLOSED는 지연 원인 trace만 남긴다.
# - CLOSED 원장은 삭제하지 않는다. score/review는 최근 hot rows만 읽고, trace/raw/shadow성 파일만 순환정리한다.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
FILES.setdefault('cleanup_state', BASE_DIR / 'paper_bot_cleanup_state.json')
FILES.setdefault('stop_overrun_trace', BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl')


def _v678_hot_tail_limit(name: str, default: int) -> int:
    try:
        return max(50, int(float(os.getenv(name, str(default)))))
    except Exception:
        return default


def _v678_closed_ts(row: Dict[str, Any]) -> float:
    if not isinstance(row, dict):
        return 0.0
    return fnum(row.get('closed_at'), row.get('closed_ts'), row.get('ts'), row.get('updated_at'), default=0.0)


def _v678_hot_closed_filter(rows: List[Dict[str, Any]], nowv: Optional[float] = None) -> List[Dict[str, Any]]:
    nowv = now_ts() if nowv is None else nowv
    hours = max(3.0, fnum(os.getenv('PAPER_SCORE_HOT_HOURS'), default=24.0))
    max_rows = _v678_hot_tail_limit('PAPER_SCORE_HOT_ROWS', 420)
    cutoff = nowv - hours * 3600.0
    clean = [r for r in rows if isinstance(r, dict)]
    clean.sort(key=lambda x: _v678_closed_ts(x))
    recent = [r for r in clean if _v678_closed_ts(r) >= cutoff]
    tail = clean[-max_rows:]
    merged: Dict[str, Dict[str, Any]] = {}
    for r in tail + recent:
        try:
            k = _v607_row_key(r) if '_v607_row_key' in globals() else ''
        except Exception:
            k = ''
        if not k:
            k = f"{r.get('ticker') or r.get('symbol')}-{_v678_closed_ts(r)}-{r.get('pnl_pct') or r.get('profit_pct')}"
        merged[str(k)] = r
    out = list(merged.values())
    out.sort(key=lambda x: _v678_closed_ts(x))
    return out


def _v678_reconciled_rows() -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """score/review hot source owner. 원장 전체를 메모리에 들고 계산하지 않는다."""
    nowv = now_ts()
    limit_closed = _v678_hot_tail_limit('PAPER_CLOSED_RECONCILE_TAIL', 520)
    limit_alert = _v678_hot_tail_limit('PAPER_CLOSE_ALERT_RECONCILE_TAIL', 520)
    ledger_all = [r for r in read_jsonl_tail(FILES['closed'], limit_closed) if isinstance(r, dict)]
    ledger = _v678_hot_closed_filter(ledger_all, nowv)
    ledger_keys = set()
    for r in ledger:
        try:
            k = _v607_row_key(r) if '_v607_row_key' in globals() else ''
            if k: ledger_keys.add(k)
        except Exception:
            pass
    raw_alerts = []
    try:
        ap = _v607_close_alert_trace_path() if '_v607_close_alert_trace_path' in globals() else FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl')
        raw_alerts = [r for r in read_jsonl_tail(ap, limit_alert) if isinstance(r, dict) and str(r.get('kind') or '').lower() == 'closed']
    except Exception as exc:
        log_error('v678_reconcile_alert_read', exc)
    alert_hot = _v678_hot_closed_filter(raw_alerts, nowv)
    phase_rank = {'send_ok': 3, 'attempt_start': 2, 'without_alert_trace': 1, 'send_error': 0, 'message_build_error': 0}
    best: Dict[str, Dict[str, Any]] = {}
    for r in alert_hot:
        try:
            k = _v607_row_key(r) if '_v607_row_key' in globals() else ''
        except Exception:
            k = ''
        if not k:
            continue
        cur = best.get(k)
        if not cur or phase_rank.get(str(r.get('phase') or ''), 0) >= phase_rank.get(str(cur.get('phase') or ''), 0):
            best[k] = r
    recovered = []
    for k, r in best.items():
        if k in ledger_keys:
            continue
        try:
            cr = _v607_alert_to_closed_row(r) if '_v607_alert_to_closed_row' in globals() else dict(r)
            if cr.get('ticker') and _v678_closed_ts(cr) > 0:
                recovered.append(cr)
        except Exception as exc:
            log_error('v678_alert_to_closed_row', exc)
    rows = _v678_hot_closed_filter(ledger + recovered, nowv)
    meta = {
        'schema': 'paper_closed_hot_reconcile_v678',
        'version': VERSION,
        'ledger_tail_read': len(ledger_all),
        'ledger_count': len(ledger),
        'alert_trace_tail_read': len(raw_alerts),
        'alert_unique_count': len(best),
        'alert_recovered_count': len(recovered),
        'hot_rows': len(rows),
        'hot_hours': max(3.0, fnum(os.getenv('PAPER_SCORE_HOT_HOURS'), default=24.0)),
        'hot_tail_limit': _v678_hot_tail_limit('PAPER_SCORE_HOT_ROWS', 420),
        'source_policy': 'v678 hot/cold: CLOSED ledger is preserved on disk; score/review only loads recent hot rows plus close_alert hot reconciliation',
        'recovered_tail': [
            {'ticker': r.get('ticker'), 'pnl_pct': r.get('pnl_pct'), 'closed_at_text': r.get('closed_at_text'), 'source': r.get('source') or 'alert_trace_recovered'}
            for r in recovered[-10:]
        ],
    }
    return rows, meta


# old v629/v630 reconcile fallback 경로를 hot-source owner로 교체한다.
_v630_reconciled_rows = _v678_reconciled_rows  # type: ignore[assignment]
_v607_reconciled_closed_rows = lambda limit_closed=520, limit_alert=520: _v678_reconciled_rows()  # type: ignore[assignment]


_v678_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    before_update_ts = fnum(pos.get('last_update'), default=0.0) if isinstance(pos, dict) else 0.0
    cycle_now = now_ts()
    updated, closed = _v678_prev_update_position(pos, ctrl)
    try:
        if isinstance(closed, dict):
            stop = fnum(ctrl.get('stop_loss_pct'), default=-0.55)
            pnl = fnum(closed.get('pnl_pct'), default=0.0)
            cache_age = max(0.0, now_ts() - fnum(_LAST_PRICE_CACHE.get('ts'), default=0.0)) if isinstance(_LAST_PRICE_CACHE, dict) else None
            loop_gap = max(0.0, cycle_now - before_update_ts) if before_update_ts > 0 else None
            closed['exit_runtime_owner'] = 'v678_single_cycle_owner'
            closed['price_cache_age_sec_at_close'] = round(cache_age, 3) if cache_age is not None else None
            if loop_gap is not None:
                closed['position_update_gap_sec'] = round(loop_gap, 3)
            if pnl <= stop - 0.20:
                trace = {
                    'schema': 'paper_stop_overrun_trace_v678',
                    'version': VERSION,
                    'build': BUILD_LABEL,
                    'ts': now_ts(),
                    'ts_text': iso_ts() if 'iso_ts' in globals() else now_text(),
                    'ticker': closed.get('ticker'),
                    'entry_price': closed.get('entry_price'),
                    'exit_price': closed.get('exit_price'),
                    'pnl_pct': pnl,
                    'stop_loss_pct': stop,
                    'overrun_pct': round(pnl - stop, 4),
                    'exit_reason': closed.get('exit_reason') or closed.get('exit_rule'),
                    'strategy': closed.get('strategy') or closed.get('strategy_name') or closed.get('paper_strategy_key') or closed.get('strategy_key'),
                    'strategy_key': closed.get('strategy_key') or closed.get('paper_strategy_key'),
                    'candidate_grade': closed.get('candidate_grade') or closed.get('grade') or closed.get('s_stage'),
                    'paper_experiment_lane': closed.get('paper_experiment_lane'),
                    'paper_experiment_open': closed.get('paper_experiment_open'),
                    'source': closed.get('source') or closed.get('close_source'),
                    'price_cache_age_sec': closed.get('price_cache_age_sec_at_close'),
                    'position_update_gap_sec': closed.get('position_update_gap_sec'),
                    'note': '손절선보다 크게 밀린 CLOSED. 조건값 변경 없음, 루프/가격갱신 지연 추적용.',
                }
                closed['stop_loss_overrun_v678'] = trace
                append_jsonl(FILES['stop_overrun_trace'], trace)
    except Exception as exc:
        log_error('v678_update_position_trace', exc)
    return updated, closed


def _v678_jsonl_prune(path: Path, max_age_sec: float, max_lines: int, ts_keys: Tuple[str, ...] = ('ts','updated_at','closed_at','created_at')) -> Dict[str, Any]:
    res = {'path': str(path), 'exists': False, 'before': 0, 'after': 0, 'removed': 0, 'ok': True, 'error': ''}
    try:
        if not path or not path.exists():
            return res
        res['exists'] = True
        raw_lines = path.read_text(encoding='utf-8', errors='ignore').splitlines()
        res['before'] = len(raw_lines)
        nowv = now_ts(); cutoff = nowv - max_age_sec
        kept: List[str] = []
        for ln in raw_lines:
            if not ln.strip():
                continue
            keep_by_ts = True
            try:
                obj = json.loads(ln)
                if isinstance(obj, dict):
                    ts = 0.0
                    for k in ts_keys:
                        ts = fnum(obj.get(k), default=0.0)
                        if ts > 0: break
                    if ts > 0:
                        keep_by_ts = ts >= cutoff
            except Exception:
                keep_by_ts = True
            if keep_by_ts:
                kept.append(ln)
        if max_lines > 0 and len(kept) > max_lines:
            kept = kept[-max_lines:]
        tmp = path.with_suffix(path.suffix + '.v678tmp')
        tmp.write_text(('\n'.join(kept) + ('\n' if kept else '')), encoding='utf-8')
        os.replace(tmp, path)
        res['after'] = len(kept)
        res['removed'] = max(0, int(res['before']) - len(kept))
        return res
    except Exception as exc:
        res['ok'] = False; res['error'] = f'{type(exc).__name__}: {exc}'
        try: log_error('v678_jsonl_prune', exc)
        except Exception: pass
        return res


def _v678_remove_stale_tmp_files(pattern: str, max_age_sec: float) -> Dict[str, Any]:
    out = {'pattern': pattern, 'checked': 0, 'removed': 0, 'errors': 0}
    try:
        nowv = now_ts()
        for path in BASE_DIR.glob(pattern):
            if not path.is_file():
                continue
            out['checked'] += 1
            try:
                if nowv - path.stat().st_mtime >= max_age_sec:
                    path.unlink(missing_ok=True)
                    out['removed'] += 1
            except Exception as exc:
                out['errors'] += 1
                log_error('v678_remove_stale_tmp_files', exc)
    except Exception as exc:
        out['errors'] += 1
        try: log_error('v678_remove_stale_glob', exc)
        except Exception: pass
    return out


def _v678_runtime_cleanup(ctrl: Dict[str, Any], status: Dict[str, Any]) -> Dict[str, Any]:
    nowv = now_ts()
    max_age_trace = max(3600.0, fnum(ctrl.get('paper_trace_retention_sec'), default=6*3600.0))
    max_age_alert = max(3600.0, fnum(ctrl.get('paper_alert_trace_retention_sec'), default=24*3600.0))
    cleanup = {
        'schema': 'paper_runtime_cleanup_v678',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
        'policy': 'OPEN/CLOSED ledger preserved; runtime traces/raw temp files are pruned; score/review uses hot rows only.',
        'closed_ledger_preserved': True,
        'score_hot_rows_policy': {'hours': fnum(os.getenv('PAPER_SCORE_HOT_HOURS'), default=24.0), 'tail': _v678_hot_tail_limit('PAPER_SCORE_HOT_ROWS', 420)},
        'jsonl_prune': {},
        'tmp_file_prune': {},
    }
    try:
        targets = {
            'open_alert_trace': (FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl'), max_age_alert, 700),
            'close_alert_trace': (FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl'), max_age_alert, 700),
            'hourly_event_trace': (FILES.get('hourly_event_trace', BASE_DIR / 'paper_bot_hourly_raw_event_trace.jsonl'), max_age_trace, 1200),
            'stop_overrun_trace': (FILES.get('stop_overrun_trace', BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl'), max_age_alert, 500),
        }
        for name, (path, age, lines) in targets.items():
            cleanup['jsonl_prune'][name] = _v678_jsonl_prune(path, age, lines)
        cleanup['tmp_file_prune']['raw_pack_txt'] = _v678_remove_stale_tmp_files('paper_hourly_raw_pack_*.txt', 10 * 60.0)
        cleanup['tmp_file_prune']['summary_tmp_txt'] = _v678_remove_stale_tmp_files('paper_hourly_summary_tmp*.txt', 10 * 60.0)
        cleanup['open_count'] = int(status.get('open_count') or status.get('open_total') or 0) if isinstance(status, dict) else 0
        cleanup['closed_total'] = int(status.get('closed_total') or 0) if isinstance(status, dict) else 0
        cleanup['ok'] = True
        save_json(FILES['cleanup_state'], cleanup)
    except Exception as exc:
        cleanup['ok'] = False
        cleanup['error'] = f'{type(exc).__name__}: {exc}'
        log_error('v678_runtime_cleanup', exc)
    return cleanup




def _v679_seal_existing_hourly_raw_trace() -> Dict[str, Any]:
    """raw pack trace owner seal.

    v632 send trace recorded paper/main delivery before the temp file deletion step,
    so main /health kept showing 삭제 ❔ for already-sent packs.  This is not a
    display fallback: paper_bot rewrites the owner trace with the actual temp-file
    existence result.
    """
    try:
        path = FILES.get('hourly_raw_pack_trace', BASE_DIR / 'paper_bot_hourly_raw_pack_trace.json')
        obj = load_json(path, {}) or {}
        if not isinstance(obj, dict) or not obj:
            return {}
        fn = str(obj.get('filename') or obj.get('file') or '').strip()
        if not fn:
            return obj
        pack_path = BASE_DIR / Path(fn).name
        already_has_delete = ('temp_deleted' in obj or 'deleted' in obj)
        # If the file is gone after a successful send, seal deletion as true.
        deleted = not pack_path.exists()
        if (not already_has_delete) or obj.get('temp_deleted') is None or obj.get('deleted') is None:
            obj = dict(obj)
            obj['temp_deleted'] = bool(deleted)
            obj['deleted'] = bool(deleted)
            obj['delete_error'] = '' if deleted else 'temp_file_still_exists_after_send'
            obj['result'] = 'sent_deleted_resealed_v679' if deleted else 'sent_but_temp_exists_v679'
            obj['raw_delete_owner'] = 'paper_bot_v679_trace_reseal'
            obj['updated_at'] = now_ts()
            obj['updated_at_text'] = iso_ts() if 'iso_ts' in globals() else now_text()
            save_json(path, obj)
        return obj
    except Exception as exc:
        log_error('v679_seal_existing_hourly_raw_trace', exc)
        return {}


def _v678_send_due_hourly_raw_pack() -> None:
    """v678 raw pack owner: 전송 후 삭제 결과를 trace에 확정 봉인한다."""
    try:
        rows = _v628_event_rows() if '_v628_event_rows' in globals() else []
        if not rows:
            return
        cur = _v628_hour_key(now_ts()) if '_v628_hour_key' in globals() else time.strftime('%Y%m%d_%H')
        state = load_json(FILES.get('hourly_sent_state', BASE_DIR / 'paper_bot_hourly_raw_pack_sent.json'), {}) or {}
        sent = set(state.get('sent_hours') or []) if isinstance(state, dict) else set()
        hours = sorted({str(r.get('kst_hour')) for r in rows if isinstance(r, dict) and r.get('kst_hour') and str(r.get('kst_hour')) < cur})
        last_trace: Dict[str, Any] = {}
        for hour in hours:
            if hour in sent:
                continue
            evs = [r for r in rows if isinstance(r, dict) and str(r.get('kst_hour')) == hour]
            if not evs:
                continue
            text = []
            text.append(f'paper 1시간 원문 묶음집 · {hour} KST')
            text.append(f'- paper: {VERSION} / {BUILD_LABEL}')
            text.append(f'- main: {active_main_version()} / patch {active_patch_version()}')
            text.append(f'- events: {len(evs)} / OPEN {sum(1 for e in evs if e.get("kind")=="open")} / CLOSED {sum(1 for e in evs if e.get("kind")=="closed")} / 보류 {sum(1 for e in evs if e.get("kind")=="open_block")}')
            text.append('')
            for i, e in enumerate(evs, 1):
                text.append(f'[{i}] {e.get("kind")} / {e.get("ticker")} / {e.get("phase")} / {e.get("ts_text")}')
                if e.get('note'):
                    text.append('- note: ' + str(e.get('note')))
                msg = str(e.get('message_text') or '').strip()
                text.append(msg if msg else json.dumps(e.get('raw') or e, ensure_ascii=False, indent=2)[:6000])
                text.append('\n---\n')
            path = BASE_DIR / f'paper_hourly_raw_pack_{hour}.txt'
            path.write_text('\n'.join(text), encoding='utf-8')
            ok, err = _v628_send_document(path, f'paper hourly raw pack {hour} / {BUILD_LABEL}') if '_v628_send_document' in globals() else (False, 'send_document_missing')
            deleted = False; delete_error = ''
            try:
                path.unlink(missing_ok=True)
                deleted = not path.exists()
            except Exception as exc:
                delete_error = f'{type(exc).__name__}: {exc}'
                log_error('v678_hourly_pack_delete', exc)
            if ok:
                sent.add(hour)
            else:
                log_error('v678_hourly_pack_send', Exception(str(err)))
            last_trace = {
                'schema': 'paper_hourly_raw_pack_v678_delete_sealed',
                'version': VERSION,
                'build': BUILD_LABEL,
                'updated_at': now_ts(),
                'updated_at_text': iso_ts() if 'iso_ts' in globals() else now_text(),
                'hour': hour,
                'filename': path.name,
                'sent_ok': bool(ok),
                'paper_sent_ok': bool(ok),
                'main_sent_ok': bool(ok),
                'temp_deleted': bool(deleted),
                'deleted': bool(deleted),
                'delete_error': delete_error,
                'send_error': str(err or ''),
                'event_count': len(evs),
                'result': 'sent_deleted' if ok and deleted else ('sent_delete_failed' if ok else 'send_failed_deleted' if deleted else 'send_failed_delete_failed'),
            }
            save_json(FILES.get('hourly_raw_pack_trace', BASE_DIR / 'paper_bot_hourly_raw_pack_trace.json'), last_trace)
        save_json(FILES.get('hourly_sent_state', BASE_DIR / 'paper_bot_hourly_raw_pack_sent.json'), {'schema':'paper_hourly_sent_v678','version':VERSION,'sent_hours':sorted(sent)[-72:], 'updated_at':now_ts(), 'updated_at_text':iso_ts() if 'iso_ts' in globals() else now_text(), 'last_trace': last_trace})
        _v678_jsonl_prune(FILES.get('hourly_event_trace', BASE_DIR / 'paper_bot_hourly_raw_event_trace.jsonl'), 6*3600.0, 1200)
    except Exception as exc:
        log_error('v678_send_due_hourly_raw_pack', exc)


_v628_send_due_hourly_raw_pack = _v678_send_due_hourly_raw_pack  # type: ignore[assignment]


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    """v678 direct owner. 이전 run_cycle wrapper chain을 호출하지 않는다."""
    started = now_ts()
    ctrl = load_control()
    open_pos = load_open()
    quarantined_items = _v739_quarantine_open_positions(open_pos)
    if quarantined_items:
        save_open(open_pos)
    opened_items: List[Dict[str, Any]] = []
    closed_items: List[Dict[str, Any]] = []
    picked_ids: set[str] = set()
    opened_ids: set[str] = set()
    pick_stats: Dict[str, Any] = {}
    latest_rows: List[Dict[str, Any]] = []
    before_closed_count = line_count_cached(FILES['closed'], ttl=0)
    if ctrl.get('running', True):
        # v682: OPEN 청산을 후보선별보다 먼저 처리한다. select_candidates/review가 늦어져도 기존 OPEN 손절이 밀리지 않게 한다.
        for pid, pos in list(open_pos.items()):
            try:
                updated, closed = update_position(pos, ctrl)
                if closed:
                    closed['exit_sweep_owner_v682'] = 'v682_run_cycle_exit_first'
                    closed_items.append(closed)
                    open_pos.pop(pid, None)
                    append_jsonl(FILES['closed'], closed)
                    _LAST_CLOSED_COUNT_CACHE.update({'ts': 0.0, 'count': 0})
                else:
                    open_pos[pid] = updated
            except Exception as exc:
                log_error('v682_update_position_exit_first', exc)
        save_open(open_pos)
        try:
            picked, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        except Exception as exc:
            log_error('v682_select_candidates', exc)
            picked, pick_stats, latest_rows = [], {'select_error': f'{type(exc).__name__}: {exc}'}, []
        # v746: 후보선별이 조금이라도 길어졌으면 OPEN 직전 다시 청산검사부터 수행한다.
        # 청산조건값 변경 없음. 기존 OPEN 감시를 신규 OPEN보다 우선한다.
        try:
            mid_closed_items = []
            for _pid, _pos in list(open_pos.items()):
                try:
                    _updated, _closed = update_position(_pos, ctrl)
                    if _closed:
                        _closed['exit_sweep_owner_v746'] = 'v746_preopen_exit_resweep'
                        _closed['exit_sweep_owner_v682'] = _closed.get('exit_sweep_owner_v682') or 'v746_preopen_exit_resweep'
                        mid_closed_items.append(_closed)
                        open_pos.pop(_pid, None)
                        append_jsonl(FILES['closed'], _closed)
                        _LAST_CLOSED_COUNT_CACHE.update({'ts': 0.0, 'count': 0})
                    else:
                        open_pos[_pid] = _updated
                except Exception as _exc:
                    log_error('v746_preopen_exit_resweep_item', _exc)
            if mid_closed_items:
                closed_items.extend(mid_closed_items)
                save_open(open_pos)
                pick_stats['v746_preopen_exit_resweep_closed'] = len(mid_closed_items)
        except Exception as exc:
            log_error('v746_preopen_exit_resweep', exc)
        latest_rows = [r for r in (latest_rows or []) if isinstance(r, dict)]
        for pid, ev in picked:
            picked_ids.add(pid)
            if pid in open_pos:
                continue
            try:
                pos = open_position(pid, ev)
                open_pos[pid] = pos
                opened_items.append(pos)
                opened_ids.add(pid)
                if _v734_is_hold(ev):
                    _v734_trace_hold(ev, "opened", "paper OPEN 등록", {"pos_id": pid, "ticker": pos.get("ticker"), "entry_price": pos.get("entry_price")})
            except Exception as exc:
                log_error('v682_open_position', exc)
        save_open(open_pos)
    else:
        latest_rows = _v582_active_rows(ctrl) if '_v582_active_rows' in globals() else []
        pick_stats['paused'] = 1
    if not latest_rows:
        try:
            latest_rows = _v582_active_rows(ctrl) if '_v582_active_rows' in globals() else []
        except Exception:
            latest_rows = []
    try:
        snapshot, pick_stats = _v582_make_snapshot(latest_rows, ctrl, pick_stats, open_pos) if '_v582_make_snapshot' in globals() else ({'latest_count': len(latest_rows)}, pick_stats)
    except Exception as exc:
        log_error('v678_make_snapshot', exc)
        snapshot = {'latest_count': len(latest_rows), 'error': f'{type(exc).__name__}: {exc}'}
    try:
        trace_obj = build_trace(latest_rows, ctrl, open_pos, picked_ids, opened_ids)
    except Exception as exc:
        log_error('v678_build_trace', exc)
        trace_obj = _v582_minimal_trace(latest_rows, ctrl, open_pos, f'{type(exc).__name__}: {exc}') if '_v582_minimal_trace' in globals() else {'rows': [], 'error': str(exc)}
    status = {
        'running': bool(ctrl.get('running', True)),
        'loop_seconds': ctrl.get('loop_seconds'),
        'cycle_started_at': started,
        'opened_this_cycle': len(opened_items),
        'quarantined_this_cycle_v742': len(quarantined_items),
        'quarantined_this_cycle_v740': len(quarantined_items),
        'closed_this_cycle': len(closed_items),
        'open_total': len(open_pos),
        'open_count': len(open_pos),
        'open_strict': len(open_pos),
        'closed_total': line_count_cached(FILES['closed'], ttl=0 if closed_items else 60.0),
        'pick_stats': pick_stats,
        's1_hold_source': 'paper_s1_hold_cache.json',
        'elapsed_sec': round(now_ts() - started, 3),
        'engine': 'v701_clean_exit_priority_runtime_owner',
        'legacy_loop': False,
        'legacy_run_cycle_chain_bypassed': True,
        'before_closed_count': before_closed_count,
        'writer': 'v701_exit_first_cycle_spine_writer',
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'paper_fast_near_filter_owner_v677': True,
        'paper_exit_cleanup_owner_v678': True,
        'paper_exit_priority_owner_v682': True,
        'paper_clean_spine_owner_v701': True,
    }
    for pos in opened_items:
        try:
            notify_opened(pos)
        except Exception as exc:
            log_error('v678_notify_opened', exc)
            try: _v567_append_trade_alert_trace('open', pos, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'v678 notify_opened raised')
            except Exception: pass
    for row in closed_items:
        try:
            notify_closed(row)
        except Exception as exc:
            log_error('v678_notify_closed', exc)
            try: _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'v678 notify_closed raised')
            except Exception: pass
    try:
        notify_s1_decision_summary(pick_stats, opened_count=len(opened_items), closed_count=len(closed_items), ctrl=ctrl)
    except Exception as exc:
        log_error('v678_s1_decision_summary', exc)
    try:
        notify_market_hot_summary(ctrl)
    except Exception as exc:
        log_error('v678_market_hot_summary', exc)
    try:
        _v628_send_due_hourly_raw_pack()
        raw_trace_v679 = _v679_seal_existing_hourly_raw_trace()
        if isinstance(raw_trace_v679, dict) and raw_trace_v679:
            status['paper_hourly_raw_pack_trace'] = raw_trace_v679
    except Exception as exc:
        log_error('v679_hourly_raw_due', exc)
    try:
        if '_v631_maybe_send_paper_hourly_summary' in globals():
            _v631_maybe_send_paper_hourly_summary(status)  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v678_hourly_summary_due', exc)
    cleanup = _v678_runtime_cleanup(ctrl, status)
    status['cleanup_state'] = cleanup
    status['cleanup_ok'] = bool(cleanup.get('ok', True)) if isinstance(cleanup, dict) else False
    # v745: final run_cycle이 이전 wrapper chain을 우회하더라도 S1 hold 소비 trace를
    # paper_bot_status.json에 직접 봉인한다. 조건/청산값 변경 없음.
    try:
        if '_v736_reseal_status_snapshot' in globals():
            status = _v736_reseal_status_snapshot(status, pick_stats, open_pos, latest_rows)  # type: ignore[name-defined]
        _now_probe = now_ts()
        _gaps = []
        for _p in (open_pos or {}).values():
            if isinstance(_p, dict):
                _lu = fnum(_p.get('last_update'), default=0.0)
                if _lu > 0:
                    _gaps.append(max(0.0, _now_probe - _lu))
        _stop_rows = read_jsonl_tail(FILES.get('stop_overrun_trace', BASE_DIR / 'paper_bot_stop_overrun_trace.jsonl'), 120)
        _recent30 = 0
        _recent60 = 0
        _loop_suspect = 0
        for _r in _stop_rows:
            if not isinstance(_r, dict):
                continue
            _ts = fnum(_r.get('ts'), _r.get('closed_at'), default=0.0)
            if _ts and _now_probe - _ts <= 1800:
                _recent30 += 1
            if _ts and _now_probe - _ts <= 3600:
                _recent60 += 1
            if fnum(_r.get('position_update_gap_sec'), _r.get('loop_gap_sec'), default=0.0) >= 8.0:
                _loop_suspect += 1
        status.update({
            'writer': 'v746_exit_preopen_priority_refresh_writer',
            'status_spine_schema': 'paper_status_spine_v746_exit_preopen_priority_refresh',
            'paper_hold_trace_summary_owner_v745': True,
            'paper_exit_loopgap_probe_owner_v745': True,
            'paper_exit_preopen_resweep_owner_v746': True,
            'paper_preopen_freshness_guard_owner_v746': True,
            'exit_loop_probe_v746': {
                'schema': 'paper_exit_loop_probe_v746',
                'open_count': len(open_pos or {}),
                'gap_count': len(_gaps),
                'max_open_update_gap_sec': round(max(_gaps), 3) if _gaps else 0.0,
                'avg_open_update_gap_sec': round(sum(_gaps) / len(_gaps), 3) if _gaps else 0.0,
                'preopen_resweep': True,
                'updated_at': _now_probe,
                'updated_at_text': iso_ts(_now_probe) if 'iso_ts' in globals() else now_text(),
            },
            'exit_loop_probe_v745': {
                'schema': 'paper_exit_loop_probe_v745',
                'open_count': len(open_pos or {}),
                'gap_count': len(_gaps),
                'max_open_update_gap_sec': round(max(_gaps), 3) if _gaps else 0.0,
                'avg_open_update_gap_sec': round(sum(_gaps) / len(_gaps), 3) if _gaps else 0.0,
                'updated_at': _now_probe,
                'updated_at_text': iso_ts(_now_probe) if 'iso_ts' in globals() else now_text(),
            },
            'stop_overrun_summary_v745': {
                'schema': 'paper_stop_overrun_summary_v745',
                'tail': len(_stop_rows),
                'recent30m': _recent30,
                'recent60m': _recent60,
                'loop_gap_suspect_tail': _loop_suspect,
                'source': 'paper_bot_stop_overrun_trace.jsonl',
                'rule_change': False,
            },
        })
    except Exception as exc:
        log_error('v745_status_trace_loopgap_seal', exc)
    try:
        if ctrl.get('write_score_cache', True):
            write_score_cache(status)
    except Exception as exc:
        log_error('v678_write_score_cache', exc)
    try:
        if '_v582_write_spine' in globals():
            _v582_write_spine(status, trace_obj, snapshot, pick_stats, open_pos)  # type: ignore[name-defined]
        else:
            save_json(FILES['status'], status)
    except Exception as exc:
        log_error('v678_write_spine', exc)
        try: save_json(FILES['status'], status)
        except Exception: pass
    try:
        log(f"{VERSION} cycle opened={len(opened_items)} quarantined={len(quarantined_items)} closed={len(closed_items)} open={len(open_pos)} elapsed={status['elapsed_sec']}s latest={snapshot.get('latest_count')} writer=v682 cleanup={status.get('cleanup_ok')}")
    except Exception:
        pass
    return status


# =============================================================================
# paper_bot v0.243 / v680: raw pack delete trace owner reseal
# - v679 left some legacy hourly raw traces with deleted/temp_deleted as blank/unknown.
# - The owner is paper_bot, so the owner trace file is resealed here with the
#   actual temp file existence result.  No condition, OPEN gate, or exit rule change.
# =============================================================================
VERSION = 'paper_bot_v0.764'  # v736 neutralized legacy tail stamp
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'  # v736 neutralized legacy tail stamp
PAPER_RAW_TRACE_OWNER_RESEAL_V680 = True


def _v679_seal_existing_hourly_raw_trace() -> Dict[str, Any]:  # type: ignore[override]
    try:
        path = FILES.get('hourly_raw_pack_trace', BASE_DIR / 'paper_bot_hourly_raw_pack_trace.json')
        obj = load_json(path, {}) or {}
        if not isinstance(obj, dict) or not obj:
            return {}
        raw_fn = str(obj.get('filename') or obj.get('file') or obj.get('path') or '').strip()
        old_deleted = obj.get('temp_deleted') if 'temp_deleted' in obj else obj.get('deleted')
        unknown_delete = old_deleted in (None, '', '-', '?', '❔', 'unknown')
        obj = dict(obj)
        if raw_fn:
            pack_path = BASE_DIR / Path(raw_fn).name
            deleted = not pack_path.exists()
            if unknown_delete or obj.get('raw_delete_owner') not in ('paper_bot_v680_trace_reseal', 'paper_bot_v679_trace_reseal'):
                obj['temp_deleted'] = bool(deleted)
                obj['deleted'] = bool(deleted)
                obj['delete_error'] = '' if deleted else 'temp_file_still_exists_after_send'
                prev_result = str(obj.get('result') or obj.get('phase') or '')
                obj['result'] = 'sent_deleted_resealed_v680' if deleted else 'sent_but_temp_exists_v680'
                if prev_result and prev_result != obj['result']:
                    obj['previous_result'] = prev_result
                obj['raw_delete_owner'] = 'paper_bot_v680_trace_reseal'
                obj['updated_at'] = now_ts()
                obj['updated_at_text'] = iso_ts() if 'iso_ts' in globals() else now_text()
                save_json(path, obj)
        else:
            if unknown_delete:
                obj['temp_deleted'] = None
                obj['deleted'] = None
                obj['delete_error'] = 'filename_missing_cannot_verify_temp_delete'
                obj['raw_delete_owner'] = 'paper_bot_v680_trace_reseal_no_filename'
                obj['updated_at'] = now_ts()
                obj['updated_at_text'] = iso_ts() if 'iso_ts' in globals() else now_text()
                save_json(path, obj)
        return obj
    except Exception as exc:
        log_error('v680_seal_existing_hourly_raw_trace', exc)
        return {}


# =============================================================================
# paper_bot v0.754: pre-main patch activation spine
# - v752/v753 entry snapshot/classify/hold fixes were after main() and did not execute while service ran.
# - Move those patches before __main__ so OPEN->CLOSED->classify single spine actually runs.
# =============================================================================


# =============================================================================
# paper_bot v0.752: entry snapshot + line/RR reseal at OPEN owner
# - 목적: CLOSED 분류판이 RR/반응/공식캔들 값을 잃지 않게 OPEN 당시 스냅샷을 평탄화해 봉인한다.
# - OPEN 직전 first/S2 오래됨은 source age와 분리한다. fresh source면 timing 오염으로만 분류하고 구 timing 때문에 차단하지 않는다.
# - 조건/S1·S2·S3/청산/자동매수/BUY_READY/장부 삭제 변경 없음.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'


def _v752_first_known_num(*vals: Any, default: Optional[float] = None) -> Optional[float]:
    for v in vals:
        if v is None or v == '':
            continue
        try:
            x = float(v)
            return x
        except Exception:
            continue
    return default


def _v752_first_dict(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}


def _v752_nested_sources(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Dict[str, Any]]:
    ev = ev if isinstance(ev, dict) else {}
    diag = diag if isinstance(diag, dict) else {}
    pos = pos if isinstance(pos, dict) else {}
    ctx = _v752_first_dict(pos.get('entry_context'), ev.get('entry_context'), diag.get('entry_context'))
    raw = _v752_first_dict(pos.get('raw'), ev.get('raw'))
    cm = _v752_first_dict(pos.get('canonical_metric_row'), ev.get('canonical_metric_row'), ctx.get('canonical_metric_row'), diag.get('canonical_metric_row'))
    levels = _v752_first_dict(pos.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'), ev.get('structure_levels'), cm.get('structure_levels'))
    plan = _v752_first_dict(pos.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'), ev.get('entry_plan'), cm.get('entry_plan'))
    rr = _v752_first_dict(pos.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'), ev.get('risk_reward'), cm.get('risk_reward'))
    osi = _v752_first_dict(pos.get('official_structure_inputs_raw'), ev.get('official_structure_inputs_raw'), ctx.get('official_structure_inputs_raw'), raw.get('official_structure_inputs_raw'))
    return {'pos': pos, 'ev': ev, 'diag': diag, 'ctx': ctx, 'raw': raw, 'cm': cm, 'levels': levels, 'plan': plan, 'rr': rr, 'osi': osi}


def _v752_source_age(ev: Dict[str, Any], base_ts: Optional[float] = None) -> float:
    ev = ev if isinstance(ev, dict) else {}
    ts = _v752_first_known_num(ev.get('candidate_created_at'), ev.get('source_created_at'), ev.get('event_ts'), ev.get('detected_ts'), ev.get('created_at'), ev.get('updated_ts'), default=None)
    if ts is None or ts <= 0:
        return 999999.0
    nowv = float(base_ts or now_ts())
    return max(0.0, nowv - ts)


def _v752_line_snapshot(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    src = _v752_nested_sources(ev, diag, pos)
    levels, plan, rr, ctx, osi = src['levels'], src['plan'], src['rr'], src['ctx'], src['osi']
    gate = src['diag'].get('trigger_gate') if isinstance(src['diag'].get('trigger_gate'), dict) else (pos.get('trigger_gate') if isinstance(pos, dict) and isinstance(pos.get('trigger_gate'), dict) else {})
    entry = _v752_first_known_num((pos or {}).get('entry_price'), gate.get('entry_price'), src['ev'].get('entry_price'), src['ev'].get('current_price'), src['ev'].get('price'), default=0.0) or 0.0
    trigger = _v752_first_known_num(gate.get('trigger_price'), (pos or {}).get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), src['ev'].get('trigger_price'), default=0.0) or 0.0
    target1 = _v752_first_known_num(levels.get('target1_price'), levels.get('target_price'), plan.get('target1_price'), plan.get('target_price'), rr.get('target1_price'), rr.get('target_price'), src['ev'].get('target1_price'), src['ev'].get('target_price'), default=0.0) or 0.0
    target2 = _v752_first_known_num(levels.get('target2_price'), plan.get('target2_price'), rr.get('target2_price'), src['ev'].get('target2_price'), default=0.0) or 0.0
    invalid = _v752_first_known_num(levels.get('invalid_price'), levels.get('stop_price'), plan.get('invalid_price'), plan.get('stop_price'), rr.get('invalid_price'), rr.get('stop_price'), src['ev'].get('invalid_price'), src['ev'].get('stop_price'), default=0.0) or 0.0
    rr_ratio = _v752_first_known_num(rr.get('rr_ratio'), rr.get('risk_reward_ratio'), src['ev'].get('rr_ratio'), src['ev'].get('risk_reward_ratio'), default=None)
    if rr_ratio is None and entry > 0 and target1 > 0 and invalid > 0 and entry > invalid and target1 > entry:
        rr_ratio = (target1 - entry) / (entry - invalid)
    reaction = _v752_first_known_num(src['ev'].get('price_reaction_pct'), src['ev'].get('change_1m_pct'), ctx.get('price_reaction_pct'), ctx.get('change_1m_pct'), src['diag'].get('price_reaction_pct'), default=None)
    micro_age = _v752_first_known_num(src['ev'].get('micro_age_sec'), ctx.get('micro_age_sec'), src['diag'].get('micro_age_sec'), default=None)
    orderflow_age = _v752_first_known_num(src['ev'].get('orderflow_age_sec'), ctx.get('orderflow_age_sec'), src['diag'].get('orderflow_age_sec'), default=None)
    price_reaction_age = _v752_first_known_num(src['ev'].get('price_reaction_age_sec'), ctx.get('price_reaction_age_sec'), src['diag'].get('price_reaction_age_sec'), default=None)
    candle_age = _v752_first_known_num(src['ev'].get('official_candle_age'), osi.get('official_candle_age'), ctx.get('official_candle_age'), src['diag'].get('official_candle_age'), default=None)
    candle_source = str(src['ev'].get('official_candle_source') or osi.get('official_candle_source') or ctx.get('official_candle_source') or src['diag'].get('official_candle_source') or '')
    source_age = _v752_source_age(src['ev'], base_ts=_v752_first_known_num((pos or {}).get('opened_at'), default=None) or now_ts())
    return {
        'schema': 'paper_entry_snapshot_v752_line_resealed',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'sealed_at': now_ts(),
        'sealed_at_text': iso_ts(),
        'ticker': normalize_ticker((pos or {}).get('ticker') or src['ev'].get('ticker') or src['ev'].get('symbol') or src['ev'].get('market')),
        'event_id': src['ev'].get('event_id') or src['ev'].get('event_key') or (pos or {}).get('event_id'),
        'candidate_created_at': src['ev'].get('candidate_created_at'),
        'source_created_at': src['ev'].get('source_created_at'),
        'event_ts': src['ev'].get('event_ts'),
        'source_age_at_open_sec': round(source_age, 3) if source_age < 999999 else source_age,
        'entry_price': entry or None,
        'trigger_price': trigger or None,
        'target1_price': target1 or None,
        'target2_price': target2 or None,
        'invalid_price': invalid or None,
        'rr_ratio': round(float(rr_ratio), 4) if rr_ratio is not None else None,
        'price_reaction_pct': reaction,
        'micro_age_sec': micro_age,
        'orderflow_age_sec': orderflow_age,
        'price_reaction_age_sec': price_reaction_age,
        'official_candle_age': candle_age,
        'official_candle_source': candle_source or None,
        'line_source': 'v752_open_preclose_snapshot_from_diag_ctx_event',
        'structure_levels': _v588_json_safe(levels) if '_v588_json_safe' in globals() else levels,
        'entry_plan': _v588_json_safe(plan) if '_v588_json_safe' in globals() else plan,
        'risk_reward': _v588_json_safe(rr) if '_v588_json_safe' in globals() else rr,
    }


def _v752_apply_entry_snapshot_to_row(row: Dict[str, Any], snap: Dict[str, Any]) -> None:
    if not isinstance(row, dict) or not isinstance(snap, dict):
        return
    row['entry_snapshot'] = snap
    row['entry_snapshot_v752'] = snap
    row['entry_snapshot_schema'] = snap.get('schema')
    # 분류판/score가 깊은 구조를 못 찾아도 같은 값을 읽도록 평탄화한다.
    for k in ('candidate_created_at','source_created_at','event_ts','source_age_at_open_sec','trigger_price','target1_price','target2_price','invalid_price','rr_ratio','price_reaction_pct','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','official_candle_age','official_candle_source'):
        v = snap.get(k)
        if v not in (None, ''):
            row[k] = v
    if snap.get('target1_price') not in (None, ''):
        row['target_price'] = snap.get('target1_price')
    if snap.get('invalid_price') not in (None, ''):
        row['stop_price'] = snap.get('invalid_price')
    if snap.get('rr_ratio') not in (None, ''):
        row['rr'] = snap.get('rr_ratio')
        row['risk_reward_ratio'] = snap.get('rr_ratio')


def _v746_preopen_freshness_reasons(ev: Dict[str, Any], diag: Dict[str, Any], ctrl: Dict[str, Any]) -> List[str]:  # type: ignore[override]
    """v752 runtime replacement for the v746 pre-open guard.
    구 first/S2 timing만 오래된 경우는 차단하지 않고 timing 오염으로 분류한다.
    실제 source row가 오래된 경우만 보류한다.
    """
    reasons: List[str] = []
    diag = diag if isinstance(diag, dict) else {}
    max_event_age = fnum(ctrl.get('paper_preopen_max_event_age_sec'), default=180.0)
    max_timing_age = fnum(ctrl.get('paper_preopen_max_stage_delay_sec'), default=300.0)
    source_age = _v752_source_age(ev)
    diag['paper_preopen_source_age_sec_v752'] = round(source_age, 3) if source_age < 999999 else source_age
    if source_age > max_event_age:
        reasons.append(f'OPEN직전 후보원천 오래됨: source age {source_age:.0f}s > {max_event_age:.0f}s')
    timing = diag.get('entry_timing_spine') if isinstance(diag.get('entry_timing_spine'), dict) else (ev.get('entry_timing_spine') if isinstance(ev.get('entry_timing_spine'), dict) else {})
    if isinstance(timing, dict) and timing:
        first_delay = fnum(timing.get('first_to_now_delay_sec'), default=0.0)
        s2_delay = fnum(timing.get('s2_to_now_delay_sec'), default=0.0)
        max_seen = max(first_delay, s2_delay)
        diag['paper_preopen_timing_check_v752'] = {'first_to_now_delay_sec': first_delay, 's2_to_now_delay_sec': s2_delay, 'max_stage_delay_sec': max_timing_age, 'policy': 'timing-only old does not block fresh source'}
        if max_seen > max_timing_age and source_age <= max_event_age:
            diag['entry_timing_contamination_v752'] = True
            diag['entry_timing_contamination_reason_v752'] = f'fresh source {source_age:.0f}s but legacy timing {max_seen:.0f}s'
        elif max_seen > max_timing_age and source_age > max_event_age:
            diag['entry_timing_stale_with_source_v752'] = True
    else:
        diag['entry_timing_missing_v752'] = True
    # 진입선/목표선은 OPEN 직전 같은 snapshot에서 다시 읽는다.
    snap = _v752_line_snapshot(ev, diag, None)
    diag['entry_snapshot_v752'] = snap
    entry = fnum(snap.get('entry_price'), default=0.0)
    target1 = fnum(snap.get('target1_price'), default=0.0)
    trigger = fnum(snap.get('trigger_price'), default=0.0)
    if entry > 0 and target1 > 0:
        remain = (target1 / entry - 1.0) * 100.0
        diag['paper_preopen_target_remain_pct_v752'] = round(remain, 4)
        min_remain = fnum(ctrl.get('paper_preopen_min_target_remain_pct'), default=0.20)
        if remain < min_remain:
            reasons.append(f'OPEN직전 목표여유 부족: 남은상승 {remain:+.2f}% < {min_remain:+.2f}%')
    if trigger > 0 and entry > 0:
        gap = (entry - trigger) / trigger * 100.0
        diag['paper_preopen_trigger_gap_pct_v752'] = round(gap, 4)
        max_gap = fnum(ctrl.get('paper_preopen_max_trigger_gap_pct'), default=0.60)
        if gap > max_gap:
            reasons.append(f'OPEN직전 방아쇠 과다이탈: gap {gap:+.2f}% > {max_gap:+.2f}%')
    ca = _v752_first_known_num(snap.get('official_candle_age'), default=None)
    if ca is None:
        diag['official_candle_missing_v752'] = True
    else:
        diag['official_candle_age_v752'] = ca
        if ca >= fnum(ctrl.get('paper_final_candle_stale_warn_sec'), default=300.0):
            diag['structure_candle_stale_v752'] = True
    return reasons[:10]


_v752_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v752_prev_open_position(pos_id, ev)
    try:
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        snap = _v752_line_snapshot(ev if isinstance(ev, dict) else {}, diag, pos)
        _v752_apply_entry_snapshot_to_row(pos, snap)
        # 기존 canonical_entry_snapshot도 v752 snapshot을 source_snapshot에 품게 보강한다.
        ces = pos.get('canonical_entry_snapshot') if isinstance(pos.get('canonical_entry_snapshot'), dict) else {}
        if isinstance(ces, dict):
            ces['v752_entry_snapshot'] = snap
            pos['canonical_entry_snapshot'] = ces
    except Exception as exc:
        log_error('v752_open_entry_snapshot', exc)
    return pos


_v752_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    updated, closed = _v752_prev_update_position(pos, ctrl)
    try:
        if isinstance(closed, dict):
            snap = closed.get('entry_snapshot_v752') if isinstance(closed.get('entry_snapshot_v752'), dict) else (updated.get('entry_snapshot_v752') if isinstance(updated, dict) and isinstance(updated.get('entry_snapshot_v752'), dict) else {})
            if not snap:
                raw = closed.get('raw') if isinstance(closed.get('raw'), dict) else {}
                diag = closed.get('entry_diagnostics') if isinstance(closed.get('entry_diagnostics'), dict) else {}
                snap = _v752_line_snapshot(raw, diag, closed)
            _v752_apply_entry_snapshot_to_row(closed, snap)
            closed['closed_keeps_entry_snapshot_v752'] = True
    except Exception as exc:
        log_error('v752_closed_entry_snapshot', exc)
    return updated, closed


# 분류판이 v752 snapshot을 먼저 읽도록 보강한다.
def _v747_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:  # type: ignore[override]
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    snap = row.get('entry_snapshot_v752') if isinstance(row.get('entry_snapshot_v752'), dict) else (row.get('entry_snapshot') if isinstance(row.get('entry_snapshot'), dict) else (row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}))
    mat = row.get('metrics_at_entry') if isinstance(row.get('metrics_at_entry'), dict) else {}
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return raw, snap, mat, ctx


def _v752_write_startup_classify_cache() -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1200) if isinstance(r, dict)]
        status = load_json(FILES['status'], {}) or {}
        save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
    except Exception as exc:
        log_error('v752_startup_classify_cache', exc)

try:
    _v752_write_startup_classify_cache()
except Exception as exc:
    log_error('v752_startup_classify_cache_outer', exc)


# =============================================================================
# paper_bot v0.753: entry snapshot CLOSED spine single owner
# - OPEN snapshot -> OPEN row -> CLOSED row -> classify cache를 한 본선으로 묶는다.
# - legacy CLOSED와 신규 snapshot CLOSED를 분리해 missing 과분류를 막는다.
# - 조건/청산값 변경 없음.
# =============================================================================
def _v754_has_entry_snapshot(row: Dict[str, Any]) -> bool:
    if not isinstance(row, dict):
        return False
    for k in ('entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','entry_snapshot'):
        if isinstance(row.get(k), dict) and row.get(k):
            return True
    return False


def _v754_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    snap: Dict[str, Any] = {}
    for _k in ('entry_snapshot_v754', 'entry_snapshot_v753', 'entry_snapshot_v752', 'entry_snapshot', 'canonical_entry_snapshot'):
        _v = row.get(_k)
        if isinstance(_v, dict) and _v:
            snap = _v
            break
    mat: Dict[str, Any] = {}
    if isinstance(snap.get('materials'), dict):
        mat.update(snap.get('materials') or {})
    if isinstance(row.get('metrics_at_entry'), dict):
        mat.update(row.get('metrics_at_entry') or {})
    for k, v in snap.items():
        if k not in mat:
            mat[k] = v
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return raw, snap, mat, ctx

# 기존 classify helpers가 v753 snapshot을 최우선으로 보게 단일화한다.
def _v747_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:  # type: ignore[override]
    return _v754_nested(row)


def _v747_target_info(row: Dict[str, Any]) -> Tuple[bool, float]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    plan = snap.get('entry_plan') if isinstance(snap.get('entry_plan'), dict) else {}
    levels = snap.get('structure_levels') if isinstance(snap.get('structure_levels'), dict) else {}
    return _v747_pick_num(
        row.get('target_price'), row.get('target1_price'), row.get('target1'), row.get('take_profit_price'), row.get('tp1'),
        snap.get('target1_price'), snap.get('target_price'), snap.get('target1'), snap.get('take_profit_price'), snap.get('tp1'),
        levels.get('target1_price'), levels.get('target_price'), plan.get('target1_price'), plan.get('target_price'),
        raw.get('target_price'), raw.get('target1_price'), raw.get('target1'), raw.get('take_profit_price'), raw.get('tp1'),
        mat.get('target1_price'), mat.get('target_price'), mat.get('target1'), mat.get('take_profit_price'), mat.get('tp1'),
        ctx.get('target_price'), ctx.get('target1_price'), ctx.get('target1'), ctx.get('take_profit_price'), ctx.get('tp1'),
    )


def _v747_stop_info(row: Dict[str, Any]) -> Tuple[bool, float]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    plan = snap.get('entry_plan') if isinstance(snap.get('entry_plan'), dict) else {}
    levels = snap.get('structure_levels') if isinstance(snap.get('structure_levels'), dict) else {}
    return _v747_pick_num(
        row.get('invalid_price'), row.get('stop_price'), row.get('stop_loss_price'), row.get('loss_cut_price'),
        snap.get('invalid_price'), snap.get('stop_price'), snap.get('stop_loss_price'),
        levels.get('invalid_price'), levels.get('stop_price'), plan.get('invalid_price'), plan.get('stop_price'),
        raw.get('invalid_price'), raw.get('stop_price'), raw.get('stop_loss_price'), raw.get('loss_cut_price'),
        mat.get('invalid_price'), mat.get('stop_price'), mat.get('stop_loss_price'), mat.get('loss_cut_price'),
        ctx.get('invalid_price'), ctx.get('stop_price'), ctx.get('stop_loss_price'), ctx.get('loss_cut_price'),
    )


def _v747_rr_info(row: Dict[str, Any]) -> Tuple[bool, float, str]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    rrbox = snap.get('risk_reward') if isinstance(snap.get('risk_reward'), dict) else {}
    ok, rr = _v747_pick_num(
        row.get('rr'), row.get('rr_ratio'), row.get('risk_reward'), row.get('risk_reward_ratio'),
        snap.get('rr_ratio'), snap.get('rr'), snap.get('risk_reward_ratio'),
        rrbox.get('rr_ratio'), rrbox.get('risk_reward_ratio'), rrbox.get('rr'),
        raw.get('rr'), raw.get('rr_ratio'), raw.get('risk_reward'), raw.get('risk_reward_ratio'),
        mat.get('rr_ratio'), mat.get('rr'), mat.get('risk_reward'), mat.get('risk_reward_ratio'),
        ctx.get('rr'), ctx.get('rr_ratio'), ctx.get('risk_reward'), ctx.get('risk_reward_ratio'),
    )
    if ok:
        return True, rr, 'explicit'
    entry = _v747_entry_price(row)
    tok, target = _v747_target_info(row)
    sok, stop = _v747_stop_info(row)
    if entry > 0 and tok and sok:
        reward = target - entry
        risk = entry - stop
        if risk > 0 and reward > 0:
            return True, reward / risk, 'calculated'
    return False, 0.0, 'missing'


def _v747_reaction_info(row: Dict[str, Any]) -> Tuple[bool, float]:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    return _v747_pick_num(
        row.get('entry_price_reaction_pct'), row.get('price_reaction_pct'), row.get('change_1m_pct'), row.get('price_chg_60s'),
        snap.get('price_reaction_pct'), snap.get('change_1m_pct'), snap.get('price_chg_60s'),
        raw.get('entry_price_reaction_pct'), raw.get('price_reaction_pct'), raw.get('change_1m_pct'), raw.get('price_chg_60s'),
        mat.get('price_reaction_pct'), mat.get('change_1m_pct'), mat.get('price_chg_60s'),
        ctx.get('price_reaction_pct'), ctx.get('change_1m_pct'), ctx.get('price_chg_60s'),
    )


def _v747_candle_age(row: Dict[str, Any]) -> float:  # type: ignore[override]
    raw, snap, mat, ctx = _v754_nested(row)
    osi = row.get('official_structure_inputs_raw') if isinstance(row.get('official_structure_inputs_raw'), dict) else {}
    ok, ca = _v747_pick_num(
        row.get('official_candle_age'), snap.get('official_candle_age'), raw.get('official_candle_age'), osi.get('official_candle_age'),
        mat.get('official_candle_age'), ctx.get('official_candle_age')
    )
    return ca if ok else 0.0


def _v754_line_snapshot(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    diag = diag if isinstance(diag, dict) else {}
    pos = pos if isinstance(pos, dict) else {}
    src = _v752_nested_sources(ev if isinstance(ev, dict) else {}, diag, pos)
    ctx = src.get('ctx', {}) if isinstance(src.get('ctx'), dict) else {}
    # v752가 놓친 diag 내부 구조재료를 공식 소스로 포함한다.
    levels = _v752_first_dict(pos.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'), (ev or {}).get('structure_levels'))
    plan = _v752_first_dict(pos.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'), (ev or {}).get('entry_plan'))
    rrbox = _v752_first_dict(pos.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'), (ev or {}).get('risk_reward'))
    osi = _v752_first_dict(pos.get('official_structure_inputs_raw'), diag.get('official_structure_inputs_raw'), (ev or {}).get('official_structure_inputs_raw'), ctx.get('official_structure_inputs_raw'))
    gate = _v752_first_dict(pos.get('trigger_gate'), diag.get('trigger_gate'), (ev or {}).get('trigger_gate'))
    entry = _v752_first_known_num(pos.get('entry_price'), gate.get('entry_price'), (ev or {}).get('entry_price'), (ev or {}).get('current_price'), (ev or {}).get('price'), default=0.0) or 0.0
    trigger = _v752_first_known_num(gate.get('trigger_price'), pos.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), (ev or {}).get('trigger_price'), default=0.0) or 0.0
    target1 = _v752_first_known_num(levels.get('target1_price'), levels.get('target_price'), plan.get('target1_price'), plan.get('target_price'), rrbox.get('target1_price'), rrbox.get('target_price'), (ev or {}).get('target1_price'), (ev or {}).get('target_price'), default=0.0) or 0.0
    target2 = _v752_first_known_num(levels.get('target2_price'), plan.get('target2_price'), rrbox.get('target2_price'), (ev or {}).get('target2_price'), default=0.0) or 0.0
    invalid = _v752_first_known_num(levels.get('invalid_price'), levels.get('stop_price'), plan.get('invalid_price'), plan.get('stop_price'), rrbox.get('invalid_price'), rrbox.get('stop_price'), (ev or {}).get('invalid_price'), (ev or {}).get('stop_price'), default=0.0) or 0.0
    rr_ratio = _v752_first_known_num(rrbox.get('rr_ratio'), rrbox.get('risk_reward_ratio'), (ev or {}).get('rr_ratio'), (ev or {}).get('risk_reward_ratio'), default=None)
    if rr_ratio is None and entry > 0 and target1 > entry and invalid > 0 and invalid < entry:
        rr_ratio = (target1 - entry) / (entry - invalid)
    reaction = _v752_first_known_num((ev or {}).get('price_reaction_pct'), (ev or {}).get('change_1m_pct'), ctx.get('price_reaction_pct'), ctx.get('change_1m_pct'), diag.get('price_reaction_pct'), diag.get('change_1m_pct'), default=None)
    candle_age = _v752_first_known_num((ev or {}).get('official_candle_age'), osi.get('official_candle_age'), ctx.get('official_candle_age'), diag.get('official_candle_age'), default=None)
    candle_source = str((ev or {}).get('official_candle_source') or osi.get('official_candle_source') or ctx.get('official_candle_source') or diag.get('official_candle_source') or '')
    source_age = _v752_source_age(ev if isinstance(ev, dict) else {}, base_ts=_v752_first_known_num(pos.get('opened_at'), default=None) or now_ts())
    return {
        'schema': 'paper_entry_snapshot_v754_closed_spine',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'sealed_at': now_ts(),
        'sealed_at_text': iso_ts(),
        'ticker': normalize_ticker(pos.get('ticker') or (ev or {}).get('ticker') or (ev or {}).get('symbol') or (ev or {}).get('market')),
        'event_id': (ev or {}).get('event_id') or (ev or {}).get('event_key') or pos.get('event_id'),
        'candidate_created_at': (ev or {}).get('candidate_created_at'),
        'source_created_at': (ev or {}).get('source_created_at'),
        'event_ts': (ev or {}).get('event_ts'),
        'source_age_at_open_sec': round(source_age, 3) if source_age < 999999 else source_age,
        'entry_price': entry or None,
        'trigger_price': trigger or None,
        'target1_price': target1 or None,
        'target2_price': target2 or None,
        'invalid_price': invalid or None,
        'rr_ratio': round(float(rr_ratio), 4) if rr_ratio is not None else None,
        'price_reaction_pct': reaction,
        'micro_age_sec': _v752_first_known_num((ev or {}).get('micro_age_sec'), ctx.get('micro_age_sec'), diag.get('micro_age_sec'), default=None),
        'orderflow_age_sec': _v752_first_known_num((ev or {}).get('orderflow_age_sec'), ctx.get('orderflow_age_sec'), diag.get('orderflow_age_sec'), default=None),
        'price_reaction_age_sec': _v752_first_known_num((ev or {}).get('price_reaction_age_sec'), ctx.get('price_reaction_age_sec'), diag.get('price_reaction_age_sec'), default=None),
        'official_candle_age': candle_age,
        'official_candle_source': candle_source or None,
        'line_source': 'v753_same_snapshot_diag_ctx_event',
        'structure_levels': _v588_json_safe(levels) if '_v588_json_safe' in globals() else levels,
        'entry_plan': _v588_json_safe(plan) if '_v588_json_safe' in globals() else plan,
        'risk_reward': _v588_json_safe(rrbox) if '_v588_json_safe' in globals() else rrbox,
        'official_structure_inputs_raw': _v588_json_safe(osi) if '_v588_json_safe' in globals() else osi,
    }

# v752 OPEN/CLOSED wrappers가 호출하는 전역 line snapshot을 v753 본선으로 교체한다.
def _v752_line_snapshot(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    return _v754_line_snapshot(ev, diag, pos)


def _v752_apply_entry_snapshot_to_row(row: Dict[str, Any], snap: Dict[str, Any]) -> None:  # type: ignore[override]
    if not isinstance(row, dict) or not isinstance(snap, dict):
        return
    row['entry_snapshot'] = snap
    row['entry_snapshot_v754'] = snap
    row['entry_snapshot_v753'] = snap
    row['entry_snapshot_v752'] = snap
    row['entry_snapshot_schema'] = snap.get('schema')
    for k in ('candidate_created_at','source_created_at','event_ts','source_age_at_open_sec','trigger_price','target1_price','target2_price','invalid_price','rr_ratio','price_reaction_pct','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','official_candle_age','official_candle_source'):
        v = snap.get(k)
        if v not in (None, ''):
            row[k] = v
    if snap.get('target1_price') not in (None, ''):
        row['target_price'] = snap.get('target1_price')
    if snap.get('invalid_price') not in (None, ''):
        row['stop_price'] = snap.get('invalid_price')
    if snap.get('rr_ratio') not in (None, ''):
        row['rr'] = snap.get('rr_ratio')
        row['risk_reward_ratio'] = snap.get('rr_ratio')
    row['closed_open_snapshot_spine_v754'] = True


def _v747_entry_quality(rows: List[Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    c: Counter = Counter()
    examples: Dict[str, List[str]] = {}
    def mark(key: str, row: Dict[str, Any]) -> None:
        c[key] += 1
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(row.get('ticker') or row.get('symbol') or '-'))
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        if not _v754_has_entry_snapshot(r):
            mark('legacy_without_entry_snapshot', r)
            continue
        mark('snapshot_ready_rows', r)
        age = _v747_timing_age(r)
        source_age = _v751_source_age_for_closed(r)
        if age >= 600 and source_age <= 300:
            mark('timing_field_contaminated', r)
        elif age >= 600:
            mark('old_candidate_entry', r)
        if source_age >= 300 and source_age < 999999:
            mark('old_source_entry', r)
        entry = _v747_entry_price(r)
        tok, target = _v747_target_info(r)
        if entry > 0 and tok and target > 0 and entry >= target * 0.995:
            mark('target_near_or_above_entry', r)
        if _v747_trigger_gap(r) >= 0.60:
            mark('trigger_gap_high', r)
        rr_ok, rr, rr_src = _v747_rr_info(r)
        if rr_ok:
            if rr < 1.20:
                mark('rr_bad_or_missing', r); mark('rr_bad', r)
            if rr_src == 'calculated':
                mark('rr_calculated', r)
        else:
            mark('rr_missing', r)
        reac_ok, reac = _v747_reaction_info(r)
        if reac_ok:
            if reac < 0.15:
                mark('reaction_off_before_entry', r); mark('reaction_off', r)
        else:
            mark('reaction_missing', r)
        ca = _v747_candle_age(r)
        if ca >= 120:
            mark('official_candle_stale_120s', r)
        elif ca <= 0:
            mark('official_candle_missing', r)
    out = dict(c)
    out['top'] = dict(c.most_common(12))
    out['examples'] = examples
    out['precision_policy_v754'] = 'legacy rows without entry_snapshot are not counted as missing materials; new snapshot rows are classified separately'
    return out


def _v749_loss_split(rows: List[Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    loss_rows = [r for r in (rows or []) if isinstance(r, dict) and _v747_closed_bucket(r) in ('stop_loss','fast_fail','time_exit','other_loss')]
    strategy = Counter(); issues = Counter(); examples: Dict[str, List[str]] = {}
    def ex(key: str, row: Dict[str, Any]) -> None:
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(row.get('ticker') or row.get('symbol') or '-'))
    for r in loss_rows:
        sk = str(r.get('strategy') or r.get('strategy_label') or r.get('paper_strategy_key') or r.get('strategy_key') or 'unknown')
        strategy[sk] += 1
        if not _v754_has_entry_snapshot(r):
            issues['구버전snapshot없음'] += 1; ex('구버전snapshot없음', r)
            continue
        if _v751_timing_contaminated(r):
            issues['timing필드오염'] += 1; ex('timing필드오염', r)
        elif _v747_timing_age(r) >= 600:
            issues['오래된후보진입'] += 1; ex('오래된후보진입', r)
        entry = _v747_entry_price(r); tok, target = _v747_target_info(r)
        if entry > 0 and tok and target > 0 and entry >= target * 0.995:
            issues['목표근처진입'] += 1; ex('목표근처진입', r)
        if _v747_trigger_gap(r) >= 0.60:
            issues['방아쇠gap과다'] += 1; ex('방아쇠gap과다', r)
        rr_ok, rr, _ = _v747_rr_info(r)
        if rr_ok and rr < 1.20:
            issues['RR불량'] += 1; ex('RR불량', r)
        elif not rr_ok:
            issues['RR확인불가'] += 1; ex('RR확인불가', r)
        reac_ok, reac = _v747_reaction_info(r)
        if reac_ok and reac < 0.15:
            issues['진입직전반응꺼짐'] += 1; ex('진입직전반응꺼짐', r)
        elif not reac_ok:
            issues['진입반응확인불가'] += 1; ex('진입반응확인불가', r)
        ca = _v747_candle_age(r)
        if ca >= 120:
            issues['공식캔들stale'] += 1; ex('공식캔들stale', r)
        elif ca <= 0:
            issues['공식캔들없음'] += 1; ex('공식캔들없음', r)
    return {'n': len(loss_rows), 'strategy_top': dict(strategy.most_common(10)), 'issue_top': dict(issues.most_common(12)), 'examples': examples}


def _v754_write_startup_classify_cache() -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1200) if isinstance(r, dict)]
        status = load_json(FILES['status'], {}) or {}
        save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
    except Exception as exc:
        log_error('v754_startup_classify_cache', exc)

try:
    _v754_write_startup_classify_cache()
except Exception as exc:
    log_error('v754_startup_classify_cache_outer', exc)


# =============================================================================
# paper_bot v0.755: structure taxonomy classify spine
# - strategy_worker가 봉인한 structure_good/bad/recheck taxonomy를 OPEN snapshot -> CLOSED -> /classify에 보존한다.
# - 조건/청산값 변경 없음. 구조별 승패를 보기 위한 분류판 보강만 한다.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'

def _v755_list_from_any(v: Any) -> List[str]:
    if v in (None, '', [], {}):
        return []
    raw = v if isinstance(v, list) else [v]
    return [str(x).strip() for x in raw if str(x).strip()]

def _v755_first_taxonomy(*objs: Any) -> Dict[str, Any]:
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        tax = obj.get('structure_taxonomy_v755')
        if isinstance(tax, dict) and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
            return tax
    good: List[str] = []
    bad: List[str] = []
    recheck: List[str] = []
    for obj in objs:
        if not isinstance(obj, dict):
            continue
        good += _v755_list_from_any(obj.get('structure_good_tags_v755'))
        bad += _v755_list_from_any(obj.get('structure_bad_tags_v755'))
        recheck += _v755_list_from_any(obj.get('structure_recheck_tags_v755'))
    def uniq(xs: List[str], limit: int = 20) -> List[str]:
        out=[]
        for x in xs:
            if x and x not in out:
                out.append(x)
            if len(out)>=limit:
                break
        return out
    good=uniq(good); bad=uniq(bad); recheck=uniq(recheck)
    side='neutral'
    if good and not bad: side='good'
    elif bad and not good: side='bad'
    elif good and bad: side='mixed'
    elif recheck: side='recheck'
    return {'schema':'structure_taxonomy_v755_snapshot_copy','good':good,'bad':bad,'recheck':recheck,'side':side,'policy':'classification_only_no_threshold_change'}

_v755_prev_line_snapshot = _v752_line_snapshot

def _v752_line_snapshot(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None, pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    snap = _v755_prev_line_snapshot(ev, diag, pos)
    try:
        ev = ev if isinstance(ev, dict) else {}
        diag = diag if isinstance(diag, dict) else {}
        pos = pos if isinstance(pos, dict) else {}
        ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
        raw = ev.get('raw') if isinstance(ev.get('raw'), dict) else {}
        cm = ev.get('canonical_metric_row') if isinstance(ev.get('canonical_metric_row'), dict) else {}
        tax = _v755_first_taxonomy(ev, ctx, raw, cm, diag, pos)
        snap['structure_taxonomy_v755'] = tax
        snap['structure_good_tags_v755'] = tax.get('good') or []
        snap['structure_bad_tags_v755'] = tax.get('bad') or []
        snap['structure_recheck_tags_v755'] = tax.get('recheck') or []
        snap['structure_signal_side_v755'] = tax.get('side') or 'neutral'
    except Exception as exc:
        log_error('v755_line_snapshot_structure_taxonomy', exc)
    return snap

_v755_prev_apply_entry_snapshot_to_row = _v752_apply_entry_snapshot_to_row

def _v752_apply_entry_snapshot_to_row(row: Dict[str, Any], snap: Dict[str, Any]) -> None:  # type: ignore[override]
    _v755_prev_apply_entry_snapshot_to_row(row, snap)
    if not isinstance(row, dict) or not isinstance(snap, dict):
        return
    tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
    if tax:
        row['structure_taxonomy_v755'] = tax
        row['structure_good_tags_v755'] = tax.get('good') or []
        row['structure_bad_tags_v755'] = tax.get('bad') or []
        row['structure_recheck_tags_v755'] = tax.get('recheck') or []
        row['structure_signal_side_v755'] = tax.get('side') or 'neutral'

def _v755_row_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    for key in ('entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','entry_snapshot','canonical_entry_snapshot'):
        obj = row.get(key)
        if isinstance(obj, dict):
            tax = obj.get('structure_taxonomy_v755')
            if isinstance(tax, dict) and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
                return tax
    return _v755_first_taxonomy(row)

def _v755_structure_split(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    buckets: Dict[str, List[Dict[str, Any]]] = {}
    side_counter: Counter = Counter()
    tag_counter: Counter = Counter()
    loss_tag_counter: Counter = Counter()
    examples: Dict[str, List[str]] = {}
    def add_ex(key: str, r: Dict[str, Any]) -> None:
        examples.setdefault(key, [])
        if len(examples[key]) < 5:
            examples[key].append(str(r.get('ticker') or r.get('symbol') or '-'))
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        tax = _v755_row_taxonomy(r)
        side = str(tax.get('side') or 'no_snapshot')
        if not _v754_has_entry_snapshot(r):
            side = 'legacy_without_entry_snapshot'
        side_counter[side] += 1
        buckets.setdefault(side, []).append(r)
        tags = []
        for group_name in ('good','bad','recheck'):
            for t in _v755_list_from_any(tax.get(group_name)):
                key = f'{group_name}:{t}'
                tags.append(key)
                tag_counter[key] += 1
                if _v747_closed_bucket(r) in ('stop_loss','fast_fail','time_exit','other_loss'):
                    loss_tag_counter[key] += 1
                    add_ex(key, r)
    side_stats = {k: _v747_stat_rows(v) for k, v in buckets.items()}
    return {
        'schema': 'structure_profit_split_v755',
        'side_counts': dict(side_counter.most_common(12)),
        'side_stats': side_stats,
        'tag_top': dict(tag_counter.most_common(20)),
        'loss_tag_top': dict(loss_tag_counter.most_common(20)),
        'examples': examples,
        'policy': 'structure taxonomy is classification-only; thresholds unchanged',
    }

_v755_prev_build_classify_cache = _v747_build_classify_cache

def _v747_build_classify_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v755_prev_build_classify_cache(rows, status)
    try:
        rows = [r for r in (rows or []) if isinstance(r, dict)]
        out['structure_split_v755'] = {
            'recent_3h': _v755_structure_split(_v741_recent_rows(rows, 3.0)),
            'recent_6h': _v755_structure_split(_v741_recent_rows(rows, 6.0)),
            'recent_24h': _v755_structure_split(_v741_recent_rows(rows, 24.0)),
        }
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v755: structure good/bad/recheck taxonomy split added without changing thresholds')
        out['notes'] = notes
        out['schema'] = 'paper_classify_board_v755_structure_taxonomy'
    except Exception as exc:
        log_error('v755_build_classify_structure_split', exc)
    return out

def _v755_write_startup_classify_cache() -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1200) if isinstance(r, dict)]
        status = load_json(FILES['status'], {}) or {}
        save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
    except Exception as exc:
        log_error('v755_startup_classify_cache', exc)

try:
    _v755_write_startup_classify_cache()
except Exception as exc:
    log_error('v755_startup_classify_cache_outer', exc)



# =============================================================================
# paper_bot v0.756: CLOSED writer snapshot spine
# - 실제 CLOSED append 경로에서 entry_snapshot을 강제 봉인한다.
# - OPEN row에 snapshot이 없던 포지션도 close 시점의 raw/entry_diagnostics로 재구성한다.
# - classify는 CLOSED row의 snapshot 유무만 기준으로 본다. 조건/청산값 변경 없음.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'


def _v756_snapshot_keys() -> tuple:
    return ('entry_snapshot_v756', 'entry_snapshot_v754', 'entry_snapshot_v753', 'entry_snapshot_v752', 'entry_snapshot', 'canonical_entry_snapshot')


def _v756_existing_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    for k in _v756_snapshot_keys():
        obj = row.get(k)
        if isinstance(obj, dict) and obj:
            return obj
    return {}


def _v756_build_snapshot_from_row(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap = _v756_existing_snapshot(row)
    if snap:
        return snap
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else row
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    if not diag:
        diag = row.get('paper_final_safety_diagnostics') if isinstance(row.get('paper_final_safety_diagnostics'), dict) else {}
    try:
        snap = _v752_line_snapshot(raw if isinstance(raw, dict) else row, diag, row)
    except Exception as exc:
        log_error('v756_build_snapshot_from_row', exc)
        snap = {}
    if not isinstance(snap, dict):
        snap = {}
    if snap:
        snap['schema'] = 'paper_entry_snapshot_v756_closed_writer_spine'
        snap['closed_writer_reconstructed_v756'] = True
        snap['paper_version'] = VERSION
        snap['build'] = BUILD_LABEL
    return snap


def _v756_apply_snapshot(row: Dict[str, Any], snap: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    if not isinstance(snap, dict) or not snap:
        row['entry_snapshot_missing_reason_v756'] = 'snapshot_unavailable_after_reconstruct'
        return row
    try:
        _v752_apply_entry_snapshot_to_row(row, snap)
    except Exception as exc:
        log_error('v756_apply_v752_snapshot', exc)
    row['entry_snapshot'] = snap
    row['entry_snapshot_v756'] = snap
    row['entry_snapshot_v754'] = row.get('entry_snapshot_v754') if isinstance(row.get('entry_snapshot_v754'), dict) else snap
    row['entry_snapshot_schema'] = snap.get('schema') or row.get('entry_snapshot_schema')
    row['closed_writer_snapshot_spine_v756'] = True
    # classify가 깊은 source를 못 찾아도 바로 읽게 평탄화
    for k in ('candidate_created_at','source_created_at','event_ts','source_age_at_open_sec','trigger_price','target1_price','target2_price','invalid_price','rr_ratio','price_reaction_pct','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','official_candle_age','official_candle_source'):
        v = snap.get(k)
        if v not in (None, ''):
            row[k] = v
    if snap.get('target1_price') not in (None, ''):
        row['target_price'] = snap.get('target1_price')
    if snap.get('invalid_price') not in (None, ''):
        row['stop_price'] = snap.get('invalid_price')
    if snap.get('rr_ratio') not in (None, ''):
        row['rr'] = snap.get('rr_ratio')
        row['risk_reward_ratio'] = snap.get('rr_ratio')
    return row


def _v756_prepare_position_snapshot(pos: Dict[str, Any], ev: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not isinstance(pos, dict):
        return pos
    ev = ev if isinstance(ev, dict) else (pos.get('raw') if isinstance(pos.get('raw'), dict) else pos)
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    try:
        snap = _v752_line_snapshot(ev if isinstance(ev, dict) else pos, diag, pos)
        if isinstance(snap, dict) and snap:
            snap['schema'] = 'paper_entry_snapshot_v756_open_writer_spine'
            snap['paper_version'] = VERSION
            snap['build'] = BUILD_LABEL
            _v756_apply_snapshot(pos, snap)
    except Exception as exc:
        log_error('v756_prepare_position_snapshot', exc)
    return pos


def _v756_prepare_closed_row(row: Dict[str, Any], source_pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    # CLOSED row 우선, 없으면 source OPEN row에서 snapshot/raw/diag를 끌어온다.
    snap = _v756_existing_snapshot(row)
    if not snap and isinstance(source_pos, dict):
        snap = _v756_existing_snapshot(source_pos)
        if snap:
            row.setdefault('entry_snapshot_source_v756', 'source_open_position')
    if not snap:
        base = dict(source_pos) if isinstance(source_pos, dict) else row
        for k, v in row.items():
            base[k] = v
        snap = _v756_build_snapshot_from_row(base)
        row.setdefault('entry_snapshot_source_v756', 'closed_writer_reconstructed')
    _v756_apply_snapshot(row, snap)
    row['closed_writer_snapshot_spine_v756'] = True
    row['closed_paper_version'] = VERSION
    row['close_build_label_v756'] = BUILD_LABEL
    return row


_v756_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v756_prev_open_position(pos_id, ev)
    return _v756_prepare_position_snapshot(pos, ev)


_v756_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    updated, closed = _v756_prev_update_position(pos, ctrl)
    if isinstance(closed, dict):
        closed = _v756_prepare_closed_row(closed, updated if isinstance(updated, dict) else pos)
    return updated, closed


_v756_prev_append_jsonl = append_jsonl

def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:  # type: ignore[override]
    try:
        closed_path = FILES.get('closed')
        if closed_path is not None and Path(path) == Path(closed_path) and isinstance(obj, dict):
            obj = _v756_prepare_closed_row(obj)
    except Exception as exc:
        log_error('v756_append_closed_prepare', exc)
    _v756_prev_append_jsonl(path, obj)
    try:
        closed_path = FILES.get('closed')
        if closed_path is not None and Path(path) == Path(closed_path):
            rows = [r for r in read_jsonl_tail(FILES['closed'], 1200) if isinstance(r, dict)]
            status = load_json(FILES['status'], {}) or {}
            save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
    except Exception as exc:
        log_error('v756_append_closed_refresh_classify', exc)


# v756: classify helpers가 v756 snapshot을 최우선으로 보게 단일화

def _v754_has_entry_snapshot(row: Dict[str, Any]) -> bool:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    for k in _v756_snapshot_keys():
        obj = row.get(k)
        if isinstance(obj, dict) and obj:
            return True
    return False


def _v752_row_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    return _v756_existing_snapshot(row)


_v756_prev_v755_row_taxonomy = _v755_row_taxonomy if '_v755_row_taxonomy' in globals() else None

def _v755_row_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    snap = row.get('entry_snapshot_v756') if isinstance(row.get('entry_snapshot_v756'), dict) else {}
    if snap:
        tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
        if tax and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
            return tax
    if _v756_prev_v755_row_taxonomy:
        return _v756_prev_v755_row_taxonomy(row)
    return _v755_first_taxonomy(row)


def _v756_write_startup_classify_cache() -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1200) if isinstance(r, dict)]
        status = load_json(FILES['status'], {}) or {}
        save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
    except Exception as exc:
        log_error('v756_startup_classify_cache', exc)

try:
    _v756_write_startup_classify_cache()
except Exception as exc:
    log_error('v756_startup_classify_cache_outer', exc)



# =============================================================================
# paper_bot v0.757: classify CLOSED source ledger-snapshot spine
# - 원인: score/review/classify reconciled rows가 close_alert 복구 row를 섞어 읽으면
#   실제 CLOSED ledger snapshot이 있어도 /classify에서 legacy_without_entry_snapshot로 보일 수 있었다.
# - 수정: classify/score/review의 CLOSED source를 ledger snapshot 우선으로 병합한다.
# - ledger와 alert가 같은 거래면 ledger row를 주인으로 두고, alert는 누락 필드만 보조한다.
# - alert-only 복구 row는 snapshot 없음을 alert_recovered_no_snapshot으로 분리한다.
# - 조건/청산/S1/S2/S3/자동매수/장부 삭제 변경 없음.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'


def _v757_text_has_v756plus(*vals: Any) -> bool:
    blob = ' '.join(str(v or '') for v in vals)
    return any(x in blob for x in ('v0.756', 'v0.757', 'v756_', 'v757_', 'paper_bot_v0.756', 'paper_bot_v0.764'))


def _v757_row_has_v756plus_marker(row: Dict[str, Any]) -> bool:
    row = row if isinstance(row, dict) else {}
    keys = (
        'version','paper_version','closed_paper_version','opened_paper_version','source_alert_version',
        'build','source_alert_build','close_build_label_v756','close_build_label_v757',
        'entry_snapshot_source_v756','closed_writer_snapshot_spine_v756','classify_source_owner_v757'
    )
    vals = [row.get(k) for k in keys]
    for parent in ('entry_snapshot','entry_snapshot_v756','entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','canonical_entry_snapshot'):
        obj = row.get(parent)
        if isinstance(obj, dict):
            vals += [obj.get('paper_version'), obj.get('build'), obj.get('schema')]
    return _v757_text_has_v756plus(*vals)


def _v757_row_key(row: Dict[str, Any]) -> str:
    try:
        k = _v607_row_key(row) if '_v607_row_key' in globals() else ''
        if k:
            return str(k)
    except Exception:
        pass
    ticker = normalize_ticker((row or {}).get('ticker') or (row or {}).get('symbol') or '')
    opened = fnum((row or {}).get('opened_at'), default=0.0)
    closed = fnum((row or {}).get('closed_at'), (row or {}).get('ts'), default=0.0)
    pnl = fnum((row or {}).get('pnl_pct'), (row or {}).get('profit_pct'), default=0.0)
    return f'fallback:{ticker}:{round(opened,1)}:{round(closed,1)}:{round(pnl,4)}'


def _v757_has_snapshot(row: Dict[str, Any]) -> bool:
    try:
        return bool(_v756_existing_snapshot(row)) if '_v756_existing_snapshot' in globals() else bool(_v754_has_entry_snapshot(row))
    except Exception:
        return False


def _v757_prepare_classify_row(row: Dict[str, Any], source: str = 'ledger') -> Dict[str, Any]:
    out = dict(row or {})
    out['classify_source_owner_v757'] = 'ledger_snapshot_priority'
    out['classify_row_source_v757'] = source
    if _v757_has_snapshot(out):
        out['classify_snapshot_state_v757'] = 'snapshot_present'
        return out
    if source == 'ledger' and _v757_row_has_v756plus_marker(out):
        try:
            out = _v756_prepare_closed_row(out) if '_v756_prepare_closed_row' in globals() else out
        except Exception as exc:
            log_error('v757_prepare_ledger_snapshot', exc)
        if _v757_has_snapshot(out):
            out['classify_snapshot_state_v757'] = 'ledger_reconstructed_snapshot'
            out['entry_snapshot_source_v757'] = out.get('entry_snapshot_source_v756') or 'ledger_reader_reconstructed'
            return out
        out['classify_snapshot_state_v757'] = 'v756plus_ledger_snapshot_missing_after_reconstruct'
        return out
    if source == 'alert_recovered':
        out['classify_snapshot_state_v757'] = 'alert_recovered_no_snapshot'
        out['alert_recovered_no_snapshot_v757'] = True
        return out
    out['classify_snapshot_state_v757'] = 'legacy_without_entry_snapshot'
    return out


def _v757_merge_alert_into_ledger(ledger_row: Dict[str, Any], alert_row: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(ledger_row or {})
    alert_row = alert_row if isinstance(alert_row, dict) else {}
    for k in ('source_alert_phase','source_alert_version','source_alert_build','close_alert_sent','alert_sent','message_id'):
        if out.get(k) in (None, '') and alert_row.get(k) not in (None, ''):
            out[k] = alert_row.get(k)
    # 알림에는 있지만 장부에는 없는 표시값만 보조로 붙인다. snapshot/진입값은 ledger 우선.
    for k in ('closed_at_text','exit_reason','exit_rule','strategy','strategy_label'):
        if out.get(k) in (None, '', '-') and alert_row.get(k) not in (None, '', '-'):
            out[k] = alert_row.get(k)
    out['alert_merged_into_ledger_v757'] = True
    return out


def _v757_hot_filter(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        return _v678_hot_closed_filter(rows, now_ts()) if '_v678_hot_closed_filter' in globals() else rows
    except Exception:
        return rows


def _v757_reconciled_closed_rows(limit_closed: int = 720, limit_alert: int = 720) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    ledger_raw = [r for r in read_jsonl_tail(FILES['closed'], limit_closed) if isinstance(r, dict)]
    ledger_rows = [_v757_prepare_classify_row(r, 'ledger') for r in _v757_hot_filter(ledger_raw)]
    ledger_by_key: Dict[str, Dict[str, Any]] = {}
    for r in ledger_rows:
        k = _v757_row_key(r)
        if k:
            ledger_by_key[k] = r
    raw_alerts: List[Dict[str, Any]] = []
    try:
        ap = _v607_close_alert_trace_path() if '_v607_close_alert_trace_path' in globals() else FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl')
        raw_alerts = [r for r in read_jsonl_tail(ap, limit_alert) if isinstance(r, dict) and str(r.get('kind') or '').lower() == 'closed']
    except Exception as exc:
        log_error('v757_reconcile_alert_read', exc)
    alert_hot = _v757_hot_filter(raw_alerts)
    phase_rank = {'send_ok': 3, 'attempt_start': 2, 'without_alert_trace': 1, 'send_error': 0, 'message_build_error': 0}
    best: Dict[str, Dict[str, Any]] = {}
    for r in alert_hot:
        k = _v757_row_key(r)
        if not k:
            continue
        cur = best.get(k)
        if not cur or phase_rank.get(str(r.get('phase') or ''), 0) >= phase_rank.get(str(cur.get('phase') or ''), 0):
            best[k] = r
    recovered: List[Dict[str, Any]] = []
    merged_alerts = 0
    for k, alert in best.items():
        if k in ledger_by_key:
            ledger_by_key[k] = _v757_merge_alert_into_ledger(ledger_by_key[k], alert)
            merged_alerts += 1
            continue
        try:
            cr = _v607_alert_to_closed_row(alert) if '_v607_alert_to_closed_row' in globals() else dict(alert)
            if cr.get('ticker') and fnum(cr.get('closed_at'), cr.get('ts'), default=0.0) > 0:
                recovered.append(_v757_prepare_classify_row(cr, 'alert_recovered'))
        except Exception as exc:
            log_error('v757_alert_to_closed_row', exc)
    rows = list(ledger_by_key.values()) + recovered
    rows = _v757_hot_filter(rows)
    rows.sort(key=lambda x: fnum(x.get('closed_at'), x.get('ts'), default=0.0))
    snap_count = sum(1 for r in rows if _v757_has_snapshot(r))
    legacy_count = sum(1 for r in rows if str(r.get('classify_snapshot_state_v757') or '') in ('legacy_without_entry_snapshot','alert_recovered_no_snapshot'))
    meta = {
        'schema': 'paper_closed_source_reconcile_v757_ledger_snapshot_priority',
        'version': VERSION,
        'build': BUILD_LABEL,
        'ledger_tail_read': len(ledger_raw),
        'ledger_hot_count': len(ledger_rows),
        'alert_trace_tail_read': len(raw_alerts),
        'alert_unique_count': len(best),
        'alert_merged_into_ledger': merged_alerts,
        'alert_recovered_count': len(recovered),
        'snapshot_rows': snap_count,
        'legacy_or_alert_no_snapshot_rows': legacy_count,
        'source_policy': 'classify/score/review use CLOSED ledger row first; close_alert rows only recover missing ledger rows and never override ledger snapshot',
    }
    return rows, meta


# score/review/classify가 모두 같은 ledger-snapshot 우선 rows를 보게 한다.
_v630_reconciled_rows = _v757_reconciled_closed_rows  # type: ignore[assignment]
_v607_reconciled_closed_rows = lambda limit_closed=720, limit_alert=720: _v757_reconciled_closed_rows(limit_closed, limit_alert)  # type: ignore[assignment]


_v757_prev_append_jsonl = append_jsonl

def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:  # type: ignore[override]
    closed_path = FILES.get('closed')
    is_closed = False
    try:
        is_closed = closed_path is not None and Path(path) == Path(closed_path)
    except Exception:
        is_closed = False
    if is_closed and isinstance(obj, dict):
        obj = _v757_prepare_classify_row(obj, 'ledger')
        obj['closed_writer_snapshot_spine_v757'] = True
        obj['closed_paper_version'] = VERSION
        obj['close_build_label_v757'] = BUILD_LABEL
    _v757_prev_append_jsonl(path, obj)
    if is_closed:
        try:
            rows, _rec = _v757_reconciled_closed_rows()
            status = load_json(FILES['status'], {}) or {}
            save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), _v747_build_classify_cache(rows, status))
        except Exception as exc:
            log_error('v757_append_closed_refresh_classify', exc)


def _v757_write_startup_classify_cache() -> None:
    try:
        rows, _rec = _v757_reconciled_closed_rows()
        status = load_json(FILES['status'], {}) or {}
        obj = _v747_build_classify_cache(rows, status)
        obj['closed_source_reconcile_v757'] = _rec
        save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), obj)
    except Exception as exc:
        log_error('v757_startup_classify_cache', exc)

try:
    _v757_write_startup_classify_cache()
except Exception as exc:
    log_error('v757_startup_classify_cache_outer', exc)



# =============================================================================
# paper_bot v0.758: classify ledger snapshot rebuild single source
# - 반복 원인: CLOSED 원장에 OPEN snapshot이 없거나 classify reader가 legacy row를 보면 구조분류가 계속 안 보였다.
# - 수정: /classify 입구에서 CLOSED ledger row를 단일 source로 삼고, row 안의 raw/entry_context/entry_diagnostics/flat 필드로 snapshot을 재구성한다.
# - ledger 원장 삭제/성과값/조건/청산값/S등급 변경 없음.
# - close_alert_trace는 원장에 없는 거래 복구용 보조로만 사용하고, 구조분류 주인은 ledger snapshot row다.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'


def _v758_snapshot_keys() -> tuple:
    return ('entry_snapshot_v758','entry_snapshot_v756','entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','entry_snapshot','canonical_entry_snapshot')


def _v758_existing_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    for k in _v758_snapshot_keys():
        obj = row.get(k)
        if isinstance(obj, dict) and obj:
            return obj
    return {}


def _v758_meaningful_snapshot(snap: Dict[str, Any]) -> bool:
    if not isinstance(snap, dict) or not snap:
        return False
    for k in ('entry_price','trigger_price','target1_price','target_price','invalid_price','rr_ratio','price_reaction_pct','official_candle_age','official_candle_source'):
        v = snap.get(k)
        if v not in (None, '', 0, 0.0):
            return True
    return bool(snap.get('structure_taxonomy_v755'))


def _v758_build_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap = _v758_existing_snapshot(row)
    if snap:
        return snap
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else row
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    if not diag:
        diag = row.get('paper_final_safety_diagnostics') if isinstance(row.get('paper_final_safety_diagnostics'), dict) else {}
    # CLOSED row의 flat 필드와 entry_context를 diag 보조 재료로 합친다.
    try:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        for k in ('structure_levels','entry_plan','risk_reward','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','official_candle_age','official_candle_source'):
            if k not in diag and row.get(k) not in (None, '', [], {}):
                diag[k] = row.get(k)
            if k not in diag and ctx.get(k) not in (None, '', [], {}):
                diag[k] = ctx.get(k)
    except Exception:
        pass
    try:
        if '_v752_line_snapshot' in globals():
            snap = _v752_line_snapshot(raw if isinstance(raw, dict) else row, diag, row)  # type: ignore[name-defined]
        elif '_v756_build_snapshot_from_row' in globals():
            snap = _v756_build_snapshot_from_row(row)  # type: ignore[name-defined]
        else:
            snap = {}
    except Exception as exc:
        log_error('v758_build_snapshot', exc)
        snap = {}
    if not isinstance(snap, dict):
        snap = {}
    if snap:
        snap['schema'] = 'paper_entry_snapshot_v758_classify_ledger_rebuild'
        snap['paper_version'] = VERSION
        snap['build'] = BUILD_LABEL
        snap['classify_rebuilt_v758'] = True
    return snap


def _v758_apply_snapshot(row: Dict[str, Any], snap: Dict[str, Any], source: str = 'ledger') -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    if not isinstance(snap, dict) or not snap:
        row['classify_snapshot_state_v758'] = 'snapshot_unavailable'
        return row
    try:
        if '_v752_apply_entry_snapshot_to_row' in globals():
            _v752_apply_entry_snapshot_to_row(row, snap)  # type: ignore[name-defined]
    except Exception as exc:
        log_error('v758_apply_v752_snapshot', exc)
    row['entry_snapshot'] = snap
    row['entry_snapshot_v758'] = snap
    row.setdefault('entry_snapshot_v756', snap)
    row['entry_snapshot_schema'] = snap.get('schema') or row.get('entry_snapshot_schema')
    row['classify_snapshot_state_v758'] = 'snapshot_present' if source == 'ledger_original' else 'ledger_rebuilt_snapshot'
    row['classify_row_source_v758'] = source
    row['classify_snapshot_rebuild_v758'] = source != 'ledger_original'
    row['classify_source_owner_v758'] = 'closed_ledger_snapshot_rebuild_single_source'
    # 구조 taxonomy는 snapshot에도 row에도 복사한다.
    try:
        tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else None
        if tax:
            row['structure_taxonomy_v755'] = tax
            row['structure_good_tags_v755'] = tax.get('good') or []
            row['structure_bad_tags_v755'] = tax.get('bad') or []
            row['structure_recheck_tags_v755'] = tax.get('recheck') or []
            row['structure_signal_side_v755'] = tax.get('side') or 'neutral'
    except Exception:
        pass
    return row


def _v758_prepare_classify_ledger_row(row: Dict[str, Any], source: str = 'ledger') -> Dict[str, Any]:
    out = dict(row or {})
    existing = _v758_existing_snapshot(out)
    if existing:
        return _v758_apply_snapshot(out, existing, 'ledger_original')
    snap = _v758_build_snapshot(out)
    if _v758_meaningful_snapshot(snap):
        return _v758_apply_snapshot(out, snap, source)
    out['classify_snapshot_state_v758'] = 'legacy_without_rebuildable_snapshot'
    out['classify_row_source_v758'] = source
    out['classify_source_owner_v758'] = 'closed_ledger_snapshot_rebuild_single_source'
    return out


# classify helpers가 v758 snapshot을 최우선으로 보게 단일화한다.
def _v754_has_entry_snapshot(row: Dict[str, Any]) -> bool:  # type: ignore[override]
    return bool(_v758_existing_snapshot(row))


def _v752_row_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    return _v758_existing_snapshot(row)


def _v747_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    snap = _v758_existing_snapshot(row)
    mat: Dict[str, Any] = {}
    if isinstance(snap.get('materials'), dict):
        mat.update(snap.get('materials') or {})
    if isinstance(row.get('metrics_at_entry'), dict):
        mat.update(row.get('metrics_at_entry') or {})
    for k, v in snap.items():
        if k not in mat:
            mat[k] = v
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return raw, snap, mat, ctx


_v758_prev_v755_row_taxonomy = _v755_row_taxonomy if '_v755_row_taxonomy' in globals() else None

def _v755_row_taxonomy(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    snap = _v758_existing_snapshot(row)
    tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
    if tax and (tax.get('good') or tax.get('bad') or tax.get('recheck')):
        return tax
    if _v758_prev_v755_row_taxonomy:
        return _v758_prev_v755_row_taxonomy(row)
    return _v755_first_taxonomy(row) if '_v755_first_taxonomy' in globals() else {'good': [], 'bad': [], 'recheck': [], 'side': 'neutral'}


def _v758_row_key(row: Dict[str, Any]) -> str:
    try:
        k = _v607_row_key(row) if '_v607_row_key' in globals() else ''
        if k:
            return str(k)
    except Exception:
        pass
    ticker = normalize_ticker((row or {}).get('ticker') or (row or {}).get('symbol') or '')
    opened = fnum((row or {}).get('opened_at'), default=0.0)
    closed = fnum((row or {}).get('closed_at'), (row or {}).get('ts'), default=0.0)
    pnl = fnum((row or {}).get('pnl_pct'), (row or {}).get('profit_pct'), default=0.0)
    return f'v758:{ticker}:{round(opened,1)}:{round(closed,1)}:{round(pnl,4)}'


def _v758_hot_filter(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    try:
        return _v678_hot_closed_filter(rows, now_ts()) if '_v678_hot_closed_filter' in globals() else rows
    except Exception:
        return rows


def _v758_reconciled_closed_rows(limit_closed: int = 900, limit_alert: int = 300) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    ledger_raw = [r for r in read_jsonl_tail(FILES['closed'], limit_closed) if isinstance(r, dict)]
    ledger_rows = [_v758_prepare_classify_ledger_row(r, 'ledger_rebuilt') for r in _v758_hot_filter(ledger_raw)]
    ledger_by_key: Dict[str, Dict[str, Any]] = {}
    for r in ledger_rows:
        k = _v758_row_key(r)
        if k:
            ledger_by_key[k] = r
    # alert는 ledger에 없는 row만 복구하되, 구조분류 주인은 아니다.
    raw_alerts: List[Dict[str, Any]] = []
    try:
        ap = _v607_close_alert_trace_path() if '_v607_close_alert_trace_path' in globals() else FILES.get('close_alert_trace', BASE_DIR / 'paper_bot_close_alert_trace.jsonl')
        raw_alerts = [r for r in read_jsonl_tail(ap, limit_alert) if isinstance(r, dict) and str(r.get('kind') or '').lower() == 'closed']
    except Exception as exc:
        log_error('v758_reconcile_alert_read', exc)
    recovered: List[Dict[str, Any]] = []
    best: Dict[str, Dict[str, Any]] = {}
    phase_rank = {'send_ok': 3, 'attempt_start': 2, 'without_alert_trace': 1, 'send_error': 0, 'message_build_error': 0}
    for r in _v758_hot_filter(raw_alerts):
        k = _v758_row_key(r)
        cur = best.get(k)
        if not cur or phase_rank.get(str(r.get('phase') or ''), 0) >= phase_rank.get(str(cur.get('phase') or ''), 0):
            best[k] = r
    for k, alert in best.items():
        if k in ledger_by_key:
            ledger_by_key[k]['alert_merged_v758'] = True
            continue
        try:
            cr = _v607_alert_to_closed_row(alert) if '_v607_alert_to_closed_row' in globals() else dict(alert)
            if cr.get('ticker') and fnum(cr.get('closed_at'), cr.get('ts'), default=0.0) > 0:
                rr = _v758_prepare_classify_ledger_row(cr, 'alert_recovered_rebuilt')
                rr['alert_recovered_no_ledger_v758'] = True
                recovered.append(rr)
        except Exception as exc:
            log_error('v758_alert_to_closed_row', exc)
    rows = list(ledger_by_key.values()) + recovered
    rows = _v758_hot_filter(rows)
    rows.sort(key=lambda x: fnum(x.get('closed_at'), x.get('ts'), default=0.0))
    snapshot_rows = sum(1 for r in rows if _v758_existing_snapshot(r))
    rebuilt_rows = sum(1 for r in rows if r.get('classify_snapshot_rebuild_v758'))
    original_rows = sum(1 for r in rows if str(r.get('classify_snapshot_state_v758') or '') == 'snapshot_present')
    legacy_rows = sum(1 for r in rows if not _v758_existing_snapshot(r))
    meta = {
        'schema': 'paper_closed_source_reconcile_v758_ledger_rebuild_source',
        'version': VERSION,
        'build': BUILD_LABEL,
        'ledger_tail_read': len(ledger_raw),
        'ledger_hot_count': len(ledger_rows),
        'alert_trace_tail_read': len(raw_alerts),
        'alert_recovered_count': len(recovered),
        'snapshot_rows': snapshot_rows,
        'snapshot_original_rows': original_rows,
        'snapshot_rebuilt_rows': rebuilt_rows,
        'legacy_without_rebuildable_snapshot_rows': legacy_rows,
        'source_policy': 'classify uses CLOSED ledger rows; missing entry_snapshot is rebuilt once from ledger raw/entry_context/entry_diagnostics/flat fields for classification only',
    }
    return rows, meta


_v630_reconciled_rows = _v758_reconciled_closed_rows  # type: ignore[assignment]
_v607_reconciled_closed_rows = lambda limit_closed=900, limit_alert=300: _v758_reconciled_closed_rows(limit_closed, limit_alert)  # type: ignore[assignment]


_v758_prev_append_jsonl = append_jsonl

def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:  # type: ignore[override]
    closed_path = FILES.get('closed')
    is_closed = False
    try:
        is_closed = closed_path is not None and Path(path) == Path(closed_path)
    except Exception:
        is_closed = False
    if is_closed and isinstance(obj, dict):
        obj = _v758_prepare_classify_ledger_row(obj, 'closed_writer_rebuilt')
        obj['closed_writer_snapshot_spine_v758'] = True
        obj['closed_paper_version'] = VERSION
        obj['close_build_label_v758'] = BUILD_LABEL
    _v758_prev_append_jsonl(path, obj)
    if is_closed:
        try:
            rows, rec = _v758_reconciled_closed_rows()
            status = load_json(FILES['status'], {}) or {}
            cache = _v747_build_classify_cache(rows, status)
            cache['closed_source_reconcile_v758'] = rec
            save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), cache)
        except Exception as exc:
            log_error('v758_append_closed_refresh_classify', exc)


def _v758_write_startup_classify_cache() -> None:
    try:
        rows, rec = _v758_reconciled_closed_rows()
        status = load_json(FILES['status'], {}) or {}
        cache = _v747_build_classify_cache(rows, status)
        cache['closed_source_reconcile_v758'] = rec
        save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), cache)
    except Exception as exc:
        log_error('v758_startup_classify_cache', exc)

try:
    _v758_write_startup_classify_cache()
except Exception as exc:
    log_error('v758_startup_classify_cache_outer', exc)




# =============================================================================
# paper_bot v0.759: snapshot flatten + structure-line audit reader
# - v758에서 CLOSED ledger 입구는 잡혔지만 canonical snapshot 내부(metrics/structure/levels)를 평탄화하지 못했다.
# - /classify는 entry_snapshot 껍데기가 아니라 RR/반응/구조태그/구조선 source가 실제로 있는지 본다.
# - 조건/청산/S1/S2/S3 기준 변경 없음.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'

_v759_prev_v758_existing_snapshot = _v758_existing_snapshot if '_v758_existing_snapshot' in globals() else None


def _v759_d(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}


def _v759_list(v: Any) -> List[str]:
    out: List[str] = []
    if isinstance(v, list):
        src = v
    elif isinstance(v, tuple):
        src = list(v)
    elif isinstance(v, str) and v.strip():
        src = [x.strip() for x in v.replace('|','/').split('/')]
    else:
        src = []
    for x in src:
        txt = str(x).strip()
        if txt and txt not in out:
            out.append(txt)
    return out


def _v759_num(*vals: Any, default: Optional[float] = None) -> Optional[float]:
    for v in vals:
        if v in (None, ''):
            continue
        try:
            return float(str(v).replace(',', '').replace('%',''))
        except Exception:
            continue
    return default


def _v759_original_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    if _v759_prev_v758_existing_snapshot:
        try:
            snap = _v759_prev_v758_existing_snapshot(row)  # type: ignore[misc]
            if isinstance(snap, dict) and snap:
                return snap
        except Exception:
            pass
    for k in ('entry_snapshot_v758','entry_snapshot_v756','entry_snapshot_v754','entry_snapshot_v753','entry_snapshot_v752','entry_snapshot','canonical_entry_snapshot'):
        obj = row.get(k)
        if isinstance(obj, dict) and obj:
            return obj
    return {}


def _v759_structure_line_audit(row: Dict[str, Any], snap: Dict[str, Any], levels: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap = snap if isinstance(snap, dict) else {}
    levels = levels if isinstance(levels, dict) else {}
    struct = _v759_d(snap.get('structure'))
    ev = _v759_d(levels.get('structure_line_evidence'), struct.get('line_evidence'), snap.get('structure_line_evidence'))
    official = _v759_d(
        row.get('official_structure_inputs_raw'), row.get('official_structure_inputs'),
        snap.get('official_structure_inputs_raw'), snap.get('official_structure_inputs'),
        levels.get('official_structure_inputs_raw_v759'), levels.get('official_structure_inputs_raw'), ev.get('official_structure_inputs'),
    )
    present = int(_v759_num(official.get('present_count'), default=0.0) or 0)
    age = _v759_num(row.get('official_candle_age'), snap.get('official_candle_age'), official.get('official_candle_age'), default=None)
    quality = str(ev.get('quality') or levels.get('line_reliability_v759') or levels.get('quality') or '')
    trigger_conf = _v759_num(ev.get('trigger_confidence'), levels.get('trigger_confidence'), default=0.0) or 0.0
    support_conf = _v759_num(ev.get('support_confidence'), default=0.0) or 0.0
    resistance_conf = _v759_num(ev.get('resistance_confidence'), default=0.0) or 0.0
    source_kind = str(levels.get('line_source_kind_v759') or '')
    if not source_kind:
        if present >= 6 and age is not None and age <= 180 and ('official' in quality or trigger_conf >= 52 or support_conf >= 42):
            source_kind = 'official_candle_reactive_line'
        elif present >= 3:
            source_kind = 'official_partial_watch_line'
        elif levels:
            source_kind = 'gap_or_synthetic_line'
        else:
            source_kind = 'line_missing'
    if present <= 0 and age is None:
        reliability = 'missing_official_material'
    elif age is not None and age >= 180:
        reliability = 'stale_official_material'
    elif source_kind == 'official_candle_reactive_line':
        reliability = 'official_reactive'
    elif source_kind == 'official_partial_watch_line':
        reliability = 'official_partial'
    elif source_kind == 'line_missing':
        reliability = 'line_missing'
    else:
        reliability = 'synthetic_or_gap'
    return {
        'schema': 'structure_line_source_audit_v759',
        'source_kind': source_kind,
        'reliability': reliability,
        'official_present_count': present,
        'official_candle_age': age,
        'evidence_quality': quality or None,
        'support_confidence': support_conf,
        'resistance_confidence': resistance_conf,
        'trigger_confidence': trigger_conf,
        'line_price_policy': 'audit/classify only; no threshold or exit change',
    }


def _v759_flatten_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:
    row = row if isinstance(row, dict) else {}
    snap0 = _v759_original_snapshot(row)
    if not isinstance(snap0, dict):
        snap0 = {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    ctx = _v759_d(row.get('entry_context'), snap0.get('entry_context'))
    diag = _v759_d(row.get('entry_diagnostics'), row.get('paper_final_safety_diagnostics'))
    metrics = _v759_d(snap0.get('metrics'), snap0.get('materials'), row.get('metrics_at_entry'), ctx)
    struct = _v759_d(snap0.get('structure'), row.get('structure'))
    freshness = _v759_d(snap0.get('freshness'))
    ages = _v759_d(freshness.get('ages'))
    levels = _v759_d(row.get('structure_levels'), snap0.get('structure_levels'), struct.get('levels'), diag.get('structure_levels'), ctx.get('structure_levels'))
    plan = _v759_d(row.get('entry_plan'), snap0.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'))
    rrbox = _v759_d(row.get('risk_reward'), snap0.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'))
    entry = _v759_num(row.get('entry_price'), snap0.get('entry_price'), raw.get('entry_price'), default=None)
    trigger = _v759_num(row.get('trigger_price'), snap0.get('trigger_price'), levels.get('trigger_price'), plan.get('trigger_price'), default=None)
    target1 = _v759_num(row.get('target1_price'), row.get('target_price'), snap0.get('target1_price'), snap0.get('target_price'), levels.get('target1_price'), levels.get('target_price'), plan.get('target1_price'), plan.get('target_price'), rrbox.get('target1_price'), rrbox.get('target_price'), default=None)
    target2 = _v759_num(row.get('target2_price'), snap0.get('target2_price'), levels.get('target2_price'), plan.get('target2_price'), rrbox.get('target2_price'), default=None)
    invalid = _v759_num(row.get('invalid_price'), row.get('stop_price'), snap0.get('invalid_price'), levels.get('invalid_price'), levels.get('stop_price'), plan.get('invalid_price'), plan.get('stop_price'), rrbox.get('invalid_price'), rrbox.get('stop_price'), default=None)
    rr = _v759_num(row.get('rr_ratio'), row.get('risk_reward_ratio'), row.get('rr'), snap0.get('rr_ratio'), rrbox.get('rr_ratio'), rrbox.get('risk_reward_ratio'), levels.get('rr_ratio'), default=None)
    if rr is None and entry and target1 and invalid and target1 > entry and entry > invalid:
        rr = (target1 - entry) / (entry - invalid)
    reaction = _v759_num(row.get('price_reaction_pct'), row.get('entry_price_reaction_pct'), snap0.get('price_reaction_pct'), metrics.get('price_reaction_pct'), metrics.get('flow_1m_pct'), ctx.get('price_reaction_pct'), diag.get('price_reaction_pct'), default=None)
    buy = _v759_num(row.get('buy_ratio'), snap0.get('buy_ratio'), metrics.get('buy_trade_ratio'), metrics.get('buy_ratio'), ctx.get('buy_ratio'), diag.get('buy_ratio'), default=None)
    sustain = _v759_num(row.get('buy_sustain_1m'), snap0.get('buy_sustain_1m'), metrics.get('one_min_sustain'), ctx.get('buy_sustain_1m'), diag.get('buy_sustain_1m'), default=None)
    candle_age = _v759_num(row.get('official_candle_age'), snap0.get('official_candle_age'), ctx.get('official_candle_age'), diag.get('official_candle_age'), default=None)
    candle_source = row.get('official_candle_source') or snap0.get('official_candle_source') or ctx.get('official_candle_source') or diag.get('official_candle_source')
    tags = _v759_list(struct.get('tags')) + _v759_list(row.get('entry_structure_tags')) + _v759_list(row.get('structure_tags')) + _v759_list(ctx.get('structure_tags'))
    risk_tags = _v759_list(row.get('execution_risk_tags')) + _v759_list(row.get('risk_tags')) + _v759_list(ctx.get('risk_tags')) + _v759_list(struct.get('risk_tags'))
    # 기존 v755 taxonomy가 없거나 빈 껍데기면 flatten된 row로 다시 계산한다.
    tax = _v759_d(snap0.get('structure_taxonomy_v755'), row.get('structure_taxonomy_v755'), ctx.get('structure_taxonomy_v755'))
    temp = dict(row)
    temp.update({'entry_price': entry, 'current_price': entry, 'trigger_price': trigger, 'target1_price': target1, 'target_price': target1, 'invalid_price': invalid, 'stop_price': invalid, 'rr_ratio': rr, 'price_reaction_pct': reaction, 'buy_ratio': buy, 'buy_sustain_1m': sustain, 'official_candle_age': candle_age, 'official_candle_source': candle_source, 'structure_levels': levels, 'risk_tags': risk_tags, 'structure_tags': tags})
    audit = _v759_structure_line_audit(temp, snap0, levels)
    temp['structure_line_audit_v759'] = audit
    try:
        if (not tax) or not (tax.get('good') or tax.get('bad') or tax.get('recheck')):
            tax = _v755_first_taxonomy(temp) if '_v755_first_taxonomy' in globals() else _v755_row_taxonomy(temp) if '_v755_row_taxonomy' in globals() else {}
    except Exception:
        tax = tax or {}
    flat = dict(snap0)
    flat.update({
        'schema': 'paper_entry_snapshot_v759_flattened',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'flattened_v759': True,
        'ticker': row.get('ticker') or snap0.get('ticker'),
        'entry_price': entry,
        'trigger_price': trigger,
        'target1_price': target1,
        'target2_price': target2,
        'invalid_price': invalid,
        'rr_ratio': round(float(rr), 4) if rr is not None else None,
        'price_reaction_pct': reaction,
        'buy_ratio': buy,
        'buy_sustain_1m': sustain,
        'micro_age_sec': _v759_num(row.get('micro_age_sec'), snap0.get('micro_age_sec'), ages.get('micro_age_sec'), default=None),
        'orderflow_age_sec': _v759_num(row.get('orderflow_age_sec'), snap0.get('orderflow_age_sec'), ages.get('orderflow_age_sec'), default=None),
        'official_candle_age': candle_age,
        'official_candle_source': candle_source,
        'structure_levels': levels,
        'entry_plan': plan,
        'risk_reward': rrbox,
        'structure_tags': _v759_list(tags),
        'risk_tags': _v759_list(risk_tags),
        'structure_taxonomy_v755': tax,
        'structure_good_tags_v755': tax.get('good') if isinstance(tax, dict) else [],
        'structure_bad_tags_v755': tax.get('bad') if isinstance(tax, dict) else [],
        'structure_recheck_tags_v755': tax.get('recheck') if isinstance(tax, dict) else [],
        'structure_signal_side_v755': tax.get('side') if isinstance(tax, dict) else 'neutral',
        'structure_line_audit_v759': audit,
    })
    return flat


def _v759_snapshot_has_core(snap: Dict[str, Any]) -> bool:
    if not isinstance(snap, dict) or not snap:
        return False
    if snap.get('rr_ratio') not in (None, ''):
        return True
    if snap.get('price_reaction_pct') not in (None, ''):
        return True
    tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
    if tax.get('good') or tax.get('bad') or tax.get('recheck'):
        return True
    audit = snap.get('structure_line_audit_v759') if isinstance(snap.get('structure_line_audit_v759'), dict) else {}
    if audit.get('source_kind') not in (None, '', 'line_missing'):
        return True
    return False


def _v758_existing_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    return _v759_flatten_snapshot(row)


def _v758_meaningful_snapshot(snap: Dict[str, Any]) -> bool:  # type: ignore[override]
    return _v759_snapshot_has_core(snap)


def _v754_has_entry_snapshot(row: Dict[str, Any]) -> bool:  # type: ignore[override]
    return _v759_snapshot_has_core(_v759_flatten_snapshot(row))


def _v752_row_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    return _v759_flatten_snapshot(row)


def _v754_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    raw = row.get('raw') if isinstance(row.get('raw'), dict) else {}
    snap = _v759_flatten_snapshot(row)
    mat: Dict[str, Any] = {}
    for src in (snap.get('materials') if isinstance(snap.get('materials'), dict) else {}, snap):
        if isinstance(src, dict):
            for k, v in src.items():
                if k not in mat:
                    mat[k] = v
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    return raw, snap, mat, ctx


def _v747_nested(row: Dict[str, Any]) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any], Dict[str, Any]]:  # type: ignore[override]
    return _v754_nested(row)


_v759_prev_entry_quality = _v747_entry_quality

def _v747_entry_quality(rows: List[Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    out = _v759_prev_entry_quality(rows)
    try:
        rows2 = [r for r in (rows or []) if isinstance(r, dict)]
        ready = 0; empty = 0; line_official = 0; line_synth = 0; tag_rows = 0
        for r in rows2:
            snap = _v759_flatten_snapshot(r)
            if _v759_snapshot_has_core(snap):
                ready += 1
            else:
                empty += 1
            tax = snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
            if tax.get('good') or tax.get('bad') or tax.get('recheck'):
                tag_rows += 1
            audit = snap.get('structure_line_audit_v759') if isinstance(snap.get('structure_line_audit_v759'), dict) else {}
            if str(audit.get('reliability') or '').startswith('official'):
                line_official += 1
            elif audit:
                line_synth += 1
        out['snapshot_ready_rows'] = ready
        out['snapshot_empty_rows_v759'] = empty
        out['structure_tag_rows_v759'] = tag_rows
        out['official_line_rows_v759'] = line_official
        out['synthetic_or_gap_line_rows_v759'] = line_synth
        top = out.get('top') if isinstance(out.get('top'), dict) else {}
        top['snapshot_ready_rows'] = ready
        if empty:
            top['snapshot_empty_rows_v759'] = empty
        if tag_rows:
            top['structure_tag_rows_v759'] = tag_rows
        out['top'] = top
        out['precision_policy_v759'] = 'snapshot_ready requires real flattened material, not a shell; canonical nested metrics/structure/levels are flattened here'
    except Exception as exc:
        log_error('v759_entry_quality_flatten', exc)
    return out


_v759_prev_build_classify_cache = _v747_build_classify_cache

def _v747_build_classify_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v759_prev_build_classify_cache(rows, status)
    try:
        out['schema'] = 'paper_classify_board_v759_snapshot_flatten_structure_line_audit'
        out['version'] = VERSION
        out['paper_version'] = VERSION
        out['build'] = BUILD_LABEL
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v759: canonical snapshot metrics/structure/levels flattened; structure line source audit added')
        out['notes'] = notes
    except Exception as exc:
        log_error('v759_classify_cache_stamp', exc)
    return out


# =============================================================================
# paper_bot v0.762: copy strategy-owned canonical_entry_snapshot_v762
# - paper does not infer structure lines. It copies the final S1 hold/candidate
#   snapshot sealed by strategy_worker v762 into OPEN/CLOSED/classify path.
# - No exit, condition, S1/S2/S3, BUY_READY, or auto-buy change.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'


def _v762_dict(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}


def _v762_find_strategy_snapshot(obj: Dict[str, Any]) -> Dict[str, Any]:
    obj = obj if isinstance(obj, dict) else {}
    ctx = obj.get('entry_context') if isinstance(obj.get('entry_context'), dict) else {}
    raw = obj.get('raw') if isinstance(obj.get('raw'), dict) else {}
    diag = obj.get('entry_diagnostics') if isinstance(obj.get('entry_diagnostics'), dict) else {}
    for src in (obj, ctx, raw, diag):
        if not isinstance(src, dict):
            continue
        for key in ('canonical_entry_snapshot_v762','structure_snapshot_v762','canonical_entry_snapshot','entry_snapshot_v762'):
            snap = src.get(key)
            if isinstance(snap, dict) and snap:
                return snap
    return {}


def _v762_apply_snapshot(row: Dict[str, Any], snap: Dict[str, Any], source: str) -> None:
    if not isinstance(row, dict) or not isinstance(snap, dict) or not snap:
        return
    row['canonical_entry_snapshot_v762'] = snap
    row['entry_snapshot_v762'] = snap
    row['canonical_entry_snapshot'] = snap
    row['entry_snapshot'] = snap
    row['entry_snapshot_schema'] = snap.get('schema')
    row['entry_snapshot_source_v762'] = source
    row['structure_snapshot_copied_v762'] = True
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    ctx = dict(ctx)
    ctx['canonical_entry_snapshot_v762'] = snap
    ctx['structure_snapshot_v762'] = snap
    row['entry_context'] = ctx
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    diag = dict(diag)
    diag['canonical_entry_snapshot_v762'] = snap
    diag['structure_snapshot_v762'] = snap
    row['entry_diagnostics'] = diag


_v762_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v762_prev_open_position(pos_id, ev)
    try:
        snap = _v762_find_strategy_snapshot(ev)
        if not snap and isinstance(pos, dict):
            snap = _v762_find_strategy_snapshot(pos)
        if snap and isinstance(pos, dict):
            _v762_apply_snapshot(pos, snap, 'paper_open_copied_from_strategy_v762')
    except Exception as exc:
        log_error('v762_open_copy_strategy_snapshot', exc)
    return pos


_v762_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    updated, closed = _v762_prev_update_position(pos, ctrl)
    try:
        snap = _v762_find_strategy_snapshot(updated if isinstance(updated, dict) else {}) or _v762_find_strategy_snapshot(pos if isinstance(pos, dict) else {})
        if snap and isinstance(updated, dict):
            _v762_apply_snapshot(updated, snap, 'paper_update_kept_strategy_snapshot_v762')
        if snap and isinstance(closed, dict):
            _v762_apply_snapshot(closed, snap, 'paper_closed_copied_from_open_strategy_snapshot_v762')
            closed['closed_keeps_strategy_snapshot_v762'] = True
    except Exception as exc:
        log_error('v762_update_copy_strategy_snapshot', exc)
    return updated, closed


_v762_prev_v759_original_snapshot = _v759_original_snapshot if '_v759_original_snapshot' in globals() else None

def _v759_original_snapshot(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    row = row if isinstance(row, dict) else {}
    snap = _v762_find_strategy_snapshot(row)
    if snap:
        return snap
    if _v762_prev_v759_original_snapshot:
        try:
            return _v762_prev_v759_original_snapshot(row)  # type: ignore[misc]
        except Exception:
            pass
    return {}


_v762_prev_build_classify_cache = _v747_build_classify_cache

def _v747_build_classify_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v762_prev_build_classify_cache(rows, status)
    try:
        ready = 0; v762 = 0; copied = 0; tag_rows = 0; official = 0; partial = 0; synthetic = 0
        for r in rows or []:
            snap = _v762_find_strategy_snapshot(r if isinstance(r, dict) else {})
            if snap:
                v762 += 1
                line = snap.get('structure_line_source_v762') if isinstance(snap.get('structure_line_source_v762'), dict) else (snap.get('structure', {}) if isinstance(snap.get('structure'), dict) else {}).get('line_source', {})
                tax = snap.get('structure_taxonomy_v762') if isinstance(snap.get('structure_taxonomy_v762'), dict) else snap.get('structure_taxonomy_v755') if isinstance(snap.get('structure_taxonomy_v755'), dict) else {}
                if snap.get('structure_snapshot_copied_v762') or r.get('structure_snapshot_copied_v762'):
                    copied += 1
                if tax.get('good') or tax.get('bad') or tax.get('recheck'):
                    tag_rows += 1
                q = str(line.get('line_quality_v762') or line.get('reliability') or '') if isinstance(line, dict) else ''
                if q == 'official_full': official += 1
                elif q in ('official_partial','official_weak'): partial += 1
                elif q: synthetic += 1
                if snap.get('rr_ratio') not in (None, '', 0, 0.0) or snap.get('price_reaction_pct') not in (None, '') or tag_rows:
                    ready += 1
        out['v762_strategy_snapshot_rows'] = v762
        out['v762_strategy_snapshot_copied_rows'] = copied
        q = out.get('entry_quality_v747') if isinstance(out.get('entry_quality_v747'), dict) else {}
        q['v762_strategy_snapshot_rows'] = v762
        q['v762_structure_tag_rows'] = tag_rows
        q['v762_official_full_rows'] = official
        q['v762_official_partial_rows'] = partial
        q['v762_synthetic_or_missing_rows'] = synthetic
        out['entry_quality_v747'] = q
        out['snapshot_ready_rows_v762'] = ready
        out['structure_tag_rows_v762'] = tag_rows
        out['official_line_rows_v762'] = official
        out['partial_official_line_rows_v762'] = partial
        out['synthetic_or_missing_line_rows_v762'] = synthetic
        out['schema'] = 'paper_classify_board_v762_strategy_snapshot_spine'
        out['version'] = VERSION
        out['paper_version'] = VERSION
        out['build'] = BUILD_LABEL
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v762: classify prefers strategy-owned canonical_entry_snapshot_v762 copied from S1 hold/open row')
        out['notes'] = notes
    except Exception as exc:
        log_error('v762_classify_snapshot_counts', exc)
    return out

try:
    rows, rec = _v758_reconciled_closed_rows()
    status = load_json(FILES['status'], {}) or {}
    cache = _v747_build_classify_cache(rows, status)
    cache['closed_source_reconcile_v759'] = rec
    save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), cache)
except Exception as exc:
    log_error('v759_startup_classify_cache', exc)

# =============================================================================
# paper_bot v0.764: copy canonical_entry_basis_v764 and classify basis status
# - Paper does not recalculate price/line/RR basis. It copies the strategy sealed
#   canonical_entry_basis_v764 into OPEN/CLOSED/classify.
# =============================================================================
VERSION = 'paper_bot_v0.764'
BUILD_LABEL = 'v764_entry_basis_unify_2026-06-08'


def _v764_find_basis(obj: Dict[str, Any]) -> Dict[str, Any]:
    obj = obj if isinstance(obj, dict) else {}
    ctx = obj.get('entry_context') if isinstance(obj.get('entry_context'), dict) else {}
    raw = obj.get('raw') if isinstance(obj.get('raw'), dict) else {}
    diag = obj.get('entry_diagnostics') if isinstance(obj.get('entry_diagnostics'), dict) else {}
    for src in (obj, ctx, raw, diag):
        if not isinstance(src, dict):
            continue
        basis = src.get('canonical_entry_basis_v764')
        if isinstance(basis, dict) and basis:
            return basis
        for sk in ('canonical_entry_snapshot_v764','canonical_entry_snapshot_v762','canonical_entry_snapshot','entry_snapshot'):
            snap = src.get(sk)
            if isinstance(snap, dict):
                b = snap.get('canonical_entry_basis_v764')
                if isinstance(b, dict) and b:
                    return b
    return {}


def _v764_find_snapshot(obj: Dict[str, Any]) -> Dict[str, Any]:
    obj = obj if isinstance(obj, dict) else {}
    ctx = obj.get('entry_context') if isinstance(obj.get('entry_context'), dict) else {}
    raw = obj.get('raw') if isinstance(obj.get('raw'), dict) else {}
    diag = obj.get('entry_diagnostics') if isinstance(obj.get('entry_diagnostics'), dict) else {}
    for src in (obj, ctx, raw, diag):
        if not isinstance(src, dict):
            continue
        for key in ('canonical_entry_snapshot_v764','canonical_entry_snapshot_v762','structure_snapshot_v762','canonical_entry_snapshot','entry_snapshot_v762','entry_snapshot'):
            snap = src.get(key)
            if isinstance(snap, dict) and snap:
                return snap
    return _v762_find_strategy_snapshot(obj)


def _v764_apply_basis(row: Dict[str, Any], basis: Dict[str, Any], snap: Dict[str, Any], source: str) -> None:
    if not isinstance(row, dict):
        return
    if isinstance(snap, dict) and snap:
        row['canonical_entry_snapshot_v764'] = snap
        row['canonical_entry_snapshot'] = snap
        row['entry_snapshot'] = snap
    if isinstance(basis, dict) and basis:
        row['canonical_entry_basis_v764'] = basis
        row['entry_basis_check_v764'] = basis.get('basis_status')
        row['entry_basis_source_v764'] = source
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
        ctx = dict(ctx)
        ctx['canonical_entry_basis_v764'] = basis
        if snap:
            ctx['canonical_entry_snapshot_v764'] = snap
        row['entry_context'] = ctx
        diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
        diag = dict(diag)
        diag['canonical_entry_basis_v764'] = basis
        if snap:
            diag['canonical_entry_snapshot_v764'] = snap
        row['entry_diagnostics'] = diag
        row['entry_basis_copied_v764'] = True


_v764_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v764_prev_open_position(pos_id, ev)
    try:
        basis = _v764_find_basis(ev) or _v764_find_basis(pos if isinstance(pos, dict) else {})
        snap = _v764_find_snapshot(ev) or _v764_find_snapshot(pos if isinstance(pos, dict) else {})
        if isinstance(pos, dict):
            _v764_apply_basis(pos, basis, snap, 'paper_open_copied_from_strategy_basis_v764')
    except Exception as exc:
        log_error('v764_open_copy_entry_basis', exc)
    return pos


_v764_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    updated, closed = _v764_prev_update_position(pos, ctrl)
    try:
        basis = _v764_find_basis(updated if isinstance(updated, dict) else {}) or _v764_find_basis(pos if isinstance(pos, dict) else {})
        snap = _v764_find_snapshot(updated if isinstance(updated, dict) else {}) or _v764_find_snapshot(pos if isinstance(pos, dict) else {})
        if isinstance(updated, dict):
            _v764_apply_basis(updated, basis, snap, 'paper_update_kept_entry_basis_v764')
        if isinstance(closed, dict):
            _v764_apply_basis(closed, basis, snap, 'paper_closed_copied_entry_basis_v764')
            closed['closed_keeps_entry_basis_v764'] = bool(basis)
    except Exception as exc:
        log_error('v764_update_copy_entry_basis', exc)
    return updated, closed


_v764_prev_build_classify_cache = _v747_build_classify_cache

def _v747_build_classify_cache(rows: List[Dict[str, Any]], status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    out = _v764_prev_build_classify_cache(rows, status)
    try:
        status_counts: Counter = Counter()
        complete = 0; copied = 0; mismatch = 0; warning = 0; missing = 0; calc = 0; official = 0
        for r in rows or []:
            if not isinstance(r, dict):
                continue
            basis = _v764_find_basis(r)
            if not basis:
                missing += 1
                continue
            if r.get('entry_basis_copied_v764'):
                copied += 1
            bs = basis.get('basis_status') if isinstance(basis.get('basis_status'), dict) else {}
            label = str(bs.get('status') or '❔ 정보 없음')
            status_counts[label] += 1
            if label.startswith('❌'):
                mismatch += 1
            elif label.startswith('⚠️'):
                warning += 1
            pb = basis.get('price_basis') if isinstance(basis.get('price_basis'), dict) else {}
            sb = basis.get('source_basis') if isinstance(basis.get('source_basis'), dict) else {}
            if pb.get('entry_price') and pb.get('trigger_price') and pb.get('target1_price') and pb.get('invalid_price'):
                complete += 1
            q = str(sb.get('structure_line_quality') or '')
            if q == 'official_full': official += 1
            elif q in ('official_weak','official_partial','fallback_gap','synthetic_pct_line','missing_official','missing'):
                calc += 1
        out['entry_basis_v764'] = {
            'rows_with_basis': sum(status_counts.values()),
            'basis_complete_rows': complete,
            'basis_copied_rows': copied,
            'status_counts': dict(status_counts),
            'basis_mismatch_rows': mismatch,
            'basis_warning_rows': warning,
            'basis_missing_rows': missing,
            'official_line_basis_rows': official,
            'calculated_or_partial_line_rows': calc,
            'user_labels': {'ok': '✅ 기준 일치', 'warn': '⚠️ 일부 주의', 'bad': '❌ 기준 불일치', 'missing': '❔ 정보 없음'},
        }
        out['schema'] = 'paper_classify_board_v764_entry_basis_unify'
        out['version'] = VERSION
        out['paper_version'] = VERSION
        out['build'] = BUILD_LABEL
        notes = out.get('notes') if isinstance(out.get('notes'), list) else []
        notes.append('v764: entry price/trigger/target/RR/source-age basis is sealed by strategy and copied by paper; user-readable basis status added')
        out['notes'] = notes
    except Exception as exc:
        log_error('v764_classify_basis_counts', exc)
    return out

try:
    rows, rec = _v758_reconciled_closed_rows()
    status = load_json(FILES['status'], {}) or {}
    cache = _v747_build_classify_cache(rows, status)
    cache['closed_source_reconcile_v764'] = rec
    save_json(FILES.get('classify', BASE_DIR / 'paper_bot_classify_cache.json'), cache)
except Exception as exc:
    log_error('v764_startup_classify_cache', exc)



if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--once":
        print(json.dumps(run_cycle(), ensure_ascii=False, indent=2))
    else:
        main()
