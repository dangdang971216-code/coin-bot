coinbot_update_v1443
- 목적: 35초 slippage stale가 생기지 않게 Paper 진입 core 앞뒤 시간을 줄이는 수리.
- 핵심: S1/entry-active cycle에서는 진입판단을 우선하고 비핵심 Telegram 요약/시간요약/shadow 재계산은 뒤로 미룸.
- v1442의 OPEN 직전 재읽기는 보험으로 유지하되, 본수리는 cycle 시간 단축.
- 변경 없음: Gate, TTL, RR, trigger, invalid, target, 청산계약, S1/S2/S3 흐름, 자동매수.
- 자동매수: OFF.
