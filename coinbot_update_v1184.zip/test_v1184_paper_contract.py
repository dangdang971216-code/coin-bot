#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, subprocess, sys, tempfile, threading, types
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PAPER=ROOT/'paper_bot_v1.046.py'

def load():
    spec=importlib.util.spec_from_file_location('paper_v1184',PAPER)
    assert spec and spec.loader
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m

def main():
    subprocess.run([sys.executable,'-m','py_compile',str(PAPER)],check=True)
    m=load()
    assert m.VERSION=='paper_bot_v1.046'
    assert m.BUILD_LABEL=='v1184_restore_classify_child_dispatch_and_atomic_writer_2026-07-02'
    assert hasattr(m,'_classify_refresh_child_v1013')
    assert m._v840_tail is m._v849_skip_paper_latest_tail
    assert m._v849_prev_v840_tail is not m._v840_tail
    funcs={k:v for k,v in vars(m).items() if isinstance(v,types.FunctionType)}
    bad=[]
    for name,fn in funcs.items():
        refs=[n for n in fn.__code__.co_names if funcs.get(n) is fn]
        if name in {'_v840_tail','_v849_skip_paper_latest_tail','_v849_prev_v840_tail'} and refs:
            bad.append((name,refs))
    assert not bad,bad
    with tempfile.TemporaryDirectory(prefix='paper-v1184-child-') as td:
        td=Path(td); child=td/'paper_bot.py'; child.write_bytes(PAPER.read_bytes())
        (td/'paper_bot_closed.jsonl').write_text('',encoding='utf-8')
        (td/'paper_bot_open.json').write_text('{}\n',encoding='utf-8')
        proc=subprocess.run([sys.executable,str(child),'--classify-refresh-v1013'],text=True,capture_output=True,timeout=60)
        assert proc.returncode==0,(proc.returncode,proc.stdout,proc.stderr)
        payload=json.loads(proc.stdout.strip().splitlines()[-1])
        assert payload.get('ok') is True,payload
        assert not (td/'paper_bot.pid').exists()
        assert not (td/'paper_bot_status.json').exists()
        assert not (td/'paper_bot.log').exists()
    with tempfile.TemporaryDirectory(prefix='paper-v1184-atomic-') as td:
        out=Path(td)/'state.json'; errors=[]
        def worker(i):
            try:
                for j in range(50): m.atomic_write_text(out,f'{i}:{j}')
            except Exception as exc: errors.append(exc)
        threads=[threading.Thread(target=worker,args=(i,)) for i in range(8)]
        [t.start() for t in threads]; [t.join() for t in threads]
        assert not errors,errors
        assert out.exists()
        assert not list(out.parent.glob(f'.{out.name}.*.tmp'))
    print('PASS v1184 paper direct runtime contract')
    return 0

if __name__=='__main__': raise SystemExit(main())
