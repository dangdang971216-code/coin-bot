Coinbot v1184 CHECK
Purpose: direct repair of Paper v1.045 startup verification failure.
Root cause: flattened Paper removed its classification-child CLI dispatch, so the helper recursively entered main().
Server state remains CHECK_PENDING_DEPLOY until Paper v1.046 exact PID/version/build/hash and next cycle are proven.
Auto-buy remains OFF.
