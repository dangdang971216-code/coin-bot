Release evidence only. Do not overwrite live ledgers.
