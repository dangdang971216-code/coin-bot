v2231은 새 기능을 추가하지 않는다.

Paper는 이미 존재하던 _STOP 상태를 undefined _STOP_EVENT 참조에 연결하고, 기존 exact OPEN sweep 같은 thread 안에서 기존 status만 갱신한다. 새 heartbeat worker는 만들지 않는다. 과거 copy 오류 로그는 보존하며 현재 source에는 import copy가 이미 있다.

Guard는 기존 manifest-only 빠른 적용을 그대로 사용한다. 변경 Main/Paper의 새 PID·버전·writer status를 기다린 뒤 판정하고 현재 선택 bundle 번호를 표시한다.

Main·Review·Strategy·Core·상승예측·구조선·진입·청산·원장은 변경하지 않는다. 자동매수 OFF.
