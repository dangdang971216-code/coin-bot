코인봇 v2156 · 상승예측 28축 연결 진실 단일화

- 새 필터·새 Shadow·새 잠금·새 원장은 만들지 않습니다.
- 기존 Feature·Market·Orderflow → Strategy 단일 상승예측 엔진 한 줄만 사용합니다.
- v2155의 상승예측 공식·가중치·판정기준·FULL_INPUT_V2155 결과세대는 그대로 유지합니다.
- 반복되던 25개 누락은 실제 배선 단절이 아니라 구조 미완성 후보였습니다.
  · NO_INVALID_STRUCTURE 13
  · NO_TRIGGER_STRUCTURE 6
  · NO_REACHABLE_T1 6
- Trigger·돌파 유지·변동성 적합·진입시점처럼 완성 구조가 필요한 축은 WAIT_STRUCTURE로 표시합니다.
- 실제 MISSING·STALE은 별도로 남기고 진입을 fail-closed 처리합니다.
- 28축 전부를 검수판에 표시합니다.
  · READY / WAIT_STRUCTURE / MISSING / STALE
  · 실제 예측 사용 여부
  · 현재값 / 이전값 / 변화량 / 점수 / age / TTL
  · 중립 원인
- 시장 공통값도 원본으로 표시합니다: 시장 폭, BTC, 외부시장, 시장위험, 거래대금 집중·유동성.
- 후보 row에는 축별 원본 전체를 중복 저장하지 않고 slim 상태계약만 남겨 24,576B hard ceiling을 지킵니다.
- 기존 OPEN/CLOSED/decision/exact 및 봉인 청산계약은 변경하지 않습니다.
- 자동매수 OFF.
