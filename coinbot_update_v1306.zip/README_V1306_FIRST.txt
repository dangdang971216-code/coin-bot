coinbot_update_v1306

목적
- v1305에서 빠진 no-limit shadow, 승패 분석판, 디스크 명령 동작/별칭을 실제 코드에 추가.
- 후보식/trigger/invalid/target/RR/청산조건/자동매수는 변경하지 않음.

명령
- Guard: /gdisk_full_v1306 또는 /gdisk_full 또는 /gdisk
- Main: /version_score /flow_map_full /candidate_standard
- Paper: /pzero_reset_v1306 /pzero_status_v1306

주의
- no-limit shadow는 v1306 적용 후 다음 exact S1부터 새로 수집. 기존 CLOSED로 꾸미지 않음.
- 실제 원장 삭제·축소·재작성 없음.
