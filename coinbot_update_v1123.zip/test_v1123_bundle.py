#!/usr/bin/env python3
import ast, importlib.util, json, os, subprocess, sys, tempfile, time, fcntl
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REVIEW=ROOT/'review_worker_v1.001.py'
GUARD=ROOT/'backga_guard_bot_v2_5_171.py'

def load(name,path,env=None):
    if env:
        os.environ.update(env)
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod

def fn_ast(path,name):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert len(nodes)==1,(name,len(nodes))
    return ast.dump(nodes[0],include_attributes=False)

# Import and compact-storage behavior.
r=load('review1123',REVIEW)
large={
 'quality_event_key_v946':'decision:x','ticker':'KRW-TEST','first_seen_ts':1.0,'first_price':100.0,
 'initial_metrics':{'risk_reward':2.5,'target_room_pct':8.0,'money_flow_score':61.0},
 'samples':{'60m':{'ts':2.0,'price':105.0,'pct':5.0,'max_pct':6.0,'min_pct':-1.0,'giveback_pct':1.0,'unused':'x'*500}},
 'policy_variants_v1120':{
   'schema':'quality_policy_variants_v1120_event_sealed',
   'safety_only':{'selected':True,'block_reasons':[]},
   'current_quality':{'selected':True,'block_reasons':[],'rank_score':77.0,'tier':'A'},
   'improved_quality':{'selected':True,'block_reasons':[],'score':70.0,'known_axes':7,'confirmation_count':3,'components':{'rr':10.0}},
   'shared_contract':'repeat me '*500,'observation_only':True,'trading_rules_changed':False,'auto_buy':False,
 }
}
compact=r._quality_active_compact_v1007(large)
final=r._quality_final_compact_v1123(large,3.0)
assert 'shared_contract' not in json.dumps(compact,ensure_ascii=False)
assert final['quality_event_key_v946']=='decision:x'
assert final['policy_variants_v1120']['improved_quality']['score']==70.0
assert len(json.dumps(compact,ensure_ascii=False)) < len(json.dumps(large,ensure_ascii=False))*0.45

# Formula functions are unchanged from v1122.
old=Path('/mnt/data/inspect1122/review_worker_v1.000.py')
for name in ('_quality_policy_variants_v1120','_quality_policy_group_stats_v1120','update_quality_policy_comparison_v1120'):
    assert fn_ast(old,name)==fn_ast(REVIEW,name),name

# Guard import and kernel lock proof.
g=load('guard1123',GUARD,{'GUARD_BOT_TOKEN':'dummy','GUARD_CHAT_ID':'1'})
with tempfile.TemporaryDirectory() as td:
    base=Path(td); (base/'runtime').mkdir()
    lock=base/'runtime'/'review_worker_singleton_v1121.lock'
    child_code='''import fcntl,json,os,sys,time\np=sys.argv[1]\nf=open(p,"a+")\nfcntl.flock(f.fileno(),fcntl.LOCK_EX)\nf.seek(0);f.truncate(0);f.write(json.dumps({"pid":os.getpid(),"version":"review_worker_v1.001","acquired_ts":time.time()}));f.flush();os.fsync(f.fileno())\nprint(os.getpid(),flush=True)\ntime.sleep(30)\n'''
    proc=subprocess.Popen([sys.executable,'-c',child_code,str(lock)],stdout=subprocess.PIPE,text=True)
    pid=int(proc.stdout.readline().strip())
    try:
        g.BOT_DIR=base
        ev=g._review_kernel_lock_evidence_v1123(pid)
        assert ev['ok'] is True,ev
        assert ev['payload_pid']==pid and ev['mainpid_has_lock_fd'] and ev['guard_lock_blocked']
    finally:
        proc.terminate(); proc.wait(timeout=5)

with tempfile.TemporaryDirectory() as td:
    base=Path(td); db=base/'review_append_dedup_v1013.sqlite3'
    child_code='''import sqlite3,sys,time
c=sqlite3.connect(sys.argv[1]); c.execute("create table if not exists t(x)"); c.commit(); print("ready",flush=True); time.sleep(30)'''
    proc=subprocess.Popen([sys.executable,'-c',child_code,str(db)],stdout=subprocess.PIPE,text=True)
    assert proc.stdout.readline().strip()=='ready'
    try:
        g.BOT_DIR=base
        writers=g._review_sqlite_writer_pids_v1123()
        assert proc.pid in writers,writers
    finally:
        proc.terminate(); proc.wait(timeout=5)
    time.sleep(0.1)
    assert g._review_sqlite_writer_pids_v1123()==[]

# Static contracts for live-only writer truth.
gtext=GUARD.read_text(encoding='utf-8')
assert "writer_truth_scope_v1123':'CURRENT_LIVE_FD_ONLY'" in gtext
assert 'historical_observed_writers_v1123' in gtext
assert "live_ev=live_current_openers.get(key,[])" in gtext
assert 'kernel_lock_v1123' in gtext
assert 'review_sqlite_writer_pids_v1123' in gtext
assert 'zero Review family PID and zero SQLite writer proven before start' in gtext
print(json.dumps({'ok':True,'compact_ratio':round(len(json.dumps(compact))/len(json.dumps(large)),4),'formula_ast_unchanged':True,'kernel_lock_proof':True,'live_fd_truth':True},ensure_ascii=False))
