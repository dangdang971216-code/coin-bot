# v1123 범위와 검수

## 실제 원인

1. v1122 결과에서 Review runtime은 MainPID 1개였지만, Guard ledger collector가 최근 1시간의 open-FD 이력을 현재 writer처럼 합쳐 `MULTI_WRITER`를 계속 만들었다.
2. Review singleton 검수는 별도 JSON의 `lock_pid`를 읽어 커널 lock 상태와 어긋날 수 있었다.
3. 배포 정리는 파일명 계열 PID에 의존해, 예상 밖 cmdline을 가진 SQLite writer를 직접 증명하지 못했다.
4. 후보품질 shadow row마다 반복 설명문과 전체 final row를 저장해 Review 저장 증가량이 커졌다.

## 새 본선

- 현재 writer 판정: 현재 `/proc/*/fd` write-open 증거만 사용.
- 과거 open-FD: `historical_observed_writers_v1123`로 보존하되 오류 판정에서 제외.
- Review lock: 커널 flock 경쟁 + MainPID lock inode 보유 + lock payload PID 일치.
- 배포: service stop → 모든 Review family PID 종료 → SQLite write-FD PID 종료 → 0개 증명 → 1개 시작.
- runtime acceptance: MainPID=status PID=kernel lock PID=SQLite writer PID.
- quality shadow: 동일 exact event와 동일 정책결정·horizon을 유지하고 저장 필드만 compact.

## 변경하지 않은 영역

- 조건 없음/current/improved 정책 공식
- 실제 품질 Gate와 rank
- trigger/invalid/target/RR/비용
- OPEN 30 / cycle 3
- Paper selector와 청산계약
- 보호 원장
- 자동매수 OFF

## 서버 검수

`MULTI_WRITER=0`, `WORKER_MULTI_INSTANCE=0`, Review writer PID 1개를 확인한다. Strategy 20초 초과는 이번 Review I/O 정리 뒤 반복 여부로 별도 판정하며, 단발 표본만으로 전략 수치를 바꾸지 않는다.
