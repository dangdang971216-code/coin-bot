코인봇 최신 전체코드 v2114
- 로컬 DONE / 서버 CHECK
- 실제 460개 규모 compact 후보 writer·atomic JSONL·cycle·Review·Paper 연결 검수
- 큰 후보행은 후보·계약을 보존하고 선택 진단값만 명시적으로 축약
- Strategy writer 실패를 Main 화면에서 확인 가능
- 후보 기준·진입·청산·전략 수치 변경 없음
- 자동매수 OFF
- 라이브 원장·runtime 상태 미포함
