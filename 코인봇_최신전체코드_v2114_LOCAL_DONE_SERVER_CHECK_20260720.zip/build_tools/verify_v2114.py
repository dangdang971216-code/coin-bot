from pathlib import Path
import ast,hashlib,tempfile,py_compile
ROOT=Path(__file__).resolve().parents[1];CODE=ROOT/"code"
ALIASES={"bot.py":"coinbot_main_v2_13_2096.py","paper_bot.py":"paper_bot_v2.067.py","backga_guard_bot.py":"backga_guard_bot_v2_6_10.py","strategy_worker.py":"strategy_worker_v2.033.py","review_worker.py":"review_worker_v2.042.py"}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 files=sorted(CODE.glob("*.py"));assert len(files)==30,len(files)
 for p in files:
  ast.parse(p.read_text(encoding="utf-8"),filename=str(p),feature_version=(3,11))
  with tempfile.NamedTemporaryFile(suffix=".pyc") as t:py_compile.compile(str(p),cfile=t.name,doraise=True)
 for a,t in ALIASES.items():assert sha(CODE/a)==sha(CODE/t),(a,t)
 print("v2114 LOCAL VERIFY PASS: 30 files / AST 3.11 / py_compile / alias hashes")
if __name__=="__main__":main()
