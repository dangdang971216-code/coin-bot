#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def read_fresh_jsonl_by_ttl(path: Path, ttl_sec: float) -> List[Dict[str, Any]]:
    """TTL 기준으로 fresh 후보만 읽는다. 개수 제한으로 후보를 자르지 않는다.

    기존 latest/후보 복구 경로의 max_lines=120/500 및 [:40] 고정 상한을
    제거하기 위한 단일 읽기 경로다. 서버 보호는 후보 수 제한이 아니라 TTL로 처리한다.
    """
    if not path.exists():
        return []
    try:
        nowv = now_ts()
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        out: List[Dict[str, Any]] = []
        for ln in reversed(lines):
            try:
                if not ln.strip():
                    continue
                o = json.loads(ln)
                if not isinstance(o, dict):
                    continue
                exp = fnum(o.get("expires_at"), default=0.0)
                ts = _event_created_ts(o)
                fresh = (exp >= nowv) if exp > 0 else (ts > 0 and (nowv - ts) <= ttl_sec)
                if fresh:
                    out.append(o)
                    continue
                # 파일은 시간순 append라, TTL의 여유구간보다 오래된 항목을 만나면 더 과거는 볼 필요 없다.
                if ts > 0 and (nowv - ts) > max(ttl_sec * 3.0, ttl_sec + 60.0):
                    break
            except Exception:
                continue
        out.reverse()
        return out
    except Exception:
        return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

def feature_rows(obj: Any) -> List[Dict[str, Any]]:
    """feature_worker cache를 한 본선으로 읽는다.
    rows/list/cache/dict 형태를 모두 map_rows로 표준화한다.
    전략 조건 수치는 변경하지 않는다.
    """
    return list(map_rows(obj).values())

VERSION = "strategy_worker_v0.40"
INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_strategy_worker_status.json"; ERROR=BASE_DIR/"clean_strategy_worker_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; RISK=BASE_DIR/"clean_risk_filter_cache.json"
PAPER=BASE_DIR/"paper_candidates.jsonl"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"; REJECT=BASE_DIR/"clean_strategy_s_reject_summary.json"; HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"; WS_TARGETS=BASE_DIR/"clean_ws_targets.json"; MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"; MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"; MISSED_REVIEW_QUEUE=BASE_DIR/"clean_missed_review_queue.json"; SCANNER_HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"
CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))
STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}
MAIN_DEPLOY_VERSION = "v2.13.394"
MAIN_BOT_VERSION = "수익형 v2.13.394"
def write_status(state:str, **extra:Any)->None:
    # v434: cycle 시작부의 evaluated=0/target=0 상태가 마지막 정상값을 지우지 않게
    # 중앙 status 저장부에서 구 0 초기화 경로를 제거한다.
    prev: Dict[str, Any] = {}
    phase = str(extra.get("phase") or "")
    is_cycle_start_zero = (
        state == "running"
        and phase.startswith("evaluating")
        and int(float(extra.get("evaluated") or 0)) <= 0
        and int(float(extra.get("target_count") or 0)) <= 0
    )
    if is_cycle_start_zero:
        try:
            prev = load_json(STATUS, {}) or {}
        except Exception:
            prev = {}
    obj={"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),"last_error":""}
    obj.update(extra)
    if is_cycle_start_zero and prev:
        for key in ("evaluated", "target_count", "s_count", "paper_latest_count", "s1_count", "s2_count", "s3_count", "router_target_count", "router_queue_count", "router_backlog_count", "last_sec"):
            if key in prev and (obj.get(key) in (None, "", 0, "0", "-")):
                obj[key] = prev.get(key)
        obj["status_route_schema"] = "strategy_status_v435_no_zero_cycle_start_no_40_cap"
        obj["status_route_note"] = "v436: S1/S2/S3 단순화 + cycle 시작 0 초기화 방지 + 후보 latest 고정 40개 제한 제거"
    if state == "error" and "error" in extra:
        obj["last_error"] = str(extra.get("error") or "")[:240]
    save_json(STATUS,obj)

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

def _normalize_paper_event(ev: Dict[str, Any], ttl_sec: float = CANDIDATE_TTL_SEC) -> Dict[str, Any]:
    row = dict(ev or {})
    ts = _event_created_ts(row) or now_ts()
    ticker = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    skey = str(row.get("strategy_key") or row.get("strategy_bucket_primary") or "strategy_s")
    scan_id = row.get("scan_id") or row.get("source_scan_id") or f"strategy_s_{int(ts // 60)}"
    eid = row.get("event_id") or row.get("id") or row.get("event_key") or f"{ticker}:{skey}:{int(ts // 60)}"
    row.update({
        "ticker": ticker,
        "market": f"KRW-{ticker}" if ticker else row.get("market"),
        "symbol": f"{ticker}_KRW" if ticker else row.get("symbol"),
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "created_at_text": row.get("created_at_text") or now_text(ts),
        "detected_at_text": row.get("detected_at_text") or now_text(ts),
        "updated_ts": now_ts(),
        "expires_at": row.get("expires_at") or (ts + ttl_sec),
        "event_id": eid,
        "event_key": eid,
        "scan_id": scan_id,
        "lane": "strict",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "candidate_grade": "S",
        "grade": "S",
    })
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    # paper_bot의 pre-open check가 top-level 또는 entry_context를 모두 볼 수 있게 복제한다.
    for k in ("ws_fresh", "micro_fresh", "spread_pct", "buy_ratio", "sell_pressure", "orderflow_score"):
        if k in ctx and row.get(k) in (None, ""):
            row[k] = ctx.get(k)
    return row

def _paper_event_fresh(ev: Dict[str, Any], nowv: Optional[float] = None) -> bool:
    nowv = nowv or now_ts()
    exp = fnum(ev.get("expires_at"), default=0.0)
    ts = _event_created_ts(ev)
    if exp > 0:
        return exp >= nowv
    return ts > 0 and (nowv - ts) <= CANDIDATE_TTL_SEC

def _paper_dedupe_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "strategy_s")
    return f"{t}:{sk}"

# v510: legacy persist_paper_handoff removed from runtime. paper_candidates_latest is written once by _v510_publish.

def risk_bad(t:str)->List[str]:
    r=load_json(RISK,{}) or {}; cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in set(r.get("open_tickers",[]) if isinstance(r,dict) else []): out.append("이미OPEN중")
    return out
def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]
def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)
def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)
def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)
def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)
def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)


def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _pickv(src: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(src, dict) and src.get(k) not in (None, "", "-"):
            return src.get(k)
    return default

def _boolv(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

def _entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str) -> Dict[str, Any]:
    """v0.11: 진입 당시 전략 판단/복기용 표준 스냅샷.
    조건을 바로 조이는 용도가 아니라, OPEN/CLOSED/score/review가 같은 근거를 보게 하는 저장 schema다.
    """
    t = ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
    snap = {
        "schema": "entry_snapshot_v1",
        "version": VERSION,
        "captured_ts": ts,
        "captured_text": now_text(ts),
        "event_id": eid,
        "ticker": t,
        "price": fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0.0),
        "strategy": {
            "primary_key": skey,
            "primary_label": STRATEGIES.get(skey, skey),
            "reasons": list(reasons or [])[:8],
            "decision_stage": "S1_immediate_candidate",
            "decision_note": "v0.11 정보스냅샷: 조건 변경 없이 S 진입 당시 재료를 보존",
        },
        "price_flow": {
            "change_30s": _pickv(row, "change_30s", "price_change_30s"),
            "change_1m": _pickv(row, "change_1m", "price_change_1m", "change_1"),
            "change_3m": _pickv(row, "change_3m", "price_change_3m", "change_3"),
            "change_5m": _pickv(row, "change_5m", "price_change_5m", "change_5"),
            "change_15m": _pickv(row, "change_15m", "price_change_15m", "change_15"),
            "change_30m": _pickv(row, "change_30m", "price_change_30m", "change_30"),
            "price_reaction_score": _pickv(row, "price_reaction_score", "price_recheck_pct"),
        },
        "position": {
            "vwap_gap_pct": _pickv(row, "vwap_gap_pct"),
            "ema5_gap_pct": _pickv(row, "ema5_gap_pct", "ma5_gap_pct"),
            "ema12_gap_pct": _pickv(row, "ema12_gap_pct"),
            "ema21_gap_pct": _pickv(row, "ema21_gap_pct"),
            "recent_high_gap_pct": _pickv(row, "recent_high_gap_pct", "below_high_pct", "below_30m_high_pct"),
            "recent_low_gap_pct": _pickv(row, "recent_low_gap_pct", "from_low_pct", "from_30m_low_pct"),
            "day_pos_pct": _pickv(row, "day_pos_pct", "current_close_pos_ratio"),
            "recent_low_rebound_pct": _pickv(row, "recent_low_rebound_pct", "low_defense_pct"),
            "breakout_hint": bool(row.get("breakout_hint")),
            "breakout_hold_hint": _pickv(row, "breakout_hold_hint", "breakout_retain_hint"),
            "sweep_reclaim_hint": bool(row.get("sweep_reclaim_hint")),
            "long_upper_wick": bool(row.get("long_upper_wick")),
            "upper_wick_pct": _pickv(row, "upper_wick_pct", "current_upper_wick_pct"),
        },
        "money_flow": {
            "turnover_24h": _pickv(row, "turnover_24h"),
            "turnover_1m": _pickv(row, "turnover_1m", "money_flow_1m"),
            "turnover_3m": _pickv(row, "turnover_3m", "money_flow_3m"),
            "turnover_5m": _pickv(row, "turnover_5m", "money_flow_5m"),
            "volume_expanding": bool(row.get("volume_expanding")),
            "volume_expansion_ratio": _pickv(row, "volume_expansion_ratio", "vol_ratio"),
            "relative_strength_pct": _pickv(row, "relative_strength_pct", "relative_strength"),
            "market_mode": _pickv(row, "market_mode"),
            "market_pressure": _pickv(row, "market_pressure"),
        },
        "orderflow": {
            "quote_fresh": _boolv(of.get("quote_fresh") or of.get("ws_fresh")),
            "quote_source": _pickv(of, "quote_source"),
            "quote_price": _pickv(of, "quote_price"),
            "quote_age_sec": _pickv(of, "quote_age_sec"),
            "ws_fresh": _boolv(of.get("ws_fresh")),
            "ws_age_sec": _pickv(of, "ws_age_sec"),
            "ws_gap_pct": _pickv(of, "ws_gap_pct", "quote_gap_pct", "current_price_ws_gap_pct"),
            "micro_fresh": _boolv(of.get("micro_fresh")),
            "micro_age_sec": _pickv(of, "micro_age_sec"),
            "spread_pct": _pickv(of, "spread_pct"),
            "buy_ratio": _pickv(of, "buy_ratio", "micro_trade_buy_ratio_30"),
            "buy_ratio_30s": _pickv(of, "buy_ratio_30s", "buy_ratio_30", "micro_trade_buy_ratio_30"),
            "buy_ratio_1m": _pickv(of, "buy_ratio_1m", "buy_ratio_60"),
            "bid_wall_ratio": _pickv(of, "bid_wall_ratio", "micro_bid_ask_wall_ratio"),
            "ask_wall_ratio": _pickv(of, "ask_wall_ratio"),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
            "ask_wall_pressure": bool(of.get("ask_wall_pressure")),
            "sell_trade_pressure": bool(of.get("sell_trade_pressure")),
            "slippage_est_pct": _pickv(of, "slippage_est_pct", "tick_pct_est"),
            "orderflow_score": _pickv(of, "orderflow_score"),
        },
        "risk": {
            "major_watch": bool(row.get("major_watch")),
            "quality_risk_tags": row.get("quality_risk_tags") if isinstance(row.get("quality_risk_tags"), list) else [],
            "hard_flags": common_hard(row, of),
            "recent_loss_or_hard": "최근반복손실/하드손실" in common_hard(row, of),
            "high_end_risk": bool(fnum(row.get("day_pos_pct"), default=50)>94 and fnum(row.get("change_5m"))<0.2),
            "sell_pressure": bool(of.get("sell_pressure") or of.get("ask_wall_pressure") or of.get("sell_trade_pressure")),
        },
        "review_after_entry": {
            "track_30s_peak_pct": None,
            "track_1m_peak_pct": None,
            "track_3m_peak_pct": None,
            "peak_reach_sec": None,
            "note": "paper_bot 청산감시가 진입 후 반응/최고수익 도달시간을 보강할 수 있는 자리",
        },
    }
    # 자주 쓰는 값은 flat alias도 같이 보존해 paper_bot 구/신 경로가 모두 읽게 한다.
    flat = {
        "entry_snapshot_schema": snap["schema"],
        "entry_snapshot_version": snap["version"],
                "change_30s": snap["price_flow"].get("change_30s"),
        "change_1m": snap["price_flow"].get("change_1m"),
        "change_3m": snap["price_flow"].get("change_3m"),
        "change_5m": snap["price_flow"].get("change_5m"),
        "change_15m": snap["price_flow"].get("change_15m"),
        "change_30m": snap["price_flow"].get("change_30m"),
        "price_change_3m": snap["price_flow"].get("change_3m"),
        "price_change_5m": snap["price_flow"].get("change_5m"),
        "vwap_gap_pct": snap["position"].get("vwap_gap_pct"),
        "ema5_gap_pct": snap["position"].get("ema5_gap_pct"),
        "recent_high_gap_pct": snap["position"].get("recent_high_gap_pct"),
        "recent_low_gap_pct": snap["position"].get("recent_low_gap_pct"),
        "day_pos_pct": snap["position"].get("day_pos_pct"),
        "relative_strength_pct": snap["money_flow"].get("relative_strength_pct"),
        "relative_strength": snap["money_flow"].get("relative_strength_pct"),
        "turnover_24h": snap["money_flow"].get("turnover_24h"),
        "money_flow_1m": snap["money_flow"].get("turnover_1m"),
        "money_flow_3m": snap["money_flow"].get("turnover_3m"),
        "money_flow_5m": snap["money_flow"].get("turnover_5m"),
        "volume_expanding": snap["money_flow"].get("volume_expanding"),
        "quote_fresh": snap["orderflow"].get("quote_fresh"),
        "quote_source": snap["orderflow"].get("quote_source"),
        "quote_price": snap["orderflow"].get("quote_price"),
        "quote_age_sec": snap["orderflow"].get("quote_age_sec"),
        "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "ws_age_sec": snap["orderflow"].get("ws_age_sec"),
        "ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "current_price_ws_gap_pct": snap["orderflow"].get("ws_gap_pct"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"),
        "micro_age_sec": snap["orderflow"].get("micro_age_sec"),
        "spread_pct": snap["orderflow"].get("spread_pct"),
        "micro_spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"),
        "micro_trade_buy_ratio_30": snap["orderflow"].get("buy_ratio"),
        "micro_buy_ratio_sustain_1m": snap["orderflow"].get("buy_ratio_1m"),
        "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "micro_bid_ask_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "sell_pressure": snap["orderflow"].get("sell_pressure"),
        "micro_ask_wall_pressure": snap["orderflow"].get("ask_wall_pressure"),
        "micro_sell_trade_pressure": snap["orderflow"].get("sell_trade_pressure"),
        "slippage_est_pct": snap["orderflow"].get("slippage_est_pct"),
        "orderflow_score": snap["orderflow"].get("orderflow_score"),
        "quality_risk_tags": snap["risk"].get("quality_risk_tags"),
    }
    snap["flat"] = flat
    return snap

def _snapshot_flat_aliases(snap: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(snap, dict) and isinstance(snap.get("flat"), dict):
        # v0.13: flat alias 안에는 snapshot 본체를 넣지 않는다.
        # flat -> entry_snapshot -> flat 순환참조가 생기면 json 저장에서 Circular reference로 worker가 error 상태가 된다.
        out = dict(snap.get("flat") or {})
        out.pop("entry_snapshot", None)
        return out
    return {}

def _minimal_entry_snapshot(row: Dict[str, Any], of: Dict[str, Any], skey: str, reasons: List[str], ts: float, eid: str, err: str = "") -> Dict[str, Any]:
    t = ticker_norm(row.get("ticker") or of.get("ticker"))
    snap = {
        "schema": "entry_snapshot_v1", "version": VERSION, "snapshot_status": "partial",
        "snapshot_error": err[:180], "ticker": t, "event_id": eid, "created_at": ts, "created_at_text": now_text(ts),
        "price_flow": {}, "position": {}, "money_flow": {},
        "orderflow": {
            "quote_fresh": bool(of.get("quote_fresh") or of.get("ws_fresh")),
            "ws_fresh": bool(of.get("ws_fresh")), "micro_fresh": bool(of.get("micro_fresh")),
            "spread_pct": of.get("spread_pct"), "buy_ratio": of.get("buy_ratio"),
            "bid_wall_ratio": of.get("bid_wall_ratio"), "ask_wall_ratio": of.get("ask_wall_ratio"),
        },
        "risk": {"hard_flags": common_hard(row, of)},
        "strategy": {"primary_key": skey, "primary_label": STRATEGIES.get(skey, skey), "reasons": reasons[:8]},
        "review_after_entry": {},
    }
    snap["flat"] = {
        "entry_snapshot_schema": snap["schema"], "entry_snapshot_version": snap["version"],         "quote_fresh": snap["orderflow"].get("quote_fresh"), "ws_fresh": snap["orderflow"].get("ws_fresh"),
        "micro_fresh": snap["orderflow"].get("micro_fresh"), "spread_pct": snap["orderflow"].get("spread_pct"),
        "buy_ratio": snap["orderflow"].get("buy_ratio"), "bid_wall_ratio": snap["orderflow"].get("bid_wall_ratio"),
        "ask_wall_ratio": snap["orderflow"].get("ask_wall_ratio"),
        "snapshot_status": snap["snapshot_status"], "snapshot_error": snap["snapshot_error"],
    }
    return snap


def _v361_adaptive_hold_profile(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    """유동 보유형 후보별 청산/복기 프로필."""
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=0.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    strong = (ch15 >= 1.2 and ch30 >= 0.8 and rel >= 0.3) or (ch5 >= 1.2 and ch15 >= 0.8 and vwap >= 0 and ema >= 0)
    ext_tp = 2.20 if strong else 1.80
    max_min = 120 if strong else 75
    return {
        'strategy_family': 'adaptive_hold',
        'strategy_family_label': '주도흐름 유동보유',
        'hold_model': 'adaptive_0_5_30_120',
        'phase_1': '0~5분 진입검증: 가격반응/체결지속/VWAP 방어 없으면 빠른정리',
        'phase_2': '5~30분 수익확인: +0.5~1.2% 도달·VWAP/EMA 유지 시 보유',
        'phase_3': '30~120분 확장: +1.2% 이상 도달 후 추세 유지 시 보호익절로 연장',
        'take_profit_pct': 1.20,
        'extended_target_pct': ext_tp,
        'extended_take_profit_pct': ext_tp,
        'protect_trigger_pct': 0.70,
        'protect_floor_pct': 0.35,
        'stop_loss_pct': -0.60,
        'hard_loss_guard_pct': -0.90,
        'time_exit_minutes': max_min,
        'time_exit_min': max_min,
        'early_validation_minutes': 5,
        'mid_validation_minutes': 30,
        'adaptive_hold_note': '나쁜 후보는 0~5분 검증 실패로 빨리 정리하고, +1.2% 이상 간 후보만 30~120분 확장 관찰',
    }

def build_event(row, of, skey, reasons):
    ts = now_ts()
    t = ticker_norm(row.get("ticker"))
    price = fnum(row.get("current_price"), row.get("price"), of.get("quote_price"), default=0)
    label = STRATEGIES.get(skey, skey)
    eid = f"{t}:{skey}:{int(ts // 60)}"
    try:
        entry_snapshot = _entry_snapshot(row, of, skey, reasons, ts, eid)
    except Exception as exc:
        append_error(ERROR, "entry_snapshot_build", exc)
        entry_snapshot = _minimal_entry_snapshot(row, of, skey, reasons, ts, eid, f"{exc.__class__.__name__}: {exc}")
    aliases = _snapshot_flat_aliases(entry_snapshot)
    base_ctx = dict(aliases)
    base_ctx.update({
        "candidate_created_at": ts,
        "event_id": eid,
        "strategy_key": skey,
        "strategy_name": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "final_entry_reasons": reasons[:6],
        "entry_snapshot": entry_snapshot,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    })
    ev = {
        "event_id": eid,
        "event_key": eid,
        "created_at": ts,
        "candidate_created_at": ts,
        "source_created_at": ts,
        "detected_ts": ts,
        "event_ts": ts,
        "updated_ts": ts,
        "expires_at": ts + CANDIDATE_TTL_SEC,
        "created_at_text": now_text(ts),
        "detected_at_text": now_text(ts),
        "scan_id": f"strategy_s_{int(ts // 60)}",
        "ticker": t,
        "market": f"KRW-{t}",
        "symbol": f"{t}_KRW",
        "strategy_key": skey,
        "strategy": label,
        "strategy_name": label,
        "paper_strategy_key": skey,
        "paper_strategy_label": label,
        "strategy_bucket_primary": skey,
        "strategy_bucket_primary_label": label,
        "strategy_bucket_labels": [label],
        "candidate_grade": "S",
        "grade": "S",
        "candidate_grade_label": "✅ S급 자동매매 상위",
        "paper_bot_open": True,
        "open_eligible": True,
        "trade_ready": True,
        "lane": "strict",
        "current_price": price,
        "entry_price": price,
        "detected_price": price,
        "score": round(13.0 + len(reasons) * 0.9 + fnum(of.get("orderflow_score")) * 0.15, 2),
        "take_profit_pct": 1.80,
        "extended_take_profit_pct": 2.80,
        "protect_trigger_pct": 1.00,
        "protect_floor_pct": 0.45,
        "stop_loss_pct": -0.45,
        "time_exit_minutes": 60,
        "reasons": reasons[:6],
        "quality_risk_tags": aliases.get("quality_risk_tags") or [],
        "entry_context": base_ctx,
        "entry_snapshot": entry_snapshot,
        "entry_snapshot_schema": "entry_snapshot_v1",
        "strategy_reasons": reasons[:6],
        "final_entry_reasons": reasons[:6],
        "brain_version": VERSION,
        "main_version": MAIN_DEPLOY_VERSION,
        "main_bot_version": MAIN_BOT_VERSION,
        "deploy_version": MAIN_DEPLOY_VERSION,
    }
    profile = _v361_adaptive_hold_profile(row, of, skey) if skey == "leader_flow_adaptive_hold_s" else {}
    if profile:
        ev["profile"] = profile
        ev["strategy_family"] = profile.get("strategy_family")
        ev["strategy_family_label"] = profile.get("strategy_family_label")
        ev["hold_model"] = profile.get("hold_model")
        ev["take_profit_pct"] = profile.get("take_profit_pct", ev.get("take_profit_pct"))
        ev["extended_target_pct"] = profile.get("extended_target_pct")
        ev["extended_take_profit_pct"] = profile.get("extended_take_profit_pct")
        ev["protect_trigger_pct"] = profile.get("protect_trigger_pct", ev.get("protect_trigger_pct"))
        ev["protect_floor_pct"] = profile.get("protect_floor_pct", ev.get("protect_floor_pct"))
        ev["stop_loss_pct"] = profile.get("stop_loss_pct", ev.get("stop_loss_pct"))
        ev["hard_loss_guard_pct"] = profile.get("hard_loss_guard_pct")
        ev["time_exit_minutes"] = profile.get("time_exit_minutes", ev.get("time_exit_minutes"))
        ev["time_exit_min"] = profile.get("time_exit_min")
        base_ctx.update(profile)
        if isinstance(entry_snapshot, dict):
            entry_snapshot.setdefault("adaptive_hold_profile", profile)
            strat = entry_snapshot.get("strategy") if isinstance(entry_snapshot.get("strategy"), dict) else {}
            strat.update({"hold_model": profile.get("hold_model"), "strategy_family": profile.get("strategy_family_label"), "decision_note": "v367 주도흐름 유동보유 후보"})
            entry_snapshot["strategy"] = strat
            ev["entry_snapshot"] = entry_snapshot
    ev.update(aliases)
    return ev
def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)


def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }


def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"



# =============================================================================
# strategy_worker v0.87 / v510: clean single-pass canonical spine
# - Does not call legacy run_once / tail overrides.
# - Reads feature/orderflow once, builds base/spike lanes independently, merges once.
# - Writes paper_candidates_latest once. No old_latest re-mix, no archive runtime append.
# - Publishes candidate_reason / recheck / lifecycle / summary from the same final rows.
# =============================================================================
VERSION = "strategy_worker_v0.96"
MAIN_VERSION = "v2.13.430"
MAIN_DEPLOY_VERSION = "v2.13.430"
MAIN_BOT_VERSION = "수익형 v2.13.430"
V510_SCHEMA = "strategy_canonical_spine_v522_freshness_single_gate"
CANDIDATE_REASON_COMPACT_CACHE = BASE_DIR / "clean_candidate_reason_compact_cache.json"
S1_LIFECYCLE_TRACE = BASE_DIR / "clean_s1_lifecycle_trace.json"
S1_LIFECYCLE_STATE = BASE_DIR / "clean_s1_lifecycle_state.json"
# v512: main command readers have used different historical names. We write the same object
# to explicit alias files, but all aliases are produced from one final_rows payload.
CANDIDATE_REASON_ALIAS_FILES = [
    CANDIDATE_REASON_COMPACT_CACHE,
    BASE_DIR / "candidate_reason_compact_cache.json",
    BASE_DIR / "clean_candidate_reason_cache.json",
]
S1_LIFECYCLE_ALIAS_FILES = [
    S1_LIFECYCLE_TRACE,
    BASE_DIR / "s1_lifecycle_trace.json",
    BASE_DIR / "clean_s1_lifecycle_cache.json",
]
RECHECK_CACHE = BASE_DIR / "clean_recheck_candidates_cache.json"
RECHECK_STATE = BASE_DIR / "clean_recheck_candidates_state.json"
CANONICAL_STRATEGY_SUMMARY = BASE_DIR / "clean_strategy_canonical_summary.json"
V510_TRACE = BASE_DIR / "clean_strategy_v510_single_pass_trace.json"

_STAGE_ORDER = {"S1": 3, "S2": 2, "S3": 1}


def _v510_num(*vals: Any, default: float = 0.0) -> float:
    return fnum(*vals, default=default)


def _v510_stage(row: Dict[str, Any]) -> str:
    st = str(row.get("s_stage") or row.get("candidate_grade") or row.get("stage") or row.get("grade") or "S3").upper()
    return st if st in ("S1", "S2", "S3") else "S3"


def _v510_uniq(xs: List[Any], maxn: int = 12) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in xs or []:
        s = str(x or "").strip()
        if not s or s in seen:
            continue
        seen.add(s); out.append(s)
        if len(out) >= maxn:
            break
    return out


def _v510_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}


def _v510_age_from_of(of: Dict[str, Any], *keys: str, default: float = 999999.0) -> float:
    return _v510_num(*[of.get(k) for k in keys], default=default)



def _v521_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime)
    except Exception:
        return 999999.0


def _v521_row_age(row: Dict[str, Any], cache_age: float, *ts_keys: str) -> float:
    # 999999 means "age field missing", not "really stale".
    for k in ("age_sec", "cache_age_sec", "row_age_sec", "updated_age_sec"):
        a = _v510_num(row.get(k), default=-1.0)
        if 0 <= a < 999998:
            return a
    for k in ts_keys or ("updated_ts", "ts", "timestamp", "created_at", "event_ts"):
        ts = _v510_num(row.get(k), default=0.0)
        if ts > 1_000_000_000:
            return max(0.0, now_ts() - ts)
    return cache_age


def _v521_load_map_with_cache_age(path: Path, cache_name: str) -> Dict[str, Dict[str, Any]]:
    obj = load_json(path, {}) or {}
    c_age = _v521_file_age(path)
    out = map_rows(obj)
    top_ts = _v510_num(obj.get("updated_ts") if isinstance(obj, dict) else 0.0, default=0.0)
    top_age = max(0.0, now_ts() - top_ts) if top_ts > 1_000_000_000 else c_age
    for t, r in list(out.items()):
        rr = dict(r)
        rr.setdefault("_cache_name", cache_name)
        rr.setdefault("_cache_age_sec", min(c_age, top_age))
        rr.setdefault("_cache_updated_ts", top_ts or now_ts() - c_age)
        out[t] = rr
    return out


def _v521_hot_map() -> Dict[str, Dict[str, Any]]:
    out = _v521_load_map_with_cache_age(SCANNER_HOT, "scanner_hot")
    c_age = _v521_file_age(SCANNER_HOT)
    for t, r in list(out.items()):
        rr = dict(r)
        if "scanner_change_1m_pct" in rr and "change_1m" not in rr:
            rr["change_1m"] = rr.get("scanner_change_1m_pct")
        if "scanner_change_3m_pct" in rr and "change_3m" not in rr:
            rr["change_3m"] = rr.get("scanner_change_3m_pct")
        rr.setdefault("hot_signal_age_sec", _v521_row_age(rr, c_age, "updated_ts", "ts", "timestamp"))
        rr.setdefault("hot_fresh", c_age <= 10)
        rr.setdefault("scanner_hot_fresh", c_age <= 10)
        out[t] = rr
    return out


def _v521_overlay_feature(src: Dict[str, Any], hot: Dict[str, Any]) -> Dict[str, Any]:
    if not hot:
        return dict(src)
    merged = dict(src)
    for k in ("scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m", "hot_signal_age_sec", "hot_fresh", "scanner_hot_fresh"):
        if merged.get(k) in (None, "", 0, 0.0, 999999, 999999.0):
            merged[k] = hot.get(k)
    if merged.get("change_1m") in (None, "", 0, 0.0) and hot.get("change_1m") is not None:
        merged["change_1m"] = hot.get("change_1m")
    if merged.get("change_3m") in (None, "", 0, 0.0) and hot.get("change_3m") is not None:
        merged["change_3m"] = hot.get("change_3m")
    merged["_scanner_hot_cache_age_sec"] = hot.get("_cache_age_sec", _v521_file_age(SCANNER_HOT))
    return merged


def _v521_age_from_sources(primary: Dict[str, Any], secondary: Dict[str, Any], cache_key: str, keys: Tuple[str, ...], default_cache_age: float = 999999.0) -> float:
    for row in (primary, secondary):
        for k in keys:
            a = _v510_num(row.get(k), default=-1.0)
            if 0 <= a < 999998:
                return a
    for row in (primary, secondary):
        c = _v510_num(row.get(cache_key), row.get("_cache_age_sec"), default=-1.0)
        if 0 <= c < 999998:
            return c
    return default_cache_age


def _v521_value_present(row: Dict[str, Any], *keys: str) -> bool:
    for k in keys:
        v = row.get(k)
        if v in (None, "", [], {}):
            continue
        try:
            if float(str(v).replace(",", "").replace("%", "")) != 0:
                return True
        except Exception:
            return True
    return False



def _v522_parse_age_item(item: Any) -> Tuple[str, float]:
    s = str(item or "").strip()
    m = re.search(r'(hot|micro|orderflow|price|quote|paper)\s+([0-9]+(?:\.[0-9]+)?)s', s)
    if not m:
        return s, 999999.0
    return m.group(1), _v510_num(m.group(2), default=999999.0)


def _v522_filter_stale_items(items: List[Any], strict: bool = True) -> List[str]:
    # A stale reason is valid only when the component is actually over TTL.
    ttl = {
        "hot": 35.0 if strict else 60.0,
        "micro": 20.0,
        "orderflow": 20.0,
        "price": 30.0,
        "quote": 20.0,
        "paper": 45.0,
    }
    out: List[str] = []
    for raw in items or []:
        comp, a = _v522_parse_age_item(raw)
        if comp in ttl:
            if a >= ttl[comp]:
                out.append(f"{comp} {a:.1f}s")
            continue
        s = str(raw or "").strip()
        if s:
            out.append(s)
    return _v510_uniq(out, 8)


def _v522_strip_freshness_text(raw: List[Any]) -> List[str]:
    # Old route may still pass "신선도재확인:hot 0.8s" as an existing reason.
    # Remove all freshness strings here; the single gate will re-add only real stale items.
    out: List[str] = []
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if "신선" in s or "final_entry_gate" in s:
            continue
        out.append(s)
    return out


def _v520_age_ok(age_val: float, limit: float) -> bool:
    return age_val < 999998 and age_val <= limit


def _v520_bool_any(*vals: Any) -> bool:
    for v in vals:
        try:
            if _v510_bool(v):
                return True
        except Exception:
            continue
    return False


def _v520_fresh_stale_items(src: Dict[str, Any], of: Dict[str, Any], hot_age: float, micro_age: float, order_age: float, price_age: float, quote_age: float, sealed_price: float, strict: bool = True) -> List[str]:
    """v522 single freshness gate.
    Age under TTL is fresh. Value/cache presence is a bonus, not a second stale route.
    """
    hot_cache_age = _v510_num(src.get("_scanner_hot_cache_age_sec"), src.get("_cache_age_sec"), default=999999.0)
    of_cache_age = _v510_num(of.get("_cache_age_sec"), default=999999.0)

    ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), src.get("scanner_change_1m_pct"), default=0.0)
    ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), src.get("scanner_change_3m_pct"), default=0.0)
    hot_present = max(abs(ch1), abs(ch3)) > 0 or _v521_value_present(src, "scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m")
    micro_present = _v521_value_present(of, "buy_ratio", "micro_trade_buy_ratio_30", "trade_buy_ratio", "spread_pct", "best_bid", "best_ask")
    order_present = micro_present or _v521_value_present(of, "orderflow_score", "sell_wall_ratio", "trade_count", "buy_count", "sell_count")
    quote_present = sealed_price > 0 or _v521_value_present(of, "quote_price", "current_price", "mid_price", "best_bid", "best_ask")
    price_present = sealed_price > 0 or _v521_value_present(src, "current_price", "price", "trade_price", "close", "last_price")

    # Missing embedded age uses cache age. If either age is fresh or value exists with fresh cache, it is fresh.
    hot_ok = bool(src.get("hot_fresh") or src.get("scanner_hot_fresh")) or _v520_age_ok(hot_age, 35) or (hot_cache_age <= 12 and hot_present)
    micro_ok = bool(of.get("micro_fresh")) or _v520_age_ok(micro_age, 20) or (of_cache_age <= 12 and micro_present)
    order_ok = bool(of.get("orderflow_fresh") or of.get("trade_fresh")) or _v520_age_ok(order_age, 20) or (of_cache_age <= 12 and order_present)
    quote_ok = bool(of.get("quote_fresh") or of.get("ws_fresh") or src.get("quote_fresh") or src.get("ws_fresh")) or _v520_age_ok(quote_age, 20) or (of_cache_age <= 12 and quote_present)
    price_ok = bool(src.get("price_reaction_fresh") or src.get("feature_fresh")) or _v520_age_ok(price_age, 30) or price_present

    stale: List[str] = []
    if strict and not hot_ok:
        stale.append(f"hot {hot_age:.1f}s")
    if not quote_ok:
        stale.append(f"quote {quote_age:.1f}s")
    if not micro_ok:
        stale.append(f"micro {micro_age:.1f}s")
    if strict and not order_ok:
        stale.append(f"orderflow {order_age:.1f}s")
    if not price_ok:
        stale.append(f"price {price_age:.1f}s")
    return _v522_filter_stale_items(stale, strict=strict)[:5]




def _v520_split_reasons(raw: List[Any], stale: List[str]) -> Tuple[List[str], List[str]]:
    decision: List[str] = []
    structure: List[str] = []
    raw = _v522_strip_freshness_text(raw)
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if s.startswith("구조:"):
            structure.append(s.replace("구조:", "", 1).strip())
            continue
        if "fresh urgent" in s or "급등 확인" in s:
            decision.append("급등확인")
            continue
        decision.append(s)
    stale = _v522_filter_stale_items(stale, strict=True)
    if stale:
        decision.append("신선도재확인:" + "/".join(stale[:3]))
    return _v510_uniq(decision, 12), _v510_uniq(structure, 8)


def _v520_normalize_reason_row(r: Dict[str, Any]) -> Dict[str, Any]:
    stale = _v522_filter_stale_items([str(x).strip() for x in (r.get("stale_reasons") or []) if str(x).strip()], strict=True)
    reasons, structures = _v520_split_reasons(list(r.get("s_stage_reasons") or []) + list(r.get("block_reasons") or []), stale)
    base_structures = r.get("structure_tags") if isinstance(r.get("structure_tags"), list) else []
    r["structure_tags"] = _v510_uniq(list(base_structures) + structures, 10)
    r["s_stage_reasons"] = reasons
    r["reason"] = " / ".join(reasons)
    r["freshness_status"] = "recheck" if stale else "fresh"
    if stale:
        r["stale_reasons"] = stale
    else:
        r["stale_reasons"] = []
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["structure_tags"] = r["structure_tags"]
    ctx["reasons"] = reasons
    ctx["freshness_status"] = r["freshness_status"]
    ctx["stale_reasons"] = r["stale_reasons"]
    r["entry_context"] = ctx
    return r


def _v510_price_reaction(row: Dict[str, Any], of: Dict[str, Any]) -> float:
    return _v510_num(of.get("price_reaction_pct"), of.get("reaction_pct"), row.get("price_reaction_pct"), row.get("change_1m"), row.get("price_change_1m"), default=0.0)


def _v510_spread(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("spread_pct"), row.get("spread_pct"), default=99.0)


def _v510_buy(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=0.0)


def _v510_sustain(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("buy_sustain_1m"), of.get("buy_ratio"), row.get("buy_sustain_1m"), default=_v510_buy(of, row))


def _v510_structure_tags(row: Dict[str, Any]) -> List[str]:
    tags: List[str] = []
    if row.get("sweep_reclaim_hint"): tags += ["저점유동성쓸림", "쓸림후빠른회복"]
    if row.get("breakout_hint"): tags += ["저항돌파후재테스트"]
    if _v510_num(row.get("vwap_gap_pct"), default=-9.0) >= -0.05: tags.append("VWAP방어")
    if _v510_num(row.get("ema5_gap_pct"), row.get("ma5_gap_pct"), default=-9.0) >= -0.10: tags.append("EMA방어")
    if row.get("volume_expanding"): tags.append("거래량확장")
    if _v510_num(row.get("change_3m"), default=0.0) >= 0.35: tags.append("돈흐름재유입")
    return _v510_uniq(tags, 8)


def _v510_risk_tags(row: Dict[str, Any], of: Dict[str, Any], hard: List[str]) -> List[str]:
    tags: List[str] = []
    spread = _v510_spread(of, row)
    buy = _v510_buy(of, row)
    if spread >= 0.35: tags.append("스프레드부담")
    if spread >= 0.35: tags.append("미끄러짐부담")
    if buy and buy < 0.58: tags.append("매수체결약함")
    if row.get("long_upper_wick"): tags.append("윗꼬리위험")
    if _v510_num(row.get("day_pos_pct"), default=50.0) > 94 and _v510_num(row.get("change_1m"), default=0.0) <= 0.05:
        tags.append("되돌림위험")
    for h in hard or []:
        if "매도" in h: tags.append("매도압력부담")
        if "스프레드" in h: tags.append("스프레드부담")
    return _v510_uniq(tags, 8)


def _v510_event_id(ticker: str, skey: str, lane: str, nowv: float) -> str:
    return f"{ticker}:{lane}:{skey}:{int(nowv // 10)}"


def _v510_make_row(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    react = _v510_price_reaction(src, of)
    spread = _v510_spread(of, src)
    buy = _v510_buy(of, src)
    sustain = _v510_sustain(of, src)
    # v519: paper_bot OPEN 필수 가격값을 strategy canonical row에서 봉인한다.
    sealed_price = _v510_num(
        src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
        of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
        of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
        default=0.0,
    )
    hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
    micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
    price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
    quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    stale_items = _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price, strict=True)
    decision_reasons, reason_structure_tags = _v520_split_reasons(reasons, stale_items)
    row = {
        "schema": "paper_candidate_v520_reason_spine_row",
        "version": VERSION,
        "ticker": t,
        "market": f"KRW-{t}" if t else src.get("market"),
        "symbol": f"{t}_KRW" if t else src.get("symbol"),
        "event_id": _v510_event_id(t, skey, lane, nowv),
        "event_key": _v510_event_id(t, skey, lane, nowv),
        "created_at": nowv,
        "candidate_created_at": nowv,
        "source_created_at": nowv,
        "detected_ts": nowv,
        "event_ts": nowv,
        "created_at_text": now_text(nowv),
        "updated_ts": nowv,
        "expires_at": nowv + (70 if stage == "S1" else 180),
        "strategy_key": skey,
        "paper_strategy_key": skey,
        "strategy_label": label,
        "strategy": label,
        "canonical_lane": lane,
        "s_stage": stage,
        "candidate_stage": stage,
        "candidate_grade": stage,
        "stage": stage,
        "grade": stage,
        "score": round(score, 3),
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "trade_price": sealed_price,
        "price_source": "strategy_v522_sealed",
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_reaction_pct": round(react, 4),
        "spread_pct": round(spread, 4),
        "slippage_pct": round(spread, 4),
        "buy_ratio": round(buy, 4),
        "buy_sustain_1m": round(sustain, 4),
        "change_1m_pct": _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0),
        "change_3m_pct": _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0),
        "change_5m_pct": _v510_num(src.get("change_5m"), src.get("price_change_5m"), default=0.0),
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "structure_tags": _v510_uniq(_v510_structure_tags(src) + reason_structure_tags, 10),
        "risk_tags": _v510_risk_tags(src, of, hard or []),
        "stale_reasons": stale_items,
        "freshness_status": "recheck" if stale_items else "fresh",
        "reason": " / ".join(decision_reasons),
        "s_stage_reasons": decision_reasons,
    }
    row["entry_context"] = {
        "strategy_key": skey,
        "strategy_label": label,
        "canonical_lane": lane,
        "structure_tags": row["structure_tags"],
        "risk_tags": row["risk_tags"],
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "freshness_status": "recheck" if stale_items else "fresh",
        "stale_reasons": stale_items,
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_source": "strategy_v522_sealed",
        "price_reaction_pct": react,
        "buy_ratio": buy,
        "buy_sustain_1m": sustain,
        "spread_pct": spread,
        "reasons": row["s_stage_reasons"],
    }
    return row


def _v510_final_gate(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    stage = _v510_stage(r)
    skey = str(r.get("strategy_key") or "")
    is_spike = skey in {"spike_momentum_ride", "spike_pullback_reaccel"}
    hot = _v510_num(r.get("hot_signal_age_sec"), default=999999.0)
    micro = _v510_num(r.get("micro_age_sec"), default=999999.0)
    order = _v510_num(r.get("orderflow_age_sec"), default=micro)
    price = _v510_num(r.get("price_reaction_age_sec"), default=999999.0)
    quote = _v510_num(r.get("quote_age_sec"), default=999999.0)
    paper_delay = max(0.0, nowv - _event_created_ts(r))
    sealed_price = _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0)
    stale: List[str] = _v520_fresh_stale_items(r, r, hot, micro, order, price, quote, sealed_price, strict=is_spike)
    if is_spike and paper_delay > 20:
        stale.append(f"paper {paper_delay:.1f}s")
    elif (not is_spike) and paper_delay > 45:
        stale.append(f"paper {paper_delay:.1f}s")
    stale = _v522_filter_stale_items(_v510_uniq(stale, 6), strict=is_spike)
    allowed = not stale
    if stage == "S1" and not allowed:
        r["v510_downgraded_from_s1"] = True
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S2"
        rr = list(r.get("s_stage_reasons") or []) + ["final_entry_gate 신선도 재확인: " + " / ".join(stale[:5])]
        r["s_stage_reasons"] = _v510_uniq(rr, 12)
    r["stale_reasons"] = stale
    r = _v520_normalize_reason_row(r)
    r["fresh_gate_ok"] = bool(allowed)
    r["open_eligible"] = bool(_v510_stage(r) == "S1" and allowed)
    r["paper_bot_open"] = bool(_v510_stage(r) == "S1" and allowed)
    r["trade_ready"] = bool(_v510_stage(r) == "S1" and allowed)
    r["v510_final_entry_gate"] = {
        "schema": "final_entry_gate_v522_single_freshness",
        "version": VERSION,
        "checked_ts": nowv,
        "age_values": {"hot": hot, "micro": micro, "orderflow": order, "price": price, "quote": quote, "paper": paper_delay},
        "stale_reasons": stale,
        "s1_allowed": bool(_v510_stage(r) == "S1" and allowed),
        "policy": "v522 single freshness gate. TTL 안의 hot/micro/orderflow age는 신선도재확인으로 남기지 않음.",
    }
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx); ctx["v510_final_entry_gate"] = r["v510_final_entry_gate"]
    r["entry_context"] = ctx
    return r


def _v510_base_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    rows: List[Dict[str, Any]] = []
    rejects: List[Dict[str, Any]] = []
    requests: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        hard = common_hard(src, of)
        core_hits: List[Tuple[str, List[str]]] = []
        core_fail: List[str] = []
        for skey, fn in evals:
            ok, why, no = fn(src, of)
            if ok: core_hits.append((skey, why))
            else: core_fail += [f"{STRATEGIES.get(skey, skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(src, core_hits, hard)
        info_bad = orderflow_info_bad(of) if need_info else []
        react = _v510_price_reaction(src, of)
        buy = _v510_buy(of, src)
        sustain = _v510_sustain(of, src)
        spread = _v510_spread(of, src)
        score = _priority_score(src, core_hits, info_bad, hard)
        reasons: List[str] = []
        skey = core_hits[0][0] if core_hits else "leader_flow_adaptive_hold_s"
        label = STRATEGIES.get(skey, skey).replace(" S", "")
        if core_hits:
            reasons += [f"구조:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
        reasons += hard[:4] + info_bad[:3]
        if react < 0.05: reasons.append("가격반응 기준근접(+0.00%→+0.05%)")
        if react < 0.35: reasons.append("가격반응 약함(+0.05%→+0.35%)")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70: reasons.append("1분 매수지속 부족")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        elif spread > 0.18: reasons.append(f"스프레드 경계값({spread:.2f}%)→재확인")
        stage = ""
        if core_hits and not hard and not info_bad and react >= 0.35 and buy >= 0.70 and sustain >= 0.70 and spread <= 0.18:
            stage = "S1"
        elif core_hits or (need_info and cheap_bucket in {"core_hit", "high_cheap"}) or score >= 88:
            # S2 is a recheck lane only; it is not paper OPEN.
            stage = "S2" if (core_hits or react >= 0.25 or score >= 105) else "S3"
        elif cheap_bucket == "high_cheap":
            stage = "S3"
        if not stage:
            rejects.append({"ticker": t, "score": score, "reasons": _v510_uniq(reasons + core_fail, 8), "updated_ts": nowv})
            continue
        row = _v510_make_row(src, of, stage, skey, label, "base", score, reasons or ["구조관찰"], nowv, hard)
        rows.append(row)
        need = []
        if not _v510_bool(of.get("quote_fresh") or of.get("ws_fresh")): need.append("quote")
        if not _v510_bool(of.get("micro_fresh")): need.append("micro")
        requests.append(_make_priority_request(t, src, "s_candidate" if stage == "S1" else "recheck_candidate", 100 + score + _STAGE_ORDER.get(stage,1)*20, need or ["micro"], core_hits, row.get("s_stage_reasons") or []))
    return rows, rejects, requests


def _v510_spike_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0)
        ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0)
        react = _v510_price_reaction(src, of)
        # Wide prefilter only. It does not cap candidates.
        if max(ch1, ch3, react) < 0.35:
            continue
        spread = _v510_spread(of, src); buy = _v510_buy(of, src); sustain = _v510_sustain(of, src)
        hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
        micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
        price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
        quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        sealed_price_probe = _v510_num(
            src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
            of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
            of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
            default=0.0,
        )
        fresh = not _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price_probe, strict=True)
        strong = (react >= 0.80 or ch1 >= 0.70 or ch3 >= 1.20) and buy >= 0.78 and sustain >= 0.78 and spread <= 0.18
        late_risk = (buy < 0.70 or sustain < 0.70 or spread > 0.35 or row_bool(src, "long_upper_wick"))
        stage = "S1" if fresh and strong and not late_risk else ("S2" if react >= 0.35 and spread <= 0.50 else "S3")
        skey = "spike_momentum_ride" if stage == "S1" and ch1 >= 0.70 else "spike_pullback_reaccel"
        label = "급등 진행형 탑승" if skey == "spike_momentum_ride" else "급등 후 눌림 재가속"
        reasons: List[str] = []
        if stage == "S1": reasons.append("fresh urgent 급등 확인")
        elif not fresh: reasons.append("눌림 재가속 재확인")
        else: reasons.append("눌림 재가속 재확인")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70: reasons.append("1분 매수지속 부족")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        score = 100 + max(0.0, react)*10 + max(0.0, ch1)*4 + max(0.0, ch3)*3 + max(0.0, buy)*2
        row = _v510_make_row(src, of, stage, skey, label, "spike", score, reasons, nowv, [])
        rows.append(_v520_normalize_reason_row(row))
    return rows


def row_bool(row: Dict[str, Any], key: str) -> bool:
    try:
        return _v510_bool(row.get(key))
    except Exception:
        return False


def _v510_merge_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        if not isinstance(r, dict): continue
        r = _v510_final_gate(r, nowv)
        t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t: continue
        sk = str(r.get("strategy_key") or "strategy")
        lane = str(r.get("canonical_lane") or "base")
        key = f"{t}:{sk}:{lane}"
        prev = merged.get(key)
        if prev is None:
            merged[key] = r; continue
        a = (_STAGE_ORDER.get(_v510_stage(r), 0), _v510_num(r.get("score"), default=0.0), _event_created_ts(r))
        b = (_STAGE_ORDER.get(_v510_stage(prev), 0), _v510_num(prev.get("score"), default=0.0), _event_created_ts(prev))
        if a >= b:
            merged[key] = r
    out = sorted(merged.values(), key=lambda x: (_STAGE_ORDER.get(_v510_stage(x),0), _v510_num(x.get("score"), default=0.0), _event_created_ts(x)), reverse=True)
    return out


def _v510_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v510_stage(r)
        c[st] = c.get(st, 0) + 1
    return c


def _v510_reason_top(rows: List[Dict[str, Any]], maxn: int = 20) -> List[Dict[str, Any]]:
    ctr: Dict[str, int] = {}
    for r in rows:
        if _v510_stage(r) == "S1": continue
        for reason in (r.get("s_stage_reasons") or r.get("block_reasons") or [])[:6]:
            s = str(reason or "").strip()
            if not s: continue
            # Collapse numeric variants lightly for panel readability.
            if "스프레드" in s: s = "스프레드"
            elif "미끄러짐" in s: s = "미끄러짐"
            elif "매수체결" in s: s = "매수체결"
            elif "1분" in s: s = "1분지속"
            elif "가격반응" in s: s = "가격반응"
            elif "신선" in s: s = "신선도재확인"
            ctr[s] = ctr.get(s, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(ctr.items(), key=lambda kv: kv[1], reverse=True)[:maxn]]



def _v512_info_quality(feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    """상태판이 읽는 정보품질 숫자를 single-pass canonical 기준으로 채운다.

    v510은 final_rows는 정상 생산했지만 /health 상단 정보요약이 0/전체로 표시됐다.
    이유는 예전 status/summary reader가 기대하던 quote_ready_count/micro_ready_count/full_info_ready_count
    계열 필드를 publish하지 않았기 때문이다. 여기서는 후보 조건을 바꾸지 않고, 같은 입력 feature/orderflow에서
    정보품질 숫자만 확정한다.
    """
    evaluated = len(feature_list)
    quote_ready = 0
    micro_ready = 0
    both_ready = 0
    orderflow_attached = 0
    price_ready = 0
    for row in feature_list:
        t = ticker_norm(row.get("ticker"))
        of = ofmap.get(t, {}) if t else {}
        has_price = _v510_num(row.get("current_price"), row.get("price"), of.get("quote_price"), of.get("current_price"), default=0.0) > 0
        quote = bool(of.get("quote_fresh") or of.get("ws_fresh") or has_price)
        micro = bool(of.get("micro_fresh") or of.get("orderflow_fresh") or of.get("buy_ratio") is not None or of.get("spread_pct") is not None)
        attached = bool(of)
        if has_price:
            price_ready += 1
        if attached:
            orderflow_attached += 1
        if quote:
            quote_ready += 1
        if micro:
            micro_ready += 1
        if quote and micro:
            both_ready += 1
    return {
        "price_ready_count": price_ready,
        "quote_ready_count": quote_ready,
        "market_price_ready_count": price_ready,
        "micro_ready_count": micro_ready,
        "full_info_ready_count": both_ready,
        "both_ready_count": both_ready,
        "orderflow_attached_count": orderflow_attached,
    }


def _v512_display_rows(rows: List[Dict[str, Any]], maxn: int = 80) -> List[Dict[str, Any]]:
    """candidate_reason/s1_lifecycle이 모두 볼 수 있는 표시 row aliases를 만든다.

    명령어 handler마다 top_candidates/items/rows/display_rows 중 서로 다른 key를 보던 구버전 흔적이 남아 있으므로,
    v512에서는 같은 canonical row를 여러 alias로만 publish한다. 새 계산 경로는 만들지 않는다.
    """
    out: List[Dict[str, Any]] = []
    for r in rows[:maxn]:
        rr = dict(r)
        rr.setdefault("display_name", rr.get("ticker") or rr.get("symbol"))
        rr.setdefault("stage", _v510_stage(rr))
        rr.setdefault("s_stage", _v510_stage(rr))
        rr.setdefault("strategy_label", rr.get("strategy") or rr.get("strategy_name") or rr.get("paper_strategy_label"))
        rr.setdefault("strategy_name", rr.get("strategy_label"))
        rr.setdefault("block_reasons", rr.get("s_stage_reasons") or rr.get("reasons") or [])
        rr.setdefault("missing_info", rr.get("missing_info") or [])
        rr.setdefault("structure_tags", rr.get("structure_tags") or rr.get("quality_structure_tags") or [])
        rr.setdefault("risk_tags", rr.get("risk_tags") or rr.get("quality_risk_tags") or [])
        out.append(rr)
    return out

def _v512_save_aliases(paths: List[Path], obj: Dict[str, Any]) -> None:
    """Write identical cache objects to historical filenames without creating a second calculation path."""
    seen: set[str] = set()
    for path in paths:
        key = str(path)
        if key in seen:
            continue
        seen.add(key)
        save_json(path, obj)


def _v512_enrich_summary_pointers(summary: Dict[str, Any], compact: Dict[str, Any], life: Dict[str, Any], recheck: Dict[str, Any]) -> None:
    """Expose cache pointers expected by older main-bot status readers."""
    ts = compact.get("updated_ts")
    summary.update({
        "candidate_reason_compact_cache_schema": compact.get("schema"),
        "candidate_reason_compact_cache_ts": ts,
        "candidate_reason_compact_cache_updated_ts": ts,
        "candidate_reason_compact_cache_status": compact.get("status", "fresh"),
        "candidate_reason_compact_cache_count": compact.get("candidate_count", 0),
        "candidate_reason_compact_cache_display_count": compact.get("display_count", 0),
        "candidate_reason_cache_file": str(CANDIDATE_REASON_COMPACT_CACHE),
        "s1_lifecycle_schema": life.get("schema"),
        "s1_lifecycle_ts": life.get("updated_ts"),
        "s1_lifecycle_worker": life.get("worker"),
        "s1_lifecycle_fresh_count": life.get("fresh_count", 0),
        "s1_lifecycle_raw_count": life.get("raw_count", 0),
        "s1_lifecycle_cache_file": str(S1_LIFECYCLE_TRACE),
        "recheck_cache_schema": recheck.get("schema"),
        "recheck_cache_ts": recheck.get("updated_ts"),
        "recheck_candidate_count": recheck.get("candidate_count", 0),
    })


def _v513_legacy_candidate_reason_top(display_rows: List[Dict[str, Any]], limit: int = 10) -> List[Dict[str, Any]]:
    """Build the old /candidate_reason top_candidates shape from the same canonical display rows.

    Main-bot v468 is strict about the compact-cache schema/key shape.  We keep one
    canonical row source, but publish the compact payload in the legacy-compatible
    shape so the command does not report "cache 없음" while health/lifecycle can
    still read the same final rows.
    """
    top: List[Dict[str, Any]] = []
    for rr in display_rows[:limit]:
        st = _v510_stage(rr)
        fail = rr.get("block_reasons") or rr.get("s_stage_reasons") or rr.get("reasons") or []
        miss = rr.get("missing_info") or rr.get("entry_missing_info") or []
        risk = rr.get("risk_tags") or rr.get("structure_risk_tags") or []
        metrics = {
            "price_reaction_pct": _v510_num(rr.get("price_reaction_pct"), default=0.0),
            "spread_pct": _v510_num(rr.get("spread_pct"), default=0.0),
            "slippage_pct": _v510_num(rr.get("slippage_pct"), rr.get("spread_pct"), default=0.0),
            "buy_ratio": _v510_num(rr.get("buy_ratio"), default=0.0),
            "buy_sustain_1m": _v510_num(rr.get("buy_sustain_1m"), rr.get("buy_ratio"), default=0.0),
        }
        top.append({
            "ticker": ticker_norm(rr.get("ticker") or rr.get("market") or rr.get("symbol")),
            "stage": st,
            "s_stage": st,
            "strategy": str(rr.get("strategy_label") or rr.get("strategy") or rr.get("strategy_key") or "-"),
            "strategy_key": str(rr.get("strategy_key") or rr.get("paper_strategy_key") or "-"),
            "score": round(_v510_num(rr.get("score"), default=0.0), 2),
            "decision": str(rr.get("recheck_state") or rr.get("review_decision") or "-"),
            "block_reasons": _v510_uniq([str(x) for x in fail], 4),
            "missing_info": _v510_uniq([str(x) for x in miss], 3),
            "metrics": metrics,
            "metric_spine_source": "v513_canonical_final_rows",
            "needed_recovery": rr.get("needed_recovery") or rr.get("need_recovery") or [],
            "relative_context": rr.get("relative_context") or {},
            "structure_tags": rr.get("structure_tags") or [],
            "structure_good_tags": rr.get("structure_good_tags") or rr.get("structure_tags") or [],
            "structure_risk_tags": risk,
            "risk_tags": risk,
            "structure_fit": rr.get("structure_fit") or rr.get("structure_summary") or ("구조위험" if risk else "구조관찰"),
            "structure_summary": rr.get("structure_summary") or "",
            "market_regime_tags": rr.get("market_regime_tags") or [],
            "market_risk_tags": rr.get("market_risk_tags") or [],
            "market_regime_summary": rr.get("market_regime_summary") or "",
            "snapshot_ts": rr.get("updated_ts") or rr.get("created_at") or now_ts(),
            "snapshot_text": rr.get("updated_text") or now_text(),
            "fresh_for_paper": True,
        })
    return top

def _v510_publish(rows: List[Dict[str, Any]], rejects: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], evaluated: int, cycle_ts: float, info_quality: Optional[Dict[str, int]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    counts = _v510_counts(rows)
    info_quality = info_quality or {}
    display_rows = _v512_display_rows(rows, 120)
    lane_counts: Dict[str, int] = {}
    for r in rows:
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    write_jsonl_atomic(PAPER_LATEST, rows)
    # Runtime OPEN does not append to archive. Archive/trade log stays paper-owned/history-only.
    priority_requests = sorted(priority_requests, key=lambda x: _v510_num(x.get("priority"), default=0.0), reverse=True)
    targets = list(dict.fromkeys([ticker_norm(r.get("ticker")) for r in priority_requests if ticker_norm(r.get("ticker"))]))
    pr_obj = {"schema": "strategy_priority_requests_v512", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "request_count": len(priority_requests), "targets": targets, "requests": priority_requests, "buckets": {}}
    for pr in priority_requests:
        b = str(pr.get("bucket") or "-"); pr_obj["buckets"][b] = pr_obj["buckets"].get(b, 0) + 1
    save_json(PRIORITY_REQ, pr_obj)
    reason_top = _v510_reason_top(rows)
    summary = {"schema": V510_SCHEMA, "version": VERSION, "main_version": MAIN_VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "evaluated": evaluated, "paper_latest_count": len(rows), "s_count": len(rows), "s_stage_counts": counts, "stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "lane_counts": lane_counts, "reason_top": reason_top, "target_count": len(targets), "priority_request_count": len(priority_requests), "events": display_rows[:20], "sample": display_rows[:20], "top_candidates": display_rows[:20], "last_sec": round(nowv - cycle_ts, 3), "policy": "v513: candidate_reason은 v473 호환 schema/key로 publish하고, 실제 row는 v510+ single-pass canonical final_rows 하나만 사용. 조건/청산/자동매수 변경 없음."}
    summary.update(info_quality)
    summary["freshness_overlay"] = {"schema": "v522_single_freshness_gate", "scanner_hot_cache_age_sec": round(_v521_file_age(SCANNER_HOT), 3), "orderflow_cache_age_sec": round(_v521_file_age(ORDERFLOW), 3)}
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    legacy_top = _v513_legacy_candidate_reason_top(display_rows, limit=10)
    compact = {"schema": "candidate_reason_compact_cache_v473_metric_spine", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "status": "fresh", "evaluated": evaluated, "paper_latest_count": len(rows), "candidate_count": len(rows), "raw_candidate_count": len(rows), "stale_candidate_count": 0, "stale_s1_ignored_count": 0, "display_count": len(display_rows), "s_stage_counts": counts, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": [x for x in reason_top if "정보" in x.get("reason", "")], "metric_spine_source_top": [{"reason": "v513_canonical_final_rows", "count": len(rows)}], "top_candidates": legacy_top, "display_rows": display_rows, "display_candidates": display_rows, "candidates": display_rows, "items": display_rows, "rows": display_rows, "top": legacy_top, "policy": summary["policy"]}
    compact.update(info_quality)
    compact["top_rows"] = legacy_top
    compact["display_candidates"] = compact.get("display_rows", [])
    compact["source_file"] = str(PAPER_LATEST)
    compact["source_policy"] = summary["policy"]
    _v512_save_aliases(CANDIDATE_REASON_ALIAS_FILES, compact)
    re_rows = [r for r in rows if _v510_stage(r) in ("S2", "S3")]
    re_state_counts: Dict[str, int] = {}
    for r in re_rows:
        st = "위험우선" if r.get("risk_tags") else ("유연재확인" if _v510_stage(r) == "S2" else "추적중")
        r["recheck_state"] = st
        re_state_counts[st] = re_state_counts.get(st, 0) + 1
    recheck_display = _v512_display_rows(re_rows, 160)
    recheck = {"schema": "recheck_candidates_cache_v513", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "candidate_count": len(re_rows), "state_counts": re_state_counts, "top": recheck_display[:80], "top_candidates": recheck_display[:80], "display_rows": recheck_display, "rows": recheck_display, "promotion_summary": {"s1_promotion_count": counts.get("S1",0), "policy": "S2/S3 재확인은 paper OPEN이 아니다."}}
    save_json(RECHECK_CACHE, recheck)
    save_json(RECHECK_STATE, {"schema": "recheck_candidates_state_v510", "version": VERSION, "updated_ts": nowv, "active": {str(r.get("event_id")): r for r in re_rows[:200]}})
    s1_rows = [r for r in display_rows if _v510_stage(r)=="S1"]
    life = {"schema": "s1_lifecycle_trace_v513_canonical", "version": VERSION, "worker": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "current_s1_count": counts.get("S1",0), "current_s2_count": counts.get("S2",0), "current_s3_count": counts.get("S3",0), "recent_s1_count": counts.get("S1",0), "paper_waiting_count": 0, "paper_pre_downgrade_count": 0, "paper_block_count": 0, "paper_final_block_count": 0, "expired_s1_ignored_count": 0, "fresh_count": len(rows), "raw_count": len(rows), "current_fresh_count": len(rows), "current_raw_count": len(rows), "fresh_candidate_count": len(rows), "raw_candidate_count": len(rows), "counts": counts, "stage_counts": counts, "current_s1": s1_rows, "current_s1_rows": s1_rows, "paper_waiting": [], "paper_pre_downgrade": [], "paper_blocked": [], "paper_final_blocked": [], "expired_s1_ignored": [], "flow_rows": display_rows[:80], "recent_flow": display_rows[:80], "recent_rows": display_rows[:80], "top": display_rows[:80], "rows": display_rows, "policy": "candidate_reason/s1_lifecycle/summary all read the same final_rows."}
    _v512_save_aliases(S1_LIFECYCLE_ALIAS_FILES, life)
    save_json(S1_LIFECYCLE_STATE, {"schema": "s1_lifecycle_state_v513", "version": VERSION, "updated_ts": nowv, "active": {str(r.get("event_id")): r for r in rows[:240]}})
    # v512: summary/health readers also need direct pointers to compact/lifecycle caches.
    _v512_enrich_summary_pointers(summary, compact, life, recheck)
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    can = {"schema": "strategy_canonical_summary_v513", "version": VERSION, "updated_ts": nowv, "cycle_started_ts": cycle_ts, "cycle_elapsed_sec": round(nowv-cycle_ts,3), "s_stage_counts": counts, "paper_latest_count": len(rows), "candidate_reason": {"schema": compact["schema"], "updated_ts": nowv, "candidate_count": len(rows)}, "recheck": {"schema": recheck["schema"], "updated_ts": nowv, "candidate_count": len(re_rows)}, "s1_lifecycle": {"schema": life["schema"], "updated_ts": nowv, "current_s1_count": counts.get("S1",0)}, "source_policy": summary["policy"]}
    save_json(CANONICAL_STRATEGY_SUMMARY, can)
    price_ready_count = sum(1 for r in rows if _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0) > 0)
    save_json(HANDOFF, {"schema": "paper_handoff_status_v522", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "latest_count": len(rows), "stage_counts": counts, "lane_counts": lane_counts, "price_ready_count": price_ready_count, "source": "paper_candidates_latest", "archive_runtime_open": False, "old_latest_remix": False, "price_policy": "strategy seals current_price/entry_price/detected_price for paper_bot"})
    save_json(V510_TRACE, {"schema": V510_SCHEMA, "version": VERSION, "updated_ts": nowv, "elapsed_sec": round(nowv-cycle_ts,3), "evaluated": evaluated, "stage_counts": counts, "lane_counts": lane_counts, "reason_top": reason_top, "sample": rows[:12]})
    write_status("running", phase="cycle_done_v522", phase_note="v522 freshness single-gate spine publish 완료", phase_started_ts=cycle_ts, strategy_worker_version=VERSION, main_version=MAIN_VERSION, deploy_version=MAIN_DEPLOY_VERSION, evaluated=evaluated, row_count=evaluated, s_count=len(rows), paper_latest_count=len(rows), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0), target_count=len(targets), priority_request_count=len(priority_requests), last_sec=round(nowv-cycle_ts,3), status_route_schema="strategy_status_v522_freshness_single_gate", **info_quality)
    return summary


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    try:
        write_status("running", phase="evaluating_v522", phase_note="v522 freshness single-gate spine 시작", strategy_worker_version=VERSION)
        fobj = load_json(FEATURE, {}) or {}
        raw_feature_list = feature_rows(fobj)
        hotmap = _v521_hot_map()
        feature_list = [_v521_overlay_feature(src, hotmap.get(ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol")), {})) for src in raw_feature_list]
        ofmap = _v521_load_map_with_cache_age(ORDERFLOW, "orderflow")
        base_rows, rejects, reqs = _v510_base_lane(cycle_ts, feature_list, ofmap)
        spike_rows = _v510_spike_lane(cycle_ts, feature_list, ofmap)
        final_rows = _v510_merge_rows(base_rows + spike_rows, cycle_ts)
        info_quality = _v512_info_quality(feature_list, ofmap)
        # Requests from spike rows are added after merge so stale/blocked rows still get recheck/urgent targets if useful.
        for r in final_rows:
            t = ticker_norm(r.get("ticker"))
            if not t: continue
            bucket = "s1_candidate" if _v510_stage(r)=="S1" else ("spike_recheck" if str(r.get("canonical_lane"))=="spike" else "recheck_candidate")
            pri = 180 if _v510_stage(r)=="S1" else (130 if _v510_stage(r)=="S2" else 90)
            reqs.append({"ticker": t, "bucket": bucket, "priority": pri + _v510_num(r.get("score"), default=0.0), "need": ["quote", "micro"], "source": "strategy_worker_v513", "strategy_key": r.get("strategy_key"), "stage": _v510_stage(r), "reasons": r.get("s_stage_reasons", [])[:6], "updated_ts": cycle_ts})
        return _v510_publish(final_rows, rejects, reqs, len(feature_list), cycle_ts, info_quality)
    except Exception as exc:
        append_error(ERROR, "v513_run_once", exc)
        write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        raise


def main() -> None:  # type: ignore[override]
    write_status("running", phase="boot_v513", evaluated=0, s_count=0, target_count=0, last_sec=0, strategy_worker_version=VERSION)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping", strategy_worker_version=VERSION)
            raise
        except Exception as exc:
            append_error(ERROR, "loop_v512", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        time.sleep(max(0.5, INTERVAL_SEC))


if __name__ == "__main__":
    main()
