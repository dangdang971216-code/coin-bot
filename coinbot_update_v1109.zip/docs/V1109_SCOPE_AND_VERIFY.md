# v1109 Strategy 병목 수술 + 재발 원인지도

## 실제 원인
`strategy_worker.attach_structure_lab`의 context 및 A/B/C/D/E 관찰 메서드가 같은 완료봉 프레임을 한 cycle 안에서 반복 변환·정렬했다.

## 수정
- `_lab_rows`에 bounded normalized-frame LRU cache를 단일 본선으로 추가.
- key: timeframe + frame list identity + length + first/middle/last OHLCV signature.
- source identity/signature 변경 시 자동 miss 후 재생성.
- empty frame은 cache를 오염시키지 않는다.
- cache hit/miss, parsed rows, parse wall/CPU, entries/evictions를 매 cycle 기록.

## 재발 지도
`/flow_map`의 FLOW-08 Strategy 원인진단에 아래를 표시한다.
- 전체 Strategy cycle
- 실제 top completed phase
- Structure Lab direct subphase
- input rows
- frame-cache hit/miss/ratio
- parse CPU
- owner/caller/writer/reader
- 영향 단계와 수정 파일

20초 이상이면 `STRATEGY_CYCLE_SLOW`로 CHECK하며, cache 회귀인지 다음 subphase 병목인지 구분한다.

## 변경 금지 영역
품질 threshold, trigger, invalid, target, actual-entry RR, slippage 한도, OPEN 30/cycle 3, 청산계약, 핵심 원장, 자동매수 OFF는 변경하지 않았다.

## 서버 검수
1. 가드봇 `/gupgrade_bundle` 단독
2. 가드봇 `/gops_refresh`
3. 메인봇 `/flow_map` + `/errorlog`

DONE 기대:
- Main v2.13.1093
- Guard v2.5.162
- Strategy v1.002
- FLOW-08 exact location
- frame cache lookups > 0, warm hit ratio >= 0.80
- Strategy cycle < 20s
- runtime mismatch 0
- 매매계약 변경 0 / 자동매수 OFF
