#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, os, sys, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

guard=load('guard_v1197',ROOT/'backga_guard_bot_v2_5_204.py')
spine=load('spine_v1197',ROOT/'canonical_spine_v1190.py')

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def age(p,sec):
    t=time.time()-sec; os.utime(p,(t,t))

def test_retention_never_truncates_active_candidate_files():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); old=guard.BOT_DIR; guard.BOT_DIR=root
        try:
            active={}
            names=['paper_candidates.jsonl','paper_candidates_latest.jsonl','paper_candidates_handoff_merged.jsonl','candidate_events.jsonl','paper_bot_candidate_handoff_trace.jsonl','paper_candidate_path_events_v1153.jsonl']
            for name in names:
                p=root/name; p.write_text(''.join(json.dumps({'i':i,'name':name})+'\n' for i in range(1200)),encoding='utf-8')
                active[name]=(p.stat().st_size,sha(p))
            stale=root/'.bundle_unpack_1'; stale.mkdir(); (stale/'x').write_bytes(b'x'*1024); age(stale,4000); age(stale/'x',4000)
            res=guard.run_retention_cleanup(False)
            assert res['errors']==0,res
            assert not stale.exists(),res
            for name,expected in active.items():
                p=root/name; assert (p.stat().st_size,sha(p))==expected,name
            state=json.loads((root/'clean_retention_state.json').read_text())
            assert state['policy']['active_candidate_snapshot_truncate'] is False
            assert state['policy']['active_candidate_path_truncate'] is False
        finally: guard.BOT_DIR=old

def test_storage_grace_matches_cleanup_owner():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        p=root/'.bundle_unpack_recent'; p.mkdir(); age(p,600)
        a=spine._storage_hygiene_summary(root,time.time())
        assert a['state']=='NORMAL',a
        age(p,1900)
        b=spine._storage_hygiene_summary(root,time.time())
        assert b['state']=='CHECK' and b['abandoned_temp'][0]['auto_cleanup'] is True,b

def test_old_unscoped_lines_do_not_keep_current_runtime_check():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); p=root/'clean_brain_error.log'; p.write_text('Traceback (most recent call last):\n old\n')
        old_start=spine._runtime_start_for_error_log; old_events=spine._error_events
        try:
            spine._runtime_start_for_error_log=lambda base,name: time.time()-100
            spine._error_events=lambda path,start:{'current':[],'historical':[],'unscoped':['old'],'line_count':1}
            age(p,1000)
            out=spine._error_scope_summary(root)
            assert out['state']=='NORMAL',out
            assert out['unscoped_line_count']==1
        finally:
            spine._runtime_start_for_error_log=old_start; spine._error_events=old_events

def write_profile(root, completed_ts, total=40.0):
    d=root/'runtime'; d.mkdir(exist_ok=True)
    payload={'component':'paper','version':'paper_bot_v1.052','pid':123,'scopes':{'exit_monitor':{'state':'NORMAL','total_sec':total,'last_sec':total,'completed_ts':completed_ts,'publish_interval_sec':10,'top_functions':[]}}}
    (d/'runtime_phase_profile_paper_v1190.json').write_text(json.dumps(payload))

def test_phase_slow_requires_current_scope():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); now=time.time(); write_profile(root,now-200,40)
        runtime={'components':[{'component':'paper','main_pid':123,'status_version':'paper_bot_v1.052','status_age_sec':1}]}
        out=spine._phase_profile_summary(root,now,runtime)
        assert not [x for x in out['slow_observations'] if x['component']=='paper'],out['slow_observations']
        write_profile(root,now,40)
        out2=spine._phase_profile_summary(root,now,runtime)
        assert [x for x in out2['slow_observations'] if x['component']=='paper'],out2['slow_observations']

def test_ops_map_decouples_paper_read_timing_and_guard_resources():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        (root/'strategy_candidate_pipeline_commit_v1150.json').write_text(json.dumps({'state':'NORMAL','complete':True,'cycle_id':'c1','candidate_commit_id':'k1','candidate_rows':461,'s1_hold_count':10,'all_required_commits_v1150':True,'committed_handoff_file_v1158':'handoff.json'}))
        (root/'handoff.json').write_text(json.dumps({'cycle_id':'c1','candidate_commit_id':'k1'}))
        (root/'review_observation_request_v1181.json').write_text(json.dumps({'cycle_id':'c1','candidate_commit_id':'k1'}))
        (root/'canonical_review_snapshot_v1181.json').write_text(json.dumps({'source':{'pipeline_cycle_id':'c1','candidate_commit_id':'k1'},'candidate':{'total':461,'s1':10}}))
        (root/'canonical_candidate_standard_v1181.json').write_text(json.dumps({'state':'NORMAL','snapshot_id':'s1'}))
        (root/'canonical_performance_snapshot_v987.json').write_text(json.dumps({'snapshot_id':'p1'}))
        old_status=spine._status_record
        old_helpers={name:getattr(spine,name) for name in ['_timing_path_summary','_paper_funnel_summary','_open_monitor_summary','_ledger_summary','_error_scope_summary','_runtime_contract','_command_delivery_summary','_resource_summary','_artifact_chain_summary','_storage_hygiene_summary','_phase_profile_summary']}
        try:
            def fake_status(label,path,owner,*a,**k):
                raw={}
                if owner=='strategy_worker': raw={'paper_latest_count':461,'s1_count':10,'full_cycle_sec_v1181':8.0,'execution_handoff_sec_v1181':7.0}
                if owner=='paper_bot': raw={'pick_stats':{'paper_generation_candidate_count_v1158':461,'s1_seen':10,'selected_s1':0,'paper_funnel_accounted_v1102':10,'paper_funnel_balance_ok_v1102':True},'elapsed_sec':8.0,'opened_this_cycle':0,'closed_this_cycle':0}
                return {'state':'NORMAL','raw':raw,'age_sec':1,'reason':'','version':'x'}
            spine._status_record=fake_status
            spine._timing_path_summary=lambda *a,**k:{'state':'COLLECTING','direct':{'strategy_execution_handoff_sec':7,'strategy_full_cycle_sec':8,'paper_cycle_sec':8},'slow_observations':[],'paper_received_identity_count':0,'repeat_exposure_count':0,'scope_cycle_id':'c1','scope_candidate_commit_id':'k1'}
            spine._paper_funnel_summary=lambda *a,**k:{'state':'NORMAL','s1_seen':10,'selected':0,'opened':0,'closed':0,'accounted':10,'unclassified':0,'balance_ok':True,'actual_integrity_exclusions':{},'audit_only_findings':{},'terminal_counts':{}}
            spine._open_monitor_summary=lambda *a,**k:{'state':'NORMAL','open_count':0}
            spine._ledger_summary=lambda *a,**k:{'state':'NORMAL','raw_rows':0,'exact_rows':0,'snapshot_id':'p1','semantic_current':True,'duplicates':0,'missing_decision_key':0,'unlinked':0}
            spine._error_scope_summary=lambda *a,**k:{'state':'NORMAL','current_count':0,'unscoped_line_count':0}
            spine._runtime_contract=lambda *a,**k:{'state':'NORMAL','components':[],'locks':[],'problems':[]}
            spine._command_delivery_summary=lambda *a,**k:{'state':'NORMAL','delivery_total_sec':1}
            spine._resource_summary=lambda *a,**k:{'state':'CHECK','disk_free_gb':4.0,'slow_cpu':[{'component':'strategy','cpu_pct':80.0}],'high_rss':[]}
            spine._artifact_chain_summary=lambda *a,**k:{'state':'NORMAL'}
            spine._storage_hygiene_summary=lambda *a,**k:{'state':'NORMAL'}
            spine._phase_profile_summary=lambda *a,**k:{'state':'NORMAL','slow_observations':[],'missing_components':[]}
            out=spine.build_ops_snapshot(root)
            stage={x['index']:x for x in out['stages']}
            assert stage[11]['state']=='NORMAL',stage[11]
            assert stage[20]['state']=='NORMAL',stage[20]
            codes=[x['code'] for x in out['problems']]
            assert 'FLOW-11-PAPER_READ' not in codes,codes
            assert 'FLOW-20-GUARD' not in codes,codes
            assert 'RESOURCE-CHECK' in codes,codes
        finally:
            spine._status_record=old_status
            for n,v in old_helpers.items(): setattr(spine,n,v)


def test_bundle_declares_support_reload_path():
    source=(ROOT/'backga_guard_bot_v2_5_204.py').read_text(encoding='utf-8')
    assert "restart_support_dependents" in source
    assert "main_support_reload" in source

if __name__=='__main__':
    tests=[test_retention_never_truncates_active_candidate_files,test_storage_grace_matches_cleanup_owner,test_old_unscoped_lines_do_not_keep_current_runtime_check,test_phase_slow_requires_current_scope,test_ops_map_decouples_paper_read_timing_and_guard_resources,test_bundle_declares_support_reload_path]
    for fn in tests: fn(); print('PASS',fn.__name__)
    print(f'PASS {len(tests)}/{len(tests)}')
