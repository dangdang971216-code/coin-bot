coinbot update v2143

Purpose
- Separate first-observation states from real WAIT transitions.
- Count only distinct-snapshot WAIT -> Trigger/T1/invalid events; zero-time effects are excluded.
- Show 6h finalized total and prediction/Brier eligibility separately without rewriting history.
- Keep only the current V2 exact OPEN/CLOSED alert visible in the Paper room.

Changed
- Main v2.13.2122
- Paper v2.085
- Review v2.054

Unchanged
- Guard, Strategy and all other workers
- Trigger/invalid/target/RR/entry/exit and candidate numeric conditions
- All canonical/exact ledgers, v2142 Review rows and Shadow data
- Auto-buy OFF
