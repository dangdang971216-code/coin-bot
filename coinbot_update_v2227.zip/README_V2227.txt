코인봇 v2227

목적
1. Review 4.7GB 전체백필 100% 완료본이 cycle_complete=False로 남아 상승예측 결과가 숨은 연결 오류 수리.
2. Paper -2% 방어의 전체 exact OPEN/퇴역보존/활성/현재세대/기타세대/성과 OPEN 범위 분리.
3. /version_score의 동일 -2% 판 중복 표시 제거.

변경
- Main v2.13.2185
- Paper v2.118
- Review v2.098
- Guard v2.6.54 유지(번들 미포함, 재시작 없음)

불변
- 상승예측 식/가중치/양수선 변경 0
- 후보/S1/구조선/trigger/invalid/target/RR 변경 0
- 진입/청산 수치 변경 0
- 기존 v2213 Shadow와 exact 원장 보존
- 자동매수 OFF

상태: LOCAL_PASS / SERVER_CHECK
