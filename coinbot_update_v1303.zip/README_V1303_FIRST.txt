coinbot_update_v1303 · v1211식 /version_score 보기판 + 후보품질 원인판

상태: LOCAL_DONE / SERVER_CHECK
자동매수: OFF
원장 삭제·축소·재작성: 없음
후보/진입 기준: v1211 clean rebase 유지
trigger/invalid/target/RR: 변경 없음

변경 목적:
- /version_score를 v1211 때처럼 줄바꿈과 구간을 보기 좋게 정리
- 상단: 실제 Paper 제한판(OPEN 10개 / cycle당 2개, 점수순 선발)의 시간별 승률·수익률 표시
- 하단: 갯수제한 없는 경우는 별도 shadow 원장이 있을 때만 표시하고, 없으면 수집 중으로 표시
- 후보품질을 나중에 만질 때 필요한 원인판 추가
- /pzero_reset_v1303, /pzero_status_v1303 명령 alias 추가

중요:
- 무제한판은 실제로 진입하지 않은 후보를 기존 CLOSED로 꾸미지 않는다.
- 후보 품질 원인판은 읽기 전용이며 기준 완화나 BUY_READY 강제를 하지 않는다.
