v1716: direct current S1 hold consumer restored to v1152 speed. Auto-buy OFF. No strategy threshold/TTL/RR/exit changes.
