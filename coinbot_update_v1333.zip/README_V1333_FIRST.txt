v1333 shadow optimizer audit only. Apply with /gupgrade_bundle. Then run /score_reason_audit and /exit_shadow_audit. Auto-buy remains OFF. No trading rules changed.
