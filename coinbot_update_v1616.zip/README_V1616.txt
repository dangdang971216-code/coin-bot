v1616 commit spine + trigger cause split. No trading rule change. Auto-buy OFF.
