v1410: original guard apply code restore. Guard source is based on v1401 stable apply flow; no disk/async/apply-flow experiments. Auto-buy OFF. No strategy rule changes.
