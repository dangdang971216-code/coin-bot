#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request, gzip
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="scanner_worker_v0.945"
INTERVAL_SEC=float(os.getenv("SCANNER_WORKER_INTERVAL_SEC","2.0"))
HTTP_TIMEOUT_SEC=float(os.getenv("SCANNER_WORKER_HTTP_TIMEOUT_SEC","3.0"))
STATUS=BASE_DIR/"clean_scanner_status.json"; MARKET=BASE_DIR/"clean_scanner_market_cache.json"; POOL=BASE_DIR/"clean_scanner_candidate_pool.json"; HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"; ERROR=BASE_DIR/"clean_scanner_error.log"
HOT_WATCH_STATE=BASE_DIR/"clean_hot_watch_scanner_state.json"
HOT_WATCH_SNAPSHOT=BASE_DIR/"clean_hot_watch_scanner_snapshot.json"
HOT_WATCH_EVENTS=BASE_DIR/"clean_hot_watch_scanner_events.jsonl"
HOT_WATCH_ARCHIVE=BASE_DIR/"hot_watch_archive"
HOT_WATCH_GAP_SEC=float(os.getenv("HOT_WATCH_GAP_SEC","300"))
HOT_WATCH_STATE_KEEP_SEC=float(os.getenv("HOT_WATCH_STATE_KEEP_SEC","86400"))
HOT_WATCH_RANK_TOP_N=max(1,int(float(os.getenv("HOT_WATCH_RANK_TOP_N","5"))))
HOT_WATCH_MIN_1M_PCT=float(os.getenv("HOT_WATCH_MIN_1M_PCT","0.20"))
HOT_WATCH_MIN_3M_PCT=float(os.getenv("HOT_WATCH_MIN_3M_PCT","0.40"))
HOT_WATCH_EVENT_MAX_BYTES=int(float(os.getenv("HOT_WATCH_EVENT_MAX_BYTES",str(50*1024*1024))))
HOT_WATCH_EVENT_KEEP_LINES=max(1000,int(float(os.getenv("HOT_WATCH_EVENT_KEEP_LINES","5000"))))
STABLE={"USDT","USDC","DAI","BUSD","FDUSD","TUSD","USDS","USD1","PYUSD","USDE","RLUSD"}; MAJOR={"BTC","ETH","XRP"}

# v481: scanner 자체가 ALL_KRW 현재가를 2초 단위로 계속 보므로, 여기서 1m/3m 실시간 변화율을 만든다.
# 기존 24h 변화율 / 1440 같은 가짜 단기흐름 fallback은 쓰지 않는다.
PRICE_HISTORY: Dict[str, List[Tuple[float, float]]] = {}
HISTORY_KEEP_SEC = float(os.getenv("SCANNER_HOT_HISTORY_KEEP_SEC", "240"))
HOT_MIN_OBS_1M = float(os.getenv("SCANNER_HOT_MIN_OBS_1M_SEC", "25"))
HOT_MIN_OBS_3M = float(os.getenv("SCANNER_HOT_MIN_OBS_3M_SEC", "70"))

def _history_pct(ticker: str, price: float, ts: float, window: float, min_obs: float) -> Tuple[Optional[float], float, str]:
    hist = PRICE_HISTORY.get(ticker) or []
    if not hist or price <= 0:
        return None, 0.0, "history_missing"
    target = ts - window
    base_ts, base_price = hist[0]
    for hts, hp in hist:
        if hts <= target:
            base_ts, base_price = hts, hp
        else:
            break
    observed = max(0.0, ts - base_ts)
    if base_price <= 0 or observed < min_obs:
        return None, observed, "warmup"
    return pct(price, base_price), observed, "scanner_price_history" if observed >= window * 0.85 else "scanner_price_history_partial"

def attach_hot_rank(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    ts = now_ts()
    cutoff = ts - HISTORY_KEEP_SEC
    # update in-memory history; 전체시장 가격 원천은 scanner ALL_KRW 그대로 사용한다.
    for r in rows:
        t = ticker_norm(r.get("ticker")); price = fnum(r.get("current_price"), r.get("price"), default=0)
        if not t or price <= 0:
            continue
        hist = PRICE_HISTORY.setdefault(t, [])
        hist.append((ts, price))
        PRICE_HISTORY[t] = [(a,b) for a,b in hist if a >= cutoff and b > 0][-180:]
    hot_rows: List[Dict[str, Any]] = []
    for r in rows:
        t = ticker_norm(r.get("ticker")); price = fnum(r.get("current_price"), r.get("price"), default=0)
        ch1, obs1, src1 = _history_pct(t, price, ts, 60.0, HOT_MIN_OBS_1M)
        ch3, obs3, src3 = _history_pct(t, price, ts, 180.0, HOT_MIN_OBS_3M)
        if ch1 is not None:
            r["scanner_change_1m_pct"] = round(ch1, 3); r["scanner_change_1m_source"] = src1
        else:
            r["scanner_change_1m_source"] = src1
        if ch3 is not None:
            r["scanner_change_3m_pct"] = round(ch3, 3); r["scanner_change_3m_source"] = src3
        else:
            r["scanner_change_3m_source"] = src3
        r["scanner_hot_observed_1m_sec"] = round(obs1, 1)
        r["scanner_hot_observed_3m_sec"] = round(obs3, 1)
        hot_score = max(0.0, ch1 or 0.0) * 4.0 + max(0.0, ch3 or 0.0) * 2.2 + min(2.0, fnum(r.get("turnover_24h"), default=0)/1_000_000_000.0)
        r["scanner_hot_score"] = round(hot_score, 3)
        hot_rows.append({
            "ticker": t, "market": f"{t}_KRW", "price": price,
            "scanner_change_1m_pct": r.get("scanner_change_1m_pct"),
            "scanner_change_3m_pct": r.get("scanner_change_3m_pct"),
            "scanner_change_1m_source": r.get("scanner_change_1m_source"),
            "scanner_change_3m_source": r.get("scanner_change_3m_source"),
            "scanner_hot_observed_1m_sec": r.get("scanner_hot_observed_1m_sec"),
            "scanner_hot_observed_3m_sec": r.get("scanner_hot_observed_3m_sec"),
            "scanner_hot_score": r.get("scanner_hot_score"),
            "turnover_24h": r.get("turnover_24h"),
            "updated_ts": ts,
        })
    valid1 = [r for r in rows if r.get("scanner_change_1m_pct") is not None]
    valid3 = [r for r in rows if r.get("scanner_change_3m_pct") is not None]
    for i, r in enumerate(sorted(valid1, key=lambda x: fnum(x.get("scanner_change_1m_pct"), default=-999), reverse=True), 1):
        r["scanner_hot_rank_1m"] = i
    for i, r in enumerate(sorted(valid3, key=lambda x: fnum(x.get("scanner_change_3m_pct"), default=-999), reverse=True), 1):
        r["scanner_hot_rank_3m"] = i
    rank_map = {ticker_norm(r.get("ticker")): r for r in rows}
    for hr in hot_rows:
        src = rank_map.get(ticker_norm(hr.get("ticker")), {})
        hr["scanner_hot_rank_1m"] = src.get("scanner_hot_rank_1m")
        hr["scanner_hot_rank_3m"] = src.get("scanner_hot_rank_3m")
    save_json(HOT, {
        "version": VERSION, "schema": "scanner_hot_rank_cache_v481",
        "updated_ts": ts, "updated_text": now_text(ts),
        "row_count": len(hot_rows),
        "known_1m": len(valid1), "known_3m": len(valid3),
        "note": "ALL_KRW 현재가 히스토리 기반 1m/3m hot rank. 24h 나눗셈 fallback 없음. warmup/missing은 source로 표시.",
        "rows": sorted(hot_rows, key=lambda x: fnum(x.get("scanner_hot_score"), default=0), reverse=True)
    })
    return {"known_1m": len(valid1), "known_3m": len(valid3)}


def hot_watch_condition(row: Dict[str, Any]) -> Tuple[bool, List[str]]:
    c1_raw=row.get("scanner_change_1m_pct"); c3_raw=row.get("scanner_change_3m_pct")
    r1_raw=row.get("scanner_hot_rank_1m"); r3_raw=row.get("scanner_hot_rank_3m")
    c1=fnum(c1_raw,default=-999999.0) if c1_raw not in (None,"") else -999999.0
    c3=fnum(c3_raw,default=-999999.0) if c3_raw not in (None,"") else -999999.0
    r1=fnum(r1_raw,default=999999.0) if r1_raw not in (None,"") else 999999.0
    r3=fnum(r3_raw,default=999999.0) if r3_raw not in (None,"") else 999999.0
    reasons: List[str]=[]
    if c1>=HOT_WATCH_MIN_1M_PCT: reasons.append("change_1m")
    if c3>=HOT_WATCH_MIN_3M_PCT: reasons.append("change_3m")
    if r1<=HOT_WATCH_RANK_TOP_N: reasons.append("rank_1m")
    if r3<=HOT_WATCH_RANK_TOP_N: reasons.append("rank_3m")
    return bool(reasons),reasons

def hot_watch_occurrence_key(ticker:str,started_ts:float)->str:
    return f"market:{ticker}|hot_started:{int(float(started_ts)*1000)}"

def append_hot_watch_event(kind:str,rec:Dict[str,Any],ts:float)->None:
    append_jsonl(HOT_WATCH_EVENTS,{"schema":"hot_watch_scanner_event_v945","version":VERSION,"kind":kind,"ts":ts,"ts_text":now_text(ts),"ticker":rec.get("ticker"),"hot_watch_occurrence_key_v945":rec.get("occurrence_key"),"started_ts":rec.get("started_ts"),"start_price":rec.get("start_price"),"last_hot_ts":rec.get("last_hot_ts"),"last_price":rec.get("last_price"),"peak_change_1m_pct":rec.get("peak_change_1m_pct"),"peak_change_3m_pct":rec.get("peak_change_3m_pct"),"best_rank_1m":rec.get("best_rank_1m"),"best_rank_3m":rec.get("best_rank_3m"),"reason":rec.get("reason"),"observation_only":True,"used_for_entry_gate":False})
    if HOT_WATCH_EVENTS.stat().st_size<=HOT_WATCH_EVENT_MAX_BYTES: return
    HOT_WATCH_ARCHIVE.mkdir(parents=True,exist_ok=True)
    stamp=time.strftime("%Y%m%d_%H%M%S",time.localtime(ts)); archive=HOT_WATCH_ARCHIVE/f"hot_watch_scanner_events_{stamp}.jsonl.gz"
    with gzip.open(archive,"wb",compresslevel=6) as dst: dst.write(HOT_WATCH_EVENTS.read_bytes())
    write_jsonl_atomic(HOT_WATCH_EVENTS,read_jsonl(HOT_WATCH_EVENTS,max_lines=HOT_WATCH_EVENT_KEEP_LINES))

def update_hot_watch(rows:List[Dict[str,Any]],ts:float)->Dict[str,Any]:
    raw=load_json(HOT_WATCH_STATE,{}); state=raw if isinstance(raw,dict) else {}
    recs_raw=state.get("records"); records:Dict[str,Dict[str,Any]]=recs_raw if isinstance(recs_raw,dict) else {}
    row_map:Dict[str,Dict[str,Any]]={}; started=ended=hot_now_count=0
    for row in rows:
        if not isinstance(row,dict): continue
        ticker=ticker_norm(row.get("ticker") or row.get("market") or row.get("symbol"))
        if not ticker: continue
        row_map[ticker]=row; old=records.get(ticker); rec=dict(old) if isinstance(old,dict) else {}
        last_hot=fnum(rec.get("last_hot_ts"),default=0.0)
        if rec.get("active") is True and last_hot>0 and ts-last_hot>HOT_WATCH_GAP_SEC:
            rec["active"]=False; rec["ended_ts"]=ts; rec["ended_text"]=now_text(ts); append_hot_watch_event("END",rec,ts); ended+=1
        hot_now,reasons=hot_watch_condition(row); price=fnum(row.get("current_price"),row.get("price"),default=0.0)
        if hot_now:
            hot_now_count+=1
            if rec.get("active") is not True:
                rec={"ticker":ticker,"active":True,"started_ts":ts,"started_text":now_text(ts),"start_price":price if price>0 else None,"occurrence_key":hot_watch_occurrence_key(ticker,ts),"last_hot_ts":ts,"last_seen_ts":ts,"hot_cycle_count":0,"reason":reasons}
                append_hot_watch_event("START",rec,ts); started+=1
            rec["active"]=True; rec["hot_now"]=True; rec["last_hot_ts"]=ts; rec["last_hot_text"]=now_text(ts); rec["last_seen_ts"]=ts; rec["last_price"]=price if price>0 else rec.get("last_price"); rec["reason"]=reasons; rec["hot_cycle_count"]=int(rec.get("hot_cycle_count") or 0)+1
            c1=row.get("scanner_change_1m_pct"); c3=row.get("scanner_change_3m_pct")
            if c1 not in (None,""): rec["peak_change_1m_pct"]=max(fnum(rec.get("peak_change_1m_pct"),default=-999999.0),fnum(c1,default=-999999.0))
            if c3 not in (None,""): rec["peak_change_3m_pct"]=max(fnum(rec.get("peak_change_3m_pct"),default=-999999.0),fnum(c3,default=-999999.0))
            r1=row.get("scanner_hot_rank_1m"); r3=row.get("scanner_hot_rank_3m")
            if r1 not in (None,""): rec["best_rank_1m"]=int(min(fnum(rec.get("best_rank_1m"),default=999999.0),fnum(r1,default=999999.0)))
            if r3 not in (None,""): rec["best_rank_3m"]=int(min(fnum(rec.get("best_rank_3m"),default=999999.0),fnum(r3,default=999999.0)))
        else:
            rec["hot_now"]=False; rec["last_seen_ts"]=ts; rec["last_price"]=price if price>0 else rec.get("last_price")
        if rec: records[ticker]=rec
    pruned=0
    for ticker in list(records):
        rec=records.get(ticker)
        if not isinstance(rec,dict): records.pop(ticker,None); pruned+=1; continue
        last_seen=fnum(rec.get("last_seen_ts"),rec.get("last_hot_ts"),default=0.0)
        if rec.get("active") is not True and last_seen>0 and ts-last_seen>HOT_WATCH_STATE_KEEP_SEC: records.pop(ticker,None); pruned+=1
    snapshot_rows=[]
    for ticker,rec in records.items():
        if not isinstance(rec,dict) or rec.get("active") is not True: continue
        src=row_map.get(ticker); source=src if isinstance(src,dict) else {}; last_hot=fnum(rec.get("last_hot_ts"),default=0.0)
        snapshot_rows.append({"ticker":ticker,"market":f"{ticker}_KRW","hot_watch_occurrence_key_v945":rec.get("occurrence_key"),"hot_watch_started_ts_v945":rec.get("started_ts"),"hot_watch_start_price_v945":rec.get("start_price"),"hot_watch_last_hot_ts_v945":rec.get("last_hot_ts"),"hot_watch_hot_now_v945":bool(rec.get("hot_now")),"hot_watch_gap_age_sec_v945":round(max(0.0,ts-last_hot),3) if last_hot>0 else None,"hot_watch_reason_v945":rec.get("reason"),"scanner_change_1m_pct":source.get("scanner_change_1m_pct"),"scanner_change_3m_pct":source.get("scanner_change_3m_pct"),"scanner_hot_rank_1m":source.get("scanner_hot_rank_1m"),"scanner_hot_rank_3m":source.get("scanner_hot_rank_3m"),"scanner_hot_score":source.get("scanner_hot_score"),"current_price":source.get("current_price") or source.get("price") or rec.get("last_price"),"peak_change_1m_pct":rec.get("peak_change_1m_pct"),"peak_change_3m_pct":rec.get("peak_change_3m_pct"),"best_rank_1m":rec.get("best_rank_1m"),"best_rank_3m":rec.get("best_rank_3m")})
    snapshot_rows.sort(key=lambda x:fnum(x.get("hot_watch_started_ts_v945"),default=0.0),reverse=True)
    save_json(HOT_WATCH_STATE,{"schema":"hot_watch_scanner_state_v945","version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"records":records,"observation_rule":{"rank_top_n":HOT_WATCH_RANK_TOP_N,"minimum_1m_pct":HOT_WATCH_MIN_1M_PCT,"minimum_3m_pct":HOT_WATCH_MIN_3M_PCT,"continuity_gap_sec":HOT_WATCH_GAP_SEC},"trading_rules_changed":False})
    snapshot={"schema":"hot_watch_scanner_snapshot_v945","version":VERSION,"updated_ts":ts,"updated_text":now_text(ts),"active_occurrence_count":len(snapshot_rows),"hot_now_count":hot_now_count,"started_this_cycle":started,"ended_this_cycle":ended,"pruned_this_cycle":pruned,"rows":snapshot_rows,"source":"scanner ALL_KRW price history + existing hot-rank observation rule","occurrence_identity":"market:<ticker>|hot_started:<first_started_ms>","observation_only":True,"used_for_entry_gate":False}
    save_json(HOT_WATCH_SNAPSHOT,snapshot); return snapshot

def http_json(url:str)->Any:
    req=urllib.request.Request(url,headers={"Accept":"application/json","User-Agent":"coinbot-scanner-worker/0.4"})
    with urllib.request.urlopen(req,timeout=HTTP_TIMEOUT_SEC) as r:
        return json.loads(r.read().decode("utf-8",errors="ignore"))
def parse_rows(payload:Any)->List[Dict[str,Any]]:
    data=payload.get("data") if isinstance(payload,dict) else payload
    if not isinstance(data,dict): return []
    ts=now_ts(); rows=[]
    for k,row in data.items():
        t=ticker_norm(k)
        if not t or t in {"DATE","STATUS"} or t in STABLE: continue
        if not isinstance(row,dict): continue
        price=fnum(row.get("closing_price"),row.get("trade_price"),row.get("close"),row.get("prev_closing_price"),default=0)
        if price<=0: continue
        prev=fnum(row.get("prev_closing_price"), row.get("opening_price"), default=price)
        turnover=fnum(row.get("acc_trade_value_24H"),row.get("acc_trade_value_24h"),row.get("acc_trade_value"),row.get("acc_trade_price_24h"),default=0)
        vol=fnum(row.get("units_traded_24H"),row.get("units_traded_24h"),row.get("units_traded"),row.get("volume"),default=0)
        chg=fnum(row.get("fluctate_rate_24H"),row.get("fluctate_rate_24h"),row.get("fluctate_rate"),row.get("change_rate"),default=pct(price,prev))
        high=fnum(row.get("max_price"), row.get("high_price"), default=price)
        low=fnum(row.get("min_price"), row.get("low_price"), default=price)
        rows.append({"ticker":t,"market":f"{t}_KRW","current_price":price,"price":price,"prev_price":prev,"turnover_24h":turnover,"volume_24h":vol,"change_24h":chg,"day_high":high,"day_low":low,"day_pos_pct":round((price-low)/(high-low)*100,2) if high>low else 50.0,"major_watch":t in MAJOR,"fresh_ts":ts,"source":"scanner_ALL_KRW"})
    rows.sort(key=lambda r:(fnum(r.get("turnover_24h")), abs(fnum(r.get("change_24h")))), reverse=True)
    for i,r in enumerate(rows,1): r["turnover_rank"]=i
    return rows
def build_pool(rows:List[Dict[str,Any]])->List[Dict[str,Any]]:
    out=[]
    for r in rows:
        t24=fnum(r.get("turnover_24h")); ch=abs(fnum(r.get("change_24h"))); pos=fnum(r.get("day_pos_pct"),default=50)
        score=min(10,t24/700_000_000.0)+min(8,ch)+ (1.0 if 35<=pos<=85 else 0.0)
        score += min(8.0, max(0.0, fnum(r.get("scanner_change_1m_pct"), default=0.0)) * 3.0)
        score += min(7.0, max(0.0, fnum(r.get("scanner_change_3m_pct"), default=0.0)) * 2.0)
        if r.get("major_watch"): score*=0.25
        rr=dict(r); rr["scanner_priority_score"]=round(score,3); out.append(rr)
    out.sort(key=lambda r:(fnum(r.get("scanner_priority_score")), fnum(r.get("turnover_24h"))), reverse=True)
    return out[:650]
def write_status(state:str, **extra:Any)->None: save_json(STATUS,{"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),**extra})
def run_once()->Dict[str,Any]:
    st=now_ts(); rows=parse_rows(http_json("https://api.bithumb.com/public/ticker/ALL_KRW"))
    if not rows: raise RuntimeError("scanner empty rows")
    hot_stat=attach_hot_rank(rows)
    hot_watch=update_hot_watch(rows,now_ts())
    pool=build_pool(rows); ts=now_ts()
    save_json(MARKET,{"version":VERSION,"schema":"scanner_market_cache_v4_hot_rank","updated_ts":ts,"updated_text":now_text(ts),"row_count":len(rows),"hot_known_1m":hot_stat.get("known_1m",0),"hot_known_3m":hot_stat.get("known_3m",0),"rows":rows})
    save_json(POOL,{"version":VERSION,"schema":"scanner_candidate_pool_v4_hot_rank","updated_ts":ts,"updated_text":now_text(ts),"row_count":len(pool),"hot_known_1m":hot_stat.get("known_1m",0),"hot_known_3m":hot_stat.get("known_3m",0),"rows":pool})
    sec=now_ts()-st; write_status("running", row_count=len(rows), pool_count=len(pool), hot_known_1m=hot_stat.get("known_1m",0), hot_known_3m=hot_stat.get("known_3m",0), hot_watch_active=hot_watch.get("active_occurrence_count",0), hot_watch_now=hot_watch.get("hot_now_count",0), last_sec=round(sec,3), source="ALL_KRW_hot_rank_hot_watch_v945")
    return {"rows":len(rows),"pool":len(pool),"sec":sec,"hot_known_1m":hot_stat.get("known_1m",0),"hot_known_3m":hot_stat.get("known_3m",0),"hot_watch_active":hot_watch.get("active_occurrence_count",0),"hot_watch_now":hot_watch.get("hot_now_count",0)}
def main()->None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5,INTERVAL_SEC))

# v1410 identity unification override (no trading-rule changes)
VERSION = 'scanner_worker_v1.410'
BUILD_LABEL = 'v1410_disk_manifest_support_and_speed_fix_2026-07-09'
MAIN_DEPLOY_VERSION = 'v1410_disk_manifest_support_and_speed_fix_2026-07-09'

if __name__=="__main__": main()
