coinbot_update_v1703

목적: 후보 범위를 줄이지 않고, OPEN 전 후보조건의 현재 owner와 제자리 owner를 분류하는 전수조사판.
추가 명령: /condition_owner_map, /preopen_condition_audit, /candidate_owner_matrix.
유지: Gate/TTL/RR/trigger/invalid/target/청산/OPEN limit/자동매수 OFF 변경 없음.
