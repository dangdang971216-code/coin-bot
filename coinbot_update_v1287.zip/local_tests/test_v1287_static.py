from pathlib import Path
for fn in ['backga_guard_bot_v2_5_265.py','paper_bot_v1.084.py']:
    p=Path(__file__).resolve().parents[1]/fn
    assert p.exists(), fn
    txt=p.read_text(encoding='utf-8')
assert 'gcompress_live_v1287_text' in (Path(__file__).resolve().parents[1]/'backga_guard_bot_v2_5_265.py').read_text(encoding='utf-8')
assert 'process_open_positions_for_exit__v1287' in (Path(__file__).resolve().parents[1]/'paper_bot_v1.084.py').read_text(encoding='utf-8')
