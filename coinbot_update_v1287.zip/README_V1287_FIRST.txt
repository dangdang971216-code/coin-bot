v1287: live append 중인 paper_exit_replay_poll 안전 prefix gzip mirror + Paper future poll observation writer compact.
매매 로직, 구조선, RR, 청산계약 변경 없음. 자동매수 OFF.
