import importlib.util, os, tempfile, time, json
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='review1124_'))
os.environ['TRADING_BOT_DIR']=str(root)
spec=importlib.util.spec_from_file_location('rw','/mnt/data/work1124/review_worker_v1.002.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
# identity: two direct decisions, one occurrence -> one identity
r1={'ticker':'AAA','entry_build_key':'cand-A','trigger_occurrence_candidate_key_v1037':'cand-A|rebreak:123','swing_gate_decision_key_v977':'decision-1'}
r2=dict(r1); r2['swing_gate_decision_key_v977']='decision-2'
assert m._quality_exact_identity(r1)==m._quality_exact_identity(r2)
assert m._quality_exact_identity(r1)[0].startswith('trigger_occurrence:')
# aggregate rows
now=time.time(); epoch=m._quality_eye_epoch_v1124(now)
base={
 'quality_event_key_v946':'trigger_occurrence:cand-A|rebreak:123',
 'quality_eye_epoch_id_v1124':epoch['epoch_id'], 'ticker':'AAA',
 'initial_metrics':{'spread_pct':0.1,'confirmed_slippage_pct':0.1},
 'samples':{'60m':{'pct':-1.0,'max_pct':0.0,'min_pct':-2.0,'giveback_pct':1.0}},
 'policy_variants_v1120':{
  'safety_only':{'selected':True},
  'current_quality':{'selected':True},
  'improved_quality':{'selected':False,'block_reasons':['improved_score_below_62']},
 }
}
agg=m._quality_eye_empty_aggregate_v1124(epoch); m._quality_eye_aggregate_add_row_v1124(agg,base)
status=m._quality_eye_status_from_aggregate_v1124(now,agg,[],epoch)
assert status['false_pass']['no_positive_mfe']==1
assert status['false_pass']['caught_by_improved']==1
assert status['horizons']['60m']['current_quality']['n']==1
# false block winner
r3={
 'quality_event_key_v946':'trigger_occurrence:cand-B','quality_eye_epoch_id_v1124':epoch['epoch_id'],'ticker':'BBB',
 'initial_metrics':{'spread_pct':0.05,'confirmed_slippage_pct':0.05},
 'samples':{'60m':{'pct':4.0,'max_pct':8.5,'min_pct':-0.5,'giveback_pct':4.5}},
 'policy_variants_v1120':{
  'safety_only':{'selected':True},
  'current_quality':{'selected':False,'block_reasons':['quality_confirmation_absent:relative/money/buyflow']},
  'improved_quality':{'selected':True},
 }
}
m._quality_eye_aggregate_add_row_v1124(agg,r3)
status=m._quality_eye_status_from_aggregate_v1124(now,agg,[],epoch)
assert status['false_block']['hit_8']==1
assert status['false_block']['recovered_by_improved_hit_1']==1
print(json.dumps({'ok':True,'root':str(root),'identity':m._quality_exact_identity(r1),'false_pass':status['false_pass'],'false_block':status['false_block']},ensure_ascii=False))
