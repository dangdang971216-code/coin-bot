#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, json, pathlib, py_compile, sys

ROOT=pathlib.Path(__file__).resolve().parent
FILES={
    'main':ROOT/'coinbot_main_v2_13_1096.py',
    'strategy':ROOT/'strategy_worker_v1.009.py',
    'review':ROOT/'review_worker_v1.002.py',
}
EXPECTED_TEXT={
    'main':['수익형 v2.13.1096','v1124_candidate_eye_policy_comparison_display_2026-06-29','strategy_worker_v1.009','review_worker_v1.002'],
    'strategy':['strategy_worker_v1.009','v1124_strategy_runtime_status_nofsync_candidate_eye_support_2026-06-29'],
    'review':['review_worker_v1.002','v1124_candidate_eye_occurrence_identity_cumulative_compare_2026-06-29'],
}
EXPECTED_AST={
    'review':{
        '_quality_gate':'eabbf7d72e8b00afc287bb0830e65a9983917d9912c069716f3dd1d4d4d42e7e',
        '_quality_block_reasons':'31186b4094cb219f215a7191f90ede51bd5045858c705641e4c5a673acfd7e24',
        '_quality_cohort':'806735a9c7829d727c4b7832c64efd53db8da9dc5f79e3d811f27cd453750a68',
        '_quality_initial_metrics':'b8204256973797b2582c418564228755ffb4d91836197b508dfab68eb14d0758',
        '_quality_policy_variants_v1120':'b224d0bb7e65894cf7529e050348d79a32c0f95a3eee3489c81bf3fa7989d70f',
    },
    'strategy':{
        '_swing_quality_gate':'1d97ab0738d5eb0bab21979aecce9161603c8dc166c4c03d4549758f21ee00f1',
        'apply_swing_entry_gate':'3c92ddd474bba91ccc65c3d5991cfabdd06f893bd39e8c19e1ce625c3a4d1900',
    },
}

def ast_hashes(path:pathlib.Path)->dict[str,str]:
    tree=ast.parse(path.read_text(encoding='utf-8'))
    out={}
    for node in ast.walk(tree):
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
            out[node.name]=hashlib.sha256(ast.dump(node,include_attributes=False).encode()).hexdigest()
    return out

def main()->int:
    result={'ok':True,'compile':{},'versions':{},'ast':{},'contracts':{}}
    for key,path in FILES.items():
        py_compile.compile(str(path),doraise=True)
        result['compile'][key]='PASS'
        text=path.read_text(encoding='utf-8')
        missing=[token for token in EXPECTED_TEXT[key] if token not in text]
        assert not missing,(key,missing)
        result['versions'][key]='PASS'
    for key,expected in EXPECTED_AST.items():
        got=ast_hashes(FILES[key])
        for name,digest in expected.items():
            assert got.get(name)==digest,(key,name,got.get(name),digest)
        result['ast'][key]='PASS'
    review=FILES['review'].read_text(encoding='utf-8')
    assert "trigger_occurrence_candidate_key_v1037" in review
    assert "direct decision last fallback" in review
    assert "if not rebuilt_now:" in review
    assert "minimum_60m_samples_per_policy" in review
    strategy=FILES['strategy'].read_text(encoding='utf-8')
    assert "actual_quality_gate_changed':False" in strategy or "quality_threshold_changed':False" in strategy
    main_text=FILES['main'].read_text(encoding='utf-8')
    assert '/quality_shadow' in main_text and '조건 없음' in main_text and '개선 조건' in main_text
    result['contracts']={
        'occurrence_identity':'PASS','aggregate_no_double_count':'PASS','minimum_sample_guard':'PASS',
        'live_quality_formula_unchanged':'PASS','live_swing_gate_unchanged':'PASS','auto_buy':'OFF',
    }
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
