import importlib.util, os, tempfile, json, time
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='strategy1124_'))
os.environ['TRADING_BOT_DIR']=str(root)
spec=importlib.util.spec_from_file_location('st','/mnt/data/work1124/strategy_worker_v1.009.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
# Redirect constants that may have been initialized before final definitions
m.STATUS=root/'status.json'; m.SUMMARY=root/'summary.json'
m._v1022_write_status_file({'updated_ts':time.time(),'state':'running'})
assert m.STATUS.exists() and json.loads(m.STATUS.read_text())['state']=='running'
m._v1014_write_strategy_summary({'schema':'x','evaluated':10,'stage_counts':{'S1':1}},time.time())
assert m.SUMMARY.exists()
p=root/'snap.json'; assert m._v1015_bounded_snapshot_write(p,{'schema':'s','updated_ts':time.time(),'x':1},60.0)
assert p.exists(); assert not m._v1015_bounded_snapshot_write(p,{'schema':'s','updated_ts':time.time(),'x':1},60.0)
print(json.dumps({'ok':True,'version':m.VERSION,'build':m.BUILD_LABEL,'files':[x.name for x in root.iterdir()]},ensure_ascii=False))
