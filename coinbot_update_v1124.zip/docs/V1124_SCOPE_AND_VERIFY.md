# v1124 범위와 검수

## 증상

- 후보품질 shadow 결과 원장이 약 12.78MB/h 증가했고 Strategy cycle이 약 54초까지 늘었다.
- 조건 없음·현재 조건·개선 조건 비교가 있어도 같은 실제 trigger 사건이 decision key 변경으로 여러 표본처럼 들어갈 수 있었다.
- 60분 완료 row는 active state에서 제거된 뒤 누적 비교에서 사라질 수 있어 장기 승률 비교가 흔들렸다.

## 코드에서 확정한 원인

1. `_quality_exact_identity`가 trigger occurrence candidate key보다 direct decision key를 먼저 선택했다.
2. 동일 trigger 사건이 cycle마다 새 direct decision key를 받으면 새 표본과 새 final ledger row가 생성될 수 있었다.
3. 비교 status가 active rows 중심이어서 완료 row가 prune된 뒤 누적 정책 성과를 안정적으로 유지하지 못했다.
4. Strategy의 재생성 가능한 status/display artifact도 durable fsync 경로를 사용해 candidate refresh wall time을 늘렸다.

## 새 본선

- 표본 identity: `trigger_occurrence_candidate_key_v1037` 우선, `entry_build_key` 차선, direct decision key는 마지막 fallback 및 감사 증거로만 보존.
- 동일 cycle source rows도 occurrence identity로 dedup한다.
- 완료 row는 append-only result ledger에 1회만 기록하고 cumulative aggregate에 누적한다.
- aggregate 재빌드 직후 process-local pending row를 다시 더하지 않아 2중 집계를 막는다.
- 1·3·5·10·20·60분 정책별 비용 후 결과, MFE, MAE, 무양수 MFE, +1·5·8·10 도달을 누적한다.
- false-pass와 false-block의 원인축과 개선안 포착/복구 수를 집계한다.
- 각 정책의 60분 표본이 최소 30개가 되기 전에는 우세 정책을 확정하지 않는다.
- Main `/quality_shadow`가 조건 없음·현재·개선 조건을 같은 화면에서 표시한다.
- Strategy의 재생성 가능한 runtime/status/display 파일은 atomic no-fsync writer를 사용하고 보호 상태·원장은 기존 durable 계약을 유지한다.

## 변경하지 않은 영역

- 실제 품질 Gate threshold와 rank 공식
- 조건 없음·현재·개선 shadow 정책 공식
- trigger·invalid·target·RR·목표공간·비용 계약
- OPEN 30 / cycle 3
- Paper selector·재진입·청산계약
- 보호 거래원장과 canonical performance 공식
- 자동매수 OFF

## 서버 검수

- Main v2.13.1096, Strategy v1.009, Review v1.002 runtime 일치
- `/quality_shadow`에 raw/unique/duplicate, clean epoch, 3개 정책, 60분 표본 준비상태가 표시
- 같은 occurrence key가 decision key만 달라져도 신규 표본은 1개
- final 1건이 cumulative aggregate에서도 1건
- runtime mismatch 0, 새 실행 오류 0
- Strategy cycle은 연속 표본으로 판단하며 단발 cold cycle만으로 전략 수치를 변경하지 않음
