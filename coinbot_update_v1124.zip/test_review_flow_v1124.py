import importlib.util, os, tempfile, json, time
from pathlib import Path
root=Path(tempfile.mkdtemp(prefix='reviewflow1124_'))
os.environ['TRADING_BOT_DIR']=str(root)
spec=importlib.util.spec_from_file_location('rw','/mnt/data/work1124/review_worker_v1.002.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
# isolate dedup for unit flow
seen=set()
m._dedup_contains_v1013=lambda kind,key: key in seen
m._dedup_commit_v1013=lambda kind,key: seen.add(key)
m._dedup_count_v1013=lambda kind: len(seen)
# redirect all quality paths to temp because constants were import-time root already, but explicit for clarity
m.QUALITY_SHADOW_STATE=root/'state.json'; m.QUALITY_SHADOW_STATUS=root/'status.json'; m.QUALITY_SHADOW_LEDGER=root/'ledger.jsonl'; m.QUALITY_SHADOW_ARCHIVE=root/'archive'; m.QUALITY_POLICY_COMPARISON_STATUS_V1120=root/'compare.json'; m.QUALITY_EYE_STATUS_V1124=root/'eye.json'; m.QUALITY_EYE_EPOCH_STATE_V1124=root/'epoch.json'; m.QUALITY_EYE_AGG_STATE_V1124=root/'agg.json'
now=1_780_000_000.0
base={
 'ticker':'AAA','entry_build_key':'cand-A','trigger_occurrence_candidate_key_v1037':'cand-A|rebreak:1000',
 'swing_gate_decision_key_v977':'decision-A1','current_price':100.0,'price_reaction_pct':0.1,
 'relative_strength_pct':1.0,'relative_strength_rank_pct':80,'money_flow_score':0.7,'buy_ratio':0.65,'buy_sustain_1m':0.6,
 'spread_pct':0.1,'confirmed_slippage_pct':0.1,'risk_reward':2.0,'target_room_pct':5.0,'trigger_gap_pct':0.1,
 'swing_entry_gate_v977':{'hard_pass':True,'stage':'S1','decision_key':'decision-A1','hard_block_reasons':[],'risk_reward':2.0,'target_room_pct':5.0,'spread_pct':0.1},
}
second=dict(base); second['swing_gate_decision_key_v977']='decision-A2'; second['swing_entry_gate_v977']=dict(base['swing_entry_gate_v977'],decision_key='decision-A2')
status,rows=m.update_quality_shadow(now,{'AAA':{'current_price':100.0}},{},[base,second],{})
assert status['source_rows_raw_v1124']==2 and status['source_unique_candidate_occurrences_v1124']==1 and status['source_duplicate_identity_rows_v1124']==1
assert len(rows)==1
# force due and advance beyond 60m
for r in m._QUALITY_STATE_CACHE_V1011.values(): r['next_review_due_ts_v1011']=0.0
status2,rows2=m.update_quality_shadow(now+3601,{'AAA':{'current_price':104.0}},{},[base],{})
assert status2['finalized_this_cycle']==1 and len(seen)==1
assert m.QUALITY_SHADOW_LEDGER.exists() and len(m.QUALITY_SHADOW_LEDGER.read_text().strip().splitlines())==1
comp=m.update_quality_policy_comparison_v1120(now+3601,rows2)
print('COMP',json.dumps(comp,ensure_ascii=False)); assert comp['finalized_events']==1
assert comp['horizons']['60m']['safety_only']['n']==1
print(json.dumps({'ok':True,'root':str(root),'status':{k:status.get(k) for k in ('source_rows_raw_v1124','source_unique_candidate_occurrences_v1124','source_duplicate_identity_rows_v1124','tracked_records')},'finalized':comp['finalized_events'],'eye_state':comp['state']},ensure_ascii=False))
