import importlib.util, tempfile, json, time
from pathlib import Path
spec=importlib.util.spec_from_file_location('main1124','/mnt/data/work1124/coinbot_main_v2_13_1096.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
root=Path(tempfile.mkdtemp(prefix='main1124_'))
m.QUALITY_SHADOW_STATUS=root/'shadow.json'; m.QUALITY_EYE_STATUS_V1124=root/'eye.json'; m.QUALITY_POLICY_COMPARISON_STATUS_V1120=root/'compat.json'
now=time.time()
(m.QUALITY_SHADOW_STATUS).write_text(json.dumps({'updated_ts':now,'version':'review_worker_v1.002','source_rows_raw_v1124':461,'source_unique_candidate_occurrences_v1124':120,'source_duplicate_identity_rows_v1124':341,'tracked_records':140,'new_records_this_cycle':3}),encoding='utf-8')
pol={k:{'n':30,'cost_adjusted_avg_pct':v,'avg_mfe_pct':v+1,'avg_mae_pct':-0.5,'win_rate_pct':55,'no_positive_mfe_count':5,'hit_5_count':2,'hit_8_count':1,'hit_10_count':0} for k,v in [('safety_only',0.1),('current_quality',-0.2),('improved_quality',0.5)]}
(m.QUALITY_EYE_STATUS_V1124).write_text(json.dumps({'updated_ts':now,'version':'review_worker_v1.002','state':'READY_FOR_REVIEW','identity_contract':'one trigger occurrence','finalized_events':40,'active_unfinalized_events':10,'horizons':{'10m':pol,'60m':pol},'leader_60m':'improved_quality','leader_state':'EVIDENCE_READY','minimum_ready_n':30,'minimum_60m_samples_per_policy':30,'delta_improved_vs_current_60m':{'cost_adjusted_avg_pct':0.7},'delta_current_vs_no_quality_60m':{'cost_adjusted_avg_pct':-0.3},'false_pass':{'no_positive_mfe':4,'negative_after_cost':8,'caught_by_improved':3,'improved_block_reason_top':[['score_low',3]]},'false_block':{'hit_1':7,'hit_5':2,'hit_8':1,'hit_10':0,'recovered_by_improved_hit_1':5,'current_block_reason_top':[['confirmation_missing',7]]}}),encoding='utf-8')
text='\n'.join(m.quality_shadow_lines(True))
assert '조건 없음 vs 현재 vs 개선' in text and 'false-pass' in text and '개선 조건' in text
print(text)
