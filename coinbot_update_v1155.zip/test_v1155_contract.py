#!/usr/bin/env python3
from __future__ import annotations
import ast
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT=Path(__file__).resolve().parent
SRC=ROOT/'coinbot_main_v2_13_1116.py'
text=SRC.read_text(encoding='utf-8')
tree=ast.parse(text)

# Final runtime identity.
assignments={}
for node in tree.body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
        try: assignments[node.targets[0].id]=ast.literal_eval(node.value)
        except Exception: pass
assert assignments.get('BOT_VERSION')=='수익형 v2.13.1116'
assert assignments.get('V650_BUILD_LABEL')=='v1155_compact_telegram_pretty_txt_2026-06-30'

required={
    'render_flow_map_telegram_v1155','render_flow_map_pretty_txt_v1155',
    'render_candidate_standard_telegram_v1155','render_candidate_standard_pretty_txt_v1155',
    'render_candidate_standard_detail_text_v1155','compact_command_output',
    'build_command_summary_text','make_handler','_v1155_seed_issue_once'
}
functions={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
missing=sorted(required-set(functions))
assert not missing,missing
assert "V1155_SINGLE_COMMAND_TXT={'flow_map_full','candidate_standard'}" in text
assert "name in V1155_ALWAYS_COMPACT_COMMANDS" in text
assert "코인봇 운영 요약집 v1155" in text
assert "render_flow_map_pretty_txt_v1155()" in text
assert "render_candidate_standard_pretty_txt_v1155()" in text
assert "코인봇 핵심 요약 v1016" not in text

manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert manifest.get('main')=='coinbot_main_v2_13_1116.py'
assert not manifest.get('guard') and not manifest.get('paper') and manifest.get('workers')=={}
assert manifest.get('auto_buy') is False and manifest.get('main_source_change') is True
assert manifest.get('strategy_behavior_change') is False

# Runtime expectations remain pinned to the already-applied v1154 components.
assert assignments.get('EXPECTED_GUARD_VERSION')=='guard_v2.5.190_candidate_time_quality_map_v1154_2026-06-30'
assert assignments.get('EXPECTED_PAPER_VERSION')=='paper_bot_v1.029'
assert assignments.get('EXPECTED_STRATEGY_VERSION')=='strategy_worker_v1.020'

# Execute only the new pure renderer definitions against synthetic canonical data.
selected=[]
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and (node.name.startswith('_v1155_') or node.name.startswith('render_flow_map_telegram_v1155') or node.name.startswith('render_flow_map_pretty_txt_v1155') or node.name.startswith('render_candidate_standard_telegram_v1155') or node.name=='compact_command_output'):
        if node.name!='_v1155_seed_issue_once':
            selected.append(node)
mod=ast.Module(body=selected,type_ignores=[])
ns:Dict[str,Any]={
    'Any':Any,'Dict':Dict,'List':List,'Optional':Optional,'Tuple':Tuple,
    'BASE_DIR':Path('/tmp'),'CANDIDATE_STANDARD_STATUS_V1141':Path('/tmp/candidate.json'),
    '_v1152_delay_label':lambda k:{'quality_to_s1_sec':'품질 통과 → S1 최초 저장','trigger_to_quality_sec':'방아쇠 발생 → 품질검사'}.get(str(k),str(k)),
    '_ops_short':lambda x,n=200:str(x)[:n],
    '_ops_fmt_mb':lambda x:f'{x}MB' if x is not None else '-',
    '_flow_reason_text':lambda d,limit=4:' / '.join(f'{k} {v}' for k,v in list((d or {}).items())[:limit]) or '없음',
}
exec(compile(mod,str(SRC),'exec'),ns)

timeq={'state':'CHECK','sample_count':4,'stale_trigger_count':4,'slippage_stale_count':0,'source_missing_count':0,'exact_first_three_count':4,'exact_coverage_pct':100.0,'wait_new_rebreak_count':0,'first_arrival_vs_repeat_state':'FIRST_ARRIVAL_PROVABLE'}
pipe={'progress_state_v1152':'COMPLETE','overall_state_v1154':'CHECK','candidate_time_quality_v1154':timeq,'delay_summary_v1152':{'count':4,'stale_count':4,'mean_total_age_sec':1168.852,'largest_segment_counts':{'quality_to_s1_sec':3,'trigger_to_quality_sec':1},'samples':[{'ticker':'RON','total_trigger_to_paper_sec':3280.447,'expired_by_sec':3160.447,'largest_segment':'trigger_to_quality_sec','largest_segment_sec':2508.36,'cycle_id':'strategy-test','exact_segments_v1153':{'trigger_to_quality_sec':2508.36,'quality_to_s1_sec':700.177,'s1_to_paper_sec':5.906}},{'ticker':'DAO','total_trigger_to_paper_sec':457.211,'expired_by_sec':337.211,'largest_segment':'quality_to_s1_sec','largest_segment_sec':446.738,'cycle_id':'strategy-test','exact_segments_v1153':{'trigger_to_quality_sec':4.41,'quality_to_s1_sec':446.738,'s1_to_paper_sec':6.054}}]}}
flow={'problem_groups':[{'code':'CANDIDATE_TIME_QUALITY_DEGRADED','severity':'CHECK','location_summary':'EDGE:strategy→paper','cause':'old trigger','impact':'candidate blocked','fix_target':'strategy_worker.py'},{'code':'CPU_SATURATION','severity':'CHECK','location_summary':'RESOURCE:micro','cause':'cpu high','impact':'delay','fix_target':'micro.py'}], 'stages':[{'step':8,'name':'Strategy','state':'NORMAL','input_count':461,'output_count':461,'blocked_count':0,'pending_count':0,'error_count':0,'cycle_sec':14.063,'reason_counts':{}},{'step':11,'name':'Paper TTL','state':'NORMAL','input_count':4,'output_count':0,'blocked_count':4,'pending_count':0,'error_count':0,'cycle_sec':0.824,'reason_counts':{'STALE_TRIGGER_OCCURRENCE':4}}], 'resource_summary':{'processes':[{'name':'micro','cpu_pct':106.26,'rss_mb':43.9,'rss_trend_mb_h':0.0,'active_phase':None}],'disk':{'available_bytes':1024},'projected_disk_days':10.6}, 'runtime_summary':{'worker_count':14,'down':[],'check':[],'mismatch':[]}, 'next_actions':[{'priority':1,'code':'CANDIDATE_TIME','action':'trace quality to S1'}]}
ns['_flow_map_v1103_snapshot']=lambda: ({'snapshot_id':'ops-test'},flow)
ns['_v1155_pipeline_objects']=lambda: ({},pipe,timeq)
ns['load_json']=lambda path,default=None: {'baseline_identity':{'candidate_reference_unique_n':18},'contract_identity':{'semantic_match':True},'final_judgement':{'state':'CHECK'},'entry_quality':{'fresh_open':11,'fresh_closed':4},'book_performance':{'fresh_closed':4},'section_completeness':{'source_gap_count':7,'source_missing_count':2}}

telegram=ns['render_flow_map_telegram_v1155']()
assert len(telegram.splitlines())<=13,telegram
assert '주원인:' in telegram and '품질 통과 → S1 최초 저장 3건' in telegram
assert '[오류 위치 인덱스]' not in telegram and '{"' not in telegram
pretty=ns['render_flow_map_pretty_txt_v1155']()
assert '[3. 20단계 흐름]' in pretty and '[4. 중요 오류와 조치]' in pretty and 'RON' in pretty
candidate=ns['render_candidate_standard_telegram_v1155']()
assert len(candidate.splitlines())<=11,candidate
assert '후보선정 기준: 변경 없음' in candidate and '원천 누락: 7개' in candidate
issue=ns['compact_command_output']('issue_ledger','''🧾 /issue_ledger\n- OPEN 4 / CHECK 101 / PARTIAL 3 / FAIL 3 / DONE 60\n📌 OPEN/CHECK 최신 우선\n- [runtime] ONE CHECK · first\n  · detail\n- [기타] TWO FAIL · second\n✅ DONE 60건''')
assert len(issue.splitlines())<=6 and 'ONE' in issue and 'detail' not in issue

print(json.dumps({'status':'PASS','telegram_lines':len(telegram.splitlines()),'candidate_lines':len(candidate.splitlines()),'pretty_lines':len(pretty.splitlines())},ensure_ascii=False))
