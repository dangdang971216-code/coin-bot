#!/usr/bin/env python3
from __future__ import annotations
import json
import hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert manifest.get('version')=='v1155'
assert manifest.get('main')=='coinbot_main_v2_13_1116.py'
assert not manifest.get('guard') and not manifest.get('paper') and manifest.get('workers')=={}
assert manifest.get('live_ledger_included') is False
missing=[x for x in manifest.get('support_files',[]) if not (ROOT/x).is_file()]
assert not missing,missing
forbidden=[]
for p in ROOT.rglob('*'):
    if not p.is_file(): continue
    rel=p.relative_to(ROOT).as_posix().lower()
    if '__pycache__' in rel or rel.endswith('.pyc') or rel.startswith('runtime/') or rel.startswith('ledger/'):
        forbidden.append(rel)
    if any(x in p.name.lower() for x in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','decision_state','canonical_performance_snapshot')):
        forbidden.append(rel)
assert not forbidden,forbidden

sha_rows={}
for line in (ROOT/'FILES_SHA256_v1155.tsv').read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    digest,rel=line.split('\t',1)
    sha_rows[rel]=digest
actual_files=sorted(p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='FILES_SHA256_v1155.tsv')
assert sorted(sha_rows)==actual_files,(set(actual_files)-set(sha_rows),set(sha_rows)-set(actual_files))
for rel,digest in sha_rows.items():
    assert hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()==digest,rel
print(json.dumps({'status':'PASS','support_files':len(manifest.get('support_files',[])),'forbidden':0,'sha_rows':len(sha_rows)},ensure_ascii=False))
