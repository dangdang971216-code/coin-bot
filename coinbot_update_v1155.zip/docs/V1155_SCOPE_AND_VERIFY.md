# v1155 범위와 검수

## 범위
1. /flow_map_full Telegram 12줄 안팎 핵심판.
2. /candidate_standard Telegram 10줄 안팎 핵심판.
3. /change_verify, /issue_ledger, /errorlog 핵심만 표시.
4. /flow_map_full, /candidate_standard 단독 실행 시 상세 TXT 자동 전송.
5. batch/multicommand는 heavy command를 항상 compact Telegram으로 표시하고 TXT는 상세 표시.
6. TXT 제목을 v1155로 정리.

## 로컬 검수
- py_compile PASS.
- synthetic canonical snapshot에서 flow Telegram 12줄, candidate Telegram 10줄.
- pretty TXT에 후보시간·20단계·오류·자원 구역 존재.
- raw JSON marker가 Telegram에 없음.
- manifest는 Main only.

## 서버 DONE 기준
- Main runtime v2.13.1116/hash 일치.
- /flow_map_full과 /candidate_standard 각각 짧은 메시지 + TXT 1개.
- multicommand에서도 긴 개발증거가 Telegram에 나오지 않음.
- TXT snapshot ID가 화면과 동일.
- 신규 오류 0, 자동매수 OFF.
