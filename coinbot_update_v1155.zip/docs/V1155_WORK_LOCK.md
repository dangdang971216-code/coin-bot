# v1155 작업 잠금

## 증상
- Telegram에서 /flow_map_full과 /candidate_standard가 개발용 전체 증거까지 출력되어 핵심 판정이 묻힘.
- /issue_ledger도 오래된 이력과 상세 설명이 길게 노출됨.
- TXT 제목이 v1016으로 남아 현재 릴리스와 혼동됨.

## 실제 원인
- explicit command와 full_mode가 compact renderer를 우회함.
- flow_map_full public renderer가 raw JSON 전체 증거를 Telegram body로 반환함.
- batch TXT도 heavy command를 상황에 따라 compact/full로 혼합함.

## owner
- Main command renderer / command collector / summary TXT writer.

## 수정 파일
- coinbot_main_v2_13_1116.py만.

## 새 본선
- Telegram: 상태, 원인, 영향, 1순위 행동만.
- TXT: 같은 snapshot의 후보시간, 20단계, 오류, 자원, 다음 행동을 구역별 표시.

## 변경하지 않음
- Strategy/Paper/Guard 코드와 모든 매매 수치·계약.
- 자동매수 OFF.
