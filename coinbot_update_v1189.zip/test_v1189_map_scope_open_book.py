#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import sys
import tempfile
import time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
BASE=Path(tempfile.mkdtemp(prefix='coinbot_v1189_test_'))
os.environ['COINBOT_BASE_DIR']=str(BASE)
os.environ.pop('TELEGRAM_TOKEN',None)
sys.path.insert(0,str(ROOT))
now=time.time(); pid=os.getpid()

def write(name,obj):
    p=BASE/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')

def status(name,version,rows=3,last=0.2,**extra):
    obj={'running':True,'state':'running','version':version,'pid':pid,'updated_ts':now,'row_count':rows,'last_sec':last,'phase':'idle'}
    obj.update(extra); write(name,obj)

status('clean_scanner_status.json','scanner_worker_v0.945',3)
status('clean_feature_status.json','feature_worker_v0.6',3)
status('clean_candle_status.json','candle_worker_v0.960',3)
status('clean_market_regime_status.json','market_regime_worker_v0.1',3)
status('clean_orderflow_status.json','orderflow_worker_v0.11',3)
status('clean_target_router_status.json','target_router_worker_v0.28',3)
status('clean_risk_status.json','risk_worker_v0.13',3)
status('clean_ws_sidecar_status.json','ws_sidecar_v0.7',3,target_count=3)
status('clean_bithumb_micro_status.json','micro_v0.15',3,target_count=3)
write('clean_ws_targets.json',[{'ticker':'ABC'},{'ticker':'DEF'},{'ticker':'GHI'}])
write('clean_bithumb_micro_cache.json',[{'ticker':'ABC'},{'ticker':'DEF'},{'ticker':'GHI'}])
write('clean_strategy_worker_status.json',{'running':True,'state':'running','version':'strategy_worker_v1.037','pid':pid,'updated_ts':now,'paper_latest_count':3,'s1_count':1,'last_sec':1.2,'full_cycle_sec_v1031':1.2,'execution_handoff_elapsed_sec_v1179':0.8,'phase':'idle'})
write('clean_review_worker_status.json',{'running':True,'state':'running','version':'review_worker_v1.016','pid':pid,'updated_ts':now,'candidate_rows':3,'last_cycle_sec':0.1,'phase':'idle'})
write('clean_brain_status.json',{'running':True,'state':'running','version':'수익형 v2.13.1132','pid':pid,'started_at':now-100,'updated_ts':now,'telegram_state':'running','telegram_error':'-','command_count':37,'scan_running':False,'phase':'idle'})
write('paper_bot_status.json',{
    'running':True,'state':'running','version':'paper_bot_v1.049','pid':pid,'process_started_at':now-100,'updated_ts':now,
    'elapsed_sec':1.5,'opened_this_cycle':1,'closed_this_cycle':0,'open_count':2,
    'pick_stats':{'latest_count':3,'paper_generation_candidate_count_v1158':3,'s1_seen':1,'selected_s1':1,'paper_funnel_accounted_v1102':1,'paper_funnel_unclassified_v1102':0,'paper_funnel_balance_ok_v1102':True,'paper_funnel_terminal_counts_v1102':{'SELECTED':1}},
    'paper_audit_only_summary_v1175':{'integrity_block_counts':{},'audit_only_counts':{},'actual_late_safety_block_count':0},
    'paper_performance_semantic_heartbeat_v1117':{'semantic_current':True,'state':'CURRENT_AFTER_WRITE'},
})
components={}
for name,ver in [('main','수익형 v2.13.1132'),('paper','paper_bot_v1.049'),('guard','guard_v2.5.201_v1189_scope_pinned_evidence_map_2026-07-02'),('strategy','strategy_worker_v1.037'),('review','review_worker_v1.016'),('scanner','scanner_worker_v0.945'),('feature','feature_worker_v0.6'),('candle','candle_worker_v0.960'),('market','market_regime_worker_v0.1'),('orderflow','orderflow_worker_v0.11'),('target','target_router_worker_v0.28'),('risk','risk_worker_v0.13'),('ws','ws_sidecar_v0.7'),('micro','micro_v0.15')]:
    components[name]={'service':name,'runtime_state':'OK','main_pid':pid,'process_count':1,'status_pid':pid,'status_version':ver,'cpu_pct':1.0,'rss_mb':20.0,'status_age_sec':0.1,'source_alias_hash_match':True}
write('clean_guard_runtime_status_v1010.json',{'version':'guard_v2.5.201_v1189_scope_pinned_evidence_map_2026-07-02','generated_at':now,'components':components,'server':{'cpu_pct':10.0,'iowait_pct':1.0,'mem_used_pct':20.0,'mem_available_mb':1000,'swap_used_mb':0,'disk_free_gb':10.0,'disk_used_pct':50.0},'io_top_components_v1011':[]})
write('runtime/strategy_worker_singleton_v1110.lock',{'pid':pid,'version':'strategy_worker_v1.037'})
write('runtime/review_worker_singleton_v1121.lock',{'pid':pid,'version':'review_worker_v1.016'})
write('strategy_candidate_pipeline_commit_v1150.json',{'state':'NORMAL','complete':True,'cycle_id':'cy1','candidate_commit_id':'cm1','candidate_rows':3,'s1_hold_count':1,'priority_request_count':3,'all_required_commits_v1150':True,'committed_handoff_file_v1158':str(BASE/'handoff.json'),'cycle_started_ts':now-2,'s1_hold_completed_ts_v1152':now-1.2,'candidate_snapshot_completed_ts_v1152':now-1.0,'priority_requests_completed_ts_v1152':now-0.9,'committed_handoff_completed_ts_v1158':now-0.8,'progress_state_v1152':'COMPLETE','last_complete_cycle_v1152':{'state':'NORMAL','cycle_id':'cy1','candidate_commit_id':'cm1','candidate_rows':3,'s1_hold_count':1,'completed_ts':now-0.8}})
write('handoff.json',{'schema':'strategy_paper_handoff_committed_v1158','cycle_id':'cy1','candidate_commit_id':'cm1'})
write('review_observation_request_v1181.json',{'pipeline_cycle_id':'cy1','candidate_commit_id':'cm1','candidate_rows':3,'created_ts':now-0.7})
write('canonical_review_snapshot_v1181.json',{'source':{'state':'NORMAL','pipeline_cycle_id':'cy1','candidate_commit_id':'cm1'},'candidate':{'total':3,'s1':1}})
standard={
 'state':'NORMAL','snapshot_id':'std1','generated_ts':now-0.6,'missing':[],
 'delivery':{'state':'NORMAL','pipeline_cycle_id':'cy1','candidate_commit_id':'cm1'},
 'candidate':{'total':3,'s1':1,'s2':1,'s3':1},'structure':{},'quality':{},'time':{},
 'performance':{'snapshot_id':'perf-old','generated_at':now-1,'count':1,'wins':1,'losses':0,'win_rate':100,'sum_pct':1.0},
 'contract':{'state':'NORMAL','owner':'paper'}
}
write('canonical_candidate_standard_v1181.json',standard)
open_rows={
 'p1':{'pos_id':'p1','ticker':'ABC','paper_decision_key_v926':'d1','trigger_price':100,'invalid_price':95,'target_price':110,'entry_price':100,'current_price':103,'last_pnl_pct':2.9,'mfe_pct_v983':4.0,'mae_pct_v983':-1.0,'giveback_pct_v983':1.1,'last_update':now},
 'p2':{'pos_id':'p2','ticker':'DEF','paper_decision_key_v926':'d2','trigger_price':100,'invalid_price':95,'target_price':110,'entry_price':100,'current_price':98,'last_pnl_pct':-2.1,'mfe_pct_v983':0.5,'mae_pct_v983':-2.1,'giveback_pct_v983':2.6,'last_update':now},
}
write('paper_bot_open.json',open_rows)
write('paper_decision_state_v926.json',{'records':{'d1':{},'d2':{}}})
(BASE/'paper_bot_closed.jsonl').write_text('',encoding='utf-8')
write('paper_closed_append_status_v925.json',{'state':'NORMAL','append_verified':True,'decision_saved':True,'open_removed':True,'notification_sent':True})
perf={
 'snapshot_id':'perf-new','generated_at':now,'generated_at_text':'now','source_owner':'paper_bot_single_canonical_performance_writer',
 'counts':{'raw_ledger_rows':2,'exact_unique_closed':2,'duplicate_closed_rows':0,'missing_decision_key':0,'decision_not_closed_or_missing':0,'bad_json_rows':0,'current_epoch_open_rows_v1046':2},
 'windows':{'today':{'n':2,'wins':2,'losses':0,'win_rate':100,'total':6,'avg':3},'yesterday':{},'recent_3h':{'n':2,'wins':2,'losses':0,'win_rate':100,'total':6,'avg':3},'recent_6h':{'n':2,'wins':2,'losses':0,'win_rate':100,'total':6,'avg':3},'recent_24h':{'n':2,'wins':2,'losses':0,'win_rate':100,'total':6,'avg':3},'all':{'n':2,'wins':2,'losses':0,'win_rate':100,'total':6,'avg':3}},
 'performance_epoch_v1045':{'stats':{'n':2,'wins':2,'losses':0,'win_rate':100,'total':6,'avg':3},'current_open_count':2},
 'book_performance_v1189':{'open_count':2,'valid_pnl_rows':2,'missing_pnl_rows':0,'current_total':0.8,'current_avg':0.4,'wins':1,'losses':1,'flats':0,'positive_total':2.9,'negative_total':-2.1,'mfe_total':4.5,'giveback_total':3.7,'giveback_avg':1.85,'profit_top':[{'ticker':'ABC','pnl_pct':2.9}],'profit_top_sum':2.9,'loss_top':[{'ticker':'DEF','pnl_pct':-2.1}],'loss_top_sum':-2.1,'giveback_top':[{'ticker':'DEF','giveback_pct':2.6}],'giveback_top_sum':2.6},
 'today_profit_top_v1189':{'rows':[{'ticker':'AAA','pnl_pct':4.0,'exit_reason':'swing_trailing'},{'ticker':'BBB','pnl_pct':2.0,'exit_reason':'structure_target'}],'sum_pct':6.0},
 'recent_rows':[]
}
write('canonical_performance_snapshot_v987.json',perf)
write('command_summary_status_v1187.json',{'ok':True,'txt_count':1,'status':'TXT 전송완료 후 서버삭제','render_sum_sec':0.1,'delivery_total_sec':0.2,'snapshot_id':'old','updated_ts':now})
# Current-cycle timing events, plus one old unscoped sample that must not contaminate current timing.
with (BASE/'paper_candidate_path_events_v1153.jsonl').open('w',encoding='utf-8') as f:
    for stage,ts in [('PAPER_RECEIVED',now-0.7),('EXECUTION_DATA_READY',now-0.5),('OPEN_COMMITTED',now-0.2)]:
        f.write(json.dumps({'stage':stage,'trigger_event_key':'e1','recorded_at':ts,'evidence':{'pipeline_cycle_id':'cy1','candidate_commit_id':'cm1'}})+'\n')
    f.write(json.dumps({'stage':'PAPER_RECEIVED','trigger_event_key':'old','recorded_at':now-10000})+'\n')
write('paper_candidate_path_state_v1153.json',{'records':{'x':{'anchor':'e1','repeat_exposure_count':2},'old':{'anchor':'old','repeat_exposure_count':999}}})
write('paper_timing_spine_status_v940.json',{'samples':[{'pipeline_cycle_id':'cy1','ticker':'ABC','selected_to_open_delay_sec':0.2,'s1_to_selected_delay_sec':0.3},{'ticker':'OLD','trigger_to_selected_delay_sec':99999}]})

spec=importlib.util.spec_from_file_location('spine',ROOT/'canonical_spine_v1189.py'); spine=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules['spine']=spine; spec.loader.exec_module(spine)
snap=spine.build_ops_snapshot(BASE)
assert len(snap['stages'])==20
assert snap['stages'][0]['state']=='NORMAL',snap['stages'][0]
assert snap['stages'][0]['evidence']['ws_count']==3 and snap['stages'][0]['evidence']['micro_count']==3
assert snap['stages'][10]['evidence']['generation_candidate_rows']==3
assert snap['stages'][10]['evidence']['execution_s1_rows']==1
assert snap['timing_path']['scope_cycle_id']=='cy1'
assert snap['timing_path']['repeat_exposure_count']==2
assert snap['timing_path']['historical_repeat_exposure_count']==999
assert all((r.get('max_sec') or 0)<99999 for r in snap['timing_path']['segments'])
assert snap['ledger_performance']['reference_relation']=='CURRENT_PERFORMANCE_NEWER'
assert snap['ledger_performance']['book_performance_present'] is True
assert snap['candidate_standard_full']['delivery']['pipeline_cycle_id']=='cy1'
(BASE/'ops_spine_snapshot_v1181.json').write_text(json.dumps(snap,ensure_ascii=False),encoding='utf-8')

spec=importlib.util.spec_from_file_location('main',ROOT/'coinbot_main_v2_13_1132.py'); main=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules['main']=main; spec.loader.exec_module(main)
compact=main.render_flow_map_compact()
assert '현재 오류 원인 0개' in compact,compact
full=main.render_flow_map_full()
for text in ['현재 generation 시간경로','완료 generation 3 확인 / 실행대상 S1 1 판독','후보판 성과참조 관계 CURRENT_PERFORMANCE_NEWER']:
    assert text in full,(text,full)
score=main.render_version_score_compact()
for text in ['🏆 오늘 실현수익 TOP5','TOP2 합산 +6.00%','전체 평가손익 +0.80%','현재 수익 TOP3 · 합 +2.90%','현재 손실 TOP3 · 합 -2.10%']:
    assert text in score,(text,score)
# Pin must force candidate command to use the candidate object embedded in the pinned ops map.
write('canonical_candidate_standard_v1181.json',dict(standard,delivery={'state':'NORMAL','pipeline_cycle_id':'cy2','candidate_commit_id':'cm2'}))
meta=main.begin_canonical_pin()
try:
    candidate_text=main.render_candidate_compact()
    assert 'cycle cy1' in candidate_text,candidate_text
finally:
    main.end_canonical_pin()
# Repeated same root cause should be one cause with two repetitions.
(BASE/'paper_bot_error.log').write_text(
    f'[{time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(now-1))} KST] v783_remove_pycache: FileNotFoundError: .bundle_unpack_111\nTraceback A\n'
    f'[{time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(now))} KST] v783_remove_pycache: FileNotFoundError: .bundle_unpack_222\nTraceback B\n',encoding='utf-8')
err=spine.error_scope_summary(BASE)
assert err['current_cause_count']==1,err
assert err['current_count']==2,err
# Paper-owned builders.
spec=importlib.util.spec_from_file_location('paper',ROOT/'paper_bot_v1.049.py'); paper=importlib.util.module_from_spec(spec); assert spec and spec.loader; sys.modules['paper']=paper; spec.loader.exec_module(paper)
book=paper._v1189_open_book_performance(open_rows,now)
assert book['open_count']==2 and round(book['current_total'],1)==0.8
closed_top=paper._v1189_today_profit_top([{'ticker':'A','pnl_pct':5,'exit_reason':'x'},{'ticker':'B','pnl_pct':-2,'exit_reason':'y'},{'ticker':'C','pnl_pct':3,'exit_reason':'z'}],now)
assert [r['ticker'] for r in closed_top['rows']]==['A','C'] and closed_top['sum_pct']==8
print('PASS')
