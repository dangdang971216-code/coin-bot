코인봇 업데이트 v1189 · 지도 정합성·OPEN 손익·오늘 TOP 완성판

현재 서버 증거 기준
- Guard v2.5.200
- Strategy v1.037
- Review v1.016
- Main v2.13.1131
- Paper v1.048
- v1188 전수지도 작동 확인
- 자동매수 OFF

v1189 대상
- Guard v2.5.201
- Main v2.13.1132
- Paper v1.049
- Strategy v1.037 유지
- Review v1.016 유지

핵심 변경
1. 같은 명령 묶음은 시작 시점 canonical 파일을 정확히 고정해 지도·후보판·성과판 cycle 혼합 방지
2. Guard 지도에 사용한 후보 기준판 원본을 같은 ops snapshot 안에 봉인
3. Paper 후보 판독을 “완료 generation 전체 확인 / 실행대상 S1 판독”으로 분리
4. WS·Micro 실제 건수 증거가 없으면 NORMAL 금지
5. 현재 generation 실행시간, 의미상 대기, 과거·범위불명 표본을 분리
6. 후보판 성과참조 ID와 최신 성과 snapshot의 생성순서를 검사하고 단순 ID 불일치를 오류로 보지 않음
7. 현재 runtime 오류를 원인 개수와 반복 횟수로 분리
8. Paper canonical 성과 snapshot에 현재 OPEN 전체 평가손익·수익/손실 합·TOP3·반납 TOP3 저장
9. 오늘 exact CLOSED 실현수익 TOP5와 합산 저장·표시
10. OPEN monitor 시각에 Paper의 last_update 증거 연결

중요 원칙
- 신규 차단 0
- 시간·오류는 진단만 하며 자동 진입제한·TTL·OPEN 제한 추가 없음
- 전략식·Gate·trigger·invalid·target·RR·spread·slippage·청산계약 변경 없음
- OPEN/CLOSED/decision/change/issue 원장 수정·삭제 없음
- 임시폴더 자동삭제 없음
- 자동매수 OFF

적용
1. 가드봇에서 /gupgrade_bundle 단독 실행
2. 자동 이어적용 완료 후 가드·메인·Paper 검수
3. runtime exact/hash, 다음 cycle, OPEN 손익 snapshot, 오늘 TOP 출력 확인 전 DONE 금지
