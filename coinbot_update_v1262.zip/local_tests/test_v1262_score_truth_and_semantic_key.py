from __future__ import annotations
import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def load(name: str):
    p = ROOT / f'{name}.py'
    spec = importlib.util.spec_from_file_location(name, p)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def test_paper_missing_and_unknown_never_become_v1211():
    m = load('paper_bot_v1.077')
    missing = {'structure_contract_version': 'structure_contract_v1211_legacy', 'structure_contract_explicit_v1261': False}
    explicit = {'structure_contract_version': 'structure_contract_v1211_legacy', 'structure_contract_explicit_v1261': True}
    unknown = {'structure_contract_version': 'structure_contract_v9999_unknown', 'structure_contract_explicit_v1261': True}
    assert m._v1262_contract_identity(missing)['class'] == 'UNCLASSIFIED_MISSING_OPEN_IDENTITY'
    assert m._v1262_contract_identity(explicit)['class'] == 'EXPLICIT_V1211'
    assert m._v1262_contract_identity(unknown)['class'] == 'UNCLASSIFIED_UNKNOWN_OPEN_IDENTITY'


def test_paper_compact_row_does_not_invent_version():
    m = load('paper_bot_v1.077')
    row = {'decision_key': 'd1', 'ticker': 'BTC', 'entry_price': 100.0, 'exit_price': 101.0, 'pnl_pct': 1.0}
    out = m._v987_perf_compact_row(row, 'd1', 'exact')
    assert out['structure_contract_version'] is None
    assert out['structure_contract_explicit_v1262'] is False
    assert out['structure_contract_class_v1262'] == 'UNCLASSIFIED_MISSING_OPEN_IDENTITY'


def test_paper_score_reconciliation_and_explicit_v1211_only():
    m = load('paper_bot_v1.077')
    rows = [
        {'decision_key': 'c', 'current_unified_contract_exact_v1261': True, 'pnl_pct': 1.0, 'opened_at': 1.0, 'closed_at': 2.0},
        {'decision_key': 'v', 'structure_contract_version': 'structure_contract_v1211_legacy', 'structure_contract_explicit_v1261': True, 'pnl_pct': 2.0, 'opened_at': 1.0, 'closed_at': 2.0},
        {'decision_key': 'm', 'structure_contract_version': 'structure_contract_v1211_legacy', 'structure_contract_explicit_v1261': False, 'pnl_pct': -1.0, 'opened_at': 1.0, 'closed_at': 2.0},
        {'decision_key': 'u', 'structure_contract_version': 'structure_contract_v9999_unknown', 'structure_contract_explicit_v1261': True, 'pnl_pct': -2.0, 'opened_at': 1.0, 'closed_at': 2.0},
        {'decision_key': 'o', 'structure_contract_version': 'structure_contract_v1212_dynamic_zones', 'structure_contract_explicit_v1261': True, 'pnl_pct': 0.5, 'opened_at': 1.0, 'closed_at': 2.0},
    ]
    m._V1262_PREV_APPLY_PERFORMANCE = lambda snap, nowv, active=None: {'rows': [dict(x) for x in rows]}
    m._v1189_open_book_performance = lambda book, nowv: {'valid_pnl_rows': 0, 'current_total': 0.0, 'wins': 0, 'losses': 0, 'flats': 0}
    out = m._v1045_apply_performance_epoch_contract__v1262({}, 100000.0, {})
    root = out['version_score_v1262']
    assert root['v1211_actual']['closed_count'] == 1
    assert root['unclassified']['closed_count'] == 2
    assert root['unclassified']['missing_contract_identity_rows'] == 1
    assert root['unclassified']['unknown_contract_identity_rows'] == 1
    assert root['other_explicit_contracts']['closed_count'] == 1
    assert root['reconciliation']['balanced'] is True
    assert out['version_score_v1261']['v1211_actual']['closed_count'] == 1


def candidate(exact_key: str, price: float = 100.0, trigger: float = 99.0, scanner: str = 'scan-occ-1'):
    return {
        'ticker': 'ABC',
        'current_price': price,
        'trigger_occurrence_candidate_key_v1037': exact_key,
        'scanner_occurrence_key_v1203': scanner,
        'candidate_pipeline_cycle_id_v1150': exact_key,
        'candidate_commit_id': exact_key,
        'unified_strategy_contract_v1257': {
            'schema': 'unified_alt_swing_contract_v1257',
            'ready': False,
            'primary_entry_structure': {
                'trigger_price': trigger,
                'invalid_price': 95.0,
                'base_target_price': 110.0,
            },
            'v1211_structural_support': {
                'early_failure_invalid_price': 94.0,
                'extension_target_price': 120.0,
            },
            'entry_quality_support': {'confirmed': False, 'reason': 'trigger_not_reached'},
        },
    }


def test_review_repeated_cycle_exact_keys_share_one_semantic_event_and_mature_6h():
    m = load('review_worker_v1.038')
    start = 1_000_000.0
    state = m._v1262_new_state(start)
    state = m._v1262_update_missed_state(state, [candidate('market:ABC|cycle:1000')], start)
    state = m._v1262_update_missed_state(state, [candidate('market:ABC|cycle:2000', price=102.0)], start + 60)
    assert len(state['events']) == 1
    event = next(iter(state['events'].values()))
    assert event['observation_count'] == 2
    assert len(event['exact_candidate_keys']) == 2
    state = m._v1262_update_missed_state(state, [candidate('market:ABC|cycle:3000', price=105.0)], start + 6 * 3600 + 1)
    event = next(iter(state['events'].values()))
    assert event['return_6h_pct'] is not None
    assert event['return_6h_pct'] == 5.0


def test_review_new_structure_creates_new_semantic_event():
    m = load('review_worker_v1.038')
    start = 2_000_000.0
    state = m._v1262_new_state(start)
    state = m._v1262_update_missed_state(state, [candidate('k1', trigger=99.0)], start)
    state = m._v1262_update_missed_state(state, [candidate('k2', trigger=101.0)], start + 1)
    assert len(state['events']) == 2


def test_review_migrates_duplicate_v1261_events_without_rewriting_old(tmp_path: Path):
    m = load('review_worker_v1.038')
    old_path = tmp_path / m.V1262_OLD_STATE_FILE
    old = {
        'schema': 'current_strategy_missed_state_v1261',
        'started_ts': 10.0,
        'events': {
            'a': {'ticker':'ABC','reason_category':'trigger_not_reached','created_ts':10.0,'start_price':100.0,'high_price':102.0,'low_price':99.0,'trigger_price':99.0,'invalid_price':95.0,'target_price':110.0,'early_failure_price':94.0,'extension_target_price':120.0,'exact_candidate_key':'k1'},
            'b': {'ticker':'ABC','reason_category':'trigger_not_reached','created_ts':20.0,'start_price':101.0,'high_price':105.0,'low_price':98.0,'trigger_price':99.0,'invalid_price':95.0,'target_price':110.0,'early_failure_price':94.0,'extension_target_price':120.0,'exact_candidate_key':'k2'},
        },
    }
    old_text = json.dumps(old, ensure_ascii=False)
    old_path.write_text(old_text, encoding='utf-8')
    state = m._v1262_migrate_v1261_state(tmp_path, 100.0)
    assert len(state['events']) == 1
    event = next(iter(state['events'].values()))
    assert event['created_ts'] == 10.0
    assert event['high_price'] == 105.0
    assert event['low_price'] == 98.0
    assert set(event['exact_candidate_keys']) == {'k1','k2'}
    assert old_path.read_text(encoding='utf-8') == old_text


def test_main_shows_unclassified_check_and_semantic_counts():
    m = load('coinbot_main_v2_13_1163')
    root = {
        'owner': 'paper_bot_single_canonical_performance_writer',
        'current_strategy': {'state':'COLLECTING','closed_count':0,'open_count':0,'closed_windows':{},'open':{},'combined':{}},
        'v1211_actual': {'state':'CHECK','closed_count':0,'all':{}},
        'unclassified': {'state':'CHECK','closed_count':1578,'missing_contract_identity_rows':1578,'unknown_contract_identity_rows':0},
    }
    m._performance_snapshot = lambda: {'version_score_v1262':root,'snapshot_id':'s1','counts':{}}
    m._version_score_review_snapshot = lambda: {'current_missed_v1262':{'state':'NORMAL','tracked_total':10,'active_missed':10,'source_observation_total':100,'completed_6h':2}}
    m.file_age = lambda path: 1.0
    text = m.render_version_score(())
    assert '명시적 v1211' in text
    assert '계약표기 미확인' in text
    assert '1578' in text
    assert 'v1211로 보정하지 않음' in text
    assert '원본 관찰 100' in text


def test_guard_live_ledger_tail_command(tmp_path: Path):
    m = load('backga_guard_bot_v2_5_240')
    m.BOT_DIR = tmp_path
    issue_rows = [{'issue_id': a, 'event': b} for a,b in m.V1262_EXPECTED_ISSUE_EVENTS]
    change_rows = [{'change_id': a, 'event': b} for a,b in m.V1262_EXPECTED_CHANGE_EVENTS]
    (tmp_path/'issue_ledger.jsonl').write_text('\n'.join(json.dumps(x) for x in issue_rows)+'\n', encoding='utf-8')
    (tmp_path/'change_verify_ledger.jsonl').write_text('\n'.join(json.dumps(x) for x in change_rows)+'\n', encoding='utf-8')
    text = m.gledger_v1262_text()
    assert '상태: DONE' in text
    assert 'append writer 계약' in text


def test_strategy_is_byte_identical_to_v1261():
    import hashlib
    new = (ROOT/'strategy_worker_v1.062.py').read_bytes()
    assert hashlib.sha256(new).hexdigest() == 'd6019dfd4f82bbdfcd9ec144882e84e1331494813782c8fe5202a64695e7f84e'
