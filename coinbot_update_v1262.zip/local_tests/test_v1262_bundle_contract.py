from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def test_manifest_and_runtime_files():
    required = {
        'DEPLOY_BUNDLE.json', 'ACTIVE_VERSION_MATRIX.json',
        'coinbot_main_v2_13_1163.py', 'paper_bot_v1.077.py',
        'review_worker_v1.038.py', 'strategy_worker_v1.062.py',
        'backga_guard_bot_v2_5_240.py',
        'ledger_events_pending/V1261_POST_SERVER_ANALYSIS_ISSUE_LEDGER_EVENTS.jsonl',
        'ledger_events_pending/V1261_POST_SERVER_ANALYSIS_CHANGE_VERIFY_EVENTS.jsonl',
    }
    assert all((ROOT/name).exists() for name in required)
    manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
    assert manifest['release']=='v1262'
    assert manifest['auto_buy'] is False
    assert manifest['actual_trading_changed'] is False
    assert manifest['strategy_values_changed'] is False
    assert manifest['paper']=='paper_bot_v1.077.py'
    assert manifest['main']=='coinbot_main_v2_13_1163.py'
    assert manifest['workers']['review']=='review_worker_v1.038.py'
    assert manifest['workers']['strategy']=='strategy_worker_v1.062.py'
    assert manifest['historical_ledgers_rewritten'] is False
    assert manifest['target_comparison_status']=='PENDING_LIVE_EXACT_AFTER_V1262'
