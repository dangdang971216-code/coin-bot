v1262는 성과판 진실과 놓친 후보 semantic key만 수리한다.
Strategy 후보식·trigger·invalid·target·RR·entry·exit는 변경하지 않았다.
과거 원장과 기존 OPEN을 재작성하지 않는다.
서버 적용·runtime·live ledger tail 증명 전 상태는 CHECK다.
자동매수 OFF.
