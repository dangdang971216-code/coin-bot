v2119 is a Python 3.11 bundle compile hotfix for two Main audit f-strings. v2118 direct candidate handoff logic is unchanged. Auto-buy OFF.
