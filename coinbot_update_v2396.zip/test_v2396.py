#!/usr/bin/env python3
from __future__ import annotations
import ast, hashlib, importlib.util, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT=Path('/mnt/data/v2396_work')
BASE=Path('/mnt/data/v2395_work')
FILES={
 'review':ROOT/'review_worker_v2.165.py',
 'main':ROOT/'coinbot_main_v2_13_2241.py',
 'core':ROOT/'strategy_v2_core_v2200.py',
 'strategy':ROOT/'strategy_worker_v2.114.py',
}
BUILD='fixed_shadow_answer_sheet_and_separate_mainline_replay_2026-08-02'

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def candles(event_ts,interval,n,start,growth):
    rows=[]
    for i in range(n):
        c=start+growth*i
        rows.append({'ts':event_ts-interval*(n-i+1),'o':c-.2,'h':c+.8,'l':c-.8,'c':c,'v':1000+i*10})
    return rows

def main():
    results=[]
    for label in ('review','main'):
        path=FILES[label]
        subprocess.run([sys.executable,'-m','py_compile',str(path)],check=True)
        ast.parse(path.read_text(encoding='utf-8'))
        results.append(f'{label}:COMPILE_AST_PASS')

    tmp=Path(tempfile.mkdtemp(prefix='v2396_review_'))
    try:
        shutil.copy2(FILES['core'],tmp/'strategy_v2_core.py')
        os.environ['TRADING_BOT_DIR']=str(tmp)
        review=load('review_v2396_test',FILES['review'])
        assert review.VERSION=='review_worker_v2.165' and review.BUILD_LABEL==BUILD
        event_ts=2_000_000.0
        review._EVENTS={
          'rise':{'event_key':'rise','prediction_contract_id':'PRE_STRUCTURE_12','prediction_selection':'DOWN','event_ts':event_ts,'event_price':120.0,'ticker':'AAA','materials':{},'explanation_tags':['RESTART'],'price_volume_sequence':{'state':'VOLUME_LEADS'}},
          'flat':{'event_key':'flat','prediction_contract_id':'PRE_STRUCTURE_12','prediction_selection':'UP','event_ts':event_ts,'event_price':120.0,'ticker':'AAA','materials':{},'explanation_tags':[],'price_volume_sequence':{'state':'UNKNOWN'}},
        }
        review._OUTCOME_ROWS={
          ('rise','3h'):{'event_key':'rise','horizon':'3h','outcome_state':'READY','mfe_pct':2.0,'mae_pct':-.4,'giveback_pct':.5,'final_return_pct':1.5,'scoring_cost_pct':.2,'scored_net_return_pct':1.3,'target_first':True,'invalid_first':False,'touch_order':'TARGET_FIRST'},
          ('flat','3h'):{'event_key':'flat','horizon':'3h','outcome_state':'READY','mfe_pct':.1,'mae_pct':-.5,'giveback_pct':.4,'final_return_pct':-.3,'scoring_cost_pct':.2,'scored_net_return_pct':-.5,'target_first':False,'invalid_first':True,'touch_order':'INVALID_FIRST'},
        }
        answer=review.build_shadow_answer_sheet()
        assert answer['state']=='READY' and answer['strategy_formula_used'] is False
        assert answer['horizons']['3h']['answer_count']==2
        assert answer['horizons']['3h']['rise_opportunity_count']==1
        original_loader=review._load_active_strategy_core
        review._load_active_strategy_core=lambda: (_ for _ in ()).throw(RuntimeError('SHADOW_MUST_NOT_CALL_STRATEGY'))
        assert review.build_shadow_answer_sheet()['state']=='READY'
        review._load_active_strategy_core=original_loader
        results.append('review:FIXED_ANSWER_INDEPENDENT_OF_STRATEGY_PASS')

        idx={
          'AAA':{'h1':candles(event_ts,3600,20,100,1.0),'h4':candles(event_ts,14400,12,90,2.0),'d1':candles(event_ts,86400,10,70,4.0)},
          'BTC':{'h1':candles(event_ts,3600,20,100,.3),'h4':candles(event_ts,14400,12,90,.5),'d1':candles(event_ts,86400,10,70,1.0)},
        }
        comp=review.build_timeframe_role_replay_comparison(idx)
        assert comp['state']=='READY'
        assert comp['shadow_answer_uses_strategy_formula'] is False
        assert comp['replay_uses_active_strategy_formula'] is True
        assert comp['future_candle_used'] is False and comp['synthetic_3h_6h_candle_used'] is False
        assert comp['historical_event_rows_rewritten'] is False and comp['historical_outcome_rows_rewritten'] is False
        assert comp['horizons']['3h']['paired_count']==2
        results.append('review:MAINLINE_REPLAY_VS_FIXED_ANSWER_PASS')
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
        os.environ.pop('TRADING_BOT_DIR',None)

    # Review run_once canonical with no events must still publish both separated contracts.
    tmp=Path(tempfile.mkdtemp(prefix='v2396_review_runtime_'))
    try:
        shutil.copy2(FILES['core'],tmp/'strategy_v2_core.py')
        env=dict(os.environ); env['TRADING_BOT_DIR']=str(tmp)
        code=f"""
import importlib.util
p={str(FILES['review'])!r}
spec=importlib.util.spec_from_file_location('r',p); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
s=m.run_once(); c=s['rise_prediction_canonical']
assert s['version']=='review_worker_v2.165' and s['build']=={BUILD!r}
assert c['shadow_answer_sheet']['state']=='WAITING'
assert c['shadow_answer_sheet']['strategy_formula_used'] is False
assert c['timeframe_role_replay_comparison']['state']=='NO_BASELINE_EVENTS'
assert c['timeframe_role_replay_comparison']['shadow_answer_uses_strategy_formula'] is False
assert c['new_shadow_created'] is False
print('PASS')
"""
        out=subprocess.check_output([sys.executable,'-c',code],env=env,text=True).strip(); assert out.endswith('PASS')
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
    results.append('review:RUN_ONCE_SEPARATED_CANONICAL_PASS')

    # Main rendering and append-only ledger seed.
    tmp=Path(tempfile.mkdtemp(prefix='v2396_main_'))
    try:
        main_copy=tmp/FILES['main'].name; shutil.copy2(FILES['main'],main_copy)
        mainmod=load('main_v2396_test',main_copy)
        assert mainmod.MAIN_VERSION=='수익형 v2.13.2241' and mainmod.BUILD==BUILD
        canonical={
          'shadow_answer_sheet':answer,
          'timeframe_role_replay_comparison':comp,
          'current_prediction_contract_directional_scoring':{},
          'live_prediction_model_id':'OFFICIAL_1H_TIMING_4H_STRUCTURE_24H_CONTEXT_V1',
        }
        text='\n'.join(mainmod._shadow_answer_sheet_lines(canonical)+['']+mainmod._mainline_replay_compare_lines(canonical))
        for token in ('Shadow 정답지 · 실제 경과 고정','새 본선 과거 대입 · Shadow 정답 비교','Strategy 공식 사용 0','본선 재실행에만 공식 사용 1'):
            assert token in text
        assert (tmp/'runtime'/'main_shadow_answer_sheet_v2396.seeded').exists()
        ledger=(tmp/'ledger'/'change_verify_ledger_events.jsonl').read_text(encoding='utf-8')
        assert 'Shadow 고정 정답지와 본선 과거대입 비교 분리' in ledger
    finally:
        shutil.rmtree(tmp,ignore_errors=True)
    results.append('main:SEPARATE_ANSWER_AND_REPLAY_BOARD_PASS')

    # v2396 changes Review/Main only. Active 1h/4h/24h Strategy and all other services are byte-identical to applied v2395.
    for name in ('strategy_v2_core.py','strategy_v2_core_v2200.py','strategy_worker.py','strategy_worker_v2.114.py','candle_worker.py','paper_bot.py','backga_guard_bot.py'):
        assert sha(ROOT/name)==sha(BASE/name), name
    results.append('unchanged:STRATEGY_CANDLE_PAPER_GUARD_HASH_PASS')

    print('\n'.join(results))
    print('ALL_LOCAL_TESTS_PASS')

if __name__=='__main__': main()
