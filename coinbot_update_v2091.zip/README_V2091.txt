코인봇 v2091 · 최종 후보 저장 뒤 구조자료 재요청 연결

현재 확인된 문제
- v2090 Strategy v2.028은 서버에서 실행됐지만 최종 구조자료 누락 51개와 full-profile 요청 0개가 동시에 남았다.
- v2090은 최종 candidate SOURCE_MISSING 봉인 전에 요청을 만들었고, 기존 v914 소비계약과 다른 bucket 이름을 사용했다.

수정
- 최종 candidate snapshot의 atomic 저장이 성공한 직후 같은 최종 row를 읽는다.
- SOURCE_MISSING S1/S2는 core_structure_source_missing_v914, S3는 near_structure_source_missing_v914로 합친다.
- profile은 기존 candle_worker 계약인 structure_full_htf_mtf_ltf를 그대로 사용한다.
- 기존 urgent 요청은 보존하고 얕은 요청만 full-profile로 업그레이드한다.
- 이 필수 요청 저장이 실패하면 해당 Strategy cycle을 정상 완료로 표시하지 않는다.
- 자료가 들어오면 기존 row 수정·강제승격 없이 새 candidate 사건으로 재평가한다.

변경하지 않음
- trigger/invalid/target 및 구조선 공식
- 후보 수·등급·rank
- 기존 OPEN과 청산계약
- v2086·v2089
- 원장
- 자동매수 OFF

판정
- 로컬 py_compile·post-commit 순서·v914 bucket/profile synthetic 검수 PASS
- 서버 적용·Candle 소비 증명 전 CHECK
