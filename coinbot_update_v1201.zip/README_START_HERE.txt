코인봇 v1201 Paper 반복 압축 수리 적용 ZIP

- 변경: Paper v1.052 -> v1.053
- 원인: compact schema가 후보 원본 schema에 덮여 매 cycle OPEN 전체를 재압축함
- 수정: compact 예약필드 마지막 봉인 + 기존 잘못된 row marker-only 1회 복구
- 변경 안 함: 후보/OPEN/cycle 개수 제한, trigger/invalid/target/RR, 청산계약
- 자동매수: OFF
- 상태: 로컬 PASS / 서버 적용 전 CHECK
