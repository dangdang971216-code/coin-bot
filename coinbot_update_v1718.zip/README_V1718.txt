v1718 S1 synthesis root map / all upflow cause. Diagnostic only. Auto-buy OFF.
