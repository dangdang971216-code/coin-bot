from __future__ import annotations
import fcntl, importlib.util, json, os, signal, subprocess, sys, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

# Strategy lock/status contract
strategy=load('strategy_v1182_test',ROOT/'strategy_worker_v1.037.py')
with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    strategy.STRATEGY_SINGLETON_LOCK_V1182=base/'runtime'/'strategy_worker_singleton_v1110.lock'
    strategy.STRATEGY_SINGLETON_STATUS_V1182=base/'clean_strategy_singleton_status_v1111.json'
    strategy._acquire_strategy_singleton_v1182()
    status=json.loads(strategy.STRATEGY_SINGLETON_STATUS_V1182.read_text())
    assert status['pid']==os.getpid()
    assert status['version']=='strategy_worker_v1.037'
    assert status['lock_held'] is True
    probe=strategy.STRATEGY_SINGLETON_LOCK_V1182.open('a+')
    blocked=False
    try:
        fcntl.flock(probe.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:
        blocked=True
    finally:
        probe.close()
    assert blocked
    strategy._release_strategy_singleton_v1182()

# Review process status/lock contract
with tempfile.TemporaryDirectory() as td:
    base=Path(td)
    env=os.environ.copy(); env['PYTHONPATH']=str(ROOT)
    proc=subprocess.Popen([sys.executable,str(ROOT/'review_worker_v1.013.py'),'--base-dir',str(base),'--interval','0.5'],env=env)
    try:
        deadline=time.time()+12
        status_path=base/'clean_review_worker_status.json'
        lock_path=base/'runtime'/'review_worker_singleton_v1121.lock'
        status={}
        while time.time()<deadline:
            if status_path.exists() and lock_path.exists():
                try:
                    status=json.loads(status_path.read_text())
                    payload=json.loads(lock_path.read_text())
                    if status.get('state')=='running' and payload.get('version')=='review_worker_v1.013':
                        break
                except Exception:
                    pass
            time.sleep(.2)
        assert proc.poll() is None
        assert status.get('state')=='running', status
        assert status.get('legacy_dedup_index_retired') is True
        payload=json.loads(lock_path.read_text())
        assert payload['pid']==proc.pid
        assert payload['version']=='review_worker_v1.013'
        probe=lock_path.open('a+')
        blocked=False
        try:
            fcntl.flock(probe.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            blocked=True
        finally:
            probe.close()
        assert blocked
    finally:
        proc.send_signal(signal.SIGTERM)
        proc.wait(timeout=8)

# Guard source keeps strict locks while accepting zero retired SQLite writer.
g=(ROOT/'backga_guard_bot_v2_5_196.py').read_text()
assert "review_dedup_retired_v1182" in g
assert "review_sqlite_writer_pids_v1123 == []" in g
assert "kernel_lock_v1123.get('ok')" in g
print('PASS v1182 release contract')
