코인봇 v1182 배포중단 원인수리

현재 상태
- v1181: Strategy v1.036만 적용된 PARTIAL
- v1182 LOCAL: PASS
- v1182 SERVER: CHECK_PENDING_DEPLOY
- 자동매수: OFF

실제 원인
1. Strategy 재구축에서 기존 singleton lock/status writer 누락
2. Review lock 경로·payload·state가 Guard 계약과 불일치
3. Guard가 Strategy fresh-boot 증명 실패로 안전하게 나머지 적용 중단

수정
- Strategy v1.037 canonical flock/status 복구
- Review v1.013 canonical kernel lock + state=running
- Guard v2.5.196은 Review dedup SQLite 폐기 상태에서 writer 0개를 정상 계약으로 검증
- 전략·진입·청산·원장 변경 없음
