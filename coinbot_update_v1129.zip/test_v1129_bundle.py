#!/usr/bin/env python3
from __future__ import annotations
import json, pathlib, py_compile, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
GUARD=ROOT/'backga_guard_bot_v2_5_174.py'
TESTS=(
 'test_guard_profitability_export_v1129.py',
 'test_guard_profitability_export_split_v1129.py',
 'test_guard_export_command_v1129.py',
 'test_guard_send_document_v1129.py',
)
FORBIDDEN=(
 'paper_bot_open.json','paper_bot_closed.jsonl','paper_bot_trade_log.jsonl',
 'paper_decision_state_v926.json','canonical_performance_snapshot_v987.json',
 'change_verify_ledger.jsonl','issue_ledger.jsonl','trade_log.json','decision_ledger.jsonl'
)
def main():
    py_compile.compile(str(GUARD),doraise=True)
    manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
    assert manifest['version']=='v1129'
    assert manifest['guard']==GUARD.name
    assert not manifest.get('main') and not manifest.get('paper') and not manifest.get('workers')
    assert manifest['strategy_mode']=='ALT_SWING' and manifest['auto_buy'] is False
    assert manifest['live_ledger_included'] is False
    for flag in ('strategy_contract_change','quality_threshold_change','quality_formula_change','rank_formula_change','slippage_contract_change','open_limit_change','cycle_limit_change','exit_contract_change','performance_formula_change','protected_ledger_source_change'):
        assert manifest[flag] is False,flag
    names=[p.name for p in ROOT.rglob('*') if p.is_file()]
    assert not any(name in names for name in FORBIDDEN), sorted(set(names)&set(FORBIDDEN))
    source=GUARD.read_text(encoding='utf-8')
    required=(
      'guard_v2.5.174_profitability_export_v1129_2026-06-29',
      'PROFITABILITY_EXPORT_FILES_V1129',
      'paper_bot_closed.jsonl','paper_bot_open.json','paper_decision_state_v926.json',
      'canonical_performance_snapshot_v987.json','paper_bot_trade_log.jsonl','paper_bot_control.json',
      'gexport_profitability_text_v1129','telegram_send_document_v1129',
      'PREFIX_SNAPSHOT_SOURCE_GREW','original_files_modified',
      'GUARD-PROFITABILITY-EXPORT-1129','change_suffix = "server-proof"','v1129-guard-profitability-export-{change_suffix}-001',
    )
    for value in required: assert value in source,value
    assert source.count('{"command": "gexport_profitability"')==1
    outputs={}
    for test in TESTS:
        proc=subprocess.run([sys.executable,str(ROOT/test)],capture_output=True,text=True,check=True)
        outputs[test]=proc.stdout.strip()
    result={
      'ok':True,
      'compile':'PASS',
      'guard_version':'v2.5.174',
      'fixed_allowlist':6,
      'read_only_source_contract':'PASS',
      'manifest_sha256_contract':'PASS',
      'jsonl_complete_tail':'PASS',
      'telegram_streaming':'PASS',
      'automatic_split':'PASS',
      'temporary_cleanup':'PASS',
      'change_id_dedup':'PASS',
      'strategy_contract':'UNCHANGED',
      'paper_contract':'UNCHANGED',
      'open_limit':'30_UNCHANGED',
      'cycle_limit':'3_UNCHANGED',
      'auto_buy':'OFF',
      'tests':outputs,
    }
    print(json.dumps(result,ensure_ascii=False,sort_keys=True))
if __name__=='__main__':main()
