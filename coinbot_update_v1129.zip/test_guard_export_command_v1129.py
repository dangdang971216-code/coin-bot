#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, pathlib, tempfile
SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_174.py')

def main():
    with tempfile.TemporaryDirectory() as td:
        os.environ.update(GUARD_BOT_TOKEN='dummy',GUARD_CHAT_ID='123',BOT_DIR=td)
        spec=importlib.util.spec_from_file_location('guard_cmd',SOURCE)
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        mod.gexport_profitability_text_v1129=lambda:'EXPORT_SENTINEL'
        assert mod.handle_single_command('/gexport_profitability')=='EXPORT_SENTINEL'
        assert mod.handle_single_command('/gprofitability_export')=='EXPORT_SENTINEL'
        menu=mod.guard_command_menu_items()
        matches=[x for x in menu if x.get('command')=='gexport_profitability']
        assert len(matches)==1,matches
        help_text=mod.help_text()
        assert '/gexport_profitability' in help_text
        print(json.dumps({'ok':True,'dispatch':True,'aliases':True,'menu_once':True,'help':True},sort_keys=True))
if __name__=='__main__':main()
