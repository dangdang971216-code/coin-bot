# v1129 Guard profitability export

## Locked symptom
The profitability audit needs protected Paper OPEN/CLOSED/decision/performance files, but the user cannot retrieve server files without a terminal or SFTP workflow.

## Actual owner
- caller: Guard Telegram command dispatcher
- command: `/gexport_profitability`
- snapshot owner: `gexport_profitability_text_v1129`
- transport owner: `telegram_send_document_v1129`
- result owner: `guard_profitability_export_last_result_v1129.json`

## Fixed allowlist
- `paper_bot_closed.jsonl`
- `paper_bot_open.json`
- `paper_decision_state_v926.json`
- `canonical_performance_snapshot_v987.json`
- `paper_bot_trade_log.jsonl`
- `paper_bot_control.json`

No user-supplied path is accepted.

## Read-only contract
- Each source is opened read-only and copied only up to the size observed at snapshot start.
- JSONL snapshot copies end on a complete newline when possible.
- Source inode/size/mtime before and after copy are recorded.
- Snapshot SHA256, size, missing files and source-change state are stored in `EXPORT_MANIFEST.json`.
- OPEN/CLOSED/trade_log/decision/performance source files are never rewritten, truncated, renamed or deleted.
- Temporary snapshot and ZIP files are removed after delivery.

## Delivery contract
- ZIPs are streamed to Telegram without loading the archive into Guard memory.
- A 45 MiB document safety cap is used.
- Large source files are split into ordered independent ZIP parts.
- Every ZIP includes the full export manifest and its own part manifest.
- Retry count is bounded to three per part.

## Change and issue ledger
The first server execution appends one lifecycle result for `GUARD-PROFITABILITY-EXPORT-1129` and one unique change verification row. Repeated exports do not duplicate the change ID.

## Unchanged
- Strategy, candidate Gate and rank
- trigger, invalid and target formulas
- Paper entry and exit code
- OPEN limit 30 and cycle limit 3
- protected source ledgers
- automatic buying remains OFF

## Server DONE proof
1. Guard runtime is `guard_v2.5.174_profitability_export_v1129_2026-06-29`.
2. `/gexport_profitability` sends one or more ZIPs.
3. Manifest lists the six approved files with SHA256 or MISSING.
4. Export result says original mutation 0 and temporary cleanup.
5. Uploaded ZIP can be opened and used for the profitability audit.
