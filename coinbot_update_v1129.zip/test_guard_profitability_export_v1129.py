#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, os, pathlib, shutil, tempfile, zipfile

SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_174.py')

def sha(path):
    h=hashlib.sha256(); h.update(path.read_bytes()); return h.hexdigest()

def main():
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td)
        bot=root/'bot'; bot.mkdir()
        received=root/'received'; received.mkdir()
        files={
            'paper_bot_closed.jsonl': b'{"id":1,"pnl":1.2}\n{"id":2,"pnl":-3.0}\n{"partial":',
            'paper_bot_open.json': json.dumps({'positions':[{'ticker':'AAA','invalid':98,'target':102}]}).encode(),
            'paper_decision_state_v926.json': json.dumps({'rows':[]}).encode(),
            'canonical_performance_snapshot_v987.json': json.dumps({'closed_count':2}).encode(),
            'paper_bot_trade_log.jsonl': b'{"event":"open"}\n{"event":"close"}\n',
            'paper_bot_control.json': json.dumps({'auto_buy':False,'max_open':30}).encode(),
        }
        for name,data in files.items():
            (bot/name).write_bytes(data)
        before={name:(sha(bot/name),(bot/name).stat().st_size,(bot/name).stat().st_mtime_ns) for name in files}
        os.environ['GUARD_BOT_TOKEN']='dummy'
        os.environ['GUARD_CHAT_ID']='123'
        os.environ['BOT_DIR']=str(bot)
        spec=importlib.util.spec_from_file_location('guard_v1129',SOURCE)
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        sent=[]
        def fake_send(chat_id,path,caption=''):
            target=received/path.name
            shutil.copy2(path,target)
            sent.append((str(chat_id),target,caption))
            return True,'MOCK_OK'
        mod.telegram_send_document_v1129=fake_send
        mod.progress_notify=lambda text: None
        text=mod.gexport_profitability_text_v1129()
        assert 'DONE' in text,text
        assert sent, 'no archive sent'
        after={name:(sha(bot/name),(bot/name).stat().st_size,(bot/name).stat().st_mtime_ns) for name in files}
        assert before==after,(before,after)
        assert not list(bot.glob(mod.GUARD_EXPORT_TMP_PREFIX_V1129+'*'))
        result=json.loads((bot/mod.GUARD_EXPORT_LAST_RESULT_V1129).read_text())
        assert result['status']=='DONE',result
        assert result['original_files_modified'] is False
        archive=sent[0][1]
        with zipfile.ZipFile(archive) as z:
            names=set(z.namelist())
            assert 'EXPORT_MANIFEST.json' in names
            assert 'PART_MANIFEST.json' in names
            manifest=json.loads(z.read('EXPORT_MANIFEST.json'))
            assert manifest['command']=='/gexport_profitability'
            assert manifest['original_files_modified'] is False
            closed_name=next(x for x in names if x.endswith('paper_bot_closed.jsonl'))
            closed=z.read(closed_name)
            assert closed.endswith(b'\n')
            assert b'partial' not in closed
            row=next(x for x in manifest['files'] if x['name']=='paper_bot_closed.jsonl')
            assert row['tail_trimmed_bytes']>0
            assert len(row['sha256'])==64
        issue=(bot/'issue_ledger.jsonl').read_text()
        change=(bot/'change_verify_ledger.jsonl').read_text()
        assert 'GUARD-PROFITABILITY-EXPORT-1129' in issue
        assert 'v1129-guard-profitability-export-server-proof-001' in change
        change_lines_before=len([x for x in change.splitlines() if x.strip()])
        second=mod.gexport_profitability_text_v1129()
        assert 'DONE' in second,second
        change2=(bot/'change_verify_ledger.jsonl').read_text()
        change_lines_after=len([x for x in change2.splitlines() if x.strip()])
        assert change_lines_after==change_lines_before,(change_lines_before,change_lines_after)
        print(json.dumps({'ok':True,'archives':len(sent),'result_status':result['status'],'original_hashes_unchanged':True,'temp_clean':True,'manifest':True,'jsonl_tail_trim':True,'ledger_append':True,'change_id_not_duplicated':True},sort_keys=True))

if __name__=='__main__': main()
