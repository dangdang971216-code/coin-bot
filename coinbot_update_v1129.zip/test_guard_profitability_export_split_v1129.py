#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, pathlib, shutil, tempfile, zipfile
SOURCE=pathlib.Path(__file__).with_name('backga_guard_bot_v2_5_174.py')

def main():
    with tempfile.TemporaryDirectory() as td:
        root=pathlib.Path(td); bot=root/'bot'; bot.mkdir(); recv=root/'recv'; recv.mkdir()
        line=(json.dumps({'ticker':'AAA','payload':'x'*900})+'\n').encode()
        (bot/'paper_bot_closed.jsonl').write_bytes(line*3500)
        for name,obj in {
            'paper_bot_open.json':{},
            'paper_decision_state_v926.json':{},
            'canonical_performance_snapshot_v987.json':{},
            'paper_bot_trade_log.jsonl':{},
            'paper_bot_control.json':{'auto_buy':False},
        }.items():
            if name.endswith('.jsonl'):
                (bot/name).write_text(json.dumps(obj)+'\n')
            else:
                (bot/name).write_text(json.dumps(obj))
        os.environ.update(GUARD_BOT_TOKEN='dummy',GUARD_CHAT_ID='123',BOT_DIR=str(bot))
        spec=importlib.util.spec_from_file_location('guard_split',SOURCE)
        mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        mod.GUARD_EXPORT_PART_PAYLOAD_BYTES_V1129=1024*1024
        mod.GUARD_EXPORT_MAX_DOCUMENT_BYTES_V1129=2*1024*1024
        sent=[]
        def fake(chat,path,caption=''):
            dst=recv/path.name; shutil.copy2(path,dst); sent.append(dst); return True,'OK'
        mod.telegram_send_document_v1129=fake
        mod.progress_notify=lambda text:None
        text=mod.gexport_profitability_text_v1129()
        assert 'DONE' in text,text
        assert len(sent)>=3,len(sent)
        all_part_names=[]
        for path in sent:
            assert path.stat().st_size<=mod.GUARD_EXPORT_MAX_DOCUMENT_BYTES_V1129
            with zipfile.ZipFile(path) as z:
                assert 'EXPORT_MANIFEST.json' in z.namelist()
                pm=json.loads(z.read('PART_MANIFEST.json'))
                all_part_names += [x['archive_name'] for x in pm['items']]
        closed_parts=[x for x in all_part_names if 'paper_bot_closed.part' in x]
        assert len(closed_parts)>=3,closed_parts
        assert closed_parts==sorted(closed_parts)
        print(json.dumps({'ok':True,'sent_parts':len(sent),'closed_chunks':len(closed_parts),'each_archive_independent':True},sort_keys=True))
if __name__=='__main__':main()
