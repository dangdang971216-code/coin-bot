v1449 CLOSED duplicate check fast index. Auto-buy OFF. No trading rule change. v1448 Paper exit-defense preserved.
