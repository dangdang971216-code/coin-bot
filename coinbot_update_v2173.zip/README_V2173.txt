v2173 root repair
- fast S1 survives the following full cycle
- first detect/S1 timestamps are immutable
- WAIT_TRIGGER uses existing Candle urgent refresh owner
- Scanner seed and final 1h status are separate
- Paper receipt is lightweight and immediate; OPEN/CLOSED writer remains single-threaded
- no strategy/candidate-quality/exit number changes
- auto-buy OFF
