from pathlib import Path

root = Path(__file__).resolve().parents[1]
main = (root / "coinbot_main_v2_13_1168.py").read_text(encoding="utf-8")
paper = (root / "paper_bot_v1.085.py").read_text(encoding="utf-8")
guard = (root / "backga_guard_bot_v2_5_266.py").read_text(encoding="utf-8")
assert "v1288 원인판" in main
assert "detail_v1288" in main
assert "V1288_VERSION_SCORE_SCHEMA" in paper
assert "trading_rules_changed" in paper
assert "gledger_v1288" in guard
print("v1288 static checks ok")
