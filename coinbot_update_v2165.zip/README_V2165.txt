v2165: actual exact book repair + whole-market 15m/30m/1h comparison + shared Paper snapshot. Strategy numbers unchanged. Auto-buy OFF.
