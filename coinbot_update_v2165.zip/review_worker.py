#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import atexit, fcntl, hashlib, json, math, os, resource, sys, time, traceback
from collections import deque
from collections import Counter
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

BASE_DIR=Path(os.getenv('TRADING_BOT_DIR','/home/dangdang971216/trading_bot'))
VERSION='review_worker_v2.063'
BUILD_LABEL='v2165_exact_market_compare_quality_ready_2026-07-22'
INTERVAL_SEC=max(5.0,float(os.getenv('REVIEW_WORKER_INTERVAL_SEC','30')))
STATUS=BASE_DIR/'clean_review_worker_status.json'
ERROR=BASE_DIR/'clean_review_worker_error.log'
PAPER_LATEST=BASE_DIR/'paper_candidates_latest.jsonl'
OPEN_PATH=BASE_DIR/'paper_v2_exact_open_v2135.json'
CLOSED_PATH=BASE_DIR/'paper_v2_exact_closed_v2135.jsonl'
OUTCOME_STATE=BASE_DIR/'strategy_v2_outcome_state_v2133.json'
OUTCOME_STATUS=BASE_DIR/'strategy_v2_outcome_status_v2133.json'
OUTCOME_LEDGER=BASE_DIR/'strategy_v2_outcomes_v2133.jsonl'
CHANGE_LEDGER=BASE_DIR/'runtime'/'change_verify_ledger.jsonl'
ISSUE_LEDGER=BASE_DIR/'ledger'/'issue_ledger_events.jsonl'
LOCK_PATH=BASE_DIR/'runtime'/'review_worker_singleton_v1121.lock'
GENERATION='ALT_SWING_V2_COMBINED_V2149_RESET_20260722'
STATE_KEY='v2149_rows'
HORIZONS=(('5m',300.0),('15m',900.0),('30m',1800.0),('1h',3600.0),('3h',10800.0),('6h',21600.0))
SHADOW_WRITERS_REMOVED=(
    'trigger_shadow_v665','quality_shadow_v1125','smart_structure_shadow_v948',
    'unified_shadow_v2010','entry_survival_shadow_v2014','top10_shadow_v2015_v2019',
    'c_break_retest_performance_shadow','open_limit_shadow'
)
_LOCK_FH=None


def now_ts()->float:return time.time()
def now_text(ts:Optional[float]=None)->str:
    return time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(ts or now_ts()))

def _atomic_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+f'.tmp.{os.getpid()}')
    tmp.write_text(json.dumps(obj,ensure_ascii=False,separators=(',',':')),encoding='utf-8')
    os.replace(tmp,path)

def load_json(path:Path,default:Any)->Any:
    try:return json.loads(path.read_text(encoding='utf-8'))
    except Exception:return default

def read_jsonl(path:Path,max_lines:int=10000)->List[Dict[str,Any]]:
    if not path.exists():return []
    try:
        with path.open('r',encoding='utf-8',errors='ignore') as f:
            lines=deque(f,maxlen=max_lines)
    except Exception:return []
    out=[]
    for line in lines:
        try:
            row=json.loads(line)
            if isinstance(row,dict):out.append(row)
        except Exception:pass
    return out

def append_jsonl(path:Path,row:Dict[str,Any])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('a',encoding='utf-8') as f:
        f.write(json.dumps(row,ensure_ascii=False,separators=(',',':'))+'\n')
        f.flush();os.fsync(f.fileno())

def append_error(where:str,exc:BaseException)->None:
    ERROR.parent.mkdir(parents=True,exist_ok=True)
    with ERROR.open('a',encoding='utf-8') as f:
        f.write(f'[{now_text()}] {where}: {type(exc).__name__}: {exc}\n')
        f.write(traceback.format_exc()+'\n')

def num(v:Any,default:Optional[float]=None)->Optional[float]:
    try:
        if v in (None,'') or isinstance(v,bool):return default
        x=float(v);return x if math.isfinite(x) else default
    except Exception:return default

def ticker(v:Any)->str:
    s=str(v or '').upper().strip().replace('KRW-','').replace('_KRW','').replace('/KRW','')
    return s

def contract_of(row:Dict[str,Any])->Dict[str,Any]:
    c=row.get('trade_path_contract_v2149')
    return c if isinstance(c,dict) and str(c.get('generation') or '')==GENERATION else {}

def open_contract(row:Dict[str,Any])->Dict[str,Any]:
    c=row.get('trade_path_contract_v2149_at_open')
    return c if isinstance(c,dict) else {}

def row_price(row:Dict[str,Any])->Optional[float]:
    for k in ('current_price','price','last_price','close','trade_price','market_price'):
        x=num(row.get(k))
        if x and x>0:return x
    c=contract_of(row);s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    x=num(s.get('current_price'))
    return x if x and x>0 else None

def exact_decision_keys(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->List[str]:
    c=contract if isinstance(contract,dict) else {}
    vals=(
        c.get('decision_key'),row.get('direct_decision_key_v2149'),row.get('direct_decision_key'),
        row.get('paper_decision_key_v926'),row.get('swing_gate_decision_key_v977'),
        row.get('source_decision_key'),row.get('decision_key'),
    )
    out=[]
    for v in vals:
        s=str(v or '').strip()
        if s and s not in out:out.append(s)
    return out

def plan_from_decision(decision:str)->str:
    # v2149:<ticker>:<plan_hash>:<trigger_event_ms>
    parts=str(decision or '').split(':')
    return 'v2149-plan:'+parts[-2] if len(parts)>=4 and parts[0]=='v2149' and parts[-2] else ''

def stable_key(row:Dict[str,Any],c:Dict[str,Any])->str:
    t=ticker(row.get('ticker') or c.get('ticker'))
    s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    inv=num(s.get('execution_invalid'));t1=num(s.get('target_t1'))
    if not t or not inv or not t1 or not t1>inv:return ''
    seed=json.dumps({'ticker':t,'invalid':round(inv,10),'target_t1':round(t1,10)},sort_keys=True,separators=(',',':'))
    return f'{GENERATION}|{t}|v2154-structure:{hashlib.sha256(seed.encode()).hexdigest()[:20]}'

def outcome(rec:Dict[str,Any])->str:
    a=num(rec.get('first_t1_ts'));b=num(rec.get('first_invalid_ts'))
    if a and b:
        if a==b:return 'AMBIGUOUS_SAME_SNAPSHOT'
        return 'T1_FIRST' if a<b else 'INVALID_FIRST'
    if a:return 'T1_FIRST'
    if b:return 'INVALID_FIRST'
    return 'NO_TOUCH'

def touch_order(up:Optional[float],down:Optional[float])->str:
    if up and down:
        if up==down:return 'AMBIGUOUS'
        return 'UP_FIRST' if up<down else 'DOWN_FIRST'
    if up:return 'UP_FIRST'
    if down:return 'DOWN_FIRST'
    return 'NO_TOUCH'

def group_scores(c:Dict[str,Any])->Dict[str,Any]:
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    e=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else (p.get('evidence') if isinstance(p.get('evidence'),dict) else {})
    g=e.get('groups') if isinstance(e.get('groups'),dict) else {}
    def gs(name:str):
        v=g.get(name);return num(v.get('score')) if isinstance(v,dict) else None
    return {
        'continuation_score':num(p.get('continuation_score')),
        'participation_score':gs('participation'),
        'trigger_flow_score':gs('trigger_flow'),
        'structure_context_score_v2155':gs('structure_context'),
        'market_context_score_v2155':gs('market_context'),
        'continuation_lower_bound':num(p.get('continuation_lower_bound')),
        'model_confidence_pct':num(p.get('model_confidence_pct')),
    }

def create_record(row:Dict[str,Any],c:Dict[str,Any],price:float,nowv:float,key:str)->Dict[str,Any]:
    s=c.get('structure') if isinstance(c.get('structure'),dict) else {}
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    comb=c.get('decision_combiner') if isinstance(c.get('decision_combiner'),dict) else {}
    scores=group_scores(c)
    rec={
        'schema':'strategy_v2_outcome_state_row_v2163','generation':GENERATION,'event_key':key,
        'plan_key':c.get('plan_key'),'decision_key':None,'decision_keys_exact_v2163':[],
        'ticker':ticker(row.get('ticker') or c.get('ticker')),'start_ts':nowv,'start_text':now_text(nowv),
        'last_seen_ts':nowv,'reference_entry':num(s.get('reference_entry'),price),
        'execution_invalid':num(s.get('execution_invalid')),'target_t1':num(s.get('target_t1')),'target_t2':num(s.get('target_t2')),
        'geometry_state':'READY' if (num(s.get('execution_invalid'),0)<num(s.get('reference_entry'),price)<num(s.get('target_t1'),0)) else str(s.get('state') or ''),
        'contract_state':c.get('state'),'structure_state':s.get('state'),'prediction_state':p.get('state'),
        'combiner_state':comb.get('state') or c.get('state'),'combiner_eligible':comb.get('entry_eligible') is True,
        'prediction_model_generation':c.get('prediction_model_generation') or p.get('prediction_model_generation'),
        'probability_is_calibrated':p.get('probability_is_calibrated') is True,
        'max_pct':0.0,'min_pct':0.0,'samples':{},'practical_samples_v2163':{},
        'practical_tracking_started_ts_v2163':nowv,'first_up_pct_ts_v2163':{},'first_down_pct_ts_v2163':{},
        'final_appended':False,'actual_trade_exact_v2163':False,'auto_buy':False,
    }
    rec.update(scores)
    return rec

def update_identity(rec:Dict[str,Any],row:Dict[str,Any],c:Dict[str,Any],nowv:float)->None:
    keys=list(rec.get('decision_keys_exact_v2163') or [])
    for k in exact_decision_keys(row,c):
        if k not in keys:keys.append(k)
    rec['decision_keys_exact_v2163']=keys
    if keys:
        rec['decision_key']=keys[0];rec['decision_link_state_v2163']='DIRECT_DECISION_KEY_READY'
        if not isinstance(rec.get('decision_snapshot_v2163'),dict):
            snap={'captured_ts':nowv,'captured_text':now_text(nowv),'contract_state':c.get('state')}
            snap.update(group_scores(c));rec['decision_snapshot_v2163']=snap
    # Current lifecycle state can change; sealed initial scores above are never overwritten.
    comb=c.get('decision_combiner') if isinstance(c.get('decision_combiner'),dict) else {}
    rec['last_contract_state_v2163']=c.get('state');rec['last_combiner_state_v2163']=comb.get('state') or c.get('state')
    rec['last_combiner_eligible_v2163']=comb.get('entry_eligible') is True

def update_path(rec:Dict[str,Any],price:float,nowv:float)->None:
    entry=num(rec.get('reference_entry'))
    if not entry or entry<=0:return
    pct=(price/entry-1.0)*100.0
    rec['last_seen_ts']=nowv;rec['last_seen_text']=now_text(nowv);rec['last_price']=price
    rec['max_pct']=max(num(rec.get('max_pct'),pct) or pct,pct);rec['min_pct']=min(num(rec.get('min_pct'),pct) or pct,pct)
    t1=num(rec.get('target_t1'));inv=num(rec.get('execution_invalid'));t2=num(rec.get('target_t2'))
    if t1 and price>=t1 and not rec.get('first_t1_ts'):rec['first_t1_ts']=nowv
    if inv and price<=inv and not rec.get('first_invalid_ts'):rec['first_invalid_ts']=nowv
    if t2 and price>=t2 and not rec.get('first_t2_ts'):rec['first_t2_ts']=nowv
    ups=rec.setdefault('first_up_pct_ts_v2163',{});downs=rec.setdefault('first_down_pct_ts_v2163',{})
    for threshold in (1,2,3):
        k=str(threshold)
        if pct>=threshold and not ups.get(k):ups[k]=nowv
        if pct<=-threshold and not downs.get(k):downs[k]=nowv
    elapsed=max(0.0,nowv-num(rec.get('start_ts'),nowv))
    samples=rec.setdefault('samples',{})
    for label,sec in HORIZONS:
        if label in samples:continue
        # Do not fabricate a missed historical horizon. Allow at most two normal cycles of lateness.
        if elapsed>=sec and elapsed<=sec+max(90.0,INTERVAL_SEC*2.5):
            samples[label]={
                'pct':round(pct,6),'max_pct':round(num(rec.get('max_pct'),0) or 0,6),'min_pct':round(num(rec.get('min_pct'),0) or 0,6),
                'outcome_so_far':outcome(rec),'sampled_ts':nowv,'sampled_text':now_text(nowv),'sample_precision_v2163':'ON_TIME_CYCLE'
            }
        elif elapsed>sec+max(90.0,INTERVAL_SEC*2.5):
            rec.setdefault('missed_horizons_v2163',[])
            if label not in rec['missed_horizons_v2163']:rec['missed_horizons_v2163'].append(label)
    pstart=num(rec.get('practical_tracking_started_ts_v2163'),nowv) or nowv
    pelapsed=max(0.0,nowv-pstart);ps=rec.setdefault('practical_samples_v2163',{})
    for label,sec in HORIZONS:
        if label in ps or pelapsed<sec:continue
        ps[label]={
            'pct':round(pct,6),'max_pct':round(num(rec.get('max_pct'),0) or 0,6),'min_pct':round(num(rec.get('min_pct'),0) or 0,6),
            'up1_vs_down1':touch_order(num(ups.get('1')),num(downs.get('1'))),
            'up2_vs_down1':touch_order(num(ups.get('2')),num(downs.get('1'))),
            'up3_vs_down1':touch_order(num(ups.get('3')),num(downs.get('1'))),
            'up1_reached':bool(ups.get('1')),'up2_reached':bool(ups.get('2')),'up3_reached':bool(ups.get('3')),
            'down1_reached':bool(downs.get('1')),'sampled_ts':nowv,'sampled_text':now_text(nowv),
            'tracking_basis_v2163':'FORWARD_ONLY_FROM_V2163'
        }

def iter_open_rows()->List[Dict[str,Any]]:
    obj=load_json(OPEN_PATH,{})
    if isinstance(obj,list):return [x for x in obj if isinstance(x,dict)]
    if not isinstance(obj,dict):return []
    for k in ('open_positions','positions','rows','open'):
        v=obj.get(k)
        if isinstance(v,list):return [x for x in v if isinstance(x,dict)]
        if isinstance(v,dict):return [x for x in v.values() if isinstance(x,dict)]
    return [x for x in obj.values() if isinstance(x,dict)]

def actual_generation(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->str:
    c=contract if isinstance(contract,dict) else {}
    return str(row.get('paper_v2_generation') or c.get('generation') or '').strip()

def actual_model(row:Dict[str,Any],contract:Optional[Dict[str,Any]]=None)->str:
    c=contract if isinstance(contract,dict) else {}
    p=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
    return str(c.get('prediction_model_generation') or p.get('prediction_model_generation') or row.get('prediction_model_generation') or '').strip()

def attach_actual_trades(records:Dict[str,Dict[str,Any]],nowv:float)->Dict[str,int]:
    open_rows=iter_open_rows()
    closed_rows=read_jsonl(CLOSED_PATH,2000)
    actual_rows=[(x,'OPEN') for x in open_rows]+[(x,'CLOSED') for x in closed_rows]
    by_decision:Dict[str,Dict[str,Any]]={}
    by_plan:Dict[str,List[Dict[str,Any]]]={}
    for rec in records.values():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        for k in rec.get('decision_keys_exact_v2163') or []:by_decision[str(k)]=rec
        p=str(rec.get('plan_key') or '')
        if p:by_plan.setdefault(p,[]).append(rec)
    total=linked=plan_derived=missing=created=0
    open_total=closed_total=0
    for row,kind in actual_rows:
        if not isinstance(row,dict):continue
        c=open_contract(row)
        if actual_generation(row,c)!=GENERATION:continue
        if actual_model(row,c)!='FULL_INPUT_V2161':continue
        total+=1
        if kind=='OPEN':open_total+=1
        else:closed_total+=1
        keys=exact_decision_keys(row,c)
        if not keys:
            missing+=1;continue
        rec=None;source='DIRECT_DECISION_KEY'
        for k in keys:
            if k in by_decision:rec=by_decision[k];break
        if rec is None:
            plans={str(c.get('plan_key') or '').strip(),str(c.get('candidate_plan_key') or '').strip()}
            plans.update(plan_from_decision(k) for k in keys if plan_from_decision(k));plans.discard('')
            matches=[]
            for plan in plans:matches.extend(by_plan.get(plan,[]))
            unique={id(x):x for x in matches}
            if len(unique)==1:
                rec=next(iter(unique.values()));source='SEALED_PLAN_KEY_EXACT';plan_derived+=1
        if rec is None and c:
            entry=num(row.get('entry_price') or row.get('open_price') or ((c.get('structure') or {}).get('reference_entry') if isinstance(c.get('structure'),dict) else None))
            if entry and entry>0:
                event='actual:'+hashlib.sha256(keys[0].encode()).hexdigest()[:24]
                rec=create_record(row,c,entry,nowv,event)
                opened=num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts'))
                rec['start_ts']=opened or nowv;rec['start_text']=now_text(rec['start_ts'])
                rec['reference_entry']=entry;rec['practical_tracking_started_ts_v2163']=nowv
                rec['actual_record_created_from_sealed_contract_v2165']=True
                records[event]=rec;created+=1;source='SEALED_EXACT_BOOK_CONTRACT'
                plan=str(c.get('plan_key') or '')
                if plan:rec['plan_key']=plan;by_plan.setdefault(plan,[]).append(rec)
        if rec is None:
            missing+=1;continue
        arr=list(rec.get('decision_keys_exact_v2163') or [])
        for k in keys:
            if k not in arr:arr.append(k)
            by_decision[k]=rec
        rec['decision_keys_exact_v2163']=arr;rec['decision_key']=arr[0]
        rec['actual_trade_exact_v2163']=True;rec['actual_link_source_v2163']=source
        rec['actual_trade_open_v2164']=kind=='OPEN';rec['actual_trade_closed_v2164']=kind=='CLOSED'
        pos=str(row.get('pos_id') or row.get('position_id') or '').strip()
        if pos:
            ids=list(rec.get('actual_pos_ids_v2163') or [])
            if pos not in ids:ids.append(pos)
            rec['actual_pos_ids_v2163']=ids
        if not isinstance(rec.get('actual_entry_snapshot_v2163'),dict):
            rec['actual_entry_snapshot_v2163']={
                'opened_at':num(row.get('paper_v2_exact_opened_ts') or row.get('opened_at') or row.get('open_ts') or row.get('entry_ts')),
                'entry_price':num(row.get('entry_price') or row.get('open_price')),
                'decision_key':arr[0],'pos_id':pos or None,'captured_ts':nowv,
                'sealed_contract_present':bool(c),'paper_v2_generation':actual_generation(row,c)
            }
        live=row_price(row)
        if live and live>0:update_path(rec,live,nowv)
        linked+=1
    return {
        'actual_exact_total':total,'actual_exact_linked':linked,'actual_plan_derived_exact':plan_derived,
        'actual_exact_missing':missing,'actual_created_from_sealed_contract_v2164':created,
        'actual_created_from_sealed_contract_v2165':created,'actual_exact_open_total_v2165':open_total,
        'actual_exact_closed_total_v2165':closed_total,'actual_exact_source_v2165':'paper_v2_exact_open/closed_v2135'
    }

def rss_mb()->float:
    try:
        for line in Path('/proc/self/status').read_text().splitlines():
            if line.startswith('VmRSS:'):return round(float(line.split()[1])/1024,2)
    except Exception:pass
    return 0.0

def run_once()->Dict[str,Any]:
    started=time.monotonic();nowv=now_ts();phase0=time.monotonic();source=[r for r in read_jsonl(PAPER_LATEST,1000) if str(r.get('strategy_generation_v2149') or '')==GENERATION];source_read_sec=round(time.monotonic()-phase0,4);phase1=time.monotonic()
    state=load_json(OUTCOME_STATE,{}) or {};state=dict(state) if isinstance(state,dict) else {}
    records=state.get(STATE_KEY) if isinstance(state.get(STATE_KEY),dict) else {}
    records={str(k):v for k,v in records.items() if isinstance(v,dict)}
    state_load_sec=round(time.monotonic()-phase1,4)
    new=0;current=0;model_counts=Counter();contract_counts=Counter();input_failures=Counter();connection_states=Counter()
    for row in source:
        c=contract_of(row);price=row_price(row);key=stable_key(row,c) if c else ''
        if not c or not key or not price or price<=0:continue
        current+=1;model=str(c.get('prediction_model_generation') or ((c.get('prediction') or {}).get('prediction_model_generation') if isinstance(c.get('prediction'),dict) else '') or 'UNKNOWN')
        model_counts[model]+=1;contract_counts[str(c.get('state') or 'UNKNOWN')]+=1
        pred=c.get('prediction') if isinstance(c.get('prediction'),dict) else {}
        evidence=c.get('prediction_evidence') if isinstance(c.get('prediction_evidence'),dict) else (pred.get('evidence') if isinstance(pred.get('evidence'),dict) else {})
        for failure in (evidence.get('required_input_failures_v2155') or pred.get('required_input_failures_v2155') or []):input_failures[str(failure)]+=1
        conns=evidence.get('input_connections_v2155') if isinstance(evidence.get('input_connections_v2155'),dict) else {}
        for meta in conns.values():
            if isinstance(meta,dict):connection_states[str(meta.get('state') or 'MISSING')]+=1
        rec=records.get(key)
        if not isinstance(rec,dict):rec=create_record(row,c,price,nowv,key);records[key]=rec;new+=1
        update_identity(rec,row,c,nowv);update_path(rec,price,nowv)
    phase2=time.monotonic();link=attach_actual_trades(records,nowv);actual_link_sec=round(time.monotonic()-phase2,4)
    finalized=0
    prune_keys=[]
    for rec_key,rec in records.items():
        if not isinstance(rec,dict) or rec.get('superseded_duplicate_v2154'):continue
        age=max(0.0,nowv-num(rec.get('start_ts'),nowv))
        if age>=21600 and not rec.get('final_appended'):
            final=dict(rec);final.update({'schema':'strategy_v2_outcome_v2163','generation':GENERATION,'outcome_6h':outcome(rec),'finalized_ts':nowv,'finalized_text':now_text(nowv),'historical_ledger_rewritten':False,'auto_buy':False})
            append_jsonl(OUTCOME_LEDGER,final);rec['final_appended']=True;finalized+=1
        # Active state is derived, not a ledger. Once the 6h final row is safely
        # appended, rotate non-open rows out of RAM/state. The append-only outcome
        # ledger preserves the full record and Main merges it for comparison.
        if rec.get('final_appended') and (not rec.get('actual_trade_exact_v2163') or rec.get('actual_trade_closed_v2164')):
            prune_keys.append(str(rec_key))
    for rec_key in prune_keys:
        records.pop(rec_key,None)
    snapshot=int(state.get('v2149_snapshot_count') or 0)+1
    active=[r for r in records.values() if isinstance(r,dict) and not r.get('superseded_duplicate_v2154')]
    horizon_counts={}
    for label,_ in HORIZONS:
        horizon_counts[label]={
            'contract_samples':sum(1 for r in active if isinstance((r.get('samples') or {}).get(label),dict)),
            'practical_forward_samples':sum(1 for r in active if isinstance((r.get('practical_samples_v2163') or {}).get(label),dict)),
        }
    active_ages=[max(0.0,nowv-(num(r.get('start_ts'),nowv) or nowv)) for r in active]
    oldest=max(active_ages) if active_ages else 0.0
    finals=[r for r in read_jsonl(OUTCOME_LEDGER,12000) if str(r.get('generation') or '')==GENERATION]
    status={
        'schema':'strategy_v2_outcome_status_v2163','version':VERSION,'build':BUILD_LABEL,'generation':GENERATION,
        'updated_ts':nowv,'updated_text':now_text(nowv),'state':'ACTIVE' if current else 'WAITING_COMBINED_V2_CANDIDATES',
        'snapshot_count':snapshot,'candidate_rows':current,'active_records':len(active),'new_records_cycle':new,'finalized_cycle':finalized,'pruned_derived_state_cycle_v2163':len(prune_keys),'pruned_derived_state_cycle_v2164':len(prune_keys),
        'prediction_model_counts_v2163':dict(model_counts),'prediction_model_counts_v2155':dict(model_counts),'contract_state_counts':dict(contract_counts),
        'required_input_failure_counts_v2155':dict(input_failures),'input_connection_state_counts_v2155':dict(connection_states),
        'full_input_active_records_v2155':sum(1 for r in active if str(r.get('prediction_model_generation') or '').startswith('FULL_INPUT_')),
        'full_input_finalized_records_v2155':sum(1 for r in finals if str(r.get('prediction_model_generation') or '').startswith('FULL_INPUT_')),
        'review_6h_state_v2154':'COMPLETE_AVAILABLE' if finals else ('WAITING_FIRST_6H' if active else 'WAITING_CANDIDATES'),
        'oldest_active_age_sec_v2154':round(oldest,3),'first_6h_due_in_sec_v2154':round(max(0.0,21600-oldest),3) if active and not finals else 0.0,
        'horizon_counts_v2163':horizon_counts,**link,
        'exact_link_policy_v2163':'direct decision key; deterministic plan hash derived from the same direct decision key only; no ticker/time proximity',
        'primary_horizons_v2163':['1h','3h'],'support_horizons_v2163':['30m','6h'],
        'shadow_active_writers_v2163':0,'shadow_removed_active_paths_v2163':list(SHADOW_WRITERS_REMOVED),
        'shadow_historical_files_deleted_v2163':False,'historical_ledgers_rewritten':False,
        'probability_calibrated':False,'prediction_used_in_final_decision':True,'decision_combiner_active':True,'paper_prediction_recompute_calls':0,
        'actual_entry_changed':False,'actual_exit_changed':False,'strategy_numbers_changed':False,'auto_buy':False,
    }
    state.update({'schema':'strategy_v2_outcome_state_v2163','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'v2149_snapshot_count':snapshot,STATE_KEY:records,'active_generation':GENERATION,'prior_keys_preserved':True,'auto_buy':False})
    phase3=time.monotonic();_atomic_json(OUTCOME_STATE,state);_atomic_json(OUTCOME_STATUS,status);state_write_sec=round(time.monotonic()-phase3,4)
    sec=round(time.monotonic()-started,3)
    worker_status={
        'schema':'clean_review_worker_status_v2163','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE','pid':os.getpid(),
        'active_owner':'review_worker_v2.063_current_outcome_only','writer_count':1,'updated_ts':nowv,'updated_text':now_text(nowv),
        'last_sec':sec,'rss_mb':rss_mb(),'proc_rss_mb':rss_mb(),'phase':'current_outcome_dense_horizons',
        'phase_sec_v2165':{'source_read':source_read_sec,'state_load':state_load_sec,'actual_link':actual_link_sec,'state_write':state_write_sec},
        'candidate_rows':current,'active_records':len(active),'horizon_counts_v2163':horizon_counts,**link,
        'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,'cycle_complete_v2164':True,'auto_buy':False,
    }
    _atomic_json(STATUS,worker_status)
    return worker_status

def ledger_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2163_dense_horizon_exact_link.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger_v870','change_id':'V2163-DENSE-HORIZON-EXACT-LINK-SHADOW-CLEANUP','issue_id':'OPEN-OUTCOME-EXACT-LINK-AND-HORIZON-GAP-2163','version':'v2163','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':txt,'writer':'review_worker_v2.061','cause':'Review created candidate rows before ENTRY_READY and did not attach the later direct decision key. Actual trades therefore failed exact linkage. The current comparison also skipped 1h and retained obsolete shadow code paths.',
        'fix':'Current-only Review owner updates direct decision aliases at ENTRY_READY, links actual trades only by direct key or its deterministic plan hash, records 30m/1h/3h/6h plus forward practical +1/+2/+3 paths, and removes all shadow writers from the active worker.',
        'not_touched':['Strategy/Trigger/Paper formulas','OPEN/CLOSED/decision/exact ledgers','sealed exits','historical shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'OPEN-OUTCOME-EXACT-LINK-AND-HORIZON-GAP-2163','status':'CHECK','title':'실제매매·놓친상승 시간대별 정확비교','detail':'direct decision key exact 연결과 30분/1시간/3시간/6시간 비교. 구 Shadow writer 중단, 과거자료 보존.','version':'v2163','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2164_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2164_runtime_order_review_fast.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2164-RUNTIME-ORDER-REVIEW-FAST-EXACT','issue_id':'MAIN-TAIL-NOT-ACTIVE-AND-REVIEW-LATENCY-2164','version':'v2164','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.062','cause':'Review held finalized derived rows for 48h, reread large JSONL files and wrote no boot status until the first long cycle. Existing OPEN rows also needed an exact sealed-contract recovery path.','fix':'Tail-bounded JSONL reads, no shallow whole-state copy, append-ledger-before-derived-state rotation, sealed direct OPEN contract exact records, boot status before first cycle, and acquired_ts lock proof.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'MAIN-TAIL-NOT-ACTIVE-AND-REVIEW-LATENCY-2164','status':'CHECK','title':'v2163 화면 미활성·Review 적용 지연','detail':'Main binding order, actual OPEN exact, Review cycle/RSS and Guard boot proof repaired together.','version':'v2164','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def ledger_v2165_once()->None:
    marker=BASE_DIR/'runtime'/'review_v2165_exact_book_market_compare.seeded'
    if marker.exists():return
    ts=now_ts();txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger_v870','change_id':'V2165-EXACT-BOOK-MARKET-COMPARE-QUALITY-READY','issue_id':'REVIEW-WRONG-ACTUAL-BOOK-AND-MARKET-TOP-BLIND-2165','version':'v2165','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':'review_worker_v2.063','cause':'Review read legacy paper_bot_open/closed instead of the active v2149 Paper exact books, so actual key showed 0/0 while Main listed current exact OPEN. The comparison also had no whole-market 15m/30m/1h reference.','fix':'Read paper_v2_exact_open/closed_v2135 only, exact-link their sealed direct contracts, update actual paths from the exact book, expose phase timings, and leave market-top rendering to the existing Main /trade_review using scanner+candle owner data.','not_touched':['Strategy/Trigger/Paper/exit formulas','OPEN/CLOSED/decision/exact ledgers','historical outcome/Shadow files','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'REVIEW-WRONG-ACTUAL-BOOK-AND-MARKET-TOP-BLIND-2165','status':'CHECK','title':'실제매매 exact 장부·시장상승 TOP 대조 수리','detail':'Review actual owner를 현재 Paper exact 장부로 바로잡고 15m/30m/1h 전체시장 대조를 기존 /trade_review에 연결한다.','version':'v2165','created_ts':ts,'created_at':txt,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True);marker.write_text(txt,encoding='utf-8')

def acquire_lock()->None:
    global _LOCK_FH
    LOCK_PATH.parent.mkdir(parents=True,exist_ok=True)
    fh=LOCK_PATH.open('a+',encoding='utf-8')
    try:fcntl.flock(fh.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit(0)
    fh.seek(0);fh.truncate();fh.write(json.dumps({'pid':os.getpid(),'version':VERSION,'build':BUILD_LABEL,'ts':now_ts(),'acquired_ts':now_ts()}));fh.flush()
    _LOCK_FH=fh
    atexit.register(lambda: fh.close() if not fh.closed else None)

def main()->None:
    acquire_lock();ledger_once();ledger_v2164_once();ledger_v2165_once()
    boot_ts=now_ts()
    _atomic_json(STATUS,{'schema':'clean_review_worker_status_v2165','version':VERSION,'build':BUILD_LABEL,'state':'ACTIVE','pid':os.getpid(),'active_owner':'review_worker_v2.063_current_outcome_only','writer_count':1,'updated_ts':boot_ts,'updated_text':now_text(boot_ts),'phase':'BOOTING_FIRST_CYCLE_V2165','cycle_complete_v2164':False,'shadow_active_writers_v2163':0,'shadow_historical_files_deleted_v2163':False,'auto_buy':False})
    while True:
        try:run_once()
        except Exception as exc:
            append_error('run_once',exc)
            _atomic_json(STATUS,{'schema':'clean_review_worker_status_v2163','version':VERSION,'build':BUILD_LABEL,'state':'ERROR','pid':os.getpid(),'updated_ts':now_ts(),'updated_text':now_text(),'error':f'{type(exc).__name__}: {exc}','shadow_active_writers_v2163':0,'auto_buy':False})
        time.sleep(INTERVAL_SEC)

if __name__=='__main__':main()
