coinbot_update_v1466

목적:
- v1465에서 단일화된 Paper live selector owner는 유지한다.
- 후보가 메마른 원인을 RR 공식/entry/target/invalid source로 분해 감사한다.
- RR_LOW가 진짜 낮은지, target이 너무 가까운지, invalid가 너무 넓은지, reported RR과 공식 RR이 어긋나는지 표시한다.
- 하드차단이 아니면 S2_RECHECK/WATCH 우선 원칙은 유지한다.
- 자동매수 OFF. 기준완화/RR기준변경/trigger/target/invalid/OPEN/청산계약 변경 없음.

검수:
/gupgrade_bundle
/grelease_verify
/source_owner
/candidate_flow
/rr_audit
/s2_recheck
/protection_audit
/version_score
/errorlog
