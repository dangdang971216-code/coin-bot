코인봇 v2093 · 메인봇 단일명령 분석형 TXT 정리

목적
- v2092의 “명령 1회 → 짧은 Telegram + 상세 TXT 자동첨부”는 유지한다.
- TXT의 원본 JSON 통째 첨부와 같은 reason 반복을 제거하고, 분석에 필요한 표로 정리한다.

수정
- /structure_board TXT:
  · 현재 source_missing 종목과 full-profile queue를 ticker로 연결
  · 현재 누락 / queue 미연결 / 회복 후 retry 잔여를 분리
  · 누락 이유·Candle 결과를 건수로 압축
  · 종목별 stage·요청·age·선택·갱신·결과·원인을 표시
  · API/cache/stale 실제 실패를 별도 표시
- /version_score·/profit_audit 등 성과 TXT:
  · 전체 canonical 본문 보존
  · reset 이후 성과와 과거 전체 분리 원칙 표시
  · CLOSED, 현재 OPEN, v2086, v2089를 섞지 않음
  · 관련 JSON은 bounded scalar summary만 기록
- Telegram compact 화면과 명령 1회 실행 계약은 그대로 유지.

변경하지 않음
- Strategy/Paper/Review/Guard 실행경로
- 후보 수·S1/S2/S3·rank
- trigger/invalid/target
- 기존 OPEN/CLOSED/decision/exact 원장
- 진입·청산·수익보호
- 자동매수 OFF

판정
- 로컬 py_compile, AST, synthetic import PASS
- 서버에서 /structure_board와 /version_score TXT 형식·크기·명령 1회 실행 확인 전 CHECK
