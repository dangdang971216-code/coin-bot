coinbot_update_v1608
- Fix v1607 partial apply: Strategy target is under workers.strategy.
- Candidate preserve/recheck only. No trading rule changes. Auto-buy OFF.
