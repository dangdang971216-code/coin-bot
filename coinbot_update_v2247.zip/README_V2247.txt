코인봇 v2247 — Telegram 주인 분리 및 업그레이드 시간판정 수리

확인된 실제 오류
- Paper 전용 토큰이 사라진 뒤 TELEGRAM_TOKEN/CHAT_ID로 fallback하여 Main bot 업데이트를 소비함.
- OPEN 알림도 Main bot 계정/방으로 전송됨.
- Main방의 /trade_review /version_score /flow_map_full을 Paper가 Paper 명령 도움말로 처리함.
- Guard는 핵심 적용이 정상이어도 전체 60초를 넘으면 시간 CHECK로 바꿀 수 있었음.

수정
1. Paper: PAPER_BOT_TOKEN과 Paper 전용 chat key만 허용. Main/Guard fallback 제거.
2. Paper 전용 키 누락 시 Paper Telegram만 꺼지고 다른 봇으로 절대 우회하지 않음.
3. Guard: 45초 목표는 표시용. 전체 wall time 상한으로 PASS를 뒤집지 않음.
4. compile/hash/PID/version/writer 검증 실패는 기존처럼 CHECK/FAIL.
5. Review 분석은 최근 봉인 exact 최대 500건 유지.

적용 전 현재 Main 명령을 되살리려면 Paper 서비스를 잠시 stop해야 함. 적용 후 Paper 전용 토큰을 복구한 뒤 Paper만 restart.
