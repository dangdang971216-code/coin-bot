coinbot_update_v1441

Purpose: Fix v1440 readable shadow board NameError for /shadow_board and /buried_shadow.

Fix:
- /shadow_board no longer references missing V1437_BURIED_SHADOW_STATUS.
- /buried_shadow reads existing V1437_BURIED_BOARD path.

No trading changes:
- Auto-buy OFF.
- No S1/Paper/OPEN/trigger/invalid/target/exit/autostop changes.
- Core ledgers are not rewritten.
