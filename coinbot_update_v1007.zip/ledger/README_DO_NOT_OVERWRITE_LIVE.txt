Release evidence only. Do not overwrite live OPEN/CLOSED/trade_log/decision/exact/change_verify/issue ledgers.
