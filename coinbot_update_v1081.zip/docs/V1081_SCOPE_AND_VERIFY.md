# v1081 Paper memory owner and surrounding worker closeout

## Root cause
- Paper canonical performance writer loaded the complete `paper_bot_closed.jsonl` into `raw_rows`.
- It then held the previous canonical snapshot, the new compact snapshot, decision maps, and multiple derived lists at the same time.
- The live audit showed 1.1GB anonymous RSS even when `performance_write` was not active, proving retained Python/glibc heap after a prior rebuild rather than page cache or child process ownership.
- Risk 5.67s was a bounded source-change recomputation of the latest 2,500 CLOSED rows. Unchanged files use the existing fingerprint cache; no Risk source change is justified.

## v1081 changes
- Paper v1.003 streams CLOSED JSONL one row at a time.
- Previous snapshot identity/key data is extracted and released before the current snapshot is built.
- Decision membership maps and temporary comparison sets are released as soon as they are no longer needed.
- `gc.collect()` and Linux `malloc_trim(0)` reclaim temporary heap after the canonical write.
- Canonical membership, first-committed dedupe, counts, exact keys, rows, windows, source digest, and output files are unchanged.
- Guard v2.5.136 adds `/gfinal_owner_v1081` to verify Paper runtime/hash/digest/memory, Risk behavior, surrounding worker alias/hash/process ownership, disk bounds, exact 0/0/0, and auto-buy OFF.

## Local proof
- 2,209 valid rows plus malformed/non-dict/duplicate/missing cases: old and new canonical snapshots were byte-identical (10,640,321 bytes).
- Old and new membership digest and source digest were identical.
- 65.6MB / 12,000-row synthetic full writer:
  - peak RSS: 661,964KB -> 569,368KB
  - retained RSS after return/delete/trim: 444,880KB -> 300,640KB
  - writer time: 4.47s -> 4.23s
- Entry selection, OPEN creation, exit monitoring, exact close commit, and OPEN persistence active functions are AST-identical.

## Excluded
- No strategy threshold, trigger, invalid, target, RR, spread, slippage, trailing, time exit, OPEN limit, or auto-buy change.
- No OPEN/CLOSED/trade_log/decision/exact/change/issue ledger is included, deleted, shrunk, or rewritten.
- Surrounding worker sources are not changed because static owner audit found no duplicated top-level definition or justified alternate writer removal.

## Server status before apply
CHECK. DONE requires `/gfinal_owner_v1081 180` after deployment.
