#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import os
import pathlib
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def main() -> None:
    g = load('guard_v1228_storage', PACKAGE_ROOT / 'backga_guard_bot_v2_5_224.py')
    gb = 1024 ** 3
    assert g._v1228_disk_pressure_level(5 * gb) == 'NORMAL'
    assert g._v1228_disk_pressure_level(3 * gb) == 'WARNING'
    assert g._v1228_disk_pressure_level(int(1.5 * gb)) == 'DANGER'
    assert g._v1228_disk_pressure_level(int(0.5 * gb)) == 'CRITICAL'

    with tempfile.TemporaryDirectory() as td:
        d = pathlib.Path(td)
        g.BOT_DIR = d
        stale = d / 'clean_performance_shadow.json.tmp.123.456'
        stale.write_bytes(b'x' * 4096)
        old = time.time() - 7200
        os.utime(stale, (old, old))
        fresh = d / 'fresh.json.tmp.1.2'
        fresh.write_text('fresh', encoding='utf-8')
        protected = d / 'paper_bot_closed.jsonl.tmp.1.2'
        protected.write_text('ledger', encoding='utf-8')
        os.utime(protected, (old, old))
        result = g.run_retention_cleanup(dry_run=False)
        assert not stale.exists()
        assert fresh.exists()
        assert protected.exists()
        assert (result.get('orphan_temp_cleanup_v1228') or {}).get('deleted', 0) >= 1

        calls = []
        def fake_priv(cmd, timeout=0):
            calls.append(list(cmd))
            return 0, 'ok'
        g._run_privileged = fake_priv
        rc, _ = g._v928_install_root_text('/etc/systemd/journald.conf.d/99-coinbot-storage.conf', '[Journal]\n')
        assert rc == 0
        assert calls[0][:3] == ['install', '-d', '-m']
        assert calls[1][:3] == ['install', '-m', '0644']

    # First v1228 policy check must run even if old v1196 cleanup recently ran.
    snapshots = iter([
        {'disk_free': int(3.5 * gb), 'disk_pct': 76.0},
        {'disk_free': int(3.6 * gb), 'disk_pct': 75.5},
        {'disk_free': int(3.7 * gb), 'disk_pct': 75.0},
    ])
    g.server_resource_snapshot = lambda: next(snapshots)
    g.read_json = lambda _p: {'last_run_ts': time.time(), 'auto_storage_policy_v1228': False}
    written = {}
    g.write_json = lambda p, obj: written.update({'path': str(p), 'obj': obj})
    g.run_retention_cleanup = lambda dry_run=False: {'freed': 10, 'deleted': 1, 'truncated': 0, 'compressed': 0, 'errors': 0}
    g._v928_system_log_fix = lambda dry_run=False: {'journal_freed': 20, 'var_log_freed': 30, 'errors': 0}
    out = g.maybe_run_auto_retention_v1196(force=False)
    assert out['ran'] is True
    assert out['state']['trigger'] == 'policy_migration_v1228'
    assert out['state']['auto_storage_policy_v1228'] is True
    assert out['state']['pressure_level_v1228'] == 'WARNING'
    assert out['state']['core_ledger_deleted'] is False
    assert out['state']['system_log_maintenance_v1228']['errors'] == 0
    assert g.VERSION.startswith('guard_v2.5.224_v1232')
    print('PASS v1228 storage: stale temp cleanup, core-ledger protection, root-dir install, migration auto-clean, staged pressure')

if __name__ == '__main__':
    main()
