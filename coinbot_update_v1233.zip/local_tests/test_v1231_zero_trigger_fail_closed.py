#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def support(tf: str, low: float, score: float = 80.0):
    return {'tf': tf, 'side': 'support', 'price': low, 'zone_low': low,
            'zone_high': low + 0.1, 'score': score, 'touch_count': 3,
            'source': f'candle.{tf}', 'atr_pct': 1.0, 'gap_pct': 0.0}

def resistance(tf: str, low: float, score: float = 80.0):
    return {'tf': tf, 'side': 'resistance', 'price': low, 'zone_low': low,
            'zone_high': low + 0.1, 'score': score, 'touch_count': 3,
            'source': f'candle.{tf}', 'atr_pct': 1.0, 'gap_pct': 0.0}

def main() -> None:
    old = load('strategy_v1230_zero_trigger_failure', PACKAGE_ROOT / 'baselines' / 'strategy_worker_v1.057_v1230_zero_trigger_failure.py')
    new = load('strategy_v1231_zero_trigger_repair', PACKAGE_ROOT / 'strategy_worker_v1.058.py')

    kwargs = dict(
        invalid_pool=[(3.0, support('h2', 97.0))],
        target_pool=[(4.0, resistance('h2', 104.0))],
        price=100.0,
        trigger_price=0.0,
        invalid_buffer_pct=0.0,
        reach_limit_pct=10.0,
        minimum_target_room_pct=1.2,
        estimated_roundtrip_cost_pct=0.5,
        cost_complete=True,
    )
    try:
        old._v1229_select_coherent_structure_pair(**kwargs)
        raise AssertionError('v1230 zero-trigger crash was not reproduced')
    except ZeroDivisionError:
        pass

    repaired = new._v1229_select_coherent_structure_pair(**kwargs)
    assert repaired['selection_mode'] == 'trigger_price_missing_no_pair'
    assert repaired['selected_invalid'] == {}
    assert repaired['selected_target'] == {}
    assert repaired['combination_count'] == 0
    assert repaired['passing_count'] == 0
    assert repaired['intermediate_count'] == 0

    # Positive-trigger trading geometry must remain unchanged.
    valid_kwargs = dict(kwargs)
    valid_kwargs['trigger_price'] = 100.0
    old_valid = old._v1229_select_coherent_structure_pair(**valid_kwargs)
    new_valid = new._v1229_select_coherent_structure_pair(**valid_kwargs)
    for key in ('selected_invalid', 'selected_target', 'selection_mode', 'combination_count',
                'passing_count', 'selected_risk_pct', 'selected_room_pct', 'selected_raw_rr'):
        assert old_valid[key] == new_valid[key], (key, old_valid[key], new_valid[key])

    assert new.VERSION == 'strategy_worker_v1.058'
    assert new.V925_MIN_RR == 1.50
    assert new.V925_MIN_TARGET_ROOM_PCT == 1.20
    assert new.V1231_ZERO_TRIGGER_FAIL_CLOSED_CONTRACT['auto_buy'] is False
    print('PASS v1231 zero trigger is fail-closed; valid stop/profit pairing unchanged')

if __name__ == '__main__':
    main()
