#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def line(price: float, tf: str = 'h1'):
    return {'rounded_price': price, 'raw_price': price, 'tf': tf, 'source': f'candle.{tf}'}

def row(ticker: str, *, trigger=100.0, stop=98.0, target=104.0,
        inv_n=1, tgt_n=1, combos=1, passing=1, cost_complete=True,
        mode='coherent_major_pair', reasons=None, stage='S2'):
    plan = {
        'trigger': line(trigger, 'm15') if trigger else {},
        'invalid': line(stop, 'h1') if stop else {},
        'target': line(target, 'h2') if target else {},
        'target_mode_v1225': mode,
        'pairing_contract_v1229': {
            'invalid_candidates': inv_n, 'target_candidates': tgt_n,
            'combinations': combos, 'passing': passing,
            'major_passing': passing, 'setup_passing': 0,
            'cost_complete': cost_complete,
        },
    }
    return {
        'ticker': ticker, 's_stage': stage,
        'candidate_pipeline_cycle_id_v1150': 'cycle-v1232',
        'dynamic_structure_plan_v1212': plan,
        'candidate_structure_diagnostic_v1218': {
            'missing_reason_codes': reasons or (['complete'] if trigger and stop and target else []),
        },
    }

def main() -> None:
    g = load('guard_v1232_pair_exclusion', PACKAGE_ROOT / 'backga_guard_bot_v2_5_224.py')
    rows = [
        row('OK', stage='S1'),
        row('TRIG', trigger=0.0, stop=0.0, target=0.0, inv_n=0, tgt_n=0, combos=0, passing=0,
            mode='trigger_price_missing_no_pair', reasons=['trigger_current_price_missing']),
        row('FEE', stop=0.0, target=0.0, inv_n=2, tgt_n=3, combos=6, passing=2, cost_complete=False,
            mode='cost_source_missing_no_pair', reasons=['paper_fee_source_missing_v1229']),
        row('STOP', stop=0.0, target=0.0, inv_n=0, tgt_n=2, combos=0, passing=0,
            mode='no_coherent_structure_pair', reasons=['invalid_support_zone_absent','coherent_stop_profit_pair_absent_v1229']),
        row('MID', stop=0.0, target=0.0, inv_n=2, tgt_n=0, combos=0, passing=0,
            mode='no_coherent_structure_pair', reasons=['target_only_intermediate_resistance_v1225']),
        row('FAR', stop=0.0, target=0.0, inv_n=2, tgt_n=0, combos=0, passing=0,
            mode='no_coherent_structure_pair', reasons=['target_resistance_beyond_dynamic_reach_v1225']),
        row('RR', stop=0.0, target=0.0, inv_n=2, tgt_n=3, combos=6, passing=0,
            mode='no_coherent_structure_pair', reasons=['coherent_stop_profit_pair_absent_v1229']),
    ]
    with tempfile.TemporaryDirectory() as td:
        d = pathlib.Path(td)
        g.BOT_DIR = d
        candidate = d / g.S1_ZERO_AUDIT_CANDIDATES_V1214
        candidate.write_text('\n'.join(json.dumps(x, ensure_ascii=False, separators=(',', ':')) for x in rows) + '\n', encoding='utf-8')
        writer = {
            'result':'OK', 'candidate_last_commit_id_v1026':'candidate-v1232',
            'candidate_snapshot_scope':{
                'pipeline_cycle_id_v1150':'cycle-v1232',
                'pipeline_cycle_id_consistent_v1150':True,
                'complete_snapshot':True,'atomic_replace':True,
                'rows_written':len(rows),'output_bytes':candidate.stat().st_size,
                'commit_id':'candidate-v1232',
            },
        }
        (d / g.S1_ZERO_AUDIT_WRITER_STATUS_V1214).write_text(json.dumps(writer), encoding='utf-8')
        report = g.collect_pair_exclusion_audit_v1232()
        assert report['verdict'] == 'PROVEN_PAIR_EXCLUSION_BREAKDOWN', report
        assert report['summary']['complete'] == 1
        assert report['summary']['excluded'] == 6
        counts = report['primary_reason_counts']
        assert counts['진입 기준선 없음'] == 1
        assert counts['비용자료 없음'] == 1
        assert counts['쓸 수 있는 손절선 없음'] == 1
        assert counts['가까운 중간 저항만 있음'] == 1
        assert counts['목표선이 도달범위 밖'] == 1
        assert counts['손해 대비 먹을 폭 부족'] == 1
        assert report['source']['writer_exact'] is True
        text = g.gpair_exclusion_audit_text_v1232()
        assert '전체 7' in text and '제외 6' in text
        assert '손해 대비 먹을 폭 부족 1' in text
    assert g.VERSION.startswith('guard_v2.5.224_v1232')
    print('PASS v1232 exact exclusion breakdown from committed candidate diagnostics')

if __name__ == '__main__':
    main()
