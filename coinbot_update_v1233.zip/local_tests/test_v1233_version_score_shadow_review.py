#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import pathlib
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def line(price: float, tf: str):
    return {'rounded_price': price, 'raw_price': price, 'tf': tf, 'source': f'test.{tf}'}

def candidate(price: float):
    return {
        'ticker':'AAA','current_price':price,'candidate_key':'aaa-event-1',
        'candidate_pipeline_cycle_id_v1150':'cycle-1',
        'dynamic_structure_plan_v1212':{
            'trigger':line(100,'m15'),'invalid':{},'target':{},
            'pairing_contract_v1229':{
                'invalid_candidates':2,'target_candidates':3,'combinations':6,
                'passing':0,'major_passing':0,'setup_passing':0,'cost_complete':True,
            },
        },
        'v1211_structure_shadow_v1222':{
            'source_exact':True,'complete':True,
            'trigger':line(100,'m15'),'invalid':line(95,'h1'),'target':line(110,'h4'),
        },
    }


def candidate_intermediate(price: float):
    row = candidate(price)
    row['ticker'] = 'BBB'
    row['candidate_key'] = 'bbb-event-1'
    plan = row['dynamic_structure_plan_v1212']
    plan['pairing_contract_v1229'] = {
        'invalid_candidates': 2, 'target_candidates': 0, 'combinations': 0,
        'passing': 0, 'major_passing': 0, 'setup_passing': 0, 'cost_complete': True,
    }
    plan['intermediate_resistance_v1225'] = line(101, 'm30')
    row['v1211_structure_shadow_v1222'] = {}
    return row

def main() -> None:
    review = load('review_v1233', PACKAGE_ROOT / 'review_worker_v1.022.py')
    with tempfile.TemporaryDirectory() as td:
        base = pathlib.Path(td)
        s1 = review.update_version_score_review(base, [candidate(99), candidate_intermediate(99)])
        assert s1['missed_current_structure']['risk_reward_shortage_count'] == 1
        assert s1['missed_current_structure']['intermediate_only_count'] == 1
        assert s1['missed_current_structure']['tracked_total'] == 2
        assert s1['previous_structure_shadow']['pending_count'] == 1
        s2 = review.update_version_score_review(base, [candidate(101), candidate_intermediate(102)])
        assert s2['previous_structure_shadow']['open_count'] == 1
        s3 = review.update_version_score_review(base, [candidate(111), candidate_intermediate(103)])
        assert s3['previous_structure_shadow']['closed_count'] == 1
        assert s3['previous_structure_shadow']['exit_reasons']['TARGET'] == 1
        assert (base/'version_score_review_state_v1233.json').exists()
        assert (base/'canonical_version_score_review_v1233.json').exists()
        state=json.loads((base/'version_score_review_state_v1233.json').read_text())
        for event in state['missed']['events'].values():
            event['created_ts']=time.time()-90000
        review.atomic_write_json(base/'version_score_review_state_v1233.json',state)
        s4=review.update_version_score_review(base, [candidate(100), candidate_intermediate(100)])
        assert s4['missed_current_structure']['risk_reward_shortage_count'] == 1  # current generation creates fresh events
        assert s4['missed_current_structure']['intermediate_only_count'] == 1

        # Only the new review/shadow state is pruned after 24h. Core ledgers
        # are not opened, rewritten, or truncated by the review worker.
        core = base/'paper_bot_closed.jsonl'
        core.write_text('{"core":true}\n', encoding='utf-8')
        core_before = core.read_bytes()
        state=json.loads((base/'version_score_review_state_v1233.json').read_text())
        old=time.time()-90000
        shadow=state['previous_structure_shadow']
        shadow['closed']=[dict(s3['previous_structure_shadow']['top_profit'][0], closed_ts=old)]
        shadow['skipped']=[{'event_id':'old-skip','ticker':'ZZZ','ts':old,'reason':'OLD'}]
        shadow['pending']={'old-pending':{'event_id':'old-pending','ticker':'ZZZ','created_ts':old}}
        shadow['open']={'old-open':{'event_id':'old-open','ticker':'ZZZ','opened_ts':old,'last_price':0}}
        review.atomic_write_json(base/'version_score_review_state_v1233.json',state)
        pruned=review.update_version_score_review(base, [])
        assert pruned['previous_structure_shadow']['pending_count']==0
        assert pruned['previous_structure_shadow']['open_count']==0
        assert pruned['previous_structure_shadow']['closed_count']==0
        assert pruned['previous_structure_shadow']['skipped_count']==0
        assert core.read_bytes()==core_before

    paper = load('paper_v1233_family', PACKAGE_ROOT / 'paper_bot_v1.066.py')
    now=time.time()
    rows=[
        {'structure_contract_version':'structure_contract_v1211_legacy','closed_at':now,'opened_at':now-100,'net_pnl_pct':1.0},
        {'structure_contract_version':'structure_contract_v1229_coherent_stop_profit_pairing','closed_at':now,'opened_at':now-100,'net_pnl_pct':2.0},
        {'structure_contract_version':'structure_contract_v1231_zero_trigger_fail_closed','closed_at':now,'opened_at':now-100,'net_pnl_pct':3.0},
        {'structure_contract_version':'','closed_at':now,'opened_at':now-100,'net_pnl_pct':9.0},
    ]
    perf=paper._v1213_contract_stats(rows,now)
    contracts=perf['contracts']
    assert contracts['structure_contract_v1211_legacy']['rows']==1
    current=contracts['structure_contract_v1212_dynamic_zones']
    assert current['rows']==2
    assert perf['unclassified_rows_v1233']==1
    assert contracts['structure_contract_v1211_legacy']['rows']==1
    assert current['raw_structure_contract_versions_v1233']['structure_contract_v1229_coherent_stop_profit_pairing']==1

    with tempfile.TemporaryDirectory() as td:
        os.environ['COINBOT_BASE_DIR']=td
        mainmod=load('main_v1233', PACKAGE_ROOT / 'coinbot_main_v2_13_1144.py')
        snap={
            'snapshot_id':'snap','generated_at':now,'counts':{},
            'windows':{'all':{'count':3,'wins':3,'losses':0,'total_pct':6,'avg_pct':2}},
            'contract_performance_v1213':perf,
        }
        pathlib.Path(td,'canonical_performance_snapshot_v987.json').write_text(json.dumps(snap),encoding='utf-8')
        pathlib.Path(td,'canonical_version_score_review_v1233.json').write_text(json.dumps(s3),encoding='utf-8')
        text=mainmod.render_version_score_compact()
        headings=['1️⃣ 현재 구조선 실제 거래','2️⃣ 현재 구조선이 제외했는데 오른 코인','3️⃣ 구조선 변경 전 실제 거래','4️⃣ 이전 구조선 전체시장 가상거래']
        positions=[text.index(h) for h in headings]
        assert positions==sorted(positions)
        assert '최근 12시간' in text
        assert '기존 상세 성과' in text
        assert '가까운 중간 저항만 있음' in text
        assert '읽기 전용 추적' in text
        assert '계약 버전 누락·미분류 1건' in text
        assert mainmod.BOT_VERSION=='수익형 v2.13.1144'
    assert review.VERSION=='review_worker_v1.022'
    assert paper.VERSION=='paper_bot_v1.066'
    print('PASS v1233 version score order, current family, missed 6h review, v1211 unlimited shadow state')

if __name__=='__main__':
    main()
