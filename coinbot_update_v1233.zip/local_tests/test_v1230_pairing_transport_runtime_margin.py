#!/usr/bin/env python3
from __future__ import annotations
import copy, importlib.util, json, pathlib, sys
ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
OLD_ROOT = pathlib.Path('/mnt/data/v1229_liveinspect') if pathlib.Path('/mnt/data/v1229_liveinspect').exists() else PACKAGE_ROOT / 'baselines'
if str(PACKAGE_ROOT) not in sys.path: sys.path.insert(0, str(PACKAGE_ROOT))

def load(name, path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod; assert spec and spec.loader; spec.loader.exec_module(mod); return mod

def install_material(mod):
    def frame_rows(_row, tf): return [{'tf':tf}]*10
    def atr(rows):
        tf=rows[0]['tf'] if rows else ''
        return {'m5':0.7,'m15':1.0,'m30':1.0,'h1':1.2,'h2':2.0,'h4':5.0}.get(tf,1.0)
    def zone(tf, low, high, score=80.0, side='resistance'):
        return {'tf':tf,'side':side,'price':(low+high)/2,'zone_low':low,'zone_high':high,'score':score,'touch_count':3,'source':f'candle.{tf}','atr_pct':1.0,'gap_pct':0.0}
    def candidates(_rows, tf, side, _price):
        if side=='support': return [zone(tf,97.0,97.2,side='support')] if tf=='h1' else []
        table={'m15':[zone('m15',100.4,100.5)],'m30':[zone('m30',100.9,101.0)],'h1':[zone('h1',103.0,103.2)],'h2':[zone('h2',106.0,106.2)],'h4':[zone('h4',109.0,109.2)]}
        return table.get(tf,[])
    mod._v1212_frame_rows=frame_rows; mod._v1212_atr_pct=atr; mod._v1212_zone_candidates=candidates
    mod._v1212_cost_inputs=lambda _row:{'spread_pct':0.1,'slippage_pct':0.1,'slippage_source':'test','fee_pct':0.2,'fee_source_v1229':'paper_active_contract','estimated_roundtrip_cost_pct':0.5,'complete':True}
    mod._v1212_strength_factor=lambda _row:1.0

def source(plan, padding, selection):
    p=copy.deepcopy(plan); p['runtime_padding_v1230']='P'*padding
    return {'ticker':'TEST','market':'KRW-TEST','candidate_pipeline_cycle_id_v1150':'cycle-x','s_stage':'S2','current_price':100.0,
    'structure_integrity_v1048':'OK','structure_integrity_block_v1048':False,'structure_integrity_refresh_required_v1048':False,
    'structure_integrity_v1049':'OK','structure_integrity_block_v1049':False,'structure_integrity_refresh_required_v1049':False,
    'structure_contract_version':plan['structure_contract_version'],'structure_contract_hash':plan['structure_contract_hash'],
    'structure_quality_score_v1212':81.4,'target_reachability_score_v1212':83.2,'global_entry_score_v1212':77.7,'dynamic_chase_limit_pct_v1212':0.8,
    'ranking_contract_version':'ranking_contract_v1212_global_dynamic_score','selection_contract_version':selection,
    'current_cycle_observation_only_v1215':False,'current_cycle_observation_role_owner_v1215':'strategy','legacy_s3_observation_label_v1215':False,'legacy_s3_observation_retired_v1215':True,
    'entry_flow_state_v1221':'WATCHING_FROZEN_TRIGGER','entry_flow_baseline_v1221':'v1211_trigger_watch_then_s1_then_paper','entry_flow_violation_v1221':False,'v1211_structure_shadow_ready_v1222':True,
    'dynamic_structure_material_evidence_v1215':{'schema':'dynamic_structure_material_evidence_v1215','link_mode':'canonical_candle_map','source_state':'READY','analysis_ready':True,'frame_counts':plan['frame_counts_v1215']},
    'dynamic_structure_plan_v1212':p,'structure_contract_v1212':p}

def main():
    old=load('strategy_v1229_runtime_failure', PACKAGE_ROOT/'baselines'/'strategy_worker_v1.056_v1229_candidate_commit_failure.py')
    new=load('strategy_v1230_runtime_repair', PACKAGE_ROOT/'strategy_worker_v1.058.py')
    install_material(old); install_material(new)
    old_plan=old._v925_current_actual_plan({'ticker':'TEST','current_price':100.0}); new_plan=new._v925_current_actual_plan({'ticker':'TEST','current_price':100.0})
    assert old_plan['trigger']==new_plan['trigger'] and old_plan['invalid']==new_plan['invalid'] and old_plan['target']==new_plan['target']
    old_src=source(old_plan,16500,'selection_contract_v1229_coherent_pairing_global_score')
    try:
        old._v861_compact_row_for_latest(old_src)
        raise AssertionError('v1229 near-ceiling failure not reproduced')
    except ValueError as exc:
        assert 'hard ceiling' in str(exc)
    new_src=source(new_plan,16500,'selection_contract_v1230_coherent_pairing')
    compact=new._v861_compact_row_for_latest(new_src)
    encoded=json.dumps(compact,ensure_ascii=False,separators=(',',':'),default=str).encode()
    assert len(encoded) <= new.V1020_ROW_HARD_CEILING_BYTES-900, len(encoded)
    plan=compact['dynamic_structure_plan_v1212']
    assert plan['trigger']==new_plan['trigger'] and plan['invalid']==new_plan['invalid'] and plan['target']==new_plan['target']
    assert plan['pairing_contract_v1229']['combinations']==new_plan['pairing_contract_v1229']['combinations']
    assert 'selected_raw_rr' not in plan['pairing_contract_v1229']
    assert 'zone_counts' not in plan and 'timeframe_contract' not in plan
    assert compact['structure_contract_v1212']['trigger']==new_plan['trigger']
    assert 'cost_inputs' not in compact['structure_contract_v1212']
    assert new.VERSION=='strategy_worker_v1.058'
    print(f'PASS v1230 transport: v1229 failure reproduced, v1230 {len(encoded)}B with {new.V1020_ROW_HARD_CEILING_BYTES-len(encoded)}B margin; trading lines unchanged')
if __name__=='__main__': main()
