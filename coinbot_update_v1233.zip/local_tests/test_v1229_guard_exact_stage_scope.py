#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def row(i: int, stage: str):
    trigger = 100.0
    invalid = 98.0
    target = 104.0
    rr = 2.0
    reached = stage == 'S1'
    reasons = [] if reached else ['frozen_trigger_not_reached']
    return {
        'ticker': f'T{i}', 's_stage': stage, 'current_price': 100.2 if reached else 99.8,
        'candidate_pipeline_cycle_id_v1150': 'cycle-v1229',
        'trigger_price': trigger, 'invalid_price': invalid, 'target_price': target,
        'risk_reward': rr, 'target_room_pct': 4.0,
        'entry_flow_state_v1221': 'TRIGGER_REACHED_S1_READY' if reached else 'WATCHING_FROZEN_TRIGGER',
        'entry_flow_contract_v1221': {'trigger_reached': reached, 'current_state': 'TRIGGER_REACHED_S1_READY' if reached else 'WATCHING_FROZEN_TRIGGER'},
        'swing_entry_gate_v977': {
            'stage': stage, 'hard_pass': reached, 'trigger_reached': reached,
            'trigger_price': trigger, 'invalid_price': invalid, 'target_price': target,
            'risk_reward': rr, 'target_room_pct': 4.0,
            'minimum_risk_reward': 1.5, 'minimum_target_room_pct': 1.2,
            'hard_block_reasons': reasons,
        },
        'dynamic_structure_plan_v1212': {
            'current_price': 99.8,
            'trigger': {'rounded_price': trigger, 'tf': 'm15'},
            'invalid': {'rounded_price': invalid, 'tf': 'h1'},
            'target': {'rounded_price': target, 'tf': 'h2'},
            'target_mode_v1212': 'coherent_major_pair',
            'cost_inputs': {'estimated_roundtrip_cost_pct': 0.4, 'fee_pct': 0.1},
            'pairing_contract_v1229': {'invalid_candidates': 2, 'target_candidates': 3, 'combinations': 6, 'passing': 2, 'major_passing': 2, 'setup_passing': 0},
        },
    }

def main() -> None:
    g = load('guard_v1229_scope', PACKAGE_ROOT / 'backga_guard_bot_v2_5_224.py')
    with tempfile.TemporaryDirectory() as td:
        d = pathlib.Path(td)
        g.BOT_DIR = d
        rows = [row(i, 'S1' if i < 2 else 'S2') for i in range(10)]
        candidate = d / g.S1_ZERO_AUDIT_CANDIDATES_V1214
        candidate.write_text('\n'.join(json.dumps(x, separators=(',', ':')) for x in rows) + '\n', encoding='utf-8')
        writer = {
            'result': 'OK', 'candidate_last_commit_id_v1026': 'candidate-v1229',
            'candidate_snapshot_scope': {
                'pipeline_cycle_id_v1150': 'cycle-v1229',
                'pipeline_cycle_id_consistent_v1150': True,
                'complete_snapshot': True, 'atomic_replace': True,
                'rows_written': len(rows), 'output_bytes': candidate.stat().st_size,
                'commit_id': 'candidate-v1229',
            },
        }
        (d / g.S1_ZERO_AUDIT_WRITER_STATUS_V1214).write_text(json.dumps(writer), encoding='utf-8')
        # Deliberately stale and mismatched Gate status; v1229 audits must ignore it for commit/stage binding.
        (d / g.S1_ZERO_AUDIT_GATE_STATUS_V1214).write_text(json.dumps({'rows': 99, 'pass_s1': 0, 'recheck_s2': 0, 'observe_s3': 99}), encoding='utf-8')
        paper_contract = {
            'integrity': {'exact_s1': True},
            'entry': {'entry_mode': 'Strategy exact S1 + Paper integrity + ranked capacity pacing'},
        }
        (d / g.PAPER_ACTIVE_CONTRACT_V1221).write_text(json.dumps(paper_contract), encoding='utf-8')

        geometry = g.collect_entry_geometry_exact_audit_v1219()
        assert geometry['source']['same_rows'] is True
        assert geometry['source']['same_stage'] is True
        assert geometry['source']['same_cycle'] is True
        assert geometry['source']['writer_exact_v1218'] is True
        assert geometry['source']['gate_status_commit_binding_removed_v1229'] is True
        assert geometry['source']['thresholds_exact_v1229'] is True
        assert geometry['pairing_v1229']['combinations'] == 60
        assert geometry['pairing_v1229']['passing'] == 20

        flow = g.collect_entry_flow_contract_audit_v1221()
        assert flow['verdict'] == 'PROVEN_V1211_FLOW_PRESERVED', flow
        assert flow['source']['same_stage'] is True
        assert flow['source']['writer_exact_v1229'] is True
        assert flow['flow']['s1_before_trigger_violation'] == 0

    assert g.VERSION.startswith('guard_v2.5.224_v1232')
    print('PASS v1229 geometry/flow exact stage from committed candidate bytes, stale Gate status excluded')

if __name__ == '__main__':
    main()
