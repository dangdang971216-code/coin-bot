#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot Review worker v1.022 / v1233.

Single owner for observation, candidate-standard, and read-only trade review.
The worker never changes Strategy candidate decisions, Paper OPEN/CLOSED, or
trading rules. It consumes the immutable Strategy generation committed before
handoff and the canonical Paper performance snapshot.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import atexit
import fcntl
import os
import signal
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Dict, Optional

from canonical_spine_v1187 import (
    AUTO_BUY,
    SPINE_SCHEMA,
    STRATEGY_MODE,
    SpinePaths,
    append_jsonl,
    atomic_write_json,
    build_candidate_standard,
    build_review_snapshot,
    digest_obj,
    integer,
    mapping,
    num,
    now_text,
    now_ts,
    read_json,
    read_candidate_rows,
)

VERSION = "review_worker_v1.022"
BUILD_LABEL = "v1233_version_score_shadow_and_missed_review_2026-07-05"
DEFAULT_INTERVAL_SEC = 3.0
HEARTBEAT_SEC = 5.0
_STOP = False
_LOCK_HANDLE: Optional[Any] = None

V1233_RETENTION_SEC = 24.0 * 3600.0
V1233_MISSED_HORIZON_SEC = 6.0 * 3600.0
V1233_SHADOW_FEE_PCT = 0.10
V1233_STATE_SCHEMA = "version_score_review_state_v1233"
V1233_SUMMARY_SCHEMA = "canonical_version_score_review_v1233"


def version_score_state_path(base: Path) -> Path:
    return base / "version_score_review_state_v1233.json"


def version_score_summary_path(base: Path) -> Path:
    return base / "canonical_version_score_review_v1233.json"


def _v1233_float(*values: Any, default: float = 0.0) -> float:
    for value in values:
        try:
            if value is None or value == "":
                continue
            out = float(value)
            if out == out and abs(out) != float("inf"):
                return out
        except (TypeError, ValueError, OverflowError):
            continue
    return default


def _v1233_ticker(row: Dict[str, Any]) -> str:
    return str(row.get("ticker") or row.get("market") or row.get("symbol") or "").strip().upper()


def _v1233_price(row: Dict[str, Any]) -> float:
    return _v1233_float(
        row.get("current_price"), row.get("live_price"), row.get("price"),
        row.get("trade_price"), row.get("close"), row.get("last_price"), default=0.0,
    )


def _v1233_nested(row: Dict[str, Any], *names: str) -> Dict[str, Any]:
    for name in names:
        value = row.get(name)
        if isinstance(value, dict):
            return value
    gate = row.get("swing_entry_gate_v977") if isinstance(row.get("swing_entry_gate_v977"), dict) else {}
    for name in names:
        value = gate.get(name)
        if isinstance(value, dict):
            return value
    return {}


def _v1233_line_price(obj: Any) -> float:
    if not isinstance(obj, dict):
        return 0.0
    return _v1233_float(obj.get("rounded_price"), obj.get("raw_price"), obj.get("price"), default=0.0)


def _v1233_event_identity(row: Dict[str, Any], ticker: str, suffix: str) -> str:
    keys = (
        row.get("candidate_key"), row.get("candidate_key_v1150"),
        row.get("trigger_occurrence_candidate_key"), row.get("occurrence_key"),
        row.get("swing_gate_decision_key_v977"), row.get("decision_key"),
    )
    stable = next((str(x).strip() for x in keys if str(x or "").strip()), "")
    if not stable:
        plan = _v1233_nested(row, "dynamic_structure_plan_v1212", "structure_contract_v1212")
        stable = "|".join((
            ticker,
            str(_v1233_line_price(plan.get("trigger"))),
            str(_v1233_line_price(plan.get("invalid"))),
            str(_v1233_line_price(plan.get("target"))),
        ))
    raw = f"{stable}|{suffix}".encode("utf-8", errors="ignore")
    return hashlib.sha256(raw).hexdigest()[:24]


def _v1233_return_pct(price: float, start: float) -> Optional[float]:
    if price <= 0 or start <= 0:
        return None
    return (price - start) / start * 100.0


def _v1233_empty_state(nowv: float) -> Dict[str, Any]:
    return {
        "schema": V1233_STATE_SCHEMA,
        "started_ts": nowv, "started_text": now_text(nowv),
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "retention_sec": V1233_RETENTION_SEC,
        "missed": {"events": {}},
        "previous_structure_shadow": {"pending": {}, "open": {}, "closed": [], "skipped": []},
        "auto_buy": False,
    }


def _v1233_metric(rows: list[Dict[str, Any]]) -> Dict[str, Any]:
    values = [_v1233_float(r.get("net_pnl_pct"), default=0.0) for r in rows]
    wins = sum(1 for x in values if x > 0)
    losses = sum(1 for x in values if x < 0)
    return {
        "count": len(rows), "wins": wins, "losses": losses,
        "win_rate": (wins / len(rows) * 100.0) if rows else None,
        "total_pct": sum(values) if values else 0.0,
        "avg_pct": (sum(values) / len(values)) if values else None,
        "avg_mfe_pct": (sum(_v1233_float(r.get("mfe_pct"), default=0.0) for r in rows) / len(rows)) if rows else None,
        "avg_mae_pct": (sum(_v1233_float(r.get("mae_pct"), default=0.0) for r in rows) / len(rows)) if rows else None,
    }


def _v1233_missed_reason(row: Dict[str, Any]) -> str:
    plan = _v1233_nested(row, "dynamic_structure_plan_v1212", "structure_contract_v1212")
    pair = plan.get("pairing_contract_v1229") if isinstance(plan.get("pairing_contract_v1229"), dict) else {}
    inv = int(_v1233_float(pair.get("invalid_candidates"), default=0.0))
    tgt = int(_v1233_float(pair.get("target_candidates"), default=0.0))
    passing = int(_v1233_float(pair.get("passing"), default=0.0))
    cost_complete = pair.get("cost_complete") is not False
    intermediate = plan.get("intermediate_resistance_v1225") if isinstance(plan.get("intermediate_resistance_v1225"), dict) else {}
    if inv > 0 and tgt > 0 and passing == 0 and cost_complete:
        return "risk_reward_pair_shortage"
    if inv > 0 and tgt == 0 and intermediate:
        return "only_intermediate_resistance"
    return ""


def _v1233_update_missed(state: Dict[str, Any], rows: list[Dict[str, Any]], prices: Dict[str, float], nowv: float) -> None:
    root = state.setdefault("missed", {})
    events = root.setdefault("events", {})
    cutoff = nowv - V1233_RETENTION_SEC
    for key in list(events):
        event = events.get(key) if isinstance(events.get(key), dict) else {}
        if _v1233_float(event.get("created_ts"), default=0.0) < cutoff:
            events.pop(key, None)
    for row in rows:
        ticker = _v1233_ticker(row)
        price = _v1233_price(row)
        reason = _v1233_missed_reason(row)
        if not ticker or price <= 0 or not reason:
            continue
        event_id = _v1233_event_identity(row, ticker, f"missed:{reason}")
        event = events.get(event_id)
        if not isinstance(event, dict):
            event = {
                "event_id": event_id, "ticker": ticker, "reason": reason,
                "created_ts": nowv, "created_text": now_text(nowv),
                "start_price": price, "high_price": price, "low_price": price,
                "current_price": price, "last_seen_ts": nowv,
                "candidate_cycle_id": row.get("candidate_pipeline_cycle_id_v1150"),
            }
            events[event_id] = event
    for event in events.values():
        if not isinstance(event, dict):
            continue
        ticker = str(event.get("ticker") or "")
        price = prices.get(ticker, 0.0)
        start = _v1233_float(event.get("start_price"), default=0.0)
        if price <= 0 or start <= 0:
            continue
        event["current_price"] = price
        event["high_price"] = max(_v1233_float(event.get("high_price"), default=price), price)
        event["low_price"] = min(_v1233_float(event.get("low_price"), default=price), price)
        event["last_seen_ts"] = nowv
        event["current_return_pct"] = _v1233_return_pct(price, start)
        event["max_gain_pct"] = _v1233_return_pct(_v1233_float(event.get("high_price"), default=price), start)
        event["max_drawdown_pct"] = _v1233_return_pct(_v1233_float(event.get("low_price"), default=price), start)
        age = max(0.0, nowv - _v1233_float(event.get("created_ts"), default=nowv))
        event["age_sec"] = age
        if age >= V1233_MISSED_HORIZON_SEC and event.get("return_6h_pct") is None:
            event["return_6h_pct"] = event.get("current_return_pct")
            event["completed_6h_ts"] = nowv


def _v1233_shadow_close(root: Dict[str, Any], event_id: str, event: Dict[str, Any], price: float, nowv: float, reason: str) -> None:
    open_map = root.setdefault("open", {})
    open_map.pop(event_id, None)
    entry = _v1233_float(event.get("entry_price"), default=0.0)
    gross = _v1233_return_pct(price, entry) or 0.0
    high = _v1233_float(event.get("high_price"), default=price)
    low = _v1233_float(event.get("low_price"), default=price)
    closed = dict(event)
    closed.update({
        "closed_ts": nowv, "closed_text": now_text(nowv), "close_price": price,
        "exit_reason": reason, "gross_pnl_pct": gross,
        "fee_pct": V1233_SHADOW_FEE_PCT, "net_pnl_pct": gross - V1233_SHADOW_FEE_PCT,
        "mfe_pct": _v1233_return_pct(high, entry) or 0.0,
        "mae_pct": _v1233_return_pct(low, entry) or 0.0,
        "hold_sec": max(0.0, nowv - _v1233_float(event.get("opened_ts"), default=nowv)),
    })
    root.setdefault("closed", []).append(closed)


def _v1233_update_shadow(state: Dict[str, Any], rows: list[Dict[str, Any]], prices: Dict[str, float], nowv: float) -> None:
    root = state.setdefault("previous_structure_shadow", {})
    pending = root.setdefault("pending", {})
    open_map = root.setdefault("open", {})
    closed = root.setdefault("closed", [])
    skipped = root.setdefault("skipped", [])
    cutoff = nowv - V1233_RETENTION_SEC
    root["closed"] = [r for r in closed if isinstance(r, dict) and _v1233_float(r.get("closed_ts"), default=0.0) >= cutoff]
    root["skipped"] = [r for r in skipped if isinstance(r, dict) and _v1233_float(r.get("ts"), default=0.0) >= cutoff]
    closed_ids = {str(r.get("event_id")) for r in root["closed"] if isinstance(r, dict)}
    skipped_ids = {str(r.get("event_id")) for r in root["skipped"] if isinstance(r, dict)}
    for key in list(pending):
        event = pending.get(key) if isinstance(pending.get(key), dict) else {}
        if _v1233_float(event.get("created_ts"), default=0.0) < cutoff:
            pending.pop(key, None)
    for key in list(open_map):
        event = open_map.get(key) if isinstance(open_map.get(key), dict) else {}
        if _v1233_float(event.get("opened_ts"), default=0.0) < cutoff:
            price = prices.get(str(event.get("ticker") or ""), _v1233_float(event.get("last_price"), default=0.0))
            if price > 0:
                _v1233_shadow_close(root, key, event, price, nowv, "REVIEW_24H_TIMEOUT")
            else:
                open_map.pop(key, None)
    for row in rows:
        ticker = _v1233_ticker(row)
        price = _v1233_price(row)
        shadow = row.get("v1211_structure_shadow_v1222") if isinstance(row.get("v1211_structure_shadow_v1222"), dict) else {}
        trigger = _v1233_line_price(shadow.get("trigger"))
        invalid = _v1233_line_price(shadow.get("invalid"))
        target = _v1233_line_price(shadow.get("target"))
        if not ticker or price <= 0 or shadow.get("source_exact") is not True or not (0 < invalid < trigger < target):
            continue
        event_id = _v1233_event_identity(row, ticker, f"v1211:{trigger:.12g}:{invalid:.12g}:{target:.12g}")
        if event_id in pending or event_id in open_map or event_id in closed_ids or event_id in skipped_ids:
            continue
        pending[event_id] = {
            "event_id": event_id, "ticker": ticker, "created_ts": nowv, "created_text": now_text(nowv),
            "trigger_price": trigger, "invalid_price": invalid, "target_price": target,
            "last_price": price, "candidate_cycle_id": row.get("candidate_pipeline_cycle_id_v1150"),
            "source": "v1211_structure_shadow_v1222",
        }
    for event_id in list(pending):
        event = pending.get(event_id) if isinstance(pending.get(event_id), dict) else {}
        ticker = str(event.get("ticker") or "")
        price = prices.get(ticker, _v1233_float(event.get("last_price"), default=0.0))
        trigger = _v1233_float(event.get("trigger_price"), default=0.0)
        invalid = _v1233_float(event.get("invalid_price"), default=0.0)
        target = _v1233_float(event.get("target_price"), default=0.0)
        event["last_price"] = price
        if price <= 0:
            continue
        if price <= invalid:
            pending.pop(event_id, None)
            root["skipped"].append({"event_id":event_id,"ticker":ticker,"ts":nowv,"reason":"INVALID_BEFORE_ENTRY"})
        elif price >= target:
            pending.pop(event_id, None)
            root["skipped"].append({"event_id":event_id,"ticker":ticker,"ts":nowv,"reason":"TARGET_ALREADY_PASSED_BEFORE_OBSERVED_ENTRY"})
        elif price >= trigger:
            pending.pop(event_id, None)
            opened = dict(event)
            opened.update({
                "opened_ts": nowv, "opened_text": now_text(nowv), "entry_price": price,
                "high_price": price, "low_price": price, "last_price": price,
            })
            open_map[event_id] = opened
    for event_id in list(open_map):
        event = open_map.get(event_id) if isinstance(open_map.get(event_id), dict) else {}
        ticker = str(event.get("ticker") or "")
        price = prices.get(ticker, _v1233_float(event.get("last_price"), default=0.0))
        if price <= 0:
            continue
        event["last_price"] = price
        event["high_price"] = max(_v1233_float(event.get("high_price"), default=price), price)
        event["low_price"] = min(_v1233_float(event.get("low_price"), default=price), price)
        invalid = _v1233_float(event.get("invalid_price"), default=0.0)
        target = _v1233_float(event.get("target_price"), default=0.0)
        if price <= invalid:
            _v1233_shadow_close(root, event_id, event, price, nowv, "INVALID")
        elif price >= target:
            _v1233_shadow_close(root, event_id, event, price, nowv, "TARGET")


def _v1233_build_summary(state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    missed_events = [e for e in ((state.get("missed") or {}).get("events") or {}).values() if isinstance(e, dict)]
    primary = [e for e in missed_events if e.get("reason") == "risk_reward_pair_shortage"]
    intermediate_only = [e for e in missed_events if e.get("reason") == "only_intermediate_resistance"]
    missed_top = sorted(missed_events, key=lambda e: _v1233_float(e.get("max_gain_pct"), default=-9999.0), reverse=True)[:5]
    missed_reason_counts: Dict[str, int] = {}
    for event in missed_events:
        reason = str(event.get("reason") or "unknown")
        missed_reason_counts[reason] = missed_reason_counts.get(reason, 0) + 1
    shadow = state.get("previous_structure_shadow") if isinstance(state.get("previous_structure_shadow"), dict) else {}
    closed = [r for r in shadow.get("closed", []) if isinstance(r, dict)]
    windows = {}
    for name, seconds in (("recent_3h",3*3600),("recent_6h",6*3600),("recent_12h",12*3600),("recent_24h",24*3600)):
        windows[name] = _v1233_metric([r for r in closed if _v1233_float(r.get("closed_ts"), default=0.0) >= nowv-seconds])
    reasons: Dict[str,int] = {}
    for row in closed:
        reason = str(row.get("exit_reason") or "UNKNOWN")
        reasons[reason] = reasons.get(reason, 0) + 1
    top_profit = sorted(closed, key=lambda r:_v1233_float(r.get("net_pnl_pct"), default=-9999.0), reverse=True)[:5]
    top_loss = sorted(closed, key=lambda r:_v1233_float(r.get("net_pnl_pct"), default=9999.0))[:5]
    return {
        "schema": V1233_SUMMARY_SCHEMA,
        "version": VERSION, "build": BUILD_LABEL,
        "generated_ts": nowv, "generated_text": now_text(nowv),
        "started_ts": state.get("started_ts"), "started_text": state.get("started_text"),
        "retention_sec": V1233_RETENTION_SEC, "auto_buy": False,
        "missed_current_structure": {
            "scope": "current structure exclusions tracked from first v1233 observation; 6h path; 24h retention",
            "tracked_total": len(missed_events),
            "risk_reward_shortage_count": len(primary),
            "intermediate_only_count": len(intermediate_only),
            "reason_counts": missed_reason_counts,
            "completed_6h": sum(1 for e in missed_events if e.get("return_6h_pct") is not None),
            "completed_6h_risk_reward": sum(1 for e in primary if e.get("return_6h_pct") is not None),
            "completed_6h_intermediate": sum(1 for e in intermediate_only if e.get("return_6h_pct") is not None),
            "positive_max_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) > 0),
            "gain_1_2_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) >= 1.2),
            "gain_3_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) >= 3.0),
            "top": missed_top,
        },
        "previous_structure_shadow": {
            "scope": "v1211 comparison-only virtual trades from v1233 start; unlimited simultaneous virtual OPEN; isolated from Paper",
            "pending_count": len(shadow.get("pending", {}) or {}),
            "open_count": len(shadow.get("open", {}) or {}),
            "closed_count": len(closed),
            "skipped_count": len(shadow.get("skipped", []) or []),
            "windows": windows, "exit_reasons": reasons,
            "fee_pct": V1233_SHADOW_FEE_PCT,
            "top_profit": top_profit, "top_loss": top_loss,
        },
        "invariants": {
            "live_paper_ledger_changed": False, "actual_open_limit_changed": False,
            "actual_entry_exit_changed": False, "shadow_open_limit": None,
            "actual_and_shadow_ledgers_separate": True, "core_ledger_retention_changed": False,
        },
    }


def update_version_score_review(base: Path, rows: Optional[list[Dict[str, Any]]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    state = read_json(version_score_state_path(base), {}) or {}
    if not isinstance(state, dict) or state.get("schema") != V1233_STATE_SCHEMA:
        state = _v1233_empty_state(nowv)
    candidate_rows = rows if isinstance(rows, list) else read_candidate_rows(SpinePaths(base).strategy_candidates, 5000)
    prices = {_v1233_ticker(row): _v1233_price(row) for row in candidate_rows if _v1233_ticker(row) and _v1233_price(row)>0}
    _v1233_update_missed(state, candidate_rows, prices, nowv)
    _v1233_update_shadow(state, candidate_rows, prices, nowv)
    state["updated_ts"] = nowv; state["updated_text"] = now_text(nowv)
    state["candidate_rows"] = len(candidate_rows)
    state["retention_policy"] = "only v1233 review/shadow state is pruned after 24h; core ledgers untouched"
    summary = _v1233_build_summary(state, nowv)
    atomic_write_json(version_score_state_path(base), state)
    atomic_write_json(version_score_summary_path(base), summary)
    return summary


def base_dir() -> Path:
    override = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(override).expanduser().resolve() if override else Path(__file__).resolve().parent


def status_path(base: Path) -> Path:
    return base / "clean_review_worker_status.json"


def error_path(base: Path) -> Path:
    return base / "clean_review_worker_error.log"


def pid_path(base: Path) -> Path:
    return base / "review_worker.pid"


def lock_path(base: Path) -> Path:
    return base / "runtime" / "review_worker_singleton_v1121.lock"


def log_error(base: Path, where: str, exc: BaseException) -> None:
    path = error_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    message = (
        f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n"
        f"{traceback.format_exc()[-4000:]}\n"
    )
    with path.open("a", encoding="utf-8") as handle:
        handle.write(message)


def write_status(base: Path, state: str, **extra: Any) -> Dict[str, Any]:
    health_state = str(state or "COLLECTING").upper()
    runtime_state = "error" if health_state == "ERROR" else ("stopped" if health_state == "STOPPED" else "running")
    payload: Dict[str, Any] = {
        "schema": "review_worker_status_v1183",
        "version": VERSION,
        "build": BUILD_LABEL,
        "running": runtime_state == "running",
        "state": runtime_state,
        "health_state": health_state,
        "phase": extra.pop("phase", health_state.lower()),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "pid": os.getpid(),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "owner": "review_worker_single_candidate_standard_owner_v1215",
        "live_ledger_write": False,
    }
    payload.update(extra)
    # Guard convenience metrics; aliases only, no Review calculation or owner change.
    payload["row_count"] = integer(payload.get("candidate_rows"), payload.get("row_count"), default=0)
    payload["last_sec"] = num(payload.get("last_cycle_sec"), payload.get("last_sec"), default=0.0)
    payload["closed_recent"] = integer(payload.get("performance_count"), payload.get("closed_recent"), default=0)
    atomic_write_json(status_path(base), payload)
    return payload


def acquire_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    path = lock_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError("review_worker v1181 already running") from exc
    acquired_ts = now_ts()
    handle.seek(0)
    handle.truncate(0)
    handle.write(__import__("json").dumps({
        "schema": "review_worker_singleton_lock_v1183",
        "pid": os.getpid(),
        "version": VERSION,
        "build": BUILD_LABEL,
        "acquired_ts": acquired_ts,
        "acquired_text": now_text(),
        "lock_path": str(path),
    }, ensure_ascii=False, separators=(",", ":")))
    handle.flush()
    os.fsync(handle.fileno())
    _LOCK_HANDLE = handle
    pid_path(base).write_text(str(os.getpid()), encoding="utf-8")


def release_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    try:
        if _LOCK_HANDLE is not None:
            fcntl.flock(_LOCK_HANDLE.fileno(), fcntl.LOCK_UN)
            _LOCK_HANDLE.close()
    except OSError:
        pass
    _LOCK_HANDLE = None
    try:
        pid_path(base).unlink(missing_ok=True)
    except OSError:
        pass


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def _v1195_review_commit_view(snapshot: Any, standard: Any) -> Dict[str, Any]:
    """Validate and normalize one Review generation before any file commit.

    Review previously wrote the canonical snapshot first and only afterwards
    dereferenced nested fields for its event/status payload.  A malformed or
    temporarily missing nested object could therefore leave a current snapshot
    on disk while the worker status switched to ERROR.  Build every scalar used
    by the commit before writing either canonical file, and fail with an exact
    contract error instead of an ambiguous ``NoneType.get`` exception.
    """
    if not isinstance(snapshot, dict):
        raise TypeError(f"review snapshot contract expected dict, got {type(snapshot).__name__}")
    if not isinstance(standard, dict):
        raise TypeError(f"candidate standard contract expected dict, got {type(standard).__name__}")
    source = mapping(snapshot.get("source"))
    candidate = mapping(snapshot.get("candidate"))
    performance = mapping(snapshot.get("performance"))
    return {
        "pipeline_cycle_id": source.get("pipeline_cycle_id"),
        "candidate_commit_id": source.get("candidate_commit_id"),
        "source_state": source.get("state"),
        "review_snapshot_id": snapshot.get("snapshot_id"),
        "candidate_standard_state": standard.get("state"),
        "candidate_rows": candidate.get("total"),
        "performance_count": integer(performance.get("count"), default=0),
    }


def process_once(base: Path, force: bool = False) -> Dict[str, Any]:
    paths = SpinePaths(base)
    request = read_json(paths.review_request, {}) or {}
    prior = read_json(paths.review_snapshot, {}) or {}
    request_identity = (
        str(request.get("candidate_commit_id") or request.get("candidate_commit_id_v1150") or ""),
        str(request.get("pipeline_cycle_id") or request.get("candidate_pipeline_cycle_id_v1150") or ""),
    )
    prior_source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
    prior_identity = (
        str(prior_source.get("candidate_commit_id") or ""),
        str(prior_source.get("pipeline_cycle_id") or ""),
    )
    if not force and request_identity == prior_identity and prior_identity != ("", ""):
        version_score_review = update_version_score_review(base)
        return {
            "processed": False,
            "reason": "same_committed_generation",
            "snapshot_id": prior.get("snapshot_id"),
            "candidate_rows": (prior.get("candidate") or {}).get("total") if isinstance(prior.get("candidate"), dict) else None,
            "version_score_review": version_score_review,
        }

    started = time.monotonic()
    write_status(
        base,
        "RUNNING",
        phase="candidate_standard_build",
        current_pipeline_cycle_id=request_identity[1] or None,
        current_candidate_commit_id=request_identity[0] or None,
    )
    snapshot = build_review_snapshot(base, request=request)
    standard = build_candidate_standard(snapshot)
    commit_view = _v1195_review_commit_view(snapshot, standard)
    event = {
        "schema": "review_generation_event_v1181",
        "event": "REVIEW_GENERATION_COMMITTED",
        "created_ts": now_ts(),
        "created_text": now_text(),
        "pipeline_cycle_id": commit_view["pipeline_cycle_id"],
        "candidate_commit_id": commit_view["candidate_commit_id"],
        "review_snapshot_id": commit_view["review_snapshot_id"],
        "candidate_standard_state": commit_view["candidate_standard_state"],
        "candidate_rows": commit_view["candidate_rows"],
        "live_ledger_write": False,
        "auto_buy": False,
    }
    # Commit boundary: every nested field used by event/status is normalized
    # before either canonical file becomes visible.
    atomic_write_json(paths.review_snapshot, snapshot)
    atomic_write_json(paths.candidate_standard, standard)
    append_jsonl(base / "review_generation_events_v1181.jsonl", event)
    version_score_review = update_version_score_review(base, read_candidate_rows(paths.strategy_candidates, 5000))
    elapsed = max(0.0, time.monotonic() - started)
    write_status(
        base,
        "NORMAL",
        phase="idle",
        last_success_ts=now_ts(),
        last_cycle_sec=round(elapsed, 6),
        last_pipeline_cycle_id=event["pipeline_cycle_id"],
        last_candidate_commit_id=event["candidate_commit_id"],
        last_review_snapshot_id=event["review_snapshot_id"],
        candidate_standard_state=event["candidate_standard_state"],
        candidate_rows=event["candidate_rows"],
        performance_count=commit_view["performance_count"],
        source_state=commit_view["source_state"],
        snapshot_digest=digest_obj(snapshot),
        review_commit_contract_v1195=True,
        review_commit_values_normalized_before_files_v1195=True,
        version_score_review_v1233=True,
        version_score_shadow_open_count=((version_score_review.get("previous_structure_shadow") or {}).get("open_count")),
        version_score_missed_count=((version_score_review.get("missed_current_structure") or {}).get("risk_reward_shortage_count")),
    )
    return {
        "processed": True,
        "elapsed_sec": elapsed,
        "snapshot": snapshot,
        "candidate_standard": standard,
        "version_score_review": version_score_review,
    }


def run_loop(base: Path, interval_sec: float) -> int:
    acquire_singleton(base)
    atexit.register(release_singleton, base)
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    write_status(base, "STARTING", phase="boot")
    last_heartbeat = 0.0
    consecutive_errors = 0
    while not _STOP:
        try:
            result = process_once(base)
            if not isinstance(result, dict):
                raise RuntimeError(f"review process_once contract returned {type(result).__name__}")
            consecutive_errors = 0
            now = now_ts()
            if not result.get("processed") and now - last_heartbeat >= HEARTBEAT_SEC:
                prior = read_json(SpinePaths(base).review_snapshot, {}) or {}
                source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
                candidate = prior.get("candidate") if isinstance(prior.get("candidate"), dict) else {}
                write_status(
                    base,
                    "NORMAL" if prior else "COLLECTING",
                    phase="idle",
                    last_review_snapshot_id=prior.get("snapshot_id"),
                    last_pipeline_cycle_id=source.get("pipeline_cycle_id"),
                    last_candidate_commit_id=source.get("candidate_commit_id"),
                    candidate_rows=candidate.get("total"),
                    heartbeat=True,
                )
                last_heartbeat = now
        except Exception as exc:  # fail visible; no stale fallback
            consecutive_errors += 1
            log_error(base, "review_loop", exc)
            write_status(
                base,
                "ERROR",
                phase="error",
                last_error=f"{type(exc).__name__}: {exc}",
                consecutive_errors=consecutive_errors,
            )
        slept = 0.0
        while slept < interval_sec and not _STOP:
            step = min(0.2, interval_sec - slept)
            time.sleep(step)
            slept += step
    write_status(base, "STOPPED", phase="shutdown")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", default="")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SEC)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    base = Path(args.base_dir).expanduser().resolve() if args.base_dir else base_dir()
    if args.once:
        result = process_once(base, force=args.force)
        print(result.get("candidate_standard") or result)
        return 0
    return run_loop(base, max(0.5, args.interval))


# v1190 read-only phase timing evidence
from runtime_phase_probe_v1190 import wrap_function as _v1190_wrap_function
_v1190_wrap_function(globals(), "process_once", "review", "cycle", VERSION, 300.0)

if __name__ == "__main__":
    raise SystemExit(main())
