coinbot_update_v1425

목적:
- S2 정확 재확인 후보 중 실제 승격 가능 후보를 shadow-only로 분리 표시
- 5승 1패인데 손익이 마이너스가 되는 청산 손익누수 문제를 /exit_leak으로 분리 감사

변경:
- bot.py / coinbot_main_v2_13_1425.py
- strategy_worker.py / strategy_worker_v1.425.py

변경하지 않음:
- 실제 Paper handoff
- 실제 OPEN
- Gate / TTL / RR / trigger / invalid / target / exit 계약 / OPEN limit
- 자동매수 OFF
- 핵심 거래 원장

검수:
- python -m py_compile PASS
- 서버 적용 후 /flow_map_full /candidate_standard /missed_where /s2_recheck /s2_promotion /exit_leak /version_score /errorlog 확인
