# v1077 Strategy candidate writer 감사 경로 경량화

## 기준

- 기준 버전: v1076 자원 owner 감사 완료
- 신규 버전: v1077
- 전략모드: ALT_SWING
- 자동매수: OFF
- 서버 적용 전 상태: CHECK

## 증상

v1076 서버 측정에서 Strategy 전체 cycle은 26.64초였고 다음 구간이 크게 잡혔다.

- structure_lab: 6.09초
- candidate_writer_full_row_audit: 5.18초
- observation_good_s2_and_s1_hold: 3.82초

`structure_lab`은 실제 전략 계산이므로 첫 수술 대상에서 제외했다. `candidate_writer_full_row_audit`은 후보 저장 전 감사·상태 집계 경로이므로 전략 영향 없이 제거 가능한 내부 낭비부터 추적했다.

## 실제 원인

`collect_freshness_missing_status()`가 후보 461개의 거대한 중첩 row 전체를 매 cycle `str(row)`로 변환하고 `999999` 문자열을 검색했다.

- 목적: 오래된 freshness sentinel 표시 감사
- 소비 reader: 0개
- 후보선별·S1·Paper 진입·청산 사용: 0개
- 비용: 실제 후보 압축 전에 전체 중첩 payload를 다시 순회·문자열 할당

추가로 11개 상태 collector가 앞 collector 결과가 누적된 dict를 매번 복사했다. collector들은 이전 collector 결과를 읽지 않는 순수 상태 생산자임을 정적 확인했다.

## 값 owner

- 후보 writer: `strategy_worker._v1021_publish_candidate_snapshot`
- 감사 집계: `strategy_worker._v1021_collect_candidate_publish_status`
- 제거 대상: `collect_freshness_missing_status`의 full-row `str(row)` sentinel scan
- canonical candidate 파일과 compactor owner는 변경하지 않음

## 수정 파일

- `strategy_worker_v0.993.py`
- `backga_guard_bot_v2_5_132.py`

## 삭제한 구 경로

- 모든 full candidate row를 문자열로 변환해 `999999`를 찾던 미사용 감사 경로
- 11개 collector 사이에서 누적 status payload를 반복 복사하던 전달 방식

## 새 본선

- freshness missing field 카운터는 기존처럼 유지
- collector는 각자 delta만 생산하고 canonical status dict에 한 번 merge
- candidate compactor, atomic write, decision key, trigger/invalid/target은 기존 그대로
- collector별 소요시간을 canonical writer status에 기록

## 로컬 검수

- py_compile PASS
- top-level 중복 정의 0
- 기존/신규 full-row mutation 동일
- 기존/신규 compact candidate payload 동일
- 제거 metric reader 0
- 합성 중첩 row audit 시험: 0.004592초 → 0.001245초, 72.9% 감소
- Guard 검수 명령 모의 실행 DONE

합성 시험은 서버 성능 증명이 아니다. 실제 판정은 서버 다음 candidate commit에서 `/gstrategy_writer_v1077 35`로 확인한다.

## 서버 검수

- Strategy runtime `strategy_worker_v0.993`
- active/target hash 일치
- 다음 candidate commit 증가
- writer result OK
- validation failure 0
- hard ceiling 0
- role/source consistency true
- candidate JSON parse 오류 0
- S1 decision/trigger/invalid/target 누락 0
- exact duplicate/key_missing/unlinked 0/0/0
- 자동매수 OFF
- candidate_writer_full_row_audit가 v1076 기준 5.18초보다 감소

## 전략 영향

- S1/S2/S3 기준 변경 0
- trigger·invalid·target·RR 변경 0
- 진입·청산·OPEN 한도 변경 0
- OPEN/CLOSED/decision/exact 원장 변경·삭제 0
- 자동매수 OFF
