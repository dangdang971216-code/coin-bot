#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_bot_v0.217_v602_final_trade_state_open_only_2026-05-31

목적:
- v0.50/v389/v397 계열의 무거운 paper runtime을 더 이상 타지 않는다.
- paper 실행기는 S1 후보 읽기 → OPEN → 기존 OPEN 청산 → 장부 저장 → 알림만 담당한다.
- OPEN/CLOSED/trade_log 장부는 보존하고, 전체 CLOSED 재계산/복기/score full 계산은 실행 루프에서 제외한다.
- v416/v0.127: paper OPEN 직전 최종 안전문을 직접 확인하고, 약한 체결/넓은 스프레드/미끄러짐 후보를 장부 OPEN 전에 보류한다.
- v479: 무반응 S1은 폐기/차단이 아니라 paper OPEN만 보류하고 다음 recheck cycle에 맡긴다.
"""

from __future__ import annotations

import json
import os
import signal
import sys
import time
import traceback
import re
import urllib.parse
import urllib.request
from collections import Counter, deque
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = 'paper_bot_v0.217'
BUILD_LABEL = 'v602_final_trade_state_open_only'
BASE_DIR = Path(__file__).resolve().parent

FILES: Dict[str, Path] = {
    "paper_latest": BASE_DIR / "paper_candidates_latest.jsonl",
    "open": BASE_DIR / "paper_bot_open.json",
    "closed": BASE_DIR / "paper_bot_closed.jsonl",
    "status": BASE_DIR / "paper_bot_status.json",
    "control": BASE_DIR / "paper_bot_control.json",
    "pid": BASE_DIR / "paper_bot.pid",
    "trace": BASE_DIR / "paper_bot_candidate_handoff_trace.json",
    "handoff_status": BASE_DIR / "paper_bot_candidate_handoff_status.json",
    "score": BASE_DIR / "paper_bot_score_cache.json",
    "trade_review": BASE_DIR / "paper_bot_trade_review_cache.json",
    "open_alert_trace": BASE_DIR / "paper_bot_open_alert_trace.jsonl",
    "hot_rank": BASE_DIR / "clean_scanner_hot_rank_cache.json",
    "error": BASE_DIR / "paper_bot_error.log",
    "log": BASE_DIR / "paper_bot.log",
}

DEFAULT_CONTROL: Dict[str, Any] = {
    "running": True,
    "loop_seconds": 8,
    "open_monitor_interval_sec": 2.0,
    "max_open_strict": 0,
    "max_new_per_cycle": 0,
    "new_open_paused": False,
    "open_trade_ready_only": True,
    "notify_on_strict_open": True,
    "notify_on_strict_close": True,
    "notify_on_s1_decision_summary": True,
    "notify_s1_decision_summary_interval_sec": 3600,
    "notify_s1_decision_summary_min_interval_sec": 3600,  # backward compat
    "notify_open_min_score": 4.45,
    "notify_open_require_micro_fresh": True,
    "notify_open_require_ws_fresh": False,
    "preopen_micro_recheck": True,
    "preopen_micro_urgent_ttl_sec": 35,
    "paper_final_reaction_proof_enabled": True,
    "paper_final_reaction_proof_mode": "recheck_hold",
    "paper_final_reaction_proof_min_windows": 2,
    "paper_final_reaction_proof_min_flow_pct": 0.01,
    "block_same_ticker_open": True,
    "candidate_ttl_sec": 120,
    "candidate_read_max_lines": 800,
    "consume_latest_scan_only": True,
    "write_score_cache": True,
    "latest_scan_window_sec": 8,
    "fee_pct_roundtrip": 0.10,
    "take_profit_pct": 1.20,
    "protect_trigger_pct": 0.70,
    "protect_floor_pct": 0.35,
    "protect_strong_trigger_pct": 1.00,
    "protect_strong_floor_pct": 0.50,
    "protect_big_trigger_pct": 1.40,
    "protect_big_floor_pct": 0.75,
    "protect_giveback_pct": 0.55,
    "stop_loss_pct": -0.55,
    "fast_fail_after_min": 2.5,
    "fast_fail_peak_under_pct": 0.20,
    "fast_fail_loss_pct": -0.35,
    "fast_fail_after_min_late": 5.0,
    "fast_fail_loss_pct_late": -0.25,
    "slow_minutes": 20,
    "slow_peak_under_pct": 0.25,
    "time_exit_minutes": 15,
    # v486: 손실은 빠르게, 수익권은 조건부로 길게 본다.
    "profit_soft_protect_trigger_pct": 0.45,
    "profit_soft_protect_floor_pct": 0.10,
    "profit_soft_protect_giveback_pct": 0.45,
    "profit_run_extend_enabled": True,
    "profit_run_extend_minutes": 15,
    "profit_run_extend_max_count": 1,
    "profit_run_extend_min_net_pct": 0.20,
    "profit_run_extend_min_peak_pct": 0.25,
    "profit_run_extend_max_giveback_pct": 0.25,
    "profit_run_strategy_keywords": ["주도", "유동보유", "leader", "momentum"],
    "notify_market_hot_alert": True,
    "notify_market_hot_immediate_enabled": False,
    "notify_market_hot_summary_interval_sec": 3600,
    "notify_market_hot_immediate_min_interval_sec": 3600,  # backward compat
    "notify_market_hot_global_min_interval_sec": 3600,
    "notify_market_hot_ticker_cooldown_sec": 3600,
    "notify_market_hot_1m_pct": 0.80,
    "notify_market_hot_3m_pct": 1.50,
    "notify_market_hot_immediate_1m_pct": 1.50,
    "notify_market_hot_immediate_3m_pct": 2.50,
    "notify_market_hot_rank_top_n": 5,
    "notify_market_hot_max_items": 4,
    "notify_market_hot_cache_ttl_sec": 90,
    "notify_entry_timing_trace": True,
}

TOKEN = os.getenv("PAPER_BOT_TOKEN", os.getenv("TELEGRAM_TOKEN", "")).strip()
ALLOWED_CHAT_ID = (
    os.getenv("PAPER_BOT_ALLOWED_CHAT_ID", "").strip()
    or os.getenv("PAPER_BOT_CHAT_ID", "").strip()
    or os.getenv("CHAT_ID", "").strip()
    or os.getenv("GUARD_CHAT_ID", "").strip()
)
NOTIFY_CHAT_ID = os.getenv("PAPER_BOT_NOTIFY_CHAT_ID", "").strip() or ALLOWED_CHAT_ID

_STOP = False
_STOP_REASON = "running"
_STARTED_TS = time.time()
_LAST_PRICE_CACHE: Dict[str, Any] = {"ts": 0.0, "prices": {}}
_LAST_STATUS: Dict[str, Any] = {}
_LAST_CLOSED_COUNT_CACHE: Dict[str, Any] = {"ts": 0.0, "count": 0}
_TG_OFFSET = 0
_LAST_S1_DECISION_NOTIFY: Dict[str, Any] = {"ts": 0.0, "key": ""}
_S1_DECISION_SUMMARY_BUCKET: Dict[str, Any] = {}
_HOT_MARKET_NOTIFY_BUCKET: Dict[str, Any] = {}


def now_ts() -> float:
    return time.time()


def iso_ts(ts: Optional[float] = None) -> str:
    import datetime as _dt
    return _dt.datetime.fromtimestamp(ts or now_ts()).strftime("%Y-%m-%d %H:%M:%S")


def fnum(*vals: Any, default: float = 0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "":
                continue
            if isinstance(v, str):
                v = v.replace(",", "").replace("%", "").strip()
            return float(v)
        except Exception:
            continue
    return default


def log(msg: str) -> None:
    try:
        with FILES["log"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {msg}\n")
    except Exception:
        pass


def log_error(where: str, exc: BaseException) -> None:
    try:
        with FILES["error"].open("a", encoding="utf-8") as f:
            f.write(f"[{iso_ts()}] {where}: {type(exc).__name__}: {exc}\n")
            f.write(traceback.format_exc() + "\n")
    except Exception:
        pass


def atomic_write_text(path: Path, text: str) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def save_json(path: Path, obj: Any) -> None:
    try:
        atomic_write_text(path, json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
    except Exception as exc:
        log_error(f"save_json:{path.name}", exc)


def load_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception as exc:
        log_error(f"load_json:{path.name}", exc)
        return default


def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    try:
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":")) + "\n")
    except Exception as exc:
        log_error(f"append_jsonl:{path.name}", exc)


def tail_lines(path: Path, max_lines: int) -> List[str]:
    if not path.exists():
        return []
    dq: deque[str] = deque(maxlen=max_lines)
    try:
        with path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                if line.strip():
                    dq.append(line.rstrip("\n"))
    except Exception as exc:
        log_error(f"tail_lines:{path.name}", exc)
    return list(dq)


def read_jsonl_tail(path: Path, max_lines: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for line in tail_lines(path, max_lines):
        try:
            row = json.loads(line)
            if isinstance(row, dict):
                out.append(row)
        except Exception:
            continue
    return out


def line_count_cached(path: Path, ttl: float = 60.0) -> int:
    ts = now_ts()
    if ts - float(_LAST_CLOSED_COUNT_CACHE.get("ts") or 0.0) < ttl:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)
    try:
        if not path.exists():
            cnt = 0
        else:
            with path.open("rb") as f:
                cnt = sum(1 for _ in f)
        _LAST_CLOSED_COUNT_CACHE.update({"ts": ts, "count": cnt})
        return cnt
    except Exception:
        return int(_LAST_CLOSED_COUNT_CACHE.get("count") or 0)


def normalize_ticker(v: Any) -> str:
    if v is None:
        return ""
    t = str(v).strip().upper().replace("/", "-").replace("_", "-")
    if not t:
        return ""
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        return (non[-1] if non else parts[-1]).strip().upper()
    if t.endswith("KRW") and len(t) > 3:
        return t[:-3].strip().upper()
    return t


def row_ts(row: Dict[str, Any], *keys: str) -> float:
    for k in keys:
        v = row.get(k)
        x = fnum(v, default=0.0)
        if x > 1000000000:
            return x
        if isinstance(v, str) and v:
            try:
                import datetime as _dt
                return _dt.datetime.fromisoformat(v.replace("Z", "+00:00")).timestamp()
            except Exception:
                pass
    return 0.0


def event_time(row: Dict[str, Any]) -> float:
    return row_ts(row, "expires_at", "candidate_expires_at", "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def event_created_ts(row: Dict[str, Any]) -> float:
    return row_ts(row, "created_at", "candidate_created_at", "source_created_at", "detected_ts", "event_ts", "ts", "timestamp")


def load_control() -> Dict[str, Any]:
    saved = load_json(FILES["control"], {})
    ctrl = dict(DEFAULT_CONTROL)
    if isinstance(saved, dict):
        ctrl.update(saved)
    # v400: paper 실행기는 기본 ON. 사용자가 명시적으로 running=false로 저장한 경우만 정지한다.
    if "running" not in ctrl:
        ctrl["running"] = True
    return ctrl


def write_pid() -> None:
    try:
        FILES["pid"].write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass


def load_open() -> Dict[str, Dict[str, Any]]:
    obj = load_json(FILES["open"], {})
    return obj if isinstance(obj, dict) else {}


def save_open(open_pos: Dict[str, Dict[str, Any]]) -> None:
    save_json(FILES["open"], open_pos if isinstance(open_pos, dict) else {})


def open_tickers(open_pos: Dict[str, Dict[str, Any]]) -> set[str]:
    return {normalize_ticker(p.get("ticker")) for p in open_pos.values() if isinstance(p, dict) and normalize_ticker(p.get("ticker"))}


def closed_recent_ids(limit: int = 2000) -> set[str]:
    ids: set[str] = set()
    for r in read_jsonl_tail(FILES["closed"], limit):
        for k in ("pos_id", "event_id", "trace_id", "handoff_id", "candidate_uid"):
            v = str(r.get(k) or "").strip()
            if v:
                ids.add(v)
    return ids


def event_id(ev: Dict[str, Any], lane: str = "strict") -> str:
    for k in ("event_id", "event_key", "trace_id", "handoff_id", "candidate_uid", "id"):
        v = str(ev.get(k) or "").strip()
        if v:
            return v
    t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")) or "UNKNOWN"
    scan = str(ev.get("scan_id") or ev.get("source_scan_id") or ev.get("strategy_scan_id") or "")[:40]
    created = int(event_created_ts(ev) or now_ts())
    score = fnum(ev.get("score"), ev.get("leader_score"), default=0.0)
    return f"{lane}:{t}:{scan}:{created}:{score:.3f}"




def candidate_brief(ev: Dict[str, Any], status: str = "", reason: str = "") -> Dict[str, Any]:
    """paper handoff 상태판용 짧은 후보 요약.

    OPEN 여부를 바꾸지 않고, S1이 paper까지 왔는지/왜 막혔는지만 남긴다.
    """
    try:
        ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
        diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    except Exception:
        diag = {}
    return {
        "ticker": normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol")),
        "event_id": event_id(ev, "strict"),
        "stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade"),
        "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "status": status or "seen",
        "reason": reason or "-",
        "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
        "seen_at": now_ts(),
        "seen_at_text": iso_ts(),
        "price_reaction_pct": fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0,
        "spread_pct": fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_ratio": fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "buy_sustain_1m": fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0,
        "block_reasons": list(ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons") or [])[:8] if isinstance((ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons")), list) else [],
    }


def _record_decision(stats: Dict[str, Any], key: str, ev: Dict[str, Any], status: str, reason: str = "") -> None:
    brief = candidate_brief(ev, status=status, reason=reason)
    stats[key] = brief
    rows = stats.get("recent_s1_decisions")
    if not isinstance(rows, list):
        rows = []
    rows.append(brief)
    stats["recent_s1_decisions"] = rows[-12:]

def get_event_price(ev: Dict[str, Any]) -> float:
    for k in ("live_price", "current_price", "price", "trade_price", "close", "last_price", "entry_price", "detected_price"):
        x = fnum(ev.get(k), default=0.0)
        if x > 0:
            return x
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for k in ("live_price", "current_price", "price", "close"):
        x = fnum(ctx.get(k), default=0.0)
        if x > 0:
            return x
    return 0.0


def fetch_all_prices_cached(ttl: float = 4.0) -> Dict[str, float]:
    ts = now_ts()
    if ts - float(_LAST_PRICE_CACHE.get("ts") or 0.0) < ttl:
        return dict(_LAST_PRICE_CACHE.get("prices") or {})
    prices: Dict[str, float] = {}
    try:
        req = urllib.request.Request(
            "https://api.bithumb.com/public/ticker/ALL_KRW",
            headers={"Accept": "application/json", "User-Agent": VERSION},
        )
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        raw = data.get("data") if isinstance(data, dict) else {}
        if isinstance(raw, dict):
            for k, v in raw.items():
                if not isinstance(v, dict):
                    continue
                t = normalize_ticker(k)
                p = fnum(v.get("closing_price"), v.get("close"), default=0.0)
                if t and p > 0:
                    prices[t] = p
    except Exception as exc:
        log_error("fetch_all_prices", exc)
    if prices:
        _LAST_PRICE_CACHE.update({"ts": ts, "prices": prices})
    return prices


def live_price(ticker: str, fallback: float = 0.0) -> float:
    t = normalize_ticker(ticker)
    prices = fetch_all_prices_cached()
    return float(prices.get(t) or fallback or 0.0)


def candidate_is_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    nowv = now_ts()
    exp = row_ts(ev, "expires_at", "candidate_expires_at")
    if exp > 0:
        return exp >= nowv
    created = event_created_ts(ev)
    if created > 0:
        return (nowv - created) <= fnum(ctrl.get("candidate_ttl_sec"), default=120.0)
    # latest 파일 자체가 방금 갱신된 경우에만 timestamp 없는 후보를 관찰 대상으로 둔다. OPEN은 하지 않는다.
    return False


def micro_fresh(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    vals = [ev, ctx]
    for obj in vals:
        if bool(obj.get("micro_fresh")):
            return True
        if str(obj.get("micro_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        age = fnum(obj.get("micro_age_sec"), default=999999.0)
        if age <= fnum(ctrl.get("preopen_micro_urgent_ttl_sec"), default=35.0):
            return True
    return False


def ws_fresh(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    for obj in (ev, ctx):
        if bool(obj.get("ws_fresh")):
            return True
        if str(obj.get("ws_row_status") or "").lower() in {"fresh", "ok", "true", "1"}:
            return True
        if fnum(obj.get("ws_age_sec"), default=999999.0) <= 30:
            return True
    return False


def _pressure_is_bad(v: Any) -> bool:
    if v in (None, ""):
        return False
    if isinstance(v, bool):
        return bool(v)
    try:
        # 숫자형 압력값은 보수적으로 0.60 이상이면 부담으로 본다.
        return float(v) >= 0.60
    except Exception:
        s = str(v).strip().lower()
        if s in {"false", "0", "none", "no", "ok", "good", "low", "정상", "없음"}:
            return False
        return any(x in s for x in ("bad", "high", "pressure", "wall", "부담", "압력", "매도"))


def _version_from_text(txt: Any) -> str:
    s = str(txt or "").strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_\.]13[_\.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    return ""


_ACTIVE_MAIN_VERSION_CACHE: Dict[str, Any] = {"ts": 0.0, "version": "", "source": ""}


def _deployed_main_version_detail() -> Tuple[str, str]:
    """실제 적용된 메인봇 버전과 출처.

    v460 단일 본선:
    - DEPLOY_TARGET.txt는 구값(v2.13.320)이 남는 경우가 있어 마지막 fallback으로만 쓴다.
    - paper 성과판은 현재 실행 중인 메인봇 상태파일/실제 배포파일을 우선한다.
    - CLOSED 장부 원본은 수정하지 않고, score cache 집계 시점에만 보정한다.
    """
    candidates: List[Tuple[str, str]] = []

    # 1) 메인봇 heartbeat/status. 실제 실행 중인 BOT_VERSION이 가장 안전하다.
    for name in ("clean_brain_status.json", "clean_resource_status.json"):
        try:
            obj = json.loads((BASE_DIR / name).read_text(encoding="utf-8", errors="ignore"))
            if isinstance(obj, dict):
                for key in ("version", "bot_version", "main_version", "BOT_VERSION"):
                    v = _version_from_text(obj.get(key))
                    if v:
                        candidates.append((v, f"{name}:{key}"))
        except Exception:
            pass

    # 2) guard가 실제 배포 완료 후 남기는 단일 진실값 후보들.
    for name in (".deployed_target", ".deployed_main_target", ".active_main_target", "deployed_target.txt"):
        try:
            txt = (BASE_DIR / name).read_text(encoding="utf-8", errors="ignore").strip()
            v = _version_from_text(txt)
            if v:
                candidates.append((v, name))
        except Exception:
            pass

    # 3) 현재 bundle main 항목. paper-only bundle이면 main이 없을 수 있으므로 보조로만 사용.
    try:
        obj = json.loads((BASE_DIR / "DEPLOY_BUNDLE.json").read_text(encoding="utf-8", errors="ignore"))
        if isinstance(obj, dict):
            for key in ("main", "target", "deploy_target", "main_file"):
                v = _version_from_text(obj.get(key))
                if v:
                    candidates.append((v, f"DEPLOY_BUNDLE.json:{key}"))
    except Exception:
        pass

    # 4) bot.py/메인 파일 내부 BOT_VERSION. 짧은 앞부분만 읽어서 무거운 경로를 피한다.
    for name in ("bot.py",):
        try:
            path = BASE_DIR / name
            if path.exists():
                txt = path.read_text(encoding="utf-8", errors="ignore")[:20000]
                v = _version_from_text(txt)
                if v:
                    candidates.append((v, f"{name}:BOT_VERSION"))
        except Exception:
            pass

    # 5) 서버에 놓인 최신 coinbot_main 파일명.
    try:
        best = 0
        for f in BASE_DIR.glob("coinbot_main_v2_13_*.py"):
            m = re.search(r"coinbot_main_v2_13_(\d+)\.py$", f.name)
            if m:
                best = max(best, int(m.group(1)))
        if best:
            candidates.append((f"v2.13.{best}", "latest_coinbot_main_file"))
    except Exception:
        pass

    # 6) 마지막 fallback: 구 DEPLOY_TARGET. 단독으로만 쓴다.
    legacy = _legacy_deploy_target_version()
    if candidates:
        # paper-only bundle/구파일 혼재 시 가장 높은 v2.13.xxx를 실제 적용 후보로 본다.
        def _n(item: Tuple[str, str]) -> int:
            m = re.search(r"v2\.13\.(\d+)", item[0])
            return int(m.group(1)) if m else 0
        best = max(candidates, key=_n)
        return best
    if legacy:
        return legacy, "DEPLOY_TARGET.txt:fallback"
    return "", ""


def _deployed_main_version() -> str:
    v, _src = _deployed_main_version_detail()
    return v


def _legacy_deploy_target_version() -> str:
    try:
        txt = (BASE_DIR / "DEPLOY_TARGET.txt").read_text(encoding="utf-8", errors="ignore").strip()
        return _version_from_text(txt)
    except Exception:
        return ""


def active_main_version_detail(ttl: float = 3.0) -> Tuple[str, str]:
    ts = now_ts()
    if ts - float(_ACTIVE_MAIN_VERSION_CACHE.get("ts") or 0.0) < ttl:
        return str(_ACTIVE_MAIN_VERSION_CACHE.get("version") or ""), str(_ACTIVE_MAIN_VERSION_CACHE.get("source") or "")
    v, src = _deployed_main_version_detail()
    _ACTIVE_MAIN_VERSION_CACHE.update({"ts": ts, "version": v, "source": src})
    return v, src


def active_main_version() -> str:
    """성과판용 현재 메인봇 버전.

    실제 실행/배포값을 우선하고, 오래된 DEPLOY_TARGET.txt는 마지막 fallback으로만 사용한다.
    """
    v, _src = active_main_version_detail()
    return v




def _paper_v488_reason_kind(text: Any) -> Tuple[str, str, str]:
    raw = str(text or '').strip()
    compact = raw.replace(' ', '').replace('_', '').replace('-', '').lower()
    if not raw:
        return ('ignore', '', '')
    if '전략조건 재확인 보류' in raw:
        return ('entry_decision', 'entry_decision', raw)
    if any(k in raw for k in ('스프레드 과다', '스프레드과다', '스프레드 부담', '스프레드부담', '진입 직전 스프레드')):
        return ('exec', 'spread', raw)
    if any(k in raw for k in ('미끄러짐', '슬리피지')):
        return ('exec', 'slippage', raw)
    if any(k in raw for k in ('매도압력', '매도벽')):
        return ('exec', 'sell_pressure', '진입 직전 매도벽/매도압력 부담')
    if '무반응' in raw:
        return ('exec', 'no_reaction', raw)
    if '호가·체결' in raw or 'micro' in compact:
        return ('fresh', 'micro_fresh', raw)
    if '실시간 시세' in raw or 'ws' in compact:
        return ('fresh', 'ws_fresh', raw)
    if '매수체결' in raw:
        return ('legacy', 'buy_ratio', raw)
    if '1분' in raw:
        return ('legacy', 'buy_sustain_1m', raw)
    if '가격반응' in raw:
        return ('legacy', 'price_reaction', raw)
    return ('other', raw, raw)


def _paper_v488_dedupe_reasons(reasons: Any, limit: int = 10) -> List[str]:
    arr = reasons if isinstance(reasons, list) else ([] if reasons is None else [reasons])
    order = {'entry_decision': 0, 'fresh': 1, 'exec': 2, 'legacy': 3, 'other': 4}
    buf: List[Tuple[int, str, str]] = []
    seen = set()
    for x in arr:
        b, k, disp = _paper_v488_reason_kind(x)
        if not k or b == 'ignore' or k in seen:
            continue
        seen.add(k)
        buf.append((order.get(b, 9), k, str(disp or x).strip()))
    return [txt for _o, _k, txt in sorted(buf, key=lambda z: z[0])[:limit]]


def _paper_v484_canonical_entry_decision(ev: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    # v533: paper OPEN gate reads only the strategy canonical decision.
    dec = ev.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or ev.get("common_entry_decision") or ctx.get("common_entry_decision")
    return dec if isinstance(dec, dict) else {}

def _paper_v537_profile_from_diag(diag: Dict[str, Any]) -> str:
    dec = diag.get("canonical_entry_decision") if isinstance(diag.get("canonical_entry_decision"), dict) else {}
    p = str(diag.get("entry_profile") or dec.get("entry_profile") or "").strip()
    if p in {"spike_fast_early", "spike_runner"}:
        return "spike"
    if p in {"spike_fast_watch", "normal_watch"}:
        return "watch"
    return p or "normal_common"


def _paper_v484_exec_safety_reasons(diag: Dict[str, Any], ctrl: Dict[str, Any]) -> List[str]:
    """v537 profile-aware last-mile safety.
    Strategy canonical_entry_decision is the entry source. Paper only checks last-mile execution,
    and uses the same profile family so spike is not re-blocked by normal spread/slippage defaults.
    """
    reasons: List[str] = []
    profile = _paper_v537_profile_from_diag(diag)
    if profile == "spike":
        max_spread = fnum(ctrl.get("paper_final_spike_max_spread_pct"), default=0.85)
        max_slip = fnum(ctrl.get("paper_final_spike_max_slippage_pct"), default=0.85)
        reaction_proof_enabled = bool(ctrl.get("paper_final_spike_reaction_proof_enabled", False))
    else:
        max_spread = fnum(ctrl.get("paper_final_max_spread_pct"), default=0.18)
        max_slip = fnum(ctrl.get("paper_final_max_slippage_pct"), default=0.20)
        reaction_proof_enabled = bool(ctrl.get("paper_final_reaction_proof_enabled", True))
    spread = fnum(diag.get("spread_pct"), default=-1.0)
    slip_raw = fnum(diag.get("slippage_pct"), default=-1.0)
    slip = slip_raw if slip_raw >= 0 else spread
    diag["paper_final_profile"] = profile
    diag["paper_final_max_spread_pct_used"] = max_spread
    diag["paper_final_max_slippage_pct_used"] = max_slip
    if spread >= 0 and spread > max_spread:
        reasons.append(f"진입 직전 스프레드 부담({spread:.2f}% > {max_spread:.2f}%)")
    if slip >= 0 and slip > max_slip:
        reasons.append(f"진입 직전 미끄러짐 부담({slip:.2f}% > {max_slip:.2f}%)")
    if reaction_proof_enabled:
        no_reaction_reason = _paper_v144_reaction_proof_block(diag, ctrl)
        if no_reaction_reason:
            reasons.append(no_reaction_reason)
    if _pressure_is_bad(diag.get("sell_pressure")):
        reasons.append("진입 직전 매도벽/매도압력 부담")
    return reasons[:10]



def _paper_v602_final_trade_state(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """strategy_worker가 봉인한 최종 매수판정만 읽는다. paper는 새 판단을 하지 않는다."""
    ctx = ctx if isinstance(ctx, dict) else {}
    sources: List[Tuple[str, Dict[str, Any]]] = []
    if isinstance(ev, dict):
        sources.append(("event", ev))
        cm = ev.get("canonical_metric_row")
        if isinstance(cm, dict):
            sources.append(("event.canonical_metric_row", cm))
    if isinstance(ctx, dict):
        sources.append(("entry_context", ctx))
        cm = ctx.get("canonical_metric_row")
        if isinstance(cm, dict):
            sources.append(("entry_context.canonical_metric_row", cm))
    for src, obj in sources:
        state = str(obj.get("final_trade_state") or "").strip()
        if state:
            return {
                "state": state,
                "allowed": state == "S1_PASS" or bool(obj.get("final_trade_allowed") is True and state == "S1_PASS"),
                "label": obj.get("final_trade_label") or obj.get("final_decision") or state,
                "reasons": obj.get("final_trade_reasons") if isinstance(obj.get("final_trade_reasons"), list) else [],
                "source": src,
                "schema": obj.get("final_decision_schema") or obj.get("schema") or "final_trade_state_v602",
            }
    return {"state": "", "allowed": False, "label": "전략 최종판정 없음", "reasons": [], "source": "missing", "schema": "missing_final_trade_state_v602"}

def paper_final_safety(ev: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, Any]]:
    """v602: paper는 strategy final_trade_state만 최종 OPEN 기준으로 읽는다.
    canonical_entry_decision은 보조 진단으로만 확인하고, 새 매수 판단은 paper에 추가하지 않는다.
    """
    ctx = copy_entry_context(ev)
    diag = build_entry_diagnostics(ev, ctx)
    final = _paper_v602_final_trade_state(ev, ctx)
    diag["final_trade_state"] = final.get("state")
    diag["final_trade_label"] = final.get("label")
    diag["final_trade_reasons"] = final.get("reasons") or []
    diag["final_trade_state_source"] = final.get("source")
    dec = _paper_v484_canonical_entry_decision(ev, ctx)
    reasons: List[str] = []
    if final.get("state") != "S1_PASS":
        why = final.get("reasons") if isinstance(final.get("reasons"), list) else []
        reasons.append("전략 최종판정 보류: " + str(final.get("label") or final.get("state") or "없음") + ((" / " + " / ".join(str(x) for x in why[:3])) if why else ""))

    if not isinstance(dec, dict) or not dec:
        diag["entry_decision_schema"] = "missing_canonical_entry_decision_v533"
        reasons.append("전략판단 원천 없음: canonical_entry_decision 누락")
    else:
        diag["canonical_entry_decision"] = dec
        diag["entry_decision_schema"] = dec.get("schema")
        diag["entry_profile"] = ev.get("entry_profile") or ctx.get("entry_profile") or dec.get("entry_profile")
        diag["exit_profile"] = ev.get("exit_profile") or ctx.get("exit_profile") or dec.get("exit_profile")
        diag["profile_family"] = ev.get("profile_family") or ctx.get("profile_family") or dec.get("profile_family")
        if not bool(dec.get("gate_pass") or dec.get("s1_allowed")):
            rs = dec.get("display_reasons") if isinstance(dec.get("display_reasons"), list) else []
            reasons.append("전략조건 재확인 보류: " + " / ".join(str(x) for x in rs[:4]))
        # last-mile execution safety only; do not duplicate strategy buy/sustain/reaction gates.
        reasons.extend(_paper_v484_exec_safety_reasons(diag, ctrl))

    if not micro_fresh(ev, ctrl):
        reasons.append("호가·체결 신선정보 없음")
    if bool(ctrl.get("paper_final_require_ws_fresh", False)) and not ws_fresh(ev):
        reasons.append("실시간 시세 신선정보 없음")

    try:
        age_ok, stale, ages = _v508_age_reasons(ev)
        diag["paper_preopen_age_values_v533"] = ages
        diag["paper_preopen_stale_reasons_v533"] = stale
        if not age_ok:
            reasons.append("preopen 신선도 실패: " + " / ".join(stale[:5]))
    except Exception as exc:
        diag["paper_preopen_age_error"] = exc.__class__.__name__

    for k in ("s1_missing_conditions", "s1_passed_conditions", "s1_distance", "s1_near_miss", "s1_short_reason", "canonical_lane", "matched_strategy_labels", "common_entry_pass", "common_entry_schema", "strategy_role", "entry_profile", "exit_profile", "profile_family", "profile_decisions"):
        val = ev.get(k) if ev.get(k) not in (None, "", [], {}) else ctx.get(k)
        if val not in (None, "", [], {}):
            diag[k] = val

    reasons = _paper_v488_dedupe_reasons(reasons, 10)
    diag["paper_final_safety_reasons"] = reasons
    diag["paper_final_safety_schema"] = "paper_final_safety_v602_final_trade_state_only"
    return (len(reasons) == 0), reasons, diag

def is_s1_candidate(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    final = _paper_v602_final_trade_state(ev, ctx)
    if final.get("state") != "S1_PASS":
        return False
    if ev.get("fresh_gate_ok") is False:
        return False
    if ev.get("paper_bot_open") is False or ev.get("open_eligible") is False or ev.get("trade_ready") is False:
        return False
    stage = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("stage") or ev.get("candidate_grade") or ev.get("grade") or "").upper()
    return stage == "S1"


def candidate_sources(ctrl: Dict[str, Any]) -> List[Tuple[str, Path, List[Dict[str, Any]]]]:
    """v512 runtime OPEN source: canonical latest only.

    Legacy merged/archive files are not read here. They may exist on disk as history/debug files,
    but they are not candidate sources for OPEN, preventing old schema rows from causing ticker/price skips.
    """
    maxn = max(50, min(2000, int(fnum(ctrl.get("candidate_read_max_lines"), default=800))))
    rows = read_jsonl_tail(FILES["paper_latest"], maxn)
    return [("paper_latest", FILES["paper_latest"], rows)]


def latest_scan_filter(rows: List[Dict[str, Any]], ctrl: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not rows or not bool(ctrl.get("consume_latest_scan_only", True)):
        return rows
    scan_ids = [str(r.get("scan_id") or r.get("source_scan_id") or "").strip() for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip()]
    if scan_ids:
        latest = scan_ids[-1]
        same = [r for r in rows if str(r.get("scan_id") or r.get("source_scan_id") or "").strip() == latest]
        if same:
            return same
    latest_ts = max((event_created_ts(r) for r in rows), default=0.0)
    if latest_ts > 0:
        win = fnum(ctrl.get("latest_scan_window_sec"), default=8.0)
        return [r for r in rows if event_created_ts(r) >= latest_ts - win]
    return rows


def build_trace(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], picked_ids: set[str], opened_ids: set[str]) -> Dict[str, Any]:
    out: List[Dict[str, Any]] = []
    open_ids = set(open_pos.keys())
    open_ticks = open_tickers(open_pos)
    for ev in rows[-160:]:
        if not isinstance(ev, dict):
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        eid = event_id(ev, "strict")
        reason: List[str] = []
        status = "observed"
        if eid in opened_ids:
            status = "open"
        elif eid in picked_ids:
            status = "selected_for_open"
        elif eid in open_ids or t in open_ticks:
            status = "already_open"
        elif not candidate_is_fresh(ev, ctrl):
            status = "expired"
            reason.append("후보오래됨")
        elif not is_s1_candidate(ev):
            status = "not_s1"
            reason.append("S1아님")
        elif ctrl.get("preopen_micro_recheck", True) and not micro_fresh(ev, ctrl):
            status = "micro_wait"
            reason.append("micro미확인")
        elif ev.get("paper_entry_hold_reasons"):
            status = "paper_entry_hold"
            reason.extend([str(x) for x in (ev.get("paper_entry_hold_reasons") or [])[:4]])
        elif ev.get("paper_final_block_reasons"):
            status = "paper_entry_hold"
            reason.extend([str(x) for x in (ev.get("paper_final_block_reasons") or [])[:4]])
        else:
            status = "merged_waiting_pick"
        out.append({
            "event_id": eid,
            "trace_id": eid,
            "ticker": t,
            "status": status,
            "reason": ",".join(reason) if reason else "-",
            "s_stage": ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade"),
            "score": ev.get("score") or ev.get("leader_score"),
            "strategy": ev.get("strategy_label") or ev.get("strategy_key") or ev.get("strategy") or ev.get("route"),
            "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema")),
            "entry_reasons": _diag_list(ev, ("entry_reasons", "final_entry_reasons", "trade_ready_reasons"), limit=6),
            "entry_structure_tags": _diag_list(ev, ("entry_structure_tags", "structure_tags", "matched_strategy_labels"), limit=8),
            "confirm_signals": _diag_list(ev, ("confirm_signals", "s1_passed_conditions"), limit=8),
            "structure_levels": ev.get("structure_levels") if isinstance(ev.get("structure_levels"), dict) else {},
            "entry_plan": ev.get("entry_plan") if isinstance(ev.get("entry_plan"), dict) else {},
            "risk_reward": ev.get("risk_reward") if isinstance(ev.get("risk_reward"), dict) else {},
            "entry_timing_spine": ev.get("entry_timing_spine") if isinstance(ev.get("entry_timing_spine"), dict) else {},
            "late_chase_flag": bool(ev.get("late_chase_flag")),
            "execution_risk_tags": _diag_list(ev, ("execution_risk_tags", "risk_tags", "structure_risk_tags"), limit=8),
            "recheck_reasons": _diag_list(ev, ("recheck_reasons", "s2_recheck_reasons"), limit=8),
            "missing_info": (list(ev.get("paper_entry_hold_reasons") or ev.get("paper_final_block_reasons") or [])[:6] or _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "s1_missing", "unmet_conditions", "block_reasons"), limit=6)),
            "created_at": ev.get("created_at") or ev.get("candidate_created_at") or ev.get("source_created_at"),
            "updated_at": nowv,
        })
    obj = {"version": VERSION, "trace_version": VERSION, "build": BUILD_LABEL, "updated_at": now_ts(), "updated_at_text": iso_ts(), "rows": out}
    save_json(FILES["trace"], obj)
    return obj




def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:
    stats: Dict[str, Any] = Counter()
    all_rows: List[Dict[str, Any]] = []
    latest_count = 0
    for name, _path, rows in candidate_sources(ctrl):
        stats[f"{name}_read"] = int(stats.get(f"{name}_read", 0)) + len(rows)
        if name == "paper_latest":
            latest_count = len(rows)
        for r in rows:
            if isinstance(r, dict):
                rr = dict(r)
                rr.setdefault("_source_file", name)
                all_rows.append(rr)
    filtered = latest_scan_filter(all_rows, ctrl)
    stats["latest_scan_before"] = len(all_rows)
    stats["latest_scan_after"] = len(filtered)
    existing_ids = set(open_pos.keys()) | closed_recent_ids()
    blocked_tickers = open_tickers(open_pos) if ctrl.get("block_same_ticker_open", True) else set()
    picked: List[Tuple[str, Dict[str, Any]]] = []
    max_new = int(fnum(ctrl.get("max_new_per_cycle"), default=0))
    max_open = int(fnum(ctrl.get("max_open_strict"), default=0))
    for ev in filtered:
        if not isinstance(ev, dict):
            continue
        stats["last_seen_candidate"] = candidate_brief(ev, status="seen")
        is_s1 = is_s1_candidate(ev)
        if is_s1:
            stats["s1_seen"] = int(stats.get("s1_seen", 0)) + 1
            _record_decision(stats, "last_s1_seen", ev, "s1_seen")
        if max_new > 0 and len(picked) >= max_new:
            stats["limit_skip"] = int(stats.get("limit_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "limit_skip", "cycle 신규 OPEN 상한")
            continue
        if max_open > 0 and len(open_pos) + len(picked) >= max_open:
            stats["limit_skip"] = int(stats.get("limit_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "limit_skip", "OPEN 상한")
            continue
        if ctrl.get("new_open_paused", False):
            stats["new_open_paused"] = int(stats.get("new_open_paused", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "new_open_paused", "신규 OPEN 일시정지")
            continue
        if not candidate_is_fresh(ev, ctrl):
            stats["stale_skip"] = int(stats.get("stale_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "stale_skip", "후보 TTL 만료")
            continue
        if ctrl.get("open_trade_ready_only", True) and not is_s1:
            stats["not_s1_skip"] = int(stats.get("not_s1_skip", 0)) + 1
            continue
        if ctrl.get("preopen_micro_recheck", True) and ctrl.get("notify_open_require_micro_fresh", True) and not micro_fresh(ev, ctrl):
            stats["micro_preopen_wait"] = int(stats.get("micro_preopen_wait", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "micro_preopen_wait", "OPEN 직전 micro 신선정보 없음")
            continue
        if ctrl.get("notify_open_require_ws_fresh", False) and not ws_fresh(ev):
            stats["ws_preopen_wait"] = int(stats.get("ws_preopen_wait", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "ws_preopen_wait", "OPEN 직전 WS 신선정보 없음")
            continue
        t = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
        price = get_event_price(ev)
        if not t:
            stats["ticker_missing_skip"] = int(stats.get("ticker_missing_skip", 0)) + 1
            stats["bad_skip"] = int(stats.get("bad_skip", 0)) + 1  # legacy aggregate
            if is_s1:
                _record_decision(stats, "last_skip", ev, "ticker_missing_skip", "ticker 필수값 없음")
            continue
        if price <= 0:
            stats["price_missing_skip"] = int(stats.get("price_missing_skip", 0)) + 1
            stats["bad_skip"] = int(stats.get("bad_skip", 0)) + 1  # legacy aggregate
            if is_s1:
                _record_decision(stats, "last_skip", ev, "price_missing_skip", "가격 필수값 없음")
            continue
        eid = event_id(ev, "strict")
        if eid in existing_ids:
            stats["dup_skip"] = int(stats.get("dup_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "dup_skip", "이미 OPEN/CLOSED 처리한 후보")
            continue
        if ctrl.get("block_same_ticker_open", True) and t in blocked_tickers:
            stats["same_ticker_skip"] = int(stats.get("same_ticker_skip", 0)) + 1
            if is_s1:
                _record_decision(stats, "last_skip", ev, "same_ticker_skip", "동일 종목 OPEN 보유중")
            continue
        ok_final, final_reasons, final_diag = paper_final_safety(ev, ctrl)
        if not ok_final:
            ev["paper_entry_hold_reasons"] = final_reasons
            # Keep the legacy field for main-bot compatibility, but user-facing wording is now 보류/recheck.
            ev["paper_final_block_reasons"] = final_reasons
            ev["paper_final_safety_diagnostics"] = final_diag
            ev["paper_entry_action"] = "recheck_hold"
            stats["paper_entry_hold"] = int(stats.get("paper_entry_hold", 0)) + 1
            stats["paper_final_block"] = int(stats.get("paper_final_block", 0)) + 1  # legacy counter
            if is_s1:
                _record_decision(stats, "last_paper_entry_hold", ev, "paper_entry_hold", " / ".join(final_reasons[:5]))
                _record_decision(stats, "last_paper_final_block", ev, "paper_entry_hold", " / ".join(final_reasons[:5]))
            continue
        ev = dict(ev)
        ev["lane"] = "strict"
        ev["paper_final_safety_passed"] = True
        ev["paper_final_safety_diagnostics"] = final_diag
        _record_decision(stats, "last_open_try", ev, "selected_for_open", "paper 최종안전문 통과")
        picked.append((eid, ev))
        existing_ids.add(eid)
        blocked_tickers.add(t)
        stats["selected_s1"] = int(stats.get("selected_s1", 0)) + 1
    stats["latest_count"] = latest_count
    stats["merged_fresh"] = sum(1 for r in filtered if candidate_is_fresh(r, ctrl))
    return picked, dict(stats), filtered

def copy_entry_context(ev: Dict[str, Any]) -> Dict[str, Any]:
    ctx: Dict[str, Any] = {}
    if isinstance(ev.get("entry_context"), dict):
        ctx.update(ev["entry_context"])
    for k, v in ev.items():
        if k.startswith("_"):
            continue
        if k not in ctx and k not in {"raw"}:
            ctx[k] = v
    return ctx


def _diag_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    srcs: List[Dict[str, Any]] = []
    for obj in (ev, ctx, ev.get("entry_context"), ev.get("entry_snapshot"), ev.get("profile"), ev.get("raw")):
        if isinstance(obj, dict):
            srcs.append(obj)
            for kk in (
                "flat", "strategy", "strategy_context", "metrics", "entry_metrics", "recheck_metrics",
                "orderflow", "orderflow_summary", "feature", "features", "price_flow", "price_context",
                "money_flow", "position", "risk", "micro", "micro_summary", "ws", "quote",
                "market", "market_context", "standard_values", "candidate_values", "score_context", "ticker_state",
            ):
                vv = obj.get(kk)
                if isinstance(vv, dict):
                    srcs.append(vv)
    return srcs


def _diag_first(ev: Dict[str, Any], keys: Iterable[str], default: Any = None, ctx: Optional[Dict[str, Any]] = None) -> Any:
    for src in _diag_sources(ev, ctx):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default


def _diag_list(ev: Dict[str, Any], keys: Iterable[str], ctx: Optional[Dict[str, Any]] = None, limit: int = 8) -> List[str]:
    out: List[str] = []
    for src in _diag_sources(ev, ctx):
        for k in keys:
            v = src.get(k)
            if v in (None, "", [], {}):
                continue
            vals: List[Any]
            if isinstance(v, list):
                vals = v
            elif isinstance(v, dict):
                vals = [f"{kk}:{vv}" for kk, vv in list(v.items())[:limit]]
            else:
                vals = [v]
            for item in vals:
                txt = str(item).strip()
                if txt and txt not in out:
                    out.append(txt)
                    if len(out) >= limit:
                        return out
    return out


def _fmt_bool(v: Any) -> str:
    if isinstance(v, str):
        if v.lower() in {"fresh", "ok", "true", "1", "yes"}:
            return "OK"
        if v.lower() in {"stale", "old", "false", "0", "no"}:
            return "부족"
    if v is True:
        return "OK"
    if v is False:
        return "부족"
    return "-" if v in (None, "") else str(v)


def _fmt_pct_value(v: Any, suffix: str = "%") -> str:
    if v in (None, ""):
        return "-"
    try:
        return f"{fnum(v):.2f}{suffix}"
    except Exception:
        return str(v)



def _paper_v143_num_if_present(obj: Any, key: str) -> Optional[float]:
    if not isinstance(obj, dict) or obj.get(key) in (None, ""):
        return None
    try:
        return float(str(obj.get(key)).replace(",", "").replace("%", "").strip())
    except Exception:
        return None


def _paper_v143_all_present(srcs: List[Dict[str, Any]], keys: List[str], group: str) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                out.append({"group": group, "source": k, "value": round(float(v), 4)})
    return out


def _paper_v143_first_present(srcs: List[Dict[str, Any]], keys: List[str]) -> Tuple[Optional[float], str]:
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            v = _paper_v143_num_if_present(src, k)
            if v is not None:
                return v, k
    return None, ""


def _paper_v143_price_delta_candidate(srcs: List[Dict[str, Any]]) -> Dict[str, Any]:
    cur, cur_src = _paper_v143_first_present(srcs, [
        "current_price", "price", "last_price", "close", "trade_price", "quote_price", "ws_price", "micro_price"
    ])
    ref, ref_src = _paper_v143_first_present(srcs, [
        "detected_price", "watch_price", "first_seen_price", "s3_price", "s2_price",
        "candidate_price", "base_price", "entry_signal_price", "signal_price", "recheck_start_price"
    ])
    if cur is not None and ref is not None and cur > 0 and ref > 0:
        return {"group": "price_delta", "source": f"{cur_src}/{ref_src}", "value": round((cur - ref) / ref * 100.0, 4)}
    return {}




def _paper_v144_flow_window_candidates(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Return actually-present short-flow windows for the final no-reaction proof.

    This deliberately does not treat missing values as 0. Missing information is not
    silently converted into a block signal; only explicit 0/negative short-flow rows
    are used to prevent VIRTUAL-style no-reaction entries.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    groups = [
        ("1m", ["flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"]),
        ("3m", ["flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"]),
        ("5m", ["flow_5m_pct", "change_5m", "chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct", "price_change_5m"]),
        ("15m", ["flow_15m_pct", "change_15m", "chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct", "price_change_15m"]),
    ]
    out: List[Dict[str, Any]] = []
    for label, keys in groups:
        val, src = _paper_v143_first_present(srcs, keys)
        if val is not None:
            out.append({"window": label, "value": round(float(val), 4), "source": src})
    return out


def _paper_v144_reaction_proof_block(diag: Dict[str, Any], ctrl: Dict[str, Any]) -> str:
    """Hold confirmed no-reaction S1 entries right before OPEN.

    This is not an S1/S2/S3 threshold change and not a discard rule. If enough
    short-flow windows are present and all are flat/negative below the tiny proof
    threshold, paper only skips this OPEN attempt and leaves the candidate to the
    next recheck/strategy cycle.
    """
    if not bool(ctrl.get("paper_final_reaction_proof_enabled", True)):
        return ""
    flows = diag.get("flow_window_candidates") if isinstance(diag.get("flow_window_candidates"), list) else []
    min_windows = int(fnum(ctrl.get("paper_final_reaction_proof_min_windows"), default=2.0))
    min_flow = fnum(ctrl.get("paper_final_reaction_proof_min_flow_pct"), default=0.01)
    usable = []
    for x in flows:
        if isinstance(x, dict) and x.get("value") is not None:
            try:
                usable.append((str(x.get("window") or "?"), float(x.get("value") or 0.0)))
            except Exception:
                pass
    if len(usable) < max(1, min_windows):
        return ""
    best = max(v for _w, v in usable)
    if best < min_flow:
        flow_txt = " / ".join(f"{w} {v:+.2f}%" for w, v in usable[:4])
        return f"진입 직전 무반응 재확인 보류({flow_txt} / 최고흐름 {best:+.2f}% < +{min_flow:.2f}%)"
    return ""

def paper_price_reaction_spine(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """paper final safety가 strategy recheck와 같은 가격반응 spine을 보게 한다.

    명시 0값이 있더라도 실제 non-zero short-flow/price-delta가 있으면 그 값을 사용한다.
    이것은 최종 안전문 기준 완화가 아니라 구 0.00 경로 제거다.
    """
    ctx = ctx if isinstance(ctx, dict) else {}
    srcs = _diag_sources(ev, ctx)
    explicit_keys = ["price_reaction_pct", "reaction_pct", "price_response_pct", "price_recheck_pct"]
    flow_keys = [
        "flow_1m_pct", "change_1m", "chg_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m",
        "flow_3m_pct", "change_3m", "chg_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m",
    ]
    candidates: List[Dict[str, Any]] = []
    candidates.extend(_paper_v143_all_present(srcs, explicit_keys, "explicit"))
    candidates.extend(_paper_v143_all_present(srcs, flow_keys, "short_flow"))
    pd = _paper_v143_price_delta_candidate(srcs)
    if pd:
        candidates.append(pd)
    explicit = [c for c in candidates if c.get("group") == "explicit"]
    nonzero_explicit = [c for c in explicit if abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_explicit:
        c = nonzero_explicit[0]
        return {"known": True, "value": float(c["value"]), "source": c.get("source"), "method": "explicit", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    nonzero_alt = [c for c in candidates if c.get("group") in ("short_flow", "price_delta") and abs(float(c.get("value") or 0.0)) >= 0.001]
    if nonzero_alt:
        c = nonzero_alt[0]
        zero_src = explicit[0].get("source") if explicit else ""
        method = "explicit_zero_overridden" if explicit else str(c.get("group") or "alternate")
        return {"known": True, "value": float(c["value"]), "source": f"{c.get('source')}" + (f"; explicit0={zero_src}" if zero_src else ""), "method": method, "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if explicit:
        c = explicit[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": "explicit_zero", "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    if candidates:
        c = candidates[0]
        return {"known": True, "value": float(c.get("value") or 0.0), "source": c.get("source"), "method": str(c.get("group") or "candidate"), "candidates": candidates[:8], "schema": "paper_price_reaction_spine_v143"}
    return {"known": False, "value": 0.0, "source": "missing", "method": "missing", "candidates": [], "schema": "paper_price_reaction_spine_v143"}

def build_entry_diagnostics(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctx = ctx if isinstance(ctx, dict) else {}
    # v553: 진입근거는 strategy_worker가 분리 봉인한 entry_reasons만 우선 사용한다.
    # s_stage_reasons/reason은 위험·부족·재확인 문구가 섞일 수 있으므로 진입근거 fallback에서 제외한다.
    reasons = _diag_list(ev, ("entry_reasons", "final_entry_reasons", "trade_ready_reasons"), ctx, 10)
    structure_tags = _diag_list(ev, ("entry_structure_tags", "structure_tags", "matched_strategy_labels"), ctx, 10)
    confirm_signals = _diag_list(ev, ("confirm_signals", "s1_passed_conditions", "condition_pass_summary"), ctx, 10)
    risk_tags = _diag_list(ev, ("execution_risk_tags", "risk_tags", "structure_risk_tags"), ctx, 10)
    recheck_reasons = _diag_list(ev, ("recheck_reasons", "s2_recheck_reasons", "freshness_flags"), ctx, 10)
    block_reasons = _diag_list(ev, ("block_reasons", "s1_missing_conditions", "unmet_conditions"), ctx, 10)
    missing = _diag_list(ev, ("missing_info", "missing_fields", "info_missing", "info_needed", "need_info", "entry_missing_info", "s1_missing"), ctx, 10)
    if not missing:
        missing = []
    matched = _diag_list(ev, ("matched_strategies", "strategy_matches", "strategy_tags", "tags"), ctx, 8)
    structure_levels = _diag_first(ev, ("structure_levels",), ctx=ctx)
    if not isinstance(structure_levels, dict):
        structure_levels = {}
    entry_plan = _diag_first(ev, ("entry_plan",), ctx=ctx)
    if not isinstance(entry_plan, dict):
        entry_plan = {}
    risk_reward = _diag_first(ev, ("risk_reward",), ctx=ctx)
    if not isinstance(risk_reward, dict):
        risk_reward = {}
    entry_timing_spine = _diag_first(ev, ("entry_timing_spine",), ctx=ctx)
    if not isinstance(entry_timing_spine, dict):
        entry_timing_spine = {}
    diag = {
        "stage_policy_schema": _diag_first(ev, ("stage_policy_schema", "lifecycle_schema"), ctx=ctx),
        "stage": _diag_first(ev, ("s_stage", "candidate_stage", "candidate_grade", "grade"), ctx=ctx),
        "strategy_key": _diag_first(ev, ("strategy_key", "paper_strategy_key", "strategy", "route", "section"), ctx=ctx),
        "strategy_label": _diag_first(ev, ("strategy_label", "paper_strategy_label", "final_entry_label"), ctx=ctx),
        "entry_reasons": reasons,
        "entry_structure_tags": structure_tags,
        "confirm_signals": confirm_signals,
        "execution_risk_tags": risk_tags,
        "recheck_reasons": recheck_reasons,
        "block_reasons": block_reasons,
        "missing_info": missing,
        "matched_strategies": matched,
        "reason_taxonomy_schema": _diag_first(ev, ("reason_taxonomy_schema",), ctx=ctx),
        "structure_levels": structure_levels,
        "entry_plan": entry_plan,
        "risk_reward": risk_reward,
        "entry_timing_spine": entry_timing_spine,
        "late_chase_flag": bool(_diag_first(ev, ("late_chase_flag",), ctx=ctx)),
        "micro_fresh": _fmt_bool(_diag_first(ev, ("micro_fresh", "micro_row_status", "micro_status"), ctx=ctx)),
        "ws_fresh": _fmt_bool(_diag_first(ev, ("ws_fresh", "ws_row_status", "quote_fresh", "quote_status"), ctx=ctx)),
        "buy_ratio": fnum(_diag_first(ev, ("buy_ratio", "buy_ratio_30s", "buy_trade_ratio", "micro_buy_ratio"), ctx=ctx), default=-1.0),
        "buy_sustain_1m": fnum(_diag_first(ev, ("micro_buy_ratio_sustain_1m", "buy_ratio_1m", "buy_sustain_1m"), ctx=ctx), default=-1.0),
        "spread_pct": fnum(_diag_first(ev, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"), ctx=ctx), default=-1.0),
        "slippage_pct": fnum(_diag_first(ev, ("slippage_est_pct", "expected_slippage_pct", "slippage_pct"), ctx=ctx), default=-1.0),
        "price_reaction_pct": fnum(_diag_first(ev, ("price_reaction_pct", "price_reaction", "reaction_pct", "price_recheck_pct"), ctx=ctx), default=0.0),
        "flow_1m_pct": fnum(_diag_first(ev, ("flow_1m_pct", "change_1m", "chg_1m", "flow_1m", "change_1m_pct", "ret_1m_pct", "price_change_1m"), ctx=ctx), default=0.0),
        "flow_3m_pct": fnum(_diag_first(ev, ("flow_3m_pct", "change_3m", "chg_3m", "flow_3m", "change_3m_pct", "ret_3m_pct", "price_change_3m"), ctx=ctx), default=0.0),
        "flow_5m_pct": fnum(_diag_first(ev, ("chg_5m", "flow_5m", "change_5m_pct", "ret_5m_pct"), ctx=ctx), default=0.0),
        "flow_15m_pct": fnum(_diag_first(ev, ("chg_15m", "flow_15m", "change_15m_pct", "ret_15m_pct"), ctx=ctx), default=0.0),
        "flow_30m_pct": fnum(_diag_first(ev, ("chg_30m", "flow_30m", "change_30m_pct", "ret_30m_pct"), ctx=ctx), default=0.0),
        "vwap_pos_pct": fnum(_diag_first(ev, ("vwap_pos_pct", "vwap_gap_pct", "vwap_position_pct", "vwap"), ctx=ctx), default=0.0),
        "ema5_pos_pct": fnum(_diag_first(ev, ("ema5_pos_pct", "ema5_gap_pct", "ema5_position_pct", "ema5"), ctx=ctx), default=0.0),
        "relative_strength": fnum(_diag_first(ev, ("relative_strength", "relative", "market_relative_strength"), ctx=ctx), default=0.0),
        "turnover_krw": fnum(_diag_first(ev, ("turnover_krw", "trade_amount_krw", "value_krw", "acc_trade_price_24h"), ctx=ctx), default=0.0),
        "sell_pressure": _diag_first(ev, ("sell_pressure", "ask_wall_pressure", "sell_trade_pressure"), ctx=ctx),
    }
    diag["flow_window_candidates"] = _paper_v144_flow_window_candidates(ev, ctx)
    diag["flow_window_source_schema"] = "paper_final_reaction_proof_v479_recheck_hold"
    diag["flow_window_map"] = {str(x.get("window")): x for x in diag["flow_window_candidates"] if isinstance(x, dict) and x.get("window")}
    pr_spine = paper_price_reaction_spine(ev, ctx)
    diag["price_reaction_pct"] = fnum(pr_spine.get("value"), default=0.0)
    diag["price_reaction_source"] = pr_spine.get("source")
    diag["price_reaction_method"] = pr_spine.get("method")
    diag["price_reaction_spine_schema"] = pr_spine.get("schema")
    diag["price_reaction_candidates"] = pr_spine.get("candidates") or []
    passed: List[str] = []
    if diag["micro_fresh"] == "OK": passed.append("micro신선")
    if diag["ws_fresh"] == "OK": passed.append("WS신선")
    if diag["buy_ratio"] >= 0: passed.append(f"매수체결 {diag['buy_ratio']:.2f}")
    if diag["buy_sustain_1m"] >= 0: passed.append(f"1분지속 {diag['buy_sustain_1m']:.2f}")
    if diag["spread_pct"] >= 0: passed.append(f"스프레드 {diag['spread_pct']:.2f}%")
    if diag["slippage_pct"] >= 0: passed.append(f"슬리피지 {diag['slippage_pct']:.2f}%")
    if diag["price_reaction_pct"]: passed.append(f"가격반응 {diag['price_reaction_pct']:+.2f}%")
    diag["condition_pass_summary"] = passed[:8]
    return diag


def _v494_first_ts_from_sources(ev: Dict[str, Any], ctx: Optional[Dict[str, Any]], keys: Iterable[str]) -> Tuple[float, str]:
    """Trace helper only. It must not change entry/exit decisions."""
    ctx = ctx if isinstance(ctx, dict) else {}
    for src in _diag_sources(ev, ctx):
        if not isinstance(src, dict):
            continue
        for k in keys:
            if k in src:
                ts = row_ts(src, k)
                if ts > 0:
                    return ts, k
    return 0.0, ""


def build_entry_timing_trace(ev: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """진입이 늦었는지 확인하기 위한 trace. 조건/청산 변경에 쓰지 않는다."""
    ctx = copy_entry_context(ev)
    diag = diag if isinstance(diag, dict) else build_entry_diagnostics(ev, ctx)
    source_ts, src_key = _v494_first_ts_from_sources(ev, ctx, (
        "first_detected_ts", "first_seen_ts", "detected_ts", "candidate_created_at",
        "source_created_at", "created_at", "event_ts", "ts", "timestamp",
    ))
    promotion_ts, promotion_key = _v494_first_ts_from_sources(ev, ctx, (
        "s1_promotion_ts", "recheck_promotion_ts", "promoted_ts", "paper_handoff_ts",
        "handoff_ts", "updated_ts", "updated_at",
    ))
    nowv = now_ts()
    source_age_sec = max(0.0, nowv - source_ts) if source_ts > 0 else 0.0
    promotion_age_sec = max(0.0, nowv - promotion_ts) if promotion_ts > 0 else 0.0
    source_to_promotion_sec = max(0.0, promotion_ts - source_ts) if source_ts > 0 and promotion_ts > 0 else 0.0
    hot1 = _diag_first(ev, ("hot_rank_1m", "scanner_hot_rank_1m"), ctx=ctx)
    hot3 = _diag_first(ev, ("hot_rank_3m", "scanner_hot_rank_3m"), ctx=ctx)
    change_1m_source = _diag_first(ev, ("change_1m_source", "scanner_change_1m_source"), ctx=ctx)
    change_3m_source = _diag_first(ev, ("change_3m_source", "scanner_change_3m_source"), ctx=ctx)
    flags: List[str] = []
    f1 = fnum(diag.get("flow_1m_pct"), default=0.0)
    f3 = fnum(diag.get("flow_3m_pct"), default=0.0)
    react = fnum(diag.get("price_reaction_pct"), default=0.0)
    pr_src = str(diag.get("price_reaction_source") or "")
    if source_age_sec >= 120:
        flags.append(f"후보오래됨({source_age_sec/60.0:.1f}분)")
    if source_to_promotion_sec >= 60:
        flags.append(f"S1승격지연({source_to_promotion_sec:.0f}초)")
    if promotion_age_sec >= 45:
        flags.append(f"paper읽기지연({promotion_age_sec:.0f}초)")
    if f1 <= 0.01 and max(react, f3) >= 0.15:
        flags.append("현재1m약함/과거반응주의")
    if pr_src and ("3m" in pr_src or "5m" in pr_src or "15m" in pr_src) and f1 <= 0.01:
        flags.append("반응원천이현재1m아님")
    return {
        "schema": "entry_timing_trace_v494",
        "source_ts": source_ts, "source_key": src_key or "-",
        "s1_promotion_ts": promotion_ts, "s1_promotion_key": promotion_key or "-",
        "source_age_sec": round(source_age_sec, 1), "source_age_min": round(source_age_sec / 60.0, 2),
        "source_to_promotion_sec": round(source_to_promotion_sec, 1),
        "paper_read_delay_sec": round(promotion_age_sec, 1),
        "price_reaction_pct": round(react, 4),
        "price_reaction_source": diag.get("price_reaction_source") or "-",
        "price_reaction_method": diag.get("price_reaction_method") or "-",
        "flow_1m_pct": round(f1, 4), "flow_3m_pct": round(f3, 4),
        "hot_rank_1m": hot1, "hot_rank_3m": hot3,
        "change_1m_source": change_1m_source or "-", "change_3m_source": change_3m_source or "-",
        "flags": flags,
    }


def format_entry_timing_line(trace: Any, prefix: str = "- ") -> str:
    if not isinstance(trace, dict) or not trace:
        return prefix + "진입시점: trace 없음"
    age = fnum(trace.get("source_age_min"), default=0.0)
    promo_delay = fnum(trace.get("source_to_promotion_sec"), default=0.0)
    paper_delay = fnum(trace.get("paper_read_delay_sec"), default=0.0)
    f1 = fnum(trace.get("flow_1m_pct"), default=0.0)
    f3 = fnum(trace.get("flow_3m_pct"), default=0.0)
    hot1 = trace.get("hot_rank_1m") or "-"
    hot3 = trace.get("hot_rank_3m") or "-"
    flags = trace.get("flags") if isinstance(trace.get("flags"), list) else []
    tail = (" / 주의 " + ", ".join(str(x) for x in flags[:2])) if flags else ""
    delay_part = f" / S1까지 {promo_delay:.0f}s / paper {paper_delay:.0f}s" if promo_delay or paper_delay else ""
    return prefix + f"진입시점: 감지후 {age:.1f}분{delay_part} / 1m {f1:+.2f}% · 3m {f3:+.2f}% / hot {hot1}/{hot3}{tail}"


def _paper_v479_flow_display(diag: Dict[str, Any], window: str) -> str:
    """Display only canonical/present short-flow values.

    Missing short-flow information is shown as '-' rather than being displayed as
    +0.00%. This is display hygiene, not a stricter entry condition.
    """
    fmap = diag.get("flow_window_map") if isinstance(diag.get("flow_window_map"), dict) else {}
    item = fmap.get(window) if isinstance(fmap, dict) else None
    if isinstance(item, dict) and item.get("value") is not None:
        try:
            return f"{float(item.get('value')):+.2f}%"
        except Exception:
            return "-"
    return "-"


def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = "- ") -> List[str]:
    lines: List[str] = []
    reasons = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
    structures = diag.get("entry_structure_tags") if isinstance(diag.get("entry_structure_tags"), list) else []
    confirms = diag.get("confirm_signals") if isinstance(diag.get("confirm_signals"), list) else []
    risks = diag.get("execution_risk_tags") if isinstance(diag.get("execution_risk_tags"), list) else []
    rechecks = diag.get("recheck_reasons") if isinstance(diag.get("recheck_reasons"), list) else []
    blocks = diag.get("block_reasons") if isinstance(diag.get("block_reasons"), list) else []
    missing = diag.get("missing_info") if isinstance(diag.get("missing_info"), list) else []
    passed = diag.get("condition_pass_summary") if isinstance(diag.get("condition_pass_summary"), list) else []
    if structures:
        lines.append(prefix + "진입구조: " + " / ".join(str(x) for x in structures[:5]))
    if reasons:
        lines.append(prefix + "진입근거: " + " / ".join(str(x) for x in reasons[:5]))
    if confirms:
        lines.append(prefix + "확인통과: " + " / ".join(str(x) for x in confirms[:5]))
    elif passed:
        lines.append(prefix + "통과정보: " + " / ".join(str(x) for x in passed[:5]))
    levels = diag.get("structure_levels") if isinstance(diag.get("structure_levels"), dict) else {}
    plan = diag.get("entry_plan") if isinstance(diag.get("entry_plan"), dict) else {}
    rr = diag.get("risk_reward") if isinstance(diag.get("risk_reward"), dict) else {}
    timing_spine = diag.get("entry_timing_spine") if isinstance(diag.get("entry_timing_spine"), dict) else {}
    if levels and levels.get("available", True):
        lines.append(prefix + "구조선: 지지 " + fmt_price(levels.get("support_price")) + " / 방아쇠 " + fmt_price(levels.get("trigger_price")) + " / 무효 " + fmt_price(levels.get("invalid_price")) + " / 목표 " + fmt_price(levels.get("target1_price")) + "→" + fmt_price(levels.get("target2_price")))
    if plan:
        lines.append(prefix + "진입계획: " + str(plan.get("plan_type") or "-") + " / " + str(plan.get("trigger_reason") or "-"))
    if rr:
        up = fnum(rr.get("expected_upside_pct"), default=0.0); dn = fnum(rr.get("expected_downside_pct"), default=0.0); ratio = fnum(rr.get("rr_ratio"), default=0.0)
        lines.append(prefix + f"손익비: 기대상승 {up:+.2f}% / 무효손실 {-abs(dn):+.2f}% / RR {ratio:.2f}")
    if timing_spine:
        d1 = timing_spine.get("first_to_now_delay_sec"); d2 = timing_spine.get("s2_to_now_delay_sec"); r1 = fnum(timing_spine.get("first_to_now_return_pct"), default=0.0); r2 = fnum(timing_spine.get("s2_to_now_return_pct"), default=0.0)
        lines.append(prefix + f"진입타이밍: 최초→현재 {fnum(d1, default=0.0):.0f}s/{r1:+.2f}% · S2→현재 {fnum(d2, default=0.0):.0f}s/{r2:+.2f}%")
    if diag.get("late_chase_flag") or (levels and levels.get("late_chase_flag")):
        basis = diag.get("late_chase_basis") if isinstance(diag.get("late_chase_basis"), dict) else (levels.get("late_chase_basis") if isinstance(levels.get("late_chase_basis"), dict) else {})
        reason = str(diag.get("late_chase_reason") or levels.get("late_chase_reason") or "")
        if basis:
            lines.append(prefix + f"늦은추격: ⚠️ 주의 / 반응 {fnum(basis.get('reaction'), default=0.0):+.2f}% · 스프 {fnum(basis.get('spread'), default=0.0):.2f}%")
        else:
            lines.append(prefix + "늦은추격: ⚠️ 주의")
    if risks:
        lines.append(prefix + "위험태그: " + " / ".join(str(x) for x in risks[:5]))
    flow = (
        f"1m {_paper_v479_flow_display(diag, '1m')} · "
        f"3m {_paper_v479_flow_display(diag, '3m')} · "
        f"5m {_paper_v479_flow_display(diag, '5m')} · "
        f"15m {_paper_v479_flow_display(diag, '15m')}"
    )
    lines.append(prefix + "흐름: " + flow)
    pos = f"VWAP {diag.get('vwap_pos_pct',0):+.2f}% · EMA5 {diag.get('ema5_pos_pct',0):+.2f}% · 상대강도 {diag.get('relative_strength',0):+.2f}"
    lines.append(prefix + "위치: " + pos)
    caution = []
    for group in (rechecks, blocks, missing):
        for x in group:
            txt = str(x)
            if txt and txt not in caution:
                caution.append(txt)
    if caution:
        lines.append(prefix + "재확인/주의: " + " / ".join(str(x) for x in caution[:5]))
    else:
        lines.append(prefix + "최종판정: S1 통과")
    return lines


def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:
    ticker = normalize_ticker(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    detected = get_event_price(ev)
    price = live_price(ticker, detected) or detected
    ts = now_ts()
    ctx = copy_entry_context(ev)
    diag = ev.get("paper_final_safety_diagnostics") if isinstance(ev.get("paper_final_safety_diagnostics"), dict) else build_entry_diagnostics(ev, ctx)
    timing_trace = build_entry_timing_trace(ev, diag)
    diag["entry_timing_trace"] = timing_trace
    grade = str(ev.get("s_stage") or ev.get("candidate_stage") or ev.get("candidate_grade") or ev.get("grade") or "S1").upper()
    current_main_version = active_main_version()
    event_main_version = ev.get("main_version") or ev.get("deploy_version") or ev.get("opened_main_version") or ""
    stamped_main_version = current_main_version if current_main_version else event_main_version
    raw_main_version = str(event_main_version or "").strip()
    return {
        "pos_id": pos_id,
        "event_id": pos_id,
        "ticker": ticker,
        "lane": "strict",
        "opened_at": ts,
        "opened_at_text": iso_ts(ts),
        "opened_paper_version": VERSION,
        # 성과판용 버전은 현재 DEPLOY_TARGET 기준으로 단일화한다.
        # 후보/worker 원본의 구버전 표기는 추적용 raw 필드에만 남긴다.
        "score_main_version": stamped_main_version,
        "opened_main_version": stamped_main_version,
        "main_version": stamped_main_version,
        "deploy_version": stamped_main_version,
        "source_main_version_raw": raw_main_version,
        "strategy_worker_version": ev.get("strategy_worker_version") or ev.get("source_version") or ev.get("brain_version") or "",
        "paper_final_safety_passed": bool(ev.get("paper_final_safety_passed")),
        "entry_price": price,
        "detected_price": detected,
        "current_price": price,
        "peak_pct": 0.0,
        "trough_pct": 0.0,
        "last_pnl_pct": -fnum(DEFAULT_CONTROL.get("fee_pct_roundtrip"), default=0.10),
        "last_update": ts,
        "strategy": ev.get("strategy") or ev.get("strategy_key") or ev.get("route") or ev.get("section") or "unknown",
        "strategy_key": ev.get("strategy_key") or ev.get("paper_strategy_key") or ev.get("route") or ev.get("strategy"),
        "strategy_label": ev.get("strategy_label") or ev.get("paper_strategy_label") or ev.get("final_entry_label"),
        "candidate_grade": grade,
        "candidate_grade_label": ev.get("candidate_grade_label") or ev.get("s_stage_label") or ev.get("final_trade_label") or "✅ 최종 매수 가능",
        "final_trade_state": ev.get("final_trade_state") or ctx.get("final_trade_state"),
        "final_trade_label": ev.get("final_trade_label") or ctx.get("final_trade_label"),
        "final_trade_reasons": ev.get("final_trade_reasons") or ctx.get("final_trade_reasons") or [],
        "trade_ready": bool((ev.get("final_trade_state") or ctx.get("final_trade_state")) == "S1_PASS"),
        "trade_ready_label": ev.get("trade_ready_label") or ev.get("final_trade_label") or ev.get("final_entry_label") or "최종 매수 가능",
        "final_entry_action": ev.get("final_entry_action") or "paper_open",
        "final_entry_label": ev.get("final_entry_label") or ev.get("final_trade_label") or ev.get("trade_ready_label") or "최종 매수 가능",
        "final_entry_reasons": ev.get("final_entry_reasons") or ev.get("final_trade_reasons") or ev.get("trade_ready_reasons") or [],
        "scan_id": ev.get("scan_id") or ev.get("source_scan_id") or "",
        "brain_version": ev.get("brain_version") or ev.get("source_version") or "",
        "score": fnum(ev.get("score"), ev.get("leader_score"), default=0.0),
        "edge": fnum(ev.get("edge"), ev.get("edge_score"), default=0.0),
        "reason": ev.get("reason") or ev.get("why") or ev.get("hold_reason") or "",
        "source_created_at": event_created_ts(ev),
        "source_created_at_text": ev.get("created_at_text") or ev.get("source_created_at_text") or "",
        "entry_context": ctx,
        "entry_diagnostics": diag,
        "entry_timing_trace": timing_trace,
        "structure_levels": diag.get("structure_levels") or {},
        "entry_plan": diag.get("entry_plan") or {},
        "risk_reward": diag.get("risk_reward") or {},
        "entry_timing_spine": diag.get("entry_timing_spine") or {},
        "late_chase_flag": bool(diag.get("late_chase_flag")),
        "entry_condition_reasons": diag.get("entry_reasons") or [],
        "entry_structure_tags": diag.get("entry_structure_tags") or [],
        "confirm_signals": diag.get("confirm_signals") or [],
        "execution_risk_tags": diag.get("execution_risk_tags") or [],
        "recheck_reasons": diag.get("recheck_reasons") or [],
        "block_reasons": diag.get("block_reasons") or [],
        "entry_missing_info": diag.get("missing_info") or [],
        "entry_condition_pass_summary": diag.get("condition_pass_summary") or [],
        "raw": ev,
    }


EXIT_ICONS = {
    "take_profit": "✅",
    "stop_loss": "❌",
    "protect_stop_after_tp": "🛡️",
    "slow_no_progress": "⚠️",
    "fast_fail_stop": "📉",
    "time_exit": "⏱️",
    "spike_fast_fail_stop": "⚡",
    "spike_runner_trailing": "🏃",
    "spike_time_exit": "⏱️",
}

EXIT_LABELS = {
    "take_profit": "✅ 익절 종료",
    "stop_loss": "❌ 손절 종료",
    "protect_stop_after_tp": "🛡️ 익절 후 보호청산",
    "slow_no_progress": "⚠️ 지지부진 종료",
    "fast_fail_stop": "📉 빠른실패 정리",
    "time_exit": "⏱️ 시간 종료",
    "spike_fast_fail_stop": "⚡ 급등형 빠른실패",
    "spike_runner_trailing": "🏃 급등형 추적청산",
    "spike_time_exit": "⏱️ 급등형 시간청산",
}

EXIT_TITLES = {
    "take_profit": "✅ paper 익절 CLOSED",
    "stop_loss": "❌ paper 손절 CLOSED",
    "protect_stop_after_tp": "🛡️ paper 보호익절 CLOSED",
    "slow_no_progress": "⚠️ paper 지지부진 CLOSED",
    "fast_fail_stop": "📉 paper 빠른실패 CLOSED",
    "time_exit": "⏱️ paper 시간청산 CLOSED",
    "spike_fast_fail_stop": "⚡ paper 급등형 빠른실패 CLOSED",
    "spike_runner_trailing": "🏃 paper 급등형 추적청산 CLOSED",
    "spike_time_exit": "⏱️ paper 급등형 시간청산 CLOSED",
}


def closed_title(row: Dict[str, Any]) -> str:
    reason = str(row.get("exit_reason") or row.get("exit_rule") or "").strip()
    return EXIT_TITLES.get(reason, "🔴 paper CLOSED")



def adaptive_protect_floor(peak: float, ctrl: Dict[str, Any]) -> float:
    """수익권 진입 후 되돌림 방어선.

    숫자 하나로 고정하지 않고 최고수익 구간에 따라 최소 보존선을 올린다.
    잘 가는 후보는 take_profit/추가보유 여지를 남기되, +0.7~1.0% 갔다가
    음전까지 방치되는 흐름을 먼저 막는 목적이다.
    """
    base = fnum(ctrl.get("protect_floor_pct"), default=0.35)
    if peak >= fnum(ctrl.get("protect_big_trigger_pct"), default=1.40):
        return max(base, fnum(ctrl.get("protect_big_floor_pct"), default=0.75))
    if peak >= fnum(ctrl.get("protect_strong_trigger_pct"), default=1.00):
        return max(base, fnum(ctrl.get("protect_strong_floor_pct"), default=0.50))
    return base


def should_fast_fail(age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> bool:
    """진입 후 반응이 없으면 기본 손절선까지 기다리지 않고 정리한다."""
    peak_limit = fnum(ctrl.get("fast_fail_peak_under_pct"), default=0.20)
    if peak >= peak_limit:
        return False
    early_min = fnum(ctrl.get("fast_fail_after_min"), default=2.5)
    early_loss = fnum(ctrl.get("fast_fail_loss_pct"), default=-0.35)
    late_min = fnum(ctrl.get("fast_fail_after_min_late"), default=5.0)
    late_loss = fnum(ctrl.get("fast_fail_loss_pct_late"), default=-0.25)
    return (age_min >= early_min and net <= early_loss) or (age_min >= late_min and net <= late_loss)


def _strategy_text_for_exit(pos: Dict[str, Any]) -> str:
    parts: List[str] = []
    for k in ("strategy", "strategy_key", "strategy_label", "final_entry_label", "candidate_grade_label"):
        v = pos.get(k)
        if v:
            parts.append(str(v))
    raw = pos.get("raw") if isinstance(pos.get("raw"), dict) else {}
    ctx = pos.get("entry_context") if isinstance(pos.get("entry_context"), dict) else {}
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    for obj in (raw, ctx, diag):
        for k in ("strategy", "strategy_key", "strategy_label", "paper_strategy_label", "final_entry_label"):
            v = obj.get(k) if isinstance(obj, dict) else None
            if v:
                parts.append(str(v))
    return " ".join(parts)


def _is_profit_run_strategy(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> bool:
    text = _strategy_text_for_exit(pos).lower()
    keys = ctrl.get("profit_run_strategy_keywords")
    if not isinstance(keys, list) or not keys:
        keys = ["주도", "유동보유", "leader", "momentum"]
    return any(str(k).lower() in text for k in keys if str(k).strip())


def _should_extend_profit_run(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Tuple[bool, str]:
    """v486: 수익권에서 살아있는 주도흐름은 15분 고정 종료하지 않고 1회 연장한다.

    조건을 새로 조이는 용도가 아니라 time_exit 직전의 청산 판단을 한곳에서 정리한다.
    무반응/손실 후보는 fast_fail/stop_loss가 먼저 처리한다.
    """
    if not bool(ctrl.get("profit_run_extend_enabled", True)):
        return False, "연장 비활성"
    max_count = int(fnum(ctrl.get("profit_run_extend_max_count"), default=1))
    done = int(fnum(pos.get("time_exit_extension_count"), default=0))
    if done >= max_count:
        return False, "연장횟수 소진"
    if not _is_profit_run_strategy(pos, ctrl):
        return False, "연장대상 전략 아님"
    min_net = fnum(ctrl.get("profit_run_extend_min_net_pct"), default=0.20)
    min_peak = fnum(ctrl.get("profit_run_extend_min_peak_pct"), default=0.25)
    max_giveback = fnum(ctrl.get("profit_run_extend_max_giveback_pct"), default=0.25)
    giveback = max(0.0, peak - net)
    if net < min_net:
        return False, f"현재수익 부족 {net:+.2f}% < {min_net:+.2f}%"
    if peak < min_peak:
        return False, f"최고수익 부족 {peak:+.2f}% < {min_peak:+.2f}%"
    if giveback > max_giveback:
        return False, f"반납 큼 {giveback:+.2f}% > {max_giveback:+.2f}%"
    return True, f"수익권 유동보유 연장: 현재 {net:+.2f}% / 최고 {peak:+.2f}% / 반납 {giveback:+.2f}%"


def _exit_decision_spine(pos: Dict[str, Any], age_min: float, peak: float, net: float, ctrl: Dict[str, Any]) -> Dict[str, Any]:
    """v486 exit decision spine.

    청산 조건을 여러 if에 흩뜨리지 않고 우선순위별로 한곳에서 결정한다.
    우선순위: 하드손절 → 빠른실패 → 익절선 → 보호익절 → 수익권 연장 → 지지부진 → 시간종료.
    """
    protect_trigger = fnum(ctrl.get("protect_trigger_pct"), default=0.70)
    protect_floor = adaptive_protect_floor(peak, ctrl)
    protect_giveback = fnum(ctrl.get("protect_giveback_pct"), default=0.55)
    giveback = max(0.0, peak - net)
    entry_profile = str(pos.get("entry_profile") or (pos.get("canonical_entry_decision") if isinstance(pos.get("canonical_entry_decision"), dict) else {}).get("entry_profile") or "normal_common")
    exit_profile = str(pos.get("exit_profile") or (pos.get("canonical_entry_decision") if isinstance(pos.get("canonical_entry_decision"), dict) else {}).get("exit_profile") or "normal_exit")
    d: Dict[str, Any] = {
        "schema": "exit_decision_spine_v535_profiles",
        "action": "hold",
        "reason": "",
        "detail": "보유",
        "age_min": round(age_min, 4),
        "net_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "giveback_pct": round(giveback, 4),
        "protect_floor_pct": round(protect_floor, 4),
        "entry_profile": entry_profile,
        "exit_profile": exit_profile,
    }

    # v535) 급등형 paper-test 전용 빠른실패/보호/추적. 일반 후보는 기존 청산 유지.
    if entry_profile == "spike":
        spike_stop = fnum(ctrl.get("spike_stop_loss_pct"), default=-0.60)
        if net <= spike_stop:
            d.update({"action": "close", "reason": "stop_loss", "detail": f"급등형 손절선 도달: 현재 {net:+.2f}%"})
            return d
        # 60~90초 안에 +0.20~0.30도 못 찍으면 빠른 실패.
        if entry_profile == "spike" and age_min >= fnum(ctrl.get("spike_fast_fail_after_min"), default=1.5) and peak < fnum(ctrl.get("spike_fast_fail_peak_under_pct"), default=0.25) and net <= fnum(ctrl.get("spike_fast_fail_net_under_pct"), default=0.05):
            d.update({"action": "close", "reason": "spike_fast_fail_stop", "detail": f"급등형 빠른실패: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
            return d
        # 수익권 진입 후 보호익절.
        if peak >= fnum(ctrl.get("spike_protect_trigger_pct"), default=0.70):
            spike_floor = fnum(ctrl.get("spike_protect_floor_pct"), default=0.30)
            spike_giveback = fnum(ctrl.get("spike_protect_giveback_pct"), default=0.55)
            if net <= spike_floor or giveback >= spike_giveback:
                d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"급등형 보호익절: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호 {spike_floor:+.2f}% / 반납 {giveback:+.2f}%"})
                return d
        # 더 가는 놈은 고정익절보다 최고수익 trailing 우선.
        if peak >= 3.00 and giveback >= 0.95:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if peak >= 2.00 and giveback >= 0.70:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if peak >= 1.20 and giveback >= 0.45:
            d.update({"action": "close", "reason": "spike_runner_trailing", "detail": f"급등형 러너 추적청산: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 반납 {giveback:+.2f}%"})
            return d
        if entry_profile == "spike" and age_min >= fnum(ctrl.get("spike_fast_time_exit_min"), default=8.0) and peak < 0.70:
            d.update({"action": "close", "reason": "spike_time_exit", "detail": f"급등형 시간청산: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
            return d

    # 1) 하드 손절은 최우선이다.
    stop_loss = fnum(ctrl.get("stop_loss_pct"), default=-0.55)
    if net <= stop_loss:
        d.update({"action": "close", "reason": "stop_loss", "detail": f"손절선 도달: 현재 {net:+.2f}%"})
        return d

    # 2) 진입 후 반응 없는 후보는 빨리 정리한다.
    if should_fast_fail(age_min, peak, net, ctrl):
        d.update({"action": "close", "reason": "fast_fail_stop", "detail": f"빠른실패 정리: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
        return d

    # 3) 명시 익절선 도달.
    take_profit = fnum(ctrl.get("take_profit_pct"), default=1.20)
    if net >= take_profit:
        d.update({"action": "close", "reason": "take_profit", "detail": f"익절선 도달: 현재 {net:+.2f}%"})
        return d

    # 4) 수익권 보호. +0.70% 이상은 기존 보호익절보다 더 먼저 본다.
    if peak >= protect_trigger and (net <= protect_floor or giveback >= protect_giveback):
        d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"수익권 보호: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호선 {protect_floor:+.2f}% / 반납 {giveback:+.2f}%"})
        return d

    # 4-1) +0.45~0.70% 갔다가 거의 본전까지 반납하는 케이스 방지.
    soft_trigger = fnum(ctrl.get("profit_soft_protect_trigger_pct"), default=0.45)
    soft_floor = fnum(ctrl.get("profit_soft_protect_floor_pct"), default=0.10)
    soft_giveback = fnum(ctrl.get("profit_soft_protect_giveback_pct"), default=0.45)
    if peak >= soft_trigger and (net <= soft_floor or giveback >= soft_giveback):
        d.update({"action": "close", "reason": "protect_stop_after_tp", "detail": f"수익권 소프트 보호: 최고 {peak:+.2f}% / 현재 {net:+.2f}% / 보호선 {soft_floor:+.2f}% / 반납 {giveback:+.2f}%"})
        return d

    # 5) 15분 time_exit 직전, 살아있는 수익권 주도흐름은 1회 연장한다.
    time_exit_min = fnum(ctrl.get("time_exit_minutes"), default=15.0)
    if age_min >= time_exit_min:
        ok_extend, why = _should_extend_profit_run(pos, age_min, peak, net, ctrl)
        if ok_extend:
            d.update({"action": "extend", "reason": "time_exit_extend", "detail": why})
            return d

    # 6) 지지부진.
    if age_min >= fnum(ctrl.get("slow_minutes"), default=20.0) and peak < fnum(ctrl.get("slow_peak_under_pct"), default=0.25) and net <= 0.10:
        d.update({"action": "close", "reason": "slow_no_progress", "detail": f"지지부진: 보유 {age_min:.1f}분 / 최고 {peak:+.2f}% / 현재 {net:+.2f}%"})
        return d

    # 7) 일반 time_exit.
    if age_min >= time_exit_min:
        d.update({"action": "close", "reason": "time_exit", "detail": f"시간종료: 보유 {age_min:.1f}분"})
        return d
    return d




def _v494_fast_fail_cause(row: Dict[str, Any]) -> Dict[str, Any]:
    """fast_fail 원인 표시용. 청산조건은 변경하지 않는다."""
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    trace = row.get("entry_timing_trace") if isinstance(row.get("entry_timing_trace"), dict) else {}
    if not trace and isinstance(diag, dict) and isinstance(diag.get("entry_timing_trace"), dict):
        trace = diag.get("entry_timing_trace")
    peak = fnum(row.get("peak_pct"), default=0.0)
    pnl = fnum(row.get("pnl_pct"), default=fnum(row.get("last_pnl_pct"), default=0.0))
    age_min = fnum(row.get("age_min"), default=0.0)
    source_age = fnum(trace.get("source_age_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    source_to_promo = fnum(trace.get("source_to_promotion_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    paper_delay = fnum(trace.get("paper_read_delay_sec"), default=0.0) if isinstance(trace, dict) else 0.0
    react = fnum(diag.get("price_reaction_pct"), default=0.0) if isinstance(diag, dict) else 0.0
    buy = fnum(diag.get("buy_ratio"), default=-1.0) if isinstance(diag, dict) else -1.0
    sustain = fnum(diag.get("buy_sustain_1m"), default=-1.0) if isinstance(diag, dict) else -1.0
    spread = fnum(diag.get("spread_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    slip = fnum(diag.get("slippage_pct"), default=-1.0) if isinstance(diag, dict) else -1.0
    reasons: List[str] = []
    label = "진입후반응없음"
    if source_to_promo >= 60 or source_age >= 120 or paper_delay >= 45:
        label = "늦은진입 의심"
        if source_age >= 120: reasons.append(f"감지후 {source_age/60.0:.1f}분")
        if source_to_promo >= 60: reasons.append(f"S1승격까지 {source_to_promo:.0f}초")
        if paper_delay >= 45: reasons.append(f"paper읽기 {paper_delay:.0f}초")
    elif react < 0.10:
        label = "진입반응 약함"
        reasons.append(f"가격반응 {react:+.2f}%")
    elif buy >= 0.70 and sustain >= 0.70 and peak <= 0.02:
        label = "체결은 좋지만 가격 안 감"
        reasons.append(f"매수 {buy:.2f} / 지속 {sustain:.2f} / 최고 {peak:+.2f}%")
    elif spread >= 0.20 or slip >= 0.20:
        label = "스프레드·미끄러짐 부담"
        if spread >= 0: reasons.append(f"스프 {spread:.2f}%")
        if slip >= 0: reasons.append(f"미끄러짐 {slip:.2f}%")
    else:
        reasons.append(f"최고 {peak:+.2f}% / 최종 {pnl:+.2f}% / 보유 {age_min:.1f}분")
    return {
        "schema": "fast_fail_cause_v494",
        "label": label,
        "reasons": reasons[:5],
        "source_age_sec": round(source_age, 1),
        "source_to_promotion_sec": round(source_to_promo, 1),
        "paper_read_delay_sec": round(paper_delay, 1),
        "price_reaction_pct": round(react, 4),
        "buy_ratio": round(buy, 4) if buy >= 0 else None,
        "buy_sustain_1m": round(sustain, 4) if sustain >= 0 else None,
        "spread_pct": round(spread, 4) if spread >= 0 else None,
        "slippage_pct": round(slip, 4) if slip >= 0 else None,
    }


def _v494_fast_fail_cause_line(row: Dict[str, Any]) -> str:
    obj = row.get("fast_fail_cause") if isinstance(row.get("fast_fail_cause"), dict) else {}
    if not obj:
        return ""
    rs = obj.get("reasons") if isinstance(obj.get("reasons"), list) else []
    tail = " / " + " / ".join(str(x) for x in rs[:3]) if rs else ""
    return f"- 빠른실패원인: {obj.get('label','-')}{tail}"

def close_review_tag(peak: float, pnl: float, reason: str) -> str:
    giveback = peak - pnl
    if peak >= 0.70 and pnl < 0:
        return "보호익절 필요 후보"
    if peak >= 0.70 and giveback >= 0.55:
        return "수익 되돌림 큼"
    if reason == "fast_fail_stop":
        return "빠른실패 정리 작동"
    if pnl <= -0.60 and peak < 0.25:
        return "빠른실패 정리 후보"
    if reason == "protect_stop_after_tp":
        return "보호익절 작동"
    if pnl > 0 and peak - pnl <= 0.35:
        return "수익 보존 양호"
    return "관찰"

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:
    ticker = normalize_ticker(pos.get("ticker"))
    entry = fnum(pos.get("entry_price"), default=0.0)
    if not ticker or entry <= 0:
        return pos, None
    price = live_price(ticker, fnum(pos.get("current_price"), default=entry))
    gross = ((price / entry) - 1.0) * 100.0 if entry else 0.0
    net = gross - fnum(ctrl.get("fee_pct_roundtrip"), default=0.10)
    pos["current_price"] = price
    pos["last_pnl_pct"] = round(net, 4)
    pos["peak_pct"] = max(fnum(pos.get("peak_pct"), default=0.0), net)
    pos["trough_pct"] = min(fnum(pos.get("trough_pct"), default=0.0), net)
    pos["last_update"] = now_ts()
    opened_at = fnum(pos.get("opened_at"), default=now_ts())
    age_min = (now_ts() - opened_at) / 60.0
    peak = fnum(pos.get("peak_pct"), default=0.0)
    decision = _exit_decision_spine(pos, age_min, peak, net, ctrl)
    pos["exit_decision_spine"] = decision
    pos["last_exit_decision"] = decision.get("action")
    pos["last_exit_decision_reason"] = decision.get("reason") or "hold"
    pos["last_exit_decision_detail"] = decision.get("detail") or "보유"
    if decision.get("action") == "extend":
        ext_count = int(fnum(pos.get("time_exit_extension_count"), default=0)) + 1
        extend_min = fnum(ctrl.get("profit_run_extend_minutes"), default=15.0)
        pos["time_exit_extension_count"] = ext_count
        pos["time_exit_extended_at"] = now_ts()
        pos["time_exit_extended_until_age_min"] = round(age_min + extend_min, 4)
        pos["time_exit_extension_reason"] = decision.get("detail") or "수익권 유동보유 연장"
        return pos, None
    if decision.get("action") != "close":
        return pos, None
    reason = str(decision.get("reason") or "").strip()
    detail = str(decision.get("detail") or reason).strip()
    if not reason:
        return pos, None
    closed_ts = now_ts()
    hold_sec = max(0, int(closed_ts - opened_at))
    closed = dict(pos)
    current_main_version = active_main_version()
    if current_main_version:
        # v434: 성과판용 버전은 후보/OPEN에서 넘어온 구버전(v2.13.385 등)을
        # 더 이상 우선하지 않는다. 원본값은 raw로 보관하고 집계용 key만 현재 본선으로 재연결한다.
        raw_version_before_close = closed.get("score_main_version") or closed.get("closed_main_version") or closed.get("main_version") or closed.get("deploy_version") or closed.get("opened_main_version")
        if raw_version_before_close and not closed.get("source_main_version_raw"):
            closed["source_main_version_raw"] = raw_version_before_close
        for key in ("score_main_version", "closed_main_version", "opened_main_version", "main_version", "deploy_version"):
            closed[key] = current_main_version
    closed.update({
        "closed_at": closed_ts,
        "closed_at_text": iso_ts(closed_ts),
        "exit_price": price,
        "pnl_pct": round(net, 4),
        "peak_pct": round(peak, 4),
        "trough_pct": round(fnum(pos.get("trough_pct"), default=0.0), 4),
        "missed_profit_pct": round(max(0.0, peak - net), 4),
        "giveback_pct": round(max(0.0, peak - net), 4),
        "went_negative_after_profit": bool(peak >= 0.70 and net < 0),
        "close_review_tag": close_review_tag(peak, net, reason),
        "age_min": round(age_min, 2),
        "hold_sec": hold_sec,
        "exit_reason": reason,
        "exit_rule": reason,
        "exit_rule_label": EXIT_LABELS.get(reason, reason),
        "exit_rule_reason": detail,
        "exit_decision_schema": "exit_decision_spine_v486",
        "exit_decision_spine": decision,
        "time_exit_extension_count": int(fnum(pos.get("time_exit_extension_count"), default=0)),
        "time_exit_extension_reason": pos.get("time_exit_extension_reason") or "",
        "closed_paper_version": VERSION,
        "close_source": "paper_bot_v0.174_profile_final_gate_aligned",
    })
    if reason == "fast_fail_stop":
        try:
            cause = _v494_fast_fail_cause(closed)
            closed["fast_fail_cause"] = cause
            closed["fast_fail_cause_label"] = cause.get("label")
            closed["fast_fail_cause_reasons"] = cause.get("reasons") or []
        except Exception as exc:
            log_error("v494_fast_fail_cause", exc)
    return pos, closed


def fmt_price(v: Any) -> str:
    x = fnum(v, default=0.0)
    if x >= 1000:
        return f"{x:,.0f}"
    if x >= 1:
        return f"{x:,.4f}"
    return f"{x:,.8f}"


def send_message(text: str) -> None:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return
    try:
        data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": text[:3900], "disable_web_page_preview": "true"}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data=data)
        urllib.request.urlopen(req, timeout=5).read()
    except Exception as exc:
        log_error("send_message", exc)


def notify_opened(pos: Dict[str, Any]) -> None:
    t = normalize_ticker(pos.get("ticker"))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ""
    diag = pos.get("entry_diagnostics") if isinstance(pos.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(pos.get("entry_timing_trace") or (diag.get("entry_timing_trace") if isinstance(diag, dict) else {})) if bool(load_control().get("notify_entry_timing_trace", True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    send_message(
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_closed(row: Dict[str, Any]) -> None:
    t = normalize_ticker(row.get("ticker"))
    diag = row.get("entry_diagnostics") if isinstance(row.get("entry_diagnostics"), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get("entry_timing_trace") or (diag.get("entry_timing_trace") if isinstance(diag, dict) else {})) if bool(load_control().get("notify_entry_timing_trace", True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    send_message(
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )




def _decision_line(obj: Any, label: str) -> str:
    if not isinstance(obj, dict):
        return f"- {label}: -"
    t = obj.get("ticker") or "-"
    status = obj.get("status") or "-"
    reason = str(obj.get("reason") or "-")
    react = fnum(obj.get("price_reaction_pct"), default=0.0)
    buy = fnum(obj.get("buy_ratio"), default=-1.0)
    sustain = fnum(obj.get("buy_sustain_1m"), default=-1.0)
    spread = fnum(obj.get("spread_pct"), default=-1.0)
    nums = []
    nums.append(f"반응 {react:+.2f}%")
    if buy >= 0:
        nums.append(f"매수 {buy:.2f}")
    if sustain >= 0:
        nums.append(f"지속 {sustain:.2f}")
    if spread >= 0:
        nums.append(f"스프 {spread:.2f}%")
    return f"- {label}: {t} / {status} / {' · '.join(nums)} / {reason[:180]}"


def _summary_reason_text(obj: Any) -> str:
    if not isinstance(obj, dict):
        return "-"
    reason = str(obj.get("reason") or "").strip()
    if not reason:
        reasons = obj.get("block_reasons") or obj.get("missing_info") or []
        if isinstance(reasons, list) and reasons:
            reason = str(reasons[0]).strip()
    return reason[:160] if reason else "-"


def _summary_counter_add(counter: Counter, text: str, amount: int = 1) -> None:
    text = str(text or "").strip()
    if not text or text == "-":
        return
    # 너무 긴 종목별 수치가 TOP을 어지럽히지 않도록 앞부분만 묶는다.
    key = text.split("/")[0].strip()[:90]
    if key:
        counter[key] += max(1, int(amount))


def _summary_top(counter: Counter, limit: int = 5) -> str:
    if not isinstance(counter, Counter) or not counter:
        return "-"
    return " / ".join(f"{k} {v}" for k, v in counter.most_common(limit))


def _reset_s1_summary_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "cycles": 0,
        "s1_seen": 0,
        "selected_s1": 0,
        "paper_final_block": 0,  # legacy counter name
        "paper_entry_hold": 0,
        "micro_preopen_wait": 0,
        "opened": 0,
        "closed": 0,
        "latest_count_max": 0,
        "fresh_count_max": 0,
        "final_block_reasons": Counter(),
        "skip_reasons": Counter(),
        "last_paper_final_block": None,
        "last_skip": None,
        "last_open_try": None,
        "last_s1_seen": None,
    }
    _S1_DECISION_SUMMARY_BUCKET.clear()
    _S1_DECISION_SUMMARY_BUCKET.update(bucket)
    return _S1_DECISION_SUMMARY_BUCKET


def _ensure_s1_summary_bucket() -> Dict[str, Any]:
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET, dict) or not _S1_DECISION_SUMMARY_BUCKET.get("start_ts"):
        return _reset_s1_summary_bucket(now_ts())
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("final_block_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["final_block_reasons"] = Counter()
    if not isinstance(_S1_DECISION_SUMMARY_BUCKET.get("skip_reasons"), Counter):
        _S1_DECISION_SUMMARY_BUCKET["skip_reasons"] = Counter()
    return _S1_DECISION_SUMMARY_BUCKET


def notify_s1_decision_summary(pick_stats: Dict[str, Any], opened_count: int = 0, closed_count: int = 0, ctrl: Optional[Dict[str, Any]] = None) -> None:
    """S1/final block 흐름은 30분 단위로 묶어 보낸다.

    OPEN/CLOSED 즉시 알림은 유지한다. 후보/OPEN보류/무반응 재확인은 매 cycle마다
    보내지 않고, 1시간 동안 누적해서 가장 많은 보류 사유와 마지막 사례만 보여준다.
    조건/전략/장부는 건드리지 않는 알림 안정화 계층이다.
    """
    if not isinstance(pick_stats, dict):
        return
    ctrl = ctrl if isinstance(ctrl, dict) else {}
    if not bool(ctrl.get("notify_on_s1_decision_summary", True)):
        return

    now = now_ts()
    interval = fnum(
        ctrl.get("notify_s1_decision_summary_interval_sec", ctrl.get("notify_s1_decision_summary_min_interval_sec", 3600)),
        default=3600.0,
    )
    interval = max(3600.0, interval)  # v513: 후보요약은 최소 1시간. 조건/전략 판단은 유지.
    bucket = _ensure_s1_summary_bucket()

    s1_seen = int(fnum(pick_stats.get("s1_seen"), default=0.0))
    selected = int(fnum(pick_stats.get("selected_s1"), default=0.0))
    final_block = int(fnum(pick_stats.get("paper_final_block"), default=0.0))
    entry_hold = int(fnum(pick_stats.get("paper_entry_hold"), default=final_block))
    micro_wait = int(fnum(pick_stats.get("micro_preopen_wait"), default=0.0))

    bucket["cycles"] = int(bucket.get("cycles", 0)) + 1
    bucket["s1_seen"] = int(bucket.get("s1_seen", 0)) + s1_seen
    bucket["selected_s1"] = int(bucket.get("selected_s1", 0)) + selected
    bucket["paper_final_block"] = int(bucket.get("paper_final_block", 0)) + final_block
    bucket["paper_entry_hold"] = int(bucket.get("paper_entry_hold", 0)) + entry_hold
    bucket["micro_preopen_wait"] = int(bucket.get("micro_preopen_wait", 0)) + micro_wait
    bucket["opened"] = int(bucket.get("opened", 0)) + int(opened_count or 0)
    bucket["closed"] = int(bucket.get("closed", 0)) + int(closed_count or 0)
    bucket["latest_count_max"] = max(int(bucket.get("latest_count_max", 0)), int(fnum(pick_stats.get("latest_count"), default=0.0)))
    bucket["fresh_count_max"] = max(int(bucket.get("fresh_count_max", 0)), int(fnum(pick_stats.get("merged_fresh"), default=0.0)))

    last_block = pick_stats.get("last_paper_entry_hold") or pick_stats.get("last_paper_final_block")
    last_skip = pick_stats.get("last_skip")
    last_open = pick_stats.get("last_open_try")
    last_seen = pick_stats.get("last_s1_seen")

    if isinstance(last_block, dict):
        bucket["last_paper_final_block"] = last_block
        _summary_counter_add(bucket["final_block_reasons"], _summary_reason_text(last_block), amount=max(1, final_block))
    if isinstance(last_skip, dict):
        bucket["last_skip"] = last_skip
        _summary_counter_add(bucket["skip_reasons"], _summary_reason_text(last_skip), amount=1)
    if isinstance(last_open, dict):
        bucket["last_open_try"] = last_open
    if isinstance(last_seen, dict):
        bucket["last_s1_seen"] = last_seen

    elapsed = now - fnum(bucket.get("start_ts"), default=now)
    if elapsed < interval:
        return

    meaningful = (
        int(bucket.get("s1_seen", 0))
        + int(bucket.get("selected_s1", 0))
        + int(bucket.get("paper_entry_hold", bucket.get("paper_final_block", 0)))
        + int(bucket.get("opened", 0))
        + int(bucket.get("closed", 0))
    )
    if meaningful <= 0:
        _reset_s1_summary_bucket(now)
        return

    final_top = _summary_top(bucket.get("final_block_reasons"), limit=5)
    skip_top = _summary_top(bucket.get("skip_reasons"), limit=5)
    title = "🧭 paper S1 1시간 재확인/보류 요약"
    if "무반응" in final_top:
        title = "🧭 paper 1시간 무반응 재확인 보류 요약"

    minutes = max(1, int(round(elapsed / 60.0)))
    lines = [
        title,
        f"- 기간: 약 {minutes}분 / cycle {bucket.get('cycles', 0)}회",
        f"- S1감지 {bucket.get('s1_seen', 0)} / OPEN선택 {bucket.get('selected_s1', 0)} / OPEN보류 {bucket.get('paper_entry_hold', bucket.get('paper_final_block', 0))}",
        f"- OPEN {bucket.get('opened', 0)} / CLOSED {bucket.get('closed', 0)} / micro대기 {bucket.get('micro_preopen_wait', 0)}",
        f"- 후보 max latest {bucket.get('latest_count_max', 0)} / fresh {bucket.get('fresh_count_max', 0)}",
        f"- 보류 TOP: {final_top}",
        f"- 스킵 TOP: {skip_top}",
        _decision_line(bucket.get("last_paper_final_block"), "마지막 OPEN보류"),
        _decision_line(bucket.get("last_open_try"), "마지막 OPEN시도"),
        _decision_line(bucket.get("last_s1_seen"), "마지막 S1감지"),
        f"- paper: {VERSION}",
    ]
    send_message("\n".join(lines))
    _reset_s1_summary_bucket(now)


def _reset_hot_market_bucket(now: Optional[float] = None) -> Dict[str, Any]:
    ts = fnum(now, default=now_ts())
    bucket = {
        "start_ts": ts,
        "last_immediate_ts": 0.0,
        "cycles": 0,
        "hot_seen": 0,
        "best_by_ticker": {},
        "last_cache_age": None,
        "last_by_ticker": {},
    }
    _HOT_MARKET_NOTIFY_BUCKET.clear(); _HOT_MARKET_NOTIFY_BUCKET.update(bucket); return _HOT_MARKET_NOTIFY_BUCKET


def _ensure_hot_market_bucket() -> Dict[str, Any]:
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET, dict) or not _HOT_MARKET_NOTIFY_BUCKET.get("start_ts"):
        return _reset_hot_market_bucket(now_ts())
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("best_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["best_by_ticker"] = {}
    if not isinstance(_HOT_MARKET_NOTIFY_BUCKET.get("last_by_ticker"), dict):
        _HOT_MARKET_NOTIFY_BUCKET["last_by_ticker"] = {}
    return _HOT_MARKET_NOTIFY_BUCKET


def _load_hot_rank_rows(ctrl: Dict[str, Any]) -> Tuple[List[Dict[str, Any]], float, Dict[str, Any]]:
    obj = load_json(FILES.get("hot_rank", BASE_DIR / "clean_scanner_hot_rank_cache.json"), {}) or {}
    if not isinstance(obj, dict): return [], 999999.0, {}
    updated = fnum(obj.get("updated_ts"), default=0.0)
    age = now_ts() - updated if updated > 0 else 999999.0
    rows = obj.get("rows") if isinstance(obj.get("rows"), list) else []
    ttl = fnum(ctrl.get("notify_market_hot_cache_ttl_sec"), default=90.0)
    if age > max(10.0, ttl): return [], age, obj
    return [r for r in rows if isinstance(r, dict)], age, obj


def _hot_row_score(row: Dict[str, Any]) -> float:
    c1=fnum(row.get("scanner_change_1m_pct"),default=0.0); c3=fnum(row.get("scanner_change_3m_pct"),default=0.0)
    r1=fnum(row.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(row.get("scanner_hot_rank_3m"),default=9999.0)
    return max(0.0,c1)*4.0 + max(0.0,c3)*2.0 + max(0.0,12.0-min(r1,r3))


def _hot_candidate_stage_index() -> Dict[str, Dict[str, Any]]:
    """hot-rank 알림에 후보판정 단계만 붙인다. OPEN/조건 판단은 바꾸지 않는다."""
    idx: Dict[str, Dict[str, Any]] = {}
    try:
        for r in read_jsonl_tail(FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 300):
            if not isinstance(r, dict):
                continue
            t = normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if not t:
                continue
            idx[t] = r
    except Exception:
        pass
    return idx


def _candidate_stage_label_for_hot(ticker: str, idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    if not ticker or not isinstance(idx, dict):
        return "후보 -"
    r = idx.get(ticker)
    if not isinstance(r, dict):
        return "후보없음"
    st = str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
    if st not in {"S1", "S2", "S3", "X"}:
        st = "-"
    return f"후보 {st}"




def _v514_short_text(value: Any, limit: int = 38) -> str:
    if value is None:
        return ""
    if isinstance(value, (list, tuple)):
        parts = [str(x).strip() for x in value if str(x).strip()]
        txt = " / ".join(parts[:3])
    elif isinstance(value, dict):
        parts = []
        for k, v in value.items():
            if v in (None, "", [], {}):
                continue
            parts.append(f"{k}:{v}")
        txt = " / ".join(parts[:3])
    else:
        txt = str(value).strip()
    txt = re.sub(r"\s+", " ", txt)
    if len(txt) > limit:
        txt = txt[:limit-1] + "…"
    return txt

def _v514_first_text(row: Dict[str, Any], keys: Iterable[str], limit: int = 38) -> str:
    if not isinstance(row, dict):
        return ""
    for k in keys:
        if k in row and row.get(k) not in (None, "", [], {}):
            txt = _v514_short_text(row.get(k), limit=limit)
            if txt:
                return txt
    return ""

def _v514_candidate_stage_detail_for_hot(ticker: str, idx: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[str, str, str, str]:
    """hot-rank 1시간 요약용. 후보단계/막힘/부족/paper상태를 canonical latest row에서만 읽는다."""
    if not ticker or not isinstance(idx, dict):
        return "후보 -", "", "", "paper -"
    r = idx.get(ticker)
    if not isinstance(r, dict):
        return "후보없음", "", "", "paper not_seen"
    st = str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
    if st not in {"S1", "S2", "S3", "X"}:
        st = "-"
    block = _v514_first_text(r, (
        "s1_block_reason", "final_block_reason", "block_reason", "main_block_reason",
        "reject_reason", "entry_block_reason", "reason", "candidate_reason",
        "막힘", "block_reasons", "reasons"
    ), limit=44)
    missing = _v514_first_text(r, (
        "missing_reason", "missing_info", "missing_tags", "lack_reason", "info_missing", "부족",
    ), limit=34)
    risk = _v514_first_text(r, (
        "risk_tags", "risk_reason", "structure_risk_tags", "spike_guard_reasons", "stale_reasons", "위험"
    ), limit=34)
    reason_parts = []
    if block: reason_parts.append(block)
    if risk: reason_parts.append("위험 " + risk)
    if missing: reason_parts.append("부족 " + missing)
    reason = " / ".join(reason_parts[:3])
    # paper 상태는 OPEN 판단이 아니라, paper가 볼 수 있는 후보인지 확인하기 위한 표시만 한다.
    if st == "S1":
        pstate = "paper open대상"
    elif st in {"S2", "S3"}:
        pstate = "paper not_s1"
    elif st == "X":
        pstate = "paper 제외"
    else:
        pstate = "paper not_seen"
    seen = _v514_first_text(r, ("paper_state", "paper_status", "handoff_status", "paper_trace_status"), limit=24)
    if seen:
        pstate = "paper " + seen
    return f"후보 {st}", reason, pstate, str(r.get("strategy_label") or r.get("strategy_key") or r.get("strategy") or "")

def _v514_time_label_from_row(row: Dict[str, Any]) -> str:
    ts = fnum(row.get("detected_ts"), row.get("first_seen_ts"), row.get("created_at"), row.get("updated_ts"), row.get("ts"), default=0.0)
    if ts <= 0:
        return "포착 -"
    try:
        return "포착 " + time.strftime("%H:%M:%S", time.localtime(ts))
    except Exception:
        return "포착 -"

def _format_hot_row(row: Dict[str, Any], stage_idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:
    t=normalize_ticker(row.get("ticker") or row.get("market") or row.get("symbol")) or "-"
    c1=fnum(row.get("scanner_change_1m_pct"),default=0.0); c3=fnum(row.get("scanner_change_3m_pct"),default=0.0)
    r1=row.get("scanner_hot_rank_1m") or "-"; r3=row.get("scanner_hot_rank_3m") or "-"
    price=row.get("current_price") or row.get("price") or row.get("trade_price")
    stage, reason, pstate, strat = _v514_candidate_stage_detail_for_hot(t, stage_idx)
    base = f"{t} {fmt_price(price)} / 1m {c1:+.2f}% #{r1} · 3m {c3:+.2f}% #{r3} / {stage}"
    extras = []
    tl = _v514_time_label_from_row(row)
    if tl != "포착 -":
        extras.append(tl)
    if strat:
        extras.append(strat)
    if reason:
        extras.append("이유 " + reason)
    if pstate:
        extras.append(pstate)
    if extras:
        return base + " / " + " / ".join(extras[:4])
    return base


def notify_market_hot_summary(ctrl: Optional[Dict[str, Any]] = None) -> None:
    # 시장 급등 관찰 알림. 매수/진입 조건은 바꾸지 않고, 실시간 알림만 강한 급등 중심으로 줄인다.
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    if not bool(ctrl.get("notify_market_hot_alert", True)): return
    bucket=_ensure_hot_market_bucket(); rows, age, meta=_load_hot_rank_rows(ctrl); now=now_ts()
    interval=max(3600.0,fnum(ctrl.get("notify_market_hot_summary_interval_sec"),default=3600.0))
    immediate_interval=max(3600.0,fnum(ctrl.get("notify_market_hot_global_min_interval_sec"),default=3600.0))
    ticker_cooldown=max(3600.0,fnum(ctrl.get("notify_market_hot_ticker_cooldown_sec", ctrl.get("notify_market_hot_immediate_min_interval_sec")),default=3600.0))
    max_items=max(1,int(fnum(ctrl.get("notify_market_hot_max_items"),default=4)))
    top_n=max(1,int(fnum(ctrl.get("notify_market_hot_rank_top_n"),default=5)))
    weak_th1=fnum(ctrl.get("notify_market_hot_1m_pct"),default=0.80); weak_th3=fnum(ctrl.get("notify_market_hot_3m_pct"),default=1.50)
    strong_th1=fnum(ctrl.get("notify_market_hot_immediate_1m_pct"),default=1.50); strong_th3=fnum(ctrl.get("notify_market_hot_immediate_3m_pct"),default=2.50)
    stage_idx = _hot_candidate_stage_index()
    good=[]
    strong=[]
    for r in rows:
        c1=fnum(r.get("scanner_change_1m_pct"),default=0.0); c3=fnum(r.get("scanner_change_3m_pct"),default=0.0)
        r1=fnum(r.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(r.get("scanner_hot_rank_3m"),default=9999.0)
        is_good = c1>=weak_th1 or c3>=weak_th3 or (r1<=top_n and c1>=0.20) or (r3<=top_n and c3>=0.40)
        is_strong = c1>=strong_th1 or c3>=strong_th3 or (r1<=3 and c1>=weak_th1) or (r3<=3 and c3>=weak_th3)
        if is_good:
            rr=dict(r); rr["_hot_score"]=_hot_row_score(rr); good.append(rr)
            if is_strong:
                strong.append(rr)
    good.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    strong.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    bucket["cycles"]=int(bucket.get("cycles",0))+1
    bucket["hot_seen"]=int(bucket.get("hot_seen",0))+len(good)
    bucket["strong_seen"]=int(bucket.get("strong_seen",0))+len(strong)
    bucket["last_cache_age"]=round(age,1) if age<999999 else None
    best=bucket.get("best_by_ticker") if isinstance(bucket.get("best_by_ticker"),dict) else {}
    for r in good[:max_items*3]:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if t and (t not in best or _hot_row_score(r)>_hot_row_score(best[t])):
            best[t]=r
    bucket["best_by_ticker"]=best

    last_by_ticker=bucket.get("last_by_ticker") if isinstance(bucket.get("last_by_ticker"),dict) else {}
    fresh_strong=[]
    for r in strong:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t:
            continue
        if now-fnum(last_by_ticker.get(t),default=0.0) >= ticker_cooldown:
            fresh_strong.append(r)
    if bool(ctrl.get("notify_market_hot_immediate_enabled", False)) and fresh_strong and now-fnum(bucket.get("last_immediate_ts"),default=0.0)>=immediate_interval:
        lines=[
            "⚡ 강한 급등 감지 / hot-rank",
            f"- 즉시 기준 1m +{strong_th1:.2f}% 또는 3m +{strong_th3:.2f}% / 약한 급등은 1시간 요약",
            f"- 신규/쿨다운 통과 {min(len(fresh_strong), max_items)}개 · 같은 종목 {int(round(ticker_cooldown/60.0))}분 쿨다운 · 전체 {int(round(immediate_interval/60.0))}분 묶음",
            "- 매수 알림 아님 · S1/OPEN 여부는 별도 판단",
        ]
        for r in fresh_strong[:max_items]:
            lines.append("- "+_format_hot_row(r, stage_idx))
            t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol"))
            if t:
                last_by_ticker[t]=now
        bucket["last_by_ticker"]=last_by_ticker
        lines.append(f"- paper: {VERSION}")
        send_message("\n".join(lines))
        bucket["last_immediate_ts"]=now
    elapsed=now-fnum(bucket.get("start_ts"),default=now)
    if elapsed<interval:
        return
    best_rows=list(best.values()); best_rows.sort(key=lambda x:_hot_row_score(x), reverse=True)
    if not best_rows:
        _reset_hot_market_bucket(now); return
    minutes=max(1,int(round(elapsed/60.0)))
    lines=["🧭 시장 hot-rank 1시간 요약", f"- 기간 약 {minutes}분 / cycle {bucket.get('cycles',0)}회 / 감지누적 {bucket.get('hot_seen',0)} / 강한급등 {bucket.get('strong_seen',0)}", f"- cache age {bucket.get('last_cache_age','-')}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}", "- 매수 알림 아님 · 많이 오른 종목/포착시간/후보단계 연결 확인용"]
    for r in best_rows[:max_items]:
        lines.append("- "+_format_hot_row(r, stage_idx))
    lines.append(f"- paper: {VERSION}")
    send_message("\n".join(lines))
    _reset_hot_market_bucket(now)


def _score_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) > 0)
    losses = max(0, n - wins)
    total = sum(fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows)
    return {"n": n, "wins": wins, "losses": losses, "win_rate": (wins / n * 100.0 if n else 0.0), "total": total, "avg": (total / n if n else 0.0)}


def _score_bucket(row: Dict[str, Any]) -> str:
    stage = str(row.get("candidate_grade") or row.get("s_stage") or row.get("stage") or row.get("grade") or "S1").upper()
    if stage in {"S", "STRICT", "OPEN"}:
        return "S1"
    if stage not in {"S1", "S2", "S3", "X"}:
        return "S1"
    return stage


def _strategy_key(row: Dict[str, Any]) -> str:
    for k in ("strategy_primary", "strategy_bucket_primary", "strategy_key", "strategy", "strategy_name"):
        v = row.get(k)
        if v:
            return str(v)
    return "unknown"


# v434: 성과판 집계용 key는 score_main_version → closed_main_version만 우선한다.
# 후보/worker의 source_version/brain_version은 실제 실행 메인버전이 아니므로
# version_summary 집계 원천에서 제거한다. 필요 시 raw 필드로만 추적한다.
_MAIN_VERSION_FIELDS = (
    "score_main_version", "closed_main_version",
    "main_version", "deploy_version", "opened_main_version",
    "entry_main_version", "source_main_version", "main_bot_version", "main_file",
    "deploy_target", "target", "source_file", "restore_build", "main_build",
    "deploy_build", "source_build",
)
_RAW_VERSION_TRACE_FIELDS = ("source_version", "brain_version", "source_main_version_raw")


def _normalize_main_version_key(v: Any, field: str = "") -> str:
    """main/deploy version 표기를 v2.13.xxx 단일 key로 맞춘다.

    v432에서 단순 v2.13.xxx만 정규화해도 score가 0전으로 남았다.
    원인은 과거 CLOSED가 v390, v427_v390_main..., coinbot_main_v2_13_390.py
    같은 단축/빌드 표기를 갖고 있을 수 있기 때문이다.

    단, paper_bot_v0.132 같은 paper/worker 버전을 main 버전으로 오인하지 않도록
    vNNN 단축 표기는 field 이름이나 값에 main/deploy/수익형 단서가 있을 때만 허용한다.
    """
    if v is None:
        return ""
    s = str(v).strip()
    if not s:
        return ""
    m = re.search(r"(?:^|[^0-9])2[_.]13[_.](\d{1,4})(?:[^0-9]|$)", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    m = re.search(r"v2\.13\.(\d{1,4})", s)
    if m:
        return f"v2.13.{int(m.group(1))}"
    field_l = str(field or "").lower()
    value_l = s.lower()
    mainish = any(x in field_l for x in ("main", "deploy", "target", "brain")) or any(
        x in value_l for x in ("main", "deploy", "target", "수익형", "coinbot_main")
    )
    if mainish:
        hits = re.findall(r"(?:^|[^0-9])v(\d{3,4})(?:[^0-9]|$)", s)
        # v390/v391 같은 main shorthand만 허용한다. v0.132/paper version은 여기 걸리지 않는다.
        if hits:
            n = int(hits[-1])
            if 300 <= n <= 9999:
                return f"v2.13.{n}"
    return ""


def _iter_version_source_values(row: Dict[str, Any]) -> Iterable[Tuple[str, Any]]:
    for k in _MAIN_VERSION_FIELDS:
        if k in row:
            yield k, row.get(k)
    # 과거 CLOSED는 원본 후보(raw)나 entry_context 안에 main/deploy 표기가 남는 경우가 있다.
    # 장부를 다시 계산하지 않고, 이미 CLOSED row 안에 들어 있는 값만 살핀다.
    for parent_key in ("raw", "entry_context", "entry_diagnostics", "source_event", "meta", "metadata"):
        obj = row.get(parent_key)
        if isinstance(obj, dict):
            for k in _MAIN_VERSION_FIELDS:
                if k in obj:
                    yield f"{parent_key}.{k}", obj.get(k)
            nested = obj.get("entry_context")
            if isinstance(nested, dict):
                for k in _MAIN_VERSION_FIELDS:
                    if k in nested:
                        yield f"{parent_key}.entry_context.{k}", nested.get(k)


def _paper_version_num(v: Any) -> int:
    m = re.search(r"paper_bot_v0\.(\d+)", str(v or ""))
    return int(m.group(1)) if m else 0


def _version_num_from_key(key: str) -> int:
    m = re.search(r"v2\.13\.(\d+)", str(key or ""))
    return int(m.group(1)) if m else 0


def _is_stale_main_key(key: str, active: str, legacy: str, recent_paper: bool) -> bool:
    if not key or not active or not recent_paper:
        return False
    if legacy and key == legacy and key != active:
        return True
    # 현재 실행 메인보다 현저히 오래된 key는 후보 raw/구 DEPLOY_TARGET 오염으로 본다.
    # 장부 원본은 그대로 두고 성과 cache 집계에서만 보정한다.
    kn = _version_num_from_key(key)
    an = _version_num_from_key(active)
    return bool(kn and an and kn < an - 20)


def _main_version_key(row: Dict[str, Any]) -> str:
    active = active_main_version()
    legacy = _legacy_deploy_target_version()
    recent_paper = _paper_version_num(row.get("closed_paper_version") or row.get("opened_paper_version")) >= 128

    # 1순위: v434 이후 CLOSED가 명시적으로 찍는 성과판용 버전.
    # 단, 구 DEPLOY_TARGET/raw 오염 key는 score cache 집계에서만 active로 보정한다.
    candidate_keys: List[str] = []
    for field in ("score_main_version", "closed_main_version"):
        key = _normalize_main_version_key(row.get(field), field)
        if key:
            candidate_keys.append(key)
            if _is_stale_main_key(key, active, legacy, recent_paper):
                continue
            return key

    # 2순위: row 안에 남은 다른 main/deploy 계열 필드.
    for field, val in _iter_version_source_values(row):
        if field in {"score_main_version", "closed_main_version"}:
            continue
        key = _normalize_main_version_key(val, field)
        if not key:
            continue
        candidate_keys.append(key)
        if _is_stale_main_key(key, active, legacy, recent_paper):
            continue
        return key

    # 3순위: 최근 paper가 닫은 행이라도 명시 key가 없으면 active로 덮지 않는다.
    # 이유: paper-only 업그레이드 직후 active main을 무조건 쓰면 과거 CLOSED가 현재판으로 빨려 들어간다.
    # 실제 stale key 보정은 위 _is_stale_main_key()에서만 처리한다.
    if candidate_keys:
        return candidate_keys[0]
    return "unknown"





def _v463_as_list(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, dict):
        return [f"{k}:{val}" for k, val in list(v.items())[:6]]
    if isinstance(v, str) and v.strip():
        parts = [p.strip() for p in re.split(r"[/,|]", v) if p.strip()]
        return parts or [v.strip()]
    return []


def _v463_entry_source(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for key in ("entry_diagnostics", "entry_context", "raw"):
        obj = row.get(key)
        if isinstance(obj, dict):
            out.append(obj)
            for sub in ("entry_diagnostics", "entry_context", "structure", "orderflow", "micro", "feature"):
                vv = obj.get(sub)
                if isinstance(vv, dict):
                    out.append(vv)
    out.append(row)
    return out


def _v463_first(row: Dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    for src in _v463_entry_source(row):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                return src.get(k)
    return default


def _v463_entry_summary(row: Dict[str, Any]) -> Dict[str, Any]:
    tags: List[str] = []
    risks: List[str] = []
    for src in _v463_entry_source(row):
        for k in ("structure_tags", "structure_good_tags", "matched_strategies", "strategy_tags"):
            tags.extend(_v463_as_list(src.get(k)))
        for k in ("structure_risk_tags", "risk_tags", "entry_missing_info", "missing_info"):
            risks.extend(_v463_as_list(src.get(k)))
    seen: set[str] = set()
    tags = [x for x in tags if not (x in seen or seen.add(x))][:5]
    seen = set()
    risks = [x for x in risks if not (x in seen or seen.add(x))][:5]
    reaction = fnum(_v463_first(row, ("price_reaction_pct", "price_reaction", "reaction_pct")), default=0.0)
    buy = fnum(_v463_first(row, ("buy_ratio", "buy_trade_ratio", "micro_buy_ratio")), default=-1.0)
    sustain = fnum(_v463_first(row, ("buy_sustain_1m", "micro_buy_ratio_sustain_1m", "buy_ratio_1m")), default=-1.0)
    spread = fnum(_v463_first(row, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct")), default=-1.0)
    metrics_parts = [f"반응 {reaction:+.2f}%"]
    if buy >= 0:
        metrics_parts.append(f"매수 {buy:.2f}")
    if sustain >= 0:
        metrics_parts.append(f"지속 {sustain:.2f}")
    if spread >= 0:
        metrics_parts.append(f"스프 {spread:.2f}%")
    return {
        "structure_tags": tags,
        "risk_tags": risks,
        "metrics": {"price_reaction_pct": reaction, "buy_ratio": buy, "buy_sustain_1m": sustain, "spread_pct": spread},
        "metrics_text": " · ".join(metrics_parts),
    }


def _recent_closed_summary(row: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ticker": normalize_ticker(row.get("ticker")),
        "pnl_pct": round(fnum(row.get("pnl_pct"), row.get("profit_pct"), default=0.0), 4),
        "peak_pct": round(fnum(row.get("peak_pct"), default=0.0), 4),
        "trough_pct": round(fnum(row.get("trough_pct"), default=0.0), 4),
        "exit_reason": row.get("exit_reason") or row.get("exit_rule") or "-",
        "exit_rule_label": row.get("exit_rule_label") or row.get("exit_reason") or "-",
        "age_min": row.get("age_min"),
        "hold_sec": row.get("hold_sec"),
        "closed_at": fnum(row.get("closed_at"), default=0.0),
        "closed_at_text": row.get("closed_at_text") or "",
        "opened_at_text": row.get("opened_at_text") or "",
        "close_review_tag": row.get("close_review_tag") or "-",
        "strategy": row.get("strategy_label") or row.get("strategy") or row.get("strategy_key") or "-",
        "version": _main_version_key(row),
        "score_main_version_raw": row.get("score_main_version") or "",
        "closed_main_version_raw": row.get("closed_main_version") or "",
        "source_main_version_raw": row.get("source_main_version_raw") or "",
        "entry_summary": _v463_entry_summary(row),
    }


def _build_recent_12h(rows: List[Dict[str, Any]], hours: float = 12.0) -> Dict[str, Any]:
    cutoff = now_ts() - hours * 3600.0
    recent = [r for r in rows if fnum(r.get("closed_at"), default=0.0) >= cutoff]
    by_version: Dict[str, List[Dict[str, Any]]] = {}
    by_reason = Counter()
    for r in recent:
        by_version.setdefault(_main_version_key(r), []).append(r)
        by_reason[str(r.get("exit_reason") or r.get("exit_rule") or "unknown")] += 1
    return {
        "schema": "paper_recent_12h_v467_score_key_strict",
        "window_hours": hours,
        "since_ts": cutoff,
        "since_text": iso_ts(cutoff),
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "global": _score_stat(recent),
        "by_version": {k: _score_stat(v) for k, v in by_version.items()},
        "version_keys": sorted(by_version.keys()),
        "exit_reason_counts": dict(by_reason.most_common(8)),
        "recent_closed": [_recent_closed_summary(r) for r in recent[-10:]],
        "active_main_version": active_main_version(),
        "active_main_version_source": active_main_version_detail()[1],
        "legacy_deploy_target_version": _legacy_deploy_target_version(),
    }



# v543: 전략별 승리군/손실군 비교 분석 캐시
# 조건/청산/paper 장부는 변경하지 않고 score cache에 분석용 요약만 추가한다.
def _v543_median(xs: List[float]) -> float:
    vals = sorted(float(x) for x in xs if x is not None)
    if not vals:
        return 0.0
    m = len(vals) // 2
    if len(vals) % 2:
        return vals[m]
    return (vals[m - 1] + vals[m]) / 2.0


def _v543_avg(xs: List[float]) -> float:
    vals = [float(x) for x in xs if x is not None]
    return sum(vals) / len(vals) if vals else 0.0


def _v543_metric(row: Dict[str, Any], names: Tuple[str, ...], default: float = 0.0) -> float:
    return fnum(_v463_first(row, names), default=default)


def _v543_metric_summary(rows: List[Dict[str, Any]], names: Tuple[str, ...]) -> Dict[str, Any]:
    vals: List[float] = []
    for r in rows:
        val = _v463_first(r, names)
        if val in (None, "", [], {}):
            continue
        vals.append(fnum(val, default=0.0))
    if not vals:
        return {"n": 0, "avg": 0.0, "median": 0.0, "min": 0.0, "max": 0.0}
    return {
        "n": len(vals),
        "avg": round(_v543_avg(vals), 4),
        "median": round(_v543_median(vals), 4),
        "min": round(min(vals), 4),
        "max": round(max(vals), 4),
    }


def _v543_counter_tags(rows: List[Dict[str, Any]], keys: Tuple[str, ...], limit: int = 6) -> Dict[str, int]:
    """v544: risk/structure tag counts are per-trade, not per-source.

    The v543 producer scanned several nested sources for each CLOSED row. If the same
    tag was present in row + context + diagnostics, it was counted multiple times,
    making values such as `스프레드부담 675` appear from only 110 losing trades.
    This keeps one vote per tag per CLOSED trade.
    """
    c: Counter = Counter()
    for r in rows:
        row_seen = set()
        for src in _v463_entry_source(r):
            for key in keys:
                for x in _v463_as_list(src.get(key)):
                    sx = str(x).strip()
                    if sx and sx not in {"-", "None", "unknown"}:
                        row_seen.add(sx)
        for sx in row_seen:
            c[sx] += 1
    return dict(c.most_common(limit))


def _v544_tag_rate_map(counts: Dict[str, int], denom: int) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    d = max(int(denom or 0), 1)
    for k, v in (counts or {}).items():
        n = int(v or 0)
        out[str(k)] = {"count": n, "rate": round(n * 100.0 / d, 1)}
    return out


def _v544_loss_combo_counter(rows: List[Dict[str, Any]], limit: int = 6) -> Dict[str, int]:
    """Loss-pattern combos for S2 recheck design.

    This is a diagnostic producer only. It does not change S1/S2/S3 criteria.
    Each CLOSED row contributes at most one count per combo.
    """
    combo_c: Counter = Counter()
    for r in rows:
        tags = set()
        for src in _v463_entry_source(r):
            for key in ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info"):
                for x in _v463_as_list(src.get(key)):
                    sx = str(x).strip()
                    if sx and sx not in {"-", "None", "unknown"}:
                        tags.add(sx)
        react = _v543_metric(r, ("price_reaction_pct", "price_reaction", "reaction_pct"), 0.0)
        buy = _v543_metric(r, ("buy_ratio", "buy_trade_ratio", "micro_buy_ratio"), 0.0)
        sustain = _v543_metric(r, ("buy_sustain_1m", "micro_buy_ratio_sustain_1m", "buy_ratio_1m"), 0.0)
        spread = _v543_metric(r, ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"), 0.0)
        slip = _v543_metric(r, ("slippage_pct", "expected_slippage_pct", "micro_slippage_pct"), spread)
        comps = set()
        if react >= 0.30:
            comps.add("가격반응높음/추격")
        if buy < 0.70:
            comps.add("매수체결약함")
        if sustain < 0.70:
            comps.add("1분지속약함")
        if spread >= 0.45 or "스프레드부담" in tags:
            comps.add("스프레드부담")
        if slip >= 0.45 or "미끄러짐부담" in tags:
            comps.add("미끄러짐부담")
        for risk in ("윗꼬리위험", "되돌림위험", "고점권가격반응약함", "채널상단과열", "거래량없는돌파", "매도압력부담"):
            if risk in tags:
                comps.add(risk)
        if len(comps) >= 2:
            # Most useful for strategy design: a compact 2~3 factor signature.
            priority = ["가격반응높음/추격", "스프레드부담", "미끄러짐부담", "1분지속약함", "매수체결약함", "윗꼬리위험", "되돌림위험", "거래량없는돌파", "매도압력부담"]
            ordered = [x for x in priority if x in comps]
            key = " + ".join(ordered[:3])
            if key:
                combo_c[key] += 1
    return dict(combo_c.most_common(limit))


def _v544_peak_summary(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    peaks: List[float] = []
    finals: List[float] = []
    givebacks: List[float] = []
    for r in rows:
        final = fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0)
        peak_raw = _v463_first(r, ("max_profit_pct", "peak_profit_pct", "highest_profit_pct", "best_profit_pct", "max_unrealized_pct", "mfe_pct"))
        peak = fnum(peak_raw, default=final)
        peaks.append(peak)
        finals.append(final)
        givebacks.append(peak - final)
    return {
        "n": len(rows),
        "peak_avg": round(_v543_avg(peaks), 4),
        "peak_median": round(_v543_median(peaks), 4),
        "final_avg": round(_v543_avg(finals), 4),
        "giveback_avg": round(_v543_avg(givebacks), 4),
        "giveback_median": round(_v543_median(givebacks), 4),
    }


def _v543_outcome_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    return _score_stat(rows)


def _v543_build_strategy_outcome_analysis(by_strategy: Dict[str, List[Dict[str, Any]]]) -> Dict[str, Any]:
    metric_defs: Dict[str, Tuple[str, ...]] = {
        "price_reaction_pct": ("price_reaction_pct", "price_reaction", "reaction_pct"),
        "buy_ratio": ("buy_ratio", "buy_trade_ratio", "micro_buy_ratio"),
        "buy_sustain_1m": ("buy_sustain_1m", "micro_buy_ratio_sustain_1m", "buy_ratio_1m"),
        "spread_pct": ("spread_pct", "micro_spread_pct", "orderbook_spread_pct"),
        "slippage_pct": ("slippage_pct", "expected_slippage_pct", "micro_slippage_pct"),
        "fresh_age_sec": ("micro_age_sec", "orderflow_age_sec", "fresh_age_sec", "quote_age_sec"),
    }
    out: Dict[str, Any] = {}
    for strategy, rows in by_strategy.items():
        if not rows:
            continue
        wins = [r for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) > 0]
        losses = [r for r in rows if fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) <= 0]
        win_pnls = [fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in wins]
        loss_pnls = [fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in losses]
        gain = sum(x for x in win_pnls if x > 0)
        loss_abs = abs(sum(x for x in loss_pnls if x < 0))
        metric_obj: Dict[str, Any] = {}
        for name, keys in metric_defs.items():
            win_sum = _v543_metric_summary(wins, keys)
            loss_sum = _v543_metric_summary(losses, keys)
            metric_obj[name] = {
                "win": win_sum,
                "loss": loss_sum,
                "gap_loss_minus_win": round(fnum(loss_sum.get("avg"), default=0.0) - fnum(win_sum.get("avg"), default=0.0), 4),
            }
        out[strategy] = {
            "all": _v543_outcome_stat(rows),
            "wins": _v543_outcome_stat(wins),
            "losses": _v543_outcome_stat(losses),
            "avg_win_pct": round(_v543_avg(win_pnls), 4),
            "avg_loss_pct": round(_v543_avg(loss_pnls), 4),
            "payoff_ratio": round((_v543_avg(win_pnls) / abs(_v543_avg(loss_pnls))) if loss_pnls and _v543_avg(loss_pnls) != 0 else 0.0, 4),
            "profit_factor": round((gain / loss_abs) if loss_abs > 0 else (gain if gain > 0 else 0.0), 4),
            "expectancy_pct": round(_v543_avg([fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0) for r in rows]), 4),
            "metrics": metric_obj,
            "win_top_risks": _v543_counter_tags(wins, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")),
            "loss_top_risks": _v543_counter_tags(losses, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")),
            "win_top_structures": _v543_counter_tags(wins, ("structure_tags", "structure_good_tags", "matched_strategies", "strategy_tags")),
            "loss_top_structures": _v543_counter_tags(losses, ("structure_tags", "structure_good_tags", "matched_strategies", "strategy_tags")),
            "win_top_risk_rates": _v544_tag_rate_map(_v543_counter_tags(wins, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")), len(wins)),
            "loss_top_risk_rates": _v544_tag_rate_map(_v543_counter_tags(losses, ("risk_tags", "structure_risk_tags", "entry_missing_info", "missing_info")), len(losses)),
            "loss_pattern_combos": _v544_loss_combo_counter(losses),
            "win_peak_summary": _v544_peak_summary(wins),
            "loss_peak_summary": _v544_peak_summary(losses),
        }
    return out



# =============================================================================
# paper_bot v0.185 / v557: today strategy score cache
# - CLOSED 장부는 삭제하지 않는다.
# - 기본 성과판이 오늘 전략 성과를 먼저 볼 수 있게 today_* cache만 추가한다.
# =============================================================================
def _v557_row_ts(row: Dict[str, Any]) -> float:
    for k in ("closed_at", "closed_ts", "exit_ts", "exited_at", "timestamp", "ts", "updated_at", "created_at"):
        v = row.get(k)
        if v not in (None, "", [], {}):
            try:
                if isinstance(v, str):
                    vv = v.replace("T", " ").replace("Z", "").strip()
                    if vv.replace(".", "", 1).isdigit():
                        return float(vv)
                    import datetime as _dt
                    try:
                        return _dt.datetime.fromisoformat(vv).timestamp()
                    except Exception:
                        pass
                return float(v)
            except Exception:
                continue
    return 0.0


def _v557_today_start_ts(nowv: Optional[float] = None) -> float:
    import datetime as _dt
    n = _dt.datetime.fromtimestamp(nowv or now_ts())
    return _dt.datetime(n.year, n.month, n.day).timestamp()


def _v557_filter_today(rows: List[Dict[str, Any]], nowv: Optional[float] = None) -> List[Dict[str, Any]]:
    start = _v557_today_start_ts(nowv)
    end = (nowv or now_ts()) + 5
    out=[]
    for r in rows:
        ts = _v557_row_ts(r)
        if ts <= 0:
            # Active CLOSED tail may contain legacy rows without timestamp. Do not include in today.
            continue
        if start <= ts <= end:
            out.append(r)
    return out


def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:
    """현재 활성 CLOSED tail만 읽어 메인봇 cache 성과판을 만든다.

    전체 장부 재계산은 하지 않는다. 가드봇이 활성 CLOSED를 최근분으로 줄이는 정책과 맞춘다.
    """
    try:
        rows = read_jsonl_tail(FILES["closed"], 300)
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        by_grade: Dict[str, List[Dict[str, Any]]] = {}
        by_strategy: Dict[str, List[Dict[str, Any]]] = {}
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        by_strategy_version: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        by_profile: Dict[str, List[Dict[str, Any]]] = {}
        by_profile_exit: Dict[str, List[Dict[str, Any]]] = {}
        by_strategy_exit: Dict[str, List[Dict[str, Any]]] = {}
        for r in rows:
            strategy_key = _strategy_key(r)
            version_key = _main_version_key(r)
            by_grade.setdefault(_score_bucket(r), []).append(r)
            by_strategy.setdefault(strategy_key, []).append(r)
            by_version.setdefault(version_key, []).append(r)
            by_version_strategy.setdefault(version_key, {}).setdefault(strategy_key, []).append(r)
            by_strategy_version.setdefault(strategy_key, {}).setdefault(version_key, []).append(r)
            prof = str(r.get("entry_profile") or "unknown")
            if prof in {"spike_fast_early", "spike_runner"}:
                prof = "spike"
            elif prof in {"spike_fast_watch", "normal_watch"}:
                prof = "watch"
            by_profile.setdefault(prof, []).append(r)
            ex = str(r.get("exit_reason") or r.get("exit_rule") or "-")
            by_profile_exit.setdefault(f"{prof}:{ex}", []).append(r)
            by_strategy_exit.setdefault(f"{strategy_key}:{ex}", []).append(r)
        grade_stats = {k: _score_stat(v) for k, v in by_grade.items()}
        grade_stats["ALL"] = _score_stat(rows)
        strategy_stats = {k: _score_stat(v) for k, v in by_strategy.items()}
        strategy_exit_stats = {k: _score_stat(v) for k, v in by_strategy_exit.items()}
        strategy_outcome_analysis = _v543_build_strategy_outcome_analysis(by_strategy)
        version_summary = {k: _score_stat(v) for k, v in by_version.items()}
        version_strategy_stats = {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in by_version_strategy.items()}
        strategy_version_stats = {sk: {vk: _score_stat(vrows) for vk, vrows in vmap.items()} for sk, vmap in by_strategy_version.items()}
        today_by_strategy: Dict[str, List[Dict[str, Any]]] = {}
        today_by_version_strategy: Dict[str, Dict[str, List[Dict[str, Any]]]] = {}
        for tr in today_rows:
            tsk = _strategy_key(tr)
            tvk = _main_version_key(tr)
            today_by_strategy.setdefault(tsk, []).append(tr)
            today_by_version_strategy.setdefault(tvk, {}).setdefault(tsk, []).append(tr)
        today_strategy_stats = {k: _score_stat(v) for k, v in today_by_strategy.items()}
        today_version_strategy_stats = {vk: {sk: _score_stat(srows) for sk, srows in smap.items()} for vk, smap in today_by_version_strategy.items()}
        entry_profile_stats = {k: _score_stat(v) for k, v in by_profile.items()}
        profile_exit_stats = {k: _score_stat(v) for k, v in by_profile_exit.items()}
        obj = {
            "schema": "paper_score_cache_v098_today_strategy",
            "version": VERSION,
            "paper_version": VERSION,
            "build": BUILD_LABEL,
            "score_scope": "active_closed_tail_cache_only",
            "updated_at": nowv,
            "updated_at_text": iso_ts(),
            "current_closed_count": len(rows),
            "closed_count": len(rows),
            "source": "paper_bot_active_closed_tail",
            "global_stats": _score_stat(rows),
            "today_scope": "local_day_midnight_to_now_cache_only",
            "today_start_ts": _v557_today_start_ts(nowv),
            "today_start_text": iso_ts(_v557_today_start_ts(nowv)),
            "today_closed_count": len(today_rows),
            "today_global_stats": _score_stat(today_rows),
            "today_strategy_stats": today_strategy_stats,
            "today_version_strategy_stats": today_version_strategy_stats,
            "grade_stats": grade_stats,
            "strategy_primary_stats": strategy_stats,
            "strategy_stats": strategy_stats,
            "strategy_exit_stats": strategy_exit_stats,
            "strategy_primary_exit_stats": strategy_exit_stats,
            "strategy_outcome_analysis": strategy_outcome_analysis,
            "entry_profile_stats": entry_profile_stats,
            "profile_exit_stats": profile_exit_stats,
            # v433 단일 본선: 메인 /version_score는 이 key만 읽는다.
            "version_summary": version_summary,
            # v549: 같은 score cache 안에서 버전별 × 전략별 성과를 봉인한다.
            # 메인봇은 CLOSED 장부를 직접 보지 않고 이 캐시만 읽는다.
            "version_strategy_stats": version_strategy_stats,
            "strategy_version_stats": strategy_version_stats,
            "version_strategy_schema": "v549_version_x_strategy_cache_only",
            "version_summary_schema": "v549_strict_score_main_version_key_with_strategy",
            "version_summary_keys": sorted(version_summary.keys()),
            "recent_12h": _build_recent_12h(rows, 12.0),
            "active_main_version": active_main_version(),
            "active_main_version_source": active_main_version_detail()[1],
            "legacy_deploy_target_version": _legacy_deploy_target_version(),
            # 아래 두 key는 full/구독자가 남아 있을 수 있어 같은 내용을 복제하지만,
            # /version_score 기본 명령은 version_summary만 읽는다.
            "version_stats": version_summary,
            "main_version_stats": version_summary,
            "status_open_count": (status or {}).get("open_count") if isinstance(status, dict) else None,
        }
        save_json(FILES["score"], obj)
    except Exception as exc:
        log_error("write_score_cache", exc)

def write_status(status: Dict[str, Any]) -> None:
    global _LAST_STATUS
    base = {
        "version": VERSION,
        "active_reader_version": VERSION,
        "build": BUILD_LABEL,
        "pid": os.getpid(),
        "self_pid": os.getpid(),
        "process_pid": os.getpid(),
        "process_alive": True,
        "updated_at": now_ts(),
        "updated_at_text": iso_ts(),
        "running": True,
        "stop_reason": "running",
    }
    base.update(status)
    _LAST_STATUS = base
    write_pid()
    save_json(FILES["status"], base)





def _format_last_pick_line(key: str, pick: Dict[str, Any]) -> str:
    obj = pick.get(key) if isinstance(pick, dict) else None
    if not isinstance(obj, dict):
        label = {
            "last_s1_seen": "마지막 S1감지",
            "last_open_try": "마지막 OPEN시도",
            "last_paper_final_block": "마지막 OPEN보류",
            "last_skip": "마지막 스킵",
        }.get(key, key)
        return f"- {label}: -"
    label = {
        "last_s1_seen": "마지막 S1감지",
        "last_open_try": "마지막 OPEN시도",
        "last_paper_final_block": "마지막 OPEN보류",
        "last_skip": "마지막 스킵",
    }.get(key, key)
    t = obj.get("ticker") or "-"
    status = obj.get("status") or "-"
    reason = obj.get("reason") or "-"
    return f"- {label}: {t} / {status} / {reason}"



# v561: /pstatus는 _LAST_STATUS.pick_stats 단독값 대신 paper status/handoff/trace/open/alert spine을 읽는다.
def _v561_age_from(obj: Any) -> str:
    try:
        if not isinstance(obj, dict):
            return '-'
        ts = fnum(obj.get('updated_at') or obj.get('ts'), default=0.0)
        if ts <= 0:
            return '-'
        return f"{max(0.0, now_ts() - ts):.1f}s"
    except Exception:
        return '-'


def _v561_latest_open_alert_trace() -> Dict[str, Any]:
    try:
        rows = read_jsonl_tail(FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl'), 80)
        for r in reversed(rows):
            if isinstance(r, dict):
                return r
    except Exception as exc:
        log_error('v561_latest_open_alert_trace', exc)
    return {}


def _v561_pick_spine(status: Dict[str, Any], handoff: Dict[str, Any]) -> Dict[str, Any]:
    pick: Dict[str, Any] = {}
    if isinstance(status, dict) and isinstance(status.get('pick_stats'), dict):
        pick.update(status.get('pick_stats') or {})
    if isinstance(handoff, dict) and isinstance(handoff.get('pick_stats'), dict):
        # handoff_status는 v560부터 현재 paper_latest 기준 heartbeat이므로 최종 source로 우선한다.
        pick.update(handoff.get('pick_stats') or {})
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        for dst, keys in {
            'latest_count': ('latest_count', 'paper_latest_count'),
            'merged_fresh': ('merged_fresh', 'fresh_count'),
            's1_seen': ('s1_seen',),
            'selected_s1': ('selected_s1',),
            'paper_entry_hold': ('paper_entry_hold', 'paper_final_block'),
            'micro_preopen_wait': ('micro_preopen_wait',),
        }.items():
            if dst in pick and pick.get(dst) not in (None, ''):
                continue
            for k in keys:
                if k in src and src.get(k) not in (None, ''):
                    pick[dst] = src.get(k)
                    break
    return pick


def _v561_current_open_lines(op: Dict[str, Dict[str, Any]], limit: int = 3) -> List[str]:
    out: List[str] = []
    try:
        vals = list(op.values()) if isinstance(op, dict) else []
        for p in vals[:limit]:
            if not isinstance(p, dict):
                continue
            opened_at = fnum(p.get('opened_at'), default=0.0)
            age_min = ((now_ts() - opened_at) / 60.0) if opened_at > 0 else 0.0
            out.append(
                f"  · {normalize_ticker(p.get('ticker'))} / {p.get('candidate_grade','S1')} / "
                f"{fnum(p.get('last_pnl_pct'), default=0.0):+.2f}% / "
                f"보유 {age_min:.1f}분 / {p.get('strategy_label') or p.get('strategy') or '-'}"
            )
    except Exception as exc:
        log_error('v561_current_open_lines', exc)
    return out


def _v561_alert_line(alert: Dict[str, Any]) -> str:
    if not isinstance(alert, dict) or not alert:
        return '- 마지막 OPEN알림: -'
    ts = fnum(alert.get('ts'), default=0.0)
    age = f"{max(0.0, now_ts() - ts):.1f}s" if ts > 0 else '-'
    ok = alert.get('sent_ok')
    err = str(alert.get('error') or '').strip()
    state = 'sent_ok' if ok is True else 'error' if err else 'unknown'
    tail = f" / {err[:80]}" if err else ''
    return f"- 마지막 OPEN알림: {alert.get('ticker') or '-'} / {state} / age {age}{tail}"


def _v561_format_last_pick_line(key: str, pick: Dict[str, Any]) -> str:
    try:
        return _format_last_pick_line(key, pick)
    except Exception:
        label = {
            'last_s1_seen': '마지막 S1감지',
            'last_open_try': '마지막 OPEN시도',
            'last_paper_final_block': '마지막 OPEN보류',
            'last_skip': '마지막 스킵',
        }.get(key, key)
        return f"- {label}: -"

def pstatus_text() -> str:
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    handoff = load_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}
    trace = load_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), {}) or {}
    if not isinstance(status, dict):
        status = {}
    if not isinstance(handoff, dict):
        handoff = {}
    if not isinstance(trace, dict):
        trace = {}
    op = load_open()
    pick = _v561_pick_spine(status, handoff)
    latest = pick.get('latest_count', status.get('latest_count', handoff.get('latest_count', '-')))
    fresh = pick.get('merged_fresh', status.get('merged_fresh', handoff.get('merged_fresh', '-')))
    open_lines = _v561_current_open_lines(op)
    alert = _v561_latest_open_alert_trace()
    lines = [
        f"🧪 paper 상태 /pstatus ({VERSION})",
        f"- running: {status.get('running', True)} / open {len(op)} / status age {_v561_age_from(status)} / handoff age {_v561_age_from(handoff)} / trace age {_v561_age_from(trace)}",
        f"- 이번 cycle: OPEN {status.get('opened_this_cycle',0)} / CLOSED {status.get('closed_this_cycle',0)} / elapsed {status.get('elapsed_sec','-')}s",
        f"- 후보: latest {latest} / fresh {fresh} / S1감지 {pick.get('s1_seen',0)} / S1선택 {pick.get('selected_s1',0)} / OPEN보류 {pick.get('paper_entry_hold', pick.get('paper_final_block',0))} / micro대기 {pick.get('micro_preopen_wait',0)}",
        f"- source: status+handoff+trace+open_alert_trace 단일판독 / handoff {handoff.get('version','-')} / trace {trace.get('version') or trace.get('trace_version') or '-'}",
        f"- 시장hot: 알림 {'ON' if load_control().get('notify_market_hot_alert', True) else 'OFF'} / cache age {max(0.0, now_ts()-fnum((load_json(FILES.get('hot_rank', BASE_DIR/'clean_scanner_hot_rank_cache.json'), {}) or {}).get('updated_ts'), default=now_ts())):.1f}s",
    ]
    if open_lines:
        lines.append('- 현재 OPEN:')
        lines.extend(open_lines)
    else:
        lines.append('- 현재 OPEN: -')
    lines.extend([
        _v561_format_last_pick_line('last_s1_seen', pick),
        _v561_format_last_pick_line('last_open_try', pick),
        _v561_format_last_pick_line('last_paper_final_block', pick),
        _v561_format_last_pick_line('last_skip', pick),
        _v561_alert_line(alert),
        '- 엔진: light_runner / legacy loop 사용 안 함',
    ])
    return "\n".join(lines)

def popen_text() -> str:
    op = load_open()
    lines = [f"📂 paper OPEN /popen ({VERSION})", f"- OPEN {len(op)}개"]
    for p in list(op.values())[:20]:
        if not isinstance(p, dict):
            continue
        diag = p.get("entry_diagnostics") if isinstance(p.get("entry_diagnostics"), dict) else {}
        rs = diag.get("entry_reasons") if isinstance(diag.get("entry_reasons"), list) else []
        lines.append(f"- {normalize_ticker(p.get('ticker'))} / {fnum(p.get('last_pnl_pct'), default=0):+.2f}% / 진입 {fmt_price(p.get('entry_price'))} / 최고 {fnum(p.get('peak_pct'), default=0):+.2f}% / {p.get('strategy_label') or p.get('strategy') or '-'}")
        if rs:
            lines.append("  · 근거: " + " / ".join(str(x) for x in rs[:3]))
    return "\n".join(lines)


def perror_text() -> str:
    lines = tail_lines(FILES["error"], 40)
    recent = "\n".join(lines[-40:])[-3500:]
    return "🧯 paper 오류 /perror\n\n" + (recent if recent else "✅ 오류로그 없음")


def plog_text() -> str:
    return "🧾 paper 로그 /plog\n\n" + ("\n".join(tail_lines(FILES["log"], 50))[-3500:] or "로그 없음")




def hot_summary_text() -> str:
    ctrl = load_control()
    rows, age, meta = _load_hot_rank_rows(ctrl)
    stage_idx = _hot_candidate_stage_index()
    max_items = max(5, int(fnum(ctrl.get("notify_market_hot_max_items"), default=4)))
    top_n = max(5, int(fnum(ctrl.get("notify_market_hot_rank_top_n"), default=5)))
    weak_th1=fnum(ctrl.get("notify_market_hot_1m_pct"),default=0.80); weak_th3=fnum(ctrl.get("notify_market_hot_3m_pct"),default=1.50)
    good=[]
    for r in rows:
        c1=fnum(r.get("scanner_change_1m_pct"),default=0.0); c3=fnum(r.get("scanner_change_3m_pct"),default=0.0)
        r1=fnum(r.get("scanner_hot_rank_1m"),default=9999.0); r3=fnum(r.get("scanner_hot_rank_3m"),default=9999.0)
        if c1>=weak_th1 or c3>=weak_th3 or (r1<=top_n and c1>=0.20) or (r3<=top_n and c3>=0.40):
            rr=dict(r); rr["_hot_score"]=_hot_row_score(rr); good.append(rr)
    good.sort(key=lambda x:fnum(x.get("_hot_score"),default=0.0), reverse=True)
    lines=["🧭 시장 hot-rank 현재 요약 /hot_summary", f"- cache age {age:.1f}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}", "- 매수 알림 아님 · 많이 오른 종목/포착시간/후보단계/못 올라온 이유 확인용"]
    if not good:
        lines.append("- 표시할 급등 후보 없음")
    for r in good[:max_items]:
        lines.append("- "+_format_hot_row(r, stage_idx))
    lines.append(f"- paper: {VERSION}")
    return "\n".join(lines)

def candidate_summary_text() -> str:
    rows = read_jsonl_tail(FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl"), 300)
    fresh = [r for r in rows if isinstance(r, dict) and candidate_is_fresh(r, load_control())]
    cnt=Counter()
    reasons=Counter()
    for r in fresh:
        st=str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
        if st not in {"S1","S2","S3","X"}: st="-"
        cnt[st]+=1
        reason = _v514_first_text(r, ("s1_block_reason","final_block_reason","block_reason","reason","risk_tags","stale_reasons","missing_reason","missing_info"), limit=40)
        if reason:
            reasons[reason]+=1
    lines=["🧭 후보요약 현재 보기 /candidate_summary", f"- latest {len(rows)} / fresh {len(fresh)} / S1 {cnt.get('S1',0)} / S2 {cnt.get('S2',0)} / S3 {cnt.get('S3',0)} / 제외 {cnt.get('X',0)}"]
    if reasons:
        top = " / ".join(f"{k} {v}" for k,v in reasons.most_common(5))
        lines.append("- 못 올라온 이유 TOP: "+top)
    show=sorted(fresh, key=lambda r:fnum(r.get("score"), r.get("candidate_score"), default=0.0), reverse=True)[:5]
    if show:
        lines.append("[상위 후보]")
    for r in show:
        t=normalize_ticker(r.get("ticker") or r.get("market") or r.get("symbol")) or "-"
        st=str(r.get("candidate_grade") or r.get("s_stage") or r.get("stage") or r.get("grade") or "-").upper()
        strat=str(r.get("strategy_label") or r.get("strategy_key") or r.get("strategy") or "-")
        reason=_v514_first_text(r, ("s1_block_reason","final_block_reason","block_reason","reason","risk_tags","stale_reasons","missing_reason","missing_info"), limit=46) or "-"
        lines.append(f"- {t} · {st} · {strat} · 이유 {reason}")
    return "\n".join(lines)

def paper_hourly_text() -> str:
    return "\n\n".join([pstatus_text(), hot_summary_text(), candidate_summary_text()])

def handle_command(cmd: str) -> str:
    c = cmd.strip().split()[0].lower()
    if c in {"/pstatus", "/status"}:
        return pstatus_text()
    if c in {"/popen", "/open"}:
        return popen_text()
    if c in {"/perror", "/error"}:
        return perror_text()
    if c in {"/plog", "/log"}:
        return plog_text()
    if c in {"/pbatch", "/batch"}:
        return "\n\n".join([pstatus_text(), popen_text(), perror_text()])
    if c in {"/hot_summary", "/hot", "/phot"}:
        return hot_summary_text()
    if c in {"/candidate_summary", "/candidate", "/pcandidate"}:
        return candidate_summary_text()
    if c in {"/paper_hourly", "/hourly", "/phourly"}:
        return paper_hourly_text()
    if c in {"/pversion", "/version"}:
        return f"{VERSION} / {BUILD_LABEL}"
    if c in {"/ponce"}:
        st = run_cycle()
        return f"✅ run once: opened {st.get('opened_this_cycle')} closed {st.get('closed_this_cycle')} elapsed {st.get('elapsed_sec')}s"
    return "명령: /pstatus /popen /hot_summary /candidate_summary /paper_hourly /perror /plog /pbatch /pversion /ponce"


def poll_telegram_once() -> None:
    global _TG_OFFSET
    if not TOKEN or not ALLOWED_CHAT_ID:
        return
    try:
        params = urllib.parse.urlencode({"timeout": 0, "offset": _TG_OFFSET + 1})
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/getUpdates?{params}")
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        for upd in data.get("result", []) if isinstance(data, dict) else []:
            _TG_OFFSET = max(_TG_OFFSET, int(upd.get("update_id") or 0))
            msg = upd.get("message") or upd.get("edited_message") or {}
            chat = msg.get("chat") or {}
            chat_id = str(chat.get("id") or "")
            text = str(msg.get("text") or "")
            if not text.startswith("/"):
                continue
            if ALLOWED_CHAT_ID and chat_id != str(ALLOWED_CHAT_ID):
                continue
            ans = handle_command(text)
            old_notify = globals().get("NOTIFY_CHAT_ID")
            try:
                globals()["NOTIFY_CHAT_ID"] = chat_id
                send_message(ans)
            finally:
                globals()["NOTIFY_CHAT_ID"] = old_notify
    except Exception as exc:
        log_error("poll_telegram_once", exc)


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP, _STOP_REASON
    _STOP = True
    _STOP_REASON = f"signal_{signum}"
    try:
        st = dict(_LAST_STATUS) if _LAST_STATUS else {}
        st.update({
            "version": VERSION,
            "running": False,
            "process_alive": False,
            "stop_reason": _STOP_REASON,
            "updated_at": nowv,
            "updated_at_text": iso_ts(),
            "open_count": len(load_open()),
        })
        save_json(FILES["status"], st)
        log(f"stop requested: {_STOP_REASON}")
    except Exception:
        pass


def main() -> None:
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    startup_status = {
        "running": True,
        "startup_status": True,
        "open_count": len(load_open()),
        "open_total": len(load_open()),
        "closed_total": line_count_cached(FILES["closed"], ttl=0),
        "engine": "light_runner",
        "legacy_loop": False,
    }
    write_score_cache(startup_status)
    write_status(startup_status)
    log(f"{VERSION} started pid={os.getpid()} build={BUILD_LABEL} token={'yes' if TOKEN else 'no'} chat={'yes' if ALLOWED_CHAT_ID else 'no'}")
    last_cycle = 0.0
    last_poll = 0.0
    while not _STOP:
        try:
            ctrl = load_control()
            loop_sec = max(2.0, fnum(ctrl.get("loop_seconds"), default=8.0))
            if now_ts() - last_cycle >= loop_sec:
                run_cycle()
                last_cycle = now_ts()
            elif now_ts() - fnum(_LAST_STATUS.get("updated_at"), default=0.0) >= 10:
                hb = dict(_LAST_STATUS)
                hb.update({"heartbeat": True})
                write_status(hb)
            if now_ts() - last_poll >= 3.0:
                poll_telegram_once()
                last_poll = now_ts()
        except Exception as exc:
            log_error("main_loop", exc)
            write_status({"running": True, "last_error": f"{type(exc).__name__}: {exc}", "engine": "light_runner"})
        time.sleep(0.5)
    log(f"{VERSION} stopped reason={_STOP_REASON}")


# =============================================================================
# paper_bot v0.157 / v500: OPEN exit_plan 봉인 + 전략별 표시
# - 청산조건 숫자를 바꾸지 않고, 현재 control 기준을 entry_price 기준 가격표로 저장/알림한다.
# - 급등 진행형/눌림 재가속도 같은 paper 장부를 쓰고 strategy_key로만 분리한다.
# =============================================================================


def _v500_price_by_pct(entry: float, pct: float) -> float:
    try:
        return float(entry) * (1.0 + float(pct) / 100.0)
    except Exception:
        return 0.0


def _v500_build_exit_plan(pos: Dict[str, Any], ctrl: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ctrl = ctrl if isinstance(ctrl, dict) else load_control()
    entry = fnum(pos.get('entry_price'), default=0.0)
    tp = fnum(ctrl.get('take_profit_pct'), default=1.20)
    strong_tp = max(tp, fnum(ctrl.get('protect_big_trigger_pct'), default=1.40))
    stop = fnum(ctrl.get('stop_loss_pct'), default=-0.55)
    protect_tr = fnum(ctrl.get('protect_trigger_pct'), default=0.70)
    protect_floor = fnum(ctrl.get('protect_floor_pct'), default=0.35)
    fast_min = fnum(ctrl.get('fast_fail_after_min'), default=2.5)
    fast_peak = fnum(ctrl.get('fast_fail_peak_under_pct'), default=0.20)
    fast_loss = fnum(ctrl.get('fast_fail_loss_pct'), default=-0.35)
    time_exit = fnum(ctrl.get('time_exit_minutes'), default=15.0)
    strat = str(pos.get('strategy_key') or pos.get('strategy') or '')
    # 급등 진행형은 기존 청산조건을 바꾸지 않는다. 다만 plan 설명에서 빠른 증명 필요를 표시한다.
    style = '급등 진행형: 초반 증명 필수' if 'spike_momentum_ride' in strat else ('급등 눌림재가속: 재가속 유지 확인' if 'spike_pullback_reaccel' in strat else '기존 paper 청산 기준')
    return {
        'schema': 'paper_exit_plan_v500', 'paper_version': VERSION, 'created_at': now_ts(), 'created_at_text': iso_ts(),
        'strategy_key': strat, 'strategy_label': pos.get('strategy_label') or pos.get('strategy') or '-', 'plan_style': style,
        'entry_price': entry,
        'take_profit_pct': tp, 'take_profit_price': _v500_price_by_pct(entry, tp),
        'strong_target_pct': strong_tp, 'strong_target_price': _v500_price_by_pct(entry, strong_tp),
        'stop_loss_pct': stop, 'stop_loss_price': _v500_price_by_pct(entry, stop),
        'protect_trigger_pct': protect_tr, 'protect_trigger_price': _v500_price_by_pct(entry, protect_tr),
        'protect_floor_pct': protect_floor, 'protect_floor_price': _v500_price_by_pct(entry, protect_floor),
        'fast_fail_after_min': fast_min, 'fast_fail_peak_under_pct': fast_peak, 'fast_fail_loss_pct': fast_loss,
        'time_exit_minutes': time_exit,
        'fee_pct_roundtrip': fnum(ctrl.get('fee_pct_roundtrip'), default=0.10),
        'note': '청산조건 변경 아님. OPEN 시점에 기존 기준을 가격표로 봉인한 복기용 계획.',
    }


def _v500_exit_plan_open_lines(plan: Any, prefix: str='- ') -> List[str]:
    if not isinstance(plan, dict) or not plan:
        return [prefix + '진입계획: exit_plan 없음']
    return [
        prefix + '진입계획: ' + str(plan.get('plan_style') or '-'),
        prefix + f"목표가: 1차 {fmt_price(plan.get('take_profit_price'))}({fnum(plan.get('take_profit_pct'), default=0.0):+.2f}%) / 강한흐름 {fmt_price(plan.get('strong_target_price'))}({fnum(plan.get('strong_target_pct'), default=0.0):+.2f}%)",
        prefix + f"손절가: {fmt_price(plan.get('stop_loss_price'))}({fnum(plan.get('stop_loss_pct'), default=0.0):+.2f}%)",
        prefix + f"보호익절: 발동 {fmt_price(plan.get('protect_trigger_price'))}({fnum(plan.get('protect_trigger_pct'), default=0.0):+.2f}%) → 방어 {fmt_price(plan.get('protect_floor_price'))}({fnum(plan.get('protect_floor_pct'), default=0.0):+.2f}%)",
        prefix + f"빠른실패: {fnum(plan.get('fast_fail_after_min'), default=0.0):.1f}분 뒤 최고<{fnum(plan.get('fast_fail_peak_under_pct'), default=0.0):+.2f}% & 현재≤{fnum(plan.get('fast_fail_loss_pct'), default=0.0):+.2f}%",
        prefix + f"시간청산: {fnum(plan.get('time_exit_minutes'), default=0.0):.0f}분 / 수수료왕복 {fnum(plan.get('fee_pct_roundtrip'), default=0.0):.2f}% 반영",
    ]


def _v500_exit_plan_result_lines(row: Dict[str, Any], prefix: str='- ') -> List[str]:
    plan = row.get('exit_plan') if isinstance(row.get('exit_plan'), dict) else {}
    if not plan:
        return [prefix + '계획대비: exit_plan 없음']
    peak = fnum(row.get('peak_pct'), default=0.0); pnl = fnum(row.get('pnl_pct'), default=0.0)
    tp = fnum(plan.get('take_profit_pct'), default=0.0); ptr = fnum(plan.get('protect_trigger_pct'), default=0.0)
    stop = fnum(plan.get('stop_loss_pct'), default=0.0)
    res = []
    res.append(prefix + f"계획대비: 목표 {'도달' if peak >= tp else '미도달'} / 보호익절 {'발동권' if peak >= ptr else '미발동'} / 손절선 {'도달' if pnl <= stop else '전 종료'}")
    res.append(prefix + f"계획가격: 목표 {fmt_price(plan.get('take_profit_price'))} / 손절 {fmt_price(plan.get('stop_loss_price'))} / 보호 {fmt_price(plan.get('protect_trigger_price'))}→{fmt_price(plan.get('protect_floor_price'))}")
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    levels = diag.get('structure_levels') if isinstance(diag.get('structure_levels'), dict) else row.get('structure_levels') if isinstance(row.get('structure_levels'), dict) else {}
    if levels and levels.get('available', True):
        t1p = fnum(levels.get('expected_upside_pct'), default=0.0)
        res.append(prefix + f"구조목표: 1차 {fmt_price(levels.get('target1_price'))}({t1p:+.2f}%) / 무효 {fmt_price(levels.get('invalid_price'))} / RR {fnum(levels.get('rr_ratio'), default=0.0):.2f}")
    return res


_v500_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v500_prev_open_position(pos_id, ev)
    try:
        plan = _v500_build_exit_plan(pos, load_control())
        pos['exit_plan'] = plan
        pos['exit_plan_schema'] = plan.get('schema')
        # strategy_key가 비어 있는 구 row도 알림/성과 구분 가능하게 보강한다.
        if not pos.get('strategy_key'):
            pos['strategy_key'] = pos.get('strategy') or (ev.get('strategy_key') if isinstance(ev, dict) else '') or 'unknown'
        if not pos.get('strategy_label'):
            pos['strategy_label'] = ev.get('strategy_label') if isinstance(ev, dict) else pos.get('strategy_key')
    except Exception as exc:
        log_error('v500_exit_plan_open_position', exc)
    return pos


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ""
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(pos.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    plan_lines = "\n".join(_v500_exit_plan_open_lines(pos.get('exit_plan')))
    send_message(
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy_key') or pos.get('strategy') or '-'}\n"
        f"{plan_lines}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker'))
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ""
    if timing_line:
        extra = extra + "\n" + timing_line
    result_lines = "\n".join(_v500_exit_plan_result_lines(row))
    send_message(
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{result_lines}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy_key') or row.get('strategy') or '-'}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )



# =============================================================================
# paper_bot v0.158 / v503: OPEN→CLOSED context 봉인 보강
# - 청산조건/장부 삭제 없음.
# - strategy_key, structure/risk tags, spike late-entry guard, timing trace를 OPEN row에 고정해
#   CLOSED/version_score에서 구조 '-' 또는 위험 '-'로 빠지는 문제를 줄인다.
# =============================================================================


def _v503_list_any(v: Any) -> List[str]:
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, tuple):
        return [str(x).strip() for x in v if str(x).strip()]
    if isinstance(v, dict):
        return [f"{k}:{val}" for k, val in list(v.items())[:8]]
    if isinstance(v, str) and v.strip():
        return [x.strip() for x in re.split(r"[/,|]", v) if x.strip()] or [v.strip()]
    return []


def _v503_sources(ev: Dict[str, Any], pos: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for obj in (ev, pos, ev.get('entry_context') if isinstance(ev, dict) else None, ev.get('strategy_context') if isinstance(ev, dict) else None, ev.get('canonical_entry_decision') if isinstance(ev, dict) else None, ev.get('metrics') if isinstance(ev, dict) else None, ev.get('raw') if isinstance(ev, dict) else None):
        if isinstance(obj, dict):
            out.append(obj)
            for sub in ('entry_context','strategy_context','metrics','structure','feature','orderflow','micro','canonical_entry_decision','spike_late_entry_guard','late_entry_guard'):
                vv = obj.get(sub)
                if isinstance(vv, dict):
                    out.append(vv)
    return out


def _v503_first_from_sources(sources: List[Dict[str, Any]], keys: Iterable[str], default: Any = None) -> Any:
    for src in sources:
        for k in keys:
            if k in src and src.get(k) not in (None, '', [], {}):
                return src.get(k)
    return default


def _v503_collect_context(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    srcs = _v503_sources(ev, pos)
    tags: List[str] = []
    risks: List[str] = []
    for src in srcs:
        for k in ('structure_tags','structure_good_tags','matched_strategies','strategy_tags','tags'):
            tags.extend(_v503_list_any(src.get(k)))
        for k in ('structure_risk_tags','risk_tags','entry_missing_info','missing_info','spike_guard_reasons'):
            risks.extend(_v503_list_any(src.get(k)))
    seen=set(); tags=[x for x in tags if not (x in seen or seen.add(x))][:8]
    seen=set(); risks=[x for x in risks if not (x in seen or seen.add(x))][:8]
    guard = _v503_first_from_sources(srcs, ('spike_late_entry_guard','late_entry_guard'), {})
    if not isinstance(guard, dict):
        guard = {}
    strat_key = _v503_first_from_sources(srcs, ('strategy_key','paper_strategy_key','strategy','route','section'), pos.get('strategy_key') or 'unknown')
    strat_label = _v503_first_from_sources(srcs, ('strategy_label','paper_strategy_label','final_entry_label'), pos.get('strategy_label') or strat_key)
    ctx = {
        'schema': 'paper_entry_context_v503',
        'strategy_key': strat_key,
        'strategy_label': strat_label,
        'structure_tags': tags,
        'structure_risk_tags': risks,
        'risk_tags': risks,
        'spike_late_entry_guard': guard,
        'spike_guard_reasons': guard.get('reasons') or [],
        'drawdown_from_high_pct': _v503_first_from_sources(srcs, ('drawdown_from_high_pct','pullback_from_high_pct'), None),
        'recent_high_price': _v503_first_from_sources(srcs, ('recent_high_price','high_price'), None),
        'hot_signal_age_sec': _v503_first_from_sources(srcs, ('hot_signal_age_sec','spike_signal_age_sec','signal_age_sec'), None),
        'price_reaction_pct': _v503_first_from_sources(srcs, ('price_reaction_pct','reaction_pct','price_recheck_pct'), None),
        'buy_ratio': _v503_first_from_sources(srcs, ('buy_ratio','buy_trade_ratio','micro_buy_ratio'), None),
        'buy_sustain_1m': _v503_first_from_sources(srcs, ('buy_sustain_1m','buy_ratio_1m','micro_buy_ratio_sustain_1m'), None),
        'spread_pct': _v503_first_from_sources(srcs, ('spread_pct','micro_spread_pct','orderbook_spread_pct'), None),
        'slippage_pct': _v503_first_from_sources(srcs, ('slippage_pct','expected_slippage_pct','slippage_est_pct'), None),
        'structure_levels': _v503_first_from_sources(srcs, ('structure_levels',), {}),
        'entry_plan': _v503_first_from_sources(srcs, ('entry_plan',), {}),
        'risk_reward': _v503_first_from_sources(srcs, ('risk_reward',), {}),
        'entry_timing_spine': _v503_first_from_sources(srcs, ('entry_timing_spine',), {}),
        'late_chase_flag': _v503_first_from_sources(srcs, ('late_chase_flag',), False),
    }
    return ctx


_v503_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v503_prev_open_position(pos_id, ev)
    try:
        ctx = _v503_collect_context(ev, pos)
        pos['paper_entry_context_v503'] = ctx
        pos['strategy_key'] = ctx.get('strategy_key') or pos.get('strategy_key') or 'unknown'
        pos['strategy_label'] = ctx.get('strategy_label') or pos.get('strategy_label') or pos.get('strategy_key')
        for key in ('structure_tags','structure_risk_tags','risk_tags','spike_late_entry_guard','spike_guard_reasons','drawdown_from_high_pct','recent_high_price','hot_signal_age_sec','structure_levels','entry_plan','risk_reward','entry_timing_spine','late_chase_flag'):
            if ctx.get(key) not in (None, '', [], {}):
                pos[key] = ctx.get(key)
        # 기존 entry_context/diagnostics에도 복기 key를 병합해 version_score 요약에서 '-'로 빠지지 않게 한다.
        ec = pos.get('entry_context') if isinstance(pos.get('entry_context'), dict) else {}
        ec.update({k: v for k, v in ctx.items() if v not in (None, '', [], {})})
        pos['entry_context'] = ec
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag.setdefault('strategy_key', ctx.get('strategy_key'))
        diag.setdefault('strategy_label', ctx.get('strategy_label'))
        diag.setdefault('matched_strategies', ctx.get('structure_tags') or [])
        for _k in ('structure_levels','entry_plan','risk_reward','entry_timing_spine','late_chase_flag'):
            if ctx.get(_k) not in (None, '', [], {}):
                diag[_k] = ctx.get(_k)
        diag.setdefault('missing_info', ctx.get('risk_tags') or [])
        for k in ('price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct'):
            if ctx.get(k) is not None:
                diag[k] = ctx.get(k)
        if ctx.get('spike_guard_reasons'):
            diag['spike_guard_reasons'] = ctx.get('spike_guard_reasons')
        pos['entry_diagnostics'] = diag
        if isinstance(pos.get('exit_plan'), dict):
            pos['exit_plan']['strategy_key'] = pos.get('strategy_key')
            pos['exit_plan']['strategy_label'] = pos.get('strategy_label')
            pos['exit_plan']['hot_signal_age_sec'] = ctx.get('hot_signal_age_sec')
            pos['exit_plan']['spike_guard_reasons'] = ctx.get('spike_guard_reasons') or []
    except Exception as exc:
        log_error('v503_entry_context_seal', exc)
    return pos


def _v503_context_lines(row: Dict[str, Any], prefix: str='- ') -> List[str]:
    ctx = row.get('paper_entry_context_v503') if isinstance(row.get('paper_entry_context_v503'), dict) else {}
    if not ctx:
        ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    out: List[str] = []
    tags = _v503_list_any(row.get('structure_tags') or ctx.get('structure_tags'))
    risks = _v503_list_any(row.get('risk_tags') or row.get('structure_risk_tags') or ctx.get('risk_tags') or ctx.get('structure_risk_tags'))
    if tags:
        out.append(prefix + '구조태그: ' + ' / '.join(tags[:5]))
    if risks:
        out.append(prefix + '위험태그: ' + ' / '.join(risks[:5]))
    guard = row.get('spike_late_entry_guard') if isinstance(row.get('spike_late_entry_guard'), dict) else ctx.get('spike_late_entry_guard') if isinstance(ctx.get('spike_late_entry_guard'), dict) else {}
    if isinstance(guard, dict) and guard:
        rs = guard.get('reasons') or []
        dd = guard.get('drawdown_from_high_pct')
        if rs or dd not in (None, ''):
            out.append(prefix + '급등진입검사: ' + (' / '.join(str(x) for x in rs[:3]) if rs else f'고점대비 {fnum(dd, default=0.0):+.2f}%'))
    return out[:4]


_v503_prev_notify_opened = notify_opened

def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    # v500 알림을 유지하되 context가 비면 아래 줄은 생략된다.
    _v503_prev_notify_opened(pos)


_v503_prev_notify_closed = notify_closed

def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    # v500 CLOSED 알림은 유지. context는 row/score cache에 봉인되어 /version_score에서도 확인 가능.
    _v503_prev_notify_closed(row)


# =============================================================================
# paper_bot v0.159 / v504: 급등 urgent timing 봉인
# - OPEN row에 hot/micro/orderflow/price age와 paper_read_delay를 보존한다.
# - 알림 포맷은 v500 exit_plan을 그대로 쓰고, entry_timing_trace에 값이 들어가게 한다.
# =============================================================================


def _v504_first(src: Dict[str, Any], keys: tuple, default=None):
    if not isinstance(src, dict):
        return default
    for k in keys:
        v = src.get(k)
        if v not in (None, '', [], {}):
            return v
    return default


def _v504_build_timing_from_event(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    ec = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    timing = ev.get('entry_timing_trace') if isinstance(ev.get('entry_timing_trace'), dict) else ec.get('entry_timing_trace') if isinstance(ec.get('entry_timing_trace'), dict) else {}
    urgent = ev.get('urgent_timing_trace_v504') if isinstance(ev.get('urgent_timing_trace_v504'), dict) else ec.get('urgent_timing_trace_v504') if isinstance(ec.get('urgent_timing_trace_v504'), dict) else {}
    out = dict(timing) if isinstance(timing, dict) else {}
    out.setdefault('schema', 'paper_entry_timing_trace_v504')
    for k in ('hot_signal_age_sec','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','quote_age_sec'):
        v = _v504_first(urgent, (k,), _v504_first(ev, (k,), _v504_first(ec, (k,), None)))
        if v not in (None, ''):
            out[k] = v
    nowv = now_ts()
    source_ts = fnum(ev.get('created_at'), ev.get('candidate_created_at'), ev.get('source_created_at'), ec.get('strategy_decision_ts'), default=0.0)
    if source_ts > 1000000000:
        out['paper_read_delay_sec'] = round(max(0.0, nowv - source_ts), 3)
    dec_ts = fnum(ec.get('strategy_decision_ts'), out.get('strategy_decision_ts'), default=0.0)
    if dec_ts > 1000000000:
        out['strategy_to_paper_delay_sec'] = round(max(0.0, nowv - dec_ts), 3)
    stale = []
    for k, label, lim in (('hot_signal_age_sec','hot',45),('micro_age_sec','micro',5),('orderflow_age_sec','orderflow',5),('price_reaction_age_sec','price',10),('paper_read_delay_sec','paper',5)):
        vv = fnum(out.get(k), default=-1.0)
        if vv >= 0 and vv > lim:
            stale.append(f'{label} {vv:.1f}s')
    out['stale_reasons'] = stale[:8]
    out['fresh_for_spike_momentum'] = len(stale) == 0
    return out


def _v529_copy_s1_context(ev: Dict[str, Any], pos: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(ev, dict) or not isinstance(pos, dict):
        return pos
    ctx = ev.get('entry_context') if isinstance(ev.get('entry_context'), dict) else {}
    keys = (
        'canonical_lane','matched_strategy_keys','matched_strategy_labels',
        's1_checklist','s1_passed_conditions','s1_missing_conditions','s1_missing_names',
        's1_block_count','s1_block_score','s1_distance','s1_near_miss','s1_near_miss_level','s1_short_reason','common_entry_pass','common_entry_schema','strategy_role','entry_profile','exit_profile','profile_family','profile_decisions','canonical_entry_decision','common_entry_decision',
        'price_chg_10s','price_chg_20s','price_chg_30s','price_chg_60s','price_accel_10s','buy_ratio_10s','buy_sustain_20s','spread_widening_10s',
        'buy_sustain_1m_source','buy_sustain_1m_real','buy_sustain_1m_is_fallback','fresh_gate_ok',
        'structure_levels','entry_plan','risk_reward','entry_timing_spine','late_chase_flag','late_chase_basis'
    )
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    for k in keys:
        val = ev.get(k) if ev.get(k) not in (None, '', [], {}) else ctx.get(k)
        if val not in (None, '', [], {}):
            pos[k] = val
            diag[k] = val
    gate = ev.get('v510_final_entry_gate') or ctx.get('v510_final_entry_gate') or ev.get('v508_final_entry_gate') or ctx.get('v508_final_entry_gate')
    if isinstance(gate, dict):
        pos['v510_final_entry_gate'] = gate
        diag['v510_final_entry_gate'] = gate
        pos['paper_entry_gate_schema'] = 'v529_v510_final_entry_gate'
    pos['entry_diagnostics'] = diag
    pos['paper_s1_diagnostic_schema'] = 'paper_s1_context_v529_inline'
    return pos

_v504_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v504_prev_open_position(pos_id, ev)
    try:
        timing = _v504_build_timing_from_event(ev, pos)
        pos['entry_timing_trace'] = timing
        pos['urgent_timing_trace_v504'] = timing
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag['entry_timing_trace'] = timing
        for k in ('hot_signal_age_sec','micro_age_sec','orderflow_age_sec','price_reaction_age_sec','quote_age_sec','paper_read_delay_sec','strategy_to_paper_delay_sec'):
            if timing.get(k) not in (None, ''):
                pos[k] = timing.get(k)
                diag[k] = timing.get(k)
        if timing.get('stale_reasons'):
            diag['urgent_stale_reasons_v504'] = timing.get('stale_reasons')
            pos['urgent_stale_reasons_v504'] = timing.get('stale_reasons')
        pos['entry_diagnostics'] = diag
        if isinstance(pos.get('exit_plan'), dict):
            pos['exit_plan']['entry_timing_trace'] = timing
            pos['exit_plan']['paper_read_delay_sec'] = timing.get('paper_read_delay_sec')
    except Exception as exc:
        log_error('v504_entry_timing_seal', exc)
    try:
        pos = _v529_copy_s1_context(ev, pos)
    except Exception as exc:
        log_error('v529_s1_context_seal', exc)
    return pos

# v504: notify_opened/closed는 v500/v503 포맷을 그대로 사용한다. entry_timing_trace에 값만 보강한다.

# =============================================================================
# paper_bot v0.160 / v505: CLOSED score context source widening
# - OPEN/CLOSED already works. This only makes version_score/recent CLOSED summaries
#   read the sealed paper_entry_context/exit_plan/timing fields so structure/risk
#   does not fall back to '-'.
# =============================================================================

_v505_prev_entry_source = _v463_entry_source

def _v463_entry_source(row: Dict[str, Any]) -> List[Dict[str, Any]]:  # type: ignore[override]
    out: List[Dict[str, Any]] = []
    try:
        for key in (
            'paper_entry_context_v503', 'entry_context', 'entry_diagnostics', 'entry_timing_trace',
            'exit_plan', 'raw', 'source_event', 'meta', 'metadata'
        ):
            obj = row.get(key)
            if isinstance(obj, dict):
                out.append(obj)
                for sub in ('paper_entry_context_v503','entry_context','entry_diagnostics','canonical_entry_decision','metrics','structure','feature','orderflow','micro','spike_late_entry_guard','urgent_timing_trace_v504','structure_levels','entry_plan','risk_reward','entry_timing_spine'):
                    vv = obj.get(sub)
                    if isinstance(vv, dict):
                        out.append(vv)
        out.extend(_v505_prev_entry_source(row))
    except Exception:
        try:
            out.extend(_v505_prev_entry_source(row))
        except Exception:
            pass
    dedup: List[Dict[str, Any]] = []
    seen: set[int] = set()
    for obj in out:
        if isinstance(obj, dict) and id(obj) not in seen:
            seen.add(id(obj)); dedup.append(obj)
    return dedup

_v505_prev_entry_summary = _v463_entry_summary

def _v463_entry_summary(row: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    sm = _v505_prev_entry_summary(row)
    try:
        tags = list(sm.get('structure_tags') or [])
        risks = list(sm.get('risk_tags') or [])
        srcs = _v463_entry_source(row)
        for src in srcs:
            for k in ('structure_tags','structure_good_tags','matched_strategies','strategy_tags','tags'):
                tags.extend(_v463_as_list(src.get(k)))
            for k in ('structure_risk_tags','risk_tags','spike_guard_reasons','urgent_stale_reasons_v504','entry_missing_info','missing_info'):
                risks.extend(_v463_as_list(src.get(k)))
        if not tags:
            label = row.get('strategy_label') or row.get('paper_strategy_label') or row.get('strategy') or row.get('strategy_key')
            sk = str(row.get('strategy_key') or row.get('strategy') or '')
            if label and ('spike' in sk or '급등' in str(label)):
                tags.append(str(label))
        seen=set(); tags=[x for x in tags if str(x).strip() and not (x in seen or seen.add(x))][:5]
        seen=set(); risks=[x for x in risks if str(x).strip() and not (x in seen or seen.add(x))][:5]
        sm['structure_tags'] = tags
        sm['risk_tags'] = risks
    except Exception:
        pass
    return sm



# =============================================================================
# paper_bot v0.162 / v509: canonical latest only + hard pre-open freshness gate
# - Deletes legacy consumer sources from the runtime OPEN path.
#   Runtime OPEN reads only paper_candidates_latest.jsonl.
# - Paper opens only rows from paper_candidates_latest.jsonl that carry the canonical
#   final gate and pass fresh/open_eligible checks.
# =============================================================================


def _v508_num(*vals: Any, default: float = 999999.0) -> float:
    for v in vals:
        try:
            if v is None or v == "" or v == [] or v == {}:
                continue
            return float(v)
        except Exception:
            continue
    return default


def _v508_srcs(ev: Dict[str, Any]) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    def add(v: Any):
        if isinstance(v, dict): out.append(v)
    add(ev)
    for k in ("entry_context", "canonical_entry_decision", "entry_snapshot", "entry_timing_trace", "urgent_timing_trace_v508", "urgent_timing_trace_v504", "v510_final_entry_gate", "v508_final_entry_gate", "v507_final_entry_gate", "paper_final_safety_diagnostics", "raw"):
        add((ev or {}).get(k))
    ctx = (ev or {}).get("entry_context") if isinstance((ev or {}).get("entry_context"), dict) else {}
    for k in ("urgent_timing_trace_v508", "urgent_timing_trace_v504", "entry_timing_trace", "v510_final_entry_gate", "v508_final_entry_gate", "v507_final_entry_gate"):
        add(ctx.get(k))
    for src in list(out):
        add(src.get("age_values"))
    seen=set(); clean=[]
    for d in out:
        if id(d) not in seen:
            seen.add(id(d)); clean.append(d)
    return clean


def _v508_first(ev: Dict[str, Any], keys: Tuple[str, ...], default: float = 999999.0) -> float:
    for src in _v508_srcs(ev):
        for k in keys:
            if k in src and src.get(k) not in (None, "", [], {}):
                v = _v508_num(src.get(k), default=default)
                if v != default:
                    return v
    return default


def _v508_strategy_key(ev: Dict[str, Any]) -> str:
    return str(ev.get("strategy_key") or ev.get("paper_strategy_key") or ev.get("strategy") or ev.get("route") or "")


def _v508_is_spike(ev: Dict[str, Any]) -> bool:
    ctx = ev.get("entry_context") if isinstance(ev.get("entry_context"), dict) else {}
    dec = ev.get("canonical_entry_decision") or ctx.get("canonical_entry_decision") or ev.get("common_entry_decision") or ctx.get("common_entry_decision")
    if not isinstance(dec, dict):
        dec = {}
    p = str(ev.get("entry_profile") or ctx.get("entry_profile") or dec.get("entry_profile") or "").strip()
    if p in {"spike", "spike_fast_early", "spike_runner"}:
        return True
    sk = _v508_strategy_key(ev)
    label = str(ev.get("strategy_label") or ev.get("strategy") or "")
    return sk in {"spike_momentum_ride", "spike_pullback_reaccel"} or "급등" in label or "spike" in sk


def _v508_age_reasons(ev: Dict[str, Any]) -> Tuple[bool, List[str], Dict[str, float]]:
    nowv = now_ts()
    hot = _v508_first(ev, ("hot_signal_age_sec", "signal_age_sec", "hot"))
    micro = _v508_first(ev, ("micro_age_sec", "trade_age_sec", "micro", "trade"))
    orderflow = _v508_first(ev, ("orderflow_age_sec", "orderflow", "trade_age_sec", "micro_age_sec"), default=micro)
    price = _v508_first(ev, ("price_reaction_age_sec", "price_age_sec", "feature_age_sec", "price", "reaction_age_sec"))
    quote = _v508_first(ev, ("quote_age_sec", "ws_age_sec", "quote", "ws"))
    # paper delay is computed from the row creation timestamp.
    src_ts = event_created_ts(ev)
    paper_delay = max(0.0, nowv - src_ts) if src_ts > 0 else 999999.0
    ages = {"hot": hot, "micro": micro, "orderflow": orderflow, "price": price, "quote": quote, "paper": paper_delay}
    stale: List[str] = []
    if _v508_is_spike(ev):
        if hot > 45.0: stale.append(f"hot {hot:.1f}s")
        if micro > 5.0: stale.append(f"micro {micro:.1f}s")
        if orderflow > 5.0: stale.append(f"orderflow {orderflow:.1f}s")
        if price > 10.0: stale.append(f"price {price:.1f}s")
        if quote > 5.0: stale.append(f"quote {quote:.1f}s")
        if paper_delay > 20.0: stale.append(f"paper {paper_delay:.1f}s")
    else:
        if price >= 999998.0: stale.append("price_age_missing")
        elif price > 30.0: stale.append(f"price {price:.1f}s")
        if micro >= 999998.0: stale.append("micro_age_missing")
        elif micro > 20.0: stale.append(f"micro {micro:.1f}s")
        if paper_delay > 45.0: stale.append(f"paper {paper_delay:.1f}s")
    return len(stale) == 0, stale, ages


# v532: is_s1_candidate/paper_final_safety tail overrides removed; main bodies read canonical_entry_decision.



# =============================================================================
# v540/paper v0.176: 전략명 canonical score cache producer
# - 장부/OPEN/CLOSED/청산조건은 변경하지 않는다.
# - score cache 집계 key만 같은 전략의 구영문키/한글명/S suffix를 canonical 한글명으로 묶는다.
# =============================================================================

def _v540_clean_strategy_raw(raw: Any) -> str:
    s = str(raw or "").strip()
    if not s or s in {"-", "None", "null", "unknown"}:
        return ""
    s = s.replace("_KRW", "").replace("KRW-", "")
    s = re.sub(r"\s+", " ", s).strip()
    s = re.sub(r"\s+[SABCX]$", "", s).strip()
    return s


def _v540_strategy_label(raw: Any) -> str:
    s = _v540_clean_strategy_raw(raw)
    if not s:
        return "구버전/미분류"
    low = s.lower()
    if "hot-rank" in low or "hot_rank" in low or "hot rank" in low:
        return "hot-rank 급등 재확인"
    if "surge_rebreak" in low or "급등 후 재돌파" in s:
        return "급등 후 재돌파"
    if "breakout_early" in low or "돌파 초입" in s:
        return "돌파 초입"
    if "leader_flow_adaptive_hold" in low or "주도흐름 유동보유" in s:
        return "주도흐름 유동보유"
    if "leader_momentum" in low or "leader_momentum_continuation" in low or "주도추세" in s or "주도 추세" in s:
        return "주도추세 지속"
    if "sweep_vwap" in low or "저점 vwap" in low or "저점 VWAP" in s:
        return "저점 VWAP 회복"
    if "money_reaccel" in low or "money_flow_reaccel" in low or "pullback_reaccel" in low or "돈흐름 재가속" in s:
        return "돈흐름 재가속"
    if "공통상승조건" in s:
        return "공통상승조건"
    if s in {"구버전/미분류", "미분류"}:
        return "구버전/미분류"
    if any("가" <= ch <= "힣" for ch in s):
        return s
    return "구버전/미분류"


def _v540_strategy_candidates(row: Dict[str, Any]) -> List[Any]:
    out: List[Any] = []
    for k in (
        "strategy_primary", "strategy_bucket_primary", "strategy_bucket_primary_label",
        "primary_strategy_key", "representative_strategy_key", "paper_strategy_key",
        "strategy_key", "strategy_label", "strategy_name", "strategy",
    ):
        v = row.get(k)
        if v not in (None, "", [], {}):
            out.append(v)
    for parent in ("entry_context", "raw", "source_event", "entry_diagnostics"):
        obj = row.get(parent)
        if isinstance(obj, dict):
            for k in (
                "strategy_primary", "strategy_bucket_primary", "strategy_bucket_primary_label",
                "primary_strategy_key", "representative_strategy_key", "paper_strategy_key",
                "strategy_key", "strategy_label", "strategy_name", "strategy",
            ):
                v = obj.get(k)
                if v not in (None, "", [], {}):
                    out.append(v)
    return out


def _strategy_key(row: Dict[str, Any]) -> str:  # type: ignore[override]
    for v in _v540_strategy_candidates(row):
        lab = _v540_strategy_label(v)
        if lab != "구버전/미분류":
            return lab
    return "구버전/미분류"



# =============================================================================
# paper_bot v0.186 / v558: cache heartbeat + OPEN alert trace
# - run_cycle이 정상적으로 도는지 handoff/score/status를 같은 cycle에서 계속 갱신한다.
# - OPEN 알림 누락 의심을 추적하기 위해 OPEN 알림 시도 로그를 별도 JSONL로 남긴다.
# - 장부/조건/청산 기준은 변경하지 않는다.
# =============================================================================
def _v558_append_open_alert_trace(pos: Dict[str, Any], ok: bool, err: str = "") -> None:
    try:
        append_jsonl(FILES.get("open_alert_trace", BASE_DIR / "paper_bot_open_alert_trace.jsonl"), {
            "schema": "paper_open_alert_trace_v558",
            "version": VERSION,
            "ts": now_ts(),
            "ts_text": iso_ts(),
            "ticker": normalize_ticker(pos.get("ticker")),
            "pos_id": pos.get("pos_id") or pos.get("event_id"),
            "opened_at": pos.get("opened_at"),
            "entry_price": pos.get("entry_price"),
            "strategy": pos.get("strategy_label") or pos.get("strategy_key") or pos.get("strategy"),
            "sent_ok": bool(ok),
            "error": str(err or ""),
        })
    except Exception as exc:
        log_error("v558_open_alert_trace", exc)


def _v558_send_message_with_result(text: str) -> bool:
    ok, _err = _v561_send_message_with_result(text)
    return ok


def _v561_send_message_with_result(text: str) -> Tuple[bool, str]:
    if not TOKEN or not NOTIFY_CHAT_ID:
        return False, 'telegram_disabled: TOKEN or NOTIFY_CHAT_ID missing'
    try:
        data = urllib.parse.urlencode({"chat_id": NOTIFY_CHAT_ID, "text": text[:3900], "disable_web_page_preview": "true"}).encode("utf-8")
        req = urllib.request.Request(f"https://api.telegram.org/bot{TOKEN}/sendMessage", data=data)
        urllib.request.urlopen(req, timeout=5).read()
        return True, ''
    except Exception as exc:
        log_error('send_message', exc)
        return False, f"{type(exc).__name__}: {exc}"


def send_message(text: str) -> None:  # type: ignore[override]
    _v561_send_message_with_result(text)


def _v561_open_message_text(pos: Dict[str, Any]) -> str:
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ''
    diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    timing_line = format_entry_timing_line(pos.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ''
    if timing_line:
        extra = extra + "\n" + timing_line
    return (
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    # OPEN 알림 본문 생성 -> 실제 send 결과 -> open_alert_trace 기록을 한곳에서 처리한다.
    text = _v561_open_message_text(pos)
    ok, err = _v561_send_message_with_result(text)
    _v558_append_open_alert_trace(pos, ok, err)
    if not ok:
        log_error('notify_opened_send_result', Exception(err or 'send_message returned false'))

def _v558_latest_file_count() -> int:
    try:
        p = FILES.get("paper_latest", BASE_DIR / "paper_candidates_latest.jsonl")
        return len(read_jsonl_tail(p, 1000))
    except Exception:
        return 0






# =============================================================================

# [v582 cleanup] removed stale duplicate writer block.

# paper_bot v0.190 / v562: OPEN 생성과 알림 trace를 같은 거래로 추적
# - OPEN 장부가 생겼는데 알림 trace가 비는 상태를 막기 위해 notify_opened 시작 시점부터 JSONL에 남긴다.
# - notify_on_strict_open 비활성/notify 경로 미도달도 cycle 종료 후 open_without_alert_trace로 남긴다.
# - 조건/S등급/청산/장부는 변경하지 않는다.
# =============================================================================
def _v562_alert_trace_path() -> Path:
    return FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl')


def _v562_append_open_alert_trace(pos: Dict[str, Any], phase: str, ok: bool = False, err: str = '', note: str = '') -> None:
    try:
        append_jsonl(_v562_alert_trace_path(), {
            'schema': 'paper_open_alert_trace_v562',
            'version': VERSION,
            'build': BUILD_LABEL,
            'phase': phase,
            'ts': now_ts(),
            'ts_text': iso_ts(),
            'ticker': normalize_ticker(pos.get('ticker')),
            'pos_id': pos.get('pos_id') or pos.get('event_id'),
            'event_id': pos.get('event_id') or pos.get('pos_id'),
            'opened_at': pos.get('opened_at'),
            'opened_at_text': pos.get('opened_at_text'),
            'entry_price': pos.get('entry_price'),
            'strategy': pos.get('strategy_label') or pos.get('strategy_key') or pos.get('strategy'),
            'candidate_grade': pos.get('candidate_grade'),
            'sent_ok': bool(ok),
            'error': str(err or ''),
            'note': str(note or ''),
        })
    except Exception as exc:
        log_error('v562_open_alert_trace_append', exc)


def _v562_recent_alert_exists(pos: Dict[str, Any], since_ts: float) -> bool:
    try:
        pid = str(pos.get('pos_id') or pos.get('event_id') or '')
        ticker = normalize_ticker(pos.get('ticker'))
        for r in read_jsonl_tail(_v562_alert_trace_path(), 160):
            if not isinstance(r, dict):
                continue
            rts = fnum(r.get('ts'), default=0.0)
            if rts and rts < since_ts - 5:
                continue
            rpid = str(r.get('pos_id') or r.get('event_id') or '')
            rticker = normalize_ticker(r.get('ticker'))
            if pid and rpid == pid:
                return True
            if ticker and rticker == ticker and abs(fnum(r.get('opened_at'), default=0.0) - fnum(pos.get('opened_at'), default=0.0)) <= 5:
                return True
    except Exception as exc:
        log_error('v562_recent_alert_exists', exc)
    return False


# notify_opened 최종 override: 본문 생성 실패/텔레그램 실패도 숨기지 않고 trace에 남긴다.
def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    _v562_append_open_alert_trace(pos, 'attempt_start', False, '', 'OPEN created; alert send started')
    try:
        text = _v561_open_message_text(pos)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v562_append_open_alert_trace(pos, 'message_build_error', False, err, 'OPEN alert text build failed')
        log_error('notify_opened_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v562_append_open_alert_trace(pos, phase, ok, err, 'OPEN alert send result')
    if not ok:
        log_error('notify_opened_send_result', Exception(err or 'send_message returned false'))








# =============================================================================
# paper_bot v0.192 / v565: paper 후보 snapshot 생산부 단일화
# - latest/fresh/S1감지/S1선택/OPEN보류/micro대기는 paper_bot이 후보파일을 읽는 순간 1회 snapshot으로 확정한다.
# - run_cycle 중간 handoff write와 cycle-end heartbeat가 서로 다른 fresh를 쓰는 이중쓰기/race를 제거한다.
# - 출력부에서 보정하지 않고, handoff/status/trace/pstatus가 같은 paper_candidate_snapshot 값을 복사한다.
# - 전략 조건, S1/S2/S3 기준, 청산, OPEN/CLOSED 장부, 자동매수, BUY_READY는 변경하지 않는다.
# =============================================================================
_V565_LAST_CANDIDATE_SNAPSHOT: Dict[str, Any] = {}


def _v565_int(v: Any, default: int = 0) -> int:
    try:
        if v is None or v == '':
            return default
        return int(float(v))
    except Exception:
        return default


def _v565_latest_rows(ctrl: Optional[Dict[str, Any]] = None, max_rows: int = 800) -> List[Dict[str, Any]]:
    """paper_candidates_latest를 읽고 paper_bot 소비 기준 latest_scan_filter까지 적용한 active row snapshot."""
    try:
        ctrl = ctrl or load_control()
        limit = int(fnum(ctrl.get('candidate_read_max_lines'), default=max_rows))
        limit = max(100, min(max_rows, limit))
        rows = read_jsonl_tail(FILES.get('paper_latest', BASE_DIR / 'paper_candidates_latest.jsonl'), limit)
        rows = [dict(r) for r in rows if isinstance(r, dict)]
        try:
            return latest_scan_filter(rows, ctrl)
        except Exception as exc:
            log_error('v565_latest_scan_filter', exc)
            return rows
    except Exception as exc:
        log_error('v565_latest_rows', exc)
        return []


def _v565_fresh_count(rows: List[Dict[str, Any]], ctrl: Optional[Dict[str, Any]] = None) -> int:
    ctrl = ctrl or load_control()
    n = 0
    for r in rows:
        try:
            if candidate_is_fresh(r, ctrl):
                n += 1
        except Exception:
            continue
    return n


def _v565_stage_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    out: Dict[str, int] = {'S1': 0, 'S2': 0, 'S3': 0, 'X': 0}
    for r in rows:
        try:
            g = str(r.get('s_stage') or r.get('candidate_grade') or r.get('grade') or r.get('stage') or '').upper()
            if is_s1_candidate(r):
                g = 'S1'
            elif g not in {'S1', 'S2', 'S3'}:
                if g in {'X', 'EXCLUDED', '제외'}:
                    g = 'X'
                else:
                    continue
            out[g] = int(out.get(g, 0)) + 1
        except Exception:
            continue
    return out


def _v565_make_snapshot(rows: List[Dict[str, Any]], ctrl: Optional[Dict[str, Any]] = None, pick_stats: Optional[Dict[str, Any]] = None, open_pos: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, Any]:
    global _V565_LAST_CANDIDATE_SNAPSHOT
    ctrl = ctrl or load_control()
    pick_stats = pick_stats if isinstance(pick_stats, dict) else {}
    open_pos = open_pos if isinstance(open_pos, dict) else load_open()
    nowv = now_ts()
    latest_count = len(rows)
    fresh_count = _v565_fresh_count(rows, ctrl)
    stages = _v565_stage_counts(rows)
    snapshot = {
        'schema': 'paper_candidate_snapshot_v565',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'source': 'paper_bot.select_candidates.latest_scan_filter.paper_candidates_latest',
        'latest_count': latest_count,
        'paper_latest_count': latest_count,
        'active_latest_count': latest_count,
        'latest_lines': latest_count,
        'merged_fresh': fresh_count,
        'fresh_count': fresh_count,
        'fresh_source': 'v565_paper_candidate_snapshot_candidate_is_fresh_once',
        's1_seen': _v565_int(pick_stats.get('s1_seen'), stages.get('S1', 0)),
        'selected_s1': _v565_int(pick_stats.get('selected_s1'), 0),
        'paper_entry_hold': _v565_int(pick_stats.get('paper_entry_hold', pick_stats.get('paper_final_block')), 0),
        'paper_final_block': _v565_int(pick_stats.get('paper_final_block', pick_stats.get('paper_entry_hold')), 0),
        'micro_preopen_wait': _v565_int(pick_stats.get('micro_preopen_wait'), 0),
        'stale_skip': _v565_int(pick_stats.get('stale_skip'), 0),
        'not_s1_skip': _v565_int(pick_stats.get('not_s1_skip'), 0),
        'stage_counts': stages,
        'open_count': len(open_pos),
        'open_total': len(open_pos),
    }
    for k in ('last_s1_seen', 'last_open_try', 'last_paper_entry_hold', 'last_paper_final_block', 'last_skip'):
        if k in pick_stats:
            snapshot[k] = pick_stats.get(k)
    _V565_LAST_CANDIDATE_SNAPSHOT = dict(snapshot)
    return snapshot


def _v565_apply_snapshot_to_pick(pick_stats: Dict[str, Any], snapshot: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(pick_stats, dict):
        pick_stats = {}
    for k in (
        'latest_count', 'paper_latest_count', 'active_latest_count', 'latest_lines',
        'merged_fresh', 'fresh_count', 'fresh_source', 's1_seen', 'selected_s1',
        'paper_entry_hold', 'paper_final_block', 'micro_preopen_wait', 'stale_skip', 'not_s1_skip',
    ):
        pick_stats[k] = snapshot.get(k, pick_stats.get(k))
    pick_stats['paper_candidate_snapshot'] = snapshot
    pick_stats['snapshot_schema'] = snapshot.get('schema')
    return pick_stats


_v565_prev_select_candidates = select_candidates

def select_candidates(ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[List[Tuple[str, Dict[str, Any]]], Dict[str, Any], List[Dict[str, Any]]]:  # type: ignore[override]
    picked, pick_stats, latest_rows = _v565_prev_select_candidates(ctrl, open_pos)
    # latest_rows는 기존 select_candidates가 실제 소비 대상으로 삼은 filtered rows다. 이 순간 한 번만 fresh/latest를 봉인한다.
    snapshot = _v565_make_snapshot(latest_rows, ctrl, pick_stats, open_pos)
    pick_stats = _v565_apply_snapshot_to_pick(pick_stats, snapshot)
    return picked, pick_stats, latest_rows


def _v565_pick_from_snapshot_or_rows(pick_stats: Optional[Dict[str, Any]] = None, rows: Optional[List[Dict[str, Any]]] = None, ctrl: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    ctrl = ctrl or load_control()
    pick_stats = pick_stats if isinstance(pick_stats, dict) else {}
    snapshot = pick_stats.get('paper_candidate_snapshot') if isinstance(pick_stats.get('paper_candidate_snapshot'), dict) else None
    if not snapshot:
        if rows is None:
            rows = _v565_latest_rows(ctrl)
        snapshot = _v565_make_snapshot(rows, ctrl, pick_stats, load_open())
    else:
        rows = rows if rows is not None else _v565_latest_rows(ctrl)
    pick = dict(pick_stats)
    pick = _v565_apply_snapshot_to_pick(pick, snapshot)
    return snapshot, pick, rows or []




def _v560_refresh_trace_status(st: Dict[str, Any]) -> None:  # type: ignore[override]
    """cycle-end heartbeat도 v565 snapshot만 복사한다. 중간/마지막 write의 fresh 값이 달라지면 안 된다."""
    ctrl = load_control()
    pick_stats = st.get('pick_stats') if isinstance(st, dict) and isinstance(st.get('pick_stats'), dict) else {}
    snapshot, pick, rows = _v565_pick_from_snapshot_or_rows(pick_stats, ctrl=ctrl)
    open_pos = load_open()
    nowv = now_ts()
    try:
        trace_obj = build_trace(rows, ctrl, open_pos, set(), set())
    except Exception as exc:
        log_error('v565_build_trace', exc)
        trace_obj = _v560_minimal_trace(rows, ctrl, open_pos, f'{type(exc).__name__}: {exc}')
    trace_rows = trace_obj.get('rows') if isinstance(trace_obj.get('rows'), list) else []
    # trace에도 snapshot 메타를 붙여 소비처가 별도 계산하지 않게 한다.
    try:
        trace_obj['paper_candidate_snapshot'] = snapshot
        trace_obj['latest_count'] = snapshot.get('latest_count', 0)
        trace_obj['merged_fresh'] = snapshot.get('merged_fresh', 0)
        trace_obj['fresh_count'] = snapshot.get('fresh_count', 0)
        trace_obj['fresh_source'] = snapshot.get('fresh_source')
        save_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), trace_obj)
    except Exception as exc:
        log_error('v565_trace_snapshot_save', exc)
    handoff_obj = {
        'schema': 'paper_handoff_status_v565_candidate_snapshot',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', 0),
        'active_latest_count': snapshot.get('active_latest_count', 0),
        'latest_lines': snapshot.get('latest_lines', 0),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'stage_counts': snapshot.get('stage_counts', {}),
        'cache_spine': 'v565 paper_candidate_snapshot same-cycle heartbeat',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
    }
    save_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), handoff_obj)
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    if not isinstance(status, dict):
        status = {}
    status.update({
        'version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', 0),
        'active_latest_count': snapshot.get('active_latest_count', 0),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'cache_spine_version': 'v565',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
    })
    save_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), status)


def _v561_pick_spine(status: Dict[str, Any], handoff: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    """/pstatus는 status/handoff의 개별 fresh가 아니라 snapshot을 최우선으로 읽는다."""
    pick: Dict[str, Any] = {}
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        snap = src.get('paper_candidate_snapshot')
        if isinstance(snap, dict):
            pick.update(snap)
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        if isinstance(src.get('pick_stats'), dict):
            ps = src.get('pick_stats') or {}
            # last_* 같은 상세 추적은 pick_stats에서 보존하되 fresh/latest는 snapshot 값이 우선이다.
            for k, v in ps.items():
                if k in {'latest_count', 'paper_latest_count', 'merged_fresh', 'fresh_count'} and k in pick:
                    continue
                pick.setdefault(k, v)
    for src in (status, handoff):
        if not isinstance(src, dict):
            continue
        for dst, keys in {
            'latest_count': ('latest_count', 'paper_latest_count', 'active_latest_count'),
            'merged_fresh': ('merged_fresh', 'fresh_count'),
            's1_seen': ('s1_seen',),
            'selected_s1': ('selected_s1',),
            'paper_entry_hold': ('paper_entry_hold', 'paper_final_block'),
            'micro_preopen_wait': ('micro_preopen_wait',),
        }.items():
            if dst in pick and pick.get(dst) not in (None, ''):
                continue
            for k in keys:
                if k in src and src.get(k) not in (None, ''):
                    pick[dst] = src.get(k)
                    break
    return pick


# =============================================================================
# paper_bot v0.193 / v566: handoff writer 최종 단일화 + OPEN 당시 snapshot 봉인
# - handoff_status를 run_cycle 중간에 쓰지 않는다. cycle-end heartbeat에서 status/trace/handoff를 같은 snapshot으로 같이 쓴다.
# - latest/fresh/S1감지/S1선택/micro대기는 paper_candidate_snapshot 값만 쓴다.
# - OPEN 포지션에는 당시 snapshot과 S1->paper 지연/first->open 변화를 보존한다.
# - 조건/S등급/청산/장부 삭제/자동매수/BUY_READY 변경 없음.
# =============================================================================


def _v566_to_float(v: Any, default: float = 0.0) -> float:
    try:
        if v in (None, '', [], {}):
            return default
        return float(str(v).replace(',', '').replace('%', '').strip())
    except Exception:
        return default


def _v566_find_ts(ev: Dict[str, Any], *keys: str) -> float:
    try:
        srcs = _diag_sources(ev) if '_diag_sources' in globals() else [ev]
    except Exception:
        srcs = [ev]
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            ts = _v566_to_float(src.get(k), 0.0)
            if ts > 0:
                return ts
    return 0.0


def _v566_find_price(ev: Dict[str, Any], *keys: str) -> float:
    try:
        srcs = _diag_sources(ev) if '_diag_sources' in globals() else [ev]
    except Exception:
        srcs = [ev]
    for src in srcs:
        if not isinstance(src, dict):
            continue
        for k in keys:
            px = _v566_to_float(src.get(k), 0.0)
            if px > 0:
                return px
    return 0.0


def _v566_snapshot_for_cycle(pick_stats: Optional[Dict[str, Any]] = None, rows: Optional[List[Dict[str, Any]]] = None, ctrl: Optional[Dict[str, Any]] = None) -> Tuple[Dict[str, Any], Dict[str, Any], List[Dict[str, Any]]]:
    """v566 단일 snapshot. 기존 v565 helper를 쓰되 schema/build만 현재판으로 봉인한다."""
    snapshot, pick, out_rows = _v565_pick_from_snapshot_or_rows(pick_stats, rows=rows, ctrl=ctrl)
    snapshot = dict(snapshot or {})
    nowv = now_ts()
    snapshot.update({
        'schema': 'paper_candidate_snapshot_v566',
        'version': VERSION,
        'build': BUILD_LABEL,
        'snapshot_owner': 'paper_bot',
        'snapshot_rule': 'paper_bot reads paper_candidates once, then status/handoff/trace copy this snapshot only',
        'updated_at': snapshot.get('updated_at') or nowv,
        'updated_at_text': snapshot.get('updated_at_text') or iso_ts(nowv),
    })
    pick = _v565_apply_snapshot_to_pick(dict(pick or {}), snapshot)
    pick['paper_candidate_snapshot'] = snapshot
    pick['snapshot_schema'] = snapshot.get('schema')
    return snapshot, pick, out_rows or []


# run_cycle 내부 중간 write 차단: handoff는 cycle-end _v560_refresh_trace_status에서만 쓴다.
def write_handoff_status(latest_count: int, merged_fresh: int, pick_stats: Dict[str, Any]) -> None:  # type: ignore[override]
    try:
        snapshot, pick, _rows = _v566_snapshot_for_cycle(pick_stats)
        pick_stats.clear()
        pick_stats.update(pick)
        # 파일 쓰기 금지. 중간 handoff write가 /paper_handoff fresh 0 race를 만들었다.
        return None
    except Exception as exc:
        log_error('v566_write_handoff_status_noop', exc)
        return None


_v566_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v566_prev_open_position(pos_id, ev)
    try:
        opened_at = _v566_to_float(pos.get('opened_at'), now_ts())
        entry_px = _v566_to_float(pos.get('entry_price'), 0.0)
        s1_ts = _v566_find_ts(ev, 's1_seen_at', 's1_seen_ts', 's1_at', 'promoted_at', 'promoted_ts', 'paper_handoff_ts', 'handoff_ts')
        first_ts = _v566_find_ts(ev, 'first_seen_at', 'first_seen_ts', 'first_seen_time', 'detected_at', 'detected_ts')
        first_px = _v566_find_price(ev, 'first_seen_price', 'detected_price', 'watch_price', 'structure_seen_price', 's2_price', 'candidate_price')
        snapshot = dict(_V565_LAST_CANDIDATE_SNAPSHOT) if isinstance(globals().get('_V565_LAST_CANDIDATE_SNAPSHOT'), dict) else {}
        open_spine = {
            'schema': 'paper_open_spine_v566',
            'version': VERSION,
            'opened_at': opened_at,
            'opened_at_text': iso_ts(opened_at),
            'snapshot_schema': snapshot.get('schema'),
            'snapshot_latest': snapshot.get('latest_count'),
            'snapshot_fresh': snapshot.get('merged_fresh', snapshot.get('fresh_count')),
            'snapshot_source': snapshot.get('fresh_source'),
            's1_seen_at': s1_ts or None,
            's1_to_paper_delay_sec': round(opened_at - s1_ts, 3) if s1_ts > 0 else None,
            'first_seen_at': first_ts or None,
            'first_to_paper_delay_sec': round(opened_at - first_ts, 3) if first_ts > 0 else None,
            'first_seen_price': first_px or None,
            'entry_price': entry_px or None,
            'first_to_open_return_pct': round((entry_px - first_px) / first_px * 100.0, 4) if first_px > 0 and entry_px > 0 else None,
        }
        pos['paper_open_spine_v566'] = open_spine
        diag = pos.get('entry_diagnostics') if isinstance(pos.get('entry_diagnostics'), dict) else {}
        diag['paper_open_spine_v566'] = open_spine
        pos['entry_diagnostics'] = diag
    except Exception as exc:
        log_error('v566_open_spine', exc)
    return pos


def _v560_refresh_trace_status(st: Dict[str, Any]) -> None:  # type: ignore[override]
    """cycle-end 단일 writer. status/trace/handoff를 같은 snapshot으로 동시에 갱신한다."""
    ctrl = load_control()
    pick_stats = st.get('pick_stats') if isinstance(st, dict) and isinstance(st.get('pick_stats'), dict) else {}
    snapshot, pick, rows = _v566_snapshot_for_cycle(pick_stats, ctrl=ctrl)
    open_pos = load_open()
    nowv = now_ts()
    try:
        trace_obj = build_trace(rows, ctrl, open_pos, set(), set())
    except Exception as exc:
        log_error('v566_build_trace', exc)
        trace_obj = _v560_minimal_trace(rows, ctrl, open_pos, f'{type(exc).__name__}: {exc}')
    trace_rows = trace_obj.get('rows') if isinstance(trace_obj.get('rows'), list) else []
    trace_obj.update({
        'schema': trace_obj.get('schema') or 'paper_candidate_handoff_trace_v566',
        'version': VERSION,
        'trace_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'paper_candidate_snapshot': snapshot,
        'writer': 'v566_cycle_end_single_writer',
    })
    handoff_obj = {
        'schema': 'paper_handoff_status_v566_candidate_snapshot',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', snapshot.get('latest_count', 0)),
        'active_latest_count': snapshot.get('active_latest_count', snapshot.get('latest_count', 0)),
        'latest_lines': snapshot.get('latest_lines', snapshot.get('latest_count', 0)),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'stage_counts': snapshot.get('stage_counts', {}),
        'cache_spine': 'v566 cycle-end single writer: handoff/status/trace copy paper_candidate_snapshot',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
        'writer': 'v566_cycle_end_single_writer',
    }
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    if not isinstance(status, dict):
        status = {}
    status.update({
        'version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'running': True,
        'open_count': len(open_pos),
        'open_total': len(open_pos),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', snapshot.get('latest_count', 0)),
        'active_latest_count': snapshot.get('active_latest_count', snapshot.get('latest_count', 0)),
        'merged_fresh': snapshot.get('merged_fresh', 0),
        'fresh_count': snapshot.get('fresh_count', 0),
        'fresh_source': snapshot.get('fresh_source'),
        'trace_rows': len(trace_rows),
        'trace_version': VERSION,
        'cache_spine_version': 'v566',
        'cache_spine': 'v566 cycle-end single writer: handoff/status/trace copy paper_candidate_snapshot',
        'pick_stats': pick,
        'paper_candidate_snapshot': snapshot,
        'writer': 'v566_cycle_end_single_writer',
    })
    save_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), trace_obj)
    save_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), handoff_obj)
    save_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), status)

# =============================================================================
# paper_bot v0.194 / v567: main entrypoint 위치 수정 + OPEN/CLOSED 매매알림 trace 단일화
# - v566 블록이 __main__ 아래에 붙어 실제 서비스에서는 paper_bot_v0.192로 도는 문제를 제거한다.
# - OPEN/CLOSED 발생 시 장부/score와 별개로 알림 시도/성공/실패 trace를 반드시 남긴다.
# - 알림 플래그가 꺼졌거나 경로가 미도달해도 cycle 종료 후 without_alert_trace를 남기고, 가능하면 한 번 보낸다.
# - 조건/S등급/청산/장부 삭제/자동매수/BUY_READY 변경 없음.
# =============================================================================


def _v567_trade_alert_path(kind: str) -> Path:
    if str(kind).lower() == 'closed':
        return BASE_DIR / 'paper_bot_close_alert_trace.jsonl'
    return FILES.get('open_alert_trace', BASE_DIR / 'paper_bot_open_alert_trace.jsonl')


def _v567_trade_id(row: Dict[str, Any]) -> str:
    return str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or '')


def _v567_append_trade_alert_trace(kind: str, row: Dict[str, Any], phase: str, ok: bool = False, err: str = '', note: str = '') -> None:
    try:
        payload = {
            'schema': f'paper_{kind}_alert_trace_v567',
            'version': VERSION,
            'build': BUILD_LABEL,
            'kind': kind,
            'phase': phase,
            'ts': now_ts(),
            'ts_text': iso_ts(),
            'ticker': normalize_ticker(row.get('ticker')),
            'pos_id': row.get('pos_id') or row.get('event_id') or row.get('entry_id'),
            'event_id': row.get('event_id') or row.get('pos_id') or row.get('entry_id'),
            'opened_at': row.get('opened_at'),
            'opened_at_text': row.get('opened_at_text'),
            'closed_at': row.get('closed_at'),
            'closed_at_text': row.get('closed_at_text'),
            'entry_price': row.get('entry_price'),
            'exit_price': row.get('exit_price'),
            'pnl_pct': row.get('pnl_pct'),
            'strategy': row.get('strategy_label') or row.get('strategy_key') or row.get('strategy'),
            'candidate_grade': row.get('candidate_grade'),
            'exit_reason': row.get('exit_reason') or row.get('exit_rule'),
            'sent_ok': bool(ok),
            'error': str(err or ''),
            'note': str(note or ''),
        }
        append_jsonl(_v567_trade_alert_path(kind), payload)
    except Exception as exc:
        log_error(f'v567_{kind}_alert_trace_append', exc)


def _v567_recent_trade_alert_exists(kind: str, row: Dict[str, Any], since_ts: float, phases: Optional[set] = None) -> bool:
    try:
        tid = _v567_trade_id(row)
        ticker = normalize_ticker(row.get('ticker'))
        opened_at = fnum(row.get('opened_at'), default=0.0)
        closed_at = fnum(row.get('closed_at'), default=0.0)
        for r in read_jsonl_tail(_v567_trade_alert_path(kind), 240):
            if not isinstance(r, dict):
                continue
            rts = fnum(r.get('ts'), default=0.0)
            if rts and rts < since_ts - 10:
                continue
            if phases and str(r.get('phase') or '') not in phases:
                continue
            rtid = str(r.get('pos_id') or r.get('event_id') or r.get('entry_id') or '')
            rticker = normalize_ticker(r.get('ticker'))
            if tid and rtid == tid:
                return True
            if ticker and rticker == ticker:
                ropen = fnum(r.get('opened_at'), default=0.0)
                rclose = fnum(r.get('closed_at'), default=0.0)
                if opened_at and ropen and abs(ropen - opened_at) <= 5:
                    return True
                if closed_at and rclose and abs(rclose - closed_at) <= 5:
                    return True
    except Exception as exc:
        log_error(f'v567_recent_{kind}_alert_exists', exc)
    return False


def _v567_closed_message_text(row: Dict[str, Any]) -> str:
    t = normalize_ticker(row.get('ticker'))
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    extra = "\n".join(format_entry_diag_lines(diag)) if diag else "- 진입근거: strategy 상세값 미전달"
    timing_line = format_entry_timing_line(row.get('entry_timing_trace') or (diag.get('entry_timing_trace') if isinstance(diag, dict) else {})) if bool(load_control().get('notify_entry_timing_trace', True)) else ''
    if timing_line:
        extra = extra + "\n" + timing_line
    return (
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )


def notify_opened(pos: Dict[str, Any]) -> None:  # type: ignore[override]
    _v567_append_trade_alert_trace('open', pos, 'attempt_start', False, '', 'OPEN created; alert send started')
    try:
        text = _v561_open_message_text(pos)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('open', pos, 'message_build_error', False, err, 'OPEN alert text build failed')
        log_error('v567_notify_opened_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('open', pos, phase, ok, err, 'OPEN alert send result')
    if not ok:
        log_error('v567_notify_opened_send_result', Exception(err or 'send_message returned false'))


def notify_closed(row: Dict[str, Any]) -> None:  # type: ignore[override]
    _v567_append_trade_alert_trace('closed', row, 'attempt_start', False, '', 'CLOSED created; alert send started')
    try:
        text = _v567_closed_message_text(row)
    except Exception as exc:
        err = f'{type(exc).__name__}: {exc}'
        _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, err, 'CLOSED alert text build failed')
        log_error('v567_notify_closed_text_build', exc)
        return
    ok, err = _v561_send_message_with_result(text)
    phase = 'send_ok' if ok else 'send_error'
    _v567_append_trade_alert_trace('closed', row, phase, ok, err, 'CLOSED alert send result')
    if not ok:
        log_error('v567_notify_closed_send_result', Exception(err or 'send_message returned false'))


def _v567_read_closed_tail_count() -> int:
    try:
        return line_count_cached(FILES['closed'], ttl=0)
    except Exception:
        return 0


def _v567_recent_closed_rows(before_count: int, max_rows: int = 20) -> List[Dict[str, Any]]:
    try:
        after_count = _v567_read_closed_tail_count()
        n = max(0, min(max_rows, after_count - int(before_count or 0)))
        if n <= 0:
            return []
        rows = read_jsonl_tail(FILES['closed'], max(n, 1))
        return [r for r in rows if isinstance(r, dict)][-n:]
    except Exception as exc:
        log_error('v567_recent_closed_rows', exc)
        return []





def _v567_latest_trade_alert(kind: str) -> Dict[str, Any]:
    try:
        rows = read_jsonl_tail(_v567_trade_alert_path(kind), 80)
        for r in reversed(rows):
            if isinstance(r, dict):
                return r
    except Exception as exc:
        log_error(f'v567_latest_{kind}_alert', exc)
    return {}


def _v567_trade_alert_line(kind: str, label: str) -> str:
    r = _v567_latest_trade_alert(kind)
    if not r:
        return f'- 마지막 {label}알림: -'
    age = max(0.0, now_ts() - fnum(r.get('ts'), default=now_ts()))
    phase = str(r.get('phase') or '-')
    ok = r.get('sent_ok')
    err = str(r.get('error') or '').strip()
    state = '✅ sent_ok' if bool(ok) else f'⚠️ {phase}'
    tail = f" / err {err[:60]}" if err else ''
    return f"- 마지막 {label}알림: {r.get('ticker') or '-'} / {state} / age {age:.1f}s{tail}"





# =============================================================================
# paper_bot v0.195 / v568: light_runner OPEN/CLOSED 매매알림 강제 연결
# - OPEN/CLOSED 장부가 생겼는데 notify_on_strict_* 설정 또는 경로 문제로 알림이 빠지는 것을 막는다.
# - light_runner cycle 종료 후 새 OPEN/CLOSED를 확인하고, send 결과 trace가 없으면 반드시 notify_opened/notify_closed를 호출한다.
# - 알림 실패도 send_error/message_build_error로 남긴다. 조건/S등급/청산/장부/자동매수/BUY_READY 변경 없음.
# =============================================================================


def _v568_event_match(kind: str, row: Dict[str, Any], trace: Dict[str, Any]) -> bool:
    try:
        tid = str(row.get('pos_id') or row.get('event_id') or row.get('entry_id') or '')
        rtid = str(trace.get('pos_id') or trace.get('event_id') or trace.get('entry_id') or '')
        if tid and rtid and tid == rtid:
            return True
        ticker = normalize_ticker(row.get('ticker'))
        rticker = normalize_ticker(trace.get('ticker'))
        if not ticker or not rticker or ticker != rticker:
            return False
        opened_at = fnum(row.get('opened_at'), default=0.0)
        ropened_at = fnum(trace.get('opened_at'), default=0.0)
        if opened_at and ropened_at and abs(opened_at - ropened_at) <= 5:
            return True
        if str(kind).lower() == 'closed':
            closed_at = fnum(row.get('closed_at'), default=0.0)
            rclosed_at = fnum(trace.get('closed_at'), default=0.0)
            if closed_at and rclosed_at and abs(closed_at - rclosed_at) <= 5:
                return True
    except Exception:
        return False
    return False


def _v568_has_send_result(kind: str, row: Dict[str, Any], since_ts: float) -> bool:
    """True면 이미 성공/실패/본문생성실패 중 하나가 남아 있어 추가 발송하지 않는다."""
    try:
        phases = {'send_ok', 'send_error', 'message_build_error'}
        for r in read_jsonl_tail(_v567_trade_alert_path(kind), 320):
            if not isinstance(r, dict):
                continue
            rts = fnum(r.get('ts'), default=0.0)
            if rts and rts < since_ts - 20:
                continue
            if str(r.get('phase') or '') not in phases:
                continue
            if _v568_event_match(kind, row, r):
                return True
    except Exception as exc:
        log_error(f'v568_has_{kind}_send_result', exc)
    return False


def _v568_closed_rows_since(before_count: int, max_rows: int = 50) -> List[Dict[str, Any]]:
    try:
        after_count = line_count_cached(FILES['closed'], ttl=0)
        n = max(0, min(max_rows, int(after_count) - int(before_count or 0)))
        if n <= 0:
            return []
        rows = read_jsonl_tail(FILES['closed'], max(n, 1))
        return [r for r in rows if isinstance(r, dict)][-n:]
    except Exception as exc:
        log_error('v568_closed_rows_since', exc)
        return []










# =============================================================================
# paper_bot v0.196 / v569: 후반 손실군 복기 cache 생산
# - CLOSED/trade_log/score cache 주인은 paper_bot이다.
# - 조건/S1/S2/S3/청산/장부는 변경하지 않는다.
# - 최근 성과 급락을 진입 당시 snapshot/위험태그/청산사유 기준으로 비교할 cache만 만든다.
# =============================================================================


def _v569_stat(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    try:
        return _score_stat(rows)
    except Exception:
        n=len(rows); wins=sum(1 for r in rows if fnum(r.get('pnl_pct'), default=0.0)>0); total=sum(fnum(r.get('pnl_pct'), default=0.0) for r in rows)
        return {'n':n,'wins':wins,'losses':max(0,n-wins),'win_rate':(wins/n*100 if n else 0.0),'total':total,'avg':(total/n if n else 0.0)}


def _v569_stat_line(rows: List[Dict[str, Any]]) -> str:
    st=_v569_stat(rows); n=int(st.get('n',0) or 0); w=int(st.get('wins',0) or 0); l=int(st.get('losses', max(0,n-w)) or 0)
    return f"{n}전 {w}승 {l}패 / 승률 {fnum(st.get('win_rate'), default=0.0):.1f}% / 합산 {fnum(st.get('total'), default=0.0):+.2f}% / 평균 {fnum(st.get('avg'), default=0.0):+.2f}%"


def _v569_nested_sources(row: Dict[str, Any]) -> List[Dict[str, Any]]:
    out=[row]
    for k in ('paper_open_spine_v566','paper_open_spine','entry_context','entry_snapshot','candidate_snapshot','source','raw','diagnostics','open_context'):
        v=row.get(k)
        if isinstance(v, dict): out.append(v)
    return out


def _v569_get(row: Dict[str, Any], keys: Iterable[str], default: Any = None) -> Any:
    for src in _v569_nested_sources(row):
        for k in keys:
            if k in src and src.get(k) not in (None, '', [], {}):
                return src.get(k)
    return default


def _v569_num(row: Dict[str, Any], keys: Iterable[str], default: float = 0.0) -> float:
    return fnum(_v569_get(row, keys, default), default=default)


def _v569_text_blob(row: Dict[str, Any]) -> str:
    vals=[]
    for src in _v569_nested_sources(row):
        for k,v in src.items():
            if k in {'raw','source','entry_context','candidate_snapshot','diagnostics'}: continue
            if isinstance(v, (str,int,float,bool)):
                vals.append(f"{k}:{v}")
            elif isinstance(v, list):
                vals.append(f"{k}:{','.join(str(x) for x in v[:8])}")
    return ' | '.join(vals)


def _v569_loss_issue_counter(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c: Counter = Counter()
    for r in rows:
        blob=_v569_text_blob(r)
        low=blob.lower()
        exit_reason=str(_v569_get(r, ('exit_reason','exit_rule','close_reason'), '-') or '-')
        c[f"청산:{exit_reason}"] += 1
        tag=str(_v569_get(r, ('close_review_tag','review_tag','result_tag'), '') or '')
        if tag and tag != '-': c[f"복기:{tag}"] += 1
        spread=_v569_num(r, ('spread_pct','entry_spread_pct','spread','best_spread_pct'), 0.0)
        slip=_v569_num(r, ('slippage_pct','expected_slippage_pct','entry_slippage_pct','slip_pct'), 0.0)
        reaction=_v569_num(r, ('price_reaction_pct','reaction_pct','entry_price_reaction_pct','reaction'), 999.0)
        buy=_v569_num(r, ('buy_ratio','buy_trade_ratio','entry_buy_ratio','buy_strength'), 999.0)
        persist=_v569_num(r, ('buy_persist_1m','one_min_buy_persist','entry_buy_persist_1m','persist_1m'), 999.0)
        first_ret=_v569_num(r, ('first_to_open_return_pct','first_to_paper_return_pct','first_to_now_return','first_to_now_return_pct'), 0.0)
        s1_delay=_v569_num(r, ('s1_to_paper_delay_sec','s1_to_open_delay_sec'), 0.0)
        fresh=_v569_num(r, ('snapshot_fresh','fresh_count','candidate_fresh_count'), -1.0)
        latest=_v569_num(r, ('snapshot_latest','latest_count','candidate_latest_count'), -1.0)
        if spread >= 0.30 or '스프레드부담' in blob or '스프레드 과다' in blob: c['진입부담:스프레드'] += 1
        if slip >= 0.25 or '미끄러짐부담' in blob: c['진입부담:미끄러짐'] += 1
        if reaction != 999.0 and reaction < 0.35: c['확인신호:가격반응 약함'] += 1
        if buy != 999.0 and buy < 0.70: c['확인신호:매수체결 약함'] += 1
        if persist != 999.0 and persist < 0.75: c['확인신호:1분지속 부족'] += 1
        if first_ret >= 1.0 or '늦은추격' in blob or 'late_chase' in low: c['타이밍:늦은추격 의심'] += 1
        if s1_delay >= 10.0: c['타이밍:S1→OPEN 지연'] += 1
        if latest > 0 and fresh <= 0: c['배관:OPEN 당시 fresh 0'] += 1
        if 'freshness' in low or '신선' in blob: c['배관:신선도 관련'] += 1
    return dict(c)


def _v569_top(counter: Dict[str, int], limit: int = 6) -> str:
    items=sorted(counter.items(), key=lambda kv:(-kv[1], kv[0]))[:limit]
    return ' / '.join(f"{k} {v}" for k,v in items) if items else '-'


def _v569_pick_primary_strategy(today_rows: List[Dict[str, Any]]) -> str:
    c: Counter = Counter(_strategy_key(r) for r in today_rows)
    if c.get('주도흐름 유동보유',0) > 0:
        return '주도흐름 유동보유'
    return c.most_common(1)[0][0] if c else '-'


def write_trade_review_cache_v569(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 500) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        for r in primary_rows:
            by_version.setdefault(_main_version_key(r), []).append(r)
        version_lines=[]
        for vk, arr in sorted(by_version.items(), key=lambda kv: str(kv[0]), reverse=True)[:5]:
            version_lines.append(f"- {vk}: {_v569_stat_line(arr)}")
        issue = _v569_loss_issue_counter(late_losses or last16_losses)
        last_issue = _v569_loss_issue_counter(last16_losses)
        summary_lines = [
            '📉 후반 손실군 복기 /trade_review · v569 cache-only',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[초반 vs 후반]',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근 16전: {_v569_stat_line(last16)}" if last16 else '- 최근 16전: 표본부족',
            '',
            '[후반 손실군 공통 원인 TOP]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(issue)}",
            f"- 최근16 손실 {len(last16_losses)}개: {_v569_top(last_issue)}",
            '',
            '[오늘 버전별 · 주분석 전략]',
            *(version_lines or ['- 표본부족']),
            '',
            '[판독]',
            '- 후반 손실군이 초반 승리군과 다르면 조건 변경 전 진입타이밍/정보지연/스프레드/미끄러짐을 먼저 분리한다.',
            '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v569',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'late_loss_count': len(late_losses),
            'last16_loss_count': len(last16_losses),
            'late_loss_issue_top': issue,
            'last16_loss_issue_top': last_issue,
            'primary_version_stats': {vk: _v569_stat(arr) for vk, arr in by_version.items()},
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v569', exc)









# =============================================================================
# paper_bot v0.197 / v570: 신선도×늦은추격 세분화 복기
# - v569에서 후반 손실군 공통 원인을 찾았고, v570은 그중 "신선도 관련"을 숫자/문구/타이밍/실행위험으로 분리한다.
# - 조건/S1/S2/S3/청산/장부/자동매수/BUY_READY 변경 없음.
# - paper_bot은 CLOSED/trade_log/score/review cache 주인이다. 메인봇은 이 cache만 읽는다.
# =============================================================================


def _v570_boolish(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    return s in {'1','true','yes','y','ok','on','맞음','있음'}


def _v570_max_num(row: Dict[str, Any], keys: Iterable[str], default: float = -1.0) -> float:
    vals: List[float] = []
    for src in _v569_nested_sources(row):
        if not isinstance(src, dict):
            continue
        for k in keys:
            if k in src and src.get(k) not in (None, '', [], {}):
                vals.append(fnum(src.get(k), default=default))
    vals = [x for x in vals if x != default]
    return max(vals) if vals else default


def _v570_any_text(row: Dict[str, Any], words: Iterable[str]) -> bool:
    blob = _v569_text_blob(row)
    low = blob.lower()
    return any((w.lower() in low) for w in words)


def _v570_case(row: Dict[str, Any]) -> Dict[str, Any]:
    """후반 손실 원인을 바로 차단조건으로 쓰지 않고, 복기용 분류만 만든다."""
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    latest = _v569_num(row, ('snapshot_latest','latest_count','candidate_latest_count','active_latest_count'), -1.0)
    fresh = _v569_num(row, ('snapshot_fresh','fresh_count','candidate_fresh_count','merged_fresh'), -1.0)
    # 개별 정보 나이. 없으면 -1로 두고, 문구만 있는 신선도와 분리한다.
    fresh_age = _v570_max_num(row, (
        'freshness_age_sec','candidate_age_sec','candidate_fresh_age_sec','row_age_sec',
        'price_age_sec','ticker_age_sec','orderflow_age_sec','micro_age_sec','ws_age_sec',
        'snapshot_age_sec','paper_candidate_age_sec'
    ), -1.0)
    price_age = _v570_max_num(row, ('price_age_sec','ticker_age_sec','ws_price_age_sec'), -1.0)
    order_age = _v570_max_num(row, ('orderflow_age_sec','trade_age_sec','buy_ratio_age_sec','one_min_age_sec'), -1.0)
    micro_age = _v570_max_num(row, ('micro_age_sec','orderbook_age_sec','slippage_age_sec','spread_age_sec'), -1.0)
    spread = _v569_num(row, ('spread_pct','entry_spread_pct','spread','best_spread_pct'), 0.0)
    slip = _v569_num(row, ('slippage_pct','expected_slippage_pct','entry_slippage_pct','slip_pct'), 0.0)
    first_ret = _v569_num(row, ('first_to_open_return_pct','first_to_paper_return_pct','first_to_now_return','first_to_now_return_pct'), 0.0)
    s1_delay = _v569_num(row, ('s1_to_paper_delay_sec','s1_to_open_delay_sec'), 0.0)
    first_delay = _v569_num(row, ('first_to_paper_delay_sec','first_to_open_delay_sec'), 0.0)
    reaction = _v569_num(row, ('price_reaction_pct','reaction_pct','entry_price_reaction_pct','reaction'), 999.0)
    buy = _v569_num(row, ('buy_ratio','buy_trade_ratio','entry_buy_ratio','buy_strength'), 999.0)
    persist = _v569_num(row, ('buy_persist_1m','one_min_buy_persist','entry_buy_persist_1m','persist_1m'), 999.0)
    late_flag = _v570_any_text(row, ('늦은추격', 'late_chase', 'late chase')) or first_ret >= 1.0
    fresh_word = _v570_any_text(row, ('freshness', '신선', 'fresh_delay', 'freshness_delay'))
    spread_bad = spread >= 0.30 or _v570_any_text(row, ('스프레드부담','스프레드 과다'))
    slip_bad = slip >= 0.25 or _v570_any_text(row, ('미끄러짐부담',))
    numeric_fresh_bad = (latest > 0 and fresh <= 0) or fresh_age >= 10.0 or price_age >= 10.0 or order_age >= 10.0 or micro_age >= 10.0
    info_late = numeric_fresh_bad
    # 신선도 문구만 있고 숫자 근거가 없으면 바로 차단 근거가 아니라 "추가확인"으로 둔다.
    fresh_text_only = fresh_word and not numeric_fresh_bad
    chase_after_wait = late_flag and (s1_delay >= 5.0 or first_delay >= 60.0 or spread_bad or slip_bad)
    weak_confirm = (reaction != 999.0 and reaction < 0.35) or (buy != 999.0 and buy < 0.70) or (persist != 999.0 and persist < 0.75)
    cats: List[str] = []
    if latest > 0 and fresh <= 0: cats.append('신선도:OPEN당시 fresh0')
    if fresh_age >= 10.0 or price_age >= 10.0 or order_age >= 10.0 or micro_age >= 10.0: cats.append('신선도:핵심정보나이과다')
    if fresh_text_only: cats.append('신선도:문구만있음_숫자확인필요')
    if late_flag: cats.append('타이밍:늦은추격')
    if chase_after_wait: cats.append('타이밍:대기후추격')
    if spread_bad: cats.append('실행위험:스프레드')
    if slip_bad: cats.append('실행위험:미끄러짐')
    if weak_confirm: cats.append('확인신호:체결반응약함')
    # 복기용 권고. 실제 조건 변경은 별도 승인 후.
    if info_late and late_flag:
        action = 'S1제외후보:신선도지연+늦은추격'
    elif info_late and (spread_bad or slip_bad):
        action = 'S2보류후보:신선도지연+실행위험'
    elif late_flag and (spread_bad or slip_bad):
        action = 'S2보류후보:늦은추격+실행위험'
    elif fresh_text_only:
        action = '추가확인:신선도문구_숫자근거부족'
    else:
        action = '조건외원인확인필요'
    return {
        'ticker': row.get('ticker') or row.get('symbol') or '-',
        'pnl_pct': pnl,
        'exit_reason': _v569_get(row, ('exit_reason','exit_rule','close_reason'), '-'),
        'latest': latest,
        'fresh': fresh,
        'fresh_age_sec': fresh_age,
        'price_age_sec': price_age,
        'orderflow_age_sec': order_age,
        'micro_age_sec': micro_age,
        'first_to_open_return_pct': first_ret,
        's1_to_paper_delay_sec': s1_delay,
        'first_to_paper_delay_sec': first_delay,
        'spread_pct': spread,
        'slippage_pct': slip,
        'late_chase_flag': bool(late_flag),
        'numeric_fresh_bad': bool(numeric_fresh_bad),
        'fresh_text_only': bool(fresh_text_only),
        'spread_bad': bool(spread_bad),
        'slip_bad': bool(slip_bad),
        'weak_confirm': bool(weak_confirm),
        'categories': cats or ['분류없음'],
        'review_action': action,
    }


def _v570_counter(cases: List[Dict[str, Any]], key: str = 'categories') -> Dict[str, int]:
    c: Counter = Counter()
    for case in cases:
        vals = case.get(key)
        if isinstance(vals, list):
            for x in vals:
                c[str(x)] += 1
        elif vals:
            c[str(vals)] += 1
    return dict(c)


def _v570_action_counter(cases: List[Dict[str, Any]]) -> Dict[str, int]:
    c: Counter = Counter()
    for case in cases:
        c[str(case.get('review_action') or '-')] += 1
    return dict(c)


def _v570_filter_safe(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """가상 참고용. 조건을 바꾸는 것이 아니라, 문제 조합 제외 시 성과가 어땠는지 복기만 한다."""
    out: List[Dict[str, Any]] = []
    for r in rows:
        c = _v570_case(r)
        # 숫자 신선도 지연+늦은추격은 가장 강한 의심군.
        if c.get('numeric_fresh_bad') and c.get('late_chase_flag'):
            continue
        # 늦은추격+스프레드/미끄러짐은 S2보류 의심군.
        if c.get('late_chase_flag') and (c.get('spread_bad') or c.get('slip_bad')):
            continue
        out.append(r)
    return out


def _v570_case_line(case: Dict[str, Any]) -> str:
    t = str(case.get('ticker') or '-')
    pnl = fnum(case.get('pnl_pct'), default=0.0)
    ret = fnum(case.get('first_to_open_return_pct'), default=0.0)
    s1d = fnum(case.get('s1_to_paper_delay_sec'), default=0.0)
    sp = fnum(case.get('spread_pct'), default=0.0)
    fr = case.get('fresh')
    cats = ','.join(str(x) for x in (case.get('categories') or [])[:3])
    return f"- {t}: {pnl:+.2f}% / first→open {ret:+.2f}% / S1→OPEN {s1d:.1f}s / fresh {fr} / 스프 {sp:.2f}% / {case.get('review_action')} / {cats}"


def write_trade_review_cache_v570(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 700) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        late_cases = [_v570_case(r) for r in late_losses]
        last_cases = [_v570_case(r) for r in last16_losses]
        safe_all = _v570_filter_safe(primary_rows)
        safe_late = _v570_filter_safe(late)
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        for r in primary_rows:
            by_version.setdefault(_main_version_key(r), []).append(r)
        version_lines=[]
        for vk, arr in sorted(by_version.items(), key=lambda kv: str(kv[0]), reverse=True)[:5]:
            version_lines.append(f"- {vk}: {_v569_stat_line(arr)}")
        summary_lines = [
            '📉 후반 손실군 복기 /trade_review · v570 신선도×늦은추격 세분화',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[초반 vs 후반]',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근 16전: {_v569_stat_line(last16)}" if last16 else '- 최근 16전: 표본부족',
            '',
            '[후반 손실군 원인 세분화]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(_v570_counter(late_cases), 8)}",
            f"- 최근16 손실 {len(last16_losses)}개: {_v569_top(_v570_counter(last_cases), 8)}",
            f"- 복기판정: {_v569_top(_v570_action_counter(late_cases), 6)}",
            '',
            '[가상 제외 참고 · 조건 변경 아님]',
            f"- 전체 주분석 전략 원본: {_v569_stat_line(primary_rows)}" if primary_rows else '- 원본: 표본부족',
            f"- 숫자 신선도지연+늦은추격/실행위험 의심 제외 시: {_v569_stat_line(safe_all)}" if primary_rows else '- 제외 참고: 표본부족',
            f"- 후반만 같은 기준 제외 시: {_v569_stat_line(safe_late)}" if late else '- 후반 제외 참고: 표본부족',
            '',
            '[후반 손실 샘플]',
            *(_v570_case_line(c) for c in late_cases[:5]),
            '',
            '[오늘 버전별 · 주분석 전략]',
            *(version_lines or ['- 표본부족']),
            '',
            '[판독]',
            '- 신선도 관련을 바로 차단하지 않고, 숫자 지연 / 문구만 있음 / 늦은추격 / 스프레드·미끄러짐 회복대기로 나눠 본다.',
            '- 숫자 신선도지연+늦은추격 조합이 반복 손실이면 S1 제외 또는 S2 보류 후보로 설계 검토한다.',
            '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v570_fresh_late_split',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'safe_all_stat_reference_only': _v569_stat(safe_all),
            'safe_late_stat_reference_only': _v569_stat(safe_late),
            'late_loss_count': len(late_losses),
            'last16_loss_count': len(last16_losses),
            'late_loss_split_top': _v570_counter(late_cases),
            'last16_loss_split_top': _v570_counter(last_cases),
            'late_review_action_top': _v570_action_counter(late_cases),
            'late_loss_cases_sample': late_cases[:20],
            'primary_version_stats': {vk: _v569_stat(arr) for vk, arr in by_version.items()},
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v570', exc)









# =============================================================================

# [v582 cleanup] removed stale duplicate writer block.

# paper_bot v0.199 / v572: 좋았던 구간 vs 나빠진 구간 복기 비교
# - 조건/S1/S2/S3/청산/장부/자동매수/BUY_READY 변경 없음.
# - paper_bot은 CLOSED/trade_log/review cache 주인이다.
# - 목적: v2.13.461 승리구간과 v2.13.462~463 손실구간의 진입 당시 fresh/late/실행위험 차이를 숫자로 비교한다.
# =============================================================================


def _v572_version_rows(rows: List[Dict[str, Any]], versions: Iterable[str]) -> List[Dict[str, Any]]:
    wanted = set(str(v) for v in versions)
    out: List[Dict[str, Any]] = []
    for r in rows:
        if _main_version_key(r) in wanted:
            out.append(r)
    return out


def _v572_case_flags(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    cases = [_v570_case(r) for r in rows]
    n = len(cases)
    losses = [c for c in cases if fnum(c.get('pnl_pct'), default=0.0) <= 0]
    def cnt(pred):
        return sum(1 for c in cases if pred(c))
    def losscnt(pred):
        return sum(1 for c in losses if pred(c))
    return {
        'n': n,
        'loss_n': len(losses),
        'late_chase': cnt(lambda c: bool(c.get('late_chase_flag'))),
        'numeric_fresh_bad': cnt(lambda c: bool(c.get('numeric_fresh_bad'))),
        'fresh_text_only': cnt(lambda c: bool(c.get('fresh_text_only'))),
        'spread_bad': cnt(lambda c: bool(c.get('spread_bad'))),
        'slip_bad': cnt(lambda c: bool(c.get('slip_bad'))),
        'weak_confirm': cnt(lambda c: bool(c.get('weak_confirm'))),
        'late_loss': losscnt(lambda c: bool(c.get('late_chase_flag'))),
        'fresh_bad_loss': losscnt(lambda c: bool(c.get('numeric_fresh_bad'))),
        'fresh_text_loss': losscnt(lambda c: bool(c.get('fresh_text_only'))),
        'spread_loss': losscnt(lambda c: bool(c.get('spread_bad'))),
        'slip_loss': losscnt(lambda c: bool(c.get('slip_bad'))),
        'weak_confirm_loss': losscnt(lambda c: bool(c.get('weak_confirm'))),
        'action_top': _v570_action_counter(cases),
        'category_top': _v570_counter(cases),
        'loss_category_top': _v570_counter(losses),
    }


def _v572_rate_line(flags: Dict[str, Any]) -> str:
    n = int(flags.get('n') or 0)
    if n <= 0:
        return '표본부족'
    def pct(k):
        return f"{int(flags.get(k) or 0)}/{n}({(float(flags.get(k) or 0)/n*100.0):.0f}%)"
    return ' / '.join([
        f"늦은추격 {pct('late_chase')}",
        f"숫자신선도지연 {pct('numeric_fresh_bad')}",
        f"문구만신선도 {pct('fresh_text_only')}",
        f"스프레드 {pct('spread_bad')}",
        f"미끄러짐 {pct('slip_bad')}",
        f"확인약함 {pct('weak_confirm')}",
    ])


def _v572_delta_lines(good_flags: Dict[str, Any], bad_flags: Dict[str, Any]) -> List[str]:
    keys = [
        ('late_chase', '늦은추격'),
        ('numeric_fresh_bad', '숫자신선도지연'),
        ('fresh_text_only', '문구만신선도'),
        ('spread_bad', '스프레드위험'),
        ('slip_bad', '미끄러짐위험'),
        ('weak_confirm', '확인신호약함'),
    ]
    gn = max(1, int(good_flags.get('n') or 0))
    bn = max(1, int(bad_flags.get('n') or 0))
    scored=[]
    for k,name in keys:
        gr=float(good_flags.get(k) or 0)/gn
        br=float(bad_flags.get(k) or 0)/bn
        scored.append((br-gr,name,gr,br))
    scored.sort(reverse=True, key=lambda x:x[0])
    out=[]
    for diff,name,gr,br in scored[:4]:
        out.append(f"- {name}: 좋았던구간 {gr*100:.0f}% → 나빠진구간 {br*100:.0f}% / 차이 {diff*100:+.0f}%p")
    return out or ['- 표본부족']


def write_trade_review_cache_v572(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 900) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        # 현재 복기상 가장 깨끗했던 구간과 급락 구간을 명시 비교한다.
        good_rows = _v572_version_rows(primary_rows, ('v2.13.461',))
        bad_rows = _v572_version_rows(primary_rows, ('v2.13.462','v2.13.463'))
        if not good_rows:
            # fallback: 앞 절반
            half = len(primary_rows)//2
            good_rows = primary_rows[:half]
        if not bad_rows:
            half = len(primary_rows)//2
            bad_rows = primary_rows[half:]
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        late_cases = [_v570_case(r) for r in late_losses]
        last_cases = [_v570_case(r) for r in last16_losses]
        safe_all = _v570_filter_safe(primary_rows)
        safe_late = _v570_filter_safe(late)
        good_flags = _v572_case_flags(good_rows)
        bad_flags = _v572_case_flags(bad_rows)
        by_version: Dict[str, List[Dict[str, Any]]] = {}
        for r in primary_rows:
            by_version.setdefault(_main_version_key(r), []).append(r)
        version_lines=[]
        for vk, arr in sorted(by_version.items(), key=lambda kv: str(kv[0]), reverse=True)[:6]:
            version_lines.append(f"- {vk}: {_v569_stat_line(arr)}")
        summary_lines = [
            '📉 후반 손실군 복기 /trade_review · v572 구간비교+신선도 보강판',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[초반 vs 후반]',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근 16전: {_v569_stat_line(last16)}" if last16 else '- 최근 16전: 표본부족',
            '',
            '[좋았던 구간 vs 나빠진 구간]',
            f"- 좋았던 구간(v2.13.461 중심): {_v569_stat_line(good_rows)}",
            f"- 나빠진 구간(v2.13.462~463 중심): {_v569_stat_line(bad_rows)}",
            f"- 좋았던 구간 위험률: {_v572_rate_line(good_flags)}",
            f"- 나빠진 구간 위험률: {_v572_rate_line(bad_flags)}",
            '[차이 TOP]',
            *_v572_delta_lines(good_flags, bad_flags),
            '',
            '[후반 손실군 원인 세분화]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(_v570_counter(late_cases), 8)}",
            f"- 최근16 손실 {len(last16_losses)}개: {_v569_top(_v570_counter(last_cases), 8)}",
            f"- 복기판정: {_v569_top(_v570_action_counter(late_cases), 6)}",
            '',
            '[가상 제외 참고 · 조건 변경 아님]',
            f"- 전체 주분석 전략 원본: {_v569_stat_line(primary_rows)}" if primary_rows else '- 원본: 표본부족',
            f"- 숫자 신선도지연+늦은추격/실행위험 의심 제외 시: {_v569_stat_line(safe_all)}" if primary_rows else '- 제외 참고: 표본부족',
            f"- 후반만 같은 기준 제외 시: {_v569_stat_line(safe_late)}" if late else '- 후반 제외 참고: 표본부족',
            '',
            '[후반 손실 샘플]',
            *(_v570_case_line(c) for c in late_cases[:5]),
            '',
            '[오늘 버전별 · 주분석 전략]',
            *(version_lines or ['- 표본부족']),
            '',
            '[판독]',
            '- 좋았던 구간과 나빠진 구간의 차이가 신선도/늦은추격/실행위험에 몰리면 조건 변경보다 정보 사전보강 루프를 우선한다.',
            '- 보강 방향: S2가 방아쇠 근접하면 target_router/orderflow/micro 긴급갱신 → 갱신값으로 재판정 → 실패+늦은추격이면 S1 금지/S2 보류.',
            '- 이 cache는 복기/설계용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v572_good_bad_compare',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'good_window_versions': ['v2.13.461'],
            'bad_window_versions': ['v2.13.462','v2.13.463'],
            'good_window_stat': _v569_stat(good_rows),
            'bad_window_stat': _v569_stat(bad_rows),
            'good_window_flags': good_flags,
            'bad_window_flags': bad_flags,
            'safe_all_stat_reference_only': _v569_stat(safe_all),
            'safe_late_stat_reference_only': _v569_stat(safe_late),
            'late_loss_count': len(late_losses),
            'last16_loss_count': len(last16_losses),
            'late_loss_split_top': _v570_counter(late_cases),
            'last16_loss_split_top': _v570_counter(last_cases),
            'late_review_action_top': _v570_action_counter(late_cases),
            'late_loss_cases_sample': late_cases[:20],
            'primary_version_stats': {vk: _v569_stat(arr) for vk, arr in by_version.items()},
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v572', exc)








# =============================================================================
# paper_bot v0.200 / v578: 최고수익 대비 최종수익 복기 cache
# - 청산조건 변경 없음. 보호익절 강화 여부를 결정하기 위한 복기 전용이다.
# - paper_bot은 CLOSED/trade_log/review cache 주인이다.
# - 목적: AZTEC처럼 +1% 이상 갔다가 거의 못 먹은 케이스를 따로 집계한다.
# =============================================================================


def _v578_peak_bucket(row: Dict[str, Any]) -> str:
    peak = fnum(row.get('peak_pct'), default=fnum(row.get('pnl_pct'), default=0.0))
    if peak >= 1.30:
        return 'peak_1_30_plus'
    if peak >= 1.00:
        return 'peak_1_00_plus'
    if peak >= 0.70:
        return 'peak_0_70_plus'
    if peak >= 0.35:
        return 'peak_0_35_plus'
    return 'peak_under_0_35'


def _v578_floor_for_peak(peak: float) -> Optional[float]:
    # 복기용 가상 계단. 실제 청산조건은 변경하지 않는다.
    if peak >= 1.30:
        return 0.80
    if peak >= 1.00:
        return 0.55
    if peak >= 0.70:
        return 0.30
    return None


def _v578_giveback_case(row: Dict[str, Any]) -> Dict[str, Any]:
    pnl = fnum(row.get('pnl_pct'), default=0.0)
    peak = fnum(row.get('peak_pct'), default=pnl)
    giveback = max(0.0, peak - pnl)
    floor = _v578_floor_for_peak(peak)
    floor_gap = 0.0 if floor is None else max(0.0, floor - pnl)
    reason = str(row.get('exit_reason') or row.get('reason') or row.get('close_reason') or '-')
    ticker = normalize_ticker(row.get('ticker') or row.get('symbol') or '-')
    return {
        'ticker': ticker,
        'strategy': _strategy_key(row),
        'version': _main_version_key(row),
        'pnl_pct': round(pnl, 4),
        'peak_pct': round(peak, 4),
        'giveback_pct': round(giveback, 4),
        'peak_bucket': _v578_peak_bucket(row),
        'protect_floor_reference': floor,
        'floor_gap_reference': round(floor_gap, 4),
        'reason': reason,
        'close_review_tag': row.get('close_review_tag') or '',
        'age_min': round(fnum(row.get('age_min') or row.get('hold_minutes'), default=0.0), 3),
        'entry_price': row.get('entry_price'),
        'exit_price': row.get('exit_price') or row.get('close_price'),
    }


def _v578_avg(vals: List[float]) -> float:
    vals=[float(v) for v in vals if v is not None]
    return round(sum(vals)/len(vals), 4) if vals else 0.0


def _v578_peak_stats(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    cases=[_v578_giveback_case(r) for r in rows]
    peak70=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 0.70]
    peak100=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 1.00]
    heavy=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 0.70 and fnum(c.get('giveback_pct'), default=0.0) >= 0.55]
    severe=[c for c in cases if fnum(c.get('peak_pct'), default=0.0) >= 1.00 and fnum(c.get('pnl_pct'), default=0.0) <= 0.20]
    floor_miss=[c for c in cases if c.get('protect_floor_reference') is not None and fnum(c.get('floor_gap_reference'), default=0.0) > 0.0]
    return {
        'n': len(cases),
        'peak70_n': len(peak70),
        'peak100_n': len(peak100),
        'heavy_giveback_n': len(heavy),
        'peak100_low_final_n': len(severe),
        'floor_miss_n': len(floor_miss),
        'avg_peak_pct': _v578_avg([fnum(c.get('peak_pct'), default=0.0) for c in cases]),
        'avg_pnl_pct': _v578_avg([fnum(c.get('pnl_pct'), default=0.0) for c in cases]),
        'avg_giveback_pct': _v578_avg([fnum(c.get('giveback_pct'), default=0.0) for c in cases]),
        'peak70_avg_giveback_pct': _v578_avg([fnum(c.get('giveback_pct'), default=0.0) for c in peak70]),
        'top_giveback_cases': sorted(cases, key=lambda c: fnum(c.get('giveback_pct'), default=0.0), reverse=True)[:12],
        'floor_miss_cases': sorted(floor_miss, key=lambda c: fnum(c.get('floor_gap_reference'), default=0.0), reverse=True)[:12],
    }


def _v578_case_line(c: Dict[str, Any]) -> str:
    floor = c.get('protect_floor_reference')
    floor_txt = '-' if floor is None else f"+{float(floor):.2f}%"
    return (
        f"- {c.get('ticker','-')}: 최종 {fnum(c.get('pnl_pct'), default=0.0):+.2f}% / "
        f"최고 {fnum(c.get('peak_pct'), default=0.0):+.2f}% / "
        f"반납 {fnum(c.get('giveback_pct'), default=0.0):+.2f}% / "
        f"가상보호 {floor_txt} / {c.get('reason','-')}"
    )


def _v578_short_stat_line(st: Dict[str, Any]) -> str:
    n = int(st.get('n') or 0)
    if n <= 0:
        return '표본부족'
    return (
        f"표본 {n} / +0.7%도달 {int(st.get('peak70_n') or 0)} / +1.0%도달 {int(st.get('peak100_n') or 0)} / "
        f"큰반납 {int(st.get('heavy_giveback_n') or 0)} / +1%→최종+0.2%이하 {int(st.get('peak100_low_final_n') or 0)} / "
        f"평균최고 {fnum(st.get('avg_peak_pct'), default=0.0):+.2f}% / 평균최종 {fnum(st.get('avg_pnl_pct'), default=0.0):+.2f}% / 평균반납 {fnum(st.get('avg_giveback_pct'), default=0.0):+.2f}%"
    )


def write_trade_review_cache_v578(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
        nowv = now_ts()
        today_rows = _v557_filter_today(rows, nowv)
        primary = _v569_pick_primary_strategy(today_rows)
        primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
        primary_rows = sorted(primary_rows, key=lambda r: _v557_row_ts(r))
        half = len(primary_rows)//2
        early = primary_rows[:half] if half else []
        late = primary_rows[half:] if half else primary_rows
        last16 = primary_rows[-16:]
        # 기존 v572 신선도/타이밍 복기도 같이 유지한다.
        late_losses = [r for r in late if fnum(r.get('pnl_pct'), default=0.0) <= 0]
        late_cases = [_v570_case(r) for r in late_losses]
        safe_all = _v570_filter_safe(primary_rows)
        all_peak = _v578_peak_stats(primary_rows)
        late_peak = _v578_peak_stats(late)
        last16_peak = _v578_peak_stats(last16)
        top_cases = all_peak.get('top_giveback_cases') or []
        floor_cases = all_peak.get('floor_miss_cases') or []
        summary_lines = [
            '📉 복기 /trade_review · v578 최고수익 반납 확인판',
            '- 기준: paper_bot CLOSED tail + 진입 당시 row/snapshot만 사용. 조건·청산 재계산 없음.',
            f"- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개",
            '',
            '[성과 흐름]',
            f"- 전체: {_v569_stat_line(primary_rows)}" if primary_rows else '- 전체: 표본부족',
            f"- 초반: {_v569_stat_line(early)}" if early else '- 초반: 표본부족',
            f"- 후반: {_v569_stat_line(late)}" if late else '- 후반: 표본부족',
            f"- 최근16: {_v569_stat_line(last16)}" if last16 else '- 최근16: 표본부족',
            '',
            '[최고수익 반납]',
            f"- 전체: {_v578_short_stat_line(all_peak)}",
            f"- 후반: {_v578_short_stat_line(late_peak)}",
            f"- 최근16: {_v578_short_stat_line(last16_peak)}",
            '',
            '[수익 돌려준 상위]',
            *( [_v578_case_line(c) for c in top_cases[:5]] or ['- 표본부족'] ),
            '',
            '[가상 보호계단 참고 · 청산 변경 아님]',
            '- 기준 예시: 최고 +0.70%→최소 +0.30%, 최고 +1.00%→최소 +0.55%, 최고 +1.30%→최소 +0.80%',
            f"- 보호계단보다 낮게 끝난 후보: {int(all_peak.get('floor_miss_n') or 0)}개",
            *( [_v578_case_line(c) for c in floor_cases[:5]] or ['- 해당 없음'] ),
            '',
            '[후반 손실 원인 참고]',
            f"- 후반 손실 {len(late_losses)}개: {_v569_top(_v570_counter(late_cases), 8)}",
            f"- 신선도지연+늦은추격 의심 제외 시: {_v569_stat_line(safe_all)}" if primary_rows else '- 제외 참고: 표본부족',
            '',
            '[판독]',
            '- +0.7~1.0% 이상 갔다가 거의 못 먹는 케이스가 반복되면 다음 단계에서 보호익절 계단 강화를 검토한다.',
            '- PHA 같은 최고수익 0 근처 빠른실패는 청산 방어가 맞고, AZTEC처럼 +1% 이상 갔다가 +0.1% 근처 종료된 케이스는 보호익절 복기 대상이다.',
            '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        ]
        obj = {
            'schema': 'paper_trade_review_cache_v578_peak_giveback',
            'version': VERSION,
            'build': BUILD_LABEL,
            'updated_at': nowv,
            'updated_at_text': iso_ts(),
            'source': 'paper_bot_closed_tail_cache_only',
            'today_closed_count': len(today_rows),
            'primary_strategy': primary,
            'primary_count': len(primary_rows),
            'overall_stat': _v569_stat(primary_rows),
            'early_stat': _v569_stat(early),
            'late_stat': _v569_stat(late),
            'last16_stat': _v569_stat(last16),
            'overall_peak_giveback': all_peak,
            'late_peak_giveback': late_peak,
            'last16_peak_giveback': last16_peak,
            'safe_all_stat_reference_only': _v569_stat(safe_all),
            'late_loss_split_top': _v570_counter(late_cases),
            'summary_text': '\n'.join(summary_lines),
        }
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v578', exc)






# =============================================================================

# [v582 cleanup] removed stale duplicate writer block.


# =============================================================================
# paper_bot v0.205 / v582: paper spine final surgery
# - No new strategy/exit condition changes.
# - One cycle reads active paper rows once and writes status/handoff/trace from the same snapshot.
# - Startup/heartbeat also overwrites stale handoff with current VERSION so old handoff cannot survive.
# =============================================================================


def _v582_stage_key(ev: Dict[str, Any]) -> str:
    v = str(ev.get('s_stage') or ev.get('candidate_grade') or ev.get('stage') or ev.get('grade') or '').upper().strip()
    if v in {'S1','S2','S3'}:
        return v
    if v in {'X','EXCLUDE','EXCLUDED','BLOCK','BLOCKED'}:
        return 'X'
    return v or '-'


def _v582_active_rows(ctrl: Optional[Dict[str, Any]] = None, max_rows: int = 800) -> List[Dict[str, Any]]:
    try:
        ctrl = ctrl or load_control()
        limit = int(fnum(ctrl.get('candidate_read_max_lines'), default=max_rows))
        limit = max(100, min(max_rows, limit))
        rows = [dict(r) for r in read_jsonl_tail(FILES['paper_latest'], limit) if isinstance(r, dict)]
        try:
            return latest_scan_filter(rows, ctrl)
        except Exception as exc:
            log_error('v582_latest_scan_filter', exc)
            return rows
    except Exception as exc:
        log_error('v582_active_rows', exc)
        return []


def _v582_make_snapshot(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], pick_stats: Optional[Dict[str, Any]], open_pos: Dict[str, Dict[str, Any]]) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    pick = dict(pick_stats or {})
    fresh_n = 0
    for r in rows:
        try:
            if candidate_is_fresh(r, ctrl):
                fresh_n += 1
        except Exception:
            pass
    stage_counts = Counter(_v582_stage_key(r) for r in rows)
    nowv = now_ts()
    snapshot = {
        'schema': 'paper_candidate_snapshot_v584_direct_rows',
        'version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'snapshot_id': f"v584-{int(nowv*1000)}",
        'snapshot_owner': 'paper_bot',
        'snapshot_rule': 'direct active rows -> one status/handoff/trace writer; paper reads strategy canonical_metric_row',
        'latest_count': len(rows),
        'paper_latest_count': len(rows),
        'active_latest_count': len(rows),
        'latest_lines': len(rows),
        'merged_fresh': fresh_n,
        'fresh_count': fresh_n,
        'fresh_source': 'v584_direct_active_rows_candidate_is_fresh',
        'stage_counts': dict(stage_counts),
        's1_count': int(stage_counts.get('S1', 0)),
        's2_count': int(stage_counts.get('S2', 0)),
        's3_count': int(stage_counts.get('S3', 0)),
        'x_count': int(stage_counts.get('X', 0)),
        'open_count': len(open_pos) if isinstance(open_pos, dict) else 0,
        'open_total': len(open_pos) if isinstance(open_pos, dict) else 0,
        'writer': 'v584_direct_spine_writer',
    }
    # Mirror snapshot values into pick_stats so /pstatus and main bot readers do not borrow stale handoff values.
    pick.update({
        'latest_count': snapshot['latest_count'],
        'paper_latest_count': snapshot['paper_latest_count'],
        'active_latest_count': snapshot['active_latest_count'],
        'merged_fresh': snapshot['merged_fresh'],
        'fresh_count': snapshot['fresh_count'],
        'fresh_source': snapshot['fresh_source'],
        'stage_counts': snapshot['stage_counts'],
        's1_seen': int(pick.get('s1_seen') or snapshot['s1_count']),
        'paper_candidate_snapshot': snapshot,
        'snapshot_schema': snapshot['schema'],
        'snapshot_id': snapshot['snapshot_id'],
        'writer': 'v584_direct_spine_writer',
    })
    return snapshot, pick


def _v582_minimal_trace(rows: List[Dict[str, Any]], ctrl: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]], err: str = '') -> Dict[str, Any]:
    out = []
    for ev in (rows or [])[:120]:
        if not isinstance(ev, dict):
            continue
        try:
            eid = event_id(ev)
            out.append({
                'trace_id': eid,
                'ticker': normalize_ticker(ev.get('ticker') or ev.get('symbol') or ev.get('market')),
                'stage': _v582_stage_key(ev),
                'fresh': candidate_is_fresh(ev, ctrl),
                'open': eid in open_pos,
                'strategy': ev.get('strategy_label') or ev.get('strategy') or ev.get('strategy_key'),
                'status': 'open' if eid in open_pos else 'observed',
            })
        except Exception:
            continue
    return {
        'schema': 'paper_candidate_handoff_trace_v584_minimal',
        'version': VERSION,
        'trace_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'rows': out,
        'fallback_reason': err,
    }


def _v582_write_spine(status: Dict[str, Any], trace_obj: Dict[str, Any], snapshot: Dict[str, Any], pick_stats: Dict[str, Any], open_pos: Dict[str, Dict[str, Any]]) -> None:
    nowv = now_ts()
    trace_rows = trace_obj.get('rows') if isinstance(trace_obj.get('rows'), list) else []
    common = {
        'version': VERSION,
        'paper_version': VERSION,
        'active_reader_version': VERSION,
        'build': BUILD_LABEL,
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'latest_count': snapshot.get('latest_count', 0),
        'paper_latest_count': snapshot.get('paper_latest_count', snapshot.get('latest_count', 0)),
        'active_latest_count': snapshot.get('active_latest_count', snapshot.get('latest_count', 0)),
        'latest_lines': snapshot.get('latest_lines', snapshot.get('latest_count', 0)),
        'merged_fresh': snapshot.get('merged_fresh', snapshot.get('fresh_count', 0)),
        'fresh_count': snapshot.get('fresh_count', snapshot.get('merged_fresh', 0)),
        'fresh_source': snapshot.get('fresh_source'),
        'open_count': len(open_pos) if isinstance(open_pos, dict) else 0,
        'open_total': len(open_pos) if isinstance(open_pos, dict) else 0,
        'stage_counts': snapshot.get('stage_counts', {}),
        'snapshot_id': snapshot.get('snapshot_id'),
        'snapshot_schema': snapshot.get('schema'),
        'paper_candidate_snapshot': snapshot,
        'pick_stats': pick_stats,
        'writer': 'v584_direct_spine_writer',
        'cache_spine': 'v584 direct single writer: status/handoff/trace + canonical metric row review',
    }
    trace_out = dict(trace_obj or {})
    trace_out.update(common)
    trace_out.update({
        'schema': 'paper_candidate_handoff_trace_v584_direct_spine',
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
    })
    handoff = dict(common)
    handoff.update({
        'schema': 'paper_handoff_status_v584_direct_spine',
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
    })
    status_out = dict(status or {})
    status_out.update(common)
    status_out.update({
        'schema': 'paper_status_v584_direct_spine',
        'running': bool(status_out.get('running', True)),
        'process_alive': True,
        'trace_version': VERSION,
        'trace_rows': len(trace_rows),
        'cache_spine_version': 'v584',
    })
    # Direct writes only. Do not call old write_status here; that path only owns process heartbeat.
    save_json(FILES['trace'], trace_out)
    save_json(FILES['handoff_status'], handoff)
    save_json(FILES['status'], status_out)
    globals()['_LAST_STATUS'] = status_out
    try:
        write_pid()
    except Exception:
        pass




# =============================================================================
# paper_bot v0.207 / v584: canonical metric row reader
# - paper_bot은 strategy_worker가 봉인한 canonical_metric_row를 읽기만 한다.
# - 구조/fresh/실행위험을 paper에서 재판정하지 않는다.
# - OPEN/CLOSED/score/review 기능 유지.
# =============================================================================

def _v584_get_canonical_metric(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return {}
    cm = row.get('canonical_metric_row')
    if isinstance(cm, dict):
        return cm
    ctx = row.get('entry_context') if isinstance(row.get('entry_context'), dict) else {}
    cm = ctx.get('canonical_metric_row')
    return cm if isinstance(cm, dict) else {}


def _v584_metric_counter(rows: List[Dict[str, Any]], path: Tuple[str, ...], limit: int = 5) -> str:
    c: Counter = Counter()
    for r in rows or []:
        cm = _v584_get_canonical_metric(r)
        v: Any = cm
        for k in path:
            if isinstance(v, dict):
                v = v.get(k)
            else:
                v = None
                break
        if v:
            c[str(v)] += 1
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v584_entry_reaction_bucket(row: Dict[str, Any]) -> str:
    peak = num(row.get('peak_profit_pct'), row.get('max_profit_pct'), default=0.0)
    final = num(row.get('pnl_pct'), row.get('profit_pct'), default=0.0)
    low = num(row.get('max_loss_pct'), row.get('min_profit_pct'), default=0.0)
    reason = str(row.get('close_reason') or row.get('exit_reason') or '')
    if peak < 0.15 and final <= -0.20:
        return '진입후무반응/빠른실패'
    if peak >= 0.70 and (peak - final) >= 0.50:
        return '최고수익반납'
    if 'stop' in reason or '손절' in reason:
        return '손절정리'
    if final > 0:
        return '수익청산'
    return '기타/표본'


def _v584_canonical_review_block(rows: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    with_canon = [r for r in rows if _v584_get_canonical_metric(r)]
    react_counter: Counter = Counter(_v584_entry_reaction_bucket(r) for r in rows)
    data = {
        'schema': 'paper_trade_review_canonical_metric_row_v584',
        'row_count': len(rows),
        'with_canonical_metric_row': len(with_canon),
        'structure_state_top': _v584_metric_counter(with_canon, ('structure','state'), 5),
        'freshness_top': _v584_metric_counter(with_canon, ('freshness_map','overall'), 5),
        'execution_risk_top': _v584_metric_counter(with_canon, ('execution_risk','state'), 5),
        'decision_top': _v584_metric_counter(with_canon, ('decision_reference',), 5),
        'entry_reaction_top': ' / '.join(f'{k} {v}' for k, v in react_counter.most_common(5)) if react_counter else '-',
    }
    lines = ['[canonical row 복기 · v584]']
    if not rows:
        lines.append('- 오늘 CLOSED 없음 또는 표본부족')
    elif not with_canon:
        lines.append('- 신규 v584 이후 CLOSED부터 canonical_metric_row가 누적됩니다.')
    else:
        lines += [
            f"- canonical 보유 {len(with_canon)}/{len(rows)}개",
            f"- 구조 TOP: {data['structure_state_top']}",
            f"- fresh TOP: {data['freshness_top']}",
            f"- 실행위험 TOP: {data['execution_risk_top']}",
            f"- 판정 TOP: {data['decision_top']}",
        ]
    lines.append(f"- 진입반응 TOP: {data['entry_reaction_top']}")
    return lines, data

_v582_base_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v582_base_write_score_cache(status)
    try:
        write_trade_review_cache_v578(status)
        obj = load_json(FILES['trade_review'], {}) or {}
        if isinstance(obj, dict):
            try:
                rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
                today_rows = _v557_filter_today(rows, now_ts())
                block_lines, block_data = _v584_canonical_review_block(today_rows)
                summary = str(obj.get('summary_text') or '')
                if '[구조×신선도 복기]' not in summary:
                    obj['summary_text'] = summary + ('\n\n' if summary else '') + '\n'.join(block_lines)
                obj['canonical_metric_row_review'] = block_data
            except Exception as exc:
                log_error('v584_canonical_metric_review', exc)
            obj['schema'] = 'paper_trade_review_cache_v584_canonical_metric_row'
            obj['version'] = VERSION
            obj['paper_version'] = VERSION
            obj['build'] = BUILD_LABEL
            obj['writer'] = 'v584_direct_spine_writer'
            save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v584', exc)


_v582_base_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    """Heartbeat/status writes cannot leave stale handoff behind.
    When called outside run_cycle, it still writes a light same-version handoff/trace snapshot.
    """
    try:
        st = dict(status or {})
        ctrl = load_control()
        open_pos = load_open()
        rows = _v582_active_rows(ctrl)
        snapshot, pick = _v582_make_snapshot(rows, ctrl, st.get('pick_stats') if isinstance(st.get('pick_stats'), dict) else {}, open_pos)
        trace_obj = _v582_minimal_trace(rows, ctrl, open_pos, 'status_heartbeat')
        st.setdefault('engine', 'light_runner')
        st.setdefault('running', True)
        _v582_write_spine(st, trace_obj, snapshot, pick, open_pos)
    except Exception as exc:
        log_error('v584_write_status_spine', exc)
        _v582_base_write_status(status)


def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    started = now_ts()
    ctrl = load_control()
    open_pos = load_open()
    opened_items: List[Dict[str, Any]] = []
    closed_items: List[Dict[str, Any]] = []
    picked_ids: set[str] = set()
    opened_ids: set[str] = set()
    pick_stats: Dict[str, Any] = {}
    latest_rows: List[Dict[str, Any]] = []
    before_closed_count = line_count_cached(FILES['closed'], ttl=0)

    if ctrl.get('running', True):
        picked, pick_stats, latest_rows = select_candidates(ctrl, open_pos)
        latest_rows = [r for r in (latest_rows or []) if isinstance(r, dict)]
        for pid, ev in picked:
            picked_ids.add(pid)
            if pid in open_pos:
                continue
            try:
                pos = open_position(pid, ev)
                open_pos[pid] = pos
                opened_items.append(pos)
                opened_ids.add(pid)
            except Exception as exc:
                log_error('open_position', exc)
        for pid, pos in list(open_pos.items()):
            try:
                updated, closed = update_position(pos, ctrl)
                if closed:
                    closed_items.append(closed)
                    open_pos.pop(pid, None)
                    append_jsonl(FILES['closed'], closed)
                    _LAST_CLOSED_COUNT_CACHE.update({'ts': 0.0, 'count': 0})
                else:
                    open_pos[pid] = updated
            except Exception as exc:
                log_error('update_position', exc)
        save_open(open_pos)
    else:
        latest_rows = _v582_active_rows(ctrl)
        pick_stats['paused'] = 1

    # If an older select path returns no rows but the active paper file has rows, use the active file for status/trace only.
    if not latest_rows:
        latest_rows = _v582_active_rows(ctrl)

    snapshot, pick_stats = _v582_make_snapshot(latest_rows, ctrl, pick_stats, open_pos)
    try:
        trace_obj = build_trace(latest_rows, ctrl, open_pos, picked_ids, opened_ids)
    except Exception as exc:
        log_error('v584_build_trace', exc)
        trace_obj = _v582_minimal_trace(latest_rows, ctrl, open_pos, f'{type(exc).__name__}: {exc}')

    status = {
        'running': bool(ctrl.get('running', True)),
        'loop_seconds': ctrl.get('loop_seconds'),
        'opened_this_cycle': len(opened_items),
        'closed_this_cycle': len(closed_items),
        'open_total': len(open_pos),
        'open_count': len(open_pos),
        'open_strict': len(open_pos),
        'closed_total': line_count_cached(FILES['closed'], ttl=0 if closed_items else 60.0),
        'pick_stats': pick_stats,
        'elapsed_sec': round(now_ts() - started, 3),
        'engine': 'light_runner',
        'legacy_loop': False,
        'before_closed_count': before_closed_count,
        'writer': 'v584_direct_spine_writer',
    }

    if ctrl.get('write_score_cache', True):
        write_score_cache(status)
    _v582_write_spine(status, trace_obj, snapshot, pick_stats, open_pos)

    for pos in opened_items:
        try:
            notify_opened(pos)
        except Exception as exc:
            log_error('v584_notify_opened', exc)
            try:
                _v567_append_trade_alert_trace('open', pos, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'v584 notify_opened raised')
            except Exception:
                pass
    for row in closed_items:
        try:
            notify_closed(row)
        except Exception as exc:
            log_error('v584_notify_closed', exc)
            try:
                _v567_append_trade_alert_trace('closed', row, 'message_build_error', False, f'{type(exc).__name__}: {exc}', 'v584 notify_closed raised')
            except Exception:
                pass

    notify_s1_decision_summary(pick_stats, opened_count=len(opened_items), closed_count=len(closed_items), ctrl=ctrl)
    notify_market_hot_summary(ctrl)
    try:
        log(f"{VERSION} cycle opened={len(opened_items)} closed={len(closed_items)} open={len(open_pos)} elapsed={status['elapsed_sec']}s latest={snapshot.get('latest_count')} fresh={snapshot.get('merged_fresh')} snapshot={snapshot.get('snapshot_id')} writer=v584")
    except Exception:
        pass
    return status


_v582_base_pstatus_text = pstatus_text

def pstatus_text() -> str:  # type: ignore[override]
    status = load_json(FILES['status'], {}) or {}
    handoff = load_json(FILES['handoff_status'], {}) or {}
    trace = load_json(FILES['trace'], {}) or {}
    op = load_open()
    snap = status.get('paper_candidate_snapshot') if isinstance(status.get('paper_candidate_snapshot'), dict) else {}
    latest = status.get('latest_count', snap.get('latest_count', '-'))
    fresh = status.get('merged_fresh', snap.get('merged_fresh', '-'))
    lines = [
        f"🧪 paper 상태 /pstatus ({VERSION})",
        f"- running: {status.get('running', True)} / open {len(op)} / status age {_v561_age_from(status)} / handoff age {_v561_age_from(handoff)} / trace age {_v561_age_from(trace)}",
        f"- 이번 cycle: OPEN {status.get('opened_this_cycle',0)} / CLOSED {status.get('closed_this_cycle',0)} / elapsed {status.get('elapsed_sec','-')}s",
        f"- 후보: latest {latest} / fresh {fresh} / S1감지 {(status.get('pick_stats') or {}).get('s1_seen', snap.get('s1_count',0))} / S1선택 {(status.get('pick_stats') or {}).get('selected_s1',0)} / OPEN보류 {(status.get('pick_stats') or {}).get('paper_entry_hold', (status.get('pick_stats') or {}).get('paper_final_block',0))} / micro대기 {(status.get('pick_stats') or {}).get('micro_preopen_wait',0)}",
        f"- spine: status {status.get('version','-')} / handoff {handoff.get('version','-')} / trace {trace.get('version') or trace.get('trace_version') or '-'} / snapshot {status.get('snapshot_id') or snap.get('snapshot_id') or '-'}",
        "- writer: v584 direct_spine_writer / paper reads strategy canonical_metric_row only",
    ]
    return '\n'.join(lines)




# =============================================================================
# paper_bot v0.208 / v586: OPEN/CLOSED alert formatter source cleanup
# - 기능 삭제 없음. 알림에 표시하는 값의 source만 canonical_metric_row/entry_diagnostics로 통일한다.
# - 누락값을 +0.00으로 보정하지 않고 "정보없음" 또는 "-"로 표시한다.
# - 구 entry_timing_trace와 canonical timing_spine을 동시에 보여주는 중복 표시를 제거한다.
# - 조건/S등급/청산/OPEN/CLOSED/장부/score/cache는 변경하지 않는다.
# =============================================================================

def _v586_present(v: Any) -> bool:
    if v is None:
        return False
    if isinstance(v, str) and not v.strip():
        return False
    return True


def _v586_to_float(v: Any) -> Optional[float]:
    if not _v586_present(v):
        return None
    try:
        return float(str(v).replace(',', '').replace('%', '').strip())
    except Exception:
        return None


def _v586_first_present_from(obj: Any, keys: Iterable[str]) -> Tuple[Any, str]:
    if not isinstance(obj, dict):
        return None, ''
    for k in keys:
        if k in obj and _v586_present(obj.get(k)):
            return obj.get(k), k
    return None, ''


def _v586_nested(obj: Any, path: Iterable[str]) -> Any:
    cur = obj
    for k in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(k)
    return cur


def _v586_get_canonical_metric(row: Dict[str, Any], diag: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    sources: List[Any] = []
    if isinstance(row, dict):
        sources.append(row)
        if isinstance(row.get('entry_context'), dict):
            sources.append(row.get('entry_context'))
        if isinstance(row.get('entry_diagnostics'), dict):
            sources.append(row.get('entry_diagnostics'))
    if isinstance(diag, dict):
        sources.append(diag)
    for src in sources:
        cm = src.get('canonical_metric_row') if isinstance(src, dict) else None
        if isinstance(cm, dict):
            return cm
    return {}


def _v586_metric(row: Dict[str, Any], diag: Dict[str, Any], canonical: Dict[str, Any], metric_key: str, fallback_keys: Iterable[str] = ()) -> Tuple[Optional[float], str]:
    mv = _v586_nested(canonical, ('metrics', metric_key))
    # canonical v584 metrics may contain 0.0 defaults, so only trust it when the original row/diag also had the key
    for src_name, src in (('diag', diag), ('row', row), ('ctx', row.get('entry_context') if isinstance(row, dict) else {})):
        if not isinstance(src, dict):
            continue
        v, k = _v586_first_present_from(src, [metric_key, *fallback_keys])
        fv = _v586_to_float(v)
        if fv is not None:
            return fv, f'{src_name}.{k}'
    fv = _v586_to_float(mv)
    if fv is not None and abs(fv) > 0.000001:
        return fv, f'canonical.metrics.{metric_key}'
    return None, ''


def _v586_pct(v: Optional[float], *, signed: bool = True, missing: str = '정보없음') -> str:
    if v is None:
        return missing
    return f'{v:+.2f}%' if signed else f'{v:.2f}%'


def _v586_num(v: Optional[float], *, missing: str = '정보없음', digits: int = 2) -> str:
    if v is None:
        return missing
    return f'{v:.{digits}f}'


def _v586_label_list(values: Any, limit: int = 5) -> str:
    if not isinstance(values, list):
        return ''
    vals = [str(x).strip() for x in values if str(x).strip()]
    return ' / '.join(vals[:limit])


def _v586_flow_value(row: Dict[str, Any], diag: Dict[str, Any], window: str) -> str:
    # Prefer the existing flow_window_map because it preserves missing-vs-zero.
    val = _paper_v479_flow_display(diag, window)
    if val != '-':
        return val
    keysets = {
        '1m': ('flow_1m_pct','change_1m','chg_1m','ret_1m_pct','price_change_1m'),
        '3m': ('flow_3m_pct','change_3m','chg_3m','ret_3m_pct','price_change_3m'),
        '5m': ('flow_5m_pct','change_5m','chg_5m','ret_5m_pct','price_change_5m'),
        '15m': ('flow_15m_pct','change_15m','chg_15m','ret_15m_pct','price_change_15m'),
    }
    for src in (diag, row, row.get('entry_context') if isinstance(row, dict) else {}):
        if not isinstance(src, dict):
            continue
        v, _ = _v586_first_present_from(src, keysets.get(window, ()))
        fv = _v586_to_float(v)
        if fv is not None:
            return f'{fv:+.2f}%'
    return '-'


def _v586_timing_line(row: Dict[str, Any], diag: Dict[str, Any], canonical: Dict[str, Any], prefix: str = '- ') -> str:
    timing = _v586_nested(canonical, ('timing_spine',))
    if not isinstance(timing, dict):
        timing = diag.get('entry_timing_spine') if isinstance(diag.get('entry_timing_spine'), dict) else {}
    if not isinstance(timing, dict) or not timing:
        return prefix + '진입타이밍: 정보없음'
    first_ts = _v586_to_float(timing.get('first_seen_ts'))
    nowv = _v586_to_float(timing.get('now_ts'))
    f_delay = _v586_to_float(timing.get('first_to_now_delay_sec'))
    if f_delay is None and first_ts is not None and nowv is not None and nowv >= first_ts:
        f_delay = nowv - first_ts
    s_delay = _v586_to_float(timing.get('s1_to_paper_delay_sec') or timing.get('paper_read_delay_sec'))
    first_ret = _v586_to_float(timing.get('first_to_now_return_pct') or timing.get('first_to_open_return_pct'))
    s2_ret = _v586_to_float(timing.get('s2_to_now_return_pct') or timing.get('s2_to_open_return_pct'))
    parts = []
    if first_ret is not None:
        delay_txt = f'{f_delay:.0f}s' if f_delay is not None else '시간정보없음'
        parts.append(f'최초→현재 {delay_txt}/{first_ret:+.2f}%')
    if s2_ret is not None:
        parts.append(f'S2→현재 {s2_ret:+.2f}%')
    if s_delay is not None:
        parts.append(f'S1→paper {s_delay:.0f}s')
    if bool(timing.get('late_chase_flag')):
        parts.append('늦은추격주의')
    return prefix + '진입타이밍: ' + (' · '.join(parts) if parts else '정보없음')


def format_entry_timing_line(trace: Any, prefix: str = '- ') -> str:  # type: ignore[override]
    """Legacy timing trace display is deprecated for alerts.
    Kept for compatibility, but it no longer prints misleading +0.00/hot -/- lines.
    """
    if not isinstance(trace, dict) or not trace:
        return ''
    f1 = _v586_to_float(trace.get('flow_1m_pct'))
    f3 = _v586_to_float(trace.get('flow_3m_pct'))
    hot1 = trace.get('hot_rank_1m')
    hot3 = trace.get('hot_rank_3m')
    if (f1 is None or abs(f1) < 0.000001) and (f3 is None or abs(f3) < 0.000001) and not _v586_present(hot1) and not _v586_present(hot3):
        return ''
    flow = f"1m {_v586_pct(f1)} · 3m {_v586_pct(f3)}"
    hot = f"hot {hot1 if _v586_present(hot1) else '정보없음'}/{hot3 if _v586_present(hot3) else '정보없음'}"
    return prefix + f"진입시점 참고: {flow} / {hot}"


def format_entry_diag_lines(diag: Dict[str, Any], prefix: str = '- ') -> List[str]:  # type: ignore[override]
    diag = diag if isinstance(diag, dict) else {}
    # When only diagnostics are passed, canonical may still be embedded inside it.
    row: Dict[str, Any] = diag.get('_source_row') if isinstance(diag.get('_source_row'), dict) else {}
    canonical = _v586_get_canonical_metric(row, diag)
    lines: List[str] = []
    structures = diag.get('entry_structure_tags') if isinstance(diag.get('entry_structure_tags'), list) else []
    reasons = diag.get('entry_reasons') if isinstance(diag.get('entry_reasons'), list) else []
    confirms = diag.get('confirm_signals') if isinstance(diag.get('confirm_signals'), list) else []
    risks = diag.get('execution_risk_tags') if isinstance(diag.get('execution_risk_tags'), list) else []
    rechecks = diag.get('recheck_reasons') if isinstance(diag.get('recheck_reasons'), list) else []
    blocks = diag.get('block_reasons') if isinstance(diag.get('block_reasons'), list) else []
    missing = diag.get('missing_info') if isinstance(diag.get('missing_info'), list) else []
    cm_struct = canonical.get('structure') if isinstance(canonical.get('structure'), dict) else {}
    cm_exec = canonical.get('execution_risk') if isinstance(canonical.get('execution_risk'), dict) else {}
    cm_fresh = canonical.get('freshness_map') if isinstance(canonical.get('freshness_map'), dict) else {}
    cm_metrics = canonical.get('metrics') if isinstance(canonical.get('metrics'), dict) else {}
    if not structures and isinstance(cm_struct.get('tags'), list):
        structures = cm_struct.get('tags')
    if structures:
        lines.append(prefix + '진입구조: ' + _v586_label_list(structures, 5))
    if reasons:
        lines.append(prefix + '진입근거: ' + _v586_label_list(reasons, 5))
    if confirms:
        lines.append(prefix + '확인통과: ' + _v586_label_list(confirms, 6))
    else:
        react, _ = _v586_metric(row, diag, canonical, 'price_reaction_pct', ('price_reaction_pct','price_reaction'))
        buy, _ = _v586_metric(row, diag, canonical, 'buy_ratio', ('buy_ratio','buy_trade_ratio'))
        sustain, _ = _v586_metric(row, diag, canonical, 'buy_sustain_1m', ('buy_sustain_1m','buy_ratio_1m'))
        spread, _ = _v586_metric(row, diag, canonical, 'spread_pct', ('spread_pct','micro_spread_pct'))
        fresh = cm_fresh.get('overall') if isinstance(cm_fresh, dict) else None
        passed = []
        if fresh: passed.append(f'신선도 {fresh}')
        if react is not None: passed.append(f'가격반응 {_v586_pct(react)}')
        if buy is not None: passed.append(f'매수체결 {_v586_num(buy)}')
        if sustain is not None: passed.append(f'1분지속 {_v586_num(sustain)}')
        if spread is not None: passed.append(f'스프레드 {_v586_pct(spread, signed=False)}')
        if passed:
            lines.append(prefix + '확인값: ' + ' / '.join(passed))
    levels = cm_struct.get('levels') if isinstance(cm_struct.get('levels'), dict) else (diag.get('structure_levels') if isinstance(diag.get('structure_levels'), dict) else {})
    plan = canonical.get('entry_plan') if isinstance(canonical.get('entry_plan'), dict) else (diag.get('entry_plan') if isinstance(diag.get('entry_plan'), dict) else {})
    rr = canonical.get('risk_reward') if isinstance(canonical.get('risk_reward'), dict) else (diag.get('risk_reward') if isinstance(diag.get('risk_reward'), dict) else {})
    if levels and levels.get('available', True):
        lines.append(prefix + '구조선: 지지 ' + fmt_price(levels.get('support_price')) + ' / 방아쇠 ' + fmt_price(levels.get('trigger_price')) + ' / 무효 ' + fmt_price(levels.get('invalid_price')) + ' / 목표 ' + fmt_price(levels.get('target1_price')) + '→' + fmt_price(levels.get('target2_price')))
    if plan:
        lines.append(prefix + '진입계획: ' + str(plan.get('plan_type') or '정보없음') + ' / ' + str(plan.get('trigger_reason') or '정보없음'))
    if rr:
        up = _v586_to_float(rr.get('expected_upside_pct'))
        dn = _v586_to_float(rr.get('expected_downside_pct'))
        ratio = _v586_to_float(rr.get('rr_ratio'))
        lines.append(prefix + f"손익비: 기대상승 {_v586_pct(up)} / 무효손실 {_v586_pct(-abs(dn) if dn is not None else None)} / RR {_v586_num(ratio)}")
    lines.append(_v586_timing_line(row, diag, canonical, prefix))
    if cm_struct.get('state'):
        lines.append(prefix + '구조판정: ' + str(cm_struct.get('state')))
    if cm_fresh.get('overall'):
        lines.append(prefix + f"신선도: {cm_fresh.get('overall')} / core age {cm_fresh.get('max_core_age_sec', '정보없음')}s")
    if risks or (isinstance(cm_exec, dict) and cm_exec.get('tags')):
        risk_list = risks if risks else cm_exec.get('tags')
        lines.append(prefix + '위험태그: ' + _v586_label_list(risk_list, 5))
    flow = f"1m {_v586_flow_value(row, diag, '1m')} · 3m {_v586_flow_value(row, diag, '3m')} · 5m {_v586_flow_value(row, diag, '5m')} · 15m {_v586_flow_value(row, diag, '15m')}"
    lines.append(prefix + '흐름: ' + flow)
    vwap, _ = _v586_metric(row, diag, canonical, 'vwap_pos_pct', ('vwap_pos_pct','vwap_gap_pct','vwap_position_pct'))
    ema, _ = _v586_metric(row, diag, canonical, 'ema5_pos_pct', ('ema5_pos_pct','ema5_gap_pct','ema5_position_pct'))
    rel, _ = _v586_metric(row, diag, canonical, 'relative_strength', ('relative_strength','market_relative_strength'))
    if vwap is None and ema is None and rel is None:
        lines.append(prefix + '위치: 정보없음')
    else:
        lines.append(prefix + f"위치: VWAP {_v586_pct(vwap)} · EMA5 {_v586_pct(ema)} · 상대강도 {_v586_num(rel)}")
    decision = canonical.get('decision_reference') if isinstance(canonical, dict) else None
    caution = []
    for group in (rechecks, blocks, missing):
        for x in group or []:
            sx = str(x).strip()
            if sx and sx not in caution:
                caution.append(sx)
    if caution:
        lines.append(prefix + '재확인/주의: ' + ' / '.join(caution[:5]))
    else:
        lines.append(prefix + '최종판정: ' + str(decision or 'S1 통과'))
    return [ln for ln in lines if isinstance(ln, str) and ln.strip()]


def _v586_diag_from_trade(row: Dict[str, Any]) -> Dict[str, Any]:
    diag = row.get('entry_diagnostics') if isinstance(row.get('entry_diagnostics'), dict) else {}
    diag = dict(diag)
    diag['_source_row'] = row
    return diag


def _v561_open_message_text(pos: Dict[str, Any]) -> str:  # type: ignore[override]
    t = normalize_ticker(pos.get('ticker'))
    link = f"https://www.bithumb.com/trade/order/{t}_KRW" if t else ''
    diag = _v586_diag_from_trade(pos)
    extra = '\n'.join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    return (
        "🟢 paper OPEN\n"
        f"- 종목: {t}\n"
        f"- 진입가: {fmt_price(pos.get('entry_price'))}\n"
        f"- 등급: {pos.get('candidate_grade','S1')} / 점수 {fnum(pos.get('score'), default=0.0):.2f}\n"
        f"- 전략: {pos.get('strategy_label') or pos.get('strategy') or '-'}\n"
        f"- profile: {pos.get('entry_profile', '-')} / exit {pos.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- 바로보기: {link}\n"
        f"- paper: {VERSION}"
    )


def _v567_closed_message_text(row: Dict[str, Any]) -> str:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker'))
    diag = _v586_diag_from_trade(row)
    extra = '\n'.join(format_entry_diag_lines(diag)) if diag else '- 진입근거: strategy 상세값 미전달'
    return (
        f"{closed_title(row)}\n"
        f"- 종목: {t}\n"
        f"- 손익: {fnum(row.get('pnl_pct'), default=0.0):+.2f}%\n"
        f"- 이유: {row.get('exit_rule_label') or row.get('exit_reason')}\n"
        f"- 진입/청산: {fmt_price(row.get('entry_price'))} → {fmt_price(row.get('exit_price'))}\n"
        f"- 최고/최저: {fnum(row.get('peak_pct'), default=0.0):+.2f}% / {fnum(row.get('trough_pct'), default=0.0):+.2f}%\n"
        f"- 청산복기: 최고 {fnum(row.get('peak_pct'), default=0.0):+.2f}% → 최종 {fnum(row.get('pnl_pct'), default=0.0):+.2f}% / 놓친수익 {fnum(row.get('missed_profit_pct'), default=0.0):+.2f}% / {row.get('close_review_tag','관찰')}\n"
        f"{(_v494_fast_fail_cause_line(row) + chr(10)) if str(row.get('exit_reason') or row.get('exit_rule') or '') == 'fast_fail_stop' else ''}"
        f"- 보유: {row.get('age_min','-')}분\n"
        f"- 전략: {row.get('strategy_label') or row.get('strategy') or '-'}\n"
        f"- profile: {row.get('entry_profile', '-')} / exit {row.get('exit_profile', '-')}\n"
        f"{extra}\n"
        f"- paper: {VERSION}"
    )



# =============================================================================
# paper_bot v0.209 / v587: hourly summary + hot-rank review spine
# - 기능/조건 변경 없음. 1시간 요약과 hot-rank 요약의 source 표시만 현재 paper spine 기준으로 맞춘다.
# - hot-rank 급등이 후보없음/not_seen일 때 무근거로 끝내지 않고 scanner→strategy 매칭 상태를 남긴다.
# =============================================================================

def _v587_status_spine() -> Dict[str, Any]:
    status = load_json(FILES.get('status', BASE_DIR / 'paper_bot_status.json'), {}) or {}
    handoff = load_json(FILES.get('handoff_status', BASE_DIR / 'paper_bot_candidate_handoff_status.json'), {}) or {}
    trace = load_json(FILES.get('trace', BASE_DIR / 'paper_bot_candidate_handoff_trace.json'), {}) or {}
    if not isinstance(status, dict): status = {}
    if not isinstance(handoff, dict): handoff = {}
    if not isinstance(trace, dict): trace = {}
    snap = status.get('paper_candidate_snapshot') if isinstance(status.get('paper_candidate_snapshot'), dict) else {}
    latest = status.get('latest_count', snap.get('latest_count', '-'))
    fresh = status.get('merged_fresh', status.get('fresh_count', snap.get('merged_fresh', snap.get('fresh_count', '-'))))
    return {
        'version': status.get('version') or status.get('paper_version') or VERSION,
        'build': status.get('build') or BUILD_LABEL,
        'latest': latest,
        'fresh': fresh,
        'snapshot_id': status.get('snapshot_id') or snap.get('snapshot_id') or handoff.get('snapshot_id') or trace.get('snapshot_id') or '-',
        'status_age': _v561_age_from(status),
        'handoff_age': _v561_age_from(handoff),
        'trace_age': _v561_age_from(trace),
    }


def _v587_paper_spine_label() -> str:
    sp = _v587_status_spine()
    return f"{sp.get('version','-')} / latest {sp.get('latest','-')} / fresh {sp.get('fresh','-')} / snapshot {sp.get('snapshot_id','-')}"


def _v587_tick_distortion_reason(row: Dict[str, Any]) -> str:
    price = _v586_to_float(row.get('current_price') or row.get('price') or row.get('trade_price'))
    c1 = _v586_to_float(row.get('scanner_change_1m_pct')) or 0.0
    c3 = _v586_to_float(row.get('scanner_change_3m_pct')) or 0.0
    t = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    if price is not None and price <= 0.001 and (abs(c1) >= 10.0 or abs(c3) >= 10.0):
        return '초저가/틱단위 급등 왜곡 의심'
    if t in {'BTT','NFT'} and (abs(c1) >= 10.0 or abs(c3) >= 10.0):
        return '초저가/틱단위 급등 왜곡 의심'
    return ''


def _v587_candidate_stage_detail_for_hot(row: Dict[str, Any], idx: Optional[Dict[str, Dict[str, Any]]] = None) -> Tuple[str, str, str, str]:
    """hot-rank 발견 → strategy 최신 후보 매칭 → paper 상태를 한 줄로 남긴다.
    매수 판단은 바꾸지 않고, not_seen의 원인 범주만 표시한다.
    """
    ticker = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or ''
    tick_reason = _v587_tick_distortion_reason(row)
    if not ticker or not isinstance(idx, dict):
        reason = 'scanner 발견 / strategy 매칭확인 불가'
        if tick_reason: reason += ' / ' + tick_reason
        return '후보확인불가', reason, 'paper not_seen', ''
    r = idx.get(ticker)
    if not isinstance(r, dict):
        reason = 'scanner 발견 / strategy latest 후보 매칭 없음'
        if tick_reason: reason += ' / ' + tick_reason
        # 후보없음은 사라지는 상태가 아니라 복기 가능한 not_candidate 상태로 표시한다.
        return '후보없음(not_candidate)', reason, 'paper not_seen', ''

    st = str(r.get('candidate_grade') or r.get('s_stage') or r.get('stage') or r.get('grade') or '-').upper()
    if st not in {'S1', 'S2', 'S3', 'X'}:
        st = '-'
    block = _v514_first_text(r, (
        's1_block_reason', 'final_block_reason', 'block_reason', 'main_block_reason',
        'reject_reason', 'entry_block_reason', 'reason', 'candidate_reason',
        '막힘', 'block_reasons', 'reasons'
    ), limit=44)
    missing = _v514_first_text(r, (
        'missing_reason', 'missing_info', 'missing_tags', 'lack_reason', 'info_missing', '부족',
    ), limit=34)
    risk = _v514_first_text(r, (
        'risk_tags', 'risk_reason', 'structure_risk_tags', 'spike_guard_reasons', 'stale_reasons', '위험'
    ), limit=34)
    reason_parts = []
    if block: reason_parts.append(block)
    if risk: reason_parts.append('위험 ' + risk)
    if missing: reason_parts.append('부족 ' + missing)
    if tick_reason: reason_parts.append(tick_reason)
    reason = ' / '.join(reason_parts[:4])
    if st == 'S1':
        pstate = 'paper open대상'
    elif st in {'S2','S3'}:
        pstate = 'paper not_s1'
    elif st == 'X':
        pstate = 'paper 제외'
    else:
        pstate = 'paper not_candidate'
    seen = _v514_first_text(r, ('paper_state', 'paper_status', 'handoff_status', 'paper_trace_status'), limit=24)
    if seen:
        pstate = 'paper ' + seen
    strat = str(r.get('strategy_label') or r.get('strategy_key') or r.get('strategy') or '')
    return f'후보 {st}', reason, pstate, strat


def _format_hot_row(row: Dict[str, Any], stage_idx: Optional[Dict[str, Dict[str, Any]]] = None) -> str:  # type: ignore[override]
    t = normalize_ticker(row.get('ticker') or row.get('market') or row.get('symbol')) or '-'
    c1 = fnum(row.get('scanner_change_1m_pct'), default=0.0)
    c3 = fnum(row.get('scanner_change_3m_pct'), default=0.0)
    r1 = row.get('scanner_hot_rank_1m') or '-'
    r3 = row.get('scanner_hot_rank_3m') or '-'
    price = row.get('current_price') or row.get('price') or row.get('trade_price')
    stage, reason, pstate, strat = _v587_candidate_stage_detail_for_hot(row, stage_idx)
    base = f"{t} {fmt_price(price)} / 1m {c1:+.2f}% #{r1} · 3m {c3:+.2f}% #{r3} / {stage}"
    extras = []
    tl = _v514_time_label_from_row(row)
    if tl != '포착 -': extras.append(tl)
    if strat: extras.append(strat)
    if reason: extras.append('이유 ' + reason)
    if pstate: extras.append(pstate)
    return base + (' / ' + ' / '.join(extras[:5]) if extras else '')


_v587_base_notify_s1_decision_summary = notify_s1_decision_summary

def notify_s1_decision_summary(pick_stats: Dict[str, Any], opened_count: int = 0, closed_count: int = 0, ctrl: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    """v587: 기존 1시간 S1 요약 기능을 유지하되 paper label은 현재 status spine으로 표시한다."""
    # 원본 함수의 로직을 유지하기 위해 같은 bucket을 사용하되, 발송 직전 label만 바꾼다.
    # 원본 함수 내부가 send_message를 직접 호출하므로 여기서는 짧은 monkey-patch 방식으로 message text만 보정한다.
    original_send = globals().get('send_message')
    def _send_with_spine(text: str) -> Any:
        if isinstance(text, str) and 'paper S1 1시간' in text:
            text = re.sub(r'- paper: .*$', '- paper spine: ' + _v587_paper_spine_label(), text, flags=re.MULTILINE)
        return original_send(text) if callable(original_send) else None
    globals()['send_message'] = _send_with_spine
    try:
        return _v587_base_notify_s1_decision_summary(pick_stats, opened_count=opened_count, closed_count=closed_count, ctrl=ctrl)
    finally:
        globals()['send_message'] = original_send


_v587_base_notify_market_hot_summary = notify_market_hot_summary

def notify_market_hot_summary(ctrl: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    """v587: hot-rank 요약 기능은 유지하고, 마지막 paper label을 현재 paper spine으로 보정한다.
    _format_hot_row override가 scanner→strategy 매칭 상태를 함께 표시한다.
    """
    original_send = globals().get('send_message')
    def _send_with_spine(text: str) -> Any:
        if isinstance(text, str) and ('시장 hot-rank' in text or '강한 급등 감지' in text):
            text = re.sub(r'- paper: .*$', '- paper spine: ' + _v587_paper_spine_label(), text, flags=re.MULTILINE)
        return original_send(text) if callable(original_send) else None
    globals()['send_message'] = _send_with_spine
    try:
        return _v587_base_notify_market_hot_summary(ctrl)
    finally:
        globals()['send_message'] = original_send


def hot_summary_text() -> str:  # type: ignore[override]
    ctrl = load_control(); rows, age, meta = _load_hot_rank_rows(ctrl)
    stage_idx = _hot_candidate_stage_index()
    top_n = max(5, int(fnum(ctrl.get('notify_market_hot_rank_top_n'), default=5)))
    good = []
    for r in rows:
        c1 = fnum(r.get('scanner_change_1m_pct'), default=0.0); c3 = fnum(r.get('scanner_change_3m_pct'), default=0.0)
        r1 = fnum(r.get('scanner_hot_rank_1m'), default=9999.0); r3 = fnum(r.get('scanner_hot_rank_3m'), default=9999.0)
        if c1 >= 0.2 or c3 >= 0.4 or r1 <= top_n or r3 <= top_n:
            rr = dict(r); rr['_hot_score'] = _hot_row_score(rr); good.append(rr)
    good.sort(key=lambda x: fnum(x.get('_hot_score'), default=0.0), reverse=True)
    lines = [
        '🧭 시장 hot-rank 현재 요약 /hot_summary · v587 scanner→strategy 연결표',
        f"- cache age {age:.1f}s / row {meta.get('row_count','-') if isinstance(meta,dict) else '-'}",
        '- 매수 알림 아님 · 급등 발견→strategy 검토→paper 상태 확인용',
        '- not_seen은 매수누락 확정이 아니라 strategy latest row 매칭 없음 표시',
    ]
    for r in good[:max(5, top_n)]:
        lines.append('- ' + _format_hot_row(r, stage_idx))
    lines.append('- paper spine: ' + _v587_paper_spine_label())
    return '\n'.join(lines)


def paper_hourly_text() -> str:  # type: ignore[override]
    return '\n\n'.join([pstatus_text(), hot_summary_text(), candidate_summary_text()])



# =============================================================================
# paper_bot v0.210 / v588: OPEN 장부 canonical_entry_snapshot 본선화
# - 새 복기 기능을 또 붙이는 것이 아니라, OPEN 순간의 strategy canonical row를
#   paper OPEN row에 필수 snapshot으로 봉인한다.
# - CLOSED row는 OPEN row를 그대로 복사하므로 canonical_entry_snapshot을 보존한다.
# - trade_review는 알림/summary 구경로가 아니라 CLOSED row의 snapshot만 읽는다.
# - 전략 조건, S등급, 청산, 자동매수, BUY_READY, 기존 장부 삭제 없음.
# =============================================================================

def _v588_json_safe(obj: Any) -> Any:
    try:
        return json.loads(json.dumps(obj, ensure_ascii=False, default=str))
    except Exception:
        return {}


def _v588_first_nonempty(*vals: Any) -> Any:
    for v in vals:
        if v is None:
            continue
        if isinstance(v, str) and not v.strip():
            continue
        if isinstance(v, (list, tuple, dict)) and len(v) == 0:
            continue
        return v
    return None


def _v588_path(obj: Any, path: Tuple[str, ...]) -> Any:
    cur = obj
    for k in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(k)
    return cur


def _v588_paths(sources: List[Dict[str, Any]], *paths: Tuple[str, ...]) -> Any:
    for src in sources:
        if not isinstance(src, dict):
            continue
        for path in paths:
            v = _v588_path(src, path)
            if _v588_first_nonempty(v) is not None:
                return v
    return None


def _v588_first_dict(*vals: Any) -> Dict[str, Any]:
    for v in vals:
        if isinstance(v, dict) and v:
            return v
    return {}


def _v588_first_list(*vals: Any) -> List[Any]:
    for v in vals:
        if isinstance(v, list) and v:
            return v
        if isinstance(v, tuple) and v:
            return list(v)
    return []


def _v588_num_value(v: Any) -> Optional[float]:
    if v is None or v == '':
        return None
    try:
        return float(v)
    except Exception:
        return None


def _v588_fmt_pct(v: Any) -> str:
    x = _v588_num_value(v)
    return '-' if x is None else f"{x:+.2f}%"


def _v588_fmt_float(v: Any, nd: int = 2) -> str:
    x = _v588_num_value(v)
    return '-' if x is None else f"{x:.{nd}f}"


def _v588_metric_value(sources: List[Dict[str, Any]], keys: Tuple[str, ...]) -> Any:
    paths = []
    for k in keys:
        paths.extend([
            (k,),
            ('metrics', k),
            ('feature', k),
            ('orderflow', k),
            ('micro', k),
            ('execution_risk', k),
            ('freshness_map', k),
            ('entry_diagnostics', k),
        ])
    return _v588_paths(sources, *paths)


def _v588_build_canonical_entry_snapshot(ev: Dict[str, Any], pos: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    ev = ev if isinstance(ev, dict) else {}
    pos = pos if isinstance(pos, dict) else {}
    ctx = _v588_first_dict(
        pos.get('entry_context'), ev.get('entry_context'), ev.get('strategy_context'), ev.get('raw') if isinstance(ev.get('raw'), dict) else {}
    )
    raw = _v588_first_dict(pos.get('raw'), ev.get('raw'))
    diag = _v588_first_dict(pos.get('entry_diagnostics'), ev.get('paper_final_safety_diagnostics'), ev.get('entry_diagnostics'), ctx.get('entry_diagnostics'))
    cm = _v588_first_dict(
        pos.get('canonical_metric_row'), ev.get('canonical_metric_row'), ctx.get('canonical_metric_row'), diag.get('canonical_metric_row'), raw.get('canonical_metric_row') if isinstance(raw, dict) else {}
    )
    dec = _v588_first_dict(pos.get('canonical_entry_decision'), ev.get('canonical_entry_decision'), ctx.get('canonical_entry_decision'), diag.get('canonical_entry_decision'))
    sources = [pos, ev, diag, cm, ctx, raw]

    structure = _v588_first_dict(cm.get('structure'), diag.get('structure'), ctx.get('structure'))
    freshness = _v588_first_dict(cm.get('freshness_map'), diag.get('freshness_map'), ctx.get('freshness_map'))
    exec_risk = _v588_first_dict(cm.get('execution_risk'), diag.get('execution_risk'), ctx.get('execution_risk'))
    timing = _v588_first_dict(cm.get('timing_spine'), pos.get('entry_timing_spine'), diag.get('entry_timing_spine'), diag.get('entry_timing_trace'), ctx.get('entry_timing_spine'))
    levels = _v588_first_dict(cm.get('structure_levels'), pos.get('structure_levels'), diag.get('structure_levels'), ctx.get('structure_levels'))
    plan = _v588_first_dict(cm.get('entry_plan'), pos.get('entry_plan'), diag.get('entry_plan'), ctx.get('entry_plan'))
    rr = _v588_first_dict(cm.get('risk_reward'), pos.get('risk_reward'), diag.get('risk_reward'), ctx.get('risk_reward'))

    metrics = {
        'price_reaction_pct': _v588_metric_value(sources, ('price_reaction_pct','reaction_pct','reaction','price_reaction','response_pct','price_response_pct')),
        'buy_trade_ratio': _v588_metric_value(sources, ('buy_trade_ratio','buy_ratio','buy_strength','buy_aggr_ratio','buy_exec_ratio','buy_pressure_ratio')),
        'one_min_sustain': _v588_metric_value(sources, ('one_min_sustain','one_min_buy_sustain','buy_sustain_1m','sustain_1m','one_min_persist','one_min_persistence')),
        'spread_pct': _v588_metric_value(sources, ('spread_pct','orderbook_spread_pct','spread_rate_pct')),
        'slippage_pct': _v588_metric_value(sources, ('slippage_pct','expected_slippage_pct','est_slippage_pct')),
        'sell_pressure': _v588_metric_value(sources, ('sell_pressure','sell_pressure_score','ask_wall_pressure','sell_wall_pressure')),
        'flow_1m_pct': _v588_metric_value(sources, ('flow_1m_pct','change_1m_pct','rate_1m','return_1m_pct')),
        'flow_3m_pct': _v588_metric_value(sources, ('flow_3m_pct','change_3m_pct','rate_3m','return_3m_pct')),
        'flow_5m_pct': _v588_metric_value(sources, ('flow_5m_pct','change_5m_pct','rate_5m','return_5m_pct')),
        'flow_15m_pct': _v588_metric_value(sources, ('flow_15m_pct','change_15m_pct','rate_15m','return_15m_pct')),
    }
    ages = {
        'micro_age_sec': _v588_metric_value(sources, ('micro_age_sec','micro_age','micro_fresh_age_sec')),
        'orderflow_age_sec': _v588_metric_value(sources, ('orderflow_age_sec','orderflow_age','orderflow_fresh_age_sec')),
        'price_age_sec': _v588_metric_value(sources, ('price_age_sec','price_age','ticker_age_sec')),
        'feature_age_sec': _v588_metric_value(sources, ('feature_age_sec','feature_age')),
        'paper_age_sec': _v588_metric_value(sources, ('paper_age_sec','paper_fresh_age_sec')),
    }
    snapshot = {
        'schema': 'canonical_entry_snapshot_v588',
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'created_at': now_ts(),
        'created_at_text': iso_ts(),
        'event_id': pos.get('event_id') or pos.get('pos_id') or event_id(ev) if ev else pos.get('pos_id'),
        'ticker': normalize_ticker(pos.get('ticker') or ev.get('ticker') or ev.get('symbol') or ev.get('market')),
        'strategy': pos.get('strategy') or ev.get('strategy') or ev.get('strategy_key'),
        'strategy_key': pos.get('strategy_key') or ev.get('strategy_key') or ev.get('strategy'),
        'candidate_grade': pos.get('candidate_grade') or ev.get('candidate_grade') or ev.get('s_stage') or 'S1',
        'entry_price': pos.get('entry_price') or get_event_price(ev),
        'detected_price': pos.get('detected_price') or get_event_price(ev),
        'metrics': _v588_json_safe(metrics),
        'freshness': {
            'overall': freshness.get('overall') or freshness.get('state') or diag.get('fresh_state') or diag.get('freshness_state'),
            'ages': _v588_json_safe(ages),
            'raw': _v588_json_safe(freshness),
        },
        'structure': {
            'state': structure.get('state') or cm.get('structure_state') or diag.get('structure_state'),
            'tags': _v588_first_list(structure.get('tags'), cm.get('structure_tags'), diag.get('entry_structure_tags'), pos.get('entry_structure_tags')),
            'levels': _v588_json_safe(levels),
        },
        'execution_risk': {
            'state': exec_risk.get('state') or cm.get('execution_risk_state') or diag.get('execution_risk_state'),
            'tags': _v588_first_list(exec_risk.get('tags'), cm.get('execution_risk_tags'), diag.get('execution_risk_tags'), pos.get('execution_risk_tags')),
            'raw': _v588_json_safe(exec_risk),
        },
        'timing_spine': _v588_json_safe(timing),
        'entry_plan': _v588_json_safe(plan),
        'risk_reward': _v588_json_safe(rr),
        'decision': {
            'reference': cm.get('decision_reference') or diag.get('decision_reference') or pos.get('final_entry_label') or ev.get('final_entry_label'),
            'entry_reasons': _v588_first_list(cm.get('entry_reasons'), diag.get('entry_reasons'), pos.get('entry_condition_reasons')),
            'block_reasons': _v588_first_list(cm.get('block_reasons'), diag.get('block_reasons'), pos.get('block_reasons')),
            'confirm_signals': _v588_first_list(diag.get('confirm_signals'), pos.get('confirm_signals'), cm.get('confirm_signals')),
            'late_chase_flag': bool(_v588_first_nonempty(cm.get('late_chase_flag'), diag.get('late_chase_flag'), pos.get('late_chase_flag'), False)),
        },
        'paper_preopen': {
            'paper_final_safety_passed': bool(pos.get('paper_final_safety_passed') or ev.get('paper_final_safety_passed')),
            'diagnostics_schema': diag.get('schema') or diag.get('entry_decision_schema'),
            'canonical_entry_decision': _v588_json_safe(dec),
        },
        'source_snapshot': _v588_json_safe(_v588_first_dict(cm.get('source_snapshot'), diag.get('source_snapshot'), ctx.get('source_snapshot'))),
    }
    return _v588_json_safe(snapshot)


_v588_prev_open_position = open_position

def open_position(pos_id: str, ev: Dict[str, Any]) -> Dict[str, Any]:  # type: ignore[override]
    pos = _v588_prev_open_position(pos_id, ev)
    try:
        snap = _v588_build_canonical_entry_snapshot(ev, pos)
        pos['canonical_entry_snapshot'] = snap
        pos['canonical_entry_snapshot_schema'] = snap.get('schema')
        pos['canonical_entry_snapshot_version'] = VERSION
        # 호환: 기존 review가 canonical_metric_row만 찾는 경로도 살린다. 새 판단은 하지 않는다.
        if isinstance(snap.get('source_snapshot'), dict) and snap['source_snapshot']:
            pos['canonical_entry_source_snapshot'] = snap['source_snapshot']
    except Exception as exc:
        log_error('v588_open_canonical_entry_snapshot', exc)
    return pos


_v588_prev_update_position = update_position

def update_position(pos: Dict[str, Any], ctrl: Dict[str, Any]) -> Tuple[Dict[str, Any], Optional[Dict[str, Any]]]:  # type: ignore[override]
    try:
        if isinstance(pos, dict) and not isinstance(pos.get('canonical_entry_snapshot'), dict):
            pos['canonical_entry_snapshot'] = _v588_build_canonical_entry_snapshot(pos.get('raw') if isinstance(pos.get('raw'), dict) else {}, pos)
            pos['canonical_entry_snapshot_schema'] = 'canonical_entry_snapshot_v588_backfilled_open'
    except Exception as exc:
        log_error('v588_update_open_snapshot_backfill', exc)
    updated, closed = _v588_prev_update_position(pos, ctrl)
    try:
        if isinstance(closed, dict) and not isinstance(closed.get('canonical_entry_snapshot'), dict):
            closed['canonical_entry_snapshot'] = _v588_build_canonical_entry_snapshot(closed.get('raw') if isinstance(closed.get('raw'), dict) else {}, closed)
            closed['canonical_entry_snapshot_schema'] = 'canonical_entry_snapshot_v588_backfilled_closed'
        if isinstance(closed, dict):
            closed['closed_keeps_canonical_entry_snapshot'] = True
    except Exception as exc:
        log_error('v588_closed_snapshot_preserve', exc)
    return updated, closed


def _v588_snapshot_line(row: Dict[str, Any]) -> str:
    snap = row.get('canonical_entry_snapshot') if isinstance(row.get('canonical_entry_snapshot'), dict) else {}
    t = normalize_ticker(row.get('ticker') or (snap.get('ticker') if isinstance(snap, dict) else '')) or '-'
    pnl = _v588_fmt_pct(row.get('pnl_pct'))
    reason = str(row.get('exit_reason') or row.get('exit_rule') or '-')
    if not snap:
        return f"- {t}: {pnl} / {reason} / OPEN snapshot 없음(구 OPEN 또는 v588 전 장부)"
    m = snap.get('metrics') if isinstance(snap.get('metrics'), dict) else {}
    fr = snap.get('freshness') if isinstance(snap.get('freshness'), dict) else {}
    ages = fr.get('ages') if isinstance(fr.get('ages'), dict) else {}
    st = snap.get('structure') if isinstance(snap.get('structure'), dict) else {}
    er = snap.get('execution_risk') if isinstance(snap.get('execution_risk'), dict) else {}
    timing = snap.get('timing_spine') if isinstance(snap.get('timing_spine'), dict) else {}
    return (
        f"- {t}: {pnl} / {reason} / "
        f"반응 {_v588_fmt_pct(m.get('price_reaction_pct'))} · 매수 {_v588_fmt_float(m.get('buy_trade_ratio'))} · "
        f"1분 {_v588_fmt_float(m.get('one_min_sustain'))} · 스프 {_v588_fmt_pct(m.get('spread_pct'))} · "
        f"미끄 {_v588_fmt_pct(m.get('slippage_pct'))} / fresh {fr.get('overall') or '-'} "
        f"micro { _v588_fmt_float(ages.get('micro_age_sec'), 1) }s · orderflow { _v588_fmt_float(ages.get('orderflow_age_sec'), 1) }s / "
        f"구조 {st.get('state') or '-'} / 실행 {er.get('state') or '-'} / "
        f"늦추 { 'Y' if (snap.get('decision') or {}).get('late_chase_flag') else 'N' } / "
        f"first→S1 { _v588_fmt_float(_v588_first_nonempty(timing.get('first_to_s1_delay_sec'), timing.get('first_to_now_delay_sec')), 0) }s"
    )


def _v588_entry_snapshot_review_block(rows: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    with_snap = [r for r in rows if isinstance(r.get('canonical_entry_snapshot'), dict)]
    fast = [r for r in rows if str(r.get('exit_reason') or r.get('exit_rule') or '').find('fast_fail') >= 0]
    show = (fast + [r for r in reversed(rows) if r not in fast])[:5]
    c_struct: Counter = Counter()
    c_exec: Counter = Counter()
    c_fresh: Counter = Counter()
    for r in with_snap:
        s = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else {}
        st = s.get('structure') if isinstance(s.get('structure'), dict) else {}
        er = s.get('execution_risk') if isinstance(s.get('execution_risk'), dict) else {}
        fr = s.get('freshness') if isinstance(s.get('freshness'), dict) else {}
        if st.get('state'): c_struct[str(st.get('state'))] += 1
        if er.get('state'): c_exec[str(er.get('state'))] += 1
        if fr.get('overall'): c_fresh[str(fr.get('overall'))] += 1
    data = {
        'schema': 'paper_trade_review_open_snapshot_v588',
        'row_count': len(rows),
        'with_canonical_entry_snapshot': len(with_snap),
        'fast_fail_count': len(fast),
        'structure_top': ' / '.join(f'{k} {v}' for k, v in c_struct.most_common(5)) if c_struct else '-',
        'execution_top': ' / '.join(f'{k} {v}' for k, v in c_exec.most_common(5)) if c_exec else '-',
        'fresh_top': ' / '.join(f'{k} {v}' for k, v in c_fresh.most_common(5)) if c_fresh else '-',
    }
    lines = ['[OPEN snapshot 복기 · v588]']
    if not rows:
        lines.append('- 오늘 CLOSED 없음')
    else:
        lines.append(f"- snapshot 보유 {len(with_snap)}/{len(rows)}개 / 빠른실패 {len(fast)}개")
        lines.append(f"- 구조 TOP: {data['structure_top']}")
        lines.append(f"- fresh TOP: {data['fresh_top']}")
        lines.append(f"- 실행위험 TOP: {data['execution_top']}")
        for r in show:
            lines.append(_v588_snapshot_line(r))
    return lines, data


_v588_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v588_prev_write_score_cache(status)
    try:
        obj = load_json(FILES['trade_review'], {}) or {}
        if not isinstance(obj, dict):
            return
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
        today_rows = _v557_filter_today(rows, now_ts())
        lines, data = _v588_entry_snapshot_review_block(today_rows)
        summary = str(obj.get('summary_text') or '')
        block = '\n'.join(lines)
        pattern = r"\n?\[OPEN snapshot 복기 · v588\][\s\S]*?(?=\n\[[^\n]+\]|\Z)"
        if '[OPEN snapshot 복기 · v588]' in summary:
            summary = re.sub(pattern, '\n' + block, summary).strip()
        else:
            summary = (summary.rstrip() + '\n\n' + block).strip() if summary else block
        obj['summary_text'] = summary
        obj['open_entry_snapshot_review_v588'] = data
        obj['schema'] = 'paper_trade_review_cache_v588_open_entry_snapshot'
        obj['version'] = VERSION
        obj['paper_version'] = VERSION
        obj['build'] = BUILD_LABEL
        obj['writer'] = 'v588_canonical_entry_snapshot_ledger'
        save_json(FILES['trade_review'], obj)
    except Exception as exc:
        log_error('write_trade_review_cache_v588', exc)



# =============================================================================
# paper_bot v0.212 / v590: paper 복기 writer/reader 단일 spine
# =============================================================================
# 목적:
# - trade_review cache가 v569/v578/v588 writer 사이에서 덮이는 문제를 끊는다.
# - CLOSED tail을 한 번 읽고, 최고수익 반납/빠른실패/후반손실/OPEN snapshot 복기를
#   paper_review_spine_v589 하나에 합쳐 저장한다.
# - 기능은 유지하되 구 writer/reader가 마지막에 이기지 못하게 모든 legacy review writer를 이 본선으로 연결한다.

V589_REVIEW_SCHEMA = 'paper_review_spine_v590'


def _v589_stat_text(rows: List[Dict[str, Any]]) -> str:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if not rows:
        return '표본부족'
    st = _score_stat(rows)
    n = int(st.get('n', 0) or 0)
    w = int(st.get('wins', 0) or 0)
    l = int(st.get('losses', max(0, n-w)) or 0)
    return f"{n}전 {w}승 {l}패 / 승률 {fnum(st.get('win_rate'), default=0.0):.1f}% / 합산 {fnum(st.get('total'), default=0.0):+.2f}% / 평균 {fnum(st.get('avg'), default=0.0):+.2f}%"


def _v589_primary_strategy(rows: List[Dict[str, Any]]) -> str:
    c: Counter = Counter()
    for r in rows or []:
        if isinstance(r, dict):
            c[_strategy_key(r)] += 1
    return c.most_common(1)[0][0] if c else '-'


def _v589_split_early_late(rows: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    rows = [r for r in (rows or []) if isinstance(r, dict)]
    if len(rows) < 2:
        return [], rows
    mid = max(1, len(rows)//2)
    return rows[:mid], rows[mid:]


def _v589_loss_reason_counter(rows: List[Dict[str, Any]]) -> Counter:
    c: Counter = Counter()
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        pnl = fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0)
        if pnl > 0:
            continue
        exit_reason = str(r.get('exit_reason') or r.get('exit_rule') or '')
        if 'fast_fail' in exit_reason:
            c['복기:빠른실패 정리 작동'] += 1
        if 'stop_loss' in exit_reason:
            c['청산:stop_loss'] += 1
        snap = r.get('canonical_entry_snapshot') if isinstance(r.get('canonical_entry_snapshot'), dict) else {}
        decision = snap.get('decision') if isinstance(snap.get('decision'), dict) else {}
        timing = snap.get('timing_spine') if isinstance(snap.get('timing_spine'), dict) else {}
        fresh = snap.get('freshness') if isinstance(snap.get('freshness'), dict) else {}
        if bool(r.get('late_chase_flag') or decision.get('late_chase_flag') or timing.get('late_chase_flag')):
            c['타이밍:늦은추격'] += 1
        # snapshot이 없거나 신선도 원천 age가 없으면 과거 장부/구 writer 영향으로 숫자 확인이 부족한 상태로 표시한다.
        ages = fresh.get('ages') if isinstance(fresh.get('ages'), dict) else {}
        if not snap or not ages:
            c['신선도:문구만있음_숫자확인필요'] += 1
        elif any(fnum(ages.get(k), default=0.0) > 12.0 for k in ('micro_age_sec','orderflow_age_sec','price_age_sec','feature_age_sec')):
            c['신선도:핵심정보나이과다'] += 1
    return c


def _v589_counter_text(c: Counter, limit: int = 6) -> str:
    return ' / '.join(f'{k} {v}' for k, v in c.most_common(limit)) if c else '-'


def _v589_peak_section(rows: List[Dict[str, Any]], late: List[Dict[str, Any]], last16: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, Any]]:
    all_peak = _v578_peak_stats(rows)
    late_peak = _v578_peak_stats(late)
    last16_peak = _v578_peak_stats(last16)
    cases = [_v578_giveback_case(r) for r in rows]
    top_cases = sorted(cases, key=lambda x: fnum(x.get('giveback_pct'), default=0.0), reverse=True)
    floor_cases = [c for c in cases if c.get('virtual_floor_pct') is not None and fnum(c.get('pnl_pct'), default=0.0) < fnum(c.get('virtual_floor_pct'), default=999.0)]
    lines = [
        '[최고수익 반납]',
        f"- 전체: {_v578_short_stat_line(all_peak)}",
        f"- 후반: {_v578_short_stat_line(late_peak)}",
        f"- 최근16: {_v578_short_stat_line(last16_peak)}",
        '',
        '[수익 돌려준 상위]',
    ]
    lines += ([_v578_case_line(c) for c in top_cases[:5]] or ['- 표본부족'])
    lines += [
        '',
        '[가상 보호계단 참고 · 청산 변경 아님]',
        '- 기준 예시: 최고 +0.70%→최소 +0.30%, 최고 +1.00%→최소 +0.55%, 최고 +1.30%→최소 +0.80%',
        f"- 보호계단보다 낮게 끝난 후보: {len(floor_cases)}개",
    ]
    lines += ([_v578_case_line(c) for c in floor_cases[:5]] or ['- 해당 없음'])
    return lines, {
        'overall_peak_giveback': all_peak,
        'late_peak_giveback': late_peak,
        'last16_peak_giveback': last16_peak,
        'top_giveback_cases': top_cases[:10],
        'below_virtual_floor_cases': floor_cases[:10],
    }


def _v589_build_paper_review_spine(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
    today_rows = _v557_filter_today(rows, nowv)
    primary = _v589_primary_strategy(today_rows)
    primary_rows = [r for r in today_rows if _strategy_key(r) == primary] if primary != '-' else today_rows
    early, late = _v589_split_early_late(primary_rows)
    last16 = primary_rows[-16:]

    peak_lines, peak_data = _v589_peak_section(primary_rows, late, last16)
    canon_lines, canon_data = _v584_canonical_review_block(primary_rows)
    snap_lines, snap_data = _v588_entry_snapshot_review_block(primary_rows)

    late_losses = [r for r in late if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) <= 0]
    last16_losses = [r for r in last16 if fnum(r.get('pnl_pct'), r.get('profit_pct'), default=0.0) <= 0]
    late_loss_counter = _v589_loss_reason_counter(late_losses)
    last16_loss_counter = _v589_loss_reason_counter(last16_losses)

    summary_lines = [
        '📉 복기 /trade_review · v590 paper review spine',
        '- 기준: paper_bot CLOSED tail + OPEN canonical_entry_snapshot + score cache 보조. 조건·청산 재계산 없음.',
        f'- 범위: 오늘 CLOSED {len(today_rows)}개 / 주분석 전략 {primary} {len(primary_rows)}개',
        '',
        '[성과 흐름]',
        f'- 전체: {_v589_stat_text(primary_rows)}',
        f'- 초반: {_v589_stat_text(early)}',
        f'- 후반: {_v589_stat_text(late)}',
        f'- 최근16: {_v589_stat_text(last16)}',
        '',
    ]
    summary_lines += peak_lines
    summary_lines += [
        '',
        '[후반 손실 원인 참고]',
        f"- 후반 손실 {len(late_losses)}개: {_v589_counter_text(late_loss_counter)}",
        f"- 최근16 손실 {len(last16_losses)}개: {_v589_counter_text(last16_loss_counter)}",
        '- 이 cache는 복기용이다. 조건/S등급/청산/장부는 변경하지 않는다.',
        '',
    ]
    summary_lines += canon_lines
    summary_lines += ['', *snap_lines]

    obj = {
        'schema': V589_REVIEW_SCHEMA,
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v590_paper_review_spine_single_writer',
        'source': 'paper_bot_closed_tail_cache_only',
        'updated_at': nowv,
        'updated_at_text': iso_ts(nowv),
        'summary_text': '\n'.join(summary_lines).strip(),
        'status_open_count': (status or {}).get('open_count') if isinstance(status, dict) else None,
        'today_closed_count': len(today_rows),
        'primary_strategy': primary,
        'primary_rows_count': len(primary_rows),
        'performance': {
            'overall': _score_stat(primary_rows),
            'early': _score_stat(early),
            'late': _score_stat(late),
            'last16': _score_stat(last16),
        },
        'peak_giveback': peak_data,
        'late_loss_reason_top': dict(late_loss_counter.most_common(10)),
        'last16_loss_reason_top': dict(last16_loss_counter.most_common(10)),
        'canonical_metric_row_review': canon_data,
        'open_entry_snapshot_review_v588': snap_data,
        'spine_policy': 'single paper review writer; legacy v569/v570/v572/v578/v588/v589 writers routed here',
    }
    return obj


def write_paper_review_spine_cache_v589(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        save_json(FILES['trade_review'], _v589_build_paper_review_spine(status))
    except Exception as exc:
        log_error('write_paper_review_spine_cache_v589', exc)


# Legacy review writer names are kept for compatibility, but all now route to one spine.
def write_trade_review_cache_v569(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


def write_trade_review_cache_v570(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


def write_trade_review_cache_v572(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


def write_trade_review_cache_v578(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


# v590 hard lock: any legacy-named review writer call is forced to the v590 spine.
def write_trade_review_cache_v588(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)

def write_trade_review_cache_v589(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v589(status)


_v589_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    # Score cache 기능은 그대로 유지하고, 마지막에 review spine을 반드시 v589 단일본으로 덮는다.
    _v589_prev_write_score_cache(status)
    write_paper_review_spine_cache_v589(status)

# v584 final entrypoint. The file deliberately has one runtime entrypoint at the end.


# =============================================================================
# paper_bot v0.213 / v591: review spine live-cycle hard lock
# =============================================================================
# 목적:
# - v590에서 main reader는 잠겼지만 live paper loop가 v590 spine을 즉시 쓰지 못한 문제 차단.
# - score/write_status/run_cycle 어디로 지나가도 마지막에 paper_review_spine_v591을 직접 저장한다.
# - 새 복기 기능 추가가 아니라 CLOSED 복기 cache writer 위치를 live 본선에 고정한다.
V591_REVIEW_SCHEMA = 'paper_review_spine_v591'


def _v591_build_paper_review_spine(status: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    try:
        obj = _v589_build_paper_review_spine(status) if '_v589_build_paper_review_spine' in globals() else {}
        if not isinstance(obj, dict):
            obj = {}
    except Exception as exc:
        log_error('v591_build_base_spine', exc)
        obj = {}
    # fallback minimal object if prior builder failed
    if not obj:
        rows = [r for r in read_jsonl_tail(FILES['closed'], 1000) if isinstance(r, dict)]
        today_rows = _v557_filter_today(rows, now_ts()) if '_v557_filter_today' in globals() else rows
        obj = {
            'summary_text': '\n'.join([
                '📉 복기 /trade_review · v591 paper review spine',
                f'- 기준: paper CLOSED tail + OPEN canonical_entry_snapshot 단일 spine',
                f'- 오늘 CLOSED {len(today_rows)}개',
                '[판독]',
                '- v591 live-cycle writer가 생성한 최소 spine입니다.',
            ]),
            'today_closed_count': len(today_rows),
        }
    txt = str(obj.get('summary_text') or '').strip()
    if txt:
        # title/schema label normalize
        txt = re.sub(r'📉 복기 /trade_review · v\d+[^\n]*', '📉 복기 /trade_review · v591 paper review spine', txt, count=1)
        txt = txt.replace('v590 paper review spine', 'v591 paper review spine')
        if '📉 복기 /trade_review · v591 paper review spine' not in txt.splitlines()[0]:
            txt = '📉 복기 /trade_review · v591 paper review spine\n' + txt
    else:
        txt = '📉 복기 /trade_review · v591 paper review spine\n- summary_text 준비 중'
    obj.update({
        'schema': V591_REVIEW_SCHEMA,
        'version': VERSION,
        'paper_version': VERSION,
        'build': BUILD_LABEL,
        'writer': 'v591_live_cycle_review_spine_writer',
        'source': 'paper_bot_closed_tail_cache_only_live_cycle',
        'updated_at': now_ts(),
        'updated_at_text': iso_ts(),
        'summary_text': txt,
        'spine_policy': 'v594 stable restore: exact v591 successful live-cycle writer restored; schema kept as paper_review_spine_v591 for main reader compatibility; no v592/v593 detail builder',
    })
    return obj


def write_paper_review_spine_cache_v591(status: Optional[Dict[str, Any]] = None) -> None:
    try:
        save_json(FILES['trade_review'], _v591_build_paper_review_spine(status))
    except Exception as exc:
        log_error('write_paper_review_spine_cache_v591', exc)


# Legacy review writer names are compatibility aliases only; all route to v591.
def write_trade_review_cache_v569(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v570(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v572(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v578(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v588(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v589(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


def write_trade_review_cache_v590(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    write_paper_review_spine_cache_v591(status)


_v591_prev_write_score_cache = write_score_cache

def write_score_cache(status: Optional[Dict[str, Any]] = None) -> None:  # type: ignore[override]
    _v591_prev_write_score_cache(status)
    write_paper_review_spine_cache_v591(status)


_v591_prev_write_status = write_status

def write_status(status: Dict[str, Any]) -> None:  # type: ignore[override]
    _v591_prev_write_status(status)
    write_paper_review_spine_cache_v591(status)


_v591_prev_run_cycle = run_cycle

def run_cycle() -> Dict[str, Any]:  # type: ignore[override]
    st = _v591_prev_run_cycle()
    write_paper_review_spine_cache_v591(st if isinstance(st, dict) else None)
    return st

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--once":
        print(json.dumps(run_cycle(), ensure_ascii=False, indent=2))
    else:
        main()
