v2088 trigger 사건 exact key 자료연결 수리

- 새 trigger 사건이 생긴 경우 Strategy 원천 decision key를 S1/Paper/보류/기존 후보품질 Shadow까지 같은 exact key로 전달합니다.
- 기존 후보품질 Shadow key 형식인 trigger_decision:<decision key>로만 연결합니다.
- 사건 전 S2/S3 후보는 정상 대기로 분리하고, 실제 key 누락·불일치만 SOURCE_MISSING으로 표시합니다.
- 보류 후보를 ticker/시간근접으로 추정하지 않습니다.
- TOP10/20/30/50 snapshot이 오래되면 STALE로 표시하고 현재 판단에 사용하지 않습니다.
- 후보 삭제·등급·순위·v2086 조건·구조선·trigger/invalid/target·기존 OPEN·청산은 변경하지 않습니다.
- 자동매수 OFF입니다.

서버 최소 검수:
Guard: /grelease_verify
Main: /version_score, /shadow_all, /weak_hold_shadow, /errorlog
