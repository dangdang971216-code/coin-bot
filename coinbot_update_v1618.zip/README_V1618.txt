v1618 canonical candidate event spine + legacy archive. No trading rule change. Auto-buy OFF.
