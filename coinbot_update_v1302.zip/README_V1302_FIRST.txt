코인봇 v1302 · v1211 클린 재기반

목적:
- 후보/진입/trigger/invalid/target/RR은 v1211 본선으로 되돌림.
- v1212 동적 구조선, v1215 동적 자료연결, v1257/v1270/v1291/v1301 후보 관련 계층은 이식하지 않음.
- 운영수리만 선별 이식: 0전 성과 anchor, Paper 0전 초기화 명령, 최신 Guard 검증/디스크·runtime 확인.

새 수동 명령:
- Paper봇 /pzero_reset_v1302 : 기존 Paper OPEN 전체정리 + /version_score 0전 anchor 재시작.
- 자동 실행 아님. 사용자가 직접 명령할 때만 작동.

금지:
- 자동매수 ON 금지.
- 원장 삭제·축소·재작성 금지.
- 후보 기준 완화/강제 BUY_READY 금지.
