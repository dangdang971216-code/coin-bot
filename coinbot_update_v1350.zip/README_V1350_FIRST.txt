v1350 runtime deploy alignment. Apply /gupgrade_bundle, then /grelease_verify. No trading rule changes. Auto-buy OFF.
