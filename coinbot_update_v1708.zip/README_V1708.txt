v1708 guard disk command bind + version_score recursion fix. No trading criteria change. Auto-buy OFF.
