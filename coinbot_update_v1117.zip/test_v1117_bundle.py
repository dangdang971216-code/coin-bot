#!/usr/bin/env python3
from pathlib import Path
import ast, importlib.util, tempfile, time, json, hashlib, os
os.environ.setdefault('GUARD_BOT_TOKEN','test-token')
os.environ.setdefault('GUARD_CHAT_ID','1')
os.environ.setdefault('BOT_DIR',str(Path(tempfile.gettempdir())/'coinbot_v1117_guard_test'))
ROOT=Path(__file__).resolve().parent
PAPER=ROOT/'paper_bot_v1.017.py'
GUARD=ROOT/'backga_guard_bot_v2_5_166.py'

def load(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def fn_dump(path,names):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    out={}
    for n in tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names:
            out.setdefault(n.name,[]).append(ast.dump(n,include_attributes=False))
    return out

assert compile(PAPER.read_text(encoding='utf-8'),str(PAPER),'exec')
assert compile(GUARD.read_text(encoding='utf-8'),str(GUARD),'exec')
p=load(PAPER,'paper_v1117_test')
g=load(GUARD,'guard_v1117_test')
assert p.VERSION=='paper_bot_v1.017'
assert 'v1117' in g.VERSION

# Paper wrapper semantic-idle proof without touching real ledgers.
with tempfile.TemporaryDirectory() as td:
    t=Path(td); snap=t/'canonical_performance_snapshot_v987.json'; snap.write_text('{}',encoding='utf-8')
    p.PERFORMANCE_SNAPSHOT_V987=snap
    p._V1082_PERF_META={'snapshot_id':'perf-test','generated_at':time.time()-700}
    p._PERFORMANCE_NEXT_BOUNDARY_TS=time.time()+3600
    p._canonical_performance_source_signature=lambda now=None: ('closed',1,2,3,'decision','digest')
    p._v1092_open_membership_digest=lambda positions: 'open-digest'
    expected=('closed',1,2,3,'decision','digest','open_membership_digest_v1092','open-digest')
    p._PERFORMANCE_LAST_SIGNATURE=expected
    p._V1092_PERF_STATS['last_mode']='noop'
    p._V1117_PREV_WRITE_SCORE_CACHE=lambda status=None,force=False,open_positions=None: dict(p._V1082_PERF_META)
    p.write_score_cache({},open_positions={})
    hb=p._V1117_PERF_SEMANTIC_HEARTBEAT
    assert hb['semantic_current'] is True and hb['event_driven_idle'] is True
    assert hb['canonical_snapshot_rewrite_for_heartbeat'] is False
    captured={}
    p._V1117_PREV_WRITE_STATUS=lambda obj: captured.update(obj)
    p.write_status({})
    assert captured['paper_performance_semantic_heartbeat_v1117']['semantic_current'] is True

fresh={'paper_performance_semantic_heartbeat_v1117':{
    'last_check_at':time.time(),'last_mode':'noop','semantic_current':True,'source_signature_match':True,
    'boundary_due_after_check':False,'snapshot_exists':True,'event_driven_idle':True,'snapshot_id':'perf-test',
    'canonical_snapshot_rewrite_for_heartbeat':False}}
root=g._ops_performance_root_cause_v1117(fresh,time.time())
assert root['diagnosis_state']=='PROVEN_EVENT_DRIVEN_IDLE'
stale=json.loads(json.dumps(fresh)); stale['paper_performance_semantic_heartbeat_v1117']['last_check_at']=time.time()-200
assert g._ops_performance_root_cause_v1117(stale,time.time())['diagnosis_state']=='CHECK_PERFORMANCE_WRITER'
changed=json.loads(json.dumps(fresh)); changed['paper_performance_semantic_heartbeat_v1117']['source_signature_match']=False
assert g._ops_performance_root_cause_v1117(changed,time.time())['diagnosis_state']=='CHECK_PERFORMANCE_WRITER'

# All pre-existing top-level function bodies are byte-for-byte AST-equivalent to v1116.
# Only the two v1117 observability wrappers are excluded from this digest.
tree=ast.parse(PAPER.read_text(encoding='utf-8'))
parts=[]
for node in tree.body:
    if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name not in {'write_score_cache__v1117','write_status__v1117'}:
        parts.append(node.name+'\0'+ast.dump(node,include_attributes=False))
core_digest=hashlib.sha256('\n'.join(parts).encode()).hexdigest()
assert core_digest=='245c16cb454fcf670bde5ec70ad13f1067c07589df472525db0c701bc9642855'

# Integrated Guard path must normalize only performance→main with proven heartbeat.
gsrc=GUARD.read_text(encoding='utf-8')
assert "src=='performance' and dst=='main'" in gsrc
assert "performance_root_v1117.get('diagnosis_state')=='PROVEN_EVENT_DRIVEN_IDLE'" in gsrc
assert 'do not force large canonical snapshot rewrites merely to refresh mtime' in gsrc

print(json.dumps({'ok':True,'paper_version':p.VERSION,'guard_version':g.VERSION,'semantic_idle':root['diagnosis_state'],'core_ast_digest':core_digest},ensure_ascii=False))
