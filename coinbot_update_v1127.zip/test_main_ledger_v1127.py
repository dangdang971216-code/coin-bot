#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, pathlib, shutil, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
base=pathlib.Path(tempfile.mkdtemp(prefix='coinbot_main_ledger_v1127_'))
module_copy=base/'coinbot_main_v2_13_1099.py'; shutil.copy2(ROOT/'coinbot_main_v2_13_1099.py',module_copy)
spec=importlib.util.spec_from_file_location('main_ledger_v1127',module_copy)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
change_path=mod._v870_path('change'); issue_path=mod._v870_path('issue_event')
change_text=change_path.read_text(encoding='utf-8')
assert 'v1126-quality-horizon-identity-writer-truth-server-001' in change_text
assert 'v1127-quality-shadow-p0-closeout-001' in change_text
assert 'QUALITY-SHADOW-P0-1127' in issue_path.read_text(encoding='utf-8')
# Create fresh runtime proof and invoke renderer finalizer.
(mod.BASE_DIR/'clean_quality_shadow_status_v1125.json').write_text(json.dumps({
 'version':'review_worker_v1.005','updated_ts':time.time(),'identity_owner_field_v1126':'trigger_occurrence_v1037.decision_key',
 'identity_owner_missing_this_cycle_v1126':2,'missing_owner_reason_counts_v1127':{'NO_TRIGGER_OBJECT':2,'TRIGGER_OBJECT_NO_DECISION_KEY':0,'OWNER_VALUE_INVALID':0},
 'storage_truth_v1127':{'active_state_schema':'quality_shadow_state_v1127_packed_active','terminal_rows_in_active_state':0,'final_ledger_append_only':True,'active_unfinished_rows':2,'state_bytes':1000,'final_ledger_file':'quality_shadow_result_ledger_v1125.jsonl','aggregate_file':'clean_quality_eye_aggregate_v1125.json'}
}),encoding='utf-8')
(mod.BASE_DIR/'clean_quality_eye_status_v1125.json').write_text(json.dumps({'updated_ts':time.time(),'comparison_contract':'10m completed rows provisional; 60m completed comparison-ready final','state':'COLLECTING'}),encoding='utf-8')
mod.render_quality_shadow_text()
change_text2=change_path.read_text(encoding='utf-8')
assert 'v1127-quality-shadow-p0-server-proof-001' in change_text2
assert (mod.BASE_DIR/'runtime'/'quality_shadow_p0_v1127.server_done').exists()
print('PASS canonical change/issue seed and same-version server proof closeout')
