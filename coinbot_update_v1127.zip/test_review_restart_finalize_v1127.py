#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, pathlib, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
base=pathlib.Path(tempfile.mkdtemp(prefix='coinbot_review_restart_v1127_'))
os.environ['TRADING_BOT_DIR']=str(base)
os.environ['QUALITY_SHADOW_CHECKPOINT_SEC']='120'
def load(name):
    spec=importlib.util.spec_from_file_location(name,ROOT/'review_worker_v1.005.py')
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod
mod=load('review_restart_a')
now=time.time()
row={'ticker':'ABC','entry_build_key':'e1','direct_decision_key':'d1','trigger_occurrence_candidate_key_v1037':'c1','trigger_occurrence_v1037':{'decision_key':'plan1','base_plan_decision_key':'plan1','kind':'INITIAL_ABOVE','sequence':0},'current_price':100.0}
status,rows=mod.update_quality_shadow(now,{'ABC':{'current_price':100.0}}, {}, [row], {})
assert status['new_records_this_cycle']==1
state=json.loads((base/'clean_quality_shadow_state_v1125.json').read_text())
assert state['schema']=='quality_shadow_state_v1127_packed_active'
assert state['active_unfinished_rows_v1127']==1
# Fresh process loads packed state and finalizes after 60m without duplicating owner.
mod2=load('review_restart_b')
status2,rows2=mod2.update_quality_shadow(now+3605,{'ABC':{'current_price':101.0}}, {}, [row], {})
assert status2['new_records_this_cycle']==0
assert status2['finalized_this_cycle']==1
assert status2['storage_truth_v1127']['terminal_rows_in_active_state']==0
assert status2['storage_truth_v1127']['active_unfinished_rows']==0
ledger=(base/'quality_shadow_result_ledger_v1125.jsonl').read_text().strip().splitlines()
assert len(ledger)==1
state2=json.loads((base/'clean_quality_shadow_state_v1125.json').read_text())
assert state2['active_unfinished_rows_v1127']==0 and state2['terminal_rows_in_state_v1127']==0
print('PASS packed restart continuity and immediate terminal offload')
