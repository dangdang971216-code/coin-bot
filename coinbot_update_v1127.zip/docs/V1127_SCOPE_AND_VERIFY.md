# v1127 후보품질 P0 묶음 마감

## 원인
- v1126은 horizon/identity 핵심 판정은 정상화했지만, missing owner를 한 숫자로만 표시했다.
- 진행 중 state는 반복되는 dict key와 완료 row grace를 포함해 파일이 계속 커졌다.
- Main 제목과 expected component identity가 이전 값으로 남았다.
- v1126/v1127 change/issue 증거가 bundle 문서에만 있고 canonical live ledger append가 없었다.

## 본선
- Review canonical owner 분류 → unfinished-only packed active state → final append-only ledger + cumulative aggregate.
- Main은 같은 status를 읽고 owner/missing/storage truth를 표시한다.
- Main canonical work-ledger writer가 v1126 PARTIAL, v1127 CHECK를 append하고, 서버 조건 충족 시 같은 버전 server-proof DONE을 append한다.

## 삭제한 구 경로
- 완료 row를 active state에 5분 더 남기는 경로.
- active state에서 동일 필드명을 row마다 반복하는 dict snapshot.
- 모든 owner 누락을 MISSING_OWNER_KEY 한 값으로만 보여주는 경로.
- `/quality_shadow`의 v1125 고정 제목.
- 실제 canonical ledger가 아닌 docs-only change evidence.

## 변경하지 않은 영역
- 실제 quality Gate/rank 공식.
- Strategy/Paper selector와 entry/exit.
- OPEN 30 / cycle 3.
- trigger/invalid/target/slippage/cost 계약.
- OPEN/CLOSED/trade_log/decision/exact/change/issue 원장 원본.
- 자동매수 OFF.
