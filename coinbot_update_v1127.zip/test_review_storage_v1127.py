#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, pathlib, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent
base=pathlib.Path(tempfile.mkdtemp(prefix='coinbot_review_storage_v1127_'))
os.environ['TRADING_BOT_DIR']=str(base)
os.environ['QUALITY_SHADOW_CHECKPOINT_SEC']='120'
spec=importlib.util.spec_from_file_location('review_storage_v1127',ROOT/'review_worker_v1.005.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
now=time.time()
variants={k:{'selected':True,'score':70.1,'block_reasons':[]} for k in ('safety_only','current_quality','improved_quality')}
records={}
for i in range(100):
    key=f'trigger_decision:plan{i}'
    records[key]={'quality_event_key_v946':key,'identity_mode_v946':'trigger_occurrence_v1037.decision_key','identity_owner_value_v1126':f'plan{i}','identity_event_class_v1126':'NEW_PLAN','ticker':f'T{i%20}','first_seen_ts':now-i,'first_price':100.0,'hard_pass_at_first':True,'cohort':'pass','max_pct':0.2,'min_pct':-0.1,'last_price':100.1,'last_seen_ts':now,'next_review_due_ts_v1011':now+30,'initial_metrics':{'spread_pct':0.1,'confirmed_slippage_pct':0.2,'risk_reward':2.0},'samples':{'1m':{'ts':now,'price':100.1,'pct':0.1,'max_pct':0.2,'min_pct':-0.1,'giveback_pct':0.1}},'policy_variants_v1120':variants,'final_appended':False}
payload=mod._quality_state_payload_v1127(records,now,1,0,{})
assert payload['schema']=='quality_shadow_state_v1127_packed_active'
assert payload['terminal_rows_in_state_v1127']==0 and len(payload['records_packed_v1127'])==100
packed=json.dumps(payload,ensure_ascii=False,separators=(',',':')).encode()
legacy=json.dumps({'records':{k:mod._quality_active_compact_v1007(v) for k,v in records.items()}},ensure_ascii=False,separators=(',',':')).encode()
assert len(packed)<len(legacy)*0.78,(len(packed),len(legacy))
unpacked,meta=mod._quality_state_records_from_obj_v1127(payload)
assert meta['packed'] is True and len(unpacked)==100
assert unpacked['trigger_decision:plan1']['identity_owner_value_v1126']=='plan1'
# Completed rows are never packed back into active state.
records['trigger_decision:plan1']['final_appended']=True
payload2=mod._quality_state_payload_v1127(records,now,2,1,{})
assert len(payload2['records_packed_v1127'])==99
print(f"PASS packed active state: {len(legacy)} -> {len(packed)} bytes; completed rows excluded")
