#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, pathlib, tempfile, time, shutil
ROOT=pathlib.Path(__file__).resolve().parent
base=pathlib.Path(tempfile.mkdtemp(prefix='coinbot_main_command_v1127_'))
module_copy=base/'coinbot_main_v2_13_1099.py'
shutil.copy2(ROOT/'coinbot_main_v2_13_1099.py',module_copy)
spec=importlib.util.spec_from_file_location('main_command_v1127',module_copy)
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
mod.BASE_DIR=base
mod.QUALITY_SHADOW_STATUS=base/'clean_quality_shadow_status_v1125.json'
mod.QUALITY_EYE_STATUS_V1124=base/'clean_quality_eye_status_v1125.json'
mod.QUALITY_POLICY_COMPARISON_STATUS_V1120=base/'clean_quality_policy_comparison_status_v1125.json'
mod.QUALITY_SHADOW_STATUS.write_text(json.dumps({
    'updated_ts':time.time(),'version':'review_worker_v1.005','source_rows_raw_v1125':3,'source_unique_trigger_decisions_v1125':2,
    'tracked_records':2,'new_records_this_cycle':1,'identity_owner_field_v1126':'trigger_occurrence_v1037.decision_key',
    'identity_owner_values_sample_v1126':['plan1'],'identity_event_counts_v1126':{'NEW_PLAN':0,'NEW_RESET_REBREAK':1,'SAME_PLAN_KEY_CHURN_BLOCKED':1,'MISSING_OWNER_KEY':1},
    'missing_owner_reason_counts_v1127':{'NO_TRIGGER_OBJECT':1,'TRIGGER_OBJECT_NO_DECISION_KEY':0,'OWNER_VALUE_INVALID':0},
    'missing_owner_samples_v1127':[{'ticker':'ABC','code':'NO_TRIGGER_OBJECT','stage':'WATCH'}],
    'storage_truth_v1127':{'active_state_schema':'quality_shadow_state_v1127_packed_active','active_unfinished_rows':2,'terminal_rows_in_active_state':0,'state_bytes':1048576,'final_ledger_file':'quality_shadow_result_ledger_v1125.jsonl','final_ledger_append_only':True,'aggregate_file':'clean_quality_eye_aggregate_v1125.json'}
}),encoding='utf-8')
empty60={k:{'n':0,'comparison_ready_n':0} for k in ('safety_only','current_quality','improved_quality')}
ten={k:{'n':1,'adjusted_n':1,'mfe_n':1,'mae_n':1} for k in ('safety_only','current_quality','improved_quality')}
mod.QUALITY_EYE_STATUS_V1124.write_text(json.dumps({'updated_ts':time.time(),'version':'review_worker_v1.005','state':'COLLECTING','identity_owner_field':'trigger_occurrence_v1037.decision_key','identity_contract':'exact owner only','comparison_contract':'10m completed provisional; 60m completed comparison-ready final','ten_minute_completed_events':1,'finalized_events':0,'active_unfinalized_events':2,'minimum_ready_n':0,'minimum_60m_samples_per_policy':30,'leader_state':'INSUFFICIENT_60M_SAMPLE','horizons':{'10m':ten,'60m':empty60},'false_pass_10m_provisional':{'no_positive_mfe':1},'false_pass_60m_final':{'no_positive_mfe':0},'false_block_60m_final':{'hit_1':0}}),encoding='utf-8')
(base/'ops_map_snapshot.json').write_text(json.dumps({'sections':{'ledger':{'quality_shadow_writer_truth_v1126':[{'name':'quality_shadow_result_ledger_v946.jsonl','inode':1,'since_owner_start_growth_bytes':0,'since_owner_start_state':'PROVEN_NO_WRITE_BY_MTIME','current_write_fd_pids':[],'active_writer_verdict':'NO_CURRENT_WRITE_PROVEN'}]}}}),encoding='utf-8')
text='\n'.join(mod.quality_shadow_lines(True))
for required in ('[v1127 후보 보는 눈','trigger_occurrence_v1037.decision_key','NEW_RESET_REBREAK 1','SAME_PLAN_KEY_CHURN_BLOCKED 1','10m 잠정 false-pass','60m 최종 false-pass','60m 비교가능 최소표본 0/30','MISSING/PENDING','적용후 +0B','owner 누락 분해','quality_shadow_state_v1127_packed_active','완료row 0'):
    assert required in text, required
rendered=mod.render_quality_shadow_text()
assert rendered.startswith('🧬 /quality_shadow · v1127 후보품질 P0 마감')
source=(ROOT/'coinbot_main_v2_13_1099.py').read_text(encoding='utf-8')
assert "'quality_shadow': required['quality_shadow']" in source
assert "'quality_shadow': render_quality_shadow_text" in source
print('PASS main /quality_shadow v1127 renderer and public command binding')
