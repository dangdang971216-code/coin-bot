from pathlib import Path
root = Path(__file__).resolve().parents[1]
strategy = (root / 'strategy_worker_v1.063.py').read_text()
paper = (root / 'paper_bot_v1.079.py').read_text()
assert 'V1206_TOTAL_CAP = 50' in paper
assert 'V1208_CYCLE_NEW_OPEN_CAP = 5' in paper
assert "'trigger_invalid_target_changed':False" in strategy
assert "'candidate_pass_changed':False" in strategy
assert "'auto_buy':False" in strategy
print('PASS OPEN 50/generation 5 and strategy numeric rules unchanged')
