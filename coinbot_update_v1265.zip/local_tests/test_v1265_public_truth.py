from pathlib import Path
root = Path(__file__).resolve().parents[1]
main = (root / 'coinbot_main_v2_13_1166.py').read_text()
paper = (root / 'paper_bot_v1.079.py').read_text()
guard = (root / 'backga_guard_bot_v2_5_243.py').read_text()
assert '계약전달 유실' in main
assert 'v1265 이후 신규 OPEN은 계약 없으면 fail-closed' in main
assert 'contract_transport_missing_open' in paper
assert '/gcontract_v1265' in guard
assert '/gledger_v1265' in guard
assert "paper_bot_v1.079" in guard
print('PASS public truth and guard proof are wired')
