from __future__ import annotations
import importlib.util
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def load(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

strategy = load('strategy_v1265_test', 'strategy_worker_v1.063.py')
paper = load('paper_v1265_test', 'paper_bot_v1.079.py')

contract = {
    'schema': 'unified_alt_swing_contract_v1257',
    'contract_digest': 'digest-1265',
    'candidate_decision_key': 'decision-1',
    'ready': True,
    'primary_entry_structure': {
        'trigger_price': 100.0,
        'invalid_price': 95.0,
        'base_target_price': 110.0,
        'structure_contract_version': 'structure_contract_v1229_coherent_stop_profit_pairing',
        'structure_contract_hash': 'hash-1',
        'source': 'current_v1212_coherent_pairing',
    },
    'v1211_structural_support': {
        'source_exact': True,
        'selection_complete': True,
        'early_failure_invalid_price': 97.0,
        'extension_target_price': 120.0,
    },
    'entry_quality_support': {
        'confirmed': True,
        'known_axes': 4,
        'confirmation_passes': 3,
        'reaction_safe': True,
    },
}
row = {
    'ticker': 'TEST',
    's_stage': 'S1',
    'open_eligible': True,
    'trigger_reached': True,
    'structure_contract_version': 'structure_contract_v1229_coherent_stop_profit_pairing',
    'structure_contract_hash': 'hash-1',
    'ranking_contract_version': 'ranking_contract_v1212_global_dynamic_score',
    'selection_contract_version': 'selection_contract_v1212_global_top_score',
    'unified_strategy_contract_v1257': contract,
    'canonical_entry_decision': {'decision_key': 'decision-1'},
}
compact = strategy._v932_compact_s1_hold_row(row)
assert compact['unified_strategy_contract_v1257']['schema'] == contract['schema']
assert compact['unified_strategy_contract_v1257']['contract_digest'] == contract['contract_digest']
assert compact['unified_contract_transport_verified_v1265'] is True
assert compact['structure_contract_version'] == row['structure_contract_version']
assert len(json.dumps(compact, ensure_ascii=False, separators=(',', ':')).encode()) <= strategy.V932_HOLD_ROW_MAX_BYTES
assert paper._v1257_candidate_contract(compact)['contract_digest'] == contract['contract_digest']
print('PASS contract survives Strategy S1 compact -> committed handoff -> Paper reader')
