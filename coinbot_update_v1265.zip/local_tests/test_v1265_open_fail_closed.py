from __future__ import annotations
import importlib.util
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def load(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    assert spec and spec.loader
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

paper = load('paper_v1265_open_test', 'paper_bot_v1.079.py')

# No file write: replace the previous OPEN constructor with an in-memory stub.
paper._V1257_PREV_OPEN_POSITION = lambda pos_id, ev: {
    'pos_id': pos_id,
    'entry_price': 100.0,
    'current_price': 100.0,
    'swing_structure_plan_v977': {
        'invalid': {'price': 95.0},
        'target': {'price': 110.0},
    },
}
try:
    paper.open_position__v1257_unified('p-missing', {'ticker': 'TEST'})
except ValueError as exc:
    assert 'v1265 unified_strategy_contract_v1257 missing' in str(exc)
else:
    raise AssertionError('missing unified contract must fail closed')

contract = {
    'schema': paper.V1257_UNIFIED_SCHEMA,
    'contract_digest': 'digest-1265',
    'candidate_decision_key': 'decision-1',
    'primary_entry_structure': {
        'trigger_price': 100.0,
        'invalid_price': 95.0,
        'base_target_price': 110.0,
    },
    'v1211_structural_support': {
        'source_exact': True,
        'selection_complete': True,
        'early_failure_invalid_price': 97.0,
        'extension_target_price': 120.0,
    },
    'entry_quality_support': {'confirmed': True},
}
pos = paper.open_position__v1257_unified('p-valid', {'ticker': 'TEST', 'unified_strategy_contract_v1257': contract})
assert pos['exit_contract_v1257']['schema'] == paper.V1257_EXIT_SCHEMA
assert pos['unified_contract_transport_verified_v1265'] is True
assert pos['unified_contract_transport_digest_v1265'] == 'digest-1265'
print('PASS missing contract fails closed and valid contract is sealed')
