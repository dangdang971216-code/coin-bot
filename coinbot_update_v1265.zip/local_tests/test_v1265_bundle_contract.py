from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
dep=json.loads((root/'DEPLOY_BUNDLE.json').read_text())
mat=json.loads((root/'ACTIVE_VERSION_MATRIX.json').read_text())
assert dep['release']=='v1265' and mat['release']=='v1265'
assert dep['runtime_files']['strategy']=='strategy_worker_v1.063.py'
assert dep['runtime_files']['paper']=='paper_bot_v1.079.py'
assert dep['runtime_files']['main']=='coinbot_main_v2_13_1166.py'
assert dep['runtime_files']['guard']=='backga_guard_bot_v2_5_243.py'
assert dep['open_capacity']=={'total':50,'generation_new':5}
assert dep['trigger_invalid_target_rr_changed'] is False
assert dep['existing_open_contract_changed'] is False
for banned in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_decision_state_v926.json'):
    assert not (root/banned).exists()
print('PASS v1265 bundle contract')
