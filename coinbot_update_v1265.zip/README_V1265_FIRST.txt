v1265는 신규 OPEN 통합계약 전달 유실을 수리한다.
먼저 /gupgrade_bundle 단독 실행 후 가드 재시작을 기다린다.
그 다음 /gdeploy /grelease_verify /gcontract_v1265 /gledger_v1265를 한 번에 실행한다.
후보식·trigger·invalid·target·RR·청산수치 변경 없음. 자동매수 OFF.
