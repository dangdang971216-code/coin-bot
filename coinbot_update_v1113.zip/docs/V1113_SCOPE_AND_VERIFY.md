# v1113 grouped operational bundle

## Included
1. Strategy singleton fresh proof
   - Rewrites the canonical singleton status from the same process-held flock at acquire, cycle start and cycle end.
   - Records pid, lock_pid, fd, inode, held state, version, build and boot id.
2. Strategy 46-second cycle owner accounting
   - Groups direct non-overlapping phases.
   - Exposes dominant group and unaccounted wall seconds/percent.
   - Guard classifies group owner or missing phase boundary before naming a leaf fix target.
3. Paper RSS owner probe
   - Bounded 12-cycle same-PID status artifact.
   - Measures load_open, select_candidates, write_status and classify helper plus between-cycle RSS.
   - Requires repeated >=25MB evidence before PROVEN classification.
4. PAPER CLOSED colour
   - Final fee-adjusted loss or structure_invalid always uses red.
   - Orange remains only for non-loss no-progress/weak-hold exits.

## Explicitly unchanged
- Strategy mode ALT_SWING.
- Quality thresholds and rank formulas.
- Trigger, invalid, target and exit contracts.
- Actual-entry RR, target room, chase, spread, slippage and cost gates.
- OPEN 30 and cycle new OPEN 3.
- Auto-buy remains OFF.
- OPEN/CLOSED/trade_log/decision/performance/change/issue ledgers are not included or rewritten.

## Server proof
1. Run `/gupgrade_bundle` alone.
2. After automatic guard continuation completes, Guard: `/gops_refresh` once.
3. Main in one message: `/flow_map` and `/errorlog`.
4. Expected:
   - Guard v2.5.165.
   - Strategy v1.005, exactly one PID, MainPID=statusPID=lockPID, lock held.
   - Strategy phase group or unaccounted wall evidence visible for slow cycles.
   - Paper v1.015 and bounded resource-owner probe begins collecting.
   - New execution errors 0.
   - Next negative PAPER CLOSED headline is red.

v1112 was not applied. It remains an unused release number and its small colour fix is absorbed here without reusing the number.
