import importlib.util, os, tempfile, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(mod)
    return mod

# Paper alert result priority and bounded probe.
paper=load('paper_v1113',ROOT/'paper_bot_v1.015.py')
assert paper.VERSION=='paper_bot_v1.015'
assert paper._v988_closed_emoji({'exit_reason':'swing_no_progress','net_after_configured_fee_pct_v983':-0.4})=='🔴'
assert paper._v988_closed_emoji({'exit_reason':'swing_max_weak_hold','net_after_configured_fee_pct_v983':0.0})=='🟠'
assert paper._v988_closed_emoji({'exit_reason':'structure_target','net_after_configured_fee_pct_v983':8.0})=='🔥'
probe_path=ROOT/'paper_resource_owner_probe_v1113.json'
try: probe_path.unlink()
except FileNotFoundError: pass
paper.PAPER_RESOURCE_OWNER_PROBE_V1113=probe_path
paper._v1113_probe_begin('cycle')
paper._v1113_probe_helper('dummy',lambda: 3)
payload=paper._v1113_probe_finish('cycle')
assert payload['schema']=='paper_resource_owner_probe_v1113'
assert len(payload['cycle_samples'])==1
assert payload['cycle_samples'][0]['helpers'][0]['helper']=='dummy'

# Strategy singleton proof refresh and wall group accounting.
with tempfile.TemporaryDirectory() as td:
    os.environ['TRADING_BOT_DIR']=td
    strategy=load('strategy_v1113',ROOT/'strategy_worker_v1.005.py')
    assert strategy.VERSION=='strategy_worker_v1.005'
    strategy._acquire_strategy_singleton_v1110()
    status=json.loads((Path(td)/'clean_strategy_singleton_status_v1111.json').read_text())
    assert status['pid']==os.getpid() and status['lock_pid']==os.getpid()
    assert status['lock_held'] is True and status['lock_fd']>=0
    profile={'phases':{
        'status_start':{'wall_sec':1.0,'cpu_sec':0.4},
        'candidate_base_spike_merge':{'wall_sec':2.0,'cpu_sec':1.5},
        'candidate_writer_compact_single_pass':{'wall_sec':3.0,'cpu_sec':2.0},
    }}
    grouped=strategy._v1113_phase_group_totals(profile)
    assert grouped['grouped_wall_sec']==6.0
    assert grouped['groups'][0]['group']=='candidate_writer'

# Guard classifier source is compiled and new contracts are present.
guard_text=(ROOT/'backga_guard_bot_v2_5_165.py').read_text()
for token in ('CHECK_STRATEGY_UNACCOUNTED_WALL','PROVEN_HELPER_OWNER_V1113','paper_resource_owner_probe_v1113.json'):
    assert token in guard_text
print('PASS v1113 bundle')
