coinbot_update_v1431
- Paper shadow writer call proof: module_load/main_start/write_status/post_run_cycle.
- Adds /exit_shadow_writer_diag.
- No candidate flow or real exit contract change. Auto-buy OFF.
