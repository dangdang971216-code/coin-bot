v1709: PRE-MAIN operational hotfix. Fixes guard disk command NameError and main /version_score recursion. No trading changes. Auto-buy OFF.
