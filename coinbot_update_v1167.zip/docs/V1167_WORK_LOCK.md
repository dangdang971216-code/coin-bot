# v1167 작업 잠금

## 증상
전체시장과 구조·품질 앞단은 정상인데 최종 S1·Paper 접수 후보가 0~4개로 축소됐다.

## 실제 원인
구 occurrence 본선은 느린 Strategy cycle마다 현재가격 한 점만 보았다. cycle 사이에 trigger 아래 접촉과 위 재돌파가 모두 발생하면 이를 놓쳐 WAIT 상태가 유지됐다. 계약이 잠시 미완성인 재돌파도 소비된 뒤 다시 reset을 요구했다.

## Owner
- 가격경로: Micro transaction_history의 거래소 timestamp
- occurrence: Strategy
- freshness/TTL: Paper

## 수정 파일
- bithumb_micro_sidecar_v0.15.py
- strategy_worker_v1.026.py
- paper_bot_v1.036.py

## 삭제 구경로
- sampled-side `_v1133_trigger_occurrence` 구현
- active versioned occurrence payload reader/writer
- 미완성 cross를 영구 소비한 뒤 reset을 강제하는 경로
- loss-reentry initial/migrated-above shortcut

## 새 본선
Micro 거래소 체결경로 → Strategy 실제 below→above 사건 → 동일 fresh 사건 계약 재확인 → Paper TTL

## 변경하지 않음
Gate·rank·trigger 가격·invalid·target·RR·비용·청산·OPEN 한도·자동매수.
