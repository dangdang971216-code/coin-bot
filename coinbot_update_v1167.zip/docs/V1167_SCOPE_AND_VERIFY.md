# v1167 범위와 검수

## 적용 범위
- Micro v0.15: 최근 30체결의 거래소 timestamp 가격경로
- Strategy v1.026: path 기반 trigger occurrence 단일 owner
- Paper v1.036: canonical occurrence와 기존 TTL 120초 소비

## 로컬 검수
1. 세 source py_compile
2. 실제 below→above 경로만 qualified
3. 계약 미완성 cross는 pending 후 같은 사건으로 qualified
4. stale terminal 뒤 새 below→above 없이는 재생성 금지
5. 이후 새 below→above에서만 새 key 생성
6. Paper fresh/stale/wait 판정
7. 구 active 함수·상태명 제거
8. Gate·구조선·실행 freshness·청산 AST 동일
9. TTL 120, OPEN 30, cycle 3 동일

## 서버 완료 조건
- Micro v0.15 / Strategy v1.026 / Paper v1.036 runtime·alias·hash 일치
- Micro path ready 표본과 age 표시
- 새 후보에 path_evidence·reset_ts·event_ts 존재
- 구 wait_new_reset_rebreak_v1133 사유 0
- S1·Paper 접수 후보가 첫 회귀 이전 수준으로 회복되는지 표본 비교
- false-pass와 stale 재게시 0
- 신규 runtime 오류 0
- 자동매수 OFF
