#!/usr/bin/env python3
from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parent
m=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1167'
assert m['main'] is None and m['guard'] is None
assert m['paper']=='paper_bot_v1.036.py'
assert m['micro']=='bithumb_micro_sidecar_v0.15.py'
assert m['workers']=={'strategy':'strategy_worker_v1.026.py'}
assert m['auto_buy'] is False and m['live_ledger_included'] is False
assert m['trigger_contract_change'] is True
assert m['quality_formula_change'] is False and m['candidate_ttl_change'] is False
for name,digest in m['source_sha256'].items():
    assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==digest,(name,digest)
for name in m['support_files']:
    # checksum/result files are created after this test and are allowed to be absent during first pass.
    if name in {'FILES_SHA256_v1167.tsv','LOCAL_TEST_RESULT_V1167.txt','PACKAGE_VERIFY_V1167.txt'}:
        continue
    assert (ROOT/name).exists(),name
for forbidden in ('paper_bot.py','strategy_worker.py','bithumb_micro_sidecar.py','bot.py','backga_guard_bot.py',
                  'paper_bot_open.json','paper_bot_closed.jsonl','paper_bot_trade_log.jsonl','issue_ledger.jsonl','change_verify_ledger.jsonl'):
    assert not (ROOT/forbidden).exists(),forbidden
print('PASS v1167 package')
