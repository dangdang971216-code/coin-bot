#!/usr/bin/env python3
from __future__ import annotations
import ast
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

ROOT = Path(__file__).resolve().parent
STRATEGY = ROOT / 'strategy_worker_v1.026.py'
PAPER = ROOT / 'paper_bot_v1.036.py'
MICRO = ROOT / 'bithumb_micro_sidecar_v0.15.py'
OLD_STRATEGY = ROOT / 'strategy_worker_v1.025.py'
OLD_PAPER = ROOT / 'paper_bot_v1.035.py'


def extract_functions(path: Path, names: set[str], ns: dict) -> dict:
    tree = ast.parse(path.read_text(encoding='utf-8'))
    found = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name in names]
    missing = names - {n.name for n in found}
    assert not missing, (path.name, missing)
    module = ast.Module(body=found, type_ignores=[])
    ast.fix_missing_locations(module)
    exec(compile(module, str(path), 'exec'), ns)
    return ns


def fnum(*values: Any, default: float = 0.0) -> float:
    for value in values:
        try:
            if value not in (None, '', [], {}, '-'):
                return float(value)
        except Exception:
            pass
    return default


strategy_ns = {
    'Any': Any, 'Dict': Dict, 'List': List, 'Optional': Optional, 'Tuple': Tuple,
    'fnum': fnum,
}
extract_functions(STRATEGY, {
    '_v925_num', 'build_minimal_gate_decision_key', '_v1159_terminal_feedback_match',
    '_trigger_path_points', '_latest_trigger_rebreak', '_trigger_occurrence',
}, strategy_ns)
trigger_occurrence = strategy_ns['_trigger_occurrence']

paper_ns = {
    'Any': Any, 'Dict': Dict, 'Optional': Optional,
    'fnum': fnum, 'now_ts': lambda: 1000.0,
    'read_strategy_entry_gate': lambda row: row.get('swing_entry_gate') if isinstance(row.get('swing_entry_gate'), dict) else row,
}
extract_functions(PAPER, {'trigger_occurrence_freshness'}, paper_ns)
freshness = paper_ns['trigger_occurrence_freshness']

micro_ns = {'Any': Any, 'Dict': Dict, 'List': List, 'Tuple': Tuple}
# datetime objects are needed only by _trade_timestamp.
from datetime import datetime, timezone, timedelta
micro_ns.update({'datetime': datetime, 'timezone': timezone, 'timedelta': timedelta})
extract_functions(MICRO, {'_trade_timestamp', '_compact_trade_path'}, micro_ns)
trade_timestamp = micro_ns['_trade_timestamp']
compact_path = micro_ns['_compact_trade_path']

# 1) Exchange timestamps parse and compact in time order.
ts1 = trade_timestamp({'transaction_date': '2026-07-01 07:00:00.000000'})
ts2 = trade_timestamp({'transaction_date': '2026-07-01 07:00:01.000000'})
assert ts2 > ts1 > 0
path = compact_path([(ts2, 101.0), (ts1, 99.0)], ts2 + 1)
assert path['ready'] is True and path['points'][0][1] == 99.0 and path['points'][-1][1] == 101.0
assert compact_path([(ts1, 99.0)], ts1 + 1)['ready'] is False

# Shared plan.
base = 1_000.0
rec = {'frozen_ts': base, 'trigger_occurrence_schema': 'trigger_occurrence_v1'}
price_path = {
    'ready': True, 'source': 'bithumb_transaction_history', 'last_ts': base + 3, 'age_sec': 0.1,
    'points': [[base + 1, 99.0], [base + 2, 100.0], [base + 3, 101.0]],
}

# 2) Proven below→above path + ready contract creates a qualified immutable event.
ev, key = trigger_occurrence(rec, 'market:TEST', 101.0, 100.0, base + 3, True, price_path, {})
assert key and ev['kind'] == 'QUALIFIED_PATH_REBREAK'
assert ev['qualification_state'] == 'QUALIFIED_EVENT' and ev['contract_ready'] is True
assert ev['event_ts'] == base + 2 and ev['reset_ts'] == base + 1
first_key = key

# 3) Same event remains stable while above, not a new decision each cycle.
ev2, key2 = trigger_occurrence(rec, 'market:TEST', 102.0, 100.0, base + 4, True,
                              {'ready': True, 'points': [[base + 3.5, 102.0]], 'source':'bithumb_transaction_history'}, {})
assert key2 == first_key and ev2['event_ts'] == base + 2

# 4) A cross is not lost when contract is temporarily unready; later recheck qualifies same event.
rec_pending = {'frozen_ts': base, 'trigger_occurrence_schema': 'trigger_occurrence_v1'}
pending, no_key = trigger_occurrence(rec_pending, 'market:PENDING', 101.0, 100.0, base + 3, False, price_path, {})
assert not no_key and pending['kind'] == 'PATH_REBREAK_PENDING_CONTRACT'
assert pending['pending_event_ts'] == base + 2
qualified, pending_key = trigger_occurrence(rec_pending, 'market:PENDING', 101.0, 100.0, base + 4, True,
                                            {'ready': False, 'points': []}, {})
assert pending_key and qualified['event_ts'] == base + 2
assert qualified['kind'] == 'QUALIFIED_PATH_REBREAK'

# 5) Exact stale terminal feedback retires old event. No later below→above means no revival.
feedback = {pending_key: {
    'decision_key': pending_key, 'terminal_code': 'STALE_TRIGGER_OCCURRENCE',
    'trigger_event_ts': base + 2, 'first_seen_ts': base + 130, 'last_seen_ts': base + 130,
}}
retired, retired_key = trigger_occurrence(rec_pending, 'market:PENDING', 101.0, 100.0, base + 131, True,
                                          {'ready': True, 'source':'bithumb_transaction_history',
                                           'points': [[base + 131, 101.0]]}, feedback)
assert not retired_key and retired['qualification_state'] == 'WAIT_PATH_RESET'

# A genuinely later reset→rebreak creates a new key.
new_path = {'ready': True, 'source':'bithumb_transaction_history',
            'points': [[base + 132, 99.0], [base + 133, 101.0]]}
renewed, renewed_key = trigger_occurrence(rec_pending, 'market:PENDING', 101.0, 100.0, base + 133, True, new_path, {})
assert renewed_key and renewed_key != pending_key and renewed['event_ts'] == base + 133

# 6) No below→above path stays fail-closed.
rec_above = {'frozen_ts': base, 'trigger_occurrence_schema':'trigger_occurrence_v1'}
wait, wait_key = trigger_occurrence(rec_above, 'market:ABOVE', 105.0, 100.0, base + 5, True,
                                    {'ready': True, 'source':'bithumb_transaction_history',
                                     'points': [[base + 1, 103.0], [base + 2, 104.0]]}, {})
assert not wait_key and wait['qualification_state'] == 'WAIT_PATH_RESET'

# 7) Paper remains TTL owner and accepts/rejects only canonical qualified events.
row = {'trigger_occurrence': renewed}
fr = freshness(row, {'candidate_ttl_sec': 120.0}, nowv=base + 140)
assert fr['fresh'] is True and fr['code'] == 'FRESH_QUALIFIED_TRIGGER_OCCURRENCE'
st = freshness(row, {'candidate_ttl_sec': 120.0}, nowv=base + 300)
assert st['fresh'] is False and st['code'] == 'STALE_TRIGGER_OCCURRENCE'
wr = freshness({'trigger_occurrence': pending}, {'candidate_ttl_sec':120.0}, nowv=base + 10)
assert wr['fresh'] is False and wr['code'] == 'WAIT_TRIGGER_PATH'

# 8) Removed active path names and obsolete states do not remain in changed sources.
combined = '\n'.join(p.read_text(encoding='utf-8') for p in (STRATEGY, PAPER, MICRO))
for forbidden in (
    'def _v1133_trigger_occurrence', 'wait_new_reset_rebreak_v1133',
    'INITIAL_ABOVE_WAIT_RESET', 'MIGRATED_ABOVE_WAIT_RESET',
    'UNQUALIFIED_REBREAK_WAIT_RESET', 'ABOVE_WITHOUT_QUALIFIED_EVENT',
    'contract_ready_at_cross',
):
    assert forbidden not in combined, forbidden

# 9) Numeric strategy/execution contracts remain unchanged.
def assignments(path: Path, names: set[str]) -> dict:
    tree = ast.parse(path.read_text(encoding='utf-8'))
    result = {}
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id in names:
                    result[target.id] = ast.literal_eval(node.value)
    return result

strategy_constants = {'V925_UNTRADABLE_SPREAD_PCT','V925_MIN_RR','V925_MIN_TARGET_ROOM_PCT','V977_MAX_TRIGGER_OVERSHOOT_PCT'}
new_strategy_constants = assignments(STRATEGY, strategy_constants)
assert new_strategy_constants == {
    'V925_UNTRADABLE_SPREAD_PCT': 1.20,
    'V925_MIN_RR': 1.50,
    'V925_MIN_TARGET_ROOM_PCT': 1.20,
    'V977_MAX_TRIGGER_OVERSHOOT_PCT': 0.60,
}
if OLD_STRATEGY.exists():
    assert new_strategy_constants == assignments(OLD_STRATEGY, strategy_constants)

# TTL and OPEN limits remain unchanged in the canonical DEFAULT_CONTROL.
def literal_assignment(path: Path, name: str):
    tree = ast.parse(path.read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == name:
            return ast.literal_eval(node.value)
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == name:
                    return ast.literal_eval(node.value)
    raise AssertionError((path.name, name))
new_control = literal_assignment(PAPER, 'DEFAULT_CONTROL')
for key, expected in (('candidate_ttl_sec',120),('max_open_strict',30),('max_new_per_cycle',3)):
    assert new_control[key] == expected
if OLD_PAPER.exists():
    old_control = literal_assignment(OLD_PAPER, 'DEFAULT_CONTROL')
    for key in ('candidate_ttl_sec','max_open_strict','max_new_per_cycle'):
        assert old_control[key] == new_control[key]

print('PASS v1167 trigger-path contract')
