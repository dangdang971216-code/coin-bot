v1629: Paper post-main lifecycle hook + runtime identity verify repair. No candidate/strategy/trading rule changes. Auto-buy OFF.
