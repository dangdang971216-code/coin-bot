v2080: pre-main binding fix. v2079 code was after main() and never ran. Read-only shadow/loss display only. Auto-buy OFF.
