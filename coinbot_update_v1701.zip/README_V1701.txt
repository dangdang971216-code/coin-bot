v1701: v1452 흐름 기준 적용 안정화판

선택 기준:
- v1454를 기준으로 사용: v1452 후보흐름 유지 + 표시만 개선된 최신 1400대.
- v1496은 후보 말림 의심 구간 이후라 전략 기준으로 사용하지 않음.
- v1630에서는 코드가 아니라 DEPLOY_TARGET/components/workers/SHA256 방식만 가져옴.

포함 active worker:
- Guard: backga_guard_bot_v2_5_1701.py
- Main: coinbot_main_v2_13_1701.py
- Paper: paper_bot_v1.701.py
- Strategy: strategy_worker_v1.701.py

변경 없음:
- 후보 기준, S1/S2/S3, trigger, invalid, target, RR, TTL, gate, OPEN 제한, 청산계약, 원장, 자동매수 OFF.
