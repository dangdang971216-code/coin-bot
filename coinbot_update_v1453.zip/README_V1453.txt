v1453 display-only: shadow_board icon tone fix; popen keeps PnL colors only. Auto-buy OFF. No trading-rule change.
