v1364는 Guard-only입니다. old-base Strategy를 최신 v1211식 cycle/commit으로 실패 처리하지 않고 old-base runtime 증거로 검수합니다. 자동매수 OFF, 매매기준 변경 0.
