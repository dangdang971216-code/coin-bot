import importlib.util
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
SRC=ROOT/'paper_bot_v1.073.py'
spec=importlib.util.spec_from_file_location('paper_v1256', SRC)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

BASE_CTRL={
    'swing_trailing_trigger_pct':2.0,
    'swing_trailing_giveback_pct':0.8,
    'fast_fail_after_min':2.5,
    'fast_fail_peak_under_pct':0.20,
    'fast_fail_loss_pct':-0.35,
    'fast_fail_after_min_late':5.0,
    'fast_fail_loss_pct_late':-0.25,
    'profit_run_extend_enabled':True,
    'profit_run_extend_minutes':15,
    'profit_run_extend_max_count':1,
    'profit_run_extend_min_net_pct':0.20,
    'profit_run_extend_min_peak_pct':0.25,
    'profit_run_extend_max_giveback_pct':0.25,
    'swing_no_progress_minutes':360,
    'swing_no_progress_peak_under_pct':0.35,
    'swing_no_progress_net_under_pct':0.0,
    'swing_max_weak_hold_minutes':4320,
    'swing_max_weak_peak_under_pct':1.0,
    'swing_max_weak_net_under_pct':0.25,
    'swing_emergency_stop_pct':-2.5,
}

m.load_control=lambda: dict(BASE_CTRL)
contract=m._v1256_new_open_exit_contract()
assert contract['version']=='v1256_complete_dynamic_exit'
assert contract['base_structure_target_preserved'] is True
assert contract['target_runner']['extend_minutes']==15.0
assert contract['fast_failure']['loss_pct']==-0.35
assert 'fast_fail_stop' in contract['allowed_reasons']
assert m.VERSION=='paper_bot_v1.073'
assert 'v1256_current_structure_fast_failure' in m.BUILD_LABEL


def pos(price=100.0, target=110.0, invalid=95.0, c=contract):
    return {
        'strategy_mode':'ALT_SWING_V977',
        'current_price':price,
        'entry_price':100.0,
        'swing_target_price_v977':target,
        'swing_invalid_price_v977':invalid,
        'exit_contract_v1038':dict(c),
    }

# Hard invalid remains first owner.
d=m._exit_decision_spine(pos(price=94.9), 1.0, 0.0, -5.1, BASE_CTRL)
assert (d['action'],d['reason'])==('close','structure_invalid')

# Early no-reaction loss closes before far invalid.
d=m._exit_decision_spine(pos(price=99.5), 3.0, 0.10, -0.40, BASE_CTRL)
assert (d['action'],d['reason'])==('close','fast_fail_stop')

# A trade with enough reaction is not fast-failed.
d=m._exit_decision_spine(pos(price=99.5), 3.0, 0.30, -0.40, BASE_CTRL)
assert d['action']=='hold'

# Base current target starts one runner rather than moving entry structure.
p=pos(price=110.0)
d=m._exit_decision_spine(p, 20.0, 9.9, 9.8, BASE_CTRL)
assert d['action']=='extend' and d['reason']=='target_runner_start'
assert d['extend_minutes']==15.0

# Active runner holds while giveback is inside sealed bound.
p=pos(price=109.9)
p['time_exit_extension_count']=1
p['time_exit_extended_until_age_min']=35.0
d=m._exit_decision_spine(p, 25.0, 10.0, 9.80, BASE_CTRL)
assert d['action']=='hold'

# Active runner closes on sealed giveback.
d=m._exit_decision_spine(p, 25.0, 10.0, 9.70, BASE_CTRL)
assert (d['action'],d['reason'])==('close','swing_trailing')

# Active runner closes at timeout even if still strong.
d=m._exit_decision_spine(p, 35.0, 10.0, 9.90, BASE_CTRL)
assert (d['action'],d['reason'])==('close','structure_target')

# Old OPEN contract remains on previous behavior: immediate base target close.
old={
    'schema':'alt_swing_exit_contract_v1038','version':'v1038','trailing_exit':True,
    'trailing_trigger_pct':2.0,'trailing_giveback_pct':0.8,'applies_to':'old_open'
}
d=m._exit_decision_spine(pos(price=110.0,c=old),20.0,9.9,9.8,BASE_CTRL)
assert (d['action'],d['reason'])==('close','structure_target')

assert 'never candidate or structure owner' in m.V1256_COMPLETE_STRATEGY_CONTRACT['v1211_role']
assert m.V1256_COMPLETE_STRATEGY_CONTRACT['existing_open_changed'] is False
assert m.V1256_COMPLETE_STRATEGY_CONTRACT['auto_buy'] is False

print('PASS v1256 complete strategy contract')
