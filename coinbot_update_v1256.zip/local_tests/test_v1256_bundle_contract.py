import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
rules=json.loads((ROOT/'TRADING_RULES_CHANGE_V1256.json').read_text(encoding='utf-8'))
src=(ROOT/'paper_bot_v1.073.py').read_text(encoding='utf-8')
assert manifest['paper']=='paper_bot_v1.073.py'
assert manifest['exit_changed'] is True
assert manifest['existing_open_contract_changed'] is False
assert manifest['auto_buy'] is False
assert rules['candidate_formula_changed'] is False
assert rules['base_target_changed'] is False
assert rules['exit_changed_for_new_open'] is True
assert rules['existing_open_contract_changed'] is False
assert "VERSION = 'paper_bot_v1.073'" in src
assert "v1256_complete_dynamic_exit" in src
assert "_v1038_new_open_exit_contract = _v1256_new_open_exit_contract" in src
assert "_exit_decision_spine = _exit_decision_spine__v1256" in src
for forbidden in ('paper_bot_open.json','paper_bot_closed.jsonl','trade_log','decision_state_v926.json','change_verify_ledger.jsonl','issue_ledger.jsonl'):
    assert not (ROOT/forbidden).exists(), forbidden
print('PASS v1256 bundle contract')
