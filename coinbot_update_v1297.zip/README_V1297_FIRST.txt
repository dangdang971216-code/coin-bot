/gupgrade_bundle
/grelease_verify
Paper bot: /pstrategy_reset_v1294
