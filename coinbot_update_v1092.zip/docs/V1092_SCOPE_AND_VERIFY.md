# v1092 Paper 증분 canonical performance writer

## 증상
- Paper의 performance_write가 약 8초까지 걸렸다.
- 새 CLOSED 한 건이 추가돼도 약 267MB `paper_bot_closed.jsonl` 전체를 다시 읽었다.
- 전체 rebuild 중 대형 rows/audit 객체 복사로 순간 RSS가 크게 상승했다.
- OPEN-only decision 변화도 CLOSED exact membership 변경처럼 취급될 수 있었다.

## 실제 원인
1. canonical performance source signature가 변경되면 raw CLOSED 전체 rebuild를 수행했다.
2. 기존 canonical snapshot의 compact rows/cursor를 정상 append 경로에서 재사용하지 않았다.
3. OPEN membership sealing과 CLOSED exact membership을 같은 rebuild 경로로 처리했다.
4. 재시작 시 이미 유효한 canonical snapshot을 runtime compact reference로 재사용하는 본선이 부족했다.

## 수정
- Paper v1.008의 최종 `write_score_cache` 하나가 canonical performance를 소유한다.
- CLOSED append는 `closed_processed_offset_v1092` 이후 byte만 읽는다.
- CLOSED-only decision digest를 membership source로 사용한다.
- OPEN membership 변화는 기존 compact rows를 재봉인한다.
- 시간 경계 변화도 기존 compact rows로 windows만 갱신한다.
- invalid snapshot, inode 교체, truncation, digest 불일치만 명시적 full rebuild를 허용한다.
- 기존 rows와 중복 audit copy는 finalization 전에 해제한다.
- status와 `/pstatus`에 mode, 시간, delta byte/row, full rebuild count를 표시한다.

## 변경하지 않음
- 성과 계산식
- ALT_SWING 분류·과거 거래 분류
- trigger/invalid/target/RR
- 진입·청산·비용 계약
- OPEN/CLOSED/decision/exact 원장
- 자동매수 상태

## 서버 검수
Guard `/gpaper_performance_fix_v1092 180`은 다음을 읽기 전용으로 증명한다.
- Paper v1.008 runtime/hash/MainPID
- status 갱신과 performance_write 시간
- append cursor와 canonical single writer
- 정상 append full scan OFF
- full rebuild 증가 0
- RSS 표본
- exact 0/0/0
- 신규 심각오류 0
- 자동매수 OFF
