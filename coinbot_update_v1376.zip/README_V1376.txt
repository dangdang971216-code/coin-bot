v1376 restore package
- Files are intentionally at ZIP root because /gupgrade_bundle reads DEPLOY_BUNDLE.json from root.
- Restores v1152 command board/screens/runtime source.
- Adds coinbot_ledger_clean_start_v1376.py for optional archive-then-clean-start ledger reset.
- Auto-buy OFF. Trading rules unchanged.
