코인봇 v2212

1. 후보 품질 자료 우선
   - 후보 배제조건은 0개로 유지한다.
   - v2211에서 미리 이름 붙인 조합 추천은 판정에서 제외한다.
   - Review가 현재 epoch exact CLOSED에서 계산한 수익군·패배군 실제 평균 차이만 먼저 표시한다.
   - 이후 원시 사건 조합으로 막을 손실과 같이 잘릴 수익을 비교하고 사용자 승인 뒤 한 개씩 적용한다.

2. 후보 배관 표시
   - 현재 candidate commit과 같은 S1 generation·Paper receipt만 비교한다.
   - 직전 Paper receipt는 현재 접수 건수로 섞지 않고 별도로 표시한다.
   - 현재 cycle 진행 중은 FAIL이 아니라 진행 중으로 표시한다.

3. 임시 -2% 손실방어
   - 최종 live exit monitor가 canonical paper_v2_exact_open_v2135 OPEN을 직접 읽는다.
   - 세대별 updater 전에 먼저 -2%를 검사하고 updater 뒤에도 재검사한다.
   - sweep 호출 횟수, 원본 OPEN, 검사, 청산, 잔존, 오류를 직접 표시한다.
   - checked=0인데 OPEN이 있으면 PASS가 아니라 ERROR다.
   - CLOSED append·decision 저장·OPEN 제거 순서는 기존 canonical commit owner를 유지한다.

4. 배포 범위
   - Main v2.13.2177 / Paper v2.114만 교체·재시작한다.
   - Strategy v2.077 / Core v2176 / Review v2.091은 변경·재시작하지 않아 진행 중 Review 스캔을 유지한다.
   - 상승예측식·구조·후보 조건·성과 초기화·원장은 변경하지 않는다.
   - 자동매수 OFF.

로컬 검수 PASS / 서버 적용·결과 검수 CHECK.
