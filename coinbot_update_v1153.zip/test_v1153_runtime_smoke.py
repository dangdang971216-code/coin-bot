#!/usr/bin/env python3
from __future__ import annotations
import ast, importlib.util, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
FILES = ['strategy_worker_v1.020.py', 'paper_bot_v1.029.py', 'coinbot_main_v2_13_1114.py']

for name in FILES:
    ast.parse((ROOT/name).read_text(encoding='utf-8'))

with tempfile.TemporaryDirectory() as td:
    temp = Path(td)
    module_dir = temp/'modules'
    runtime_root = temp/'runtime_root'
    module_dir.mkdir()
    runtime_root.mkdir()
    copies = []
    for name in FILES:
        dst = module_dir/name
        shutil.copy2(ROOT/name, dst)
        copies.append(dst)
        subprocess.run([sys.executable, '-m', 'py_compile', str(dst)], check=True, cwd=temp)

    old = os.environ.get('TRADING_BOT_DIR')
    os.environ['TRADING_BOT_DIR'] = str(runtime_root)
    try:
        for path in copies[:2]:
            spec = importlib.util.spec_from_file_location('smoke_'+path.stem, str(path))
            mod = importlib.util.module_from_spec(spec)
            assert spec.loader
            spec.loader.exec_module(mod)
    finally:
        if old is None:
            os.environ.pop('TRADING_BOT_DIR', None)
        else:
            os.environ['TRADING_BOT_DIR'] = old

print(json.dumps({'status':'PASS','py_compile':True,'isolated_import_strategy_paper':True,'main_ast_compile_only':True,'package_runtime_files_created':False}, ensure_ascii=False))
