# v1153 범위와 검수

## 코드 변경
### Strategy v1.020
- 사건별 append-once 시간 원장 추가
- S1 압축 파일에 candidate_path_timestamps_v1153 보존
- 계약 미준비 돌파는 TRIGGER_CROSS_REJECTED로 관찰만 기록

### Paper v1.029
- 최초 수신·실행자료 준비·최종 선택·차단·OPEN 확정시간 기록
- v1152 지연판이 실제 owner timestamp를 우선 사용하고 기존 cycle timestamp를 fallback으로 사용

### Main v2.13.1114
- 새 지연구간을 쉬운 한국어로 표시
- 현재 Strategy/Paper/Guard 예상 버전 정렬

## 로컬 검수
- py_compile PASS
- isolated import PASS
- Strategy/Paper append-once 중복방지 PASS
- S1 compact 전달 PASS
- exact 3구간 계산 PASS
- 기존 trigger/quality/RR/reentry/exit 안전 함수 AST 동일 PASS
- 자동매수 OFF

## 서버 검수
1. 실제 alias/target/version/hash 일치
2. 새 사건 원장 생성
3. flow_map에 trigger→품질, 품질→S1, S1→Paper 중 실제 표본 표시
4. STALE 표본이 첫 전달 지연인지 반복 사건인지 key로 분리
5. 신규 오류 0
6. 자동매수 OFF
