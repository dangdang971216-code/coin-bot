# v1153 작업 잠금

## 증상
최근 S1 5건 중 4건이 STALE_TRIGGER_OCCURRENCE, 1건이 SLIPPAGE_STALE로 차단됐다. 현재 자료만으로는 첫 전달부터 늦었는지, 같은 옛 사건이 반복 게시됐는지 구분할 수 없다.

## 실제 원인 후보
1. trigger 돌파 순간 Feature·Orderflow 정보 미준비
2. Strategy cycle 지연
3. 동일 trigger 사건 반복 S1 게시
4. S1 최초 저장과 Paper 최초 수신 timestamp 부재
5. 후보 확정 뒤에야 실행자료 우선갱신이 진행되는 순서

## 이번 버전 범위
- Strategy owner: TRIGGER_EVENT, QUALITY_EVALUATED, QUALITY_PASS, S1_HOLD_CREATED
- Paper owner: PAPER_RECEIVED, EXECUTION_DATA_READY, SELECTOR_DECIDED, TERMINAL_BLOCKED, OPEN_COMMITTED
- 모든 사건은 trigger_event_key/candidate_key/direct_decision_key로 연결
- 최초 사건은 append-once JSONL, 중복방지 state는 별도 runtime cache
- 기존 v1152 cycle 단계시간은 fallback 증거로 유지

## 변경하지 않는 영역
- 품질 Gate 수치
- trigger occurrence 계약
- candidate TTL
- 실제 진입가 RR·target room
- spread·slippage 한도
- 재진입 차단
- invalid·target·trailing·time exit
- OPEN 30·cycle 신규 3
- 자동매수 OFF

## 삭제·차단 완화 없음
이번 버전은 STALE/MISSING 차단을 제거하지 않는다. 늦은 원인을 증명할 시간 원장만 추가한다.

## 완료 기준
- 새 사건에서 trigger→quality, quality→S1, S1→Paper 계산 가능
- 동일 사건 반복 cycle에서도 각 stage JSONL 1건
- terminal block 또는 OPEN commit 최초시각 보존
- 기존 안전 함수 AST와 핵심 상수 동일
- 서버 runtime/hash/새 원장 기록 증명 전 CHECK
