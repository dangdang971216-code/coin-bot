from pathlib import Path
import importlib.util
root=Path(__file__).resolve().parent
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
s=load('sv1172',root/'strategy_worker_v1.031.py')
rec={'frozen_ts':10.0}
# Above observation is audit-only and does not start Paper TTL.
e0,k0=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',101.0,100.0,100.0,qualified=False,price_path={})
assert e0['observed_trigger_ts']==100.0 and e0['qualified_event_ts'] is None and not k0
# First final qualification seals one immutable exact decision.
e1,k1=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',101.0,100.0,150.0,qualified=True,price_path={})
assert e1['observed_trigger_ts']==100.0 and e1['qualified_event_ts']==150.0 and k1
# Same above episode never refreshes timestamps/key.
e2,k2=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',101.2,100.0,170.0,qualified=True,price_path={})
assert e2['observed_trigger_ts']==100.0 and e2['qualified_event_ts']==150.0 and k2==k1
# Below resets; re-above starts a new observation and qualification.
e3,k3=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',99.0,100.0,180.0,qualified=False,price_path={})
assert e3['qualified_event_ts'] is None and not k3
e4,k4=s._v1037_trigger_occurrence(rec,'KRW-TEST|plan',101.0,100.0,190.0,qualified=True,price_path={})
assert e4['qualified_event_ts']==190.0 and k4 and k4!=k1
p=load('pv1172',root/'paper_bot_v1.039.py')
ev={'swing_entry_gate_v977':{'trigger_occurrence':e4}}
f=p.trigger_occurrence_freshness(ev,{'candidate_ttl_sec':120},nowv=200.0)
assert f['fresh'] is True and f['age_sec']==10.0 and f['market_trigger_observed_ts']==190.0
# Delay path TTL is qualification->Paper, while market-trigger wait is separate.
row={'ticker':'TEST','swing_entry_gate_v977':{'trigger_occurrence':e4},'candidate_path_timestamps_v1153':{'market_trigger_observed_at':190.0,'entry_qualified_at':195.0,'s1_ready_current_cycle_at_v1172':196.0,'paper_received_at':200.0,'quality_evaluated_at':195.0,'quality_pass_at':195.0}}
d=p.candidate_delay_path_v1152(row,{}, {'candidate_ttl_sec':120},paper_ts=200.0)
assert d['entry_qualification_to_paper_sec_v1172']==5.0
assert d['market_trigger_to_paper_sec_v1172']==10.0
assert d['transport_segments_v1172']['s1_event_to_s1_commit_sec'] is None
print('PASS')
