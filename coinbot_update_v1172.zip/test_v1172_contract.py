from pathlib import Path
import ast,re
root=Path(__file__).resolve().parent
s=(root/'strategy_worker_v1.031.py').read_text(encoding='utf-8')
p=(root/'paper_bot_v1.039.py').read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.031'" in s
assert "VERSION = 'paper_bot_v1.039'" in p
assert '_v1037_trigger_occurrence__v1172_root' in s
assert "event_time_owner':'strategy_final_entry_qualification'" in s
assert "market_trigger_time_owner" in s
assert "quality_gate_pass_count_v1097':int(summary.get('rows',0))" in s
assert "quality_gate_block_count_v1097':0" in s
assert 's1_ready_current_cycle_at_v1172' in s and 'entry_qualified_at_v1172' in s
assert "main_cycle_candidate_first_v1172" in p
assert 'single_price_snapshot_v1172' in p
assert 'price_override: Optional[float]=None' in p
assert "schema=='trigger_occurrence_v1172' and owner=='strategy_final_entry_qualification'" in p
assert 'entry_qualification_to_paper_sec_v1172' in p
assert 'ACTUAL_ENTRY_RR_LOW' in p and 'SLIPPAGE_STALE' in p and 'SPREAD_OVER_LIMIT' in p
for token in ('V925_MIN_RR','V925_MIN_TARGET_ROOM_PCT','V977_MAX_TRIGGER_OVERSHOOT_PCT','V925_UNTRADABLE_SPREAD_PCT'):
    assert token in s
ast.parse(s); ast.parse(p)
print('PASS')
