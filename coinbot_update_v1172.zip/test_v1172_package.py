from pathlib import Path
import zipfile,hashlib
z=Path(__file__).resolve().parent/'coinbot_update_v1172.zip'
with zipfile.ZipFile(z) as f:
    assert f.testzip() is None
    names=set(f.namelist())
    assert 'strategy_worker_v1.031.py' in names and 'paper_bot_v1.039.py' in names
print('PASS')
