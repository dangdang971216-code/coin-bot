#!/usr/bin/env python3
from pathlib import Path
import ast, re
SRC=Path(__file__).with_name('coinbot_main_v2_13_1121.py')
text=SRC.read_text(encoding='utf-8')
mod=ast.parse(text)
from collections import Counter
names=Counter(n.name for n in mod.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)))
assert not {k:v for k,v in names.items() if v>1}, names
assert "BOT_VERSION = '수익형 v2.13.1121'" in text
assert "V650_BUILD_LABEL = 'v1161_main_ledger_summary_single_owner_2026-06-30'" in text
assert "운영 요약집 v1159" not in text
assert "· v1159 · TXT 1개" not in text
assert "return _v1161_compact_issue_ledger(body)" in text
assert "활성 issue 없음" not in text[text.index('def compact_command_output'):text.index('def build_command_summary_text')]
print('PASS v1161 contract')
