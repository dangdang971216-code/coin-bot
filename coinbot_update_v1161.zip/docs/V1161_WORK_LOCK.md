# v1161 작업 잠금
- 증상: 상세 TXT에는 한글 장부가 있으나 Telegram 통합 요약은 활성 issue 없음으로 오판.
- 실제 원인: 구 OPEN/CHECK 문자열 재파싱 reader, 중복 top-level issue renderer, v1159 고정 release label.
- 수정 owner: Main 표시·명령 요약만.
- 변경 금지: 후보·Gate·rank·TTL·RR·trigger·invalid·target·청산·OPEN 한도·자동매수.
- Guard/Paper/Strategy 소스와 자체 버전은 변경하지 않음.
