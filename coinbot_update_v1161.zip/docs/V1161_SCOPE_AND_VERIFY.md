# v1161 범위와 서버 검수
1. 다중명령 Telegram /issue_ledger가 빨강·노랑·초록 장부를 직접 표시.
2. `활성 issue 없음` 오판 0.
3. top-level 중복 정의 0.
4. Telegram 시작 알림과 TXT 제목 모두 v1161.
5. /readiness_board와 상세 TXT 내용 유지.
6. 신규 오류 0, 자동매수 OFF.

SYSTEM_REGRESSION 계약 digest와 trigger 지연은 owner가 달라 이번 버전에 섞지 않는다.
