#!/usr/bin/env python3
from pathlib import Path
import json
root=Path(__file__).parent
m=json.loads((root/'DEPLOY_BUNDLE.json').read_text())
assert m['version']=='v1161'
assert m['main']=='coinbot_main_v2_13_1121.py'
assert m['guard'] is None and m['paper'] is None and m['workers']=={}
assert m['auto_buy'] is False
for bad in ('paper_bot_open.json','paper_bot_closed.jsonl','trade_log.jsonl','issue_ledger_events.jsonl'):
    assert not (root/bad).exists()
print('PASS v1161 package')
