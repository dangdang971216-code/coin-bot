from __future__ import annotations
import copy, importlib.util, json, os, tempfile, time
from pathlib import Path
HERE=Path(__file__).resolve().parent
OLD=Path('/mnt/data/v1144_full/코인봇_최신전체코드_v1144_CHECK_20260629/strategy_worker_v1.014.py')
NEW=HERE/'strategy_worker_v1.015.py'

def load(path,name,base):
 os.environ['TRADING_BOT_DIR']=str(base)
 sp=importlib.util.spec_from_file_location(name,str(path)); m=importlib.util.module_from_spec(sp); sp.loader.exec_module(m); return m

def universe(n=459, per=106):
 out=[]
 for k in range(n):
  frames={}
  for j,tf in enumerate(('m1','m3','m5','m15','m30','h1','h2','h4')):
   rows=[]
   for i in range(per):
    ts=1780000000+i*60
    o=100+k*0.01+j+i*0.001; c=o+0.01; rows.append([ts,o,c,c+0.02,o-0.02,1000+i])
   frames[tf]=rows
  out.append({'ticker':f'T{k:03d}','candle_ts':1780000000+(per-1)*60,'structure_lab_candles':{'updated_ts':1000.0,'last_full_profile_fetch_ts':900.0,'sources':{tf:'official' for tf in frames},'frames':frames}})
 return out

def run(mod, items):
 for row in items:
  for tf in ('m1','m3','m5','m15','m30','h1','h2','h4'):
   mod._lab_rows(row,tf)

def main():
 with tempfile.TemporaryDirectory() as td:
  base=Path(td); old=load(OLD,'oldbench',base/'o'); new=load(NEW,'newbench',base/'n')
  items=universe()
  results={}
  for label,mod in [('old',old),('new',new)]:
   mod._STRUCTURE_LAB_NORMALIZED_FRAME_CACHE_V1109.clear(); mod._STRUCTURE_LAB_NORMALIZED_FRAME_STATS_V1109.clear()
   if hasattr(mod,'_STRUCTURE_LAB_NORMALIZED_FRAME_OBJECT_ID_V1147'): mod._STRUCTURE_LAB_NORMALIZED_FRAME_OBJECT_ID_V1147.clear()
   t=time.perf_counter(); run(mod,items); first=time.perf_counter()-t
   reload_items=copy.deepcopy(items)
   before=mod._lab_normalized_frame_stats_snapshot_v1109()
   t=time.perf_counter(); run(mod,reload_items); second=time.perf_counter()-t
   after=mod._lab_normalized_frame_stats_snapshot_v1109()
   results[label]={'first_sec':round(first,4),'reload_sec':round(second,4),'reload_hits':after['hits']-before['hits'],'reload_misses':after['misses']-before['misses'],'reload_parsed_rows':after['parsed_source_rows']-before['parsed_source_rows'],'cross_object_hits':after.get('stable_cross_object_hits',0)-before.get('stable_cross_object_hits',0)}
  results['result']='PASS'; results['frames']=459*8; results['rows_per_frame']=106
  print(json.dumps(results,indent=2))
if __name__=='__main__': main()
