# v1147 범위·검수

## 증상
Strategy cycle 약 24.6초, Structure Lab 약 6.4초. S1 6건이 Paper 도착 시 stale 계열로 전부 차단된 표본이 확인됐다.

## 코드로 확정한 원인
1. cycle 시작에서 34MB Candle checkpoint를 읽고 delta까지 합쳤는데 urgent publish가 같은 full file을 다시 읽었다.
2. 30초 단위 candidate_reason 진단도 같은 full file을 다시 읽었다.
3. Structure Lab fallback에도 직접 Candle reader가 남아 있었다.
4. normalized-frame cache key가 `id(rows)`를 사용해 JSON reload마다 동일 봉 3,672 frame을 새 자료로 오인했다.

## 수정
- full Candle reader owner를 `_v1014_load_candle_map()` 하나로 제한.
- Structure Lab/urgent publish는 run_once canonical map 재사용.
- display 진단은 `clean_candle_status.json` compact owner만 사용.
- cache key를 ticker/tf/Candle metadata/length/first·middle·last OHLCV signature로 교체.
- 실제 metadata 또는 frame 경계가 바뀌면 miss, 객체만 바뀌면 hit.

## 변경하지 않음
Gate, rank, quality threshold, TTL, trigger, invalid, target, RR, trailing, exit, OPEN 30, cycle 신규 3, Paper/Risk/Main/Guard, 후보 기준판, 자동매수.

## 로컬 검수
- py_compile PASS
- 같은 자료 JSON reload: hit
- 실제 봉/metadata 변경: miss
- v1.014와 normalized output exact
- 매매 핵심 함수 AST 동일
- 로컬 3,672-frame benchmark: reload miss 3,672→0, parsed rows 389,232→0

## 서버 완료 기준
- Strategy v1.015 runtime/hash/target 일치
- cycle 및 Structure Lab 시간이 반복 표본에서 감소
- normalized cache cross-object hits 발생, violations 0
- direct Candle full reader는 canonical owner 1개만 유지
- stale trigger/candidate 차단 변화는 관찰하되 결과를 미리 보장하지 않음
- 신규 오류 0, 자동매수 OFF
