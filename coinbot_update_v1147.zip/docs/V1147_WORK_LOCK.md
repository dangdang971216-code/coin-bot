# v1147 작업 잠금 — Strategy Candle 단일읽기 + stable completed-frame cache

- issue: STRATEGY-CYCLE-ROOT-1147 / OPEN
- 기준 서버: Strategy v1.014 / hash 26a676ca08715c6bfce17f42e7f6b4395a1e9175fe06e1c53db35c5647956f88
- 수정 파일: strategy_worker.py → strategy_worker_v1.015.py
- 전략 영향: 없음 / runtime reader·cache identity 수술만
- 자동매수: OFF 유지

## 코드로 확정한 원인
1. `run_once`가 `_v1014_load_candle_map()`으로 canonical Candle map을 이미 읽고 `_v510_publish(... candle_map_v1032=candle_map)`에 전달한다.
2. 그런데 `_v608_publish_candle_urgent_targets()` 내부 `_v608_candle_age_index()`가 `load_json(CANDLE)`을 다시 호출한다. 같은 34MB full checkpoint를 cycle 안에서 중복 파싱하며 delta merge가 반영된 canonical map도 버린다.
3. Structure Lab normalized-frame cache key가 `(tf, id(rows), len, first/middle/last)`이다. Candle JSON checkpoint reload 후 내용이 같아도 `id(rows)`가 바뀌어 전체 timeframe cache가 miss/eviction 된다.
4. 서버 증거: 4,361 lookups / 3,672 misses / 3,672 evictions / 388,661 source rows reparse / parse CPU 3.056s. Shadow proof는 object-id change 48,641건, exact equivalent 48,641건, violation 0건이다.

## 삭제할 구경로
- `_v608_candle_age_index()`의 직접 `load_json(CANDLE)` reader
- active normalized-frame cache key의 `id(rows)` ownership
- v1140 observation-only shadow 비교 실행 경로

## 새 본선
- `run_once` canonical Candle map → `_v510_publish` → Candle urgent age index가 동일 map을 읽음
- Candle metadata + timeframe + frame boundary signature가 normalized-frame cache identity를 소유
- 같은 내용의 새 JSON 객체는 cache hit, 실제 frame/metadata 변화는 miss

## 변경 금지
Gate, rank, quality threshold, TTL, trigger, invalid, target, RR, trailing, exit, OPEN 30, cycle 3, Paper/Risk/Main/Guard, 후보 기준판 계산, 원장, 자동매수.

## 추가 추적 결과
5. `candidate_reason` heavy display 경로의 `_v601_candle_priority_status()`도 30초마다 `load_json(CANDLE)`로 같은 full checkpoint를 다시 파싱했다.
6. `attach_structure_lab()`에는 active caller가 canonical map을 넘기는데도 직접 Candle 파일을 다시 읽는 legacy fallback이 남아 있었다.

## 최종 삭제 대상
- urgent age 계산의 직접 Candle full read
- candidate_reason display 진단의 직접 Candle full read
- Structure Lab의 직접 Candle fallback
- active cache identity의 `id(rows)`
- 증명 완료된 v1140 shadow 실행 경로

## 최종 단일본선
`run_once._v1014_load_candle_map()`만 full checkpoint + delta merge를 소유한다. 이후 Strategy의 Structure Lab과 urgent publish는 동일 canonical map을 읽고, display 진단은 Candle worker의 compact status만 읽는다.
