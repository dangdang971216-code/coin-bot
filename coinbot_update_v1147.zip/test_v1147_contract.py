#!/usr/bin/env python3
from __future__ import annotations
import ast
import copy
import importlib.util
import json
import os
import tempfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
NEW=HERE/'strategy_worker_v1.015.py'
OLD=Path('/mnt/data/v1144_full/코인봇_최신전체코드_v1144_CHECK_20260629/strategy_worker_v1.014.py')


def load_module(path: Path, name: str, base: Path):
    old=os.environ.get('TRADING_BOT_DIR')
    os.environ['TRADING_BOT_DIR']=str(base)
    try:
        spec=importlib.util.spec_from_file_location(name,str(path))
        mod=importlib.util.module_from_spec(spec)
        assert spec and spec.loader
        spec.loader.exec_module(mod)
        return mod
    finally:
        if old is None: os.environ.pop('TRADING_BOT_DIR',None)
        else: os.environ['TRADING_BOT_DIR']=old


def frame(seed: int, n: int=48):
    rows=[]
    for i in range(n):
        ts=1_780_000_000 + i*60
        o=100.0+seed+i*0.1
        c=o+0.03
        h=c+0.05
        l=o-0.04
        v=1000.0+i
        rows.append([ts,o,c,h,l,v])
    return rows


def candle_row(ticker: str='KRW-TEST', updated: float=1000.0):
    rows=frame(1)
    return {
        'ticker':ticker,
        'candle_ts':rows[-1][0],
        'structure_lab_candles':{
            'updated_ts':updated,
            'last_full_profile_fetch_ts':900.0,
            'sources':{'m1':'official_exchange_completed_candles_compact'},
            'frames':{'m1':rows},
        },
    }


def function_ast(path: Path, name: str):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    matches=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
    assert matches, f'missing function {name}'
    return ast.dump(matches[-1],include_attributes=False)


def main():
    with tempfile.TemporaryDirectory() as td:
        base=Path(td)
        new=load_module(NEW,'strategy_v1147_test',base)
        old=load_module(OLD,'strategy_v1144_test',base/'old')

        assert new.VERSION=='strategy_worker_v1.015'
        assert new.BUILD_LABEL=='v1147_strategy_candle_map_reuse_stable_frame_cache_2026-06-30'

        # 1) Same completed material after JSON reload must hit the active cache.
        new._STRUCTURE_LAB_NORMALIZED_FRAME_CACHE_V1109.clear()
        new._STRUCTURE_LAB_NORMALIZED_FRAME_OBJECT_ID_V1147.clear()
        new._STRUCTURE_LAB_NORMALIZED_FRAME_STATS_V1109.clear()
        a=candle_row()
        out1=new._lab_rows(a,'m1')
        b=json.loads(json.dumps(a))
        assert id(a['structure_lab_candles']['frames']['m1']) != id(b['structure_lab_candles']['frames']['m1'])
        out2=new._lab_rows(b,'m1')
        stats=new._lab_normalized_frame_stats_snapshot_v1109()
        assert out1==out2
        assert stats['misses']==1,stats
        assert stats['hits']==1,stats
        assert stats['stable_cross_object_hits']==1,stats

        # 2) A real boundary/metadata change must invalidate and rebuild.
        c=json.loads(json.dumps(a))
        c['structure_lab_candles']['frames']['m1'][-1][2]+=1.0
        c['candle_ts']+=60
        c['structure_lab_candles']['updated_ts']+=60
        out3=new._lab_rows(c,'m1')
        stats2=new._lab_normalized_frame_stats_snapshot_v1109()
        assert stats2['misses']==2,stats2
        assert out3!=out2

        # 3) Normalized output remains byte-for-byte equivalent to v1.014.
        old._STRUCTURE_LAB_NORMALIZED_FRAME_CACHE_V1109.clear()
        old._STRUCTURE_LAB_NORMALIZED_FRAME_STATS_V1109.clear()
        src=candle_row('KRW-EQ',2000.0)
        old_out=old._lab_rows(copy.deepcopy(src),'m1')
        new._STRUCTURE_LAB_NORMALIZED_FRAME_CACHE_V1109.clear()
        new._STRUCTURE_LAB_NORMALIZED_FRAME_OBJECT_ID_V1147.clear()
        new._STRUCTURE_LAB_NORMALIZED_FRAME_STATS_V1109.clear()
        new_out=new._lab_rows(copy.deepcopy(src),'m1')
        assert old_out==new_out

        # 4) Candle urgent age uses the already merged canonical map and never reads CANDLE.
        now=1_800_000_000.0
        new.now_ts=lambda: now
        canonical={'A':{'ticker':'A','candle_ts':now-30},'B':{'ticker':'B','candle_ts':now-90}}
        ages=new._v608_candle_age_index(canonical)
        assert ages=={'A':30.0,'B':90.0},ages
        age_src=function_ast(NEW,'_v608_candle_age_index')
        assert 'load_json' not in age_src
        assert 'CANDLE' not in age_src
        source_text=NEW.read_text(encoding='utf-8')
        assert source_text.count('load_json(CANDLE,{})') == 1, 'only _v1014_load_candle_map may read the full Candle checkpoint'
        diag_src=function_ast(NEW,'_v601_candle_priority_status')
        assert 'load_json(CANDLE' not in diag_src
        try:
            new.attach_structure_lab([], new.now_ts(), candle_map_override=None)
        except RuntimeError as exc:
            assert 'canonical candle_map is required' in str(exc)
        else:
            raise AssertionError('legacy direct Candle fallback remained active')

        # 5) Critical trading-contract functions and constants are unchanged.
        critical_functions=(
            'apply_swing_entry_gate','_v925_current_actual_plan','_swing_quality_gate',
            '_v554_apply_entry_plan_state__v1115','seal_canonical_candidate_keys',
        )
        for name in critical_functions:
            assert function_ast(OLD,name)==function_ast(NEW,name),name
        critical_constants=(
            'V925_MIN_RR','V925_MIN_TARGET_ROOM_PCT','V925_UNTRADABLE_SPREAD_PCT',
            'V977_MAX_TRIGGER_OVERSHOOT_PCT','STRUCTURE_LAB_RECOMPUTE_BUDGET',
            'STRUCTURE_LAB_LIVE_METHOD_BUDGET','STRUCTURE_EVENT_DELIVERY_TTL_SEC',
        )
        for name in critical_constants:
            assert getattr(old,name)==getattr(new,name),(name,getattr(old,name),getattr(new,name))

        print(json.dumps({
            'result':'PASS',
            'version':new.VERSION,
            'stable_reload':{'misses':stats['misses'],'hits':stats['hits'],'cross_object_hits':stats['stable_cross_object_hits']},
            'real_change_miss':stats2['misses'],
            'normalized_output_exact':True,
            'direct_candle_reload_retired':True,
            'critical_trade_functions_unchanged':list(critical_functions),
            'critical_constants_unchanged':list(critical_constants),
            'auto_buy':False,
        },ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
