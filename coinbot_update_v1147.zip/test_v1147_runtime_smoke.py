#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import tempfile
from pathlib import Path

SRC=Path(__file__).resolve().parent/'strategy_worker_v1.015.py'

def main():
    with tempfile.TemporaryDirectory() as td:
        os.environ['TRADING_BOT_DIR']=td
        spec=importlib.util.spec_from_file_location('strategy_v1147_smoke',str(SRC))
        mod=importlib.util.module_from_spec(spec); assert spec and spec.loader; spec.loader.exec_module(mod)
        now=mod.now_ts()
        mod.CANDLE_URGENT_TARGETS=Path(td)/'urgent.json'
        mod.CANDLE_URGENT_RESULT=Path(td)/'urgent_result.json'
        rows=[{'ticker':'KRW-TEST','s_stage':'S1','current_price':100.0,'final_trade_state':'S1_PASS'}]
        cmap={'KRW-TEST':{'ticker':'KRW-TEST','candle_ts':now-100}}
        original=mod.load_json
        calls=[]
        def guarded(path,default=None):
            calls.append(str(path))
            if Path(path)==mod.CANDLE:
                raise AssertionError('retired direct Candle full reload was called')
            return original(path,default)
        mod.load_json=guarded
        summary=mod._v608_publish_candle_urgent_targets(rows,now,cmap)
        assert summary['request_count']==1,summary
        payload=json.loads(mod.CANDLE_URGENT_TARGETS.read_text(encoding='utf-8'))
        assert payload['direct_full_candle_reload_retired_v1147'] is True
        assert payload['candle_age_source_v1147']=='run_once canonical candle_map with merged delta'
        assert str(mod.CANDLE) not in calls
        print(json.dumps({'result':'PASS','request_count':summary['request_count'],'direct_candle_reads':0,'version':mod.VERSION},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
