코인봇 v2192 단일 진실 복구

목적
- Paper 0전 초기화와 별개였던 Strategy-V2 Paper exact 성과책을 같은 epoch로 정렬
- 상승예측 통과 현재행만 S1 hold와 Paper receipt에 전달
- Review는 한 event_key 집합으로 시간대·항목별 정확도를 계산
- /version_score와 /trade_review는 같은 봉인 snapshot을 사용

변경하지 않음
- 상승예측 점수·임계값
- 구조선·Trigger·Invalid·Target·RR
- Paper 비용·청산 공식
- 과거 CLOSED/event 원장
- 자동매수 OFF

서버 적용 전 LOCAL PASS, 서버 적용 후 CHECK 필요
