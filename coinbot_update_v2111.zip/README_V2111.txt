coinbot_update_v2111.zip

목적
- v2110 실제 후보흐름은 있었지만 Strategy 구조계약 status 0, Paper 계약누락, Review snapshot 미생성 상태 수리
- manifest workers에 Strategy/Review를 명시하여 alias·restart·release verify 범위 강제
- Strategy active cycle 모든 후보에 계약 100%를 후보/S1 commit 직전 재증명
- 미완성 계약은 후보를 삭제하지 않고 RECHECK, S1 강제승격 없음
- Review atomic candidate snapshot 정확히 읽고 오늘 TOP·entry failure·shake·weak entry·구조판 독립 저장
- /reset_readiness가 RESET_READY일 때만 /pzero_reset 실행
- 기존 OPEN/과거 원장/Shadow 변경 없음, 자동매수 OFF

버전
- Main 수익형 v2.13.2093
- Paper paper_bot_v2.064
- Strategy strategy_worker_v2.031
- Review review_worker_v2.040
- Guard guard_v2.6.10
