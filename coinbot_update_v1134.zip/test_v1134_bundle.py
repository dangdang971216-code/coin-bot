from pathlib import Path
import json, py_compile, zipfile, re
root=Path(__file__).resolve().parent
m=json.loads((root/'DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert m['version']=='v1134'
assert m['paper']=='paper_bot_v1.021.py'
assert not m.get('main')
assert m.get('workers')=={}
assert m['auto_buy'] is False
required=[m['paper'],*m['support_files']]
missing=[x for x in required if not (root/x).exists()]
assert not missing,missing
for p in root.rglob('*.py'):
    py_compile.compile(str(p),doraise=True)
print('PASS v1134 paper-only bundle')
