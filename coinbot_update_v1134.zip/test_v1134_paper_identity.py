from pathlib import Path
import re, ast, importlib.util, tempfile, os, hashlib
p=Path(__file__).resolve().parent/'paper_bot_v1.021.py'
s=p.read_text(encoding='utf-8')
versions=re.findall(r"^\s*VERSION\s*=\s*['\"]([^'\"]+)",s,re.M)
builds=re.findall(r"^\s*BUILD_LABEL\s*=\s*['\"]([^'\"]+)",s,re.M)
assert versions and versions[-1]=='paper_bot_v1.021', versions[-3:]
assert builds and builds[-1]=='v1133_qualified_trigger_occurrence_freshness_contract_2026-06-29', builds[-3:]
assert p.name.startswith(versions[-1])
assert 'def trigger_occurrence_freshness_v1133' in s
assert 'STALE_TRIGGER_OCCURRENCE' in s
assert 'WAIT_NEW_REBREAK' in s
assert 'TRIGGER_OCCURRENCE_TIME_INVALID' in s
ast.parse(s)
# Runtime import must expose the same final identity.
with tempfile.TemporaryDirectory() as td:
    os.environ['TRADING_BOT_DIR']=td
    spec=importlib.util.spec_from_file_location('paper_v1134',p)
    m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    assert m.VERSION=='paper_bot_v1.021',m.VERSION
    assert m.BUILD_LABEL=='v1133_qualified_trigger_occurrence_freshness_contract_2026-06-29',m.BUILD_LABEL
print('PASS v1134 paper exact identity and v1133 contract presence')
