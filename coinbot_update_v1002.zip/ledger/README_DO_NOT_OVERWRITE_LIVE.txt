이 폴더는 배포 변경기록 seed만 포함합니다.
서버의 OPEN/CLOSED/trade_log/decision/change_verify/issue 원장을 덮어쓰거나 삭제하지 마십시오.
