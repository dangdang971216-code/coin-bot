import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('sr',ROOT/'structure_rebuild_worker_v0.1.py')
sr=importlib.util.module_from_spec(spec); spec.loader.exec_module(sr)


def test_valid_order():
    assert sr.valid_order({'invalid':90,'trigger':100,'target':120})
    assert not sr.valid_order({'invalid':100,'trigger':100,'target':120})


def test_complete_v1211_is_preserved():
    old={'invalid':90,'trigger':100,'target':130}
    cur={'invalid':95,'trigger':105,'target':115}
    draft,owner=sr.correction_draft(old,cur)
    assert draft==old
    assert owner=={'trigger':'v1211','invalid':'v1211','target':'v1211'}


def test_current_only_fills_missing_axis():
    old={'invalid':90,'trigger':100,'target':None}
    cur={'invalid':95,'trigger':105,'target':120}
    draft,owner=sr.correction_draft(old,cur)
    assert draft['invalid']==90 and draft['trigger']==100 and draft['target']==120
    assert owner['target']=='current_fill_missing'


def test_current_repairs_invalid_order_without_replacing_valid_axes():
    old={'invalid':101,'trigger':100,'target':130}
    cur={'invalid':95,'trigger':105,'target':120}
    draft,owner=sr.correction_draft(old,cur)
    assert sr.valid_order(draft)
    assert draft['target']==130
    assert owner['invalid']=='current_repair_invalid_order'


def test_plan_metrics_actual_entry_and_cost():
    m=sr.plan_metrics({'invalid':90,'trigger':100,'target':125},105,0.2)
    assert m['ordered'] and m['entry_valid']
    assert m['entry_rr_after_cost']>1


def test_no_candidate_filter_contract_in_source():
    text=(ROOT/'structure_rebuild_worker_v0.1.py').read_text()
    assert 'candidate_filtering": False' in text
    assert 'auto_buy": False' in text
    assert 'Strategy,' in text or 'Strategy' in text


def test_process_once_writes_snapshot_without_trading_changes(tmp_path):
    import json
    class Paths:
        def __init__(self, base):
            self.review_request=base/'review_request.json'
            self.strategy_candidates=base/'candidates.json'
    class FakeReview:
        SpinePaths=Paths
        @staticmethod
        def read_json(path, default=None):
            try: return json.loads(path.read_text())
            except Exception: return default
        @staticmethod
        def _v1241_request_generation(req):
            c=req.get('pipeline_cycle_id'); m=req.get('candidate_commit_id')
            return {'cycle_id':c,'candidate_commit_id':m,'generation_key':f'{c}|{m}' if c and m else ''}
        @staticmethod
        def _v1241_stable_committed_rows(base, request, require_pipeline=False):
            rows=json.loads((base/'candidates.json').read_text())
            return rows, {'candidate_rows':len(rows),'canonical_s1_rows':sum(1 for r in rows if r.get('s_stage')=='S1'),'candidate_file_sha256':'abc'}
        @staticmethod
        def read_candidate_rows(path, limit): return json.loads(path.read_text())
        @staticmethod
        def stage(row): return row.get('s_stage')
        @staticmethod
        def _v1233_ticker(row): return row.get('ticker')
        @staticmethod
        def _v1233_price(row): return row.get('price')
        @staticmethod
        def _v1237_cost(row): return 0.2
        @staticmethod
        def _v1236_line(row,name): return row['dynamic_structure_plan_v1212'][name]
        @staticmethod
        def _v1236_line_price(line): return line.get('price')
    rows=[{
        'ticker':'AAA','price':105,'s_stage':'S1',
        'dynamic_structure_plan_v1212':{'trigger':{'price':102},'invalid':{'price':96},'target':{'price':118}},
        'v1211_structure_shadow_v1222':{'trigger':{'rounded_price':100},'invalid':{'rounded_price':90},'target':{'rounded_price':130}}
    }]
    (tmp_path/'review_request.json').write_text(json.dumps({'pipeline_cycle_id':'c1','candidate_commit_id':'m1'}))
    (tmp_path/'candidates.json').write_text(json.dumps(rows))
    sr._REVIEW=FakeReview
    snap=sr.process_once(tmp_path)
    assert snap['comparison']['counts']['s1_both_complete']==1
    assert snap['invariants']['s1_changed'] is False
    assert snap['invariants']['entry_changed'] is False
    assert snap['invariants']['auto_buy'] is False
    assert (tmp_path/'canonical_structure_rebuild_audit_v1253.json').exists()
