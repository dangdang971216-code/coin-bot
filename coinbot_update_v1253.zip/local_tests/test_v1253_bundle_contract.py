import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def test_versions_and_worker_manifest():
    manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text())
    assert manifest['version']=='v1253'
    assert manifest['main']=='coinbot_main_v2_13_1158.py'
    assert manifest['guard']=='backga_guard_bot_v2_5_232.py'
    assert manifest['workers']['structure_rebuild']=='structure_rebuild_worker_v0.1.py'
    assert manifest['actual_trading_changed'] is False
    assert manifest['auto_buy'] is False

def test_main_and_guard_commands():
    main=(ROOT/'coinbot_main_v2_13_1158.py').read_text()
    guard=(ROOT/'backga_guard_bot_v2_5_232.py').read_text()
    assert '수익형 v2.13.1158' in main
    assert '"structure_rebuild": render_structure_rebuild' in main
    assert '/gstructure_rebuild' in guard
    assert 'tradingbot-structure-rebuild-worker' in guard

def test_no_live_ledgers_packaged():
    forbidden={'paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.jsonl','paper_decision_state_v926.json'}
    names={p.name for p in ROOT.rglob('*') if p.is_file()}
    assert not (names & forbidden)
