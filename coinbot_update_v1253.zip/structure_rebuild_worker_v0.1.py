#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot v1253 structure rebuild audit worker.

Read-only audit that compares the v1211 previous structure selection with the
current v1212+ dynamic structure on the same committed candidate generation.
It also builds a conservative draft where v1211 is the base and current lines
only fill a missing or invalid v1211 axis.  Nothing here changes Strategy,
Paper, OPEN/CLOSED, candidate rank, S1, entry, exit, or auto-buy.
"""
from __future__ import annotations

import argparse
import fcntl
import importlib
import json
import math
import os
import signal
import time
import traceback
from collections import Counter
from pathlib import Path
from statistics import median
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

VERSION = "structure_rebuild_worker_v0.1"
BUILD_LABEL = "v1253_v1211_structure_root_audit_and_current_correction_draft_2026-07-05"
SNAPSHOT_SCHEMA = "canonical_structure_rebuild_audit_v1253"
STATUS_SCHEMA = "structure_rebuild_worker_status_v1253"
EVENT_SCHEMA = "structure_rebuild_audit_event_v1253"
DEFAULT_INTERVAL_SEC = 5.0
_STOP = False
_REVIEW: Optional[Any] = None


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    from datetime import datetime, timezone, timedelta
    return datetime.fromtimestamp(float(ts if ts is not None else now_ts()), timezone(timedelta(hours=9))).strftime("%Y-%m-%d %H:%M:%S KST")


def base_dir() -> Path:
    raw = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(raw).expanduser().resolve() if raw else Path(__file__).resolve().parent


def snapshot_path(base: Path) -> Path:
    return base / "canonical_structure_rebuild_audit_v1253.json"


def status_path(base: Path) -> Path:
    return base / "clean_structure_rebuild_worker_status.json"


def state_path(base: Path) -> Path:
    return base / "structure_rebuild_audit_state_v1253.json"


def event_path(base: Path) -> Path:
    return base / "structure_rebuild_audit_events_v1253.jsonl"


def lock_path(base: Path) -> Path:
    return base / ".structure_rebuild_worker.lock"


def error_path(base: Path) -> Path:
    return base / "clean_structure_rebuild_worker_error.log"


def finite(value: Any) -> Optional[float]:
    try:
        out = float(value)
        return out if math.isfinite(out) else None
    except (TypeError, ValueError, OverflowError):
        return None


def integer(value: Any, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError, OverflowError):
        return default


def read_json(path: Path, default: Any = None) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return default


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    tmp = path.with_name(f".{path.name}.{os.getpid()}.{time.time_ns()}.tmp")
    with tmp.open("w", encoding="utf-8") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def append_jsonl(path: Path, payload: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    line = json.dumps(dict(payload), ensure_ascii=False, sort_keys=True, separators=(",", ":")) + "\n"
    with path.open("a", encoding="utf-8") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        handle.write(line)
        handle.flush()
        os.fsync(handle.fileno())
        fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def load_review() -> Any:
    global _REVIEW
    if _REVIEW is None:
        module = importlib.import_module("review_worker")
        required = (
            "SpinePaths", "read_candidate_rows", "read_json", "stage",
            "_v1241_request_generation", "_v1241_stable_committed_rows",
            "_v1233_ticker", "_v1233_price", "_v1236_line", "_v1236_line_price", "_v1237_cost",
        )
        missing = [name for name in required if not hasattr(module, name)]
        if missing:
            raise RuntimeError("Review owner contract missing: " + ",".join(missing))
        _REVIEW = module
    return _REVIEW


def line_price(obj: Any) -> Optional[float]:
    if not isinstance(obj, Mapping):
        return None
    for key in ("rounded_price", "raw_price", "price", "value"):
        value = finite(obj.get(key))
        if value is not None and value > 0:
            return value
    return None


def current_lines(review: Any, row: Mapping[str, Any]) -> Dict[str, Optional[float]]:
    out: Dict[str, Optional[float]] = {}
    for name in ("trigger", "invalid", "target"):
        raw = review._v1236_line(dict(row), name)
        out[name] = finite(review._v1236_line_price(raw))
    return out


def previous_lines(row: Mapping[str, Any]) -> Dict[str, Optional[float]]:
    shadow = row.get("v1211_structure_shadow_v1222") if isinstance(row.get("v1211_structure_shadow_v1222"), Mapping) else {}
    return {name: line_price(shadow.get(name)) for name in ("trigger", "invalid", "target")}


def valid_order(lines: Mapping[str, Any]) -> bool:
    t = finite(lines.get("trigger")); i = finite(lines.get("invalid")); g = finite(lines.get("target"))
    return bool(t is not None and i is not None and g is not None and 0 < i < t < g)


def plan_metrics(lines: Mapping[str, Any], entry: Optional[float], cost_pct: float) -> Dict[str, Any]:
    trigger = finite(lines.get("trigger")); invalid = finite(lines.get("invalid")); target = finite(lines.get("target"))
    ordered = valid_order(lines)
    structure_risk = ((trigger - invalid) / trigger * 100.0) if ordered and trigger and invalid else None
    structure_room = ((target - trigger) / trigger * 100.0) if ordered and trigger and target else None
    structure_rr = (structure_room / structure_risk) if structure_risk and structure_room is not None else None
    entry_valid = bool(entry is not None and invalid is not None and target is not None and invalid < entry < target)
    entry_risk = ((entry - invalid) / entry * 100.0) if entry_valid and entry else None
    entry_room = ((target - entry) / entry * 100.0) if entry_valid and entry else None
    net_room = (entry_room - cost_pct) if entry_room is not None else None
    entry_rr = (net_room / entry_risk) if entry_risk and net_room is not None else None
    return {
        "ordered": ordered,
        "entry_valid": entry_valid,
        "structure_risk_pct": structure_risk,
        "structure_room_pct": structure_room,
        "structure_rr": structure_rr,
        "entry_risk_pct": entry_risk,
        "entry_room_pct": entry_room,
        "entry_net_room_pct": net_room,
        "entry_rr_after_cost": entry_rr,
    }


def correction_draft(previous: Mapping[str, Any], current: Mapping[str, Any]) -> Tuple[Dict[str, Optional[float]], Dict[str, str]]:
    """Use v1211 as the root. Current lines may only repair a missing/invalid axis."""
    draft = {name: finite(previous.get(name)) for name in ("trigger", "invalid", "target")}
    owner = {name: "v1211" if draft[name] is not None else "missing" for name in draft}
    for name in ("trigger", "invalid", "target"):
        if draft[name] is None:
            cur = finite(current.get(name))
            if cur is not None:
                draft[name] = cur
                owner[name] = "current_fill_missing"
    if valid_order(draft):
        return draft, owner
    # Repair only the axis that violates ordering; never replace a valid v1211 trio.
    cur = {name: finite(current.get(name)) for name in ("trigger", "invalid", "target")}
    if not valid_order(cur):
        return draft, owner
    trigger = draft.get("trigger")
    invalid = draft.get("invalid")
    target = draft.get("target")
    if trigger is None or invalid is None or not (0 < invalid < trigger):
        draft["invalid"] = cur["invalid"]; owner["invalid"] = "current_repair_invalid_order"
    trigger = draft.get("trigger"); target = draft.get("target")
    if trigger is None or target is None or not (trigger < target):
        draft["target"] = cur["target"]; owner["target"] = "current_repair_target_order"
    if not valid_order(draft):
        draft["trigger"] = cur["trigger"]; owner["trigger"] = "current_repair_trigger_order"
    return draft, owner


def pct_diff(a: Optional[float], b: Optional[float], base: Optional[float]) -> Optional[float]:
    if a is None or b is None or base is None or base <= 0:
        return None
    return (a - b) / base * 100.0


def med(values: Sequence[float]) -> Optional[float]:
    return float(median(values)) if values else None


def bounded_sample(row: Mapping[str, Any], current: Mapping[str, Any], previous: Mapping[str, Any], draft: Mapping[str, Any], owners: Mapping[str, str], review: Any) -> Dict[str, Any]:
    return {
        "ticker": str(review._v1233_ticker(dict(row)) or ""),
        "stage": str(review.stage(dict(row)) or ""),
        "entry_price": finite(review._v1233_price(dict(row))),
        "current": dict(current),
        "v1211": dict(previous),
        "v1211_plus_current_correction_draft": dict(draft),
        "draft_axis_owner": dict(owners),
    }


def summarize_rows(review: Any, rows: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    counts = Counter()
    diffs: Dict[str, list[float]] = {"trigger": [], "invalid": [], "target": [], "risk": [], "room": [], "rr": []}
    stage_counts = Counter()
    samples: list[Dict[str, Any]] = []
    s1_samples: list[Dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        stage = str(review.stage(row) or "").upper()
        stage_counts[stage or "UNKNOWN"] += 1
        if stage == "S1": counts["s1_rows"] += 1
        entry = finite(review._v1233_price(row))
        cost = max(0.0, finite(review._v1237_cost(row)) or 0.0)
        cur = current_lines(review, row)
        old = previous_lines(row)
        cur_m = plan_metrics(cur, entry, cost)
        old_m = plan_metrics(old, entry, cost)
        cur_ok = bool(cur_m["ordered"]); old_ok = bool(old_m["ordered"])
        counts["current_complete"] += int(cur_ok)
        counts["v1211_complete"] += int(old_ok)
        counts["both_complete"] += int(cur_ok and old_ok)
        counts["current_only_complete"] += int(cur_ok and not old_ok)
        counts["v1211_only_complete"] += int(old_ok and not cur_ok)
        counts["neither_complete"] += int(not cur_ok and not old_ok)
        if stage == "S1":
            counts["s1_current_complete"] += int(cur_ok)
            counts["s1_v1211_complete"] += int(old_ok)
            counts["s1_both_complete"] += int(cur_ok and old_ok)
        draft, owners = correction_draft(old, cur)
        draft_m = plan_metrics(draft, entry, cost)
        counts["draft_complete"] += int(draft_m["ordered"])
        counts["draft_uses_current_fill"] += int(any(str(v).startswith("current_") for v in owners.values()))
        counts["draft_preserves_full_v1211"] += int(old_ok and owners == {"trigger":"v1211","invalid":"v1211","target":"v1211"})
        if cur_ok and old_ok and entry:
            for name in ("trigger", "invalid", "target"):
                d = pct_diff(finite(old.get(name)), finite(cur.get(name)), entry)
                if d is not None: diffs[name].append(d)
            old_risk = finite(old_m.get("entry_risk_pct")); cur_risk = finite(cur_m.get("entry_risk_pct"))
            old_room = finite(old_m.get("entry_room_pct")); cur_room = finite(cur_m.get("entry_room_pct"))
            old_rr = finite(old_m.get("entry_rr_after_cost")); cur_rr = finite(cur_m.get("entry_rr_after_cost"))
            if old_risk is not None and cur_risk is not None: diffs["risk"].append(old_risk-cur_risk)
            if old_room is not None and cur_room is not None: diffs["room"].append(old_room-cur_room)
            if old_rr is not None and cur_rr is not None: diffs["rr"].append(old_rr-cur_rr)
            counts["v1211_target_farther"] += int((old.get("target") or 0) > (cur.get("target") or 0))
            counts["current_target_farther"] += int((cur.get("target") or 0) > (old.get("target") or 0))
            counts["v1211_invalid_wider"] += int((old.get("invalid") or 0) < (cur.get("invalid") or 0))
            counts["current_invalid_wider"] += int((cur.get("invalid") or 0) < (old.get("invalid") or 0))
            counts["v1211_trigger_earlier"] += int((old.get("trigger") or 0) < (cur.get("trigger") or 0))
            counts["current_trigger_earlier"] += int((cur.get("trigger") or 0) < (old.get("trigger") or 0))
        if len(samples) < 12 and (old_ok or cur_ok):
            samples.append(bounded_sample(row, cur, old, draft, owners, review))
        if stage == "S1" and len(s1_samples) < 12:
            s1_samples.append(bounded_sample(row, cur, old, draft, owners, review))
    return {
        "counts": dict(counts),
        "stage_counts": dict(stage_counts),
        "median_v1211_minus_current": {
            "trigger_pct_of_entry": med(diffs["trigger"]),
            "invalid_pct_of_entry": med(diffs["invalid"]),
            "target_pct_of_entry": med(diffs["target"]),
            "entry_risk_pct_point": med(diffs["risk"]),
            "entry_room_pct_point": med(diffs["room"]),
            "entry_rr_after_cost": med(diffs["rr"]),
        },
        "samples": samples,
        "s1_samples": s1_samples,
    }


def pair_reference(base: Path) -> Dict[str, Any]:
    review = read_json(base / "canonical_version_score_review_v1237.json", {}) or {}
    pair = review.get("paired_matchup_v1241") if isinstance(review, Mapping) and isinstance(review.get("paired_matchup_v1241"), Mapping) else {}
    unlimited = pair.get("unlimited") if isinstance(pair, Mapping) and isinstance(pair.get("unlimited"), Mapping) else {}
    practical = pair.get("practical") if isinstance(pair, Mapping) and isinstance(pair.get("practical"), Mapping) else {}
    return {
        "available_pair_rows": integer(pair.get("available_pair_rows")) if isinstance(pair, Mapping) else 0,
        "entry_ready_pairs": integer(pair.get("entry_ready_pairs")) if isinstance(pair, Mapping) else 0,
        "unlimited_closed_event_count": integer(unlimited.get("closed_event_count")),
        "practical_closed_event_count": integer(practical.get("closed_event_count")),
        "unlimited_paired_deltas": unlimited.get("paired_deltas") if isinstance(unlimited.get("paired_deltas"), Mapping) else {},
        "practical_paired_deltas": practical.get("paired_deltas") if isinstance(practical.get("paired_deltas"), Mapping) else {},
        "winner_allowed": False,
    }


def process_once(base: Path) -> Dict[str, Any]:
    started = time.monotonic()
    review = load_review()
    paths = review.SpinePaths(base)
    request = review.read_json(paths.review_request, {}) or {}
    generation = review._v1241_request_generation(request)
    if not generation.get("generation_key"):
        cycle = str(request.get("pipeline_cycle_id") or request.get("candidate_pipeline_cycle_id_v1150") or "").strip()
        commit = str(request.get("candidate_commit_id") or request.get("candidate_commit_id_v1150") or "").strip()
        generation = {"cycle_id": cycle, "candidate_commit_id": commit, "generation_key": f"{cycle}|{commit}" if cycle and commit else ""}
    rows, integrity = review._v1241_stable_committed_rows(base, request, require_pipeline=False)
    summary = summarize_rows(review, rows)
    pair = pair_reference(base)
    state = read_json(state_path(base), {}) or {}
    processed = state.get("processed_generations") if isinstance(state.get("processed_generations"), Mapping) else {}
    generation_key = str(generation.get("generation_key") or "")
    new_generation = bool(generation_key and generation_key not in processed)
    if new_generation:
        append_jsonl(event_path(base), {
            "schema": EVENT_SCHEMA, "event": "GENERATION_AUDITED", "ts": now_ts(), "text": now_text(),
            "generation": dict(generation), "counts": summary.get("counts"),
            "actual_trading_changed": False, "auto_buy": False,
        })
        processed = dict(processed)
        processed[generation_key] = {"ts": now_ts(), "cycle_id": generation.get("cycle_id"), "candidate_commit_id": generation.get("candidate_commit_id")}
        # Keep only recent 500 audit identities; append-only jsonl is the durable history.
        if len(processed) > 500:
            processed = dict(sorted(processed.items(), key=lambda item: finite((item[1] or {}).get("ts")) or 0.0)[-500:])
        state = {"schema":"structure_rebuild_audit_state_v1253","processed_generations":processed,"last_generation":dict(generation),"updated_ts":now_ts()}
        atomic_write_json(state_path(base), state)
    counts = summary.get("counts") if isinstance(summary.get("counts"), Mapping) else {}
    state_name = "COLLECTING_V1211_ROOT_AUDIT"
    if not generation_key:
        state_name = "CHECK_GENERATION_IDENTITY"
    elif integer(counts.get("both_complete")) == 0:
        state_name = "CHECK_NO_COMPARABLE_STRUCTURE_ROWS"
    elif integer(counts.get("s1_both_complete")) == 0:
        state_name = "COLLECTING_NO_COMPARABLE_S1"
    snapshot = {
        "schema": SNAPSHOT_SCHEMA,
        "version": VERSION,
        "build": BUILD_LABEL,
        "mode": "SHADOW_ONLY_READ_ONLY",
        "state": state_name,
        "generated_ts": now_ts(),
        "generated_text": now_text(),
        "cycle_elapsed_sec": round(time.monotonic()-started, 6),
        "generation": {
            "cycle_id": generation.get("cycle_id"), "candidate_commit_id": generation.get("candidate_commit_id"),
            "generation_key": generation_key, "candidate_file_sha256": integrity.get("candidate_file_sha256"),
            "committed_rows": integrity.get("candidate_rows") or integrity.get("row_count"),
            "committed_s1_rows": integrity.get("canonical_s1_rows"),
            "new_generation_audited": new_generation,
        },
        "comparison": summary,
        "pair_reference": pair,
        "contracts": {
            "root": "v1211 previous structure selection",
            "current_role": "correction evidence and missing/invalid axis repair only",
            "draft_rule": "preserve a valid complete v1211 trio; current lines may fill missing or repair invalid order only",
            "candidate_filtering": False,
            "policy_competition_role": "secondary analysis only",
            "winner_allowed": False,
        },
        "next_stage": {
            "after_audit": "build v1211-root plus current evidence scoring and later fast-failure/profit-extension exits",
            "requires_before_live": ["same candidate/entry/time/cost comparison", "exact close sample", "cost-after positive", "big-loss reduction", "profit-giveback reduction"],
        },
        "invariants": {
            "strategy_writer_changed": False, "review_writer_changed": False, "paper_writer_changed": False,
            "candidate_rank_changed": False, "s1_changed": False, "entry_changed": False, "exit_changed": False,
            "existing_open_changed": False, "core_ledgers_changed": False, "auto_buy": False,
        },
    }
    atomic_write_json(snapshot_path(base), snapshot)
    status = {
        "schema": STATUS_SCHEMA, "version": VERSION, "build": BUILD_LABEL, "pid": os.getpid(),
        "state": "NORMAL" if state_name.startswith("COLLECTING") else state_name,
        "health_state": state_name, "updated_ts": now_ts(), "updated_text": now_text(),
        "last_sec": snapshot["cycle_elapsed_sec"], "rows": integer((snapshot.get("generation") or {}).get("committed_rows")),
        "both_complete": integer(counts.get("both_complete")), "s1_both_complete": integer(counts.get("s1_both_complete")),
        "draft_complete": integer(counts.get("draft_complete")), "error": "", "auto_buy": False,
    }
    atomic_write_json(status_path(base), status)
    return snapshot


def write_error(base: Path, exc: BaseException) -> None:
    text = f"[{now_text()}] {type(exc).__name__}: {exc}\n{traceback.format_exc()[-8000:]}\n"
    with error_path(base).open("a", encoding="utf-8") as handle:
        handle.write(text)
    atomic_write_json(status_path(base), {
        "schema": STATUS_SCHEMA, "version": VERSION, "build": BUILD_LABEL, "pid": os.getpid(),
        "state": "CHECK", "health_state": "CHECK_RUNTIME_ERROR", "updated_ts": now_ts(), "updated_text": now_text(),
        "error": f"{type(exc).__name__}: {exc}", "auto_buy": False,
    })


def acquire_lock(base: Path) -> Any:
    handle = lock_path(base).open("a+")
    fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    return handle


def stop_handler(_signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SEC)
    args = parser.parse_args()
    base = base_dir(); base.mkdir(parents=True, exist_ok=True)
    try:
        lock = acquire_lock(base)
    except OSError:
        return 2
    signal.signal(signal.SIGTERM, stop_handler); signal.signal(signal.SIGINT, stop_handler)
    try:
        while not _STOP:
            try:
                process_once(base)
            except Exception as exc:
                write_error(base, exc)
            if args.once:
                break
            time.sleep(max(1.0, float(args.interval)))
    finally:
        try: fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        except OSError: pass
        lock.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
