코인봇 v2200

목적
- v2199 파일은 교체됐지만 명령 등록 코드가 main() 아래에 있어 실제 런타임이 v2198을 계속 사용한 순서 오류 수정

수정
- 기존 중간 main() 호출 제거
- v2200 /trade_review·/version_score 등록 완료 후 파일 마지막에서 main() 한 번만 실행
- v2199 직접 formula replay 기능과 출력은 그대로 유지

변경 없음
- v2198 상승예측 본선식
- 후보·S1·Paper 접수
- 구조선·Trigger·Invalid·Target·RR
- Paper 비용·청산·성과 초기화
- 모든 과거 원장
- 새 명령·새 Shadow·새 장치
- 자동매수 OFF

LOCAL PASS / SERVER CHECK
