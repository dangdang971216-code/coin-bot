coinbot_update_v1365.zip

목적: Paper가 S1을 읽고도 선택 0/OPEN 0일 때 후보별 최종 사유를 남긴다.
범위: paper only. Strategy/Main/Guard/trigger/invalid/target/RR/청산계약/자동매수 변경 없음.
적용 후: /gupgrade_bundle 단독 실행 -> /grelease_verify -> /flow_map_full /version_score -> /gpaper_selector_audit.
