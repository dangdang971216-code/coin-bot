coinbot_update_v1604.zip

목적: 운영정리판. 오늘 성과/v1603 이후/전체누적 참고를 분리하고, 정보없음 이유·운영지도 stale·runtime 주인을 쉽게 표시한다.

변경 범위: Main 표시 전용(bot.py, coinbot_main_v2_13_1604.py).
변경 없음: 후보 기준, Gate, RR, trigger/invalid/target 공식, 청산, OPEN 제한, 원장 삭제/재작성, 자동매수 OFF.
상태: LOCAL_DONE / SERVER_CHECK.
검수: /ops_runtime, /version_score, /data_pipeline, /flow_map_full, /errorlog
