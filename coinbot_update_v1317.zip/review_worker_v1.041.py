#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Coinbot Review worker v1.040 / v1312.

Single owner for observation, candidate-standard, and read-only trade review.
The worker never changes Strategy candidate decisions, Paper OPEN/CLOSED, or
trading rules. It consumes the immutable Strategy generation committed before
handoff and the canonical Paper performance snapshot.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import math
import statistics
import atexit
import fcntl
import os
import signal
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Dict, Optional

from canonical_spine_v1187 import (
    AUTO_BUY,
    SPINE_SCHEMA,
    STRATEGY_MODE,
    SpinePaths,
    append_jsonl,
    atomic_write_json,
    build_candidate_standard,
    build_review_snapshot,
    digest_obj,
    integer,
    mapping,
    num,
    now_text,
    now_ts,
    read_json,
    read_candidate_rows,
    stage,
)

VERSION = "review_worker_v1.041"
BUILD_LABEL = "v1312_review_missed_state_bounded_writer_disk_growth_stop_2026-07-07"
DEFAULT_INTERVAL_SEC = 3.0
HEARTBEAT_SEC = 5.0
_STOP = False
_LOCK_HANDLE: Optional[Any] = None
_COMMITTED_ROWS_V1241: list[Dict[str, Any]] = []
_COMMITTED_IDENTITY_V1241: tuple[str, str] = ("", "")
_COMMITTED_DIGEST_V1241 = ""
_COMMITTED_INTEGRITY_V1241: Dict[str, Any] = {}

V1233_RETENTION_SEC = 24.0 * 3600.0
V1233_MISSED_HORIZON_SEC = 6.0 * 3600.0
V1233_SHADOW_FEE_PCT = 0.10
V1233_STATE_SCHEMA = "version_score_review_state_v1237"
V1233_SUMMARY_SCHEMA = "canonical_version_score_review_v1237"


def version_score_state_path(base: Path) -> Path:
    return base / "version_score_review_state_v1237.json"


def version_score_summary_path(base: Path) -> Path:
    return base / "canonical_version_score_review_v1237.json"


def _v1242_paper_exact_replay_status(base: Path) -> Dict[str, Any]:
    raw=read_json(base / "paper_exit_replay_status_v1242.json", {}) or {}
    if not isinstance(raw,dict) or raw.get("schema")!="paper_exit_replay_status_v1242":
        return {
            "schema":"review_paper_exact_exit_replay_v1242","stage":"CAPTURE_AND_LINK_STAGE1",
            "state":"CHECK_WAITING_PAPER_CAPTURE","poll_sweeps":0,"poll_records":0,"close_commit_ok":0,"close_commit_fail":0,
            "historical_pre_v1242":"NOT_REPLAYABLE_WITHOUT_POLL_EVIDENCE",
            "alternate_structure_exact_replay":"NOT_STARTED","actual_exit_changed":False,"auto_buy":False,
        }
    state=str(raw.get("state") or "CHECK")
    exact_ready=bool(state=="NORMAL" and integer(raw.get("poll_records"),default=0)>0)
    return {
        "schema":"review_paper_exact_exit_replay_v1242","stage":"CAPTURE_AND_LINK_STAGE1",
        "state":state,"paper_version":raw.get("version"),"paper_build":raw.get("build"),
        "poll_sweeps":integer(raw.get("poll_sweeps"),default=0),"poll_records":integer(raw.get("poll_records"),default=0),
        "close_commit_ok":integer(raw.get("close_commit_ok"),default=0),"close_commit_fail":integer(raw.get("close_commit_fail"),default=0),
        "evidence_append_failures":integer(raw.get("evidence_append_failures"),default=0),
        "last_sweep_id":raw.get("last_sweep_id"),"last_sweep_record_count":integer(raw.get("last_sweep_record_count"),default=0),
        "current_policy_poll_capture_exact":exact_ready,
        "historical_pre_v1242":raw.get("historical_pre_v1242") or "NOT_REPLAYABLE_WITHOUT_POLL_EVIDENCE",
        "alternate_structure_exact_replay":"READY_AFTER_LINKED_CLOSES" if integer(raw.get("close_commit_ok"),default=0)>0 else "WAITING_LINKED_CLOSE",
        "policy":"Paper poll sequence is canonical; missing historical polls are never inferred from current values",
        "actual_exit_changed":False,"auto_buy":False,
    }


def _v1233_float(*values: Any, default: float = 0.0) -> float:
    for value in values:
        try:
            if value is None or value == "":
                continue
            out = float(value)
            if out == out and abs(out) != float("inf"):
                return out
        except (TypeError, ValueError, OverflowError):
            continue
    return default


def _v1233_ticker(row: Dict[str, Any]) -> str:
    return str(row.get("ticker") or row.get("market") or row.get("symbol") or "").strip().upper()


def _v1233_price(row: Dict[str, Any]) -> float:
    return _v1233_float(
        row.get("current_price"), row.get("live_price"), row.get("price"),
        row.get("trade_price"), row.get("close"), row.get("last_price"), default=0.0,
    )


def _v1233_nested(row: Dict[str, Any], *names: str) -> Dict[str, Any]:
    for name in names:
        value = row.get(name)
        if isinstance(value, dict):
            return value
    gate = row.get("swing_entry_gate_v977") if isinstance(row.get("swing_entry_gate_v977"), dict) else {}
    for name in names:
        value = gate.get(name)
        if isinstance(value, dict):
            return value
    return {}


def _v1233_line_price(obj: Any) -> float:
    if not isinstance(obj, dict):
        return 0.0
    return _v1233_float(obj.get("rounded_price"), obj.get("raw_price"), obj.get("price"), default=0.0)


def _v1236_sig_price(value: float) -> str:
    try:
        value=float(value)
    except (TypeError,ValueError):
        return "0"
    if value<=0:
        return "0"
    return f"{value:.6g}"


def _v1236_line_tf(obj: Any) -> str:
    return str(obj.get("tf") or obj.get("timeframe") or "") if isinstance(obj,dict) else ""


def _v1233_event_identity(row: Dict[str, Any], ticker: str, suffix: str) -> str:
    """Semantic occurrence key, stable across repeated Strategy cycles.

    v1235 preferred trigger event_ts, but that timestamp can be refreshed every
    cycle and created duplicate review/shadow events. v1236 keys by the sealed
    executable structure. v1211 shadow suffix already contains its three lines.
    """
    if str(suffix).startswith("v1211:"):
        stable=str(suffix)
    else:
        plan=_v1233_nested(row,"dynamic_structure_plan_v1212","structure_contract_v1212")
        trigger=plan.get("trigger") if isinstance(plan.get("trigger"),dict) else {}
        invalid=plan.get("invalid") if isinstance(plan.get("invalid"),dict) else {}
        target=plan.get("target") if isinstance(plan.get("target"),dict) else {}
        intermediate=plan.get("intermediate_resistance_v1225") if isinstance(plan.get("intermediate_resistance_v1225"),dict) else {}
        line_sig='|'.join((
            _v1236_sig_price(_v1233_line_price(trigger)),_v1236_line_tf(trigger),
            _v1236_sig_price(_v1233_line_price(invalid)),_v1236_line_tf(invalid),
            _v1236_sig_price(_v1233_line_price(target)),_v1236_line_tf(target),
            _v1236_sig_price(_v1233_line_price(intermediate)),_v1236_line_tf(intermediate),
        ))
        structure_hash=str(row.get("structure_contract_hash") or plan.get("structure_contract_hash") or "").strip()
        if line_sig.replace('|','').replace('0',''):
            stable=f"{suffix}|lines:{line_sig}"
        elif structure_hash:
            stable=f"{suffix}|hash:{structure_hash}"
        else:
            # No structure means one active semantic event per ticker/reason,
            # not one event per refreshed cycle timestamp.
            stable=f"{suffix}|no_structure"
    return hashlib.sha256(f"{ticker}|{stable}".encode("utf-8",errors="ignore")).hexdigest()[:24]

def _v1233_return_pct(price: float, start: float) -> Optional[float]:
    if price <= 0 or start <= 0:
        return None
    return (price - start) / start * 100.0


def _v1233_empty_state(nowv: float) -> Dict[str, Any]:
    return {
        "schema": V1233_STATE_SCHEMA,
        "started_ts": nowv, "started_text": now_text(nowv),
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "retention_sec": V1233_RETENTION_SEC,
        "missed": {"events": {}},
        "previous_structure_shadow": {"pending": {}, "open": {}, "closed": [], "skipped": []},
        "auto_buy": False,
    }


def _v1233_metric(rows: list[Dict[str, Any]]) -> Dict[str, Any]:
    values = [_v1233_float(r.get("net_pnl_pct"), default=0.0) for r in rows]
    wins = sum(1 for x in values if x > 0)
    losses = sum(1 for x in values if x < 0)
    return {
        "count": len(rows), "wins": wins, "losses": losses,
        "win_rate": (wins / len(rows) * 100.0) if rows else None,
        "total_pct": sum(values) if values else 0.0,
        "avg_pct": (sum(values) / len(values)) if values else None,
        "avg_mfe_pct": (sum(_v1233_float(r.get("mfe_pct"), default=0.0) for r in rows) / len(rows)) if rows else None,
        "avg_mae_pct": (sum(_v1233_float(r.get("mae_pct"), default=0.0) for r in rows) / len(rows)) if rows else None,
    }


def _v1233_missed_reason(row: Dict[str, Any]) -> str:
    plan = _v1233_nested(row, "dynamic_structure_plan_v1212", "structure_contract_v1212")
    pair = plan.get("pairing_contract_v1229") if isinstance(plan.get("pairing_contract_v1229"), dict) else {}
    inv = int(_v1233_float(pair.get("invalid_candidates"), default=0.0))
    tgt = int(_v1233_float(pair.get("target_candidates"), default=0.0))
    passing = int(_v1233_float(pair.get("passing"), default=0.0))
    cost_complete = pair.get("cost_complete") is not False
    intermediate = plan.get("intermediate_resistance_v1225") if isinstance(plan.get("intermediate_resistance_v1225"), dict) else {}
    if inv > 0 and tgt > 0 and passing == 0 and cost_complete:
        return "risk_reward_pair_shortage"
    if inv > 0 and tgt == 0 and intermediate:
        return "only_intermediate_resistance"
    return ""


def _v1233_update_missed(state: Dict[str, Any], rows: list[Dict[str, Any]], prices: Dict[str, float], nowv: float) -> None:
    root=state.setdefault("missed",{}); events=root.setdefault("events",{})
    cutoff=nowv-V1233_RETENTION_SEC
    for key in list(events):
        event=events.get(key) if isinstance(events.get(key),dict) else {}
        if _v1233_float(event.get("created_ts"),default=0.0)<cutoff:
            events.pop(key,None)
    for row in rows:
        ticker=_v1233_ticker(row); price=_v1233_price(row); reason=_v1233_missed_reason(row)
        if not ticker or price<=0 or not reason: continue
        plan=_v1233_nested(row,"dynamic_structure_plan_v1212","structure_contract_v1212")
        trigger=plan.get("trigger") if isinstance(plan.get("trigger"),dict) else {}
        invalid=plan.get("invalid") if isinstance(plan.get("invalid"),dict) else {}
        target=plan.get("target") if isinstance(plan.get("target"),dict) else {}
        intermediate=plan.get("intermediate_resistance_v1225") if isinstance(plan.get("intermediate_resistance_v1225"),dict) else {}
        event_id=_v1233_event_identity(row,ticker,f"missed:{reason}")
        event=events.get(event_id)
        if not isinstance(event,dict):
            event={
                "event_id":event_id,"semantic_event_id":event_id,"ticker":ticker,"reason":reason,
                "created_ts":nowv,"created_text":now_text(nowv),"start_price":price,
                "high_price":price,"low_price":price,"current_price":price,"last_seen_ts":nowv,
                "trigger_price":_v1233_line_price(trigger),"invalid_price":_v1233_line_price(invalid),
                "target_price":_v1233_line_price(target),"intermediate_price":_v1233_line_price(intermediate),
                "trigger_tf":_v1236_line_tf(trigger),"invalid_tf":_v1236_line_tf(invalid),"target_tf":_v1236_line_tf(target),
                "candidate_cycle_id_first":row.get("candidate_pipeline_cycle_id_v1150"),
            }
            events[event_id]=event
        event["candidate_cycle_id_last"]=row.get("candidate_pipeline_cycle_id_v1150")
    for event in events.values():
        if not isinstance(event,dict): continue
        ticker=str(event.get("ticker") or ""); price=prices.get(ticker,0.0); start_price=_v1233_float(event.get("start_price"),default=0.0)
        if price<=0 or start_price<=0: continue
        event["current_price"]=price
        event["high_price"]=max(_v1233_float(event.get("high_price"),default=price),price)
        event["low_price"]=min(_v1233_float(event.get("low_price"),default=price),price)
        event["last_seen_ts"]=nowv
        event["current_return_pct"]=_v1233_return_pct(price,start_price)
        event["max_gain_pct"]=_v1233_return_pct(_v1233_float(event.get("high_price"),default=price),start_price)
        event["max_drawdown_pct"]=_v1233_return_pct(_v1233_float(event.get("low_price"),default=price),start_price)
        age=max(0.0,nowv-_v1233_float(event.get("created_ts"),default=nowv)); event["age_sec"]=age
        if age>=V1233_MISSED_HORIZON_SEC and event.get("return_6h_pct") is None:
            event["return_6h_pct"]=event.get("current_return_pct"); event["completed_6h_ts"]=nowv

def _v1233_shadow_close(root: Dict[str, Any], event_id: str, event: Dict[str, Any], price: float, nowv: float, reason: str) -> None:
    open_map = root.setdefault("open", {})
    open_map.pop(event_id, None)
    entry = _v1233_float(event.get("entry_price"), default=0.0)
    gross = _v1233_return_pct(price, entry) or 0.0
    high = _v1233_float(event.get("high_price"), default=price)
    low = _v1233_float(event.get("low_price"), default=price)
    closed = dict(event)
    closed.update({
        "closed_ts": nowv, "closed_text": now_text(nowv), "close_price": price,
        "exit_reason": reason, "gross_pnl_pct": gross,
        "fee_pct": V1233_SHADOW_FEE_PCT, "net_pnl_pct": gross - V1233_SHADOW_FEE_PCT,
        "mfe_pct": _v1233_return_pct(high, entry) or 0.0,
        "mae_pct": _v1233_return_pct(low, entry) or 0.0,
        "hold_sec": max(0.0, nowv - _v1233_float(event.get("opened_ts"), default=nowv)),
    })
    root.setdefault("closed", []).append(closed)


def _v1233_update_shadow(state: Dict[str, Any], rows: list[Dict[str, Any]], prices: Dict[str, float], nowv: float) -> None:
    root = state.setdefault("previous_structure_shadow", {})
    pending = root.setdefault("pending", {})
    open_map = root.setdefault("open", {})
    closed = root.setdefault("closed", [])
    skipped = root.setdefault("skipped", [])
    cutoff = nowv - V1233_RETENTION_SEC
    root["closed"] = [r for r in closed if isinstance(r, dict) and _v1233_float(r.get("closed_ts"), default=0.0) >= cutoff]
    root["skipped"] = [r for r in skipped if isinstance(r, dict) and _v1233_float(r.get("ts"), default=0.0) >= cutoff]
    closed_ids = {str(r.get("event_id")) for r in root["closed"] if isinstance(r, dict)}
    skipped_ids = {str(r.get("event_id")) for r in root["skipped"] if isinstance(r, dict)}
    for key in list(pending):
        event = pending.get(key) if isinstance(pending.get(key), dict) else {}
        if _v1233_float(event.get("created_ts"), default=0.0) < cutoff:
            pending.pop(key, None)
    for key in list(open_map):
        event = open_map.get(key) if isinstance(open_map.get(key), dict) else {}
        if _v1233_float(event.get("opened_ts"), default=0.0) < cutoff:
            price = prices.get(str(event.get("ticker") or ""), _v1233_float(event.get("last_price"), default=0.0))
            if price > 0:
                _v1233_shadow_close(root, key, event, price, nowv, "REVIEW_24H_TIMEOUT")
            else:
                open_map.pop(key, None)
    for row in rows:
        ticker = _v1233_ticker(row)
        price = _v1233_price(row)
        shadow = row.get("v1211_structure_shadow_v1222") if isinstance(row.get("v1211_structure_shadow_v1222"), dict) else {}
        trigger = _v1233_line_price(shadow.get("trigger"))
        invalid = _v1233_line_price(shadow.get("invalid"))
        target = _v1233_line_price(shadow.get("target"))
        if not ticker or price <= 0 or shadow.get("source_exact") is not True or not (0 < invalid < trigger < target):
            continue
        event_id = _v1233_event_identity(row, ticker, f"v1211:{trigger:.12g}:{invalid:.12g}:{target:.12g}")
        if event_id in pending or event_id in open_map or event_id in closed_ids or event_id in skipped_ids:
            continue
        pending[event_id] = {
            "event_id": event_id, "ticker": ticker, "created_ts": nowv, "created_text": now_text(nowv),
            "trigger_price": trigger, "invalid_price": invalid, "target_price": target,
            "last_price": price, "candidate_cycle_id": row.get("candidate_pipeline_cycle_id_v1150"),
            "source": "v1211_structure_shadow_v1222",
        }
    for event_id in list(pending):
        event = pending.get(event_id) if isinstance(pending.get(event_id), dict) else {}
        ticker = str(event.get("ticker") or "")
        price = prices.get(ticker, _v1233_float(event.get("last_price"), default=0.0))
        trigger = _v1233_float(event.get("trigger_price"), default=0.0)
        invalid = _v1233_float(event.get("invalid_price"), default=0.0)
        target = _v1233_float(event.get("target_price"), default=0.0)
        event["last_price"] = price
        if price <= 0:
            continue
        if price <= invalid:
            pending.pop(event_id, None)
            root["skipped"].append({"event_id":event_id,"ticker":ticker,"ts":nowv,"reason":"INVALID_BEFORE_ENTRY"})
        elif price >= target:
            pending.pop(event_id, None)
            root["skipped"].append({"event_id":event_id,"ticker":ticker,"ts":nowv,"reason":"TARGET_ALREADY_PASSED_BEFORE_OBSERVED_ENTRY"})
        elif price >= trigger:
            pending.pop(event_id, None)
            opened = dict(event)
            opened.update({
                "opened_ts": nowv, "opened_text": now_text(nowv), "entry_price": price,
                "high_price": price, "low_price": price, "last_price": price,
            })
            open_map[event_id] = opened
    for event_id in list(open_map):
        event = open_map.get(event_id) if isinstance(open_map.get(event_id), dict) else {}
        ticker = str(event.get("ticker") or "")
        price = prices.get(ticker, _v1233_float(event.get("last_price"), default=0.0))
        if price <= 0:
            continue
        event["last_price"] = price
        event["high_price"] = max(_v1233_float(event.get("high_price"), default=price), price)
        event["low_price"] = min(_v1233_float(event.get("low_price"), default=price), price)
        invalid = _v1233_float(event.get("invalid_price"), default=0.0)
        target = _v1233_float(event.get("target_price"), default=0.0)
        if price <= invalid:
            _v1233_shadow_close(root, event_id, event, price, nowv, "INVALID")
        elif price >= target:
            _v1233_shadow_close(root, event_id, event, price, nowv, "TARGET")


def _v1233_build_summary(state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    missed_events = [e for e in ((state.get("missed") or {}).get("events") or {}).values() if isinstance(e, dict)]
    primary = [e for e in missed_events if e.get("reason") == "risk_reward_pair_shortage"]
    intermediate_only = [e for e in missed_events if e.get("reason") == "only_intermediate_resistance"]
    missed_top = sorted(missed_events, key=lambda e: _v1233_float(e.get("max_gain_pct"), default=-9999.0), reverse=True)[:5]
    missed_reason_counts: Dict[str, int] = {}
    for event in missed_events:
        reason = str(event.get("reason") or "unknown")
        missed_reason_counts[reason] = missed_reason_counts.get(reason, 0) + 1
    shadow = state.get("previous_structure_shadow") if isinstance(state.get("previous_structure_shadow"), dict) else {}
    closed = [r for r in shadow.get("closed", []) if isinstance(r, dict)]
    windows = {}
    for name, seconds in (("recent_3h",3*3600),("recent_6h",6*3600),("recent_12h",12*3600),("recent_24h",24*3600)):
        windows[name] = _v1233_metric([r for r in closed if _v1233_float(r.get("closed_ts"), default=0.0) >= nowv-seconds])
    reasons: Dict[str,int] = {}
    for row in closed:
        reason = str(row.get("exit_reason") or "UNKNOWN")
        reasons[reason] = reasons.get(reason, 0) + 1
    top_profit = sorted(closed, key=lambda r:_v1233_float(r.get("net_pnl_pct"), default=-9999.0), reverse=True)[:5]
    top_loss = sorted(closed, key=lambda r:_v1233_float(r.get("net_pnl_pct"), default=9999.0))[:5]
    return {
        "schema": V1233_SUMMARY_SCHEMA,
        "version": VERSION, "build": BUILD_LABEL,
        "generated_ts": nowv, "generated_text": now_text(nowv),
        "started_ts": state.get("started_ts"), "started_text": state.get("started_text"),
        "retention_sec": V1233_RETENTION_SEC, "auto_buy": False,
        "missed_current_structure": {
            "scope": "current structure exclusions tracked from first v1234 semantic occurrence; 6h path; 24h retention",
            "tracked_total": len(missed_events),
            "risk_reward_shortage_count": len(primary),
            "intermediate_only_count": len(intermediate_only),
            "reason_counts": missed_reason_counts,
            "completed_6h": sum(1 for e in missed_events if e.get("return_6h_pct") is not None),
            "completed_6h_risk_reward": sum(1 for e in primary if e.get("return_6h_pct") is not None),
            "completed_6h_intermediate": sum(1 for e in intermediate_only if e.get("return_6h_pct") is not None),
            "positive_max_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) > 0),
            "gain_1_2_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) >= 1.2),
            "gain_3_count": sum(1 for e in missed_events if _v1233_float(e.get("max_gain_pct"), default=0.0) >= 3.0),
            "top": missed_top,
        },
        "previous_structure_shadow": {
            "scope": "v1211 comparison-only virtual trades from v1233 start; unlimited simultaneous virtual OPEN; isolated from Paper",
            "pending_count": len(shadow.get("pending", {}) or {}),
            "open_count": len(shadow.get("open", {}) or {}),
            "closed_count": len(closed),
            "skipped_count": len(shadow.get("skipped", []) or []),
            "windows": windows, "exit_reasons": reasons,
            "fee_pct": V1233_SHADOW_FEE_PCT,
            "top_profit": top_profit, "top_loss": top_loss,
        },
        "invariants": {
            "live_paper_ledger_changed": False, "actual_open_limit_changed": False,
            "actual_entry_exit_changed": False, "shadow_open_limit": None,
            "actual_and_shadow_ledgers_separate": True, "core_ledger_retention_changed": False,
        },
    }



def _v1234_stat(rows: list[Dict[str, Any]]) -> Dict[str, Any]:
    values=[_v1233_float(r.get('net_pnl_pct'),r.get('pnl_pct'),default=0.0) for r in rows]
    wins=sum(1 for v in values if v>0); losses=sum(1 for v in values if v<0)
    def avg(key: str) -> Optional[float]:
        nums=[_v1233_float(r.get(key),default=0.0) for r in rows if r.get(key) not in (None,'')]
        return sum(nums)/len(nums) if nums else None
    return {
        'count':len(rows),'wins':wins,'losses':losses,'win_rate':wins/len(rows)*100.0 if rows else None,
        'total_pct':sum(values),'avg_pct':sum(values)/len(values) if values else None,
        'avg_mfe_pct':avg('mfe_pct'),'avg_mae_pct':avg('mae_pct'),'avg_giveback_pct':avg('giveback_pct'),'avg_hold_sec':avg('hold_sec'),
    }


def _v1234_quality_replay(row: Dict[str, Any]) -> Dict[str, Any]:
    def known(*keys: str) -> tuple[Optional[float], str]:
        for key in keys:
            if row.get(key) in (None,''):
                continue
            try:
                value=float(row.get(key))
                if value==value and abs(value)!=float('inf'):
                    return value,key
            except Exception:
                continue
        return None,'source_missing'
    reaction,reaction_src=known('price_reaction_pct')
    relative_rank,relative_rank_src=known('relative_strength_rank_pct')
    relative,relative_src=known('relative_strength')
    money,money_src=known('money_flow')
    buy,buy_src=known('buy_ratio')
    sustain,sustain_src=known('buy_sustain_1m')
    rr=_v1233_float(row.get('actual_entry_rr'),row.get('risk_reward'),default=0.0)
    room=_v1233_float(row.get('target_distance_pct'),row.get('target_room_pct'),default=0.0)
    spread=_v1233_float(row.get('spread_pct'),default=-1.0)
    slip=row.get('paper_reference_cost_pct')
    slip_n=None if slip in (None,'') else _v1233_float(slip,default=0.0)
    reaction_safe=reaction is not None and reaction>=-0.35
    reaction_strong=reaction is not None and reaction>=0.05
    relative_pass=(relative_rank is not None and relative_rank>=50.0) or (relative is not None and ((relative>=50.0) if abs(relative)>5.0 else (relative>=0.0)))
    money_pass=money is not None and money>=50.0
    buy_pass=buy is not None and sustain is not None and buy>=0.50 and sustain>=0.45
    known_axes=sum(1 for value in (reaction is not None, relative_rank is not None or relative is not None, money is not None, buy is not None and sustain is not None) if value)
    confirmations=sum(1 for value in (relative_pass,money_pass,buy_pass) if value)
    reasons=[]
    if known_axes<3: reasons.append('quality_source_missing')
    if reaction is None: reasons.append('quality_reaction_source_missing')
    elif not reaction_safe: reasons.append('quality_reaction_unsafe')
    if confirmations<1: reasons.append('quality_confirmation_absent')
    passed=bool(known_axes>=3 and reaction_safe and confirmations>=1)
    clip=lambda v,lo,hi:max(lo,min(hi,v))
    structure_score=15.0*clip((rr-1.5)/2.5,0.0,1.0)+15.0*clip((room-1.2)/2.8,0.0,1.0)
    reaction_score=20.0*clip(((reaction if reaction is not None else -0.35)+0.35)/1.35,0.0,1.0)
    rel_basis=relative_rank if relative_rank is not None else (relative if relative is not None and abs(relative)>5.0 else 50.0+clip(relative or 0.0,-2.0,2.0)*12.5)
    rel_score=20.0*clip(rel_basis/100.0,0.0,1.0)
    money_score=20.0*clip((money if money is not None else 40.0)/100.0,0.0,1.0)
    execution_base=((buy or 0.0)+(sustain or 0.0))/2.0 if buy is not None and sustain is not None else 0.40
    cost=max(0.0,spread if spread>=0 else 1.2)+max(0.0,slip_n if slip_n is not None else 1.2)
    execution_score=10.0*clip(execution_base-(cost/2.4)*0.35,0.0,1.0)
    return {
        'evaluable':known_axes>=3 and reaction is not None,'would_pass':passed,'known_axes':known_axes,'confirmations':confirmations,
        'reaction_safe':reaction_safe,'reaction_strong':reaction_strong,'reasons':reasons,
        'score':round(structure_score+reaction_score+rel_score+money_score+execution_score,4),
        'sources':{'reaction':reaction_src,'relative':relative_rank_src if relative_rank is not None else relative_src,'money':money_src,'buy':buy_src,'sustain':sustain_src},
    }


def _v1234_trigger_grace_minutes(row: Dict[str, Any]) -> float:
    trigger=row.get('trigger') if isinstance(row.get('trigger'),dict) else {}
    tf=str(trigger.get('tf') or trigger.get('timeframe') or 'm15').lower()
    return {'m1':1.0,'m3':3.0,'m5':5.0,'m15':15.0,'m30':30.0,'h1':60.0}.get(tf,15.0)


def _v1234_exit_diagnostic(row: Dict[str, Any]) -> Dict[str, Any]:
    hold_min=max(0.0,_v1233_float(row.get('hold_sec'),default=0.0)/60.0)
    grace=_v1234_trigger_grace_minutes(row)
    mfe=_v1233_float(row.get('mfe_pct'),default=0.0)
    net=_v1233_float(row.get('net_pnl_pct'),row.get('pnl_pct'),default=0.0)
    giveback=_v1233_float(row.get('giveback_pct'),default=max(0.0,mfe-net))
    fee=_v1233_float(row.get('configured_fee_pct'),default=0.10)
    spread=max(0.0,_v1233_float(row.get('spread_pct'),default=0.0))
    recovery=max(0.25,fee+spread*2.0)
    reason=str(row.get('exit_reason') or '')
    early=bool(reason=='swing_dynamic_momentum_decay' and hold_min<grace)
    profit_to_loss=bool(mfe>=recovery and net<=0.0)
    small_gap=bool(mfe>0.0 and mfe<1.0 and giveback>=max(0.20,mfe*0.55))
    delayed=bool(reason=='swing_dynamic_momentum_decay' and hold_min>=grace and profit_to_loss)
    return {'early_timeframe_conflict':early,'profit_to_loss_gap':profit_to_loss,'small_profit_giveback_gap':small_gap,'delayed_momentum_exit':delayed,'grace_min':grace,'recovery_trigger_pct':recovery}


def _v1234_hybrid_replay(base: Path, candidate_rows: list[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    perf=read_json(base/'canonical_performance_snapshot_v987.json',{}) or {}
    all_rows=[r for r in (perf.get('rows') or []) if isinstance(r,dict)]
    previous=[]; current=[]; unclassified=[]
    for row in all_rows:
        raw=str(row.get('structure_contract_version') or '').strip()
        if raw=='structure_contract_v1211_legacy': previous.append(row); continue
        match=re.search(r'structure_contract_v(\d+)',raw) if raw else None
        if match and int(match.group(1))>1211: current.append(row)
        else: unclassified.append(row)
    pass_rows=[]; block_rows=[]; missing_rows=[]; reason_counts={}; replay_rows=[]
    for row in current:
        decision=_v1234_quality_replay(row)
        replay_rows.append((row,decision))
        if not decision['evaluable']:
            missing_rows.append(row)
        elif decision['would_pass']:
            pass_rows.append(row)
        else:
            block_rows.append(row)
        for reason in decision['reasons']:
            reason_counts[reason]=reason_counts.get(reason,0)+1
    diagnostics=[(row,_v1234_exit_diagnostic(row)) for row in current]
    early=[row for row,d in diagnostics if d['early_timeframe_conflict']]
    profit_loss=[row for row,d in diagnostics if d['profit_to_loss_gap']]
    small_gap=[row for row,d in diagnostics if d['small_profit_giveback_gap']]
    delayed=[row for row,d in diagnostics if d['delayed_momentum_exit']]
    combined=[row for row,d in diagnostics if d['early_timeframe_conflict'] or d['profit_to_loss_gap']]
    candidate_pass=[r for r in candidate_rows if r.get('hybrid_entry_shadow_pass_v1234') is True]
    candidate_block=[r for r in candidate_rows if r.get('hybrid_entry_shadow_pass_v1234') is False]
    current_s1=[r for r in candidate_rows if stage(r) == 'S1']
    current_s1_block=[r for r in current_s1 if r.get('hybrid_entry_shadow_pass_v1234') is False]
    cand_reasons={}
    for row in candidate_block:
        for reason in str(row.get('hybrid_entry_shadow_reason_v1234') or '').split('|'):
            if reason and reason!='PASS': cand_reasons[reason]=cand_reasons.get(reason,0)+1
    examples=[]
    for row in current_s1_block[:8]:
        examples.append({'ticker':_v1233_ticker(row),'reason':row.get('hybrid_entry_shadow_reason_v1234'),'current_score':row.get('global_entry_score_v1212'),'hybrid_score':row.get('hybrid_entry_shadow_score_v1234')})
    return {
        'schema':'hybrid_surgery_replay_v1234','mode':'SHADOW_ONLY','performance_snapshot_id':perf.get('snapshot_id'),
        'source_rows':len(all_rows),'previous_actual':_v1234_stat(previous),'current_actual':_v1234_stat(current),'unclassified_rows':len(unclassified),
        'entry_replay':{
            'current_rows':len(current),'evaluable_rows':len(pass_rows)+len(block_rows),'source_missing_rows':len(missing_rows),
            'hybrid_would_pass':len(pass_rows),'hybrid_would_block':len(block_rows),'block_reason_counts':reason_counts,
            'actual_outcomes_if_hybrid_pass':_v1234_stat(pass_rows),'actual_outcomes_if_hybrid_block':_v1234_stat(block_rows),
            'interpretation':'actual historical outcomes split by sealed OPEN-time metrics; not counterfactual fills',
        },
        'exit_replay':{
            'current_rows':len(current),'early_timeframe_conflict':len(early),'profit_to_loss_gap':len(profit_loss),
            'small_profit_giveback_gap':len(small_gap),'delayed_momentum_exit':len(delayed),'combined_flagged':len(combined),
            'early_stats':_v1234_stat(early),'profit_to_loss_stats':_v1234_stat(profit_loss),'combined_stats':_v1234_stat(combined),
            'variants':['timeframe_grace_only','cost_recovery_floor_only','combined'],
            'interpretation':'eligibility and damage audit from exact CLOSED fields; no fabricated counterfactual exit price',
        },
        'current_generation':{
            'rows':len(candidate_rows),'hybrid_pass':len(candidate_pass),'hybrid_block':len(candidate_block),
            'current_s1':len(current_s1),'current_s1_hybrid_block':len(current_s1_block),
            'block_reason_counts':cand_reasons,'s1_block_examples':examples,
        },
        'contract':{
            'candidate_quality':'v1211 source/reaction/confirmation gate','structure_lines':'current coherent stop-target pairing',
            'exit_variants':'trigger-timeframe grace + cost recovery floor','hard_target_invalid_unchanged':True,
            'actual_entry_changed':False,'actual_exit_changed':False,'existing_open_changed':False,'auto_buy':False,
        },
    }



# -----------------------------------------------------------------------------
# v1236 - multi-state truth labels / conservative EV / semantic evidence
#
# Review remains the only owner. Live Strategy/Paper decisions are untouched.
# Target-vs-invalid is no longer forced to 100%: intermediate exits, ambiguous
# path evidence and unresolved events are first-class outcomes.
# -----------------------------------------------------------------------------

V1236_MODEL_SCHEMA="probability_policy_shadow_v1236"
V1236_MIN_SHARED_NUMERIC=4
V1236_MAX_NEIGHBORS=60
V1236_PRIOR_STRENGTH=12.0
V1236_STATES=("TARGET_FIRST","INVALID_FIRST","INTERMEDIATE_EXIT","AMBIGUOUS_BOTH","UNRESOLVED")


def _v1236_finite(value: Any) -> Optional[float]:
    try:
        out=float(value)
        if out==out and abs(out)!=float('inf'): return out
    except (TypeError,ValueError,OverflowError): pass
    return None


def _v1236_first_num(row: Dict[str, Any], *keys: str) -> Optional[float]:
    for key in keys:
        out=_v1236_finite(row.get(key))
        if out is not None: return out
    return None


def _v1236_line(row: Dict[str, Any], name: str) -> Dict[str, Any]:
    direct=row.get(name)
    if isinstance(direct,dict): return direct
    gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
    plan=gate.get('structure_plan') if isinstance(gate.get('structure_plan'),dict) else {}
    if not plan:
        for key in ('dynamic_structure_plan_v1212','swing_structure_plan_v977','structure_plan'):
            if isinstance(row.get(key),dict): plan=row[key]; break
    value=plan.get(name) if isinstance(plan,dict) else None
    return value if isinstance(value,dict) else {}


def _v1236_line_price(line: Dict[str, Any]) -> Optional[float]:
    for key in ('price','rounded_price','raw_price','value'):
        out=_v1236_finite(line.get(key))
        if out is not None and out>0: return out
    return None


def _v1236_tf(line: Dict[str, Any], default: str='unknown') -> str:
    return str(line.get('tf') or line.get('timeframe') or default).strip().lower()


def _v1236_tf_minutes(tf: str) -> float:
    return {'m1':1.0,'1m':1.0,'m3':3.0,'3m':3.0,'m5':5.0,'5m':5.0,'m15':15.0,'15m':15.0,
            'm30':30.0,'30m':30.0,'h1':60.0,'1h':60.0,'h2':120.0,'2h':120.0,'h4':240.0,'4h':240.0}.get(str(tf).lower(),15.0)


def _v1236_route_family(row: Dict[str, Any]) -> str:
    text=' '.join(str(row.get(k) or '') for k in ('entry_method','strategy','strategy_label','strategy_key','paper_strategy_key','source_lane')).lower()
    if 'hot-rank' in text or 'hot_rank' in text or '급등' in text: return 'hot_rank'
    if 'coverage' in text or '전체커버' in text: return 'coverage'
    if 's3_observe' in text or '관찰경로' in text: return 's3_observe'
    if '돌파' in text or 'breakout' in text or 'rebreak' in text: return 'breakout'
    if '주도' in text or 'leader' in text or '유동보유' in text: return 'leader_trend'
    if '돈흐름' in text or 'flow' in text or '재가속' in text: return 'money_flow'
    if 'vwap' in text or '저점' in text or '회복' in text: return 'vwap_recovery'
    return 'other'


def _v1236_market_family(row: Dict[str, Any]) -> str:
    text=str(row.get('market_mode_at_open') or row.get('market_mode') or row.get('market_regime') or row.get('market_state') or '').strip().lower()
    if not text:
        ctx=row.get('market_context') if isinstance(row.get('market_context'),dict) else {}
        text=str(ctx.get('market_regime') or ctx.get('regime') or ctx.get('market_state') or '').strip().lower()
    if any(x in text for x in ('bull','상승','risk_on','strong')): return 'bull'
    if any(x in text for x in ('bear','하락','risk_off','weak')): return 'bear'
    if any(x in text for x in ('side','range','횡보','neutral')): return 'sideways'
    return 'unknown'


def _v1236_features(row: Dict[str, Any], candidate: bool=False) -> Dict[str, Any]:
    gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
    trigger=_v1236_line(row,'trigger'); invalid=_v1236_line(row,'invalid'); target=_v1236_line(row,'target')
    entry=_v1236_first_num(row,'entry_price','actual_entry_price','current_price','live_price','price','last_price')
    if entry is None: entry=_v1236_line_price(trigger)
    target_distance=_v1236_first_num(row,'target_distance_pct','target_room_pct')
    invalid_distance=_v1236_first_num(row,'invalid_distance_pct','stop_distance_pct','invalid_distance_pct_v925')
    tp=_v1236_line_price(target); ip=_v1236_line_price(invalid)
    if entry and entry>0 and target_distance is None and tp and tp>entry: target_distance=(tp-entry)/entry*100.0
    if entry and entry>0 and invalid_distance is None and ip and ip<entry: invalid_distance=(entry-ip)/entry*100.0
    rr=_v1236_first_num(row,'actual_entry_rr','risk_reward','risk_reward_ratio')
    if rr is None: rr=_v1236_finite(gate.get('risk_reward'))
    reaction=_v1236_first_num(row,'price_reaction_pct','reaction_pct','change_1m_pct','change_1m')
    relative_rank=_v1236_first_num(row,'relative_strength_rank_pct','relative_strength_rank_pct_v1095')
    relative=_v1236_first_num(row,'relative_strength','relative_strength_pct')
    if relative_rank is None and relative is not None: relative_rank=relative if abs(relative)>5.0 else 50.0+max(-2.0,min(2.0,relative))*12.5
    money=_v1236_first_num(row,'money_flow','money_flow_score','money_expand_score','turnover_change_pct')
    buy=_v1236_first_num(row,'buy_ratio','buy_trade_ratio','micro_buy_ratio')
    sustain=_v1236_first_num(row,'buy_sustain_1m','buy_sustain_60s','micro_buy_ratio_sustain_1m')
    spread=_v1236_first_num(row,'spread_pct','micro_spread_pct','entry_spread_pct')
    if spread is None: spread=_v1236_finite(gate.get('spread_pct'))
    slip=_v1236_first_num(row,'paper_reference_cost_pct','paper_reference_slippage_pct','confirmed_slippage_pct')
    if slip is None: slip=_v1236_finite(gate.get('confirmed_slippage_pct'))
    fee=_v1236_first_num(row,'configured_fee_pct','configured_roundtrip_fee_pct_v983')
    if fee is None: fee=0.10
    cost=max(0.0,spread or 0.0)+max(0.0,slip or 0.0)+max(0.0,fee or 0.0)
    numeric={'reaction':reaction,'relative_rank':relative_rank,'money_flow':money,'buy_ratio':buy,'buy_sustain':sustain,
             'rr':rr,'target_distance':target_distance,'invalid_distance':invalid_distance,'spread':spread,'cost':cost}
    return {'ticker':_v1233_ticker(row),'route':_v1236_route_family(row),'market':_v1236_market_family(row),
            'trigger_tf':_v1236_tf(trigger),'invalid_tf':_v1236_tf(invalid),'target_tf':_v1236_tf(target),
            'numeric':numeric,'known_numeric':sum(1 for v in numeric.values() if v is not None),'candidate':candidate}


_V1236_SCALES={'reaction':0.80,'relative_rank':30.0,'money_flow':25.0,'buy_ratio':0.25,'buy_sustain':0.25,
               'rr':1.20,'target_distance':4.0,'invalid_distance':3.0,'spread':0.50,'cost':0.60}
_V1236_WEIGHTS={'reaction':1.25,'relative_rank':1.15,'money_flow':1.15,'buy_ratio':1.0,'buy_sustain':1.0,
                'rr':0.75,'target_distance':0.85,'invalid_distance':0.75,'spread':0.8,'cost':0.9}


def _v1236_similarity(a: Dict[str, Any], b: Dict[str, Any]) -> tuple[float,int,float]:
    av=a.get('numeric') or {}; bv=b.get('numeric') or {}; total=weight=0.0; shared=0
    for key,scale in _V1236_SCALES.items():
        x=av.get(key); y=bv.get(key)
        if x is None or y is None: continue
        w=_V1236_WEIGHTS[key]; shared+=1; weight+=w; total+=w*min(3.0,abs(float(x)-float(y))/scale)
    if shared<V1236_MIN_SHARED_NUMERIC or weight<=0: return 0.0,shared,0.0
    penalty=0.0
    if a.get('route')!='other' and b.get('route')!='other' and a.get('route')!=b.get('route'): penalty+=0.75
    if a.get('market')!='unknown' and b.get('market')!='unknown' and a.get('market')!=b.get('market'): penalty+=0.35
    penalty+=min(0.35,abs(math.log(max(_v1236_tf_minutes(str(a.get('trigger_tf'))),1.0)/max(_v1236_tf_minutes(str(b.get('trigger_tf'))),1.0)))*0.18)
    return 1.0/(1.0+total/weight+penalty),shared,shared/float(len(_V1236_SCALES))


def _v1236_outcome(row: Dict[str, Any], feature: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    feature=feature or _v1236_features(row,False); numeric=feature.get('numeric') or {}
    pnl=_v1233_float(row.get('net_pnl_pct'),row.get('pnl_pct'),default=0.0)
    mfe=_v1233_float(row.get('mfe_pct'),row.get('peak_pct'),default=0.0)
    mae=_v1233_float(row.get('mae_pct'),row.get('trough_pct'),default=0.0)
    giveback=_v1233_float(row.get('giveback_pct'),default=max(0.0,mfe-pnl))
    cost=max(0.0,_v1233_float(row.get('configured_fee_pct'),default=0.10))+max(0.0,_v1233_float(row.get('spread_pct'),default=0.0))+max(0.0,_v1233_float(row.get('paper_reference_cost_pct'),default=0.0))
    opened=_v1236_first_num(row,'opened_at','open_ts','entry_ts'); closed=_v1236_first_num(row,'closed_at','close_ts','exit_ts')
    target_ts=_v1236_first_num(row,'target_first_touch_ts'); invalid_ts=_v1236_first_num(row,'invalid_first_touch_ts')
    reason=str(row.get('exit_reason') or row.get('reason') or '')
    target_reason=reason=='structure_target'; invalid_reason=reason=='structure_invalid'
    target_dist=_v1236_finite(numeric.get('target_distance')); invalid_dist=_v1236_finite(numeric.get('invalid_distance'))
    tol=0.03
    target_path=bool(target_dist is not None and target_dist>0 and mfe>=target_dist-tol)
    invalid_path=bool(invalid_dist is not None and invalid_dist>0 and mae<=-(invalid_dist-tol))
    target_exact=target_ts is not None or target_reason; invalid_exact=invalid_ts is not None or invalid_reason
    if target_reason and target_ts is None: target_ts=closed
    if invalid_reason and invalid_ts is None: invalid_ts=closed
    target_delay=(target_ts-opened) if target_ts is not None and opened is not None and target_ts>=opened else None
    invalid_delay=(invalid_ts-opened) if invalid_ts is not None and opened is not None and invalid_ts>=opened else None
    if target_exact and invalid_exact and target_ts is not None and invalid_ts is not None:
        state='TARGET_FIRST' if target_ts<=invalid_ts else 'INVALID_FIRST'; evidence='EXACT_TOUCH_TIME'
    elif target_exact and not invalid_exact: state='TARGET_FIRST'; evidence='EXACT_REASON_OR_TIME'
    elif invalid_exact and not target_exact: state='INVALID_FIRST'; evidence='EXACT_REASON_OR_TIME'
    elif target_path and invalid_path: state='AMBIGUOUS_BOTH'; evidence='MFE_MAE_INFERRED_NO_ORDER'
    elif target_path: state='TARGET_FIRST'; evidence='MFE_INFERRED'
    elif invalid_path: state='INVALID_FIRST'; evidence='MAE_INFERRED'
    elif closed is not None or reason: state='INTERMEDIATE_EXIT'; evidence='CLOSED_WITHOUT_LINE_TOUCH'
    else: state='UNRESOLVED'; evidence='OPEN_OR_INCOMPLETE'
    hold_sec=_v1233_float(row.get('hold_sec'),default=max(0.0,(closed-opened) if closed is not None and opened is not None else 0.0))
    recovery=max(0.25,cost)
    return {'pnl':pnl,'win':pnl>0.0,'loss':pnl<0.0,'mfe':mfe,'mae':mae,'giveback':giveback,'cost':cost,
            'outcome_state':state,'evidence':evidence,'target_delay':target_delay,'invalid_delay':invalid_delay,
            'target_timing_exact':target_delay is not None,'invalid_timing_exact':invalid_delay is not None,
            'giveback_risk':bool(mfe>=recovery and (pnl<=0.0 or giveback>=max(0.25,mfe*0.55))),
            'tail_loss':bool(pnl<=-1.50),'hold_sec':hold_sec,'closed':closed is not None or bool(reason)}


def _v1236_prepare(rows: list[Dict[str, Any]]) -> list[Dict[str, Any]]:
    out=[]
    for row in rows:
        feature=_v1236_features(row,False); out.append({'row':row,'feature':feature,'outcome':_v1236_outcome(row,feature)})
    return out


def _v1236_weighted_mean(items: list[tuple[float,float]], default: float=0.0) -> float:
    sw=sum(w for _,w in items if w>0)
    return sum(v*w for v,w in items if w>0)/sw if sw>0 else default


def _v1236_prior(prepared: list[Dict[str, Any]]) -> Dict[str, Any]:
    outs=[x['outcome'] for x in prepared]
    if not outs:
        states={k:0.0 for k in V1236_STATES}; states['INTERMEDIATE_EXIT']=1.0
        return {'p_win':0.5,'states':states,'p_giveback':0.35,'p_tail':0.15,'avg_win':0.8,'avg_loss':0.8,'mean':0.0,'std':1.0,'avg_cost':0.10}
    pnl=[o['pnl'] for o in outs]; wins=[v for v in pnl if v>0]; losses=[-v for v in pnl if v<0]
    states={k:sum(1 for o in outs if o['outcome_state']==k)/len(outs) for k in V1236_STATES}
    return {'p_win':sum(1 for o in outs if o['win'])/len(outs),'states':states,
            'p_giveback':sum(1 for o in outs if o['giveback_risk'])/len(outs),'p_tail':sum(1 for o in outs if o['tail_loss'])/len(outs),
            'avg_win':sum(wins)/len(wins) if wins else 0.8,'avg_loss':sum(losses)/len(losses) if losses else 0.8,
            'mean':sum(pnl)/len(pnl),'std':statistics.pstdev(pnl) if len(pnl)>1 else 1.0,'avg_cost':sum(o['cost'] for o in outs)/len(outs)}


def _v1236_probability(success_weight: float,total_weight: float,prior: float,strength: float=V1236_PRIOR_STRENGTH) -> float:
    return (success_weight+prior*strength)/(total_weight+strength) if total_weight+strength>0 else prior


def _v1236_profile(feature: Dict[str, Any], p_giveback: float, p_tail: float, candidate_cost: float) -> tuple[str,Dict[str,Any]]:
    route=str(feature.get('route') or 'other'); n=feature.get('numeric') or {}; trigger_minutes=_v1236_tf_minutes(str(feature.get('trigger_tf') or 'm15')); target_minutes=_v1236_tf_minutes(str(feature.get('target_tf') or 'h2'))
    target_dist=float(n.get('target_distance') or 0.0); invalid_dist=float(n.get('invalid_distance') or 0.0)
    if p_giveback>=0.50: profile='giveback_guard'
    elif route in {'hot_rank','breakout'} and trigger_minutes<=15: profile='fast_breakout'
    elif target_minutes>=120 or target_dist>=5.0: profile='slow_trend'
    elif invalid_dist>=3.5 or float(n.get('spread') or 0.0)>=0.35 or p_tail>=0.28: profile='volatile_structure'
    else: profile='balanced'
    if profile=='fast_breakout': grace=max(3.0,trigger_minutes); no_progress=max(6.0,trigger_minutes*2.0); arm=max(candidate_cost+0.20,0.40); floor=max(0.02,candidate_cost*0.15)
    elif profile=='slow_trend': grace=max(15.0,trigger_minutes); no_progress=max(45.0,trigger_minutes*3.0); arm=max(candidate_cost+0.45,0.80); floor=max(0.05,candidate_cost*0.25)
    elif profile=='giveback_guard': grace=max(5.0,trigger_minutes); no_progress=max(20.0,trigger_minutes*2.0); arm=max(candidate_cost+0.15,0.35); floor=max(0.03,candidate_cost*0.15)
    elif profile=='volatile_structure': grace=max(10.0,trigger_minutes); no_progress=max(30.0,trigger_minutes*2.5); arm=max(candidate_cost+0.35,0.70); floor=max(0.03,candidate_cost*0.20)
    else: grace=max(5.0,trigger_minutes); no_progress=max(20.0,trigger_minutes*2.0); arm=max(candidate_cost+0.25,0.55); floor=max(0.03,candidate_cost*0.20)
    return profile,{'observation_grace_min':round(grace,2),'no_progress_review_min':round(no_progress,2),'profit_protect_arm_pct':round(arm,3),'profit_floor_pct':round(floor,3),'target_invalid_immediate':True,'mode':'SHADOW_ONLY'}


def _v1236_horizon(outcome: Dict[str, Any], sec: float) -> str:
    td=outcome.get('target_delay'); idd=outcome.get('invalid_delay')
    if td is not None and td<=sec and (idd is None or td<=idd): return 'TARGET_FIRST'
    if idd is not None and idd<=sec and (td is None or idd<td): return 'INVALID_FIRST'
    state=outcome.get('outcome_state'); hold=float(outcome.get('hold_sec') or 0.0)
    if state=='INTERMEDIATE_EXIT' and hold<=sec: return 'INTERMEDIATE_EXIT'
    if state=='INTERMEDIATE_EXIT' or (td is not None and td>sec) or (idd is not None and idd>sec): return 'NO_TOUCH_BY_HORIZON'
    return 'UNKNOWN_TIMING'


def _v1236_estimate(candidate: Dict[str, Any], prepared: list[Dict[str, Any]], nowv: Optional[float]=None) -> Dict[str, Any]:
    nowv=nowv or now_ts(); cf=_v1236_features(candidate,True); prior=_v1236_prior(prepared); pool=[]
    for item in prepared:
        sim,shared,coverage=_v1236_similarity(cf,item['feature'])
        if sim<=0: continue
        row=item['row']; closed=_v1236_first_num(row,'closed_at','close_ts') or nowv; age_days=max(0.0,(nowv-closed)/86400.0)
        recency=0.65+0.35*math.exp(-age_days/14.0); route_bonus=1.15 if cf.get('route')==item['feature'].get('route') and cf.get('route')!='other' else 1.0
        pool.append((sim*recency*route_bonus,sim,coverage,item['outcome']))
    pool.sort(key=lambda x:x[0],reverse=True); pool=pool[:V1236_MAX_NEIGHBORS]
    candidate_cost=float((cf.get('numeric') or {}).get('cost') or 0.10)
    if not pool:
        profile,policy=_v1236_profile(cf,prior['p_giveback'],prior['p_tail'],candidate_cost)
        states=prior['states']; conservative=prior['mean']-0.75*prior['std']
        return {'schema':V1236_MODEL_SCHEMA,'state':'LOW','neighbors':0,'effective_n':0.0,'coverage':0.0,'confidence':0.0,
                'p_win':prior['p_win'],'outcome_probs':states,'p_target_first':states['TARGET_FIRST'],'p_invalid_first':states['INVALID_FIRST'],
                'p_intermediate_exit':states['INTERMEDIATE_EXIT'],'p_ambiguous':states['AMBIGUOUS_BOTH'],'p_unresolved':states['UNRESOLVED'],
                'p_giveback':prior['p_giveback'],'p_tail_loss':prior['p_tail'],'expected_net_pct':prior['mean'],'conservative_ev_pct':conservative,
                'uncertainty_penalty_pct':0.75*prior['std'],'profile':profile,'exit_policy':policy,'candidate_cost_pct':candidate_cost,'horizons':{},
                'feature_known':cf.get('known_numeric'),'route':cf.get('route'),'market':cf.get('market')}
    sw=sum(x[0] for x in pool); sw2=sum(x[0]**2 for x in pool); neff=sw*sw/sw2 if sw2>0 else 0.0
    coverage=_v1236_weighted_mean([(x[2],x[0]) for x in pool],0.0); pnl_items=[(x[3]['pnl'],x[0]) for x in pool]; mean_net=_v1236_weighted_mean(pnl_items,prior['mean'])
    std=math.sqrt(max(0.0,_v1236_weighted_mean([((v-mean_net)**2,w) for v,w in pnl_items],prior['std']**2)))
    p_win=_v1236_probability(sum(x[0] for x in pool if x[3]['win']),sw,prior['p_win']); p_loss=_v1236_probability(sum(x[0] for x in pool if x[3]['loss']),sw,1.0-prior['p_win'])
    state_probs={state:_v1236_probability(sum(x[0] for x in pool if x[3]['outcome_state']==state),sw,prior['states'].get(state,0.0)) for state in V1236_STATES}
    total_state=sum(state_probs.values()) or 1.0; state_probs={k:v/total_state for k,v in state_probs.items()}
    p_give=_v1236_probability(sum(x[0] for x in pool if x[3]['giveback_risk']),sw,prior['p_giveback']); p_tail=_v1236_probability(sum(x[0] for x in pool if x[3]['tail_loss']),sw,prior['p_tail'])
    avg_win=_v1236_weighted_mean([(x[3]['pnl'],x[0]) for x in pool if x[3]['pnl']>0],prior['avg_win']); avg_loss=_v1236_weighted_mean([(-x[3]['pnl'],x[0]) for x in pool if x[3]['pnl']<0],prior['avg_loss'])
    hist_cost=_v1236_weighted_mean([(x[3]['cost'],x[0]) for x in pool],prior['avg_cost']); cost_delta=candidate_cost-hist_cost
    probability_ev=p_win*avg_win-p_loss*avg_loss-cost_delta; blended=0.55*probability_ev+0.45*(mean_net-cost_delta)
    standard_error=std/math.sqrt(max(1.0,neff)); unknown_mass=state_probs['AMBIGUOUS_BOTH']+state_probs['UNRESOLVED']
    uncertainty=0.70*standard_error+max(0.0,0.72-coverage)*0.55+0.30/math.sqrt(max(1.0,neff))+0.20*unknown_mass
    risk_penalty=0.22*p_tail*avg_loss+0.10*p_give+0.08*state_probs['INVALID_FIRST']*avg_loss
    conservative=blended-uncertainty-risk_penalty
    confidence=max(0.0,min(100.0,100.0*(0.50*min(1.0,neff/30.0)+0.35*coverage+0.15*_v1236_weighted_mean([(x[1],x[0]) for x in pool],0.0))*(1.0-0.35*unknown_mass)))
    state='HIGH' if neff>=30 and coverage>=0.80 and unknown_mass<0.25 else ('MEDIUM' if neff>=15 and coverage>=0.65 else 'LOW')
    horizons={}
    for hours in (3,6,12):
        sec=hours*3600.0; counts={k:0.0 for k in ('TARGET_FIRST','INVALID_FIRST','INTERMEDIATE_EXIT','NO_TOUCH_BY_HORIZON','UNKNOWN_TIMING')}
        for w,_,_,outcome in pool: counts[_v1236_horizon(outcome,sec)]+=w
        known=sw-counts['UNKNOWN_TIMING']; probs={k:(counts[k]/known if known>0 else None) for k in ('TARGET_FIRST','INVALID_FIRST','INTERMEDIATE_EXIT','NO_TOUCH_BY_HORIZON')}
        horizons[f'{hours}h']={'state_probs_known':probs,'known_evidence_weight':round(known,4),'unknown_timing_weight':round(counts['UNKNOWN_TIMING'],4),'unknown_timing_ratio':round(counts['UNKNOWN_TIMING']/sw,6) if sw>0 else None}
    profile,policy=_v1236_profile(cf,p_give,p_tail,candidate_cost)
    return {'schema':V1236_MODEL_SCHEMA,'state':state,'neighbors':len(pool),'effective_n':round(neff,4),'coverage':round(coverage,4),'confidence':round(confidence,2),
            'p_win':round(p_win,6),'outcome_probs':{k:round(v,6) for k,v in state_probs.items()},'p_target_first':round(state_probs['TARGET_FIRST'],6),
            'p_invalid_first':round(state_probs['INVALID_FIRST'],6),'p_intermediate_exit':round(state_probs['INTERMEDIATE_EXIT'],6),
            'p_ambiguous':round(state_probs['AMBIGUOUS_BOTH'],6),'p_unresolved':round(state_probs['UNRESOLVED'],6),
            'p_giveback':round(p_give,6),'p_tail_loss':round(p_tail,6),'avg_win_pct':round(avg_win,6),'avg_loss_pct':round(avg_loss,6),
            'expected_net_pct':round(blended,6),'conservative_ev_pct':round(conservative,6),'uncertainty_penalty_pct':round(uncertainty+risk_penalty,6),
            'candidate_cost_pct':round(candidate_cost,6),'historical_neighbor_cost_pct':round(hist_cost,6),'profile':profile,'exit_policy':policy,
            'horizons':horizons,'feature_known':cf.get('known_numeric'),'route':cf.get('route'),'market':cf.get('market')}


def _v1236_score_bucket(rows: list[Dict[str, Any]], score_key: str) -> Dict[str, Any]:
    valid=[r for r in rows if _v1236_finite(r.get(score_key)) is not None]; valid.sort(key=lambda r:float(r[score_key]),reverse=True)
    if not valid: return {'evaluable':0,'top_count':0,'top':_v1234_stat([]),'bottom':_v1234_stat([])}
    n=max(1,len(valid)//3); return {'evaluable':len(valid),'top_count':n,'top':_v1234_stat([r['row'] for r in valid[:n]]),'bottom':_v1234_stat([r['row'] for r in valid[-n:]])}


def _v1236_walk_forward(prepared: list[Dict[str, Any]]) -> Dict[str, Any]:
    ordered=sorted(prepared,key=lambda x:_v1236_first_num(x['row'],'closed_at','opened_at') or 0.0); predictions=[]
    for idx,item in enumerate(ordered):
        train=ordered[:idx]
        if len(train)<12: continue
        model=_v1236_estimate(item['row'],train,nowv=_v1236_first_num(item['row'],'closed_at') or now_ts()); quality=_v1234_quality_replay(item['row']); current=_v1236_first_num(item['row'],'global_entry_score_v1212')
        predictions.append({'row':item['row'],'current_score':current,'quality_score':quality.get('score'),'ev_score':model.get('conservative_ev_pct'),'model_state':model.get('state')})
    return {'schema':'policy_walk_forward_v1236','prediction_rows':len(predictions),'minimum_train_rows':12,
            'current_score':_v1236_score_bucket(predictions,'current_score'),'v1211_quality_score':_v1236_score_bucket(predictions,'quality_score'),
            'conservative_ev_score':_v1236_score_bucket(predictions,'ev_score'),'policy_note':'walk-forward; each row uses only earlier CLOSED evidence'}


def _v1236_probability_policy(base: Path, candidate_rows: list[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    perf=read_json(base/'canonical_performance_snapshot_v987.json',{}) or {}; all_rows=[r for r in (perf.get('rows') or []) if isinstance(r,dict)]; current=[]
    for row in all_rows:
        raw=str(row.get('structure_contract_version') or '').strip(); match=re.search(r'structure_contract_v(\d+)',raw) if raw else None
        if match and int(match.group(1))>1211: current.append(row)
    prepared=_v1236_prepare(current); ranked=[]
    for row in candidate_rows:
        model=_v1236_estimate(row,prepared,nowv); quality=_v1234_quality_replay(row)
        ranked.append({'ticker':_v1233_ticker(row),'route':model.get('route'),'market':model.get('market'),'current_stage':str(row.get('s_stage') or row.get('candidate_stage') or ''),
                       'current_score':_v1236_first_num(row,'global_entry_score_v1212','rank_score','score'),'v1211_quality_score':quality.get('score'),
                       'conservative_ev_pct':model.get('conservative_ev_pct'),'expected_net_pct':model.get('expected_net_pct'),'p_win':model.get('p_win'),
                       'p_target_first':model.get('p_target_first'),'p_invalid_first':model.get('p_invalid_first'),'p_intermediate_exit':model.get('p_intermediate_exit'),
                       'p_ambiguous':model.get('p_ambiguous'),'p_unresolved':model.get('p_unresolved'),'p_giveback':model.get('p_giveback'),'p_tail_loss':model.get('p_tail_loss'),
                       'confidence':model.get('confidence'),'state':model.get('state'),'neighbors':model.get('neighbors'),'effective_n':model.get('effective_n'),
                       'coverage':model.get('coverage'),'profile':model.get('profile'),'exit_policy':model.get('exit_policy'),'horizons':model.get('horizons')})
    key=lambda r:(_v1236_finite(r.get('conservative_ev_pct')) if _v1236_finite(r.get('conservative_ev_pct')) is not None else -999.0,_v1236_finite(r.get('confidence')) or 0.0)
    ranked_ev=sorted(ranked,key=key,reverse=True); ranked_current=sorted(ranked,key=lambda r:_v1236_finite(r.get('current_score')) if _v1236_finite(r.get('current_score')) is not None else -999.0,reverse=True); ranked_quality=sorted(ranked,key=lambda r:_v1236_finite(r.get('v1211_quality_score')) if _v1236_finite(r.get('v1211_quality_score')) is not None else -999.0,reverse=True)
    topn=min(20,len(ranked)); ev_t={r['ticker'] for r in ranked_ev[:topn]}; cur_t={r['ticker'] for r in ranked_current[:topn]}; qua_t={r['ticker'] for r in ranked_quality[:topn]}
    states={}; profiles={}
    for r in ranked: states[str(r.get('state') or 'UNKNOWN')]=states.get(str(r.get('state') or 'UNKNOWN'),0)+1; profiles[str(r.get('profile') or 'unknown')]=profiles.get(str(r.get('profile') or 'unknown'),0)+1
    truth_counts={k:0 for k in V1236_STATES}; evidence_counts={}
    for item in prepared:
        o=item['outcome']; truth_counts[o['outcome_state']]=truth_counts.get(o['outcome_state'],0)+1; evidence_counts[o['evidence']]=evidence_counts.get(o['evidence'],0)+1
    return {'schema':V1236_MODEL_SCHEMA,'mode':'SHADOW_ONLY','performance_snapshot_id':perf.get('snapshot_id'),'generated_at':nowv,'history_rows':len(current),
            'truth_label_counts':truth_counts,'truth_evidence_counts':evidence_counts,'candidate_rows':len(ranked),
            'positive_conservative_ev':sum(1 for r in ranked if (_v1236_finite(r.get('conservative_ev_pct')) or -999)>0),'evidence_states':states,'profile_counts':profiles,
            'current_candidates':{'top_ev':ranked_ev[:20],'top_current':ranked_current[:20],'top_v1211_quality':ranked_quality[:20],
                                  'top20_overlap':{'ev_current':len(ev_t&cur_t),'ev_v1211':len(ev_t&qua_t),'current_v1211':len(cur_t&qua_t)}},
            'walk_forward':_v1236_walk_forward(prepared),'invariants':{'actual_candidate_stage_changed':False,'actual_rank_changed':False,'paper_intake_changed':False,'actual_exit_changed':False,'existing_open_changed':False,'core_ledgers_changed':False,'auto_buy':False},
            'limitations':['historical executed trades only','horizon probabilities expose unknown timing instead of treating unknown as loss','no fabricated fills or exit prices']}


# -----------------------------------------------------------------------------
# v1237 - paired current/previous structure x exit-policy matchup
#
# Every arm in one event uses the same observed entry price, timestamp and fee.
# Line exits are exact at Review sampling granularity. The current-exit arm is an
# observable proxy: original target/invalid, 2%/0.8% trailing, response protect,
# 360m no-progress and 3-poll weakness/giveback. It does NOT claim access to the
# Paper-only live support-line owner, so exactness is explicitly PARTIAL_PROXY.
# -----------------------------------------------------------------------------
V1237_PAIR_SCHEMA='paired_structure_exit_matchup_v1241'
V1241_PAIR_STATE_KEY='paired_matchup_v1241'
V1237_PAIR_ARMS=(
    'current_structure_line_exit',
    'previous_structure_line_exit',
    'current_structure_current_exit_proxy',
    'previous_structure_current_exit_proxy',
)
V1237_PRACTICAL_OPEN_CAP=10
V1239_PRACTICAL_NEW_PER_GENERATION=2
V1237_TRAILING_TRIGGER_PCT=2.0
V1237_TRAILING_GIVEBACK_PCT=0.8
V1237_NO_PROGRESS_MIN=360.0


def _v1237_stage(row: Dict[str, Any]) -> str:
    for key in ('s_stage','candidate_stage','final_stage','stage','selector_stage'):
        value=str(row.get(key) or '').strip().upper()
        if value: return value
    gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
    for key in ('s_stage','stage','result_stage'):
        value=str(gate.get(key) or '').strip().upper()
        if value: return value
    return ''


def _v1237_is_s1(row: Dict[str, Any]) -> bool:
    if row.get('is_s1') is True or row.get('s1_ready') is True: return True
    return _v1237_stage(row)=='S1'


def _v1237_pair_lines(row: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    plan=_v1233_nested(row,'dynamic_structure_plan_v1212','structure_contract_v1212')
    shadow=row.get('v1211_structure_shadow_v1222') if isinstance(row.get('v1211_structure_shadow_v1222'),dict) else {}
    cur={k:_v1233_line_price(plan.get(k)) for k in ('trigger','invalid','target')}
    old={k:_v1233_line_price(shadow.get(k)) for k in ('trigger','invalid','target')}
    if shadow.get('source_exact') is not True: return None
    if not (0<cur['invalid']<cur['trigger']<cur['target']): return None
    if not (0<old['invalid']<old['trigger']<old['target']): return None
    return {'current':cur,'previous':old}


def _v1237_pair_id(row: Dict[str, Any], lines: Dict[str, Any]) -> str:
    ticker=_v1233_ticker(row)
    sig='|'.join([ticker]+[_v1236_sig_price(lines[group][name]) for group in ('current','previous') for name in ('trigger','invalid','target')])
    return hashlib.sha256(sig.encode('utf-8')).hexdigest()[:24]


def _v1237_score(row: Dict[str, Any]) -> float:
    return _v1233_float(row.get('global_entry_score_v1212'),row.get('rank_score'),row.get('score'),default=0.0)


def _v1237_cost(row: Dict[str, Any]) -> float:
    fee=max(0.0,_v1233_float(row.get('configured_fee_pct'),default=V1233_SHADOW_FEE_PCT))
    spread=max(0.0,_v1233_float(row.get('spread_pct'),default=0.0))
    slip=max(0.0,_v1233_float(row.get('paper_reference_cost_pct'),default=0.0))
    return fee+spread+slip


def _v1237_strength_snapshot(row: Dict[str, Any]) -> tuple[int,int]:
    def val(*keys: str) -> Optional[float]:
        for key in keys:
            if row.get(key) not in (None,''):
                try: return float(row.get(key))
                except Exception: pass
        return None
    reaction=val('price_reaction_pct','reaction_pct')
    relative=val('relative_strength_rank_pct','relative_strength')
    money=val('money_flow_score','money_flow')
    buy=val('buy_ratio','buy_execution_ratio')
    sustain=val('buy_sustain_1m','buy_sustain')
    strong=weak=0
    for value,good,bad in ((reaction,0.05,-0.20),(relative,55.0,45.0),(money,55.0,45.0),(buy,0.52,0.45),(sustain,0.50,0.42)):
        if value is None: continue
        if value>=good: strong+=1
        elif value<=bad: weak+=1
    return strong,weak


def _v1237_new_arm(structure: str, mode: str, lines: Dict[str,float], nowv: float) -> Dict[str, Any]:
    return {'structure':structure,'exit_mode':mode,'invalid_price':lines['invalid'],'target_price':lines['target'],
            'closed':False,'weak_streak':0,'opened_ts':nowv}


def _v1239_generation_context(base: Path) -> Dict[str, str]:
    """Read the committed Strategy generation from its canonical Review request.

    Candidate rows are written before the candidate commit id is created, so a
    row-local generation key is incomplete.  The immutable Review request is
    written after the candidate snapshot, priority request and Paper handoff all
    share the same cycle+commit pair.  Missing either half is fail-closed for the
    practical board; the unlimited board remains observation-only.
    """
    request=read_json(SpinePaths(base).review_request,{}) or {}
    cycle=str(request.get('pipeline_cycle_id') or request.get('candidate_pipeline_cycle_id_v1150') or '').strip()
    commit=str(request.get('candidate_commit_id') or request.get('candidate_commit_id_v1150') or '').strip()
    key=f"{cycle}|{commit}" if cycle and commit else ''
    return {'cycle_id':cycle,'candidate_commit_id':commit,'generation_key':key,
            'state':'NORMAL' if key else 'CHECK_MISSING_CYCLE_OR_COMMIT'}


def _v1237_new_event(row: Dict[str, Any], lines: Dict[str, Any], price: float, nowv: float, scope: str, generation: Dict[str,str]) -> Dict[str, Any]:
    event_id=_v1237_pair_id(row,lines); cost=_v1237_cost(row); generation_key=str(generation.get('generation_key') or '')
    return {'event_id':event_id,'semantic_event_id':event_id,'ticker':_v1233_ticker(row),'scope':scope,
            'opened_ts':nowv,'opened_text':now_text(nowv),'entry_price':price,'last_price':price,'high_price':price,'low_price':price,
            'fee_and_execution_cost_pct':cost,'rank_score':_v1237_score(row),'route':str(row.get('route') or row.get('entry_route') or ''),
            'candidate_cycle_id':generation.get('cycle_id'),'candidate_commit_id':generation.get('candidate_commit_id'),
            'candidate_generation_key':generation_key,
            'line_pair':lines,'arms':{
                'current_structure_line_exit':_v1237_new_arm('current','LINE_ONLY',lines['current'],nowv),
                'previous_structure_line_exit':_v1237_new_arm('previous','LINE_ONLY',lines['previous'],nowv),
                'current_structure_current_exit_proxy':_v1237_new_arm('current','CURRENT_POLICY_OBSERVABLE_PROXY',lines['current'],nowv),
                'previous_structure_current_exit_proxy':_v1237_new_arm('previous','CURRENT_POLICY_OBSERVABLE_PROXY',lines['previous'],nowv),
            },'last_update_ts':nowv}


def _v1237_close_arm(arm: Dict[str, Any], event: Dict[str, Any], price: float, nowv: float, reason: str) -> None:
    if arm.get('closed'): return
    entry=_v1233_float(event.get('entry_price'),default=0.0); cost=_v1233_float(event.get('fee_and_execution_cost_pct'),default=0.0)
    gross=_v1233_return_pct(price,entry) or 0.0
    arm.update({'closed':True,'closed_ts':nowv,'closed_text':now_text(nowv),'close_price':price,'exit_reason':reason,
                'gross_pnl_pct':gross,'net_pnl_pct':gross-cost,'hold_sec':max(0.0,nowv-_v1233_float(event.get('opened_ts'),default=nowv)),
                'mfe_pct':_v1233_return_pct(_v1233_float(event.get('high_price'),default=price),entry) or 0.0,
                'mae_pct':_v1233_return_pct(_v1233_float(event.get('low_price'),default=price),entry) or 0.0})
    arm['giveback_pct']=max(0.0,_v1233_float(arm.get('mfe_pct'),default=0.0)-_v1233_float(arm.get('net_pnl_pct'),default=0.0))


def _v1237_update_arm(arm: Dict[str, Any], event: Dict[str, Any], row: Dict[str, Any], price: float, nowv: float) -> None:
    if arm.get('closed'): return
    invalid=_v1233_float(arm.get('invalid_price'),default=0.0); target=_v1233_float(arm.get('target_price'),default=0.0)
    if price<=invalid: _v1237_close_arm(arm,event,price,nowv,'INVALID'); return
    if price>=target: _v1237_close_arm(arm,event,price,nowv,'TARGET'); return
    if arm.get('exit_mode')!='CURRENT_POLICY_OBSERVABLE_PROXY': return
    entry=_v1233_float(event.get('entry_price'),default=0.0); cost=_v1233_float(event.get('fee_and_execution_cost_pct'),default=0.0)
    net=(_v1233_return_pct(price,entry) or 0.0)-cost
    peak=(_v1233_return_pct(_v1233_float(event.get('high_price'),default=price),entry) or 0.0)-cost
    giveback=max(0.0,peak-net); age_min=max(0.0,nowv-_v1233_float(event.get('opened_ts'),default=nowv))/60.0
    strong,weak=_v1237_strength_snapshot(row)
    arm['weak_streak']=int(arm.get('weak_streak') or 0)+1 if weak>=3 and weak>strong else 0
    arm['last_strength_count']=strong; arm['last_weakness_count']=weak
    recovery=max(0.25,cost)
    if peak>=V1237_TRAILING_TRIGGER_PCT and giveback>=V1237_TRAILING_GIVEBACK_PCT and net>0:
        _v1237_close_arm(arm,event,price,nowv,'POLICY_PROXY_TRAILING'); return
    if peak>=recovery and net<=0:
        _v1237_close_arm(arm,event,price,nowv,'POLICY_PROXY_RESPONSE_PROTECT'); return
    ratio=(giveback/peak) if peak>0 else 0.0
    if int(arm.get('weak_streak') or 0)>=3 and ratio>=0.55 and weak>strong:
        _v1237_close_arm(arm,event,price,nowv,'POLICY_PROXY_MOMENTUM_DECAY'); return
    if age_min>=V1237_NO_PROGRESS_MIN and peak<0.35 and net<=0:
        _v1237_close_arm(arm,event,price,nowv,'POLICY_PROXY_NO_PROGRESS')


def _v1237_scope_root(state: Dict[str, Any], scope: str) -> Dict[str, Any]:
    root=state.setdefault(V1241_PAIR_STATE_KEY,{}).setdefault(scope,{})
    root.setdefault('open',{}); root.setdefault('closed',[]); root.setdefault('skipped',[])
    return root


def _v1237_seen(root: Dict[str, Any]) -> set[str]:
    out=set(root.get('open',{}).keys())
    out.update(str(x.get('event_id')) for x in root.get('closed',[]) if isinstance(x,dict))
    out.update(str(x.get('event_id')) for x in root.get('skipped',[]) if isinstance(x,dict))
    return out


def _v1239_generation_event_counts(root: Dict[str, Any]) -> Dict[str, int]:
    counts: Dict[str, int] = {}
    events=[]
    events.extend(x for x in (root.get('open',{}) or {}).values() if isinstance(x,dict))
    events.extend(x for x in (root.get('closed',[]) or []) if isinstance(x,dict))
    events.extend(x for x in (root.get('skipped',[]) or []) if isinstance(x,dict))
    for event in events:
        key=str(event.get('candidate_generation_key') or '').strip()
        if key:
            counts[key]=counts.get(key,0)+1
    return counts


def _v1237_update_open(root: Dict[str, Any], rows_by_ticker: Dict[str,Dict[str,Any]], prices: Dict[str,float], nowv: float) -> None:
    cutoff=nowv-V1233_RETENTION_SEC
    root['closed']=[x for x in root.get('closed',[]) if isinstance(x,dict) and _v1233_float(x.get('terminal_ts'),default=0.0)>=cutoff]
    root['skipped']=[x for x in root.get('skipped',[]) if isinstance(x,dict) and _v1233_float(x.get('ts'),default=0.0)>=cutoff]
    for event_id in list(root.get('open',{})):
        event=root['open'].get(event_id) if isinstance(root['open'].get(event_id),dict) else {}
        ticker=str(event.get('ticker') or ''); row=rows_by_ticker.get(ticker,{})
        price=prices.get(ticker,_v1233_float(event.get('last_price'),default=0.0))
        if price<=0: continue
        event['last_price']=price; event['last_update_ts']=nowv
        event['high_price']=max(_v1233_float(event.get('high_price'),default=price),price)
        low=_v1233_float(event.get('low_price'),default=price); event['low_price']=min(low if low>0 else price,price)
        for arm in (event.get('arms') or {}).values():
            if isinstance(arm,dict): _v1237_update_arm(arm,event,row,price,nowv)
        if nowv-_v1233_float(event.get('opened_ts'),default=nowv)>=V1233_RETENTION_SEC:
            for arm in (event.get('arms') or {}).values():
                if isinstance(arm,dict) and not arm.get('closed'): _v1237_close_arm(arm,event,price,nowv,'REVIEW_24H_TIMEOUT')
        if all(isinstance(arm,dict) and arm.get('closed') for arm in (event.get('arms') or {}).values()):
            event['terminal_ts']=max(_v1233_float(arm.get('closed_ts'),default=nowv) for arm in event['arms'].values())
            root['open'].pop(event_id,None); root['closed'].append(event)


def _v1237_eligible(rows: list[Dict[str,Any]], nowv: float) -> list[tuple[float,Dict[str,Any],Dict[str,Any],float]]:
    out=[]
    for row in rows:
        lines=_v1237_pair_lines(row); price=_v1233_price(row)
        if not lines or not _v1237_is_s1(row) or price<=0: continue
        if price<=max(lines['current']['invalid'],lines['previous']['invalid']): continue
        if price>=min(lines['current']['target'],lines['previous']['target']): continue
        # S1 is the canonical observed entry-ready event. Both structures use this same price/time.
        out.append((_v1237_score(row),row,lines,price))
    out.sort(key=lambda x:x[0],reverse=True)
    return out


def _v1237_metric(events: list[Dict[str,Any]], arm_key: str, cutoff: float=0.0) -> Dict[str,Any]:
    rows=[]
    for event in events:
        arm=(event.get('arms') or {}).get(arm_key) if isinstance(event.get('arms'),dict) else None
        if not isinstance(arm,dict) or not arm.get('closed') or _v1233_float(arm.get('closed_ts'),default=0.0)<cutoff: continue
        rows.append(arm)
    return _v1234_stat(rows)


def _v1237_deltas(events: list[Dict[str,Any]]) -> Dict[str,Any]:
    pairs={
        'previous_minus_current_line':('previous_structure_line_exit','current_structure_line_exit'),
        'previous_minus_current_policy_proxy':('previous_structure_current_exit_proxy','current_structure_current_exit_proxy'),
        'policy_proxy_minus_line_current_structure':('current_structure_current_exit_proxy','current_structure_line_exit'),
        'policy_proxy_minus_line_previous_structure':('previous_structure_current_exit_proxy','previous_structure_line_exit'),
    }
    out={}
    for name,(a,b) in pairs.items():
        vals=[]
        for event in events:
            arms=event.get('arms') if isinstance(event.get('arms'),dict) else {}; aa=arms.get(a); bb=arms.get(b)
            if isinstance(aa,dict) and isinstance(bb,dict) and aa.get('closed') and bb.get('closed'):
                vals.append(_v1233_float(aa.get('net_pnl_pct'),default=0.0)-_v1233_float(bb.get('net_pnl_pct'),default=0.0))
        out[name]={'paired_count':len(vals),'avg_delta_pct':sum(vals)/len(vals) if vals else None,'positive_delta_count':sum(1 for x in vals if x>0)}
    return out


def _v1237_scope_summary(root: Dict[str,Any], nowv: float) -> Dict[str,Any]:
    events=[x for x in root.get('closed',[]) if isinstance(x,dict)]+[x for x in (root.get('open',{}) or {}).values() if isinstance(x,dict)]
    windows={}
    for label,sec in (('recent_3h',10800),('recent_6h',21600),('recent_12h',43200),('recent_24h',86400)):
        windows[label]={arm:_v1237_metric(events,arm,nowv-sec) for arm in V1237_PAIR_ARMS}
    return {'open_count':len(root.get('open',{}) or {}),'closed_event_count':len(root.get('closed',[]) or []),'skipped_count':len(root.get('skipped',[]) or []),
            'arm_metrics':{arm:_v1237_metric(events,arm,0.0) for arm in V1237_PAIR_ARMS},'windows':windows,'paired_deltas':_v1237_deltas(events)}


def _v1237_update_matchup(state: Dict[str,Any], rows: list[Dict[str,Any]], prices: Dict[str,float], nowv: float, generation: Optional[Dict[str,str]]=None) -> Dict[str,Any]:
    rows_by_ticker={_v1233_ticker(row):row for row in rows if _v1233_ticker(row)}
    unlimited=_v1237_scope_root(state,'unlimited'); practical=_v1237_scope_root(state,'practical')
    _v1237_update_open(unlimited,rows_by_ticker,prices,nowv); _v1237_update_open(practical,rows_by_ticker,prices,nowv)
    eligible=_v1237_eligible(rows,nowv)
    generation=dict(generation or {})
    generation_key=str(generation.get('generation_key') or '').strip()
    generation_state='NORMAL' if generation_key and generation.get('cycle_id') and generation.get('candidate_commit_id') else 'CHECK_MISSING_CYCLE_OR_COMMIT'
    generation['state']=generation_state
    for _score,row,lines,price in eligible:
        event_id=_v1237_pair_id(row,lines)
        if event_id not in _v1237_seen(unlimited): unlimited['open'][event_id]=_v1237_new_event(row,lines,price,nowv,'unlimited',generation)
    capacity=max(0,V1237_PRACTICAL_OPEN_CAP-len(practical.get('open',{}) or {})); opened=0; seen=_v1237_seen(practical)
    generation_counts=_v1239_generation_event_counts(practical); generation_missing=len(eligible) if generation_state!='NORMAL' else 0; opened_by_generation: Dict[str,int]={}
    if generation_state=='NORMAL':
        for _score,row,lines,price in eligible:
            if opened>=capacity: break
            event_id=_v1237_pair_id(row,lines)
            if event_id in seen: continue
            if generation_counts.get(generation_key,0)>=V1239_PRACTICAL_NEW_PER_GENERATION:
                continue
            practical['open'][event_id]=_v1237_new_event(row,lines,price,nowv,'practical',generation)
            seen.add(event_id); opened+=1
            generation_counts[generation_key]=generation_counts.get(generation_key,0)+1
            opened_by_generation[generation_key]=opened_by_generation.get(generation_key,0)+1
    state[V1241_PAIR_STATE_KEY]['last_cycle']={'ts':nowv,'available_pair_rows':sum(1 for row in rows if _v1237_pair_lines(row)),'entry_ready_pairs':len(eligible),'committed_s1_rows':sum(1 for row in rows if stage(row)=='S1'),'practical_opened_this_review_cycle':opened,'generation_key_missing_rows':generation_missing,'opened_by_generation':opened_by_generation,'generation_state':generation_state,'candidate_pipeline_cycle_id_v1150':generation.get('cycle_id'),'candidate_commit_id':generation.get('candidate_commit_id')}
    legacy=state.get('paired_matchup_v1237') if isinstance(state.get('paired_matchup_v1237'),dict) else {}
    legacy_open=sum(len((legacy.get(scope) or {}).get('open') or {}) for scope in ('unlimited','practical') if isinstance(legacy.get(scope),dict))
    legacy_closed=sum(len((legacy.get(scope) or {}).get('closed') or []) for scope in ('unlimited','practical') if isinstance(legacy.get(scope),dict))
    return {'schema':V1237_PAIR_SCHEMA,'mode':'SHADOW_ONLY','generated_ts':nowv,
            'available_pair_rows':state[V1241_PAIR_STATE_KEY]['last_cycle']['available_pair_rows'],'entry_ready_pairs':len(eligible),'committed_s1_rows':state[V1241_PAIR_STATE_KEY]['last_cycle']['committed_s1_rows'],
            'unlimited':_v1237_scope_summary(unlimited,nowv),'practical':_v1237_scope_summary(practical,nowv),
            'same_entry_contract':True,'same_entry_price_time_fee_within_event':True,
            'practical_contract':{'open_cap':V1237_PRACTICAL_OPEN_CAP,'new_per_generation':V1239_PRACTICAL_NEW_PER_GENERATION,'generation_owner':'review_observation_request_v1181.pipeline_cycle_id + candidate_commit_id','missing_generation_key':'CHECK_SKIP','selection':'current canonical global score'},
            'exactness':{'line_exit':'REVIEW_SAMPLED_EXACT','current_exit':'PARTIAL_OBSERVABLE_PROXY','missing_from_proxy':['Paper live support-line owner','exact strength/weakness poll sequence between Review samples']},
            'dedupe':'ticker + current sealed lines + previous sealed lines; one semantic event inside 24h retention','generation_cap_repair_v1239':True,
            'generation_alignment_repair_v1241':True,
            'legacy_pre_v1241_excluded':{'state_key':'paired_matchup_v1237','open_count':legacy_open,'closed_count':legacy_closed,'reason':'candidate rows could be read between committed Review generations'},
            'last_cycle':state[V1241_PAIR_STATE_KEY]['last_cycle'],
            'invariants':{'actual_candidate_rank_changed':False,'actual_s1_changed':False,'paper_intake_changed':False,'actual_exit_changed':False,'existing_open_changed':False,'core_ledgers_changed':False,'auto_buy':False}}

def _v1234_shadow_signature(event: Dict[str, Any]) -> str:
    return '|'.join((str(event.get('ticker') or ''),f"{_v1233_float(event.get('trigger_price'),default=0.0):.12g}",f"{_v1233_float(event.get('invalid_price'),default=0.0):.12g}",f"{_v1233_float(event.get('target_price'),default=0.0):.12g}"))


def _v1236_shadow_signature_event(event: Dict[str, Any]) -> str:
    ticker=str(event.get('ticker') or '').upper(); trigger=_v1236_sig_price(_v1233_float(event.get('trigger_price'),default=0.0)); invalid=_v1236_sig_price(_v1233_float(event.get('invalid_price'),default=0.0)); target=_v1236_sig_price(_v1233_float(event.get('target_price'),default=0.0))
    return f"{ticker}|{trigger}|{invalid}|{target}"


def _v1236_compact_state(state: Dict[str, Any], nowv: float) -> Dict[str, int]:
    stats={'missed_before':0,'missed_after':0,'shadow_before':0,'shadow_after':0,'removed':0}
    missed=state.setdefault('missed',{}).setdefault('events',{}); stats['missed_before']=len(missed)
    merged={}
    for event in missed.values():
        if not isinstance(event,dict): continue
        # Old v1235 rows did not preserve lines; collapse their cycle copies by ticker/reason.
        line_sig='|'.join(_v1236_sig_price(_v1233_float(event.get(k),default=0.0)) for k in ('trigger_price','invalid_price','target_price','intermediate_price'))
        base=f"{str(event.get('ticker') or '').upper()}|{event.get('reason') or ''}|{line_sig if line_sig.replace('|','').replace('0','') else 'legacy'}"
        key=hashlib.sha256(base.encode()).hexdigest()[:24]; old=merged.get(key)
        if old is None: old=dict(event); old['event_id']=key; old['semantic_event_id']=key; merged[key]=old
        else:
            old['created_ts']=min(_v1233_float(old.get('created_ts'),default=nowv),_v1233_float(event.get('created_ts'),default=nowv))
            old['high_price']=max(_v1233_float(old.get('high_price'),default=0.0),_v1233_float(event.get('high_price'),default=0.0))
            lows=[x for x in (_v1233_float(old.get('low_price'),default=0.0),_v1233_float(event.get('low_price'),default=0.0)) if x>0]; old['low_price']=min(lows) if lows else 0.0
            if _v1233_float(event.get('last_seen_ts'),default=0.0)>=_v1233_float(old.get('last_seen_ts'),default=0.0):
                for k in ('last_seen_ts','current_price','current_return_pct','age_sec'): old[k]=event.get(k)
    state['missed']['events']=merged; stats['missed_after']=len(merged)
    shadow=state.setdefault('previous_structure_shadow',{}); all_before=sum(len(shadow.get(k) or {}) if isinstance(shadow.get(k),dict) else len(shadow.get(k) or []) for k in ('pending','open','closed','skipped')); stats['shadow_before']=all_before
    closed_map={}
    for event in shadow.get('closed',[]) if isinstance(shadow.get('closed'),list) else []:
        if not isinstance(event,dict): continue
        sig=_v1236_shadow_signature_event(event)+'|'+str(event.get('exit_reason') or ''); key=hashlib.sha256(sig.encode()).hexdigest()[:24]
        if key not in closed_map or _v1233_float(event.get('closed_ts'),default=0.0)<_v1233_float(closed_map[key].get('closed_ts'),default=1e30):
            clone=dict(event); clone['event_id']=key; clone['semantic_event_id']=key; closed_map[key]=clone
    skipped_map={}
    for event in shadow.get('skipped',[]) if isinstance(shadow.get('skipped'),list) else []:
        if not isinstance(event,dict): continue
        sig=_v1236_shadow_signature_event(event)+'|'+str(event.get('reason') or ''); key=hashlib.sha256(sig.encode()).hexdigest()[:24]
        if key not in skipped_map: clone=dict(event); clone['event_id']=key; clone['semantic_event_id']=key; skipped_map[key]=clone
    terminal={_v1236_shadow_signature_event(x) for x in closed_map.values()}|{_v1236_shadow_signature_event(x) for x in skipped_map.values()}
    for bucket in ('open','pending'):
        result={}
        source=shadow.get(bucket) if isinstance(shadow.get(bucket),dict) else {}
        for event in source.values():
            if not isinstance(event,dict): continue
            sig=_v1236_shadow_signature_event(event)
            if sig in terminal: continue
            key=hashlib.sha256(sig.encode()).hexdigest()[:24]
            old=result.get(key)
            if old is None: clone=dict(event); clone['event_id']=key; clone['semantic_event_id']=key; result[key]=clone
            else:
                old['high_price']=max(_v1233_float(old.get('high_price'),default=0.0),_v1233_float(event.get('high_price'),default=0.0)); lows=[x for x in (_v1233_float(old.get('low_price'),default=0.0),_v1233_float(event.get('low_price'),default=0.0)) if x>0]; old['low_price']=min(lows) if lows else 0.0
        shadow[bucket]=result
    shadow['closed']=list(closed_map.values()); shadow['skipped']=list(skipped_map.values())
    stats['shadow_after']=sum(len(shadow.get(k) or {}) if isinstance(shadow.get(k),dict) else len(shadow.get(k) or []) for k in ('pending','open','closed','skipped'))
    stats['removed']=(stats['missed_before']-stats['missed_after'])+(stats['shadow_before']-stats['shadow_after'])
    state['semantic_compaction_v1236']={**stats,'ts':nowv}
    return stats


def _v1237_load_state(base: Path, nowv: float) -> Dict[str, Any]:
    current=read_json(version_score_state_path(base),{}) or {}
    if isinstance(current,dict) and current.get('schema')==V1233_STATE_SCHEMA:
        _v1236_compact_state(current,nowv); current.setdefault('paired_matchup_v1237',{}); current.setdefault(V1241_PAIR_STATE_KEY,{}); return current
    prior=read_json(base/'version_score_review_state_v1236.json',{}) or {}
    if isinstance(prior,dict) and prior:
        state=dict(prior); state['schema']=V1233_STATE_SCHEMA; state['migration_v1237_from_v1236']={'performed':True,'source':'version_score_review_state_v1236.json','ts':nowv}; _v1236_compact_state(state,nowv); state.setdefault('paired_matchup_v1237',{}); state.setdefault(V1241_PAIR_STATE_KEY,{}); return state
    prior=read_json(base/'version_score_review_state_v1235.json',{}) or {}
    if isinstance(prior,dict) and prior:
        state=dict(prior); state['schema']=V1233_STATE_SCHEMA; state['migration_v1237_from_v1235']={'performed':True,'source':'version_score_review_state_v1235.json','ts':nowv}; _v1236_compact_state(state,nowv); state.setdefault('paired_matchup_v1237',{}); state.setdefault(V1241_PAIR_STATE_KEY,{}); return state
    state=_v1233_empty_state(nowv); state.setdefault('paired_matchup_v1237',{}); state.setdefault(V1241_PAIR_STATE_KEY,{}); _v1236_compact_state(state,nowv); return state

def _v1241_candidate_bytes(path: Path) -> tuple[bytes,list[Dict[str,Any]]]:
    raw=path.read_bytes()
    rows=[]
    for line_no,line in enumerate(raw.decode('utf-8',errors='strict').splitlines(),1):
        if not line.strip():
            continue
        obj=json.loads(line)
        if not isinstance(obj,dict):
            raise TypeError(f'candidate row {line_no} is not object')
        rows.append(obj)
    return raw,rows


def _v1241_request_generation(request: Dict[str,Any]) -> Dict[str,Any]:
    cycle=str(request.get('pipeline_cycle_id') or request.get('candidate_pipeline_cycle_id_v1150') or '').strip()
    commit=str(request.get('candidate_commit_id') or request.get('candidate_commit_id_v1150') or '').strip()
    return {'cycle_id':cycle,'candidate_commit_id':commit,'generation_key':f'{cycle}|{commit}' if cycle and commit else '',
            'state':'NORMAL' if cycle and commit else 'CHECK_MISSING_CYCLE_OR_COMMIT'}



def _v1317_read_generation_candidate_rows(request: Dict[str,Any], fallback_path: Path) -> tuple[bytes,list[Dict[str,Any]],str]:
    path_text = str(request.get('committed_candidate_file_v1317') or '').strip()
    expected_digest = str(request.get('committed_candidate_file_sha256_v1317') or '').strip()
    path = Path(path_text) if path_text else fallback_path
    raw = path.read_bytes()
    rows=[]
    for line_no,line in enumerate(raw.decode('utf-8',errors='strict').splitlines(),1):
        if not line.strip():
            continue
        obj=json.loads(line)
        if not isinstance(obj,dict):
            raise TypeError(f'candidate row {line_no} is not object')
        rows.append(obj)
    digest = hashlib.sha256(raw).hexdigest()
    if path_text and expected_digest and digest != expected_digest:
        raise RuntimeError(f'v1317 candidate generation digest mismatch expected={expected_digest} actual={digest}')
    return raw,rows,('IMMUTABLE_CANDIDATE_GENERATION_V1317' if path_text else 'ROLLING_LATEST_FALLBACK')

def _v1241_stable_committed_rows(base: Path, request: Dict[str,Any], require_pipeline: bool) -> tuple[list[Dict[str,Any]],Dict[str,Any]]:
    paths=SpinePaths(base); generation=_v1241_request_generation(request)
    cycle=generation['cycle_id']; commit=generation['candidate_commit_id']
    if generation['state']!='NORMAL':
        raise RuntimeError('v1241 committed Review request missing cycle/commit')
    raw1,rows,reader_source_v1317=_v1317_read_generation_candidate_rows(request, paths.strategy_candidates)
    if reader_source_v1317 == 'ROLLING_LATEST_FALLBACK':
        raw2=paths.strategy_candidates.read_bytes()
        if raw1!=raw2:
            raise RuntimeError('v1241 candidate file changed during stable read')
    digest=hashlib.sha256(raw1).hexdigest()
    reader_source_v1317 = locals().get('reader_source_v1317', 'UNKNOWN')
    row_cycles={str(r.get('candidate_pipeline_cycle_id_v1150') or '').strip() for r in rows}
    if row_cycles!={cycle}:
        raise RuntimeError(f'v1241 candidate cycle mismatch request={cycle} rows={sorted(row_cycles)}')
    expected=integer(request.get('candidate_rows'),default=-1)
    if expected>=0 and expected!=len(rows):
        raise RuntimeError(f'v1241 candidate row mismatch request={expected} file={len(rows)}')
    canonical_s1=sum(1 for row in rows if stage(row)=='S1')
    expected_s1=integer(request.get('s1_count'),default=-1)
    if expected_s1>=0 and expected_s1!=canonical_s1:
        raise RuntimeError(f'v1241 S1 mismatch request={expected_s1} canonical={canonical_s1}')
    pipeline=read_json(paths.strategy_pipeline,{}) or {}
    pipeline_proof_source='NOT_REQUIRED'
    if require_pipeline:
        current_cycle=str(pipeline.get('cycle_id') or '').strip()
        current_commit=str(pipeline.get('candidate_commit_id') or '').strip()
        current_ok=(
            str(pipeline.get('state') or '').upper()=='NORMAL'
            and pipeline.get('complete') is True
            and current_cycle==cycle
            and current_commit==commit
            and pipeline.get('all_required_commits_v1150') is True
        )
        last_complete=pipeline.get('last_complete_cycle_v1152') if isinstance(pipeline.get('last_complete_cycle_v1152'),dict) else {}
        last_cycle=str(last_complete.get('cycle_id') or '').strip()
        last_commit=str(last_complete.get('candidate_commit_id') or '').strip()
        last_required=(last_complete.get('all_required_commits') is True or last_complete.get('all_required_commits_v1150') is True)
        last_ok=(
            str(last_complete.get('state') or '').upper()=='NORMAL'
            and last_cycle==cycle
            and last_commit==commit
            and last_required
        )
        if current_ok:
            pipeline_proof_source='CURRENT_NORMAL'
            proof=current=dict(pipeline)
        elif last_ok:
            pipeline_proof_source='LAST_COMPLETE_NORMAL'
            proof=dict(last_complete)
        else:
            raise RuntimeError(
                'v1247 no completed pipeline proof for Review request '
                f'request={cycle}/{commit} current={current_cycle}/{current_commit}/'
                f'{str(pipeline.get("state") or "").upper()} last={last_cycle}/{last_commit}/'
                f'{str(last_complete.get("state") or "").upper()}'
            )
        request_handoff_id=str(request.get('committed_handoff_id') or '').strip()
        request_handoff_digest=str(request.get('committed_handoff_digest') or '').strip()
        proof_handoff_id=str(proof.get('committed_handoff_id_v1158') or '').strip()
        proof_handoff_digest=str(proof.get('committed_handoff_digest_v1158') or '').strip()
        if request_handoff_id and proof_handoff_id and request_handoff_id!=proof_handoff_id:
            raise RuntimeError('v1247 committed handoff id differs from completed pipeline proof')
        if request_handoff_digest and proof_handoff_digest and request_handoff_digest!=proof_handoff_digest:
            raise RuntimeError('v1247 committed handoff digest differs from completed pipeline proof')
    integrity={'schema':'review_committed_generation_integrity_v1241','state':'NORMAL','cycle_id':cycle,
               'candidate_commit_id':commit,'generation_key':generation['generation_key'],'candidate_rows':len(rows),
               'canonical_s1_rows':canonical_s1,'candidate_file_sha256':digest,'candidate_reader_source_v1317':reader_source_v1317,'pipeline_checked':bool(require_pipeline),
               'pipeline_proof_source_v1247':pipeline_proof_source,
               'selection_source':'stable candidate bytes matching completed Review request','live_price_source':'latest candidate file price fields only'}
    return rows,integrity


def _v1241_set_committed_rows(rows: list[Dict[str,Any]], integrity: Dict[str,Any]) -> None:
    global _COMMITTED_ROWS_V1241,_COMMITTED_IDENTITY_V1241,_COMMITTED_DIGEST_V1241,_COMMITTED_INTEGRITY_V1241
    _COMMITTED_ROWS_V1241=list(rows)
    _COMMITTED_IDENTITY_V1241=(str(integrity.get('candidate_commit_id') or ''),str(integrity.get('cycle_id') or ''))
    _COMMITTED_DIGEST_V1241=str(integrity.get('candidate_file_sha256') or '')
    _COMMITTED_INTEGRITY_V1241=dict(integrity)


# v1257 singleization: removed the pre-v1257 competing Review writer that
# updated missed-candidate, v1211 virtual, hybrid, probability, paired-matchup
# and exact replay state in one function. Historical state files and source
# diffs remain in the package; no active writer or fallback remains here.



def base_dir() -> Path:
    override = os.getenv("COINBOT_BASE_DIR", "").strip()
    return Path(override).expanduser().resolve() if override else Path(__file__).resolve().parent


def status_path(base: Path) -> Path:
    return base / "clean_review_worker_status.json"


def error_path(base: Path) -> Path:
    return base / "clean_review_worker_error.log"


def pid_path(base: Path) -> Path:
    return base / "review_worker.pid"


def lock_path(base: Path) -> Path:
    return base / "runtime" / "review_worker_singleton_v1121.lock"


def log_error(base: Path, where: str, exc: BaseException) -> None:
    path = error_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    message = (
        f"[{now_text()}] {where}: {type(exc).__name__}: {exc}\n"
        f"{traceback.format_exc()[-4000:]}\n"
    )
    with path.open("a", encoding="utf-8") as handle:
        handle.write(message)


def write_status(base: Path, state: str, **extra: Any) -> Dict[str, Any]:
    health_state = str(state or "COLLECTING").upper()
    runtime_state = "error" if health_state == "ERROR" else ("stopped" if health_state == "STOPPED" else "running")
    payload: Dict[str, Any] = {
        "schema": "review_worker_status_v1183",
        "version": VERSION,
        "build": BUILD_LABEL,
        "running": runtime_state == "running",
        "state": runtime_state,
        "health_state": health_state,
        "phase": extra.pop("phase", health_state.lower()),
        "updated_ts": now_ts(),
        "updated_text": now_text(),
        "pid": os.getpid(),
        "strategy_mode": STRATEGY_MODE,
        "auto_buy": False,
        "owner": "review_worker_single_candidate_standard_owner_v1215",
        "live_ledger_write": False,
    }
    payload.update(extra)
    # Guard convenience metrics; aliases only, no Review calculation or owner change.
    payload["row_count"] = integer(payload.get("candidate_rows"), payload.get("row_count"), default=0)
    payload["last_sec"] = num(payload.get("last_cycle_sec"), payload.get("last_sec"), default=0.0)
    payload["closed_recent"] = integer(payload.get("performance_count"), payload.get("closed_recent"), default=0)
    atomic_write_json(status_path(base), payload)
    return payload


def acquire_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    path = lock_path(base)
    path.parent.mkdir(parents=True, exist_ok=True)
    handle = path.open("a+", encoding="utf-8")
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError as exc:
        raise RuntimeError("review_worker v1181 already running") from exc
    acquired_ts = now_ts()
    handle.seek(0)
    handle.truncate(0)
    handle.write(__import__("json").dumps({
        "schema": "review_worker_singleton_lock_v1183",
        "pid": os.getpid(),
        "version": VERSION,
        "build": BUILD_LABEL,
        "acquired_ts": acquired_ts,
        "acquired_text": now_text(),
        "lock_path": str(path),
    }, ensure_ascii=False, separators=(",", ":")))
    handle.flush()
    os.fsync(handle.fileno())
    _LOCK_HANDLE = handle
    pid_path(base).write_text(str(os.getpid()), encoding="utf-8")


def release_singleton(base: Path) -> None:
    global _LOCK_HANDLE
    try:
        if _LOCK_HANDLE is not None:
            fcntl.flock(_LOCK_HANDLE.fileno(), fcntl.LOCK_UN)
            _LOCK_HANDLE.close()
    except OSError:
        pass
    _LOCK_HANDLE = None
    try:
        pid_path(base).unlink(missing_ok=True)
    except OSError:
        pass


def signal_handler(signum: int, _frame: Any) -> None:
    global _STOP
    _STOP = True


def _v1195_review_commit_view(snapshot: Any, standard: Any) -> Dict[str, Any]:
    """Validate and normalize one Review generation before any file commit.

    Review previously wrote the canonical snapshot first and only afterwards
    dereferenced nested fields for its event/status payload.  A malformed or
    temporarily missing nested object could therefore leave a current snapshot
    on disk while the worker status switched to ERROR.  Build every scalar used
    by the commit before writing either canonical file, and fail with an exact
    contract error instead of an ambiguous ``NoneType.get`` exception.
    """
    if not isinstance(snapshot, dict):
        raise TypeError(f"review snapshot contract expected dict, got {type(snapshot).__name__}")
    if not isinstance(standard, dict):
        raise TypeError(f"candidate standard contract expected dict, got {type(standard).__name__}")
    source = mapping(snapshot.get("source"))
    candidate = mapping(snapshot.get("candidate"))
    performance = mapping(snapshot.get("performance"))
    return {
        "pipeline_cycle_id": source.get("pipeline_cycle_id"),
        "candidate_commit_id": source.get("candidate_commit_id"),
        "source_state": source.get("state"),
        "review_snapshot_id": snapshot.get("snapshot_id"),
        "candidate_standard_state": standard.get("state"),
        "candidate_rows": candidate.get("total"),
        "performance_count": integer(performance.get("count"), default=0),
    }


def process_once(base: Path, force: bool = False) -> Dict[str, Any]:
    paths = SpinePaths(base)
    request = read_json(paths.review_request, {}) or {}
    prior = read_json(paths.review_snapshot, {}) or {}
    request_identity = (
        str(request.get("candidate_commit_id") or request.get("candidate_commit_id_v1150") or ""),
        str(request.get("pipeline_cycle_id") or request.get("candidate_pipeline_cycle_id_v1150") or ""),
    )
    prior_source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
    prior_identity = (
        str(prior_source.get("candidate_commit_id") or ""),
        str(prior_source.get("pipeline_cycle_id") or ""),
    )
    generation=_v1241_request_generation(request)
    same_generation=(request_identity == prior_identity and prior_identity != ("", ""))

    if same_generation and not force:
        try:
            if _COMMITTED_IDENTITY_V1241!=request_identity or not _COMMITTED_ROWS_V1241:
                committed_rows,integrity=_v1241_stable_committed_rows(base,request,require_pipeline=False)
                _v1241_set_committed_rows(committed_rows,integrity)
            live_rows=read_candidate_rows(paths.strategy_candidates,5000)
            version_score_review=update_version_score_review(base,_COMMITTED_ROWS_V1241,live_rows=live_rows,
                generation=generation,generation_integrity=_COMMITTED_INTEGRITY_V1241)
            return {"processed":False,"reason":"same_committed_generation_live_price_refresh_only",
                    "snapshot_id":prior.get("snapshot_id"),"candidate_rows":len(_COMMITTED_ROWS_V1241),
                    "version_score_review":version_score_review}
        except Exception as exc:
            write_status(base,"CHECK",phase="committed_generation_wait_v1241",
                current_pipeline_cycle_id=request_identity[1] or None,current_candidate_commit_id=request_identity[0] or None,
                generation_alignment_state_v1241="CHECK_WAITING_STABLE_COMMITTED_ROWS",generation_alignment_error_v1241=str(exc))
            return {"processed":False,"reason":"waiting_for_stable_committed_generation","snapshot_id":prior.get("snapshot_id"),
                    "candidate_rows":None,"version_score_review":read_json(version_score_summary_path(base),{}) or {},"check":str(exc)}

    started = time.monotonic()
    write_status(base,"RUNNING",phase="candidate_generation_stability_check_v1241",
        current_pipeline_cycle_id=request_identity[1] or None,current_candidate_commit_id=request_identity[0] or None)
    try:
        committed_rows,integrity=_v1241_stable_committed_rows(base,request,require_pipeline=True)
    except Exception as exc:
        write_status(base,"CHECK",phase="candidate_generation_stability_wait_v1241",
            current_pipeline_cycle_id=request_identity[1] or None,current_candidate_commit_id=request_identity[0] or None,
            generation_alignment_state_v1241="CHECK_WAITING_COMPLETED_GENERATION",generation_alignment_error_v1241=str(exc))
        return {"processed":False,"reason":"waiting_for_completed_generation","snapshot_id":prior.get("snapshot_id"),
                "candidate_rows":None,"version_score_review":read_json(version_score_summary_path(base),{}) or {},"check":str(exc)}

    raw_digest_before=integrity['candidate_file_sha256']
    # v1246: committed_rows were already read twice, hashed, and matched to the
    # completed request/pipeline. Build from that frozen generation even when
    # Strategy advances to the next candidate file during Review calculation.
    snapshot = build_review_snapshot(base, request=request, candidate_rows=committed_rows)
    standard = build_candidate_standard(snapshot)
    commit_view = _v1195_review_commit_view(snapshot, standard)
    if str(commit_view.get('pipeline_cycle_id') or '')!=generation['cycle_id'] or str(commit_view.get('candidate_commit_id') or '')!=generation['candidate_commit_id']:
        raise RuntimeError('v1241 built Review snapshot identity mismatch')
    if integer(commit_view.get('candidate_rows'),default=-1)!=len(committed_rows):
        raise RuntimeError('v1241 built Review snapshot row count mismatch')
    event = {
        "schema": "review_generation_event_v1242",
        "event": "REVIEW_COMMITTED_GENERATION_ALIGNED_AND_EXIT_CAPTURE_LINKED",
        "created_ts": now_ts(),"created_text": now_text(),
        "pipeline_cycle_id": commit_view["pipeline_cycle_id"],"candidate_commit_id": commit_view["candidate_commit_id"],
        "review_snapshot_id": commit_view["review_snapshot_id"],"candidate_standard_state": commit_view["candidate_standard_state"],
        "candidate_rows": commit_view["candidate_rows"],"candidate_file_sha256":raw_digest_before,
        "canonical_s1_rows":integrity.get('canonical_s1_rows'),
        "frozen_candidate_generation_v1246": True,
        "strategy_advance_during_review_allowed_v1246": True,
        "live_ledger_write": False,"auto_buy": False,
    }
    atomic_write_json(paths.review_snapshot, snapshot)
    atomic_write_json(paths.candidate_standard, standard)
    append_jsonl(base / "review_generation_events_v1181.jsonl", event)
    _v1241_set_committed_rows(committed_rows,integrity)
    version_score_review = update_version_score_review(base, committed_rows, live_rows=committed_rows,
        generation=generation,generation_integrity=integrity)
    elapsed = max(0.0, time.monotonic() - started)
    write_status(base,"NORMAL",phase="idle",last_success_ts=now_ts(),last_cycle_sec=round(elapsed,6),
        last_pipeline_cycle_id=event["pipeline_cycle_id"],last_candidate_commit_id=event["candidate_commit_id"],
        last_review_snapshot_id=event["review_snapshot_id"],candidate_standard_state=event["candidate_standard_state"],
        candidate_rows=event["candidate_rows"],performance_count=commit_view["performance_count"],source_state=commit_view["source_state"],
        snapshot_digest=digest_obj(snapshot),review_commit_contract_v1195=True,review_commit_values_normalized_before_files_v1195=True,
        version_score_review_v1257=True,generation_alignment_state_v1241="NORMAL",candidate_file_sha256_v1241=raw_digest_before,
        committed_s1_rows_v1241=integrity.get('canonical_s1_rows'),
        frozen_candidate_generation_v1246=True,
        strategy_advance_during_review_allowed_v1246=True,
        pipeline_proof_source_v1247=integrity.get('pipeline_proof_source_v1247'),
        unified_contract_rows_v1257=((version_score_review.get('unified_strategy_v1257') or {}).get('contract_rows')),
        unified_ready_rows_v1257=((version_score_review.get('unified_strategy_v1257') or {}).get('ready_rows')),
        unified_early_failure_rows_v1257=((version_score_review.get('unified_strategy_v1257') or {}).get('early_failure_rows')),
        unified_extension_rows_v1257=((version_score_review.get('unified_strategy_v1257') or {}).get('extension_rows')),
        retired_experiment_state_v1257=((version_score_review.get('retired_experiments_v1257') or {}).get('state')),
        paper_exact_exit_replay_state_v1242=((version_score_review.get('paper_exact_exit_replay_v1242') or {}).get('state')),
        paper_exact_exit_poll_records_v1242=((version_score_review.get('paper_exact_exit_replay_v1242') or {}).get('poll_records')),
        auto_buy=False)
    return {"processed":True,"snapshot":snapshot,"candidate_standard":standard,"event":event,
            "version_score_review":version_score_review,"elapsed_sec":round(elapsed,6)}




def _v1245_nonprocessed_heartbeat(result: Dict[str, Any], prior: Dict[str, Any]) -> Dict[str, Any]:
    """Keep generation-wait failures visible instead of repainting them NORMAL."""
    reason = str(result.get("reason") or "idle")
    check = str(result.get("check") or "").strip()
    waiting_reasons = {
        "waiting_for_stable_committed_generation",
        "waiting_for_completed_generation",
    }
    waiting = bool(check or reason in waiting_reasons)
    source = prior.get("source") if isinstance(prior.get("source"), dict) else {}
    candidate = prior.get("candidate") if isinstance(prior.get("candidate"), dict) else {}
    return {
        "health_state": "CHECK" if waiting else ("NORMAL" if prior else "COLLECTING"),
        "phase": reason if waiting else "idle",
        "last_review_snapshot_id": prior.get("snapshot_id"),
        "last_pipeline_cycle_id": source.get("pipeline_cycle_id"),
        "last_candidate_commit_id": source.get("candidate_commit_id"),
        "candidate_rows": result.get("candidate_rows") if result.get("candidate_rows") is not None else candidate.get("total"),
        "heartbeat": True,
        "generation_alignment_state_v1245": "CHECK_WAITING" if waiting else "NORMAL",
        "generation_alignment_error_v1245": check or None,
    }

def run_loop(base: Path, interval_sec: float) -> int:
    acquire_singleton(base)
    atexit.register(release_singleton, base)
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)
    write_status(base, "STARTING", phase="boot")
    last_heartbeat = 0.0
    consecutive_errors = 0
    while not _STOP:
        try:
            result = process_once(base)
            if not isinstance(result, dict):
                raise RuntimeError(f"review process_once contract returned {type(result).__name__}")
            consecutive_errors = 0
            current_ts = now_ts()
            if not result.get("processed") and current_ts - last_heartbeat >= HEARTBEAT_SEC:
                prior = read_json(SpinePaths(base).review_snapshot, {}) or {}
                heartbeat = _v1245_nonprocessed_heartbeat(result, prior)
                health_state = heartbeat.pop("health_state")
                write_status(base, health_state, **heartbeat)
                last_heartbeat = current_ts
        except Exception as exc:  # fail visible; no stale fallback
            consecutive_errors += 1
            log_error(base, "review_loop", exc)
            write_status(
                base,
                "ERROR",
                phase="error",
                last_error=f"{type(exc).__name__}: {exc}",
                consecutive_errors=consecutive_errors,
            )
        slept = 0.0
        while slept < interval_sec and not _STOP:
            step = min(0.2, interval_sec - slept)
            time.sleep(step)
            slept += step
    write_status(base, "STOPPED", phase="shutdown")
    return 0

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-dir", default="")
    parser.add_argument("--interval", type=float, default=DEFAULT_INTERVAL_SEC)
    parser.add_argument("--once", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    base = Path(args.base_dir).expanduser().resolve() if args.base_dir else base_dir()
    if args.once:
        result = process_once(base, force=args.force)
        print(result.get("candidate_standard") or result)
        return 0
    return run_loop(base, max(0.5, args.interval))



# v1257: retire competing strategy experiment writers. Historical state files
# and ledgers are preserved untouched; this canonical summary now describes one
# active unified strategy and exact ledger continuity only.
def update_version_score_review(base: Path, rows: list[Dict[str, Any]], live_rows: Optional[list[Dict[str,Any]]] = None,
                                generation: Optional[Dict[str,Any]] = None, generation_integrity: Optional[Dict[str,Any]] = None) -> Dict[str, Any]:
    nowv=now_ts()
    candidate_rows=list(rows or [])
    gen=dict(generation or _v1239_generation_context(base))
    contracts=[]
    for row in candidate_rows:
        if not isinstance(row,dict):
            continue
        contract=row.get('unified_strategy_contract_v1257')
        if isinstance(contract,dict) and contract.get('schema')=='unified_alt_swing_contract_v1257':
            contracts.append(contract)
    summary={
        'schema':'canonical_version_score_review_v1257','version':VERSION,'build':BUILD_LABEL,
        'updated_ts':nowv,'updated_text':now_text(nowv),'mode':'UNIFIED_STRATEGY_ONLY',
        'current_generation':{
            'pipeline_cycle_id':gen.get('cycle_id'),'candidate_commit_id':gen.get('candidate_commit_id'),
            'candidate_rows':len(candidate_rows),'integrity':dict(generation_integrity or {}),
        },
        'unified_strategy_v1257':{
            'state':'NORMAL' if contracts else 'COLLECTING','contract_rows':len(contracts),
            'ready_rows':sum(1 for x in contracts if x.get('ready') is True),
            'early_failure_rows':sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('early_failure_invalid_price'))),
            'extension_rows':sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('extension_target_price'))),
            'quality_confirmed_rows':sum(1 for x in contracts if ((x.get('entry_quality_support') or {}).get('confirmed') is True)),
            'entry_owner':'strategy_worker.apply_swing_entry_gate_v1257',
            'exit_owner':'paper_bot._exit_decision_spine_v1257 for new sealed OPEN only',
            'existing_open_unchanged':True,'auto_buy':False,
        },
        'paper_exact_exit_replay_v1242':_v1242_paper_exact_replay_status(base),
        'retired_experiments_v1257':{
            'state':'RETIRED_FROM_ACTIVE_DECISION_AND_PUBLIC_SCORE',
            'items':['v1234_hybrid_surgery','v1236_probability_policy','v1237_pair_matchup','v1251_policy_competition','v1253_structure_rebuild_audit'],
            'historical_files_deleted':False,'historical_ledgers_rewritten':False,
            'new_state_writes':False,'trade_decision_use':False,
        },
        'invariants':{
            'review_changes_candidates':False,'review_changes_open_closed':False,'canonical_performance_owner':'paper_bot',
            'historical_state_preserved':True,'auto_buy':False,
        },
    }
    atomic_write_json(version_score_summary_path(base),summary)
    return summary


# -----------------------------------------------------------------------------
# v1261 - fresh current-strategy missed-candidate review owner
#
# New active state starts at zero in a new file.  Older review/shadow files stay
# on disk for audit but are never read by the active public score.  Candidate
# identity is exact-key only; ticker/time proximity is forbidden.
# -----------------------------------------------------------------------------
V1261_MISSED_STATE_SCHEMA = 'current_strategy_missed_state_v1261'
V1261_MISSED_SUMMARY_SCHEMA = 'canonical_version_score_review_v1261'
V1261_RETENTION_SEC = 24.0 * 3600.0
V1261_HORIZONS = (
    ('return_30m_pct', 30.0 * 60.0),
    ('return_1h_pct', 3600.0),
    ('return_3h_pct', 3.0 * 3600.0),
    ('return_6h_pct', 6.0 * 3600.0),
)


def version_score_state_path(base: Path) -> Path:  # type: ignore[override]
    return base / 'version_score_current_missed_state_v1261.json'


def version_score_summary_path(base: Path) -> Path:  # type: ignore[override]
    return base / 'canonical_version_score_review_v1261.json'


def _v1261_candidate_key(row: Dict[str, Any]) -> str:
    for key in (
        'trigger_occurrence_candidate_key_v1037', 'trigger_occurrence_candidate_key',
        'candidate_exact_identity', 'event_key', 'event_id',
        'swing_gate_decision_key_v977',
    ):
        value = str(row.get(key) or '').strip()
        if value:
            return value
    gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
    value = str(gate.get('decision_key') or '').strip()
    return value


def _v1261_contract(row: Dict[str, Any]) -> Dict[str, Any]:
    value = row.get('unified_strategy_contract_v1257')
    return value if isinstance(value, dict) and value.get('schema') == 'unified_alt_swing_contract_v1257' else {}


def _v1261_ready(row: Dict[str, Any]) -> bool:
    contract = _v1261_contract(row)
    return bool(contract.get('ready') is True)


def _v1261_reason_texts(row: Dict[str, Any]) -> list[str]:
    out: list[str] = []
    for key in (
        'paper_entry_hold_reasons','paper_final_block_reasons','final_entry_reasons','final_trade_reasons',
        'hold_reasons','block_reasons','s1_missing_conditions','s1_missing_names','s_stage_reasons',
        'source_missing_frames_v1001','extreme_quality_risk_tags_v925',
    ):
        value = row.get(key)
        if isinstance(value, list):
            out.extend(str(x) for x in value if str(x).strip())
        elif value not in (None, ''):
            out.append(str(value))
    gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
    for key in ('display_reasons','hard_reasons','reasons','missing_conditions'):
        value = gate.get(key)
        if isinstance(value, list):
            out.extend(str(x) for x in value if str(x).strip())
    contract = _v1261_contract(row)
    quality = contract.get('entry_quality_support') if isinstance(contract.get('entry_quality_support'), dict) else {}
    if quality.get('reason') not in (None, '', 'CONFIRMED'):
        out.append(str(quality.get('reason')))
    return list(dict.fromkeys(out))[:20]


def _v1261_reason_category(row: Dict[str, Any], reasons: list[str]) -> str:
    blob = ' '.join(reasons).lower()
    contract = _v1261_contract(row)
    primary = contract.get('primary_entry_structure') if isinstance(contract.get('primary_entry_structure'), dict) else {}
    if not primary or not all(primary.get(k) not in (None, '', 0, 0.0) for k in ('trigger_price','invalid_price','base_target_price')):
        return 'structure_source_missing'
    if 'source_missing' in blob or '자료' in blob and '누락' in blob:
        return 'structure_source_missing'
    if 'frozen_trigger_not_reached' in blob or 'trigger' in blob and ('not_reached' in blob or '미도달' in blob or '대기' in blob):
        return 'trigger_not_reached'
    if 'risk_reward' in blob or 'rr' in blob and ('below' in blob or '부족' in blob):
        return 'risk_reward_below'
    if 'target_room' in blob or ('목표' in blob and '공간' in blob):
        return 'target_room_below'
    if any(token in blob for token in ('spread','slippage','execution','비용','스프레드','미끄러')):
        return 'execution_cost'
    if any(token in blob for token in ('chase','overshoot','추격')):
        return 'trigger_chase'
    if bool(row.get('observation_only') or row.get('observation_only_v988') or row.get('s3_observation_only_v988')):
        return 'observation_only'
    stage = str(row.get('s_stage') or row.get('candidate_stage') or row.get('stage') or '').upper()
    if stage == 'S3':
        return 'observation_only'
    return 'other_current_exclusion'


def _v1261_line_values(row: Dict[str, Any]) -> Dict[str, Any]:
    contract = _v1261_contract(row)
    primary = contract.get('primary_entry_structure') if isinstance(contract.get('primary_entry_structure'), dict) else {}
    support = contract.get('v1211_structural_support') if isinstance(contract.get('v1211_structural_support'), dict) else {}
    shadow = row.get('v1211_structure_shadow_v1222') if isinstance(row.get('v1211_structure_shadow_v1222'), dict) else {}
    v1211_trigger = _v1233_line_price(shadow.get('trigger'))
    v1211_invalid = _v1233_line_price(shadow.get('invalid'))
    v1211_target = _v1233_line_price(shadow.get('target'))
    price = _v1233_price(row)
    v1211_ready = bool(
        shadow.get('source_exact') is True and shadow.get('complete') is True
        and 0 < v1211_invalid < v1211_trigger < v1211_target
        and price >= v1211_trigger and price < v1211_target and price > v1211_invalid
    )
    return {
        'trigger_price': _v1233_float(primary.get('trigger_price'), row.get('swing_trigger_price_v977'), row.get('trigger_price'), default=0.0),
        'invalid_price': _v1233_float(primary.get('invalid_price'), row.get('swing_invalid_price_v977'), row.get('invalid_price'), default=0.0),
        'target_price': _v1233_float(primary.get('base_target_price'), row.get('swing_target_price_v977'), row.get('target_price'), default=0.0),
        'early_failure_price': _v1233_float(support.get('early_failure_invalid_price'), default=0.0),
        'extension_target_price': _v1233_float(support.get('extension_target_price'), default=0.0),
        'v1211_source_exact': bool(shadow.get('source_exact') is True and shadow.get('complete') is True),
        'v1211_trigger_price': v1211_trigger,
        'v1211_invalid_price': v1211_invalid,
        'v1211_target_price': v1211_target,
        'v1211_would_be_ready_at_exclusion': v1211_ready,
    }


def _v1261_new_state(nowv: float) -> Dict[str, Any]:
    return {
        'schema': V1261_MISSED_STATE_SCHEMA,
        'started_ts': nowv, 'started_text': now_text(nowv),
        'updated_ts': nowv, 'updated_text': now_text(nowv),
        'events': {}, 'exact_key_missing_skipped': 0,
        'old_state_imported': False, 'auto_buy': False,
    }


def _v1261_update_event_path(event: Dict[str, Any], price: float, nowv: float) -> None:
    start = _v1233_float(event.get('start_price'), default=0.0)
    if start <= 0 or price <= 0:
        return
    event['current_price'] = price
    event['high_price'] = max(_v1233_float(event.get('high_price'), default=price), price)
    event['low_price'] = min(_v1233_float(event.get('low_price'), default=price), price)
    event['last_seen_ts'] = nowv
    event['age_sec'] = max(0.0, nowv - _v1233_float(event.get('created_ts'), default=nowv))
    event['current_return_pct'] = _v1233_return_pct(price, start)
    event['max_gain_pct'] = _v1233_return_pct(_v1233_float(event.get('high_price'), default=price), start)
    event['max_drawdown_pct'] = _v1233_return_pct(_v1233_float(event.get('low_price'), default=price), start)
    for field, sec in V1261_HORIZONS:
        if event['age_sec'] >= sec and event.get(field) is None:
            event[field] = event.get('current_return_pct')
            event[field.replace('_pct', '_ts')] = nowv
    target = _v1233_float(event.get('target_price'), default=0.0)
    invalid = _v1233_float(event.get('invalid_price'), default=0.0)
    if target > 0 and price >= target and event.get('target_first_touch_ts') is None:
        event['target_first_touch_ts'] = nowv
    if invalid > 0 and price <= invalid and event.get('invalid_first_touch_ts') is None:
        event['invalid_first_touch_ts'] = nowv
    tts = _v1233_float(event.get('target_first_touch_ts'), default=0.0)
    its = _v1233_float(event.get('invalid_first_touch_ts'), default=0.0)
    if tts and its:
        event['first_touch'] = 'TARGET' if tts < its else 'INVALID' if its < tts else 'SAME_SAMPLE'
    elif tts:
        event['first_touch'] = 'TARGET'
    elif its:
        event['first_touch'] = 'INVALID'
    else:
        event['first_touch'] = 'NONE'


def _v1261_update_missed_state(state: Dict[str, Any], rows: list[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    events = state.setdefault('events', {})
    cutoff = nowv - V1261_RETENTION_SEC
    for key in list(events):
        event = events.get(key) if isinstance(events.get(key), dict) else {}
        if _v1233_float(event.get('created_ts'), default=0.0) < cutoff:
            events.pop(key, None)
    prices = {_v1233_ticker(r): _v1233_price(r) for r in rows if isinstance(r, dict) and _v1233_ticker(r) and _v1233_price(r) > 0}
    missing_key_rows = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        exact_key = _v1261_candidate_key(row)
        if not exact_key:
            missing_key_rows += 1
            continue
        ticker = _v1233_ticker(row)
        if not ticker:
            continue
        identity = hashlib.sha256(f'{ticker}|{exact_key}'.encode('utf-8', errors='ignore')).hexdigest()[:32]
        if _v1261_ready(row):
            if isinstance(events.get(identity), dict) and events[identity].get('recovered_to_ready_ts') is None:
                events[identity]['recovered_to_ready_ts'] = nowv
                events[identity]['recovered_to_ready'] = True
            continue
        price = _v1233_price(row)
        if price <= 0:
            continue
        reasons = _v1261_reason_texts(row)
        category = _v1261_reason_category(row, reasons)
        if not isinstance(events.get(identity), dict):
            lines = _v1261_line_values(row)
            events[identity] = {
                'event_id': identity, 'exact_candidate_key': exact_key,
                'candidate_decision_key': str(row.get('swing_gate_decision_key_v977') or '').strip() or None,
                'ticker': ticker, 'reason_category': category, 'reasons': reasons,
                'created_ts': nowv, 'created_text': now_text(nowv),
                'start_price': price, 'current_price': price, 'high_price': price, 'low_price': price,
                'candidate_cycle_id_first': row.get('candidate_pipeline_cycle_id_v1150'),
                'candidate_commit_id_first': str(row.get('candidate_commit_id') or '').strip() or None,
                'recovered_to_ready': False,
                **lines,
            }
        event = events[identity]
        event['candidate_cycle_id_last'] = row.get('candidate_pipeline_cycle_id_v1150')
        event['last_reason_category'] = category
        event['last_reasons'] = reasons
    for identity, event in list(events.items()):
        if not isinstance(event, dict):
            continue
        ticker = str(event.get('ticker') or '')
        price = prices.get(ticker, 0.0)
        if price > 0:
            _v1261_update_event_path(event, price, nowv)
    state['exact_key_missing_skipped'] = missing_key_rows
    state['updated_ts'] = nowv
    state['updated_text'] = now_text(nowv)
    state['events'] = events
    return state


def _v1261_missed_summary(state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    events = [e for e in (state.get('events') or {}).values() if isinstance(e, dict)]
    missed = [e for e in events if e.get('recovered_to_ready') is not True]
    completed = [e for e in missed if e.get('return_6h_pct') is not None]
    reason_counts: Dict[str, int] = {}
    first_touch_counts: Dict[str, int] = {}
    for event in missed:
        reason = str(event.get('reason_category') or 'other_current_exclusion')
        reason_counts[reason] = reason_counts.get(reason, 0) + 1
        touch = str(event.get('first_touch') or 'NONE')
        first_touch_counts[touch] = first_touch_counts.get(touch, 0) + 1
    top = sorted(missed, key=lambda e: _v1233_float(e.get('max_gain_pct'), default=-9999.0), reverse=True)[:10]
    return {
        'schema': 'current_strategy_missed_summary_v1261',
        'state': 'NORMAL' if events else 'COLLECTING',
        'started_ts': state.get('started_ts'), 'started_text': state.get('started_text'),
        'tracked_total': len(events), 'active_missed': len(missed),
        'recovered_to_ready': sum(1 for e in events if e.get('recovered_to_ready') is True),
        'completed_6h': len(completed),
        'positive_max_count': sum(1 for e in missed if _v1233_float(e.get('max_gain_pct'), default=0.0) > 0),
        'gain_1_2_count': sum(1 for e in missed if _v1233_float(e.get('max_gain_pct'), default=0.0) >= 1.2),
        'gain_3_count': sum(1 for e in missed if _v1233_float(e.get('max_gain_pct'), default=0.0) >= 3.0),
        'v1211_would_be_ready_count': sum(1 for e in missed if e.get('v1211_would_be_ready_at_exclusion') is True),
        'reason_counts': reason_counts, 'first_touch_counts': first_touch_counts,
        'exact_key_missing_skipped': int(state.get('exact_key_missing_skipped') or 0),
        'top': top,
        'policy': 'v1261 start only; exact candidate key; 30m/1h/3h/6h path; 24h retention; no virtual PnL added to actual performance',
    }


_V1261_PREV_UPDATE_VERSION_SCORE_REVIEW = update_version_score_review

def update_version_score_review(base: Path, rows: list[Dict[str, Any]], live_rows: Optional[list[Dict[str,Any]]] = None,
                                generation: Optional[Dict[str,Any]] = None, generation_integrity: Optional[Dict[str,Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    nowv = now_ts()
    candidate_rows = [r for r in (rows or []) if isinstance(r, dict)]
    gen = dict(generation or _v1239_generation_context(base))
    state = read_json(version_score_state_path(base), {}) or {}
    if not isinstance(state, dict) or state.get('schema') != V1261_MISSED_STATE_SCHEMA:
        state = _v1261_new_state(nowv)
    state = _v1261_update_missed_state(state, candidate_rows, nowv)
    atomic_write_json(version_score_state_path(base), state)
    contracts = []
    for row in candidate_rows:
        contract = _v1261_contract(row)
        if contract:
            contracts.append(contract)
    summary = {
        'schema': V1261_MISSED_SUMMARY_SCHEMA, 'version': VERSION, 'build': BUILD_LABEL,
        'updated_ts': nowv, 'updated_text': now_text(nowv),
        'mode': 'CURRENT_VS_V1211_ACTUAL_WITH_FRESH_MISSED_ONLY',
        'current_generation': {
            'pipeline_cycle_id': gen.get('cycle_id'), 'candidate_commit_id': gen.get('candidate_commit_id'),
            'candidate_rows': len(candidate_rows), 'integrity': dict(generation_integrity or {}),
        },
        'unified_strategy_v1257': {
            'state': 'NORMAL' if contracts else 'COLLECTING', 'contract_rows': len(contracts),
            'ready_rows': sum(1 for x in contracts if x.get('ready') is True),
            'early_failure_rows': sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('early_failure_invalid_price'))),
            'extension_rows': sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('extension_target_price'))),
            'quality_confirmed_rows': sum(1 for x in contracts if ((x.get('entry_quality_support') or {}).get('confirmed') is True)),
            'entry_owner': 'strategy_worker.apply_swing_entry_gate_v1257',
            'exit_owner': 'paper_bot._exit_decision_spine_v1257 for new sealed OPEN only',
            'existing_open_unchanged': True, 'auto_buy': False,
        },
        'current_missed_v1261': _v1261_missed_summary(state, nowv),
        'retired_experiments_v1257': {
            'state': 'RETIRED_FROM_ACTIVE_DECISION_AND_PUBLIC_SCORE',
            'items': ['transition cohort','old missed accumulation','previous structure virtual shadow','policy competition','hybrid shadow','pair matchup'],
            'historical_files_deleted': False, 'historical_ledgers_rewritten': False,
            'new_state_writes': False, 'trade_decision_use': False,
        },
        'paper_exact_exit_replay_v1242': _v1242_paper_exact_replay_status(base),
        'invariants': {
            'review_changes_candidates': False, 'review_changes_open_closed': False,
            'canonical_performance_owner': 'paper_bot', 'old_review_state_imported': False,
            'exact_candidate_key_only': True, 'ticker_time_proximity_link_forbidden': True,
            'historical_state_preserved': True, 'auto_buy': False,
        },
    }
    atomic_write_json(version_score_summary_path(base), summary)
    return summary

V1261_REVIEW_CONTRACT = {
    'schema': 'current_missed_review_contract_v1261',
    'state_file': 'version_score_current_missed_state_v1261.json',
    'old_state_imported': False,
    'exact_candidate_key_only': True,
    'horizons': ['30m','1h','3h','6h'],
    'retention_hours': 24,
    'trading_rules_changed': False,
    'auto_buy': False,
}


# -----------------------------------------------------------------------------
# v1262 - missed-candidate semantic occurrence owner
#
# Strategy execution keys remain exact and cycle-scoped.  Review requires that
# exact key as evidence, but groups repeated observations by scanner occurrence
# plus sealed trigger/invalid/target lines.  No ticker/time-proximity joining is
# used.  The v1261 state file is read once for migration and never rewritten.
# -----------------------------------------------------------------------------
V1262_MISSED_STATE_SCHEMA = 'current_strategy_missed_state_v1262'
V1262_MISSED_SUMMARY_SCHEMA = 'canonical_version_score_review_v1262'
V1262_STATE_FILE = 'version_score_current_missed_state_v1262.json'
V1262_SUMMARY_FILE = 'canonical_version_score_review_v1262.json'
V1262_OLD_STATE_FILE = 'version_score_current_missed_state_v1261.json'


def version_score_state_path(base: Path) -> Path:  # type: ignore[override]
    return base / V1262_STATE_FILE


def version_score_summary_path(base: Path) -> Path:  # type: ignore[override]
    return base / V1262_SUMMARY_FILE


def _v1262_sig_price(value: Any) -> str:
    number = _v1233_float(value, default=0.0)
    return f'{number:.12g}' if number > 0 else '0'


def _v1262_semantic_identity_values(
    ticker: str, scanner_occurrence: str, lines: Dict[str, Any], reason_category: str
) -> tuple[str, str]:
    line_sig = '|'.join((
        _v1262_sig_price(lines.get('trigger_price')),
        _v1262_sig_price(lines.get('invalid_price')),
        _v1262_sig_price(lines.get('target_price')),
        _v1262_sig_price(lines.get('early_failure_price')),
        _v1262_sig_price(lines.get('extension_target_price')),
    ))
    has_structure = any(part != '0' for part in line_sig.split('|')[:3])
    if has_structure:
        stable = f'scanner:{scanner_occurrence or "NONE"}|lines:{line_sig}'
    else:
        stable = f'scanner:{scanner_occurrence or "NONE"}|no_structure|reason:{reason_category}'
    digest = hashlib.sha256(f'{ticker}|{stable}'.encode('utf-8', errors='ignore')).hexdigest()[:32]
    return digest, stable


def _v1262_scanner_occurrence(row: Dict[str, Any]) -> str:
    for key in ('scanner_occurrence_key_v1203', 'hot_watch_occurrence_key', 'scanner_occurrence_key'):
        value = str(row.get(key) or '').strip()
        if value:
            return value
    return ''


def _v1262_semantic_identity(row: Dict[str, Any], ticker: str, reason_category: str) -> tuple[str, str, Dict[str, Any]]:
    lines = _v1261_line_values(row)
    identity, stable = _v1262_semantic_identity_values(
        ticker, _v1262_scanner_occurrence(row), lines, reason_category
    )
    return identity, stable, lines


def _v1262_new_state(nowv: float) -> Dict[str, Any]:
    return {
        'schema': V1262_MISSED_STATE_SCHEMA,
        'started_ts': nowv, 'started_text': now_text(nowv),
        'updated_ts': nowv, 'updated_text': now_text(nowv),
        'events': {}, 'exact_key_missing_skipped': 0,
        'migrated_from_v1261': False, 'migration_source_events': 0,
        'migration_semantic_events': 0, 'auto_buy': False,
    }


def _v1262_merge_event(dst: Dict[str, Any], src: Dict[str, Any]) -> Dict[str, Any]:
    if not dst:
        out = dict(src)
        exact = str(out.get('exact_candidate_key') or '').strip()
        out['exact_candidate_keys'] = list(out.get('exact_candidate_keys') or ([exact] if exact else []))
        out['observation_count'] = max(1, int(out.get('observation_count') or 1))
        return out
    created_candidates = [
        _v1233_float(dst.get('created_ts'), default=0.0),
        _v1233_float(src.get('created_ts'), default=0.0),
    ]
    created_candidates = [x for x in created_candidates if x > 0]
    if created_candidates:
        dst['created_ts'] = min(created_candidates)
        dst['created_text'] = now_text(dst['created_ts'])
    if _v1233_float(dst.get('start_price'), default=0.0) <= 0 and _v1233_float(src.get('start_price'), default=0.0) > 0:
        dst['start_price'] = src.get('start_price')
    highs = [_v1233_float(dst.get('high_price'), default=0.0), _v1233_float(src.get('high_price'), default=0.0)]
    highs = [x for x in highs if x > 0]
    if highs:
        dst['high_price'] = max(highs)
    lows = [_v1233_float(dst.get('low_price'), default=0.0), _v1233_float(src.get('low_price'), default=0.0)]
    lows = [x for x in lows if x > 0]
    if lows:
        dst['low_price'] = min(lows)
    for field in ('return_30m_pct','return_1h_pct','return_3h_pct','return_6h_pct'):
        if dst.get(field) is None and src.get(field) is not None:
            dst[field] = src.get(field)
            dst[field.replace('_pct','_ts')] = src.get(field.replace('_pct','_ts'))
    for field in ('target_first_touch_ts','invalid_first_touch_ts','recovered_to_ready_ts'):
        values = [_v1233_float(dst.get(field), default=0.0), _v1233_float(src.get(field), default=0.0)]
        values = [x for x in values if x > 0]
        if values:
            dst[field] = min(values)
    dst['recovered_to_ready'] = bool(dst.get('recovered_to_ready') is True or src.get('recovered_to_ready') is True)
    exact_keys = list(dst.get('exact_candidate_keys') or [])
    for value in [dst.get('exact_candidate_key'), src.get('exact_candidate_key')] + list(src.get('exact_candidate_keys') or []):
        value = str(value or '').strip()
        if value and value not in exact_keys:
            exact_keys.append(value)
    dst['exact_candidate_keys'] = exact_keys[-64:]
    dst['observation_count'] = int(dst.get('observation_count') or 0) + max(1, int(src.get('observation_count') or 1))
    return dst


def _v1262_migrate_v1261_state(base: Path, nowv: float) -> Dict[str, Any]:
    state = _v1262_new_state(nowv)
    old = read_json(base / V1262_OLD_STATE_FILE, {}) or {}
    old_events = old.get('events') if isinstance(old, dict) and isinstance(old.get('events'), dict) else {}
    state['migrated_from_v1261'] = bool(old_events)
    state['migration_source_events'] = len(old_events)
    for old_event in old_events.values():
        if not isinstance(old_event, dict):
            continue
        ticker = str(old_event.get('ticker') or '').strip().upper()
        if not ticker:
            continue
        category = str(old_event.get('reason_category') or 'other_current_exclusion')
        lines = {key: old_event.get(key) for key in (
            'trigger_price','invalid_price','target_price','early_failure_price','extension_target_price',
            'v1211_source_exact','v1211_trigger_price','v1211_invalid_price','v1211_target_price',
            'v1211_would_be_ready_at_exclusion',
        )}
        identity, stable = _v1262_semantic_identity_values(
            ticker, str(old_event.get('scanner_occurrence_key') or ''), lines, category
        )
        migrated = dict(old_event)
        migrated['event_id'] = identity
        migrated['semantic_occurrence_key'] = stable
        migrated['semantic_key_schema'] = 'scanner_occurrence_plus_sealed_lines_v1262'
        migrated['migrated_from_v1261'] = True
        migrated['exact_candidate_keys'] = [str(old_event.get('exact_candidate_key') or '').strip()] if str(old_event.get('exact_candidate_key') or '').strip() else []
        existing = state['events'].get(identity) if isinstance(state['events'].get(identity), dict) else {}
        state['events'][identity] = _v1262_merge_event(existing, migrated)
    state['migration_semantic_events'] = len(state['events'])
    state['started_ts'] = _v1233_float(old.get('started_ts'), default=nowv) if isinstance(old, dict) else nowv
    state['started_text'] = now_text(state['started_ts'])
    return state


def _v1262_update_missed_state(state: Dict[str, Any], rows: list[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    events = state.setdefault('events', {})
    cutoff = nowv - V1261_RETENTION_SEC
    for key in list(events):
        event = events.get(key) if isinstance(events.get(key), dict) else {}
        if _v1233_float(event.get('created_ts'), default=0.0) < cutoff:
            events.pop(key, None)
    prices = {_v1233_ticker(r): _v1233_price(r) for r in rows if isinstance(r, dict) and _v1233_ticker(r) and _v1233_price(r) > 0}
    missing_key_rows = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        exact_key = _v1261_candidate_key(row)
        if not exact_key:
            missing_key_rows += 1
            continue
        ticker = _v1233_ticker(row)
        if not ticker:
            continue
        reasons = _v1261_reason_texts(row)
        category = _v1261_reason_category(row, reasons)
        identity, stable, lines = _v1262_semantic_identity(row, ticker, category)
        if _v1261_ready(row):
            if isinstance(events.get(identity), dict) and events[identity].get('recovered_to_ready_ts') is None:
                events[identity]['recovered_to_ready_ts'] = nowv
                events[identity]['recovered_to_ready'] = True
            continue
        price = _v1233_price(row)
        if price <= 0:
            continue
        if not isinstance(events.get(identity), dict):
            events[identity] = {
                'event_id': identity,
                'semantic_occurrence_key': stable,
                'semantic_key_schema': 'scanner_occurrence_plus_sealed_lines_v1262',
                'exact_candidate_key': exact_key,
                'exact_candidate_keys': [exact_key],
                'observation_count': 0,
                'candidate_decision_key': str(row.get('swing_gate_decision_key_v977') or '').strip() or None,
                'ticker': ticker, 'reason_category': category, 'reasons': reasons,
                'created_ts': nowv, 'created_text': now_text(nowv),
                'start_price': price, 'current_price': price, 'high_price': price, 'low_price': price,
                'scanner_occurrence_key': _v1262_scanner_occurrence(row) or None,
                'candidate_cycle_id_first': row.get('candidate_pipeline_cycle_id_v1150'),
                'candidate_commit_id_first': str(row.get('candidate_commit_id') or '').strip() or None,
                'recovered_to_ready': False,
                **lines,
            }
        event = events[identity]
        exact_keys = list(event.get('exact_candidate_keys') or [])
        if exact_key not in exact_keys:
            exact_keys.append(exact_key)
        event['exact_candidate_keys'] = exact_keys[-64:]
        event['observation_count'] = int(event.get('observation_count') or 0) + 1
        event['candidate_cycle_id_last'] = row.get('candidate_pipeline_cycle_id_v1150')
        event['candidate_commit_id_last'] = str(row.get('candidate_commit_id') or '').strip() or None
        event['last_reason_category'] = category
        event['last_reasons'] = reasons
    for event in list(events.values()):
        if not isinstance(event, dict):
            continue
        price = prices.get(str(event.get('ticker') or ''), 0.0)
        if price > 0:
            _v1261_update_event_path(event, price, nowv)
    state['exact_key_missing_skipped'] = missing_key_rows
    state['updated_ts'] = nowv
    state['updated_text'] = now_text(nowv)
    state['events'] = events
    return state


def _v1262_missed_summary(state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out = _v1261_missed_summary(state, nowv)
    out['schema'] = 'current_strategy_missed_summary_v1262'
    out['semantic_occurrence_total'] = int(out.get('tracked_total') or 0)
    out['source_observation_total'] = sum(int(e.get('observation_count') or 0) for e in (state.get('events') or {}).values() if isinstance(e, dict))
    out['migration_source_events'] = int(state.get('migration_source_events') or 0)
    out['migration_semantic_events'] = int(state.get('migration_semantic_events') or 0)
    out['migrated_from_v1261'] = bool(state.get('migrated_from_v1261'))
    out['policy'] = 'exact key required as evidence; semantic owner = scanner occurrence + sealed lines; no ticker/time proximity; 24h retention; no actual PnL'
    return out


_V1262_PREV_UPDATE_VERSION_SCORE_REVIEW = update_version_score_review


def update_version_score_review(base: Path, rows: list[Dict[str, Any]], live_rows: Optional[list[Dict[str,Any]]] = None,
                                generation: Optional[Dict[str,Any]] = None, generation_integrity: Optional[Dict[str,Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    nowv = now_ts()
    candidate_rows = [r for r in (rows or []) if isinstance(r, dict)]
    gen = dict(generation or _v1239_generation_context(base))
    state = read_json(version_score_state_path(base), {}) or {}
    if not isinstance(state, dict) or state.get('schema') != V1262_MISSED_STATE_SCHEMA:
        state = _v1262_migrate_v1261_state(base, nowv)
    state = _v1262_update_missed_state(state, candidate_rows, nowv)
    atomic_write_json(version_score_state_path(base), state)
    contracts = [_v1261_contract(row) for row in candidate_rows if _v1261_contract(row)]
    missed = _v1262_missed_summary(state, nowv)
    summary = {
        'schema': V1262_MISSED_SUMMARY_SCHEMA, 'version': VERSION, 'build': BUILD_LABEL,
        'updated_ts': nowv, 'updated_text': now_text(nowv),
        'mode': 'CURRENT_SCORE_TRUTH_AND_SEMANTIC_MISSED_V1262',
        'current_generation': {
            'pipeline_cycle_id': gen.get('cycle_id'), 'candidate_commit_id': gen.get('candidate_commit_id'),
            'candidate_rows': len(candidate_rows), 'integrity': dict(generation_integrity or {}),
        },
        'unified_strategy_v1257': {
            'state': 'NORMAL' if contracts else 'COLLECTING', 'contract_rows': len(contracts),
            'ready_rows': sum(1 for x in contracts if x.get('ready') is True),
            'early_failure_rows': sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('early_failure_invalid_price'))),
            'extension_rows': sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('extension_target_price'))),
            'quality_confirmed_rows': sum(1 for x in contracts if ((x.get('entry_quality_support') or {}).get('confirmed') is True)),
            'entry_owner': 'strategy_worker.apply_swing_entry_gate_v1257',
            'exit_owner': 'paper_bot._exit_decision_spine_v1257 for new sealed OPEN only',
            'existing_open_unchanged': True, 'auto_buy': False,
        },
        'current_missed_v1262': missed,
        # Corrected compatibility alias for a partially updated Main.
        'current_missed_v1261': missed,
        'retired_experiments_v1257': {
            'state': 'RETIRED_FROM_ACTIVE_DECISION_AND_PUBLIC_SCORE',
            'items': ['transition cohort','old missed accumulation','previous structure virtual shadow','policy competition','hybrid shadow','pair matchup'],
            'historical_files_deleted': False, 'historical_ledgers_rewritten': False,
            'new_state_writes': False, 'trade_decision_use': False,
        },
        'paper_exact_exit_replay_v1242': _v1242_paper_exact_replay_status(base),
        'invariants': {
            'review_changes_candidates': False, 'review_changes_open_closed': False,
            'canonical_performance_owner': 'paper_bot', 'old_v1261_state_rewritten': False,
            'exact_candidate_key_required': True, 'exact_candidate_key_is_event_owner': False,
            'semantic_occurrence_owner': 'scanner occurrence plus sealed structure lines',
            'ticker_time_proximity_link_forbidden': True,
            'historical_state_preserved': True, 'auto_buy': False,
        },
    }
    atomic_write_json(version_score_summary_path(base), summary)
    # Keep only a corrected read-compatible summary alias; the old state file is
    # not modified.
    atomic_write_json(base / 'canonical_version_score_review_v1261.json', summary)
    return summary


V1262_REVIEW_CONTRACT = {
    'schema': 'current_missed_review_contract_v1262',
    'state_file': V1262_STATE_FILE,
    'old_state_file_rewritten': False,
    'exact_candidate_key_required': True,
    'event_owner': 'semantic scanner occurrence plus sealed lines',
    'ticker_time_proximity_link': False,
    'horizons': ['30m','1h','3h','6h'],
    'retention_hours': 24,
    'candidate_formula_changed': False,
    'trigger_invalid_target_rr_changed': False,
    'entry_exit_changed': False,
    'auto_buy': False,
}


# -----------------------------------------------------------------------------
# v1263 - fresh stable missed-occurrence state + bounded persistence
#
# v1262 proved that exact cycle keys and exact floating structure prices churned
# too often for a useful missed-opportunity ledger.  v1263 deliberately starts a
# fresh non-trading review state.  One event is owned by the scanner occurrence
# plus the frozen structure plan identity.  Exact candidate keys remain audit
# evidence only.  Retired v1261/v1262 state is never imported or rewritten.
# -----------------------------------------------------------------------------
V1263_MISSED_STATE_SCHEMA = 'current_strategy_missed_state_v1312'
V1263_STATE_FILE = 'version_score_current_missed_state_v1312.json'
V1263_STATE_WRITE_INTERVAL_SEC = 300.0
V1263_MAX_EVENTS = 1200
V1263_MAX_EVENTS_HARD = 1500
V1263_MAX_EXACT_KEYS_PER_EVENT = 4
_V1263_STATE_CACHE: Dict[str, Any] = {}
_V1263_STATE_CACHE_BASE = ''
_V1263_LAST_STATE_WRITE_TS = 0.0
_V1263_LAST_PERSISTED_DIGEST = ''


def version_score_state_path(base: Path) -> Path:  # type: ignore[override]
    return base / V1263_STATE_FILE


def _v1263_nested(row: Dict[str, Any], *path: str) -> Any:
    cur: Any = row
    for key in path:
        if not isinstance(cur, dict):
            return None
        cur = cur.get(key)
    return cur


def _v1263_plan_identity(row: Dict[str, Any]) -> str:
    contract = _v1261_contract(row)
    primary = contract.get('primary_entry_structure') if isinstance(contract.get('primary_entry_structure'), dict) else {}
    for value in (
        primary.get('structure_contract_hash'),
        _v1263_nested(row, 'swing_structure_plan_v977', 'plan_key'),
        _v1263_nested(row, 'swing_structure_plan_v977', 'plan_id'),
        _v1263_nested(row, 'swing_entry_gate_v977', 'structure_plan', 'plan_key'),
        _v1263_nested(row, 'swing_entry_gate_v977', 'structure_plan', 'plan_id'),
        _v1263_nested(row, 'trigger_occurrence', 'base_plan_decision_key'),
        _v1263_nested(row, 'swing_entry_gate_v977', 'trigger_occurrence', 'base_plan_decision_key'),
    ):
        text = str(value or '').strip()
        if text:
            return text
    frozen = _v1233_float(
        row.get('swing_trigger_frozen_ts_v977'),
        _v1263_nested(row, 'swing_structure_plan_v977', 'frozen_ts'),
        _v1263_nested(row, 'swing_entry_gate_v977', 'frozen_ts'),
        _v1263_nested(row, 'swing_entry_gate_v977', 'structure_plan', 'frozen_ts'),
        _v1263_nested(row, 'trigger_occurrence', 'plan_frozen_ts'),
        _v1263_nested(row, 'swing_entry_gate_v977', 'trigger_occurrence', 'plan_frozen_ts'),
        default=0.0,
    )
    return f'frozen:{int(frozen * 1000.0)}' if frozen > 0 else ''


def _v1263_semantic_identity(row: Dict[str, Any], ticker: str, reason_category: str) -> tuple[str, str]:
    scanner = _v1262_scanner_occurrence(row)
    plan = _v1263_plan_identity(row)
    if plan:
        stable = f'scanner:{scanner or "NONE"}|plan:{plan}'
    elif scanner:
        # No structure exists yet.  The scanner occurrence and exclusion family
        # are the only stable owners available; no time-proximity guessing.
        stable = f'scanner:{scanner}|no_plan|reason:{reason_category}'
    else:
        return '', ''
    digest = hashlib.sha256(f'{ticker}|{stable}'.encode('utf-8', errors='ignore')).hexdigest()[:32]
    return digest, stable


def _v1263_new_state(nowv: float) -> Dict[str, Any]:
    return {
        'schema': V1263_MISSED_STATE_SCHEMA,
        'started_ts': nowv, 'started_text': now_text(nowv),
        'updated_ts': nowv, 'updated_text': now_text(nowv),
        'events': {},
        'exact_key_missing_skipped': 0,
        'semantic_key_missing_skipped': 0,
        'fresh_start_v1312': True,
        'fresh_start_v1263': True,
        'retired_state_imported': False,
        'bounded_writer_v1312': True,
        'max_events_v1312': V1263_MAX_EVENTS,
        'auto_buy': False,
    }


def _v1263_load_state(base: Path, nowv: float) -> Dict[str, Any]:
    global _V1263_STATE_CACHE, _V1263_STATE_CACHE_BASE
    base_key = str(base.resolve())
    if _V1263_STATE_CACHE and _V1263_STATE_CACHE_BASE == base_key:
        return _V1263_STATE_CACHE
    current = read_json(base / V1263_STATE_FILE, {}) or {}
    if not isinstance(current, dict) or current.get('schema') != V1263_MISSED_STATE_SCHEMA or not isinstance(current.get('events'), dict):
        current = _v1263_new_state(nowv)
    _V1263_STATE_CACHE = current
    _V1263_STATE_CACHE_BASE = base_key
    return _V1263_STATE_CACHE


def _v1263_compact_event(event: Dict[str, Any]) -> Dict[str, Any]:
    out = dict(event)
    keys = [str(x).strip() for x in (out.get('exact_candidate_keys') or []) if str(x).strip()]
    first = str(out.get('exact_candidate_key') or '').strip()
    last = str(out.get('exact_candidate_key_last') or '').strip()
    ordered: list[str] = []
    for value in [first] + keys + [last]:
        if value and value not in ordered:
            ordered.append(value)
    if len(ordered) > V1263_MAX_EXACT_KEYS_PER_EVENT:
        ordered = ordered[:2] + ordered[-2:]
    out['exact_candidate_keys'] = ordered
    out['exact_candidate_key'] = ordered[0] if ordered else None
    out['exact_candidate_key_last'] = ordered[-1] if ordered else None
    for key in ('reasons', 'last_reasons', 'created_text'):
        out.pop(key, None)
    return out


def _v1312_prune_events(events: Dict[str, Any], nowv: float) -> tuple[Dict[str, Any], int, str]:
    """Bound Review-only missed-opportunity state so it cannot grow without limit.

    This is display/review data only.  It never changes Strategy candidates,
    Paper OPEN/CLOSED, trigger, invalid, target, RR, or exits.
    """
    if not isinstance(events, dict):
        return {}, 0, 'not_dict'
    before = len(events)
    # First keep the normal time retention, then enforce an absolute capacity cap.
    rows = [(str(k), v) for k, v in events.items() if isinstance(v, dict)]
    rows.sort(key=lambda kv: (_v1233_float(kv[1].get('last_seen_ts'), kv[1].get('created_ts'), default=0.0), str(kv[0])), reverse=True)
    if len(rows) <= V1263_MAX_EVENTS_HARD:
        return dict(rows), max(0, before - len(rows)), 'retention_only'
    kept = rows[:V1263_MAX_EVENTS]
    return dict(kept), max(0, before - len(kept)), 'capacity_bound_v1312'

def _v1263_update_state(state: Dict[str, Any], rows: list[Dict[str, Any]], nowv: float) -> Dict[str, Any]:
    events = state.setdefault('events', {})
    cutoff = nowv - V1261_RETENTION_SEC
    for key in list(events):
        event = events.get(key) if isinstance(events.get(key), dict) else {}
        if _v1233_float(event.get('created_ts'), default=0.0) < cutoff:
            events.pop(key, None)
    prices = {_v1233_ticker(r): _v1233_price(r) for r in rows if isinstance(r, dict) and _v1233_ticker(r) and _v1233_price(r) > 0}
    exact_missing = 0
    semantic_missing = 0
    created = 0
    observations = 0
    for row in rows:
        if not isinstance(row, dict):
            continue
        exact_key = _v1261_candidate_key(row)
        if not exact_key:
            exact_missing += 1
            continue
        ticker = _v1233_ticker(row)
        if not ticker:
            continue
        reasons = _v1261_reason_texts(row)
        category = _v1261_reason_category(row, reasons)
        identity, stable = _v1263_semantic_identity(row, ticker, category)
        if not identity:
            semantic_missing += 1
            continue
        if _v1261_ready(row):
            if isinstance(events.get(identity), dict) and events[identity].get('recovered_to_ready_ts') is None:
                events[identity]['recovered_to_ready_ts'] = nowv
                events[identity]['recovered_to_ready'] = True
            continue
        price = _v1233_price(row)
        if price <= 0:
            continue
        if not isinstance(events.get(identity), dict):
            lines = _v1261_line_values(row)
            events[identity] = {
                'event_id': identity,
                'semantic_occurrence_key': stable,
                'semantic_key_schema': 'scanner_occurrence_plus_frozen_plan_v1263',
                'exact_candidate_key': exact_key,
                'exact_candidate_key_last': exact_key,
                'exact_candidate_keys': [exact_key],
                'observation_count': 0,
                'candidate_decision_key': str(row.get('swing_gate_decision_key_v977') or '').strip() or None,
                'ticker': ticker, 'reason_category': category,
                'created_ts': nowv,
                'start_price': price, 'current_price': price, 'high_price': price, 'low_price': price,
                'scanner_occurrence_key': _v1262_scanner_occurrence(row) or None,
                'plan_identity_v1263': _v1263_plan_identity(row) or None,
                'candidate_cycle_id_first': row.get('candidate_pipeline_cycle_id_v1150'),
                'candidate_commit_id_first': str(row.get('candidate_commit_id') or '').strip() or None,
                'recovered_to_ready': False,
                **lines,
            }
            created += 1
        event = events[identity]
        keys = [str(x).strip() for x in (event.get('exact_candidate_keys') or []) if str(x).strip()]
        if exact_key not in keys:
            keys.append(exact_key)
        if len(keys) > V1263_MAX_EXACT_KEYS_PER_EVENT:
            keys = keys[:2] + keys[-2:]
        event['exact_candidate_keys'] = keys
        event['exact_candidate_key_last'] = exact_key
        event['observation_count'] = int(event.get('observation_count') or 0) + 1
        event['candidate_cycle_id_last'] = row.get('candidate_pipeline_cycle_id_v1150')
        event['candidate_commit_id_last'] = str(row.get('candidate_commit_id') or '').strip() or None
        event['last_reason_category'] = category
        observations += 1
    for event in list(events.values()):
        if not isinstance(event, dict):
            continue
        price = prices.get(str(event.get('ticker') or ''), 0.0)
        if price > 0:
            _v1261_update_event_path(event, price, nowv)
    events, pruned_capacity, prune_reason = _v1312_prune_events(events, nowv)
    state['exact_key_missing_skipped'] = exact_missing
    state['semantic_key_missing_skipped'] = semantic_missing
    state['events_created_this_cycle'] = created
    state['observations_added_this_cycle'] = observations
    state['events_pruned_capacity_this_cycle_v1312'] = pruned_capacity
    state['prune_reason_v1312'] = prune_reason
    state['bounded_writer_v1312'] = True
    state['max_events_v1312'] = V1263_MAX_EVENTS
    state['updated_ts'] = nowv
    state['updated_text'] = now_text(nowv)
    state['events'] = events
    return state


def _v1263_compact_state(state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out = dict(state)
    events = out.get('events') if isinstance(out.get('events'), dict) else {}
    out['events'] = {str(key): _v1263_compact_event(value) for key, value in events.items() if isinstance(value, dict)}
    out['schema'] = V1263_MISSED_STATE_SCHEMA
    out['updated_ts'] = nowv
    out['updated_text'] = now_text(nowv)
    out['state_owner'] = 'review_worker_bounded_current_missed_state_v1312'
    out['retired_state_imported'] = False
    out['retention_hours'] = 24
    out['max_events_v1312'] = V1263_MAX_EVENTS
    out['bounded_writer_v1312'] = True
    out['auto_buy'] = False
    return out


def _v1263_state_digest(state: Dict[str, Any]) -> str:
    events = state.get('events') if isinstance(state.get('events'), dict) else {}
    material = {
        'event_count': len(events),
        'completed_6h': sum(1 for e in events.values() if isinstance(e, dict) and e.get('return_6h_pct') is not None),
        'observation_total': sum(int(e.get('observation_count') or 0) for e in events.values() if isinstance(e, dict)),
        'latest_event_ts': max((_v1233_float(e.get('created_ts'), default=0.0) for e in events.values() if isinstance(e, dict)), default=0.0),
    }
    return hashlib.sha256(json.dumps(material, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def _v1263_persist_state(base: Path, state: Dict[str, Any], nowv: float, force: bool = False) -> tuple[bool, str]:
    global _V1263_LAST_STATE_WRITE_TS, _V1263_LAST_PERSISTED_DIGEST
    digest = _v1263_state_digest(state)
    due = force or _V1263_LAST_STATE_WRITE_TS <= 0 or (nowv - _V1263_LAST_STATE_WRITE_TS) >= V1263_STATE_WRITE_INTERVAL_SEC
    if not due:
        return False, digest
    if (not force) and _V1263_LAST_PERSISTED_DIGEST and digest == _V1263_LAST_PERSISTED_DIGEST:
        _V1263_LAST_STATE_WRITE_TS = nowv
        return False, digest
    atomic_write_json(base / V1263_STATE_FILE, state)
    _V1263_LAST_STATE_WRITE_TS = nowv
    _V1263_LAST_PERSISTED_DIGEST = digest
    return True, digest


def _v1263_missed_summary(state: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    out = _v1261_missed_summary(state, nowv)
    out['schema'] = 'current_strategy_missed_summary_v1263'
    out['semantic_occurrence_total'] = int(out.get('tracked_total') or 0)
    out['source_observation_total'] = sum(int(e.get('observation_count') or 0) for e in (state.get('events') or {}).values() if isinstance(e, dict))
    out['semantic_key_missing_skipped'] = int(state.get('semantic_key_missing_skipped') or 0)
    out['events_created_this_cycle'] = int(state.get('events_created_this_cycle') or 0)
    out['observations_added_this_cycle'] = int(state.get('observations_added_this_cycle') or 0)
    out['fresh_start_v1263'] = True
    out['fresh_start_v1312'] = True
    out['bounded_writer_v1312'] = True
    out['max_events_v1312'] = V1263_MAX_EVENTS
    out['events_pruned_capacity_this_cycle_v1312'] = int(state.get('events_pruned_capacity_this_cycle_v1312') or 0)
    out['state_age_sec'] = max(0.0, nowv - _v1233_float(state.get('started_ts'), default=nowv))
    out['policy'] = 'fresh v1312 bounded state only; exact key audit evidence; semantic owner = scanner occurrence + frozen plan; 24h retention with capacity bound; no actual PnL'
    return out


def update_version_score_review(base: Path, rows: list[Dict[str, Any]], live_rows: Optional[list[Dict[str,Any]]] = None,
                                generation: Optional[Dict[str,Any]] = None, generation_integrity: Optional[Dict[str,Any]] = None) -> Dict[str, Any]:  # type: ignore[override]
    nowv = now_ts()
    candidate_rows = [r for r in (rows or []) if isinstance(r, dict)]
    gen = dict(generation or _v1239_generation_context(base))
    state = _v1263_load_state(base, nowv)
    state = _v1263_update_state(state, candidate_rows, nowv)
    state = _v1263_compact_state(state, nowv)
    _V1263_STATE_CACHE.clear()
    _V1263_STATE_CACHE.update(state)
    persisted, state_digest = _v1263_persist_state(base, state, nowv, force=not (base / V1263_STATE_FILE).exists())
    contracts = [_v1261_contract(row) for row in candidate_rows if _v1261_contract(row)]
    missed = _v1263_missed_summary(state, nowv)
    summary = {
        'schema': V1262_MISSED_SUMMARY_SCHEMA, 'version': VERSION, 'build': BUILD_LABEL,
        'updated_ts': nowv, 'updated_text': now_text(nowv),
        'mode': 'CURRENT_SCORE_TRUTH_AND_FRESH_STABLE_MISSED_V1263',
        'current_generation': {
            'pipeline_cycle_id': gen.get('cycle_id'), 'candidate_commit_id': gen.get('candidate_commit_id'),
            'candidate_rows': len(candidate_rows), 'integrity': dict(generation_integrity or {}),
        },
        'unified_strategy_v1257': {
            'state': 'NORMAL' if contracts else 'COLLECTING', 'contract_rows': len(contracts),
            'ready_rows': sum(1 for x in contracts if x.get('ready') is True),
            'early_failure_rows': sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('early_failure_invalid_price'))),
            'extension_rows': sum(1 for x in contracts if ((x.get('v1211_structural_support') or {}).get('extension_target_price'))),
            'quality_confirmed_rows': sum(1 for x in contracts if ((x.get('entry_quality_support') or {}).get('confirmed') is True)),
            'entry_owner': 'strategy_worker.apply_swing_entry_gate_v1257',
            'exit_owner': 'paper_bot._exit_decision_spine_v1257 for new sealed OPEN only',
            'existing_open_unchanged': True, 'auto_buy': False,
        },
        'current_missed_v1262': missed,
        'current_missed_v1263': missed,
        'review_state_v1263': {
            'state_file': V1263_STATE_FILE,
            'event_count': len(state.get('events') or {}),
            'persist_interval_sec': V1263_STATE_WRITE_INTERVAL_SEC,
            'persisted_this_cycle': persisted,
            'last_persisted_ts': _V1263_LAST_STATE_WRITE_TS,
            'digest': state_digest,
            'fresh_start': True,
            'fresh_start_v1312': True,
            'retired_state_imported': False,
            'bounded_writer_v1312': True,
            'max_events_v1312': V1263_MAX_EVENTS,
            'events_pruned_capacity_this_cycle_v1312': int(state.get('events_pruned_capacity_this_cycle_v1312') or 0),
            'old_v1261_state_rewritten': False,
            'old_v1262_state_rewritten': False,
        },
        'retired_experiments_v1257': {
            'state': 'RETIRED_FROM_ACTIVE_DECISION_AND_PUBLIC_SCORE',
            'items': ['transition cohort','old missed accumulation','previous structure virtual shadow','policy competition','hybrid shadow','pair matchup','v1261/v1262 churned missed state'],
            'guard_cleanup_allowlisted_after_v1263_proof': True,
            'historical_trade_ledgers_rewritten': False,
            'new_state_writes': False, 'trade_decision_use': False,
        },
        'paper_exact_exit_replay_v1242': _v1242_paper_exact_replay_status(base),
        'invariants': {
            'review_changes_candidates': False, 'review_changes_open_closed': False,
            'canonical_performance_owner': 'paper_bot',
            'exact_candidate_key_required': True, 'exact_candidate_key_is_event_owner': False,
            'semantic_occurrence_owner': 'scanner occurrence plus frozen plan identity',
            'ticker_time_proximity_link_forbidden': True,
            'retired_state_imported': False,
            'actual_trade_ledgers_deleted': False,
            'auto_buy': False,
        },
    }
    atomic_write_json(base / V1262_SUMMARY_FILE, summary)
    return summary


V1263_REVIEW_CONTRACT = {
    'schema': 'fresh_stable_current_missed_review_contract_v1263',
    'state_file': V1263_STATE_FILE,
    'fresh_start': True,
    'fresh_start_v1312': True,
    'bounded_writer_v1312': True,
    'max_events_v1312': V1263_MAX_EVENTS,
    'retired_state_imported': False,
    'semantic_owner': 'scanner occurrence + frozen plan identity',
    'ticker_time_proximity_link': False,
    'persist_interval_sec': V1263_STATE_WRITE_INTERVAL_SEC,
    'retention_hours': 24,
    'retired_review_files_guard_deletable_after_proof': True,
    'v1263_large_state_guard_deletable_after_v1312_proof': True,
    'candidate_formula_changed': False,
    'trigger_invalid_target_rr_changed': False,
    'entry_exit_changed': False,
    'auto_buy': False,
}

# v1190 read-only phase timing evidence
from runtime_phase_probe_v1190 import wrap_function as _v1190_wrap_function
_v1190_wrap_function(globals(), "process_once", "review", "cycle", VERSION, 300.0)

if __name__ == "__main__":
    raise SystemExit(main())
