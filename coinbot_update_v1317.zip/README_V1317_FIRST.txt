v1317: generation spine unification. Apply /gupgrade_bundle first. No strategy formula/trigger/invalid/target/RR/exit/autobuy change.
