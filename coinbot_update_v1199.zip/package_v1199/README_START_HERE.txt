coinbot_update_v1199

목적:
- v1198 폐기 및 OPEN 30/cycle 3 변경 완전 제외
- 현재 오류 0인데 남던 가짜 CHECK 정리
- Review 비동기 지연·Main 명령형 profile·Paper 경계표본·자원 관찰을 실제 오류와 분리
- 후보 수·OPEN 수·cycle 수 변경 없음

적용은 APPLY_V1199.txt 순서만 사용합니다.
