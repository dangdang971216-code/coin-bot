#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, sys, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name: str, path: Path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); sys.modules[name]=mod; spec.loader.exec_module(mod); return mod

spine=load('spine_v1199',ROOT/'canonical_spine_v1190.py')


def write_json(path: Path, obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj),encoding='utf-8')


def test_recent_async_review_lag_is_normal_chain():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); now=time.time()
        pipeline={'cycle_id':'c2','candidate_commit_id':'k2','committed_handoff_file_v1158':'handoff.json'}
        request={'cycle_id':'c2','candidate_commit_id':'k2','created_ts':now}
        review={'generated_ts':now-12,'source':{'pipeline_cycle_id':'c1','candidate_commit_id':'k1'}}
        standard={}; performance={}
        write_json(root/'handoff.json',{'cycle_id':'c2','candidate_commit_id':'k2'})
        for name in ('strategy_candidate_pipeline_commit_v1150.json','review_observation_request_v1181.json','canonical_review_snapshot_v1181.json','canonical_candidate_standard_v1181.json','paper_bot_status.json','paper_bot_open.json','paper_closed_append_status_v925.json','canonical_performance_snapshot_v987.json'):
            write_json(root/name,{})
        out=spine._artifact_chain_summary(root,now,pipeline,request,review,standard,performance)
        assert out['state']=='NORMAL',out
        assert out['review_relation']=='ASYNC_REVIEW_LAG',out
        assert out['async_lag_consumers_v1199']==['review_snapshot'],out
        assert out['collecting_consumers']==[],out


def test_unscoped_historical_lines_do_not_create_problem():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td)
        # Verify the exact problem gate rather than deleting preserved history.
        source=(ROOT/'canonical_spine_v1190.py').read_text(encoding='utf-8')
        assert 'errors.get("state") == "CHECK" and errors.get("unscoped_line_count")' in source
        assert 'elif errors.get("unscoped_line_count"):' not in source


def test_on_demand_main_stale_profile_is_informational():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); now=time.time(); d=root/'runtime'; d.mkdir()
        write_json(d/'runtime_phase_profile_main_v1190.json',{
            'component':'main','version':'수익형 v2.13.1135','pid':111,
            'scopes':{'command_bundle':{'state':'NORMAL','total_sec':4.0,'last_sec':4.0,'completed_ts':now-900,'publish_interval_sec':300,'window_count':1,'window_avg_sec':4.0,'top_functions':[]}}
        })
        old=now-900; os.utime(d/'runtime_phase_profile_main_v1190.json',(old,old))
        runtime={'components':[{'component':'main','main_pid':111,'status_version':'수익형 v2.13.1135','status_age_sec':1}]}
        out=spine._phase_profile_summary(root,now,runtime)
        row=next(x for x in out['components'] if x['component']=='main')
        assert row['state']=='NORMAL',row
        assert row['on_demand_stale_but_runtime_current_v1199'] is True,row
        assert not [x for x in out['issue_components_v1197'] if x['component']=='main'],out


def test_small_single_paper_overrun_is_not_current_issue():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); now=time.time(); d=root/'runtime'; d.mkdir()
        write_json(d/'runtime_phase_profile_paper_v1190.json',{
            'component':'paper','version':'paper_bot_v1.052','pid':222,
            'scopes':{'execution_core':{'state':'NORMAL','total_sec':10.48,'last_sec':10.48,'completed_ts':now-2,'publish_interval_sec':10,'window_count':1,'window_avg_sec':10.48,'top_functions':[]}}
        })
        runtime={'components':[{'component':'paper','main_pid':222,'status_version':'paper_bot_v1.052','status_age_sec':1}]}
        out=spine._phase_profile_summary(root,now,runtime)
        assert not [x for x in out['slow_observations'] if x['component']=='paper'],out['slow_observations']


def test_sustained_or_material_paper_overrun_remains_visible():
    with tempfile.TemporaryDirectory() as td:
        root=Path(td); now=time.time(); d=root/'runtime'; d.mkdir()
        path=d/'runtime_phase_profile_paper_v1190.json'
        runtime={'components':[{'component':'paper','main_pid':222,'status_version':'paper_bot_v1.052','status_age_sec':1}]}
        write_json(path,{'component':'paper','version':'paper_bot_v1.052','pid':222,'scopes':{'execution_core':{'state':'NORMAL','total_sec':10.6,'last_sec':10.6,'completed_ts':now-2,'publish_interval_sec':10,'window_count':4,'window_avg_sec':10.4,'top_functions':[]}}})
        out=spine._phase_profile_summary(root,now,runtime)
        row=next(x for x in out['slow_observations'] if x['component']=='paper')
        assert row['sustained_over_limit_v1199'] is True,row
        write_json(path,{'component':'paper','version':'paper_bot_v1.052','pid':222,'scopes':{'execution_core':{'state':'NORMAL','total_sec':13.0,'last_sec':13.0,'completed_ts':now-2,'publish_interval_sec':10,'window_count':1,'window_avg_sec':13.0,'top_functions':[]}}})
        out2=spine._phase_profile_summary(root,now,runtime)
        row2=next(x for x in out2['slow_observations'] if x['component']=='paper')
        assert row2['material_single_overrun_v1199'] is True,row2



def test_component_cpu_is_observation_when_server_has_headroom():
    out=spine._resource_summary(Path('/tmp'),{
        'server':{'disk_free_gb':3.89,'disk_used_pct':72.8,'mem_used_pct':26.4,'mem_available_mb':17680.0,'cpu_pct':90.5,'iowait_pct':0.2,'load1':5.49,'cpu_count':8},
        'components':{'paper':{'cpu_pct':75.6,'rss_mb':3184.2},'micro':{'cpu_pct':76.1,'rss_mb':41.2},'strategy':{'cpu_pct':81.2,'rss_mb':557.6}},
    })
    assert out['state']=='NORMAL',out
    assert {x['component'] for x in out['slow_cpu']}=={'paper','micro','strategy'},out
    assert out['high_rss'][0]['component']=='paper',out
    assert out['component_activity_is_observation_v1199'] is True,out


def test_actual_server_pressure_remains_check():
    out=spine._resource_summary(Path('/tmp'),{
        'server':{'disk_free_gb':2.5,'disk_used_pct':85.0,'mem_used_pct':30.0,'mem_available_mb':12000.0,'cpu_pct':96.0,'iowait_pct':0.5,'load1':9.0,'cpu_count':8},
        'components':{},
    })
    assert out['state']=='CHECK',out
    assert out['pressure_check_reasons_v1199'],out

def test_versions_and_no_open_limit_change():
    main=(ROOT/'coinbot_main_v2_13_1135.py').read_text(encoding='utf-8')
    guard=(ROOT/'backga_guard_bot_v2_5_205.py').read_text(encoding='utf-8')
    assert '수익형 v2.13.1135' in main
    assert 'guard_v2.5.205_v1199' in guard
    assert 'USER_APPROVED_UNLIMITED_UNTIL_QUALITY_REVIEW' in guard
    assert "'OPEN_LIMIT_MODE','severity':'NORMAL'" in guard
    assert 'OPEN 30/cycle 3' not in guard
    names={p.name for p in ROOT.iterdir() if p.is_file()}
    assert 'paper_bot_v1.053.py' not in names
    assert 'paper_bot_v1.052.py' not in names


if __name__=='__main__':
    tests=[test_recent_async_review_lag_is_normal_chain,test_unscoped_historical_lines_do_not_create_problem,test_on_demand_main_stale_profile_is_informational,test_small_single_paper_overrun_is_not_current_issue,test_sustained_or_material_paper_overrun_remains_visible,test_component_cpu_is_observation_when_server_has_headroom,test_actual_server_pressure_remains_check,test_versions_and_no_open_limit_change]
    for fn in tests:
        fn(); print('PASS',fn.__name__)
    print(f'PASS {len(tests)}/{len(tests)}')
