현재 실행 중인 Guard는 자기 새 코드를 같은 명령 안에서 사용할 수 없습니다.
첫 적용 후 /gguard_restart로 v2.6.60을 활성화하고, 같은 v2240 ZIP을 한 번 더 실행하면
Main·Review는 고정 시간제한 없이 정확한 runtime 신분이 나올 때까지 기다린 뒤 최종 PASS를 냅니다.
