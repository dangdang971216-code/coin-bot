이 ZIP에는 라이브 원장이 포함되지 않는다.
절대 덮어쓰거나 삭제하지 않을 파일:
- paper_bot_open.json 및 OPEN 원장
- paper_bot_closed.jsonl
- paper_bot_trade_log 계열
- paper_decision_state 계열
- canonical exact/performance 원장
- change_verify_ledger / issue_ledger_events
- good-S2 및 관찰 결과 원장
배포는 Python source와 release metadata만 교체한다.
