v1352 fixes v1351 bundle manifest/runtime labels so main/strategy/paper are actual deploy targets, not SKIP. 자동매수 OFF. No live ledger included.
