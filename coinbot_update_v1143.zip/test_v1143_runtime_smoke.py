import importlib.util, json, shutil, tempfile, time
from pathlib import Path

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

ROOT=Path(__file__).resolve().parent

def prepare_strategy(mod, writer_status):
    mod.PAPER_LATEST_WRITER_STATUS_V861=writer_status
    mod._v1026_load_candidate_commit_state=lambda:None
    mod._v1021_collect_candidate_publish_status=lambda rows,base:dict(base)
    mod._v1028_live_phase_enter=lambda *a,**k:None
    mod._v1027_phase_stop=lambda *a,**k:None
    mod._v821_publish_candidate_lite_snapshot=lambda *a,**k:None
    mod._v861_compact_row_for_latest=lambda r:dict(r)
    mod._v861_cleanup_legacy_tmp=lambda p:{}
    mod._v1026_candidate_commit_fields=lambda:{}
    mod._v1021_write_io_status=lambda *a,**k:None
    mod.save_json=lambda path,obj: Path(path).write_text(json.dumps(obj,ensure_ascii=False))

with tempfile.TemporaryDirectory() as module_td:
    module_td=Path(module_td)
    copied={}
    for name in ('strategy_worker_v1.014.py','paper_bot_v1.026.py','coinbot_main_v2_13_1110.py'):
        copied[name]=module_td/name
        shutil.copy2(ROOT/name,copied[name])

    # Strategy writer output bytes remain exact; only status proof is added.
    new_strategy=load('strategy_new',copied['strategy_worker_v1.014.py'])
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        rows=[{'ticker':'AAA','rank':1},{'ticker':'BBB','rank':2}]
        new_latest=td/'new.jsonl'
        prepare_strategy(new_strategy,td/'new_status.json')
        new_strategy._v1021_publish_candidate_snapshot(new_latest,rows,{})
        expected=b''.join(json.dumps(r,ensure_ascii=False,separators=(',',':')).encode('utf-8')+b'\n' for r in rows)
        assert new_latest.read_bytes()==expected
        status=json.loads((td/'new_status.json').read_text())
        scope=status['candidate_snapshot_scope']
        assert scope['state']=='NORMAL' and scope['rows_written']==2
        assert scope['atomic_replace'] is True and scope['complete_snapshot'] is True

    # Paper reads Strategy proof and effective control without command execution.
    paper=load('paper_v1143',copied['paper_bot_v1.026.py'])
    captured={}
    paper._v1135_update_trigger_stability_audit=lambda:{'schema':'audit'}
    paper._v1135_update_fresh_path_evidence=lambda status:{'schema':'fresh'}
    paper._v1045_manifest=lambda:{}
    paper._v1045_epoch=lambda:{}
    paper.load_control=lambda:{'candidate_ttl_sec':120,'max_open_strict':30,'max_new_per_cycle':3,'new_open_paused':False,'time_exit_minutes':15}
    paper._V1135_PREV_WRITE_STATUS=lambda out:captured.update(out)
    def fake_load(path,default=None):
        name=Path(path).name
        if name=='clean_strategy_paper_latest_writer_status.json':
            return {'result':'OK','candidate_snapshot_scope':{'state':'NORMAL','complete_snapshot':True,'atomic_replace':True,'tail_cap':None,'rows_written':460,'output_bytes':123,'commit_id':'c1','updated_ts':100.0}}
        return default if default is not None else {}
    paper.load_json=fake_load
    paper.write_status__v1135({'version':'paper_bot_v1.026'})
    ps=captured['candidate_summary_scope_v1143']
    assert ps['state']=='NORMAL' and ps['rows_written']==460
    assert captured['effective_control_contract_v1142']['max_open_strict']==30
    assert captured['effective_control_contract_v1142']['max_new_per_cycle']==3

    # Main refuses stale Review verdicts. Its import side effects stay in temp.
    main=load('main_v1143',copied['coinbot_main_v2_13_1110.py'])
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        (td/'candidate_standard_status_v1141.json').write_text(json.dumps({'updated_ts':time.time()-600,'final_judgement':{'state':'MIXED'}}))
        (td/'clean_review_worker_status.json').write_text(json.dumps({'phase':'idle_after_error','state':'error','error':'NameError: legacy wrapper'}))
        main.BASE_DIR=td
        main.CANDIDATE_STANDARD_STATUS_V1141=td/'candidate_standard_status_v1141.json'
        rendered=main.render_candidate_standard_text()
        assert 'CHECK_SOURCE · 현재판정 사용 금지' in rendered
        assert 'legacy wrapper' in rendered

print(json.dumps({'ok':True,'strategy_output_exact':True,'strategy_scope_rows':scope['rows_written'],'paper_scope_state':ps['state'],'paper_open_limit':30,'paper_cycle_limit':3,'main_stale_block':True},ensure_ascii=False))
