# v1143 후보 기준판 본선 재연결·구경로 삭제

## 원인
v1142 Review tail wrapper가 선언되지 않은 이전 run_once/cadence 변수를 참조해 장기 실행 첫 cycle에서 실패했다. 후보판 전체범위 proof도 `/candidate_summary` 명령 실행에 의존했고, Review 상태가 오래돼도 Main은 과거 MIXED를 현재 판정처럼 표시할 수 있었다.

## 제거
- Review candidate-standard run_once tail wrapper
- Strategy candidate-standard run_once tail wrapper
- 선언되지 않은 legacy wrapper globals
- Paper command-side scope status writer
- Guard의 `paper_candidate_summary_scope_v1140.json` reader
- stale Review verdict의 정상 표시

## 단일 본선
1. Strategy atomic candidate writer가 행수·바이트·commit ID·atomic/full scope를 status에 봉인한다.
2. Paper status가 Strategy proof와 실제 effective control을 읽는다.
3. Review의 기존 단일 run_once가 기준판을 60초 cadence로 갱신한다.
4. Guard는 Review runtime error·stale status·scope mismatch를 지도에 올린다.
5. Main은 Review 오류 또는 180초 초과 시 과거 판정을 차단한다.

## 변경하지 않은 영역
Gate, rank, TTL 120초, trigger/invalid/target/RR, spread/slippage, exit 수치, OPEN 30, cycle 3, 자동매수 OFF, 보호 원장.

## 서버 DONE 조건
- Review v1.010 phase `idle/running`, error 없음
- 후보 기준판 `CHECK_SAMPLE` 또는 `NORMAL`; stale MIXED 금지
- Paper effective contract `30/3`, scope NORMAL
- Guard `REVIEW_RUNTIME_ERROR`, `CANDIDATE_SUMMARY_SCOPE_MISMATCH` 해소
- Strategy candidate output bytes/rows 동일
- 신규 runtime 오류 0
