import ast, importlib.util, json, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

# Review direct-cycle contract: no wrapper, all globals initialized.
review_path=ROOT/'review_worker_v1.010.py'
text=review_path.read_text()
assert 'run_once__v1141_candidate_standard' not in text
assert '_V1141_PREV_RUN_ONCE' not in text
assert 'candidate_standard_cycle = _candidate_standard_cycle_update()' in text
review=load('review_v1143',review_path)
with tempfile.TemporaryDirectory() as td:
    review.CANDIDATE_STANDARD_STATUS_V1141=Path(td)/'missing.json'
    review._v1141_standard_source_signature=lambda: 'sig'
    review.update_candidate_standard=lambda *a,**k: {
        'final_judgement':{'state':'CHECK_SAMPLE'},
        'baseline_identity':{'baseline_id':'B1'},
        'candidate_quality':{'all_rows':460,'reference_state':{'state':'COLLECTING'}},
    }
    review._CANDIDATE_STANDARD_LAST_RUN_MONO=0.0
    out=review._candidate_standard_cycle_update()
    assert out['state']=='CHECK_SAMPLE'
    assert out['writer_owner']=='review_worker.run_once'

# Strategy candidate scope is owned by the atomic writer, not a command.
strategy_path=ROOT/'strategy_worker_v1.014.py'
stext=strategy_path.read_text()
assert "'candidate_snapshot_scope':{" in stext
assert "'owner':'strategy_worker._v1021_publish_candidate_snapshot'" in stext
assert "'legacy_tail_300_retired':True" in stext

# Paper command no longer writes the scope proof.
paper_path=ROOT/'paper_bot_v1.026.py'
ptext=paper_path.read_text()
assert '_v1140_write_candidate_scope_status' not in ptext
assert 'V1140_CANDIDATE_SCOPE_STATUS' not in ptext
assert 'candidate_summary_scope_v1143' in ptext
assert "Strategy atomic candidate writer proof -> Paper status reader" not in ptext  # Guard owns this wording.

# Main blocks stale/error Review output instead of showing an old verdict.
main_path=ROOT/'coinbot_main_v2_13_1110.py'
mtext=main_path.read_text()
assert 'CHECK_SOURCE · 현재판정 사용 금지' in mtext
assert "review_phase=='idle_after_error'" in mtext
assert '과거 MIXED/NORMAL 값은 stale reference' in mtext

# Guard promotes Review runtime errors and reads Strategy/Paper scope proof.
guard_path=ROOT/'backga_guard_bot_v2_5_184.py'
gtext=guard_path.read_text()
assert 'REVIEW_RUNTIME_ERROR' in gtext
assert 'ops_candidate_summary_scope_contract_v1143' in gtext
assert 'command execution never owns scope freshness' in gtext
assert "BOT_DIR/'paper_candidate_summary_scope_v1140.json'" not in gtext

# Trading invariants: baseline hashes are bundled; only writer/status integration may differ.
baseline=json.loads((ROOT/'BASELINE_FUNCTION_HASHES_V1143.json').read_text())['function_hashes']
new_tree=ast.parse(strategy_path.read_text())
new_hashes={n.name:__import__('hashlib').sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in new_tree.body if isinstance(n,ast.FunctionDef)}
changed=sorted(k for k in set(baseline)|set(new_hashes) if baseline.get(k)!=new_hashes.get(k))
allowed=['_v1021_publish_candidate_snapshot','run_once__v1115_tx_closeout','run_once__v1141_candidate_standard_contract']
assert changed==allowed, changed

print(json.dumps({'ok':True,'review_state':out['state'],'strategy_changed_functions':changed,'scope_owner':'strategy_atomic_writer'},ensure_ascii=False))
