코인봇 v2208
- 원인: Main이 exact 필드가 없으면 구 valid_events를 exact로 대체했고, Review 재시작 중 이전 프로세스 snapshot을 계속 현재값으로 표시
- 수정: current Review snapshot/runtime/health의 producer instance가 모두 같을 때만 완료본 인정
- 새 계산 중에는 BUILDING, exact 0 완료본은 표본 축적 CHECK로 표시
- 구 정확도/TOP/점수구간 재사용 없음
- 상승예측식·후보·구조·Paper·청산·원장 변경 없음
- 자동매수 OFF
