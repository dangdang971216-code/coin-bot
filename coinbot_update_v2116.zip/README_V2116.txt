coinbot_update_v2116

Main: 수익형 v2.13.2098
Paper: paper_bot_v2.069
Strategy: strategy_worker_v2.035
Review: review_worker_v2.044
Guard: guard_v2.6.10
Support: candidate_commit_spine.py

This release replaces, rather than wraps, the v2111-v2115 candidate transport path.
LOCAL DONE / SERVER CHECK. Auto-buy OFF.
