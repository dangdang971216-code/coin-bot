#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Canonical candidate commit spine.

One immutable Strategy commit owns candidates and S1 hold rows. Paper and Review
acknowledge that exact commit; they never invent a second cycle id. The current
pointer is written only after all commit files and compatibility mirrors are
fully durable. Trading formulas and ledgers are outside this module.
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import shutil
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Tuple

SCHEMA = "candidate_commit_spine_v2116"
ROOT_DIRNAME = "candidate_commit_spine"
CURRENT_POINTER = "candidate_commit_current.json"
COMPLETED_POINTER = "candidate_commit_completed.json"
STATUS_FILE = "candidate_commit_spine_status.json"
CLEANUP_FILE = "candidate_commit_cleanup_status.json"
LOCK_FILE = "candidate_commit_spine.lock"
KEEP_COMMITS = 4

LEGACY_STATE_FILES = (
    "unified_structure_contract_status_v2111.json",
    "unified_structure_contract_status_v2113.json",
    "unified_structure_contract_status_v2114.json",
    "unified_structure_contract_status_v2115.json",
    "strategy_candidate_contract_snapshot_v2113.json",
    "strategy_candidate_contract_snapshot_v2114.json",
    "strategy_candidate_contract_snapshot_v2115.json",
    "strategy_unified_contract_cycle_proof_v2111.json",
    "strategy_unified_contract_cycle_proof_v2113.json",
    "strategy_unified_contract_cycle_proof_v2114.json",
    "strategy_unified_contract_cycle_proof_v2115.json",
    "strategy_candidate_transport_status_v2114.json",
    "strategy_candidate_transport_status_v2115.json",
    "strategy_handoff_stage_status_v2115.json",
    "strategy_unified_contract_boot_v2111.json",
    "strategy_unified_contract_boot_v2113.json",
    "strategy_unified_contract_boot_v2114.json",
    "strategy_unified_contract_boot_v2115.json",
    "review_unified_structure_status_v2111.json",
    "review_unified_structure_status_v2113.json",
    "review_unified_structure_status_v2114.json",
    "review_unified_structure_status_v2115.json",
    "review_snapshot_writer_status_v2111.json",
    "review_snapshot_writer_status_v2113.json",
    "review_snapshot_writer_status_v2114.json",
    "review_snapshot_writer_status_v2115.json",
    "review_snapshot_boot_v2111.json",
    "review_snapshot_boot_v2113.json",
    "review_snapshot_boot_v2114.json",
    "review_snapshot_boot_v2115.json",
    "paper_unified_contract_owner_status_v2111.json",
    "paper_unified_contract_owner_status_v2112.json",
    "paper_unified_contract_owner_status_v2113.json",
    "paper_unified_contract_owner_status_v2114.json",
    "paper_unified_contract_owner_status_v2115.json",
)

LEGACY_CODE_FILES = (
    "coinbot_main_v2_13_2093.py",
    "coinbot_main_v2_13_2094.py",
    "coinbot_main_v2_13_2095.py",
    "coinbot_main_v2_13_2096.py",
    "coinbot_main_v2_13_2097.py",
    "paper_bot_v2.064.py",
    "paper_bot_v2.065.py",
    "paper_bot_v2.066.py",
    "paper_bot_v2.067.py",
    "paper_bot_v2.068.py",
    "strategy_worker_v2.031.py",
    "strategy_worker_v2.032.py",
    "strategy_worker_v2.033.py",
    "strategy_worker_v2.034.py",
    "review_worker_v2.040.py",
    "review_worker_v2.041.py",
    "review_worker_v2.042.py",
    "review_worker_v2.043.py",
)


def _json_default(value: Any) -> Any:
    if isinstance(value, Path):
        return str(value)
    return str(value)


def _json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=_json_default).encode("utf-8")


def _atomic_write_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{time.time_ns()}")
    with tmp.open("wb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def atomic_write_json(path: Path, obj: Any) -> None:
    _atomic_write_bytes(path, _json_bytes(obj))


def atomic_write_jsonl(path: Path, rows: Iterable[Mapping[str, Any]]) -> Tuple[int, int, int]:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f".tmp.{os.getpid()}.{time.time_ns()}")
    count = 0
    total = 0
    max_row = 0
    with tmp.open("wb") as handle:
        for row in rows:
            line = _json_bytes(dict(row)) + b"\n"
            handle.write(line)
            count += 1
            total += len(line)
            max_row = max(max_row, len(line.rstrip(b"\n")))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)
    return count, total, max_row


def read_json(path: Path, default: Any = None) -> Any:
    try:
        if not path.exists() or not path.is_file():
            return default
        return json.loads(path.read_text(encoding="utf-8", errors="strict"))
    except (OSError, json.JSONDecodeError, UnicodeError):
        return default


def read_jsonl(path: Path, limit: Optional[int] = None) -> List[Dict[str, Any]]:
    if not path.exists() or not path.is_file():
        return []
    rows: List[Dict[str, Any]] = []
    try:
        with path.open("r", encoding="utf-8") as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict):
                    rows.append(obj)
                    if limit is not None and len(rows) >= limit:
                        break
    except OSError:
        return []
    return rows


def _root(base_dir: Path) -> Path:
    return Path(base_dir) / ROOT_DIRNAME


def _commit_dir(base_dir: Path, commit_id: str) -> Path:
    return _root(base_dir) / "commits" / commit_id


def _contract(row: Mapping[str, Any]) -> Dict[str, Any]:
    value = row.get("unified_structure_contract_v2110")
    return dict(value) if isinstance(value, dict) else {}


def _stage(row: Mapping[str, Any]) -> str:
    for key in (
        "s_stage", "candidate_stage", "candidate_grade", "stage", "grade",
        "selected_s_stage_v510", "candidate_stage_v510", "final_stage_v510",
        "s_grade", "candidate_final_grade",
    ):
        value = str(row.get(key) or "").upper().strip()
        if value in {"S1", "S2", "S3"}:
            return value
    return "S3"


def _counts(rows: Iterable[Mapping[str, Any]]) -> Dict[str, Any]:
    rows_list = [r for r in rows if isinstance(r, Mapping)]
    stage_counts = {"S1": 0, "S2": 0, "S3": 0}
    contract_count = 0
    executable = 0
    for row in rows_list:
        stage_counts[_stage(row)] += 1
        contract = _contract(row)
        if contract:
            contract_count += 1
            if str(contract.get("final_state") or "").upper() == "EXECUTABLE":
                executable += 1
    return {
        "row_count": len(rows_list),
        "contract_count": contract_count,
        "contract_missing": max(0, len(rows_list) - contract_count),
        "coverage_pct": round(contract_count / len(rows_list) * 100.0, 2) if rows_list else 100.0,
        "stage_counts": stage_counts,
        "executable_contract_count": executable,
    }


@contextlib.contextmanager
def _lock(base_dir: Path):
    root = _root(base_dir)
    root.mkdir(parents=True, exist_ok=True)
    lock_path = root / LOCK_FILE
    with lock_path.open("a+b") as handle:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def cleanup_legacy_state(
    base_dir: Path,
    *,
    version: str,
    build: str,
    code_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Delete only the exact superseded v2111-v2115 transport artifacts.

    No glob is used for code or runtime state. Core trade/performance/change/issue
    and Shadow ledgers are never candidates for deletion.
    """
    base_dir = Path(base_dir)
    deleted: List[str] = []
    deleted_code: List[str] = []
    missing = 0
    errors: List[str] = []
    for name in LEGACY_STATE_FILES:
        path = base_dir / name
        try:
            if path.exists() and path.is_file():
                path.unlink()
                deleted.append(name)
            else:
                missing += 1
        except OSError as exc:
            errors.append(f"state/{name}: {type(exc).__name__}: {exc}")
    if code_dir is not None:
        code_root = Path(code_dir).resolve()
        for name in LEGACY_CODE_FILES:
            path = (code_root / name).resolve()
            try:
                if path.parent != code_root:
                    errors.append(f"code/{name}: unsafe path")
                    continue
                if path.exists() and path.is_file():
                    path.unlink()
                    deleted_code.append(name)
                else:
                    missing += 1
            except OSError as exc:
                errors.append(f"code/{name}: {type(exc).__name__}: {exc}")
    root = _root(base_dir)
    now = time.time()
    stale_tmp_deleted = 0
    if root.exists():
        for path in root.rglob("*.tmp.*"):
            try:
                if path.is_file() and now - path.stat().st_mtime > 600:
                    path.unlink()
                    stale_tmp_deleted += 1
            except OSError:
                pass
        commits_dir = root / "commits"
        if commits_dir.exists():
            for path in commits_dir.glob(".tmp.*"):
                try:
                    if path.is_dir() and now - path.stat().st_mtime > 600:
                        shutil.rmtree(path, ignore_errors=True)
                        stale_tmp_deleted += 1
                except OSError:
                    pass
    result = {
        "schema": "candidate_commit_cleanup_status_v2116",
        "version": version,
        "build": build,
        "updated_ts": now,
        "deleted_state_count": len(deleted),
        "deleted_state_files": deleted,
        "deleted_code_count": len(deleted_code),
        "deleted_code_files": deleted_code,
        "missing_count": missing,
        "stale_tmp_deleted": stale_tmp_deleted,
        "errors": errors,
        "protected": [
            "OPEN/CLOSED/trade_log/decision/exact ledgers",
            "change_verify/issue ledgers",
            "Shadow ledgers and generations",
            "canonical performance snapshots",
        ],
        "cleanup_scope": "exact v2111-v2115 candidate transport code/state allowlist only",
        "broad_disk_cleanup": False,
        "auto_buy": False,
    }
    atomic_write_json(base_dir / CLEANUP_FILE, result)
    return result


def _prune_commits(base_dir: Path, keep_ids: Iterable[str]) -> Dict[str, Any]:
    commits_dir = _root(base_dir) / "commits"
    keep = {str(x) for x in keep_ids if x}
    deleted: List[str] = []
    if not commits_dir.exists():
        return {"deleted": deleted}
    dirs = [p for p in commits_dir.iterdir() if p.is_dir() and not p.name.startswith(".tmp.")]
    dirs.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0.0, reverse=True)
    keep.update(p.name for p in dirs[:KEEP_COMMITS])
    for path in dirs:
        if path.name in keep:
            continue
        try:
            shutil.rmtree(path)
            deleted.append(path.name)
        except OSError:
            pass
    return {"deleted": deleted}


def validate_commit(base_dir: Path, commit_id: str) -> Dict[str, Any]:
    commit_id = str(commit_id or "").strip()
    if not commit_id:
        return {"state": "CHECK", "errors": ["commit_id missing"]}
    commit_dir = _commit_dir(Path(base_dir), commit_id)
    manifest = read_json(commit_dir / "manifest.json", {}) or {}
    hold = read_json(commit_dir / "s1_hold.json", {}) or {}
    rows = read_jsonl(commit_dir / "candidates.jsonl")
    errors: List[str] = []
    if not isinstance(manifest, dict) or manifest.get("candidate_commit_id") != commit_id:
        errors.append("manifest identity mismatch")
    declared = int(manifest.get("candidate_count") or 0) if isinstance(manifest, dict) else 0
    if declared != len(rows):
        errors.append(f"candidate count {declared}!={len(rows)}")
    hold_rows = hold.get("rows") if isinstance(hold, dict) and isinstance(hold.get("rows"), list) else []
    hold_declared = int(hold.get("row_count") or 0) if isinstance(hold, dict) else 0
    if hold_declared != len(hold_rows):
        errors.append(f"hold count {hold_declared}!={len(hold_rows)}")
    cycle_id = str(manifest.get("cycle_id") or "") if isinstance(manifest, dict) else ""
    for idx, row in enumerate(rows):
        if str(row.get("candidate_commit_id_v2116") or "") != commit_id:
            errors.append(f"candidate[{idx}] commit mismatch")
            break
        if str(row.get("candidate_pipeline_cycle_id_v1150") or "") != cycle_id:
            errors.append(f"candidate[{idx}] cycle mismatch")
            break
    for idx, row in enumerate(hold_rows):
        if not isinstance(row, dict):
            errors.append(f"hold[{idx}] not dict")
            break
        if str(row.get("candidate_commit_id_v2116") or "") != commit_id:
            errors.append(f"hold[{idx}] commit mismatch")
            break
        if str(row.get("candidate_pipeline_cycle_id_v1150") or "") != cycle_id:
            errors.append(f"hold[{idx}] cycle mismatch")
            break
    return {
        "state": "PASS" if not errors else "CHECK",
        "errors": errors,
        "candidate_count": len(rows),
        "hold_count": len(hold_rows),
        "cycle_id": cycle_id or None,
        "candidate_commit_id": commit_id,
    }


def publish_commit(
    *,
    base_dir: Path,
    cycle_id: str,
    full_rows: List[Dict[str, Any]],
    hold_rows: List[Dict[str, Any]],
    compact_builder: Callable[[Dict[str, Any]], Dict[str, Any]],
    version: str,
    build: str,
    now_ts: Optional[float] = None,
    candidate_alias: Optional[Path] = None,
    hold_alias: Optional[Path] = None,
) -> Dict[str, Any]:
    base_dir = Path(base_dir)
    cycle_id = str(cycle_id or "").strip()
    if not cycle_id:
        raise ValueError("candidate commit cycle_id missing")
    nowv = float(now_ts if now_ts is not None else time.time())
    source_rows = [dict(r) for r in full_rows if isinstance(r, dict)]
    source_hold = [dict(r) for r in hold_rows if isinstance(r, dict)]
    source_counts = _counts(source_rows)
    hold_counts = _counts(source_hold)
    if source_counts["contract_missing"]:
        raise RuntimeError(f"candidate contract missing before commit: {source_counts['contract_missing']}")
    if hold_counts["contract_missing"]:
        raise RuntimeError(f"S1 hold contract missing before commit: {hold_counts['contract_missing']}")

    compact_rows: List[Dict[str, Any]] = []
    for row in source_rows:
        compact = compact_builder(dict(row))
        if not isinstance(compact, dict):
            raise TypeError("compact_builder returned non-dict")
        compact_rows.append(compact)
    if len(compact_rows) != len(source_rows):
        raise RuntimeError(f"candidate compact mismatch {len(source_rows)}->{len(compact_rows)}")

    digest_seed = f"{cycle_id}|{len(source_rows)}|{len(source_hold)}|{nowv:.6f}".encode("utf-8")
    commit_id = f"candidate-{hashlib.sha256(digest_seed).hexdigest()[:20]}"
    root = _root(base_dir)
    commits_dir = root / "commits"
    final_dir = commits_dir / commit_id
    tmp_dir = commits_dir / f".tmp.{commit_id}.{os.getpid()}.{time.time_ns()}"

    with _lock(base_dir):
        commits_dir.mkdir(parents=True, exist_ok=True)
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir, ignore_errors=True)
        tmp_dir.mkdir(parents=True, exist_ok=False)
        for row in compact_rows:
            row["candidate_commit_id_v2116"] = commit_id
            row["candidate_pipeline_cycle_id_v1150"] = cycle_id
        for row in source_hold:
            row["candidate_commit_id_v2116"] = commit_id
            row["candidate_pipeline_cycle_id_v1150"] = cycle_id

        candidate_count, candidate_bytes, max_row_bytes = atomic_write_jsonl(tmp_dir / "candidates.jsonl", compact_rows)
        hold_payload = {
            "schema": "paper_s1_hold_cache_v2116",
            "version": version,
            "build": build,
            "updated_ts": nowv,
            "cycle_id": cycle_id,
            "candidate_commit_id": commit_id,
            "candidate_pipeline_cycle_id_v1150": cycle_id,
            "candidate_pipeline_cycle_consistent_v1150": True,
            "source_s1_count": len(source_hold),
            "row_count": len(source_hold),
            "rows": source_hold,
            "hold_ttl_sec": 120.0,
            "auto_buy": False,
        }
        atomic_write_json(tmp_dir / "s1_hold.json", hold_payload)
        manifest = {
            "schema": SCHEMA,
            "version": version,
            "build": build,
            "created_ts": nowv,
            "cycle_id": cycle_id,
            "candidate_commit_id": commit_id,
            "state": "COMMITTED",
            "candidate_file": "candidates.jsonl",
            "hold_file": "s1_hold.json",
            "candidate_count": candidate_count,
            "candidate_bytes": candidate_bytes,
            "candidate_max_row_bytes": max_row_bytes,
            "integrity_state": "PASS",
            "source_counts": source_counts,
            "hold_counts": hold_counts,
            "candidate_deleted": False,
            "candidate_threshold_relaxed": False,
            "buy_ready_forced": False,
            "auto_buy": False,
        }
        atomic_write_json(tmp_dir / "manifest.json", manifest)
        if final_dir.exists():
            shutil.rmtree(final_dir)
        os.replace(tmp_dir, final_dir)

        integrity = validate_commit(base_dir, commit_id)
        if integrity.get("state") != "PASS":
            raise RuntimeError("candidate commit integrity failed: " + "; ".join(integrity.get("errors") or []))
        if candidate_alias is not None:
            alias_count, _, _ = atomic_write_jsonl(Path(candidate_alias), compact_rows)
            if alias_count != candidate_count:
                raise RuntimeError(f"candidate compatibility mirror mismatch {candidate_count}->{alias_count}")
        if hold_alias is not None:
            atomic_write_json(Path(hold_alias), hold_payload)
            alias_hold = read_json(Path(hold_alias), {}) or {}
            if not isinstance(alias_hold, dict) or str(alias_hold.get("candidate_commit_id") or "") != commit_id:
                raise RuntimeError("hold compatibility mirror identity mismatch")

        pointer = {
            "schema": "candidate_commit_current_v2116",
            "version": version,
            "build": build,
            "updated_ts": nowv,
            "candidate_commit_id": commit_id,
            "cycle_id": cycle_id,
            "commit_dir": str(final_dir),
            "candidate_path": str(final_dir / "candidates.jsonl"),
            "hold_path": str(final_dir / "s1_hold.json"),
            "manifest_path": str(final_dir / "manifest.json"),
            "candidate_count": candidate_count,
            "hold_count": len(source_hold),
            "state": "CURRENT",
            "integrity_state": "PASS",
            "auto_buy": False,
        }
        atomic_write_json(base_dir / CURRENT_POINTER, pointer)
        atomic_write_json(base_dir / STATUS_FILE, {
            "schema": "candidate_commit_spine_status_v2116",
            "version": version,
            "build": build,
            "updated_ts": nowv,
            "current": pointer,
            "completed": read_json(base_dir / COMPLETED_POINTER, {}),
            "state": "CURRENT_COMMITTED",
            "auto_buy": False,
        })
        completed = read_json(base_dir / COMPLETED_POINTER, {}) or {}
        _prune_commits(base_dir, [commit_id, completed.get("candidate_commit_id") if isinstance(completed, dict) else ""])
    return {**manifest, "commit_dir": str(final_dir)}


def read_pointer(base_dir: Path, *, completed: bool = False) -> Dict[str, Any]:
    path = Path(base_dir) / (COMPLETED_POINTER if completed else CURRENT_POINTER)
    obj = read_json(path, {})
    return obj if isinstance(obj, dict) else {}


def read_commit(base_dir: Path, commit_id: Optional[str] = None, *, completed: bool = False) -> Dict[str, Any]:
    pointer = read_pointer(base_dir, completed=completed)
    selected = str(commit_id or pointer.get("candidate_commit_id") or "").strip()
    if not selected:
        return {"pointer": pointer, "manifest": {}, "candidates": [], "hold": {}, "paper_ack": {}, "review_ack": {}}
    commit_dir = _commit_dir(Path(base_dir), selected)
    manifest = read_json(commit_dir / "manifest.json", {}) or {}
    hold = read_json(commit_dir / "s1_hold.json", {}) or {}
    return {
        "pointer": pointer,
        "manifest": manifest if isinstance(manifest, dict) else {},
        "candidates": read_jsonl(commit_dir / "candidates.jsonl"),
        "hold": hold if isinstance(hold, dict) else {},
        "paper_ack": read_json(commit_dir / "paper_ack.json", {}) or {},
        "review_ack": read_json(commit_dir / "review_ack.json", {}) or {},
        "commit_dir": str(commit_dir),
    }


def _ack_valid(ack: Mapping[str, Any], manifest: Mapping[str, Any], role: str) -> bool:
    if not isinstance(ack, Mapping) or not isinstance(manifest, Mapping):
        return False
    if ack.get("role") != role or ack.get("state") != "PASS":
        return False
    if str(ack.get("candidate_commit_id") or "") != str(manifest.get("candidate_commit_id") or ""):
        return False
    if str(ack.get("cycle_id") or "") != str(manifest.get("cycle_id") or ""):
        return False
    return True


def write_ack(
    *,
    base_dir: Path,
    role: str,
    commit_id: str,
    state: str,
    version: str,
    build: str,
    details: Mapping[str, Any],
    now_ts: Optional[float] = None,
) -> Dict[str, Any]:
    if role not in {"paper", "review"}:
        raise ValueError("role must be paper or review")
    base_dir = Path(base_dir)
    nowv = float(now_ts if now_ts is not None else time.time())
    commit_id = str(commit_id or "").strip()
    if not commit_id:
        raise ValueError("ack commit_id missing")
    with _lock(base_dir):
        current = read_pointer(base_dir)
        commit = read_commit(base_dir, commit_id)
        manifest = commit.get("manifest") if isinstance(commit.get("manifest"), dict) else {}
        if not manifest:
            raise FileNotFoundError(f"candidate commit missing: {commit_id}")
        ack = {
            "schema": f"candidate_commit_{role}_ack_v2116",
            "role": role,
            "version": version,
            "build": build,
            "updated_ts": nowv,
            "candidate_commit_id": commit_id,
            "cycle_id": manifest.get("cycle_id"),
            "state": str(state).upper(),
            "is_current_commit": str(current.get("candidate_commit_id") or "") == commit_id,
            "details": dict(details),
            "auto_buy": False,
        }
        commit_dir = _commit_dir(base_dir, commit_id)
        atomic_write_json(commit_dir / f"{role}_ack.json", ack)
        paper_ack = ack if role == "paper" else read_json(commit_dir / "paper_ack.json", {}) or {}
        review_ack = ack if role == "review" else read_json(commit_dir / "review_ack.json", {}) or {}
        complete = _ack_valid(paper_ack, manifest, "paper") and _ack_valid(review_ack, manifest, "review")
        if complete:
            existing_completed = read_json(base_dir / COMPLETED_POINTER, {}) or {}
            existing_created = float(existing_completed.get("commit_created_ts") or 0.0) if isinstance(existing_completed, dict) else 0.0
            this_created = float(manifest.get("created_ts") or 0.0)
            if this_created >= existing_created:
                completed_pointer = {
                    "schema": "candidate_commit_completed_v2116",
                    "version": version,
                    "build": build,
                    "updated_ts": nowv,
                    "commit_created_ts": this_created,
                    "candidate_commit_id": commit_id,
                    "cycle_id": manifest.get("cycle_id"),
                    "candidate_count": manifest.get("candidate_count"),
                    "hold_count": (manifest.get("hold_counts") or {}).get("row_count") if isinstance(manifest.get("hold_counts"), dict) else None,
                    "paper_ack_ts": paper_ack.get("updated_ts"),
                    "review_ack_ts": review_ack.get("updated_ts"),
                    "state": "PASS",
                    "auto_buy": False,
                }
                atomic_write_json(base_dir / COMPLETED_POINTER, completed_pointer)
        status = {
            "schema": "candidate_commit_spine_status_v2116",
            "version": version,
            "build": build,
            "updated_ts": nowv,
            "current": current,
            "completed": read_json(base_dir / COMPLETED_POINTER, {}),
            "paper_ack": paper_ack,
            "review_ack": review_ack,
            "state": "COMPLETE" if complete else "WAITING_ACK",
            "auto_buy": False,
        }
        atomic_write_json(base_dir / STATUS_FILE, status)
    return ack


def status_model(base_dir: Path, *, freshness_sec: float = 180.0) -> Dict[str, Any]:
    nowv = time.time()
    current = read_pointer(base_dir)
    completed = read_pointer(base_dir, completed=True)
    current_id = str(current.get("candidate_commit_id") or "")
    commit = read_commit(base_dir, current_id) if current_id else {}
    manifest = commit.get("manifest") if isinstance(commit.get("manifest"), dict) else {}
    paper_ack = commit.get("paper_ack") if isinstance(commit.get("paper_ack"), dict) else {}
    review_ack = commit.get("review_ack") if isinstance(commit.get("review_ack"), dict) else {}
    current_age = max(0.0, nowv - float(current.get("updated_ts") or 0.0)) if current.get("updated_ts") else None
    completed_age = max(0.0, nowv - float(completed.get("updated_ts") or 0.0)) if completed.get("updated_ts") else None
    current_complete = bool(
        current_id
        and str(completed.get("candidate_commit_id") or "") == current_id
        and completed.get("state") == "PASS"
        and _ack_valid(paper_ack, manifest, "paper")
        and _ack_valid(review_ack, manifest, "review")
    )
    return {
        "schema": "candidate_commit_spine_model_v2116",
        "current": current,
        "completed": completed,
        "manifest": manifest,
        "paper_ack": paper_ack,
        "review_ack": review_ack,
        "current_age_sec": current_age,
        "completed_age_sec": completed_age,
        "current_fresh": current_age is not None and current_age <= freshness_sec,
        "current_complete": current_complete,
        "ready": current_complete and current_age is not None and current_age <= freshness_sec,
        "auto_buy": False,
    }
