from __future__ import annotations

import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def load_module(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def test_strategy_zero_trigger_is_fail_closed_without_cycle_abort():
    strategy = load_module("strategy_v1259_test", "strategy_worker_v1.061.py")
    result = strategy._v1229_select_coherent_structure_pair(
        [],
        [],
        price=100.0,
        trigger_price=0.0,
        invalid_buffer_pct=0.1,
        reach_limit_pct=10.0,
        minimum_target_room_pct=1.2,
        estimated_roundtrip_cost_pct=0.1,
        cost_complete=True,
    )
    assert result["selection_mode"] == "trigger_price_missing_no_pair"
    assert result["intermediate_count"] == 0
    assert strategy.VERSION == "strategy_worker_v1.061"
    assert strategy.BUILD_LABEL.startswith("v1259_")


def test_version_score_icons_and_result_interpretation():
    main = load_module("main_v1259_test", "coinbot_main_v2_13_1161.py")
    windows = {
        "recent_3h": {"count": 10, "wins": 6, "losses": 4, "sum_pct": 1.2, "avg_pct": 0.12},
        "recent_6h": {"count": 20, "wins": 9, "losses": 11, "sum_pct": -2.4, "avg_pct": -0.12},
        "recent_12h": {"count": 30, "wins": 15, "losses": 15, "sum_pct": 0.0, "avg_pct": 0.0},
        "recent_24h": {"count": 40, "wins": 18, "losses": 22, "sum_pct": -3.0, "avg_pct": -0.075},
        "today": {"count": 40, "wins": 18, "losses": 22, "sum_pct": -3.0, "avg_pct": -0.075},
        "all": {"count": 100, "wins": 45, "losses": 55, "sum_pct": -10.0, "avg_pct": -0.1},
    }
    fresh = {"count": 12, "wins": 7, "losses": 5, "sum_pct": 0.5, "avg_pct": 0.0417}
    book = {
        "fresh_closed": fresh,
        "current_open": {"count": 3, "wins": 1, "losses": 2, "sum_pct": -0.8, "avg_pct": -0.2667},
        "combined": {"count": 15, "wins": 8, "losses": 7, "sum_pct": -0.3, "avg_pct": -0.02},
    }
    reasons = {
        "swing_trailing": {"count": 4, "wins": 4, "losses": 0, "sum_pct": 8.0, "avg_pct": 2.0},
        "structure_invalid": {"count": 3, "wins": 0, "losses": 3, "sum_pct": -9.0, "avg_pct": -3.0},
    }
    snap = {"snapshot_id": "test", "source_owner": "paper", "counts": {"raw_ledger_rows": 1, "exact_unique_closed": 1}}
    main._performance_snapshot = lambda: snap
    main.file_age = lambda _path: 1.0
    main._window_stat = lambda _snap, key: windows.get(key, {})
    main._fresh_epoch = lambda _snap: fresh
    main._book_map = lambda _snap: book
    main._recent_diag = lambda _snap: {"primary_exit_reason": reasons}
    main._paper_status = lambda: {"unified_strategy_v1257": {"contracted_open": 0, "existing_open_contracts_preserved": 3}}

    text = main.render_version_score()
    assert "✅ 최근 3시간" in text
    assert "❌ 최근 6시간" in text
    assert "➖ 최근 12시간" in text
    assert "[결과 해석]" in text
    assert "손실 핵심: structure_invalid" in text
    assert "신규 OPEN 0개" in text
    assert main.BOT_VERSION == "수익형 v2.13.1161"
    assert main.BUILD_LABEL.startswith("v1259_")
