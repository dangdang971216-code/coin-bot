코인봇 v1259

현재 문제
- Strategy가 trigger_price=0 행에서 ZeroDivisionError로 현재 cycle writer를 멈춤
- /version_score의 초록/빨강 표시가 사라지고 결과 해석이 없음

수정
- 해당 후보만 구조계약 미완성으로 fail-closed 처리하고 전체 cycle 저장은 계속
- 비용 후 합산손익 기준 ✅/❌/➖/🟡 복구
- 같은 canonical snapshot으로 수익 핵심·손실 핵심·손익 구조·새 계약 진행상태 설명

변경 안 함
- 후보식, S1, 점수순, trigger, invalid, target, RR, 진입, 청산 수치, 기존 OPEN, 원장, 자동매수 OFF

판정
- 로컬 DONE / 서버 CHECK_PENDING_APPLY
