# v1087 canonical operations maps

## Scope

v1087 adds operational visibility only.

- Guard is the sole collector and snapshot writer.
- Main is a read-only renderer.
- One current snapshot powers five commands.
- No worker or Paper execution code is changed.
- No automatic repair, cleanup, deletion or restart exists.

## Canonical flow

```text
systemd / deployed marker / active source / status /proc / files
                            |
                            v
                 Guard collector (one owner)
                            |
                            v
                ops_map_snapshot_v1087.json
                            |
        +----------+---------+----------+----------+
        |          |         |          |          |
    /code_map /system_map /resource_map /ledger_map /ops_map
                    Main read-only views
```

## Code map

Evidence priority:

1. deployed marker
2. exact active-source hash match
3. UNKNOWN when evidence is absent or ambiguous

It never chooses the numerically highest source as the deployed target.
It reports duplicate definitions, simple wrapper candidates, fallback/legacy references,
version-numbered active functions and static dead candidates. These are audit candidates only.

## System map

Displays service state, MainPID, source sync, status age and cycle time for:

- Main, Guard, Paper
- Scanner, Candle, Market, Feature, Orderflow
- Target Router, Strategy, Risk, Review
- WebSocket and Micro

## Resource map

Displays per-process CPU, RSS, read/write I/O and open FD count plus server disk usage.
CPU and I/O rates require a previous sample; the first sample is UNKNOWN.

## Ledger map

Displays protected core ledgers and large/open state files with:

- current size
- growth since previous sample
- mtime age
- bounded line count when the file is small enough
- current open-file and write-mode evidence
- active source references

Protected core ledgers are never classified as automatic deletion candidates.

## Bounded overhead

- Static AST audit is cached by active source hash.
- Full static audit runs only when the active source hash changes.
- Current snapshot is atomic replace.
- History appends only on section status change or hourly heartbeat.
- No fallback cache is used by Main.

## Server verification

Run `/gops_refresh`, then all five Main map commands.
The map infrastructure can be DONE even when maps report findings; findings are the output,
not a failure of the map writer itself.
