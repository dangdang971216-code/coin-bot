코인봇 v2211

1. 후보 품질
   - v2210의 장기 흐름 2/3 하드보류를 해제한다.
   - 단일 양수·음수나 가족 수로 후보를 자르지 않는다.
   - 현재 신규 배제조건은 0개다.
   - 수익 CLOSED와 손실 CLOSED에서 반복되는 복합 조합을 /trade_review에 비교한다.
   - 손실군 반복, 수익군 훼손 적음, 표본 충분을 모두 만족한 조합만 사용자 승인 뒤 한 개씩 적용한다.

2. Review 오류
   - 같은 PID temp 파일을 두 thread가 공유해 os.replace FileNotFoundError가 난 원인을 수리한다.
   - 공통 잠금과 PID+thread+time 고유 temp를 사용한다.
   - 최종 canonical status 파일과 원장은 그대로 유지한다.

3. 임시 -2% 손실방어
   - 비용 포함 순손익 -2.0%를 현재/이전/구형 exact OPEN 모든 세대에 적용한다.
   - target 우선, 원래 구조 invalid 보존, 새 trigger+새 decision key 재진입 계약 유지.
   - 실제 sweep 검사·청산·-2% 이하 잔존 건수를 상태판에 표시한다.

4. 변경하지 않음
   - 상승예측 가중치와 양수 점수선
   - 구조 trigger/invalid/target/RR 수치
   - 과거 OPEN/CLOSED/decision/exact 원장과 성과 초기화
   - 새 Shadow·새 명령·후보 개수 제한
   - 자동매수 OFF

로컬 검수 PASS / 서버 적용·결과 검수 CHECK.
