coinbot_update_v1603

목적:
- v1602에서 드러난 trigger/invalid/target 값 전달 누락 수리
- Strategy가 이미 가진 구조재료를 S1/Paper handoff row에 봉인
- 자료가 없으면 계속 DATA_PIPELINE 문제로 표시, 후보 품질 실패로 보지 않음

변경 없음:
- 후보 기준, Gate, rank, TTL, RR, trigger/invalid/target 공식, spread/slippage 기준, 청산, OPEN 제한, 자동매수 OFF

검수:
- /data_pipeline
- /candidate_standard
- /flow_map_full
- /errorlog
