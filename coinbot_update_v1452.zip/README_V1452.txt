v1452 display-only: compact /shadow_board and full compact /popen. No trading-rule change. Auto-buy OFF.
