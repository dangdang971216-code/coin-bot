from __future__ import annotations

import hashlib
import json
import math
import statistics
import time
from collections import Counter
from typing import Any, Dict, Iterable, List, Optional, Tuple

VERSION = "strategy_v2_core_v2190"
BUILD_LABEL = "rise_prediction_clean_baseline_2026-07-31"
GENERATION = "ALT_SWING_V2_COMBINED_V2149_RESET_20260722"
PREDICTION_MODEL_GENERATION = "RISE_INPUT_BASELINE_COLLECT"

REQUIRED_ROWS = {"m5": 48, "m15": 32, "m30": 48, "h1": 48, "h2": 32, "h4": 20}
TF_WEIGHT = {"m5": 1.0, "m15": 1.5, "m30": 2.1, "h1": 2.9, "h2": 4.0, "h4": 5.0}
RISE_MATERIAL_NAMES = (
    "return_30m_atr_adjusted",
    "price_acceleration_30m",
    "price_acceleration_1h",
    "relative_strength_1h",
    "relative_strength_acceleration_1h",
    "turnover_growth_recent1h_vs_prior3h",
    "turnover_acceleration_30m",
    "higher_low_strength_atr",
    "pullback_recovery_ratio",
    "target_path_consumed_ratio",
    "btc_price_acceleration_1h",
    "market_breadth_change",
    "market_liquidity_state",
)

def _num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or isinstance(value, bool):
            return default
        out = float(value)
        return out if math.isfinite(out) else default
    except Exception:
        return default

def _clip(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))

def _median(values: Iterable[float], default: float = 0.0) -> float:
    vals = [float(x) for x in values if _num(x) is not None]
    return float(statistics.median(vals)) if vals else float(default)

def _ema(values: List[float], period: int) -> Optional[float]:
    clean = [float(x) for x in values if _num(x) is not None]
    if len(clean) < max(2, period):
        return None
    alpha = 2.0 / (float(period) + 1.0)
    value = sum(clean[:period]) / float(period)
    for item in clean[period:]:
        value = alpha * item + (1.0 - alpha) * value
    return value

def _atr(rows: List[Dict[str, float]], period: int = 14) -> float:
    if len(rows) < 2:
        return 0.0
    trs: List[float] = []
    prev: Optional[float] = None
    for row in rows[-max(period * 4, 48):]:
        high = float(row.get("h") or 0.0)
        low = float(row.get("l") or 0.0)
        close = float(row.get("c") or 0.0)
        if min(high, low, close) <= 0:
            continue
        tr = high - low if prev is None else max(high - low, abs(high - prev), abs(low - prev))
        trs.append(max(0.0, tr))
        prev = close
    if not trs:
        return 0.0
    seed = min(period, len(trs))
    value = sum(trs[:seed]) / seed
    for tr in trs[seed:]:
        value = ((period - 1.0) * value + tr) / period
    return max(0.0, value)

def _pivots(rows: List[Dict[str, float]], side: str, window: int) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    if len(rows) < window * 2 + 3:
        return out
    for idx in range(window, len(rows) - window):
        row = rows[idx]
        value = float(row["l"] if side == "low" else row["h"])
        peers = [float(rows[j]["l"] if side == "low" else rows[j]["h"]) for j in range(idx - window, idx + window + 1) if j != idx]
        confirmed = value < min(peers) if side == "low" else value > max(peers)
        if confirmed:
            out.append({"price": value, "ts": float(row["ts"]), "index": idx, "side": side})
    return out

def _cluster_levels(levels: List[Dict[str, Any]], *, atr_ref: float, current: float) -> List[Dict[str, Any]]:
    clean = [dict(x) for x in levels if (_num(x.get("price"), 0.0) or 0.0) > 0]
    clean.sort(key=lambda x: float(x["price"]))
    groups: List[List[Dict[str, Any]]] = []
    tolerance = max(atr_ref * 0.22, current * 0.0012)
    for item in clean:
        price = float(item["price"])
        if groups:
            center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in groups[-1]) / max(1e-12, sum(float(x.get("weight") or 1.0) for x in groups[-1]))
            if abs(price - center) <= tolerance:
                groups[-1].append(item)
                continue
        groups.append([item])
    out: List[Dict[str, Any]] = []
    for group in groups:
        weight_sum = sum(float(x.get("weight") or 1.0) for x in group)
        center = sum(float(x["price"]) * float(x.get("weight") or 1.0) for x in group) / max(weight_sum, 1e-12)
        out.append({
            "price": center,
            "low": min(float(x["price"]) for x in group) - tolerance * 0.35,
            "high": max(float(x["price"]) for x in group) + tolerance * 0.35,
            "score": weight_sum + min(3.0, len({str(x.get("tf")) for x in group})) * 0.5,
            "source_count": len(group),
            "timeframes": sorted({str(x.get("tf")) for x in group}),
            "last_source_ts": max(float(x.get("ts") or 0.0) for x in group),
        })
    return out

def _level_candidates(frames: Dict[str, List[Dict[str, float]]], tfs: Tuple[str, ...], side: str) -> List[Dict[str, Any]]:
    levels: List[Dict[str, Any]] = []
    for tf in tfs:
        rows = frames.get(tf) or []
        window = 2 if tf in {"m5", "m15"} else 3
        for item in _pivots(rows[-120:], "low" if side == "support" else "high", window):
            item["tf"] = tf
            item["weight"] = TF_WEIGHT.get(tf, 1.0)
            levels.append(item)
    return levels

def _trend_axis(rows: List[Dict[str, float]]) -> Optional[float]:
    closes = [float(r["c"]) for r in rows if float(r.get("c") or 0.0) > 0]
    if len(closes) < 24:
        return None
    fast = _ema(closes, 8)
    slow = _ema(closes, 21)
    prior_fast = _ema(closes[:-3], 8) if len(closes) >= 27 else None
    if fast is None or slow is None or prior_fast is None or slow <= 0:
        return None
    spread = (fast - slow) / slow * 100.0
    slope = (fast - prior_fast) / max(abs(prior_fast), 1e-12) * 100.0
    return _clip(spread * 2.8 + slope * 5.0, -1.0, 1.0)

def _row_price(row: Dict[str, Any]) -> Optional[float]:
    for obj in (row, row.get("raw") if isinstance(row.get("raw"), dict) else {}, row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}):
        if not isinstance(obj, dict):
            continue
        for key in ("current_price", "trade_price", "price", "last_price", "close", "entry_price"):
            value = _num(obj.get(key))
            if value is not None and value > 0:
                return value
    return None

def _nested(row: Dict[str, Any], *keys: str) -> Dict[str, Any]:
    for key in keys:
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}

def _plan_hash(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:20]

def _return_pct(rows: List[Dict[str, float]], bars: int, end_offset: int = 0) -> Optional[float]:
    if bars <= 0 or len(rows) < bars + 1 + end_offset:
        return None
    end_index = len(rows) - 1 - end_offset
    start_index = end_index - bars
    start = _num(rows[start_index].get("c"))
    end = _num(rows[end_index].get("c"))
    if start is None or end is None or start <= 0:
        return None
    return (end / start - 1.0) * 100.0


def _bar_turnover(row: Dict[str, float]) -> Optional[float]:
    close = _num(row.get("c"))
    volume = _num(row.get("v"))
    if close is None or volume is None or close <= 0 or volume < 0:
        return None
    return close * volume


def _avg_turnover(rows: List[Dict[str, float]]) -> Optional[float]:
    values = [_bar_turnover(row) for row in rows]
    ready = [float(value) for value in values if value is not None]
    return sum(ready) / len(ready) if ready else None


def _frame_state(rows: List[Dict[str, float]], need: int, nowv: float, frame_sec: float) -> Dict[str, Any]:
    count = len(rows)
    latest = _num(rows[-1].get("ts")) if rows else None
    age = max(0.0, nowv - (latest + frame_sec)) if latest is not None else None
    if count < need:
        state = "MISSING"
    elif age is not None and age > frame_sec * 2.25:
        state = "STALE"
    else:
        state = "READY"
    return {"state": state, "count": count, "required": need, "last_completed_ts": latest, "age_sec": round(age, 3) if age is not None else None}


def _material(name: str, value: Any, owner: str, source: str, state: str, raw: Any = None) -> Dict[str, Any]:
    numeric = _num(value)
    return {
        "name": name,
        "value": round(numeric, 8) if numeric is not None else value if isinstance(value, (str, dict, list)) else None,
        "raw": raw,
        "owner": owner,
        "source": source,
        "state": state if state in {"READY", "STALE", "MISSING"} else "MISSING",
        "used_as_gate": False,
        "zero_filled": False,
    }


def _source_state(*states: str) -> str:
    values = [str(value or "MISSING") for value in states]
    if any(value == "MISSING" for value in values):
        return "MISSING"
    if any(value == "STALE" for value in values):
        return "STALE"
    return "READY"


def _latest_confirmed_swing_low(rows: List[Dict[str, float]]) -> Dict[str, Any]:
    lows = _pivots(rows[-80:], "low", 2)
    if not lows:
        return {"state": "MISSING", "price": None, "ts": None}
    item = lows[-1]
    return {"state": "READY", "price": _num(item.get("price")), "ts": _num(item.get("ts"))}


def _market_context(row: Dict[str, Any]) -> Dict[str, Any]:
    for key in ("global_market_context_v2130", "market_context_v2130"):
        value = row.get(key)
        if isinstance(value, dict):
            return value
    return {}


def build_rise_prediction_input(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], structure: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    m30 = list(frames.get("m30") or [])
    h1 = list(frames.get("h1") or [])
    benchmark_source = row.get("prediction_benchmark_candles") if isinstance(row.get("prediction_benchmark_candles"), dict) else {}
    benchmark_frames_raw = benchmark_source.get("frames") if isinstance(benchmark_source.get("frames"), dict) else benchmark_source
    benchmark_frames: Dict[str, List[Dict[str, float]]] = {}
    for tf, rows in (benchmark_frames_raw or {}).items():
        if not isinstance(rows, list):
            continue
        normalized = []
        for item in rows:
            if isinstance(item, dict):
                ts = _num(item.get("ts")); op = _num(item.get("o")); cl = _num(item.get("c")); hi = _num(item.get("h")); lo = _num(item.get("l")); vol = _num(item.get("v"), 0.0)
            elif isinstance(item, (list, tuple)) and len(item) >= 6:
                ts, op, cl, hi, lo, vol = (_num(item[0]), _num(item[1]), _num(item[2]), _num(item[3]), _num(item[4]), _num(item[5], 0.0))
            else:
                continue
            if None in (ts, op, cl, hi, lo) or min(float(op), float(cl), float(hi), float(lo)) <= 0:
                continue
            normalized.append({"ts": float(ts), "o": float(op), "c": float(cl), "h": float(hi), "l": float(lo), "v": max(0.0, float(vol or 0.0))})
        normalized.sort(key=lambda item: item["ts"])
        benchmark_frames[str(tf)] = normalized
    btc_h1 = list(benchmark_frames.get("h1") or [])

    states = {
        "m30": _frame_state(m30, 8, nowv, 1800.0),
        "h1": _frame_state(h1, 16, nowv, 3600.0),
        "btc_h1": _frame_state(btc_h1, 4, nowv, 3600.0),
    }
    current = _row_price(row)
    atr1h = _atr(h1, 14) if h1 else 0.0
    atr1h_pct = (atr1h / current * 100.0) if current and current > 0 and atr1h > 0 else None

    ret30 = _return_pct(m30, 1)
    prior30 = _return_pct(m30, 1, 1)
    ret1h = _return_pct(h1, 1)
    prior1h = _return_pct(h1, 1, 1)
    btc1h = _return_pct(btc_h1, 1)
    btc_prior1h = _return_pct(btc_h1, 1, 1)

    recent1h_turn = _avg_turnover(h1[-1:]) if len(h1) >= 1 else None
    prior3h_turn = _avg_turnover(h1[-4:-1]) if len(h1) >= 4 else None
    recent30_turn = _avg_turnover(m30[-1:]) if len(m30) >= 1 else None
    prior30_turn = _avg_turnover(m30[-2:-1]) if len(m30) >= 2 else None

    swing = _latest_confirmed_swing_low(m30)
    previous_swings = _pivots(m30[-80:], "low", 2)
    prior_swing_price = _num(previous_swings[-2].get("price")) if len(previous_swings) >= 2 else None
    current_swing_price = _num(swing.get("price"))
    higher_low = ((current_swing_price - prior_swing_price) / max(atr1h, 1e-12)) if current_swing_price is not None and prior_swing_price is not None and atr1h > 0 else None

    recent_highs = _pivots(m30[-80:], "high", 2)
    prior_high = _num(recent_highs[-1].get("price")) if recent_highs else None
    pullback_recovery = None
    if current is not None and current_swing_price is not None and prior_high is not None and prior_high > current_swing_price:
        pullback_recovery = (current - current_swing_price) / (prior_high - current_swing_price)

    target_consumed = _num(structure.get("entry_fraction_to_t1"))
    market = _market_context(row)
    breadth_change = _num(market.get("breadth_velocity_pct_v2130"))
    market_age = None
    market_updated = _num(market.get("updated_ts"))
    if market_updated is not None:
        market_age = max(0.0, nowv - market_updated)
    market_state = "MISSING" if not market else ("STALE" if market_age is not None and market_age > 300.0 else "READY")
    liquidity_raw = {
        "turnover_concentration_top10_pct": _num(market.get("turnover_concentration_top10_pct_v2130")),
        "turnover_concentration_velocity": _num(market.get("turnover_concentration_velocity_v2130")),
        "market_change_dispersion_pct": _num(market.get("market_change_dispersion_pct_v2155")),
        "risk_state": market.get("risk_state_v2130"),
        "context_state": market.get("state"),
    }

    material_rows: Dict[str, Dict[str, Any]] = {}
    material_rows["return_30m_atr_adjusted"] = _material(
        "return_30m_atr_adjusted",
        (ret30 / atr1h_pct) if ret30 is not None and atr1h_pct and atr1h_pct > 0 else None,
        "candle_worker", "completed m30 return / h1 ATR%", _source_state(states["m30"]["state"], states["h1"]["state"]),
        {"return_30m_pct": ret30, "atr_1h_pct": atr1h_pct},
    )
    material_rows["price_acceleration_30m"] = _material(
        "price_acceleration_30m", (ret30 - prior30) if ret30 is not None and prior30 is not None else None,
        "candle_worker", "recent completed 30m return - prior completed 30m return", states["m30"]["state"],
        {"recent_30m_pct": ret30, "prior_30m_pct": prior30},
    )
    material_rows["price_acceleration_1h"] = _material(
        "price_acceleration_1h", (ret1h - prior1h) if ret1h is not None and prior1h is not None else None,
        "candle_worker", "recent completed 1h return - prior completed 1h return", states["h1"]["state"],
        {"recent_1h_pct": ret1h, "prior_1h_pct": prior1h},
    )
    rs1h = (ret1h - btc1h) if ret1h is not None and btc1h is not None else None
    prior_rs1h = (prior1h - btc_prior1h) if prior1h is not None and btc_prior1h is not None else None
    rs_state = _source_state(states["h1"]["state"], states["btc_h1"]["state"])
    material_rows["relative_strength_1h"] = _material(
        "relative_strength_1h", rs1h, "strategy_v2_core", "ticker completed h1 return - BTC completed h1 return", rs_state,
        {"ticker_1h_pct": ret1h, "btc_1h_pct": btc1h},
    )
    material_rows["relative_strength_acceleration_1h"] = _material(
        "relative_strength_acceleration_1h", (rs1h - prior_rs1h) if rs1h is not None and prior_rs1h is not None else None,
        "strategy_v2_core", "current 1h relative strength - prior 1h relative strength", rs_state,
        {"current_rs_1h": rs1h, "prior_rs_1h": prior_rs1h},
    )
    material_rows["turnover_growth_recent1h_vs_prior3h"] = _material(
        "turnover_growth_recent1h_vs_prior3h",
        ((recent1h_turn / prior3h_turn) - 1.0) * 100.0 if recent1h_turn is not None and prior3h_turn and prior3h_turn > 0 else None,
        "candle_worker", "completed OHLCV close*volume recent 1h vs prior 3h hourly average", states["h1"]["state"],
        {"recent_1h_turnover_proxy": recent1h_turn, "prior_3h_hourly_avg_proxy": prior3h_turn},
    )
    material_rows["turnover_acceleration_30m"] = _material(
        "turnover_acceleration_30m",
        ((recent30_turn / prior30_turn) - 1.0) * 100.0 if recent30_turn is not None and prior30_turn and prior30_turn > 0 else None,
        "candle_worker", "completed OHLCV close*volume recent 30m vs prior 30m", states["m30"]["state"],
        {"recent_30m_turnover_proxy": recent30_turn, "prior_30m_turnover_proxy": prior30_turn},
    )
    material_rows["higher_low_strength_atr"] = _material(
        "higher_low_strength_atr", higher_low, "strategy_v2_core", "latest two confirmed m30 swing lows / h1 ATR", _source_state(states["m30"]["state"], states["h1"]["state"]),
        {"latest_swing_low": current_swing_price, "prior_swing_low": prior_swing_price, "atr_1h": atr1h},
    )
    material_rows["pullback_recovery_ratio"] = _material(
        "pullback_recovery_ratio", pullback_recovery, "strategy_v2_core", "current recovery between latest confirmed m30 swing low and prior confirmed high", states["m30"]["state"],
        {"current_price": current, "swing_low": current_swing_price, "prior_swing_high": prior_high},
    )
    material_rows["target_path_consumed_ratio"] = _material(
        "target_path_consumed_ratio", target_consumed, "strategy_v2_core", "existing dynamic trigger-to-target path consumption", "READY" if target_consumed is not None else "MISSING",
        {"entry_fraction_to_t1": target_consumed},
    )
    material_rows["btc_price_acceleration_1h"] = _material(
        "btc_price_acceleration_1h", (btc1h - btc_prior1h) if btc1h is not None and btc_prior1h is not None else None,
        "candle_worker", "BTC recent completed 1h return - prior completed 1h return", states["btc_h1"]["state"],
        {"recent_btc_1h_pct": btc1h, "prior_btc_1h_pct": btc_prior1h},
    )
    material_rows["market_breadth_change"] = _material(
        "market_breadth_change", breadth_change, "market_regime_worker", "breadth_velocity_pct_v2130", market_state,
        {"breadth_up_pct": _num(market.get("breadth_up_pct")), "breadth_change": breadth_change, "age_sec": market_age},
    )
    material_rows["market_liquidity_state"] = _material(
        "market_liquidity_state", liquidity_raw, "market_regime_worker", "turnover concentration + concentration velocity + market dispersion + risk state", market_state, liquidity_raw,
    )

    # Missing values remain missing even when the source frame itself exists.
    for item in material_rows.values():
        if item.get("state") == "READY" and item.get("value") is None:
            item["state"] = "MISSING"
    state_counts = Counter(str(item.get("state") or "MISSING") for item in material_rows.values())
    ready_count = state_counts.get("READY", 0)
    latest_m30_ts = _num(m30[-1].get("ts")) if m30 else None
    event_bar_close_ts = latest_m30_ts + 1800.0 if latest_m30_ts is not None else None
    episode_low_ts = _num(swing.get("ts"))
    episode_id = f"{ticker}:{int(episode_low_ts)}" if ticker and episode_low_ts is not None else None
    event_key = f"{ticker}:{int(event_bar_close_ts)}" if ticker and event_bar_close_ts is not None else None
    event_price = _num(m30[-1].get("c")) if m30 else current
    pre_signal_rise_pct = None
    if event_price is not None and current_swing_price is not None and current_swing_price > 0:
        pre_signal_rise_pct = (event_price / current_swing_price - 1.0) * 100.0
    values = {name: material_rows[name].get("value") for name in RISE_MATERIAL_NAMES}
    return {
        "schema": "rise_prediction_input",
        "state": "READY" if ready_count == len(RISE_MATERIAL_NAMES) else ("PARTIAL" if ready_count else "MISSING"),
        "owner": "strategy_v2_core",
        "ticker": ticker,
        "event_key": event_key,
        "event_bar_close_ts": event_bar_close_ts,
        "event_price": round(event_price, 12) if event_price is not None else None,
        "episode_id": episode_id,
        "episode_low_ts": episode_low_ts,
        "episode_low_price": current_swing_price,
        "pre_signal_rise_pct": round(pre_signal_rise_pct, 8) if pre_signal_rise_pct is not None else None,
        "materials": material_rows,
        "material_values": values,
        "material_names": list(RISE_MATERIAL_NAMES),
        "source_state_counts": dict(state_counts),
        "input_coverage_pct": round(ready_count / len(RISE_MATERIAL_NAMES) * 100.0, 3),
        "probability_3h": None,
        "probability_6h": None,
        "giveback_risk": None,
        "late_capture_risk": None,
        "model_state": "BASELINE_COLLECTING",
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": False,
        "candidate_preserved": True,
        "zero_fill_used": False,
        "auto_buy": False,
    }


def _prediction(row: Dict[str, Any], structure: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]]) -> Dict[str, Any]:
    nowv = _num(row.get("prediction_owner_meta_v2155", {}).get("strategy_cycle_ts") if isinstance(row.get("prediction_owner_meta_v2155"), dict) else None, time.time()) or time.time()
    payload = build_rise_prediction_input(row, frames, structure, nowv)
    return {
        "schema": "rise_prediction_observation",
        "state": "BASELINE_COLLECTING",
        "prediction_model_generation": PREDICTION_MODEL_GENERATION,
        "rise_prediction_input": payload,
        "materials": payload.get("materials"),
        "material_values": payload.get("material_values"),
        "input_coverage_pct": payload.get("input_coverage_pct"),
        "probability_3h": None,
        "probability_6h": None,
        "giveback_risk": None,
        "late_capture_risk": None,
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_in_final_decision": False,
        "decision_reason": "새 상승예측 재료 수집 중 · 상승예측은 후보 통과/보류에 사용하지 않음",
        "candidate_preserved": True,
        "auto_buy": False,
    }


def _combine_structure_prediction(structure: Dict[str, Any], prediction: Dict[str, Any]) -> Dict[str, Any]:
    structure_state = str(structure.get("state") or "DATA_MISSING")
    if structure_state == "STRUCTURE_READY":
        state = "ENTRY_READY"
        eligible = True
        reason = "기존 동적 trigger·invalid·target 구조 준비 완료 · 새 상승예측은 관찰만"
    else:
        state = structure_state
        eligible = False
        reason = f"구조 상태 {structure_state} · 상승예측 관찰은 후보를 차단하지 않음"
    return {
        "schema": "structure_execution_combiner",
        "state": state,
        "entry_eligible": eligible,
        "owner": "strategy_v2_core.structure",
        "reason": reason,
        "structure_state": structure_state,
        "prediction_state": prediction.get("state"),
        "prediction_recomputed_in_paper": False,
        "prediction_used_as_gate": False,
        "candidate_preserved": True,
        "auto_buy": False,
    }


def build_combined_v2_contract(row: Dict[str, Any], frames: Dict[str, List[Dict[str, float]]], *, now_ts: Optional[float] = None) -> Dict[str, Any]:
    ts = float(now_ts if now_ts is not None else time.time())
    ticker = str(row.get("ticker") or row.get("symbol") or "").upper().replace("KRW-", "").strip()
    current = _row_price(row)
    counts = {tf: len(frames.get(tf) or []) for tf in REQUIRED_ROWS}
    missing = [tf for tf, need in REQUIRED_ROWS.items() if counts.get(tf, 0) < need]
    if current is None or current <= 0:
        missing.append("current_price")
    base: Dict[str, Any] = {
        "schema": "combined_v2_trade_contract_v2149", "version": VERSION, "build": BUILD_LABEL,
        "generation": GENERATION, "prediction_model_generation": PREDICTION_MODEL_GENERATION, "ticker": ticker, "evaluated_ts": ts,
        "candidate_preserved": True, "historical_ledger_rewritten": False,
        "legacy_structure_used": False, "legacy_entry_gate_used": False,
        "prediction_gate_active": False, "decision_combiner_active": True, "auto_buy": False,
    }
    if missing:
        base.update({
            "state": "DATA_MISSING", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "DATA_MISSING", "owner": "candle_worker" if "current_price" not in missing else "feature_worker", "missing": sorted(set(missing)), "candidate_quality_failed": False},
            "structure": {"state": "DATA_MISSING", "frame_counts": counts, "completed_candles_only": True},
            "prediction": {"state": "WAIT_STRUCTURE", "prediction_used_in_final_decision": False, "decision_combiner_active": True, "probability_is_calibrated": False},
            "decision_combiner": {"state": "WAIT_STRUCTURE", "entry_eligible": False, "candidate_preserved": True, "auto_buy": False},
        })
        return base

    m5, m15, m30, h1, h2, h4 = (frames[tf] for tf in ("m5", "m15", "m30", "h1", "h2", "h4"))
    atr5, atr15, atr30, atr1h, atr2h, atr4h = (_atr(x) for x in (m5, m15, m30, h1, h2, h4))
    major_axes = [x for x in (_trend_axis(h4), _trend_axis(h2)) if x is not None]
    setup_axes = [x for x in (_trend_axis(h1), _trend_axis(m30)) if x is not None]
    major_axis = sum(major_axes) / len(major_axes) if major_axes else 0.0
    setup_axis = sum(setup_axes) / len(setup_axes) if setup_axes else 0.0

    entry_levels = _level_candidates(frames, ("m5", "m15"), "resistance")
    entry_clusters = _cluster_levels(entry_levels, atr_ref=max(atr5, atr15 * 0.6), current=current)
    setup_levels = _level_candidates(frames, ("m30", "h1"), "support")
    support_clusters = _cluster_levels(setup_levels, atr_ref=max(atr30, atr1h * 0.55), current=current)
    target_levels = _level_candidates(frames, ("h2", "h4"), "resistance")
    target_clusters = _cluster_levels(target_levels, atr_ref=max(atr2h, atr4h * 0.55), current=current)

    # v2159 Trigger correctness repair.
    # - A resistance is a zone, so breakout ownership is the zone HIGH, never the center.
    # - A completed breakout remains valid for up to three completed 5m bars while closes hold above it.
    # - Among equally near zones (same clustering tolerance), prefer the better confirmed/recent zone.
    recent_rows = m5[-6:]
    recent_closes = [float(r["c"]) for r in recent_rows]
    recent_lows = [float(r["l"]) for r in recent_rows]
    # v2166: the 5m close remains the primary confirmation, but completed 1m/3m
    # candles may confirm the same already-built WAIT_TRIGGER contract earlier.
    # Forming candles are still excluded by the candle owner.
    m1 = list(frames.get("m1") or [])
    m3 = list(frames.get("m3") or [])
    short_frames_ready_v2166 = bool(len(m1) >= 3 or len(m3) >= 2)
    trigger_obj: Optional[Dict[str, Any]] = None
    trigger_state = "WAIT_TRIGGER"
    trigger_event_ts: Optional[float] = None
    trigger_mode = "WAIT_BREAK"
    trigger_break_index: Optional[int] = None
    trigger_selection_policy = "ZONE_HIGH_RECENT_HOLD_QUALITY_WITHIN_NEAREST_CLUSTER_BAND_V2159"

    def zone_line(zone: Dict[str, Any]) -> float:
        return float(zone.get("high") or zone.get("price") or 0.0)

    def zone_quality(zone: Dict[str, Any]) -> Tuple[float, float, float, float]:
        return (
            float(len(zone.get("timeframes") or [])),
            float(zone.get("source_count") or 0),
            float(zone.get("score") or 0.0),
            float(zone.get("last_source_ts") or 0.0),
        )

    fired: List[Tuple[float, Tuple[float, float, float, float], Dict[str, Any], str, int]] = []
    for zone in entry_clusters:
        level = zone_line(zone)
        if level <= 0 or len(recent_closes) < 2:
            continue
        break_idx: Optional[int] = None
        # Only the last three completed bars can own a still-valid breakout.
        first_idx = max(1, len(recent_closes) - 4)
        for idx in range(first_idx, len(recent_closes)):
            if recent_closes[idx - 1] <= level < recent_closes[idx]:
                break_idx = idx
        crossed_now = break_idx == len(recent_closes) - 1
        held_after_break = break_idx is not None and all(c > level for c in recent_closes[break_idx:])
        retested_now = (
            any(c > level for c in recent_closes[-5:-1])
            and recent_lows[-1] <= level + max(atr5 * 0.18, current * 0.0008)
            and recent_closes[-1] > level
        )
        early_mode = None
        early_event_ts = None
        early_tolerance = max(atr5 * 0.10, current * 0.0005)
        if len(m1) >= 3:
            c0, c1, c2 = (float(m1[-3]["c"]), float(m1[-2]["c"]), float(m1[-1]["c"]))
            l1, l2 = float(m1[-2]["l"]), float(m1[-1]["l"])
            if c0 <= level < c1 and c2 > level and min(l1, l2) >= level - early_tolerance:
                early_mode = "EARLY_M1_DOUBLE_HOLD"
                early_event_ts = float(m1[-2]["ts"])
        if early_mode is None and len(m3) >= 2:
            c0, c1 = float(m3[-2]["c"]), float(m3[-1]["c"])
            l1 = float(m3[-1]["l"])
            if c0 <= level < c1 and l1 >= level - early_tolerance:
                early_mode = "EARLY_M3_BREAK_HOLD"
                early_event_ts = float(m3[-1]["ts"])
        if crossed_now:
            mode = "COMPLETED_BREAK"
            event_idx = len(recent_closes) - 1
        elif retested_now:
            mode = "COMPLETED_RETEST_HOLD"
            event_idx = len(recent_closes) - 1
        elif held_after_break:
            mode = "COMPLETED_BREAK_HOLD"
            event_idx = int(break_idx)
        elif early_mode is not None and early_event_ts is not None:
            mode = early_mode
            event_idx = -1
        else:
            continue
        event_ts = float(early_event_ts if mode.startswith("EARLY_") else recent_rows[event_idx]["ts"])
        fired.append((event_ts, zone_quality(zone), zone, mode, event_idx))

    if fired:
        fired.sort(key=lambda item: (item[0], item[1]), reverse=True)
        trigger_event_ts, _, trigger_obj, trigger_mode, trigger_break_index = fired[0]
        trigger_state = "TRIGGER_FIRED"
    else:
        above = [z for z in entry_clusters if zone_line(z) >= current * 0.999]
        if above:
            nearest = min(zone_line(z) for z in above)
            selection_band = max(max(atr5, atr15 * 0.6) * 0.22, current * 0.0012)
            near_band = [z for z in above if zone_line(z) <= nearest + selection_band]
            trigger_obj = max(near_band, key=lambda z: (zone_quality(z), -abs(zone_line(z) - current)))
            trigger_state = "WAIT_TRIGGER"
        else:
            below = [z for z in entry_clusters if zone_line(z) < current]
            if below:
                trigger_obj = max(below, key=lambda z: zone_line(z))
                trigger_state = "TRIGGER_PASSED"
                trigger_mode = "OLD_LEVEL_ALREADY_CONSUMED"
    if trigger_obj is None:
        base.update({
            "state": "NO_TRIGGER_STRUCTURE", "decision_key": None, "plan_key": None,
            "material_diagnosis": {"state": "NO_TRIGGER_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False},
            "structure": {"state": "NO_TRIGGER_STRUCTURE", "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis},
        })
        base["prediction"] = _prediction(row, base["structure"], frames)
        return base

    trigger = float(trigger_obj.get("high") or trigger_obj["price"])
    support_candidates = [z for z in support_clusters if float(z["high"]) < trigger and (int(z.get("source_count") or 0) >= 2 or "h1" in (z.get("timeframes") or []))]
    support = max(support_candidates, key=lambda z: float(z["price"]), default=None)
    if support is None:
        structure = {"state": "NO_INVALID_STRUCTURE", "trigger": trigger, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_INVALID_STRUCTURE", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_INVALID_STRUCTURE", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = _prediction(row, structure, frames)
        return base

    invalid_buffer = max(atr30 * 0.22, atr1h * 0.10, trigger * 0.0008)
    invalid = float(support["low"]) - invalid_buffer
    target_floor = max(trigger, current)
    targets = [z for z in target_clusters if float(z["low"]) > target_floor * 1.00001]
    if not targets:
        structure = {"state": "NO_REACHABLE_T1", "trigger": trigger, "execution_invalid": invalid, "trigger_state": trigger_state, "frame_counts": counts, "major_trend_axis": major_axis, "setup_trend_axis": setup_axis}
        base.update({"state": "NO_REACHABLE_T1", "decision_key": None, "plan_key": None, "material_diagnosis": {"state": "NO_REACHABLE_T1", "owner": "strategy_v2_core_v2161", "candidate_quality_failed": False}, "structure": structure})
        base["prediction"] = _prediction(row, structure, frames)
        return base
    targets.sort(key=lambda z: float(z["low"]))
    t1 = float(targets[0]["low"])
    t2 = float(targets[1]["low"]) if len(targets) > 1 else None
    reference = current if trigger_state == "TRIGGER_FIRED" else trigger
    if not (invalid < reference < t1):
        structure_state = "PRICE_ORDER_INVALID"
    elif trigger_state == "WAIT_TRIGGER":
        structure_state = "WAIT_TRIGGER"
    elif trigger_state == "TRIGGER_PASSED":
        structure_state = "TRIGGER_PASSED"
    else:
        structure_state = "STRUCTURE_READY"

    risk_pct = (reference - invalid) / reference * 100.0
    room_pct = (t1 - reference) / reference * 100.0
    rr = room_pct / risk_pct if risk_pct > 0 else None
    fraction = max(0.0, (current - trigger) / max(t1 - trigger, 1e-12))
    # v2166 candidate-quality axis: after early detection is enabled, a remaining
    # non-retest entry that already consumed a large part of T1 and arrived after
    # an outsized 15m/30m run is held for a retest instead of chased.
    change_15m = _num(row.get("change_15m"), 0.0) or 0.0
    change_30m = _num(row.get("change_30m"), 0.0) or 0.0
    pre_entry_run_pct_v2166 = max(change_15m, change_30m)
    atr15_pct_v2166 = (atr15 / current * 100.0) if current > 0 else 0.0
    late_run_limit_v2166 = max(2.0, atr15_pct_v2166 * 2.4)
    entry_timing_wait_v2166 = bool(
        trigger_state == "TRIGGER_FIRED"
        and trigger_mode not in {"COMPLETED_RETEST_HOLD"}
        and fraction >= 0.32
        and pre_entry_run_pct_v2166 >= late_run_limit_v2166
    )
    if entry_timing_wait_v2166:
        structure_state = "ENTRY_TIMING_WAIT"
    vol_now = sum(float(r.get("v") or 0.0) for r in m5[-3:]) / 3.0
    vol_base = _median([float(r.get("v") or 0.0) for r in m5[-30:-3]], default=0.0)
    volume_axis = _clip(math.log(max(vol_now, 1e-12) / max(vol_base, 1e-12)) / 1.2, -1.0, 1.0) if vol_base > 0 else 0.0
    trigger_quality = (
        0.75 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_RETEST_HOLD"
        else 0.62 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M1_DOUBLE_HOLD"
        else 0.58 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "EARLY_M3_BREAK_HOLD"
        else 0.60 if trigger_state == "TRIGGER_FIRED" and trigger_mode == "COMPLETED_BREAK_HOLD"
        else 0.45 if trigger_state == "TRIGGER_FIRED"
        else -0.15 if trigger_state == "WAIT_TRIGGER"
        else -0.65
    )
    last_bar=m5[-1];bar_range=max(float(last_bar["h"])-float(last_bar["l"]),1e-12)
    breakout_body_pct=abs(float(last_bar["c"])-float(last_bar["o"]))/bar_range*100.0
    breakout_upper_wick_pct=(float(last_bar["h"])-max(float(last_bar["o"]),float(last_bar["c"])))/bar_range*100.0
    breakout_close_position_pct=(float(last_bar["c"])-float(last_bar["l"]))/bar_range*100.0
    trigger_hold_above_pct=(float(last_bar["c"])-trigger)/trigger*100.0 if trigger>0 else None
    atr_pct={"m5":atr5/current*100.0,"m15":atr15/current*100.0,"m30":atr30/current*100.0,"h1":atr1h/current*100.0,"h2":atr2h/current*100.0,"h4":atr4h/current*100.0}
    tr_now=_median([float(r["h"])-float(r["l"]) for r in m5[-5:]],default=0.0)
    tr_base=_median([float(r["h"])-float(r["l"]) for r in m5[-30:-5]],default=0.0)
    short_atr_expansion_ratio=(tr_now/tr_base) if tr_base>0 else None
    invalid_noise_ref=max(atr_pct["m30"],atr_pct["h1"]*0.55,0.000001)
    target_atr_ref=max(atr_pct["h2"],atr_pct["h4"]*0.55,0.000001)
    invalid_noise_multiple=risk_pct/invalid_noise_ref if invalid_noise_ref>0 else None
    target_atr_multiple=room_pct/target_atr_ref if target_atr_ref>0 else None
    plan_seed = {
        "ticker": ticker, "trigger": round(trigger, 12), "invalid": round(invalid, 12), "t1": round(t1, 12),
        "t2": round(t2, 12) if t2 else None, "trigger_state": trigger_state,
        "trigger_event_ts": trigger_event_ts, "h4_ts": float(h4[-1]["ts"]), "m5_ts": float(m5[-1]["ts"]),
    }
    plan_key = "v2149-plan:" + _plan_hash(plan_seed)
    structure = {
        "schema": "combined_v2_structure_v2149", "state": structure_state, "reference_entry": round(reference, 12),
        "current_price": round(current, 12), "trigger": round(trigger, 12), "trigger_state": trigger_state,
        "trigger_mode": trigger_mode, "trigger_event_ts": trigger_event_ts,
        "trigger_selection_policy_v2159": trigger_selection_policy,
        "trigger_breakout_line_source_v2159": "entry_zone_high",
        "trigger_valid_hold_bars_v2159": 3,
        "trigger_early_completed_frames_v2166": ["m1", "m3"],
        "trigger_short_frames_ready_v2166": short_frames_ready_v2166,
        "pretrigger_contract_ready_v2166": True,
        "entry_timing_wait_v2166": entry_timing_wait_v2166,
        "pre_entry_run_pct_v2166": round(pre_entry_run_pct_v2166, 6),
        "late_run_limit_pct_v2166": round(late_run_limit_v2166, 6),
        "trigger_break_index_v2159": trigger_break_index,
        "trigger_zone_score_v2159": round(float(trigger_obj.get("score") or 0.0), 6),
        "trigger_zone_source_count_v2159": int(trigger_obj.get("source_count") or 0),
        "trigger_zone_timeframes_v2159": list(trigger_obj.get("timeframes") or []),
        "entry_zone_low": round(float(trigger_obj["low"]), 12), "entry_zone_high": round(float(trigger_obj["high"]), 12),
        "execution_invalid": round(invalid, 12), "structural_support": round(float(support["price"]), 12),
        "target_t1": round(t1, 12), "target_t2": round(t2, 12) if t2 else None,
        "risk_pct": round(risk_pct, 6), "t1_room_pct": round(room_pct, 6), "rr_t1": round(rr, 6) if rr is not None else None,
        "entry_fraction_to_t1": round(fraction, 6), "major_trend_axis": round(major_axis, 6),
        "setup_trend_axis": round(setup_axis, 6), "trigger_quality_axis": round(trigger_quality, 6),
        "volume_expansion_axis": round(volume_axis, 6), "frame_counts": counts,
        "breakout_body_pct":round(breakout_body_pct,6),"breakout_upper_wick_pct":round(breakout_upper_wick_pct,6),
        "breakout_close_position_pct":round(breakout_close_position_pct,6),"trigger_hold_above_pct":round(trigger_hold_above_pct,6) if trigger_hold_above_pct is not None else None,
        "trigger_age_sec":round(max(0.0,ts-trigger_event_ts),3) if trigger_event_ts else None,"atr_pct_v2155":{k:round(v,6) for k,v in atr_pct.items()},
        "short_atr_expansion_ratio":round(short_atr_expansion_ratio,6) if short_atr_expansion_ratio is not None else None,
        "invalid_noise_multiple":round(invalid_noise_multiple,6) if invalid_noise_multiple is not None else None,
        "target_atr_multiple":round(target_atr_multiple,6) if target_atr_multiple is not None else None,
        "completed_candles_only": True, "forming_candle_excluded": True,
        "timeframe_contract": {"major": "4h/2h", "setup": "1h/30m", "trigger": "15m/5m", "execution": "1m/quote"},
        "source": "strategy_v2_core_v2168_only", "legacy_structure_used": False,
    }
    prediction = _prediction(row, structure, frames)
    combiner = _combine_structure_prediction(structure, prediction)
    state = str(combiner.get("state") or "ENGINE_ERROR")
    decision_key = None
    if state == "ENTRY_READY" and trigger_event_ts:
        decision_key = f"v2149:{ticker}:{plan_key.split(':')[-1]}:{int(trigger_event_ts * 1000)}"
    base.update({
        "state": state, "decision_key": decision_key, "plan_key": plan_key,
        "material_diagnosis": {"state": "READY" if state in {"ENTRY_READY", "WAIT_TRIGGER", "TRIGGER_PASSED", "ENTRY_TIMING_WAIT"} else state, "owner": str(combiner.get("owner") or "strategy_v2_core.structure"), "candidate_quality_failed": False, "missing": []},
        "structure": structure, "prediction": prediction, "decision_combiner": combiner,
        "execution_policy": {
            "schema": "combined_v2_execution_policy_v2149", "actual_price_required": True,
            "fresh_spread_slippage_required": True, "after_cost_reward_must_be_positive": True,
            "entry_must_remain_in_first_half_to_t1": True, "fixed_legacy_rr_room_chase_thresholds_used": False,
            "prediction_recomputed_in_paper": False, "decision_combiner_active": True,
            "prediction_used_in_strategy": False,
        },
    })
    return base



def compact_combined_v2_contract(value: Any) -> Dict[str, Any]:
    if not isinstance(value, dict):
        return {}
    structure = value.get("structure") if isinstance(value.get("structure"), dict) else {}
    prediction = value.get("prediction") if isinstance(value.get("prediction"), dict) else {}
    combiner = value.get("decision_combiner") if isinstance(value.get("decision_combiner"), dict) else {}
    rise_input = prediction.get("rise_prediction_input") if isinstance(prediction.get("rise_prediction_input"), dict) else {}
    structure_keys = (
        "state", "reference_entry", "current_price", "trigger", "trigger_state", "trigger_mode", "trigger_event_ts",
        "entry_zone_low", "entry_zone_high", "execution_invalid", "structural_support", "target_t1", "target_t2",
        "risk_pct", "t1_room_pct", "rr_t1", "entry_fraction_to_t1", "major_trend_axis", "setup_trend_axis",
        "trigger_quality_axis", "volume_expansion_axis", "frame_counts", "completed_candles_only", "forming_candle_excluded",
        "timeframe_contract", "source", "legacy_structure_used", "entry_timing_wait_v2166", "pre_entry_run_pct_v2166",
        "late_run_limit_pct_v2166", "trigger_selection_policy_v2159", "trigger_breakout_line_source_v2159",
        "trigger_valid_hold_bars_v2159", "trigger_break_index_v2159", "trigger_zone_score_v2159",
        "trigger_zone_source_count_v2159", "trigger_zone_timeframes_v2159",
    )
    compact_input = {
        "schema": rise_input.get("schema"),
        "state": rise_input.get("state"),
        "owner": rise_input.get("owner"),
        "ticker": rise_input.get("ticker"),
        "event_key": rise_input.get("event_key"),
        "event_bar_close_ts": rise_input.get("event_bar_close_ts"),
        "event_price": rise_input.get("event_price"),
        "episode_id": rise_input.get("episode_id"),
        "episode_low_ts": rise_input.get("episode_low_ts"),
        "episode_low_price": rise_input.get("episode_low_price"),
        "pre_signal_rise_pct": rise_input.get("pre_signal_rise_pct"),
        "materials": rise_input.get("materials"),
        "material_values": rise_input.get("material_values"),
        "material_names": rise_input.get("material_names"),
        "source_state_counts": rise_input.get("source_state_counts"),
        "input_coverage_pct": rise_input.get("input_coverage_pct"),
        "probability_3h": None,
        "probability_6h": None,
        "giveback_risk": None,
        "late_capture_risk": None,
        "model_state": "BASELINE_COLLECTING",
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": False,
        "zero_fill_used": False,
        "auto_buy": False,
    }
    return {
        "schema": "combined_v2_trade_contract_compact",
        "version": value.get("version"),
        "build": value.get("build"),
        "generation": value.get("generation"),
        "prediction_model_generation": value.get("prediction_model_generation"),
        "state": value.get("state"),
        "ticker": value.get("ticker"),
        "evaluated_ts": value.get("evaluated_ts"),
        "decision_key": value.get("decision_key"),
        "plan_key": value.get("plan_key"),
        "material_diagnosis": value.get("material_diagnosis"),
        "structure": {key: structure.get(key) for key in structure_keys},
        "prediction": {
            "schema": prediction.get("schema"),
            "state": prediction.get("state"),
            "prediction_model_generation": prediction.get("prediction_model_generation"),
            "rise_prediction_input": compact_input,
            "input_coverage_pct": prediction.get("input_coverage_pct"),
            "probability_3h": None,
            "probability_6h": None,
            "giveback_risk": None,
            "late_capture_risk": None,
            "weights_applied": False,
            "thresholds_applied": False,
            "prediction_used_in_final_decision": False,
            "decision_reason": prediction.get("decision_reason"),
            "candidate_preserved": True,
            "auto_buy": False,
        },
        "prediction_evidence": {
            "rise_prediction_input": compact_input,
            "materials": compact_input.get("materials"),
            "material_values": compact_input.get("material_values"),
            "source_state_counts": compact_input.get("source_state_counts"),
            "input_coverage_pct": compact_input.get("input_coverage_pct"),
            "zero_fill_used": False,
        },
        "decision_combiner": {
            "state": combiner.get("state"),
            "entry_eligible": combiner.get("entry_eligible"),
            "owner": combiner.get("owner"),
            "reason": combiner.get("reason"),
            "structure_state": combiner.get("structure_state"),
            "prediction_state": combiner.get("prediction_state"),
            "prediction_used_as_gate": False,
            "candidate_preserved": True,
        },
        "execution_policy": value.get("execution_policy"),
        "prediction_gate_active": False,
        "candidate_preserved": True,
        "auto_buy": False,
    }


def prediction_contract_identity(role_contract_hash: Optional[str] = None) -> Dict[str, Any]:
    payload = {
        "schema": "rise_prediction_material_contract",
        "model_generation": PREDICTION_MODEL_GENERATION,
        "material_names": list(RISE_MATERIAL_NAMES),
        "weights_applied": False,
        "thresholds_applied": False,
        "prediction_used_as_gate": False,
    }
    digest = hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
    return {**payload, "contract_hash": digest, "ready": True, "auto_buy": False}

