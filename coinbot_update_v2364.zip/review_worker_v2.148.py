#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import atexit
import fcntl
import hashlib
import json
import math
import os
import time
import traceback
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

BASE_DIR = Path(os.getenv('TRADING_BOT_DIR', '/home/dangdang971216/trading_bot'))
VERSION = 'review_worker_v2.148'
BUILD_LABEL = 'rise_prediction_single_ledger_owner_2026-07-31'
MAIN_DEPLOY_VERSION = BUILD_LABEL
INTERVAL_SEC = max(5.0, float(os.getenv('REVIEW_WORKER_INTERVAL_SEC', '30')))
STATUS = BASE_DIR / 'clean_review_worker_status.json'
ERROR = BASE_DIR / 'clean_review_worker_error.log'
LOCK_PATH = BASE_DIR / 'runtime' / 'review_worker_singleton_v1121.lock'
SNAPSHOT = BASE_DIR / 'runtime' / 'current_candidate_snapshot_v2176.json'
CANDLE_CACHE = BASE_DIR / 'clean_candle_cache.json'
CANDLE_DELTA = BASE_DIR / 'clean_candle_delta_v1014.jsonl'
LEDGER_DIR = BASE_DIR / 'rise_prediction_ledger'
ROLLUP_LEDGER = LEDGER_DIR / 'rollups.jsonl'
CHANGE_LEDGER = BASE_DIR / 'runtime' / 'change_verify_ledger.jsonl'
ISSUE_LEDGER = BASE_DIR / 'ledger' / 'issue_ledger_events.jsonl'
RAW_RETENTION_SEC = 5 * 24 * 3600.0
ROLLUP_RETENTION_SEC = 90 * 24 * 3600.0
HORIZONS = (('30m', 1800.0), ('1h', 3600.0), ('3h', 10800.0), ('6h', 21600.0))
MATERIAL_NAMES = (
    'return_30m_atr_adjusted',
    'price_acceleration_30m',
    'price_acceleration_1h',
    'relative_strength_1h',
    'relative_strength_acceleration_1h',
    'turnover_growth_recent1h_vs_prior3h',
    'turnover_acceleration_30m',
    'higher_low_strength_atr',
    'pullback_recovery_ratio',
    'target_path_consumed_ratio',
    'btc_price_acceleration_1h',
    'market_breadth_change',
    'market_liquidity_state',
)
OLD_RISE_DERIVED_PATHS = (
    BASE_DIR / 'strategy_v2_outcome_state_v2133.json',
    BASE_DIR / 'strategy_v2_outcome_status_v2133.json',
    BASE_DIR / 'strategy_v2_outcomes_v2133.jsonl',
    BASE_DIR / 'strategy_v2_actual_exact_status_v2168.json',
    BASE_DIR / 'prediction_material_recovery_status_v2339.json',
    BASE_DIR / 'runtime' / 'review_incremental_state.json',
    BASE_DIR / 'runtime' / 'review_incremental_snapshot.json',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-wal',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-shm',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-journal',
)

_LOCK_FH = None
_STATE_LOADED = False
_EVENTS: Dict[str, Dict[str, Any]] = {}
_OUTCOMES: set[Tuple[str, str]] = set()
_OUTCOME_ROWS: Dict[Tuple[str, str], Dict[str, Any]] = {}
_ROLLED_DATES: set[str] = set()
_CANDLE_SIGNATURE: Optional[Tuple[int, int]] = None
_CANDLE_INDEX: Dict[str, Dict[str, List[Dict[str, float]]]] = {}
_CANDLE_COUNT = 0
_COLLECTION_START_TS: Optional[float] = None


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts or now_ts()))


def num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or value == '' or isinstance(value, bool):
            return default
        result = float(value)
        return result if math.isfinite(result) else default
    except Exception:
        return default


def ticker(value: Any) -> str:
    return str(value or '').upper().strip().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '')


def load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    with tmp.open('w', encoding='utf-8') as handle:
        json.dump(obj, handle, ensure_ascii=False, separators=(',', ':'))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
        handle.flush()
        os.fsync(handle.fileno())


def read_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    try:
        with path.open('r', encoding='utf-8', errors='ignore') as handle:
            for line in handle:
                try:
                    item = json.loads(line)
                except Exception:
                    continue
                if isinstance(item, dict):
                    rows.append(item)
    except Exception:
        return []
    return rows


def append_error(where: str, exc: BaseException) -> None:
    ERROR.parent.mkdir(parents=True, exist_ok=True)
    with ERROR.open('a', encoding='utf-8') as handle:
        handle.write(f'[{now_text()}] {where}: {type(exc).__name__}: {exc}\n')
        handle.write(traceback.format_exc() + '\n')


def day_key(ts: float) -> str:
    return time.strftime('%Y-%m-%d', time.localtime(ts))


def raw_path(date_text: str) -> Path:
    return LEDGER_DIR / f'{date_text}.jsonl'


def file_signature(path: Path) -> int:
    try:
        stat = path.stat()
        return stat.st_mtime_ns ^ stat.st_size
    except OSError:
        return 0


def acquire_lock() -> None:
    global _LOCK_FH
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    handle = LOCK_PATH.open('a+', encoding='utf-8')
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit(0)
    handle.seek(0)
    handle.truncate()
    handle.write(json.dumps({'pid': os.getpid(), 'version': VERSION, 'build': BUILD_LABEL, 'ts': now_ts()}))
    handle.flush()
    _LOCK_FH = handle
    atexit.register(lambda: handle.close() if not handle.closed else None)


def _candidate_rows(snapshot: Any) -> List[Dict[str, Any]]:
    if not isinstance(snapshot, dict):
        return []
    rows = snapshot.get('rows')
    return [dict(row) for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []


def _rise_input(row: Dict[str, Any]) -> Dict[str, Any]:
    value = row.get('rise_prediction_input')
    if isinstance(value, dict):
        return value
    contract = row.get('trade_path_contract_v2149') if isinstance(row.get('trade_path_contract_v2149'), dict) else {}
    prediction = contract.get('prediction') if isinstance(contract.get('prediction'), dict) else {}
    value = prediction.get('rise_prediction_input')
    return value if isinstance(value, dict) else {}


def _event_record(row: Dict[str, Any], snapshot: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    payload = _rise_input(row)
    event_key = str(payload.get('event_key') or '')
    event_ts = num(payload.get('event_bar_close_ts'))
    symbol = ticker(payload.get('ticker') or row.get('ticker'))
    if not event_key or event_ts is None or not symbol:
        return None
    materials = payload.get('materials') if isinstance(payload.get('materials'), dict) else {}
    material_names = list(payload.get('material_names') or [])
    if tuple(material_names) != MATERIAL_NAMES:
        # Contract mismatch is recorded honestly, not repaired or zero-filled.
        contract_state = 'MATERIAL_CONTRACT_MISMATCH'
    else:
        contract_state = str(payload.get('state') or 'MISSING')
    structure = payload.get('structure_contract') if isinstance(payload.get('structure_contract'), dict) else {}
    baseline = payload.get('baseline_decision') if isinstance(payload.get('baseline_decision'), dict) else {}
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'event',
        'event_key': event_key,
        'event_ts': event_ts,
        'event_text': now_text(event_ts),
        'ticker': symbol,
        'event_price': num(payload.get('event_price')),
        'episode_id': payload.get('episode_id'),
        'episode_low_ts': num(payload.get('episode_low_ts')),
        'episode_low_price': num(payload.get('episode_low_price')),
        'pre_signal_rise_pct': num(payload.get('pre_signal_rise_pct')),
        'input_state': contract_state,
        'input_coverage_pct': num(payload.get('input_coverage_pct')),
        'source_state_counts': payload.get('source_state_counts') if isinstance(payload.get('source_state_counts'), dict) else {},
        'materials': materials,
        'material_values': payload.get('material_values') if isinstance(payload.get('material_values'), dict) else {},
        'material_names': material_names,
        'probability_3h': None,
        'probability_6h': None,
        'giveback_risk': None,
        'late_capture_risk': None,
        'model_state': 'BASELINE_COLLECTING',
        'weights_applied': False,
        'thresholds_applied': False,
        'prediction_used_as_gate': False,
        'structure_contract': structure,
        'baseline_decision': baseline,
        'baseline_decision_basis': 'DYNAMIC_STRUCTURE_ONLY_OBSERVATION_NOT_NEW_PREDICTION',
        'candidate_snapshot_id': snapshot.get('snapshot_id'),
        'candidate_commit_id': snapshot.get('candidate_commit_id'),
        'cycle_id': snapshot.get('cycle_id'),
        'owner': 'review_worker',
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'auto_buy': False,
    }


def _load_rollup_dates() -> None:
    for row in read_jsonl(ROLLUP_LEDGER):
        if row.get('record_type') == 'daily_rollup' and row.get('source_date'):
            _ROLLED_DATES.add(str(row.get('source_date')))


def load_state_once() -> None:
    global _STATE_LOADED, _COLLECTION_START_TS
    if _STATE_LOADED:
        return
    LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    _load_rollup_dates()
    cutoff = now_ts() - RAW_RETENTION_SEC - 24 * 3600.0
    for path in sorted(LEDGER_DIR.glob('20??-??-??.jsonl')):
        try:
            date_ts = time.mktime(time.strptime(path.stem, '%Y-%m-%d'))
        except Exception:
            continue
        if date_ts < cutoff:
            continue
        for row in read_jsonl(path):
            record_type = str(row.get('record_type') or '')
            key = str(row.get('event_key') or '')
            if record_type == 'event' and key:
                _EVENTS.setdefault(key, row)
                event_ts = num(row.get('event_ts'))
                if event_ts is not None:
                    _COLLECTION_START_TS = event_ts if _COLLECTION_START_TS is None else min(_COLLECTION_START_TS, event_ts)
            elif record_type == 'outcome' and key and row.get('horizon'):
                outcome_key = (key, str(row.get('horizon')))
                # Only a terminal READY/FAILED outcome closes the retry loop.
                if str(row.get('outcome_state') or '') in {'READY', 'FAILED_SOURCE_MISSING'}:
                    _OUTCOMES.add(outcome_key)
                    _OUTCOME_ROWS[outcome_key] = row
    _STATE_LOADED = True


def _cache_pairs(obj: Any) -> Iterable[Tuple[str, Dict[str, Any]]]:
    if isinstance(obj, dict):
        rows = obj.get('rows')
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict):
                    yield ticker(row.get('ticker') or row.get('symbol') or row.get('market')), row
            return
        if isinstance(rows, dict):
            for key, row in rows.items():
                if isinstance(row, dict):
                    yield ticker(key or row.get('ticker')), row
            return
        for key, row in obj.items():
            if isinstance(row, dict) and isinstance(row.get('structure_lab_candles'), dict):
                yield ticker(key or row.get('ticker')), row
    elif isinstance(obj, list):
        for row in obj:
            if isinstance(row, dict):
                yield ticker(row.get('ticker') or row.get('symbol') or row.get('market')), row


def _apply_delta(row: Dict[str, Any], ops: Any) -> Dict[str, Any]:
    import copy
    out = copy.deepcopy(row) if isinstance(row, dict) else {}
    for op in ops if isinstance(ops, list) else []:
        if not isinstance(op, dict):
            continue
        kind = str(op.get('op') or '')
        path = [str(item) for item in (op.get('path') or [])]
        if not path:
            continue
        current = out
        valid = True
        for key in path[:-1]:
            if not isinstance(current, dict):
                valid = False
                break
            next_value = current.get(key)
            if not isinstance(next_value, dict):
                if kind == 'remove':
                    valid = False
                    break
                next_value = {}
                current[key] = next_value
            current = next_value
        if not valid or not isinstance(current, dict):
            continue
        key = path[-1]
        if kind == 'remove':
            current.pop(key, None)
        elif kind == 'set':
            current[key] = copy.deepcopy(op.get('value'))
        elif kind == 'list_roll':
            existing = current.get(key) if isinstance(current.get(key), list) else []
            drop = max(0, int(num(op.get('drop_front'), 0.0) or 0))
            additions = op.get('append') if isinstance(op.get('append'), list) else []
            current[key] = copy.deepcopy(existing[drop:] + additions)
    return out


def _normalize_frame(rows: Any) -> List[Dict[str, float]]:
    out = []
    for item in rows if isinstance(rows, list) else []:
        if isinstance(item, dict):
            ts = num(item.get('ts')); op = num(item.get('o')); close = num(item.get('c')); high = num(item.get('h')); low = num(item.get('l')); volume = num(item.get('v'), 0.0)
        elif isinstance(item, (list, tuple)) and len(item) >= 6:
            ts, op, close, high, low, volume = (num(item[0]), num(item[1]), num(item[2]), num(item[3]), num(item[4]), num(item[5], 0.0))
        else:
            continue
        if None in (ts, op, close, high, low) or min(float(op), float(close), float(high), float(low)) <= 0:
            continue
        out.append({'ts': float(ts), 'o': float(op), 'c': float(close), 'h': float(high), 'l': float(low), 'v': max(0.0, float(volume or 0.0))})
    out.sort(key=lambda item: item['ts'])
    return out


def candle_index() -> Tuple[Dict[str, Dict[str, List[Dict[str, float]]]], int]:
    global _CANDLE_SIGNATURE, _CANDLE_INDEX, _CANDLE_COUNT
    signature = (file_signature(CANDLE_CACHE), file_signature(CANDLE_DELTA))
    if _CANDLE_SIGNATURE == signature and _CANDLE_INDEX:
        return _CANDLE_INDEX, _CANDLE_COUNT
    base_obj = load_json(CANDLE_CACHE, {}) or {}
    source: Dict[str, Dict[str, Any]] = {}
    checkpoint = str(base_obj.get('delta_checkpoint_id_v1016') or '') if isinstance(base_obj, dict) else ''
    for symbol, row in _cache_pairs(base_obj):
        if symbol:
            source[symbol] = dict(row)
    if CANDLE_DELTA.exists():
        try:
            with CANDLE_DELTA.open('r', encoding='utf-8', errors='ignore') as handle:
                for line in handle:
                    try:
                        item = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(item, dict):
                        continue
                    symbol = ticker(item.get('ticker'))
                    if not symbol:
                        continue
                    schema = str(item.get('schema') or '')
                    if schema == 'candle_delta_ops_v1016':
                        base_checkpoint = str(item.get('base_checkpoint_id_v1016') or '')
                        if checkpoint and base_checkpoint and checkpoint != base_checkpoint:
                            continue
                        source[symbol] = _apply_delta(source.get(symbol, {}), item.get('ops'))
                    elif schema == 'candle_delta_patch_v1015' and isinstance(item.get('row'), dict):
                        source[symbol] = dict(item.get('row'))
        except Exception as exc:
            append_error('candle_delta', exc)
    index: Dict[str, Dict[str, List[Dict[str, float]]]] = {}
    count = 0
    for symbol, row in source.items():
        lab = row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'), dict) else {}
        frames = lab.get('frames') if isinstance(lab.get('frames'), dict) else {}
        normalized = {}
        for tf in ('m1', 'm3', 'm5', 'm15', 'm30', 'h1'):
            values = _normalize_frame(frames.get(tf))
            if values:
                normalized[tf] = values
                count += len(values)
        if normalized:
            index[symbol] = normalized
    _CANDLE_SIGNATURE = signature
    _CANDLE_INDEX = index
    _CANDLE_COUNT = count
    return index, count


def _select_path(frames: Dict[str, List[Dict[str, float]]], start_ts: float, end_ts: float) -> Tuple[str, List[Dict[str, float]], str]:
    choices = (('m1', 60.0), ('m3', 180.0), ('m5', 300.0), ('m15', 900.0), ('m30', 1800.0))
    best_tf = ''
    best_rows: List[Dict[str, float]] = []
    best_reason = 'CANDLE_PATH_MISSING'
    for tf, sec in choices:
        rows = [row for row in frames.get(tf, []) if start_ts <= row['ts'] < end_ts]
        if not rows:
            continue
        last_end = rows[-1]['ts'] + sec
        if last_end + sec * 0.25 < end_ts:
            best_reason = f'{tf}_HORIZON_INCOMPLETE'
            continue
        return tf, rows, 'READY'
    return best_tf, best_rows, best_reason


def resolve_outcome(event: Dict[str, Any], horizon: str, horizon_sec: float, index: Dict[str, Dict[str, List[Dict[str, float]]]], nowv: float) -> Optional[Dict[str, Any]]:
    event_key = str(event.get('event_key') or '')
    event_ts = num(event.get('event_ts'))
    event_price = num(event.get('event_price'))
    symbol = ticker(event.get('ticker'))
    if not event_key or event_ts is None or event_price is None or event_price <= 0 or not symbol:
        return None
    if nowv < event_ts + horizon_sec:
        return None
    frames = index.get(symbol) or {}
    frame_name, path, state = _select_path(frames, event_ts, event_ts + horizon_sec)
    if not path:
        return {
            'schema': 'rise_prediction_ledger_record', 'record_type': 'outcome', 'event_key': event_key,
            'event_ts': event_ts, 'ticker': symbol, 'horizon': horizon, 'horizon_sec': horizon_sec,
            'outcome_state': 'MISSING', 'missing_reason': state, 'source_frame': frame_name or None,
            'baseline_passed': bool((event.get('baseline_decision') or {}).get('entry_eligible')),
            'target_first': False, 'invalid_first': False, 'actual_rise_success': None,
            'completed_ts': nowv, 'completed_text': now_text(nowv), 'owner': 'review_worker',
            'zero_fill_used': False, 'auto_buy': False,
        }
    structure = event.get('structure_contract') if isinstance(event.get('structure_contract'), dict) else {}
    target = num(structure.get('target_t1'))
    invalid = num(structure.get('execution_invalid'))
    first_target = None
    first_invalid = None
    ambiguous_ts = None
    max_price = event_price
    min_price = event_price
    max_ts = event_ts
    min_ts = event_ts
    for bar in path:
        high = float(bar['h']); low = float(bar['l'])
        if high > max_price:
            max_price = high; max_ts = float(bar['ts'])
        if low < min_price:
            min_price = low; min_ts = float(bar['ts'])
        hit_target = target is not None and high >= target
        hit_invalid = invalid is not None and low <= invalid
        if hit_target and first_target is None:
            first_target = float(bar['ts'])
        if hit_invalid and first_invalid is None:
            first_invalid = float(bar['ts'])
        if hit_target and hit_invalid and ambiguous_ts is None:
            ambiguous_ts = float(bar['ts'])
    if first_target is not None and first_invalid is not None:
        if first_target == first_invalid:
            touch_order = 'AMBIGUOUS_SAME_BAR'
        elif first_target < first_invalid:
            touch_order = 'TARGET_FIRST'
        else:
            touch_order = 'INVALID_FIRST'
    elif first_target is not None:
        touch_order = 'TARGET_FIRST'
    elif first_invalid is not None:
        touch_order = 'INVALID_FIRST'
    else:
        touch_order = 'NO_TOUCH'
    final_price = float(path[-1]['c'])
    final_return = (final_price / event_price - 1.0) * 100.0
    mfe = (max_price / event_price - 1.0) * 100.0
    mae = (min_price / event_price - 1.0) * 100.0
    giveback = mfe - final_return
    pre_rise = num(event.get('pre_signal_rise_pct'))
    early_capture = None
    if pre_rise is not None and pre_rise >= 0 and mfe > 0 and pre_rise + mfe > 0:
        early_capture = mfe / (pre_rise + mfe)
    passed = bool((event.get('baseline_decision') or {}).get('entry_eligible'))
    success = True if touch_order == 'TARGET_FIRST' else False if touch_order == 'INVALID_FIRST' else None
    if passed and success is True:
        result_group = 'PASS_RISE'
    elif passed and success is False:
        result_group = 'PASS_FAIL'
    elif not passed and success is True:
        result_group = 'HOLD_MISSED_RISE'
    elif not passed and success is False:
        result_group = 'HOLD_CORRECT'
    else:
        result_group = 'UNRESOLVED'
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'outcome',
        'event_key': event_key,
        'event_ts': event_ts,
        'ticker': symbol,
        'episode_id': event.get('episode_id'),
        'horizon': horizon,
        'horizon_sec': horizon_sec,
        'outcome_state': 'READY',
        'touch_order': touch_order,
        'target_first': touch_order == 'TARGET_FIRST',
        'invalid_first': touch_order == 'INVALID_FIRST',
        'actual_rise_success': success,
        'baseline_passed': passed,
        'baseline_decision_basis': 'DYNAMIC_STRUCTURE_ONLY_OBSERVATION_NOT_NEW_PREDICTION',
        'result_group': result_group,
        'event_price': event_price,
        'final_price': final_price,
        'final_return_pct': round(final_return, 8),
        'mfe_pct': round(mfe, 8),
        'mae_pct': round(mae, 8),
        'mfe_ts': max_ts,
        'mae_ts': min_ts,
        'mfe_delay_sec': round(max(0.0, max_ts - event_ts), 3),
        'giveback_pct': round(giveback, 8),
        'early_capture_ratio': round(early_capture, 8) if early_capture is not None else None,
        'pre_signal_rise_pct': pre_rise,
        'first_target_ts': first_target,
        'first_invalid_ts': first_invalid,
        'ambiguous_same_bar_ts': ambiguous_ts,
        'source_frame': frame_name,
        'source_completed_candles_only': True,
        'completed_ts': nowv,
        'completed_text': now_text(nowv),
        'owner': 'review_worker',
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'auto_buy': False,
    }


def append_new_events(snapshot: Dict[str, Any]) -> Tuple[int, int]:
    global _COLLECTION_START_TS
    created = 0
    duplicates = 0
    for row in _candidate_rows(snapshot):
        record = _event_record(row, snapshot)
        if not record:
            continue
        key = str(record['event_key'])
        if key in _EVENTS:
            duplicates += 1
            continue
        append_jsonl(raw_path(day_key(float(record['event_ts']))), record)
        _EVENTS[key] = record
        _COLLECTION_START_TS = float(record['event_ts']) if _COLLECTION_START_TS is None else min(_COLLECTION_START_TS, float(record['event_ts']))
        created += 1
    return created, duplicates


def append_due_outcomes(nowv: float, index: Dict[str, Dict[str, List[Dict[str, float]]]]) -> Dict[str, int]:
    counts = Counter()
    for key, event in list(_EVENTS.items()):
        event_ts = num(event.get('event_ts'))
        if event_ts is None or nowv - event_ts > RAW_RETENTION_SEC + 24 * 3600.0:
            continue
        for horizon, sec in HORIZONS:
            outcome_key = (key, horizon)
            if outcome_key in _OUTCOMES or nowv < event_ts + sec:
                continue
            record = resolve_outcome(event, horizon, sec, index, nowv)
            if record is None:
                continue
            state = str(record.get('outcome_state') or 'MISSING')
            if state != 'READY':
                # Candle outcome data can arrive late. Do not seal MISSING and do not
                # zero-fill; retry through the existing Candle cache on later cycles.
                counts[f'{horizon}:PENDING_{state}'] += 1
                continue
            append_jsonl(raw_path(day_key(event_ts)), record)
            _OUTCOMES.add(outcome_key)
            _OUTCOME_ROWS[outcome_key] = record
            counts[f'{horizon}:READY'] += 1
    return dict(counts)


def _weighted_average(rows: List[Tuple[float, float]]) -> Optional[float]:
    denominator = sum(weight for _, weight in rows)
    return sum(value * weight for value, weight in rows) / denominator if denominator > 0 else None


def build_rollup(date_text: str, records: List[Dict[str, Any]]) -> Dict[str, Any]:
    events = {str(row.get('event_key')): row for row in records if row.get('record_type') == 'event' and row.get('event_key')}
    outcomes = [row for row in records if row.get('record_type') == 'outcome']
    episode_counts = Counter(str(row.get('episode_id') or row.get('event_key')) for row in events.values())
    outcome_counts = Counter()
    metrics: Dict[str, Dict[str, List[Tuple[float, float]]]] = defaultdict(lambda: defaultdict(list))
    material_groups: Dict[str, Dict[str, List[Tuple[float, float]]]] = defaultdict(lambda: defaultdict(list))
    for row in outcomes:
        key = str(row.get('event_key') or '')
        event = events.get(key, {})
        episode = str(event.get('episode_id') or key)
        weight = 1.0 / max(1, episode_counts.get(episode, 1))
        horizon = str(row.get('horizon') or 'unknown')
        group = str(row.get('result_group') or row.get('outcome_state') or 'unknown')
        outcome_counts[f'{horizon}:{group}'] += 1
        for metric in ('final_return_pct', 'mfe_pct', 'mae_pct', 'giveback_pct', 'early_capture_ratio'):
            value = num(row.get(metric))
            if value is not None:
                metrics[horizon][metric].append((value, weight))
        values = event.get('material_values') if isinstance(event.get('material_values'), dict) else {}
        for name in MATERIAL_NAMES:
            value = num(values.get(name))
            if value is not None:
                material_groups[f'{horizon}:{group}'][name].append((value, weight))
    public_metrics = {
        horizon: {name: round(value, 8) if value is not None else None for name, items in group.items() if (value := _weighted_average(items)) is not None}
        for horizon, group in metrics.items()
    }
    public_materials = {
        group: {name: round(value, 8) if value is not None else None for name, items in values.items() if (value := _weighted_average(items)) is not None}
        for group, values in material_groups.items()
    }
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'daily_rollup',
        'source_date': date_text,
        'generated_ts': now_ts(),
        'generated_text': now_text(),
        'event_count': len(events),
        'unique_episode_count': len(episode_counts),
        'outcome_count': len(outcomes),
        'outcome_counts': dict(outcome_counts),
        'episode_weighted_metrics': public_metrics,
        'episode_weighted_material_means': public_materials,
        'material_names': list(MATERIAL_NAMES),
        'weights_applied_to_prediction': False,
        'thresholds_applied_to_prediction': False,
        'prediction_used_as_gate': False,
        'raw_retention_days': 5,
        'owner': 'review_worker',
        'auto_buy': False,
    }


def _terminal_missing_outcome(event: Dict[str, Any], horizon: str, horizon_sec: float, nowv: float) -> Dict[str, Any]:
    baseline = event.get('baseline_decision') if isinstance(event.get('baseline_decision'), dict) else {}
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'outcome',
        'event_key': event.get('event_key'),
        'event_ts': event.get('event_ts'),
        'ticker': event.get('ticker'),
        'episode_id': event.get('episode_id'),
        'horizon': horizon,
        'horizon_sec': horizon_sec,
        'outcome_state': 'FAILED_SOURCE_MISSING',
        'missing_reason': 'CANDLE_PATH_NOT_COMPLETED_BEFORE_RAW_RETENTION',
        'baseline_passed': bool(baseline.get('entry_eligible')),
        'baseline_decision_basis': 'DYNAMIC_STRUCTURE_ONLY_OBSERVATION_NOT_NEW_PREDICTION',
        'target_first': False,
        'invalid_first': False,
        'actual_rise_success': None,
        'result_group': 'SOURCE_MISSING',
        'completed_ts': nowv,
        'completed_text': now_text(nowv),
        'owner': 'review_worker',
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'auto_buy': False,
    }


def rotate_ledgers(nowv: float) -> Dict[str, int]:
    rolled = deleted = terminal_missing = 0
    for path in sorted(LEDGER_DIR.glob('20??-??-??.jsonl')):
        try:
            date_start = time.mktime(time.strptime(path.stem, '%Y-%m-%d'))
        except Exception:
            continue
        # Delete only after the entire local date is older than 120 hours.
        if nowv - (date_start + 24 * 3600.0) <= RAW_RETENTION_SEC:
            continue
        date_text = path.stem
        records = list(read_jsonl(path))
        events = {str(row.get('event_key')): row for row in records if row.get('record_type') == 'event' and row.get('event_key')}
        terminal_keys = {
            (str(row.get('event_key')), str(row.get('horizon')))
            for row in records
            if row.get('record_type') == 'outcome' and str(row.get('outcome_state') or '') in {'READY', 'FAILED_SOURCE_MISSING'}
        }
        # A missing source remains retryable for the full raw-retention window.
        # Only at final rotation is it sealed as a source failure for the rollup.
        for key, event in events.items():
            for horizon, sec in HORIZONS:
                if (key, horizon) in terminal_keys:
                    continue
                record = _terminal_missing_outcome(event, horizon, sec, nowv)
                records.append(record)
                terminal_keys.add((key, horizon))
                terminal_missing += 1
        if date_text not in _ROLLED_DATES:
            append_jsonl(ROLLUP_LEDGER, build_rollup(date_text, records))
            _ROLLED_DATES.add(date_text)
            rolled += 1
        path.unlink(missing_ok=True)
        deleted += 1
        for key, event in list(_EVENTS.items()):
            event_ts = num(event.get('event_ts'))
            if event_ts is not None and day_key(event_ts) == date_text:
                _EVENTS.pop(key, None)
                for horizon, _ in HORIZONS:
                    outcome_key = (key, horizon)
                    _OUTCOMES.discard(outcome_key)
                    _OUTCOME_ROWS.pop(outcome_key, None)
    # Rollups are derived summaries; rewrite only this one derived file for retention.
    if ROLLUP_LEDGER.exists():
        keep = []
        cutoff = nowv - ROLLUP_RETENTION_SEC
        for row in read_jsonl(ROLLUP_LEDGER):
            generated = num(row.get('generated_ts'), nowv)
            if generated is not None and generated >= cutoff:
                keep.append(row)
        tmp = ROLLUP_LEDGER.with_name(f'.{ROLLUP_LEDGER.name}.{os.getpid()}.{time.time_ns()}.tmp')
        with tmp.open('w', encoding='utf-8') as handle:
            for row in keep:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
            handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp, ROLLUP_LEDGER)
    return {'rolled': rolled, 'raw_files_deleted': deleted, 'terminal_source_missing': terminal_missing}


def cleanup_old_rise_derived(allow: bool) -> List[str]:
    if not allow:
        return []
    removed = []
    for path in OLD_RISE_DERIVED_PATHS:
        try:
            if path.exists():
                path.unlink()
                removed.append(str(path.relative_to(BASE_DIR)))
        except Exception as exc:
            append_error(f'cleanup_{path.name}', exc)
    return removed


def seed_change_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_single_ledger.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-CLEAN-BASELINE',
        'issue_id': 'OLD-RISE-PREDICTION-LATE-AND-WRONG',
        'version': 'v2364',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'The active rise prediction mixed old weighted layers and often recognized already-risen or re-rising coins late. Its results were split across multiple shadow and outcome views.',
        'fix': 'Remove the old rise-prediction active gate; collect only the agreed 13 materials; write one event/outcome ledger with episode dedupe, missed-rise tracking and five-day raw rotation.',
        'not_touched': ['dynamic trigger/invalid/target', 'Paper execution cost checks', 'OPEN/CLOSED/trade/decision exact ledgers', 'exit contract', 'Guard upgrade flow', 'auto-buy OFF'],
        'remaining': 'Server runtime proof and five-day baseline data before any learned weights or thresholds.',
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'OLD-RISE-PREDICTION-LATE-AND-WRONG',
        'status': 'CHECK',
        'title': '기존 상승예측 폐기·새 재료 기준선 수집',
        'detail': '새 상승예측은 13개 재료만 기록하며 첫 5일 동안 가중치·컷·하드차단을 적용하지 않는다.',
        'version': 'v2364',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')


def run_once() -> Dict[str, Any]:
    started = time.monotonic()
    nowv = now_ts()
    load_state_once()
    snapshot = load_json(SNAPSHOT, {}) or {}
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    created, duplicates = append_new_events(snapshot)
    index, candle_count = candle_index()
    outcome_counts = append_due_outcomes(nowv, index)
    rotation = rotate_ledgers(nowv)
    removed = cleanup_old_rise_derived(bool(created or _EVENTS))
    raw_files = sorted(LEDGER_DIR.glob('20??-??-??.jsonl'))
    outcome_total = Counter(horizon for _, horizon in _OUTCOMES)
    result_groups = Counter()
    touch_orders = Counter()
    outcome_states = Counter()
    for record in _OUTCOME_ROWS.values():
        horizon = str(record.get('horizon') or 'unknown')
        outcome_states[f"{horizon}:{str(record.get('outcome_state') or 'MISSING')}"] += 1
        if record.get('result_group'):
            result_groups[f"{horizon}:{str(record.get('result_group'))}"] += 1
        if record.get('touch_order'):
            touch_orders[f"{horizon}:{str(record.get('touch_order'))}"] += 1
    input_states = Counter(str(event.get('input_state') or 'MISSING') for event in _EVENTS.values())
    pending = Counter()
    for key, event in _EVENTS.items():
        event_ts = num(event.get('event_ts'))
        if event_ts is None:
            continue
        for horizon, sec in HORIZONS:
            if (key, horizon) not in _OUTCOMES:
                pending[horizon] += 1
    elapsed = max(0.0, time.monotonic() - started)
    canonical = {
        'schema': 'rise_prediction_canonical_status',
        'state': 'ACTIVE' if _EVENTS else 'WAITING',
        'owner': 'review_worker',
        'ledger_root': str(LEDGER_DIR),
        'collection_start_ts': _COLLECTION_START_TS,
        'collection_start_text': now_text(_COLLECTION_START_TS) if _COLLECTION_START_TS else None,
        'event_count_in_retention': len(_EVENTS),
        'new_events': created,
        'duplicate_events_prevented': duplicates,
        'unique_episode_count': len({str(event.get('episode_id') or event.get('event_key')) for event in _EVENTS.values()}),
        'input_state_counts': dict(input_states),
        'outcome_counts': dict(outcome_total),
        'outcome_state_counts': dict(outcome_states),
        'result_group_counts': dict(result_groups),
        'touch_order_counts': dict(touch_orders),
        'new_outcome_counts': outcome_counts,
        'pending_outcome_counts': dict(pending),
        'raw_file_count': len(raw_files),
        'raw_retention_days': 5,
        'rollup_retention_days': 90,
        'rollup_count': len(_ROLLED_DATES),
        'rotation': rotation,
        'old_rise_derived_removed': removed,
        'material_names': list(MATERIAL_NAMES),
        'material_count': len(MATERIAL_NAMES),
        'event_key_contract': 'ticker + completed_30m_bar_close_ts',
        'episode_id_contract': 'ticker + latest_confirmed_m30_swing_low_ts',
        'weights_applied': False,
        'thresholds_applied': False,
        'prediction_used_as_gate': False,
        'new_shadow_created': False,
        'new_worker_created': False,
        'new_service_created': False,
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'missing_outcome_retries_active': True,
        'historical_trade_ledgers_deleted': False,
        'auto_buy': False,
    }
    status = {
        'schema': 'clean_review_worker_status',
        'version': VERSION,
        'build': BUILD_LABEL,
        'state': 'running',
        'pid': os.getpid(),
        'active_owner': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'last_completed_ts': nowv,
        'cycle_complete': True,
        'cycle_complete_v2294': True,
        'analysis_ready': True,
        'analysis_ready_v2246': True,
        'cycle_elapsed_sec': round(elapsed, 3),
        'candidate_snapshot_id': snapshot.get('snapshot_id'),
        'candidate_commit_id': snapshot.get('candidate_commit_id'),
        'candidate_row_count': len(_candidate_rows(snapshot)),
        'candle_ticker_count': len(index),
        'candle_row_count': candle_count,
        'rise_prediction_canonical': canonical,
        'review_status': {
            'schema': 'review_status',
            'owner': 'review',
            'version': VERSION,
            'build': BUILD_LABEL,
            'state': canonical['state'],
            'new_shadow_created': False,
            'historical_ledgers_rewritten': False,
            'historical_trade_ledgers_deleted': False,
            'auto_buy': False,
        },
        'writer_count': 1,
        'historical_ledgers_rewritten': False,
        'historical_trade_ledgers_deleted': False,
        'new_shadow_created': False,
        'auto_buy': False,
    }
    atomic_json(STATUS, status)
    return status


def main() -> None:
    acquire_lock()
    seed_change_once()
    boot = now_ts()
    atomic_json(STATUS, {
        'schema': 'clean_review_worker_status', 'version': VERSION, 'build': BUILD_LABEL,
        'state': 'booting', 'pid': os.getpid(), 'active_owner': VERSION,
        'updated_ts': boot, 'updated_text': now_text(boot), 'writer_count': 1,
        'new_shadow_created': False, 'auto_buy': False,
    })
    while True:
        try:
            run_once()
        except Exception as exc:
            append_error('run_once', exc)
            atomic_json(STATUS, {
                'schema': 'clean_review_worker_status', 'version': VERSION, 'build': BUILD_LABEL,
                'state': 'ERROR', 'pid': os.getpid(), 'active_owner': VERSION,
                'updated_ts': now_ts(), 'updated_text': now_text(),
                'error': f'{type(exc).__name__}: {exc}', 'writer_count': 1,
                'new_shadow_created': False, 'auto_buy': False,
            })
        time.sleep(INTERVAL_SEC)


if __name__ == '__main__':
    main()
