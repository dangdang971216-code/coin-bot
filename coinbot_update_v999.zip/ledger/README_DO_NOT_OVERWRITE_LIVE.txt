Release seed only. Do not overwrite live OPEN/CLOSED/trade_log/decision/change_verify/issue ledgers.
