코인봇 v2095 · 기존 TOP10 순서판 연결 + 자주 쓰는 성과명령 속도개선

목적
- 새 Shadow를 만들지 않는다.
- 이미 누적 중인 OPEN10×cycle 1/2/3/무제한 TOP10 Shadow, v2019 exact 전체순위·선택순서 장부, v1093 실제 진입순서 감사를 한 판에 연결한다.
- 나중에 실제 OPEN 10개·cycle 1~2개 제한을 검토할 때 저장순서가 아니라 기존 검증 순서판을 근거로 사용한다.
- /version_score에서 과거 전체·모든 Shadow 정밀진단을 자동 재실행하지 않고 현재 canonical snapshot만 읽어 빠르게 표시한다.

/quality_open_audit
- 기존 v1093 코드 gap·실제 cycle 진입순서 성과 유지
- 현재 S1/eligible의 final rank 완료·누락 표시
- 기존 GLOBAL_RELATIVE / GLOBAL_RELATIVE_SYNC / INTEGRATED v2035의 cycle 1·2 exact 성과 연결
- v2019 전체 후보순위 snapshot·가상 선택순서 봉인 여부 표시
- 최소표본이 있는 cycle 1·2 선두를 표시하되 실제 selector는 변경하지 않음

/open_exposure_shadow
- 전체 OPEN 10·20·50·100의 현재 capacity를 표시
- cycle 1·2·3·5 모두 표시
- 기존 OPEN10×cycle1·2 forward 결과와 현재 capacity를 분리
- 한도 밖 후보는 삭제하지 않고 다음 cycle 새 candidate 사건으로 재평가하는 기존 원칙 유지

/version_score 속도
- 현재 epoch 성과, 현재 OPEN, 오늘/현재 TOP, 기존 TOP10 선두 요약만 현재 snapshot에서 읽음
- 과거 전체 수익원인은 /profit_audit
- 손실방어 빠른판은 /loss_defense_audit
- 전체원장 스캔은 사용자가 /loss_defense_audit_full을 직접 실행할 때만 수행

변경하지 않음
- 새 Shadow·새 generation·새 원장 없음
- 기존 TOP10/품질/구조/수익보호 Shadow 공식과 표본 보존
- 실제 Strategy/Paper selector·후보 순서 변경 없음
- 실제 OPEN 10개·cycle 1~2개 제한 미적용
- 후보 기준·S1/S2/S3·trigger·invalid·target·RR·비용·청산 변경 없음
- 기존 OPEN/CLOSED/decision/exact 원장 변경 없음
- 자동매수 OFF

판정
- 로컬 py_compile·AST·synthetic import PASS
- Main 74개 public command·74개 output profile 유지
- synthetic fixture에서 /version_score가 구 누적진단 재실행 없이 현재 snapshot만 사용
- /quality_open_audit에 기존 cycle1·2 selector 결과와 v2019 exact 순위 증거 표시
- /open_exposure_shadow에 전체10·cycle2 포함 확인
- 서버 /grelease_verify와 실제 명령 결과 전 CHECK
