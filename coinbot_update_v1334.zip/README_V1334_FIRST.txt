v1334: /exit_shadow_audit NameError 표시수리 전용. /gupgrade_bundle 먼저 적용. 전략/진입/청산/자동매수 변경 없음.
