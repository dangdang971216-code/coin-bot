v2163: direct decision key exact linkage repair, 30m/1h/3h/6h comparison, 1h/3h primary, obsolete Shadow active writers removed. Historical data preserved. Auto-buy OFF.
