v1630: Paper 후보 접수 reader 단일화 및 중복 active 해석 제거. 후보선택/Gate/RR/청산/OPEN/자동매수 변경 없음.
