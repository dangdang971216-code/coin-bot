#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations
import json, os, time, traceback
from pathlib import Path
from typing import Any, Dict, List, Optional
from collections import Counter

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
VERSION = "review_worker_v0.720"
INTERVAL_SEC = float(os.getenv("REVIEW_WORKER_INTERVAL_SEC", "30"))
RETENTION_DAYS = float(os.getenv("REVIEW_RETENTION_DAYS", "0.25"))
ACTIVE_REVIEW_MAX = int(os.getenv("REVIEW_ACTIVE_MAX", "180"))
TRIGGER_SHADOW_PENDING_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_PENDING_TTL_SEC", "900"))
TRIGGER_SHADOW_ENTERED_TTL_SEC = float(os.getenv("TRIGGER_SHADOW_ENTERED_TTL_SEC", "3600"))
TRIGGER_SHADOW_ACTIVE_MAX = int(os.getenv("TRIGGER_SHADOW_ACTIVE_MAX", "900"))
SOURCE_SNAPSHOT_LINES = int(os.getenv("REVIEW_SOURCE_SNAPSHOT_LINES", "260"))

STATUS = BASE_DIR / "clean_review_worker_status.json"
ERROR = BASE_DIR / "clean_review_worker_error.log"
CLOSED = BASE_DIR / "paper_bot_closed.jsonl"
PAPER_LATEST = BASE_DIR / "paper_candidates_latest.jsonl"
FEATURE = BASE_DIR / "clean_feature_cache.json"
ORDERFLOW = BASE_DIR / "clean_orderflow_summary_cache.json"
REGIME = BASE_DIR / "clean_market_regime_cache.json"
QUEUE = BASE_DIR / "clean_missed_review_queue.json"
STATE = BASE_DIR / "clean_missed_review_state.json"
SUMMARY = BASE_DIR / "clean_missed_review_summary.json"
OLD_SUMMARY = BASE_DIR / "clean_review_summary.json"
TRIGGER_SHADOW_CANDIDATES = BASE_DIR / "clean_trigger_shadow_candidates_v665.json"
TRIGGER_SHADOW_STATE = BASE_DIR / "clean_trigger_shadow_state_v665.json"
TRIGGER_SHADOW_SUMMARY = BASE_DIR / "clean_trigger_shadow_review_v665.json"
MARKET_MISS_CANDIDATES = BASE_DIR / "clean_market_miss_candidates_v667.json"
MARKET_MISS_STATE = BASE_DIR / "clean_market_miss_state_v667.json"
MARKET_MISS_SUMMARY = BASE_DIR / "clean_market_miss_review_v667.json"

def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default

def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default

def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)

def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out: List[Dict[str, Any]] = []
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o, dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:] + "\n")
    except Exception: pass

def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts = [p for p in t.split("-") if p]
    if len(parts) >= 2:
        non = [p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t) > 3: t = t[:-3]
    return t.strip().upper()

def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t = ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t] = r
    elif isinstance(obj, dict):
        for k, v in obj.items():
            t = ticker_norm(k)
            if t and isinstance(v, dict):
                vv = dict(v); vv.setdefault("ticker", t); out[t] = vv
    return out

def write_status(state: str, **extra: Any) -> None:
    save_json(STATUS, {"version": VERSION, "state": state, "pid": os.getpid(), "updated_ts": now_ts(), "updated_text": now_text(), **extra})

def profit(row: Dict[str, Any]) -> float:
    return fnum(row.get("profit_pct"), row.get("return_pct"), row.get("pnl_pct"), row.get("profit_rate"), default=0.0)

def _current_price(ticker: str, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> float:
    f = fmap.get(ticker, {}) or {}
    o = ofmap.get(ticker, {}) or {}
    return fnum(o.get("quote_price"), o.get("current_price"), o.get("price"), f.get("current_price"), f.get("price"), f.get("last_price"), f.get("close"), default=0.0)

def _pct(cur: float, base: float) -> float:
    return round((cur - base) / base * 100.0, 3) if cur and base else 0.0

def _risk_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """결과만 오른 위험 후보와 진짜 놓친 후보를 분리하기 위한 표시용 판정.
    조건/S1/S2/S3 기준은 바꾸지 않고 review 분류만 정리한다.
    """
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    sustain = fnum(m.get("buy_sustain_1m"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    reasons = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    risk: List[str] = []
    mild: List[str] = []
    if spread >= 0.30: risk.append(f"스프레드 {spread:.2f}%")
    elif spread >= 0.20: mild.append(f"스프레드 {spread:.2f}%")
    if slip >= 0.30: risk.append(f"미끄러짐 {slip:.2f}%")
    elif slip >= 0.20: mild.append(f"미끄러짐 {slip:.2f}%")
    if buy and buy < 0.55: risk.append(f"매수체결 {buy:.2f}")
    elif buy and buy < 0.68: mild.append(f"매수체결 {buy:.2f}")
    if sustain and sustain < 0.55: risk.append(f"1분지속 {sustain:.2f}")
    elif sustain and sustain < 0.64: mild.append(f"1분지속 {sustain:.2f}")
    for word in ("매도벽", "매도압력", "EMA5 아래", "추세 부담"):
        if word in reasons:
            risk.append(word)
    if cur_pct <= -1.00:
        risk.append(f"현재 되돌림 {cur_pct:+.2f}%")
    return {"risk": risk, "mild": mild, "is_high_risk": bool(risk), "risk_note": " / ".join(risk[:4]) if risk else (" / ".join(mild[:4]) if mild else "위험 낮음")}

def _sample_pct(rec: Dict[str, Any], label: str) -> Optional[float]:
    # label: 5m/10m/20m. direct value가 없으면 samples[label].pct를 본다.
    key = f"after_{label}_pct"
    v = rec.get(key)
    if v not in (None, ""):
        return fnum(v, default=0.0)
    samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
    sample = samples.get(label) if isinstance(samples.get(label), dict) else {}
    if sample.get("pct") not in (None, ""):
        return fnum(sample.get("pct"), default=0.0)
    return None

def _timing_profile(rec: Dict[str, Any]) -> Dict[str, Any]:
    """v457: 최고수익 착시를 분리한다.
    S1 완화/승격 근거는 5/10/20분 안에 오른 후보만 쓰기 위함이다.
    """
    a5 = _sample_pct(rec, "5m")
    a10 = _sample_pct(rec, "10m")
    a20 = _sample_pct(rec, "20m")
    vals = {"5m": a5, "10m": a10, "20m": a20}
    # 초반에 명확히 간 후보만 진짜놓침 근거로 둔다.
    early_hit = (a5 is not None and a5 >= 0.30) or (a10 is not None and a10 >= 0.50) or (a20 is not None and a20 >= 0.70)
    mild_hit = (a5 is not None and a5 >= 0.10) or (a10 is not None and a10 >= 0.20) or (a20 is not None and a20 >= 0.30)
    sample_ready = any(v is not None for v in vals.values())
    note = " / ".join(f"{k} {v:+.2f}%" for k, v in vals.items() if v is not None) or "시간표 부족"
    return {"early_hit": early_hit, "mild_hit": mild_hit, "sample_ready": sample_ready, "note": note, "samples": vals}

def _decision(rec: Dict[str, Any], elapsed: float) -> str:
    max_pct = fnum(rec.get("max_pct"), default=0.0)
    cur_pct = fnum(rec.get("current_pct"), default=0.0)
    rp = _risk_profile(rec)
    tp = _timing_profile(rec)
    rec["risk_reasons"] = rp.get("risk", [])
    rec["risk_note"] = rp.get("risk_note", "")
    rec["timing_note"] = tp.get("note", "")
    rec["timing_samples"] = tp.get("samples", {})
    if max_pct >= 1.20:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("early_hit"):
            rec["timing_class"] = "초반상승"
            return "❌ 진짜 놓친 후보"
        # 최고수익만 큰 후보는 S1 완화 근거로 쓰지 않는다.
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if max_pct >= 0.70:
        if rp.get("is_high_risk"):
            rec["timing_class"] = "위험상승"
            return "🔥 결과만 오른 위험 후보"
        if tp.get("mild_hit"):
            rec["timing_class"] = "아까움"
            return "⚠️ 아까운 후보"
        rec["timing_class"] = "늦게오름"
        return "⏳ 늦게 오른 후보"
    if elapsed >= 1200 and max_pct < 0.30:
        rec["timing_class"] = "초반무반응"
        return "✅ 안 산 게 맞음"
    if elapsed >= 300 and cur_pct <= -0.30 and max_pct < 0.50:
        rec["timing_class"] = "빠른약세"
        return "✅ 안 산 게 맞음"
    rec["timing_class"] = "추적중"
    return "❔ 추적중"

def _short_reasons(rec: Dict[str, Any]) -> str:
    reasons = rec.get("block_reasons") if isinstance(rec.get("block_reasons"), list) else []
    missing = rec.get("missing_info") if isinstance(rec.get("missing_info"), list) else []
    arr = [str(x) for x in (reasons + missing) if str(x).strip()]
    return " / ".join(arr[:3]) if arr else "-"


def _has_structure(rec: Dict[str, Any]) -> bool:
    if not isinstance(rec, dict):
        return False
    tags = rec.get("structure_tags")
    risk = rec.get("structure_risk_tags")
    fit = rec.get("structure_fit")
    return (isinstance(tags, list) and bool(tags)) or (isinstance(risk, list) and bool(risk)) or bool(str(fit or "").strip())

def _copy_structure(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_structure(src):
        return False
    st = src.get("chart_structure") if isinstance(src.get("chart_structure"), dict) else {}
    dst["structure_tags"] = src.get("structure_tags") if isinstance(src.get("structure_tags"), list) else st.get("tags", [])
    dst["structure_good_tags"] = src.get("structure_good_tags") if isinstance(src.get("structure_good_tags"), list) else st.get("good_tags", [])
    dst["structure_risk_tags"] = src.get("structure_risk_tags") if isinstance(src.get("structure_risk_tags"), list) else st.get("risk_tags", [])
    dst["structure_fit"] = str(src.get("structure_fit") or st.get("strategy_fit") or "")
    dst["structure_summary"] = str(src.get("structure_summary") or st.get("summary") or "")
    dst["chart_structure"] = st
    dst["structure_source"] = "candidate_snapshot"
    return True


def _has_market(rec: Dict[str, Any]) -> bool:
    return isinstance(rec, dict) and (isinstance(rec.get("market_regime_tags"), list) and bool(rec.get("market_regime_tags")) or bool(str(rec.get("market_regime_summary") or "").strip()))

def _copy_market(dst: Dict[str, Any], src: Dict[str, Any]) -> bool:
    if not isinstance(dst, dict) or not isinstance(src, dict) or not _has_market(src):
        return False
    mr = src.get("market_regime") if isinstance(src.get("market_regime"), dict) else {}
    dst["market_regime_tags"] = src.get("market_regime_tags") if isinstance(src.get("market_regime_tags"), list) else mr.get("tags", [])
    dst["market_risk_tags"] = src.get("market_risk_tags") if isinstance(src.get("market_risk_tags"), list) else mr.get("risk_tags", [])
    dst["market_regime_summary"] = str(src.get("market_regime_summary") or mr.get("summary") or "")
    dst["market_regime"] = mr
    dst["market_source"] = "candidate_snapshot"
    return True

def _derive_market_from_rec(rec: Dict[str, Any], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    t = ticker_norm(rec.get("ticker"))
    row = fmap.get(t, {}) if t else {}
    of = ofmap.get(t, {}) if t else {}
    tags: List[str] = []
    risks: List[str] = []
    mode = str((regime or {}).get("market_mode") or (regime or {}).get("mode") or row.get("market_mode") or of.get("market_mode") or "")
    def add(arr: List[str], x: str) -> None:
        if x and x not in arr:
            arr.append(x)
    if "강" in mode:
        add(tags, "시장강함")
    elif "약" in mode:
        add(tags, "시장약함")
    elif mode:
        add(tags, "시장보통")
    else:
        add(tags, "장세정보부족")
    pressure = str((regime or {}).get("market_pressure") or row.get("market_pressure") or of.get("market_pressure") or "")
    if "급락" in mode or "급락" in pressure:
        add(risks, "시장급락위험")
    if "과열" in mode or "과열" in pressure:
        add(risks, "시장과열")
    if "횡보" in mode or "횡보" in pressure:
        add(tags, "시장횡보")
    return {"schema":"market_regime_tags_v447_review_only", "tags":tags[:8], "risk_tags":risks[:6], "summary":(", ".join(tags[:3]) if tags else "-") + (" / 위험 " + ", ".join(risks[:2]) if risks else "")}

def _ensure_market(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> None:
    if not isinstance(rec, dict) or _has_market(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_market(rec, sources.get(t, {}) or {}):
        return
    mt = _derive_market_from_rec(rec, fmap, ofmap, regime)
    rec["market_regime"] = mt
    rec["market_regime_tags"] = mt.get("tags", [])
    rec["market_risk_tags"] = mt.get("risk_tags", [])
    rec["market_regime_summary"] = mt.get("summary", "")
    rec["market_source"] = "review_derived_display"

def _unique(items: List[str]) -> List[str]:
    out: List[str] = []
    for x in items:
        t = str(x or "").strip()
        if t and t not in out:
            out.append(t)
    return out

def _derive_structure_from_rec(rec: Dict[str, Any]) -> Dict[str, Any]:
    """기존 active review state처럼 구조태그가 없던 기록에 붙이는 표시용 보강.
    후보 차단·S1 승격·청산에는 쓰지 않는다.
    """
    text = " / ".join(str(x) for x in (rec.get("block_reasons") or []) if str(x).strip())
    strat = str(rec.get("strategy") or rec.get("strategy_key") or "")
    m = rec.get("metrics") if isinstance(rec.get("metrics"), dict) else {}
    spread = fnum(m.get("spread_pct"), default=0.0)
    slip = fnum(m.get("slippage_pct"), default=0.0)
    buy = fnum(m.get("buy_ratio"), default=0.0)
    cur = fnum(rec.get("current_pct"), default=0.0)
    maxp = fnum(rec.get("max_pct"), default=0.0)
    tags: List[str] = []
    risks: List[str] = []

    if "돈흐름" in strat or "reaccel" in strat:
        tags += ["눌림후재가속", "돈흐름재유입"]
        if "VWAP" not in text and "EMA" not in text:
            tags.append("VWAP방어")
    if "돌파" in strat or "breakout" in strat:
        tags += ["저항돌파", "저항돌파후재테스트"]
        if "돌파 후" in text or "돌파선" in text:
            tags.append("지지전환확인")
    if "저점" in strat or "VWAP 회복" in strat or "sweep" in strat:
        tags += ["저점유동성쓸림", "쓸림후빠른회복", "VWAP재회복"]
    if "주도흐름" in strat or "유동보유" in strat or "adaptive_hold" in strat:
        tags += ["얕은눌림", "VWAP방어", "EMA방어", "상대강도유지"]
    if "주도추세" in strat or "momentum" in strat:
        tags += ["고점저점상승", "추세지속", "채널하단방어"]
    if "급등" in strat or "재돌파" in strat or "rebreak" in strat:
        tags += ["급등후눌림", "고점재돌파", "돈흐름재유입"]

    if "고점권" in text and "가격반응" in text:
        risks.append("고점권가격반응약함")
    if "스프레드" in text or spread >= 0.30:
        risks.append("스프레드부담")
    if "미끄" in text or slip >= 0.30:
        risks.append("미끄러짐부담")
    if "매도벽" in text or "매도압력" in text:
        risks.append("매도압력부담")
    if "돌파 후" in text and "부족" in text:
        risks.append("가짜돌파위험")
    if cur <= -1.0 or (maxp >= 1.2 and cur < 0):
        risks.append("되돌림위험")
    if buy and buy < 0.55:
        risks.append("매수체결약함")

    if not tags:
        tags = ["구조정보부족"]
    tags = _unique(tags)[:10]
    risks = _unique(risks)[:8]
    fit = "구조좋음" if tags and tags != ["구조정보부족"] else "구조정보부족"
    severe = any(x in risks for x in ["스프레드부담", "미끄러짐부담", "매도압력부담", "되돌림위험", "매수체결약함", "가짜돌파위험"])
    if risks and fit == "구조좋음":
        fit = "구조좋음 · 위험동반" if severe else "구조관찰"
    elif risks:
        fit = "구조위험"
    return {
        "schema": "review_structure_derived_display_v447",
        "tags": tags,
        "good_tags": [t for t in tags if t != "구조정보부족"],
        "risk_tags": risks,
        "strategy_fit": fit,
        "summary": f"{fit} · 좋음 {', '.join(tags[:3]) if tags else '-'} / 위험 {', '.join(risks[:3]) if risks else '-'}",
    }

def _ensure_structure(rec: Dict[str, Any], sources: Dict[str, Dict[str, Any]]) -> None:
    if not isinstance(rec, dict) or _has_structure(rec):
        return
    t = ticker_norm(rec.get("ticker"))
    if t and _copy_structure(rec, sources.get(t, {}) or {}):
        return
    st = _derive_structure_from_rec(rec)
    rec["chart_structure"] = st
    rec["structure_tags"] = st.get("tags", [])
    rec["structure_good_tags"] = st.get("good_tags", [])
    rec["structure_risk_tags"] = st.get("risk_tags", [])
    rec["structure_fit"] = st.get("strategy_fit", "")
    rec["structure_summary"] = st.get("summary", "")
    rec["structure_source"] = "review_derived_display"

def _summ_rows(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    rows = sorted(rows, key=lambda r: (fnum(r.get("max_pct"), default=0.0), fnum(r.get("score"), default=0.0)), reverse=True)
    out = []
    for r in rows[:limit]:
        out.append({
            "ticker": r.get("ticker"), "stage": r.get("stage"), "strategy": r.get("strategy"),
            "score": r.get("score"), "decision": r.get("decision"),
            "first_price": r.get("first_price"), "current_price": r.get("current_price"),
            "current_pct": r.get("current_pct"), "max_pct": r.get("max_pct"),
            "after_5m_pct": r.get("after_5m_pct"), "after_10m_pct": r.get("after_10m_pct"), "after_20m_pct": r.get("after_20m_pct"),
            "first_seen_ts": r.get("first_seen_ts"), "first_seen_text": r.get("first_seen_text"),
            "last_seen_ts": r.get("last_seen_ts"), "last_seen_text": r.get("last_seen_text"),
            "max_seen_ts": r.get("max_seen_ts"), "max_seen_text": r.get("max_seen_text"),
            "reasons": _short_reasons(r),
            "risk_note": r.get("risk_note", ""),
            "risk_reasons": r.get("risk_reasons", []),
            "structure_tags": r.get("structure_tags", []),
            "structure_good_tags": r.get("structure_good_tags", []),
            "structure_risk_tags": r.get("structure_risk_tags", []),
            "structure_fit": r.get("structure_fit", ""),
            "structure_summary": r.get("structure_summary", ""),
            "chart_structure": r.get("chart_structure", {}),
            "market_regime_tags": r.get("market_regime_tags", []),
            "market_risk_tags": r.get("market_risk_tags", []),
            "market_regime_summary": r.get("market_regime_summary", ""),
            "market_regime": r.get("market_regime", {}),
            "review_class": r.get("decision", ""),
            "timing_class": r.get("timing_class", ""),
            "timing_note": r.get("timing_note", ""),
            "timing_samples": r.get("timing_samples", {}),
        })
    return out

def _reason_top(rows: List[Dict[str, Any]], limit: int = 8) -> List[Dict[str, Any]]:
    cnt: Dict[str, int] = {}
    for r in rows:
        for x in (r.get("block_reasons") or []):
            key = str(x).split()[0].strip() or str(x).strip()
            if key: cnt[key] = cnt.get(key, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(cnt.items(), key=lambda kv: kv[1], reverse=True)[:limit]]

def _close_item_from_trade(r: Dict[str, Any], tag: str, give: float, sources: Dict[str, Dict[str, Any]], fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]], regime: Dict[str, Any]) -> Dict[str, Any]:
    item = {"ticker": ticker_norm(r.get("ticker")), "peak_pct": fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0), "pnl_pct": fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0), "giveback_pct": round(give,3), "reason": r.get("exit_reason"), "tag": r.get("close_review_tag") or tag}
    # closed row 자체의 entry_context/snapshot 구조를 우선 복사하고, 없으면 현재 후보 snapshot 또는 표시용 파생값을 붙인다.
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    snap = r.get("entry_snapshot") if isinstance(r.get("entry_snapshot"), dict) else {}
    flat = snap.get("flat") if isinstance(snap.get("flat"), dict) else {}
    src = dict(r)
    for k in ("chart_structure", "structure_tags", "structure_good_tags", "structure_risk_tags", "structure_fit", "structure_summary", "market_regime", "market_regime_tags", "market_risk_tags", "market_regime_summary"):
        if k not in src and k in ctx: src[k] = ctx[k]
        if k not in src and k in flat: src[k] = flat[k]
    if _has_structure(src):
        _copy_structure(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_structure(item, sources.get(t, {}) or {})
        _ensure_structure(item, sources)
    if _has_market(src):
        _copy_market(item, src)
    else:
        t = ticker_norm(item.get("ticker"))
        if t:
            _copy_market(item, sources.get(t, {}) or {})
        _ensure_market(item, sources, fmap, ofmap, regime)
    return item

def _legacy_closed_summary(sources: Optional[Dict[str, Dict[str, Any]]]=None, fmap: Optional[Dict[str, Dict[str, Any]]]=None, ofmap: Optional[Dict[str, Dict[str, Any]]]=None, regime: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    sources = sources or {}; fmap = fmap or {}; ofmap = ofmap or {}; regime = regime or {}
    rows = read_jsonl(CLOSED, max_lines=360)
    def pnl(r: Dict[str, Any]) -> float: return fnum(r.get("pnl_pct"), r.get("profit_pct"), default=0.0)
    def peak(r: Dict[str, Any]) -> float: return fnum(r.get("peak_pct"), r.get("max_profit_pct"), default=0.0)
    protect_needed=[]; fast_fail=[]; good_keep=[]
    for r in rows[-80:]:
        pk=peak(r); pn=pnl(r); give=max(0.0, pk-pn)
        if pk >= 0.70 and (pn < 0 or give >= 0.55):
            protect_needed.append(_close_item_from_trade(r, "보호익절 필요 후보", give, sources, fmap, ofmap, regime))
        elif pn <= -0.60 and pk < 0.25:
            fast_fail.append(_close_item_from_trade(r, "빠른실패 정리 후보", give, sources, fmap, ofmap, regime))
        elif pn > 0 and pk-pn <= 0.35:
            good_keep.append(_close_item_from_trade(r, "수익 보존 양호", give, sources, fmap, ofmap, regime))
    big_loss = sorted([r for r in rows if profit(r) <= -0.8], key=profit)[:10]
    good_win = sorted([r for r in rows if profit(r) >= 1.0], key=profit, reverse=True)[:10]
    return {"closed_recent": len(rows), "big_loss": len(big_loss), "good_win": len(good_win), "close_review": {"protect_needed_count": len(protect_needed), "fast_fail_count": len(fast_fail), "good_keep_count": len(good_keep), "protect_needed": protect_needed[-5:], "fast_fail": fast_fail[-5:], "good_keep": good_keep[-5:]}}



# v655: review_worker는 후보판단/장부 주인이 아니라 복기 요약 주인이다.
# paper CLOSED 장부는 삭제하지 않고, active missed-review state에서 의미 낮은 추적만 빨리 순환한다.
def _v655_keep_active_review(rec: Dict[str, Any], nowv: float, base_ttl: float) -> bool:
    if not isinstance(rec, dict):
        return False
    first = fnum(rec.get("first_seen_ts"), default=nowv)
    age = max(0.0, nowv - first)
    cls = str(rec.get("decision") or rec.get("review_class") or rec.get("review_hint") or "")
    maxp = fnum(rec.get("max_pct"), default=0.0)
    curp = fnum(rec.get("current_pct"), default=0.0)
    # 중요한 복기 후보는 기존 보관기한 유지.
    if any(w in cls for w in ("진짜 놓친", "아까운", "위험 후보", "위험상승")):
        return age <= base_ttl
    # 늦게 오른 후보/큰 변동 후보는 전략 보정 참고용으로 몇 시간만 유지.
    if "늦게 오른" in cls or maxp >= 0.70 or abs(curp) >= 1.00:
        return age <= min(base_ttl, 6 * 3600.0)
    # 추적중/안 산 게 맞음은 디스크·CPU를 잡아먹지 않게 짧게 순환.
    if "추적중" in cls or not cls:
        return age <= min(base_ttl, 90 * 60.0)
    if "안 산 게 맞음" in cls:
        return age <= min(base_ttl, 45 * 60.0)
    return age <= min(base_ttl, 2 * 3600.0)



def _v664_prune_active_size(active: Dict[str, Dict[str, Any]], nowv: float, max_keep: int = ACTIVE_REVIEW_MAX) -> Dict[str, Dict[str, Any]]:
    """v664: active missed-review state 크기 제한.
    paper CLOSED 장부는 손대지 않고, 상태 추적용 active dict만 핵심/최근 후보 위주로 유지한다.
    """
    if not isinstance(active, dict) or len(active) <= max_keep:
        return active
    important_words = ("진짜 놓친", "아까운", "위험 후보", "위험상승", "늦게 오른")
    rows = []
    for k, v in active.items():
        if not isinstance(v, dict):
            continue
        cls = str(v.get('decision') or v.get('review_class') or v.get('review_hint') or '')
        imp = 1 if any(w in cls for w in important_words) else 0
        maxp = fnum(v.get('max_pct'), default=0.0)
        curp = abs(fnum(v.get('current_pct'), default=0.0))
        last = fnum(v.get('last_seen_ts'), v.get('first_seen_ts'), default=0.0)
        score = imp * 1000000.0 + maxp * 1000.0 + curp * 300.0 + last / 100000.0
        rows.append((score, k, v))
    rows.sort(key=lambda x: x[0], reverse=True)
    kept = {k: v for _, k, v in rows[:max_keep]}
    return kept


# =============================================================================
# review_worker v0.14 / v665: trigger shadow benchmark 추적
# - strategy_worker가 만든 shadow 후보를 읽어 이후 가격 경로를 비교한다.
# - 실제 paper OPEN/장부/청산은 바꾸지 않는다.
# =============================================================================

def _v665_variant_key(c: Dict[str, Any], variant: Dict[str, Any]) -> str:
    return '|'.join(str(x or '-') for x in (c.get('shadow_key_base'), variant.get('key')))



def _v678_trigger_shadow_score(rec: Dict[str, Any], nowv: float) -> float:
    try:
        entered = 1 if bool(rec.get('entered')) else 0
        maxp = fnum(rec.get('max_pct'), default=0.0)
        curp = abs(fnum(rec.get('current_pct'), default=0.0))
        last = fnum(rec.get('last_seen_ts'), rec.get('first_seen_ts'), default=nowv)
        sampled = len(rec.get('samples') if isinstance(rec.get('samples'), dict) else {})
        return entered * 1000000.0 + sampled * 200000.0 + maxp * 1000.0 + curp * 200.0 + last / 100000.0
    except Exception:
        return 0.0


def _v678_prune_trigger_shadow_active(active: Dict[str, Dict[str, Any]], nowv: float) -> Dict[str, Dict[str, Any]]:
    """trigger shadow는 검증용 state라 오래 들고 있지 않는다. touched라고 TTL을 무시하지 않는다."""
    ttl_entered = max(600.0, TRIGGER_SHADOW_ENTERED_TTL_SEC)
    ttl_pending = max(300.0, TRIGGER_SHADOW_PENDING_TTL_SEC)
    max_keep = max(100, TRIGGER_SHADOW_ACTIVE_MAX)
    kept = {}
    for k, rec in (active or {}).items():
        if not isinstance(rec, dict):
            continue
        first = fnum(rec.get('first_seen_ts'), default=nowv)
        age = max(0.0, nowv - first)
        entered = bool(rec.get('entered'))
        if entered and age <= ttl_entered:
            kept[k] = rec
        elif (not entered) and age <= ttl_pending:
            kept[k] = rec
    if len(kept) <= max_keep:
        return kept
    ranked = sorted(kept.items(), key=lambda kv: _v678_trigger_shadow_score(kv[1], nowv), reverse=True)
    return {k: v for k, v in ranked[:max_keep]}

def _v665_trigger_shadow_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(TRIGGER_SHADOW_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    state_obj = load_json(TRIGGER_SHADOW_STATE, {}) or {}
    active = state_obj.get('active') if isinstance(state_obj, dict) and isinstance(state_obj.get('active'), dict) else {}
    touched = set()
    # 기존 state 정리 TTL: 미진입 30분, 진입 40분 이후 요약만 남김
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = ticker_norm(c.get('ticker'))
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        if not cur:
            cur = fnum(c.get('current_price'), default=0.0)
        for var in c.get('variants') or []:
            if not isinstance(var, dict):
                continue
            k = _v665_variant_key(c, var)
            touched.add(k)
            threshold = fnum(var.get('threshold_price'), default=0.0)
            rec = active.get(k) if isinstance(active.get(k), dict) else None
            if not rec:
                rec = {
                    'schema': 'trigger_shadow_variant_state_v665',
                    'key': k,
                    'ticker': t,
                    'variant': var.get('key'),
                    'variant_label': var.get('label'),
                    'entry_mode': var.get('entry_mode'),
                    'threshold_price': threshold,
                    'first_seen_ts': nowv,
                    'first_seen_text': now_text(nowv),
                    'source': c.get('trigger_source'),
                    'stage': c.get('stage'),
                    'coin_quality_score': c.get('coin_quality_score'),
                    'trigger_price': c.get('trigger_price'),
                    'trigger_gap_pct': c.get('trigger_gap_pct'),
                    'entered': False,
                    'samples': {},
                    'max_pct': 0.0,
                    'min_pct': 0.0,
                    'policy': 'v665 shadow only. 실제 주문/장부 변경 없음.',
                }
            rec['last_seen_ts'] = nowv
            rec['last_seen_text'] = now_text(nowv)
            rec['latest_price'] = cur
            # 진입 판정: immediate는 첫 가격, threshold는 해당 가격 이상 도달 시 가상진입.
            if not rec.get('entered') and cur:
                if str(var.get('entry_mode')) == 'immediate' or (threshold and cur >= threshold):
                    rec['entered'] = True
                    rec['entry_ts'] = nowv
                    rec['entry_text'] = now_text(nowv)
                    rec['entry_price'] = cur
                    rec['entry_reason'] = 'immediate_current' if str(var.get('entry_mode')) == 'immediate' else 'threshold_reached'
            if rec.get('entered') and cur:
                entry = fnum(rec.get('entry_price'), default=0.0)
                pct = _pct(cur, entry)
                rec['current_pct'] = pct
                rec['max_pct'] = max(fnum(rec.get('max_pct'), default=pct), pct)
                rec['min_pct'] = min(fnum(rec.get('min_pct'), default=pct), pct)
                elapsed = max(0.0, nowv - fnum(rec.get('entry_ts'), default=nowv))
                samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
                for label, sec in (('3m',180),('5m',300),('10m',600),('20m',1200)):
                    if elapsed >= sec and label not in samples:
                        samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': pct, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
                rec['samples'] = samples
            else:
                wait = max(0.0, nowv - fnum(rec.get('first_seen_ts'), default=nowv))
                rec['wait_sec'] = round(wait, 1)
                if wait >= 1200:
                    rec['not_entered_timeout'] = True
            active[k] = rec
    # v678 active pruning owner
    # 이전 구경로는 k in touched면 TTL을 넘어도 계속 살려 active가 수천 개로 누적됐다.
    # touched 예외를 삭제하고, entered/pending TTL + 서버보호 safety cap으로 단일화한다.
    before_shadow_active = len(active)
    active = _v678_prune_trigger_shadow_active(active, nowv)
    pruned_shadow_active = max(0, before_shadow_active - len(active))
    rows = list(active.values())
    entered = [r for r in rows if r.get('entered')]
    pending = [r for r in rows if not r.get('entered')]
    by_variant: Dict[str, List[Dict[str, Any]]] = {}
    for r in rows:
        by_variant.setdefault(str(r.get('variant') or '-'), []).append(r)
    variant_summary = {}
    for vk, arr in by_variant.items():
        ent = [r for r in arr if r.get('entered')]
        variant_summary[vk] = {
            'total': len(arr),
            'entered': len(ent),
            'pending': len(arr) - len(ent),
            'avg_max_pct': round(sum(fnum(r.get('max_pct'), default=0.0) for r in ent) / len(ent), 3) if ent else 0.0,
            'win_0_3_count': sum(1 for r in ent if fnum(r.get('max_pct'), default=0.0) >= 0.30),
            'loss_0_3_count': sum(1 for r in ent if fnum(r.get('min_pct'), default=0.0) <= -0.30),
        }
    top = sorted(entered, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:8]
    summary = {
        'schema': 'trigger_shadow_review_v665',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'active_count': len(rows),
        'entered_count': len(entered),
        'pending_count': len(pending),
        'pruned_count_v678': pruned_shadow_active,
        'active_max_v678': TRIGGER_SHADOW_ACTIVE_MAX,
        'ttl_entered_sec_v678': TRIGGER_SHADOW_ENTERED_TTL_SEC,
        'ttl_pending_sec_v678': TRIGGER_SHADOW_PENDING_TTL_SEC,
        'variant_summary': variant_summary,
        'top_entered': [{k:r.get(k) for k in ('ticker','variant','variant_label','source','stage','coin_quality_score','entry_price','latest_price','current_pct','max_pct','min_pct')} for r in top],
        'policy': 'v678 trigger shadow hot/cold. 실제 S1/paper OPEN/청산/자동매수 변경 없음. touched TTL 예외 삭제.',
    }
    save_json(TRIGGER_SHADOW_STATE, {'schema':'trigger_shadow_state_v665', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(TRIGGER_SHADOW_SUMMARY, summary)
    return summary



# =============================================================================
# review_worker v0.15 / v667: whole-market missed-scan review
# - strategy_worker가 저장한 전체 canonical snapshot을 추적해 3/5/10분 뒤 상승 후보가 어디서 묻혔는지 본다.
# - 실제 paper 장부/OPEN/청산/자동매수는 변경하지 않는다.
# =============================================================================

def _v667_miss_key(c: Dict[str, Any]) -> str:
    return ticker_norm(c.get('ticker'))


def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    # v668: always publish a visible summary, even before 3/5/10m maturity.
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    # TTL: 최근 35분만 추적. 전체 456개를 보되 ticker별 1개 state만 유지한다.
    ttl = 35 * 60.0
    active = {k:v for k,v in active.items() if isinstance(v, dict) and nowv - fnum(v.get('first_seen_ts'), default=nowv) <= ttl}
    for c in candidates:
        if not isinstance(c, dict):
            continue
        t = _v667_miss_key(c)
        if not t:
            continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get('snapshot_price'), default=0.0) or cur
        if not base:
            continue
        rec = active.get(t)
        if not isinstance(rec, dict):
            rec = {
                'schema': 'market_miss_state_row_v667',
                'ticker': t,
                'first_seen_ts': nowv,
                'first_seen_text': now_text(nowv),
                'first_price': base,
                'min_pct': 0.0,
                'max_pct': 0.0,
                'samples': {},
            }
        rec.update({
            'last_seen_ts': nowv,
            'last_seen_text': now_text(nowv),
            'initial_stage': c.get('initial_stage'),
            'coin_quality_score': c.get('coin_quality_score'),
            'execution_risk_score': c.get('execution_risk_score'),
            'miss_bucket': c.get('miss_bucket'),
            'initial_reason': c.get('initial_reason'),
            'trigger_source': c.get('trigger_source'),
            'trigger_gap_pct': c.get('trigger_gap_pct'),
            'coverage_only': c.get('coverage_only'),
        })
        if cur:
            rec['latest_price'] = cur
            cp = _pct(cur, fnum(rec.get('first_price'), default=base))
            rec['current_pct'] = cp
            rec['max_pct'] = max(fnum(rec.get('max_pct'), default=cp), cp)
            rec['min_pct'] = min(fnum(rec.get('min_pct'), default=cp), cp)
            elapsed = nowv - fnum(rec.get('first_seen_ts'), default=nowv)
            rec['age_sec'] = round(elapsed, 1)
            samples = rec.get('samples') if isinstance(rec.get('samples'), dict) else {}
            for label, sec in (('3m',180),('5m',300),('10m',600)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {'ts': nowv, 'text': now_text(nowv), 'price': cur, 'pct': cp, 'max_pct': rec.get('max_pct'), 'min_pct': rec.get('min_pct')}
            rec['samples'] = samples
            # 분류: 오른 후보가 왜 안 샀는지. 위험 낮고 품질 높으면 진짜 놓침 가능성.
            maxp = fnum(rec.get('max_pct'), default=0.0)
            risk = fnum(rec.get('execution_risk_score'), default=0.0)
            q = fnum(rec.get('coin_quality_score'), default=0.0)
            bucket = str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',):
                rec['miss_decision'] = '❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate':
                rec['miss_decision'] = '✅ 위험필터_성공검토'
            elif maxp >= 0.40:
                rec['miss_decision'] = '⚠️ 아까운상승'
            else:
                rec['miss_decision'] = '관찰중'
        active[t] = rec
    rows = list(active.values())
    matured = [r for r in rows if fnum(r.get('age_sec'), default=0) >= 180]
    risers = [r for r in rows if fnum(r.get('max_pct'), default=0) >= 0.40]
    true_missed = [r for r in rows if str(r.get('miss_decision')) == '❌ 진짜놓침_후보']
    buckets = Counter(str(r.get('miss_bucket') or '-') for r in risers)
    stages = Counter(str(r.get('initial_stage') or '-') for r in rows)
    decisions = Counter(str(r.get('miss_decision') or '-') for r in rows)
    top = sorted(risers, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]
    true_top = sorted(true_missed, key=lambda r: fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
    def slim(r: Dict[str, Any]) -> Dict[str, Any]:
        return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','execution_risk_score','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_gap_pct')}
    summary = {
        'schema': 'market_miss_review_v671_tracking_fixed',
        'version': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'candidate_source_age_sec': round(nowv - fnum(cand_obj.get('updated_ts'), default=nowv), 1) if isinstance(cand_obj, dict) else None,
        'tracking_total': len(rows),
        'matured_count': len(matured),
        'rise_count': len(risers),
        'true_missed_count': len(true_missed),
        'candidate_source_count': len(candidates),
        'active_saved_count': len(rows),
        'price_source': 'orderflow/feature current price + snapshot fallback',
        'tracking_waiting_3m': sum(1 for r in rows if fnum(r.get('age_sec'), default=0) < 180),
        'miss_bucket_counts': dict(buckets.most_common(10)),
        'initial_stage_counts': dict(stages.most_common(6)),
        'decision_counts': dict(decisions.most_common(8)),
        'recheck_lane_counts': dict(Counter(str(r.get('miss_bucket') or '-') for r in rows if str(r.get('miss_decision')) in ('❌ 진짜놓침_후보','⚠️ 아까운상승')).most_common(10)),
        'top_risers': [slim(r) for r in top],
        'true_missed_top': [slim(r) for r in true_top],
        'policy': 'v671: Counter import/runtime error 복구 + 전체 456 놓침검증 추적 상태를 항상 저장/표시. 실제 S1/paper OPEN/청산/자동매수 변경 없음.',
    }
    save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v671_tracking_fixed', 'version':VERSION, 'updated_ts':nowv, 'updated_text':now_text(nowv), 'active':active})
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary

def run_once() -> Dict[str, Any]:
    st = now_ts(); write_status("running", phase="refreshing", last_sec=0)
    queue = load_json(QUEUE, {}) or {}
    qrows = queue.get("review_candidates") if isinstance(queue, dict) and isinstance(queue.get("review_candidates"), list) else []
    # v446: review state에 이미 들어간 구 후보도 구조태그가 보이도록 현재 후보 snapshot/queue와 표시용 파생값으로 보강한다.
    source_rows = [r for r in read_jsonl(PAPER_LATEST, max_lines=SOURCE_SNAPSHOT_LINES) if isinstance(r, dict)] + [r for r in qrows if isinstance(r, dict)]
    structure_sources: Dict[str, Dict[str, Any]] = {}
    for sr in source_rows:
        tt = ticker_norm(sr.get("ticker") or sr.get("symbol") or sr.get("market"))
        if tt and (_has_structure(sr) or _has_market(sr)):
            structure_sources[tt] = sr
    state = load_json(STATE, {}) or {}
    active = state.get("active") if isinstance(state.get("active"), dict) else {}
    fmap = map_rows(load_json(FEATURE, {}) or {})
    ofmap = map_rows(load_json(ORDERFLOW, {}) or {})
    regime = load_json(REGIME, {}) or {}
    nowv = now_ts()
    try:
        trigger_shadow_v665 = _v665_trigger_shadow_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v665_trigger_shadow_update", exc)
        trigger_shadow_v665 = {"schema":"trigger_shadow_review_v665_error", "error": f"{exc.__class__.__name__}: {exc}"}
    try:
        market_miss_v667 = _v667_market_miss_update(nowv, fmap, ofmap)
    except Exception as exc:
        append_error(ERROR, "v667_market_miss_update", exc)
        market_miss_v667 = {"schema":"market_miss_review_v667_error", "error": f"{exc.__class__.__name__}: {exc}"}
    ttl = max(3600.0, RETENTION_DAYS * 86400.0)
    # 오래된 비핵심 복기 state만 제거. paper 장부는 삭제하지 않음.
    before_active = len(active)
    active = {k:v for k,v in active.items() if _v655_keep_active_review(v, nowv, ttl)}
    active = _v664_prune_active_size(active, nowv, ACTIVE_REVIEW_MAX)
    pruned_active = max(0, before_active - len(active))

    for c in qrows:
        if not isinstance(c, dict): continue
        stage = str(c.get("stage") or "").upper()
        if stage not in ("S2", "S3"): continue
        t = ticker_norm(c.get("ticker"))
        if not t: continue
        cur = _current_price(t, fmap, ofmap)
        base = fnum(c.get("snapshot_price"), c.get("price"), default=0.0) or cur
        rec = active.get(t) or {
            "ticker": t, "first_seen_ts": nowv, "first_seen_text": now_text(nowv),
            "first_price": base, "min_pct": 0.0, "max_pct": 0.0,
            "max_seen_ts": nowv, "max_seen_text": now_text(nowv), "samples": {},
        }
        rec.update({
            "stage": stage, "strategy": c.get("strategy"), "strategy_key": c.get("strategy_key"),
            "score": c.get("score"), "block_reasons": c.get("block_reasons", []),
            "missing_info": c.get("missing_info", []), "metrics": c.get("metrics", {}),
            "structure_tags": c.get("structure_tags", []),
            "structure_good_tags": c.get("structure_good_tags", []),
            "structure_risk_tags": c.get("structure_risk_tags", []),
            "structure_fit": c.get("structure_fit", ""),
            "structure_summary": c.get("structure_summary", ""),
            "chart_structure": c.get("chart_structure", {}),
            "last_seen_ts": nowv, "last_seen_text": now_text(nowv),
        })
        if not fnum(rec.get("first_price"), default=0.0) and base:
            rec["first_price"] = base
        if cur:
            rec["current_price"] = cur
            cp = _pct(cur, fnum(rec.get("first_price"), default=0.0))
            rec["current_pct"] = cp
            prev_max = fnum(rec.get("max_pct"), default=cp)
            if cp >= prev_max:
                rec["max_seen_ts"] = nowv
                rec["max_seen_text"] = now_text(nowv)
            rec["max_pct"] = max(prev_max, cp)
            rec["min_pct"] = min(fnum(rec.get("min_pct"), default=cp), cp)
            elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
            samples = rec.get("samples") if isinstance(rec.get("samples"), dict) else {}
            for label, sec in (("5m",300),("10m",600),("20m",1200)):
                if elapsed >= sec and label not in samples:
                    samples[label] = {"ts": nowv, "text": now_text(nowv), "price": cur, "pct": cp}
                    rec[f"after_{label}_pct"] = cp
            rec["samples"] = samples
            rec["decision"] = _decision(rec, elapsed)
        active[t] = rec

    # v441: active state에 남은 구 decision/review_hint를 그대로 쓰지 않는다.
    # 현재 max/current/위험프로필 기준으로 다시 분류해 /review 상단 count와 후보별 문구가 어긋나지 않게 한다.
    for rec in active.values():
        if not isinstance(rec, dict):
            continue
        _ensure_structure(rec, structure_sources)
        _ensure_market(rec, structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {})
        elapsed = nowv - fnum(rec.get("first_seen_ts"), default=nowv)
        rec["decision"] = _decision(rec, elapsed)
        rec["review_class"] = rec["decision"]
        rec["review_hint"] = rec["decision"]
    all_rows = list(active.values())
    missed = [r for r in all_rows if str(r.get("decision")) == "❌ 진짜 놓친 후보"]
    regret = [r for r in all_rows if str(r.get("decision")) == "⚠️ 아까운 후보"]
    late_rise = [r for r in all_rows if str(r.get("decision")) == "⏳ 늦게 오른 후보"]
    risk_rise = [r for r in all_rows if str(r.get("decision")) == "🔥 결과만 오른 위험 후보"]
    correct = [r for r in all_rows if str(r.get("decision")) == "✅ 안 산 게 맞음"]
    done = {"❌ 진짜 놓친 후보", "⚠️ 아까운 후보", "⏳ 늦게 오른 후보", "🔥 결과만 오른 위험 후보", "✅ 안 산 게 맞음"}
    pending = [r for r in all_rows if str(r.get("decision")) not in done]
    legacy = _legacy_closed_summary(structure_sources, fmap, ofmap, regime if isinstance(regime, dict) else {})
    summary = {
        "schema": "missed_review_summary_v457_timing_split",
        "version": VERSION,
        "updated_ts": nowv, "updated_text": now_text(nowv),
        "queue_age_sec": round(nowv - fnum(queue.get("updated_ts"), default=nowv), 1) if isinstance(queue, dict) else None,
        "tracking_total": len(all_rows), "queue_candidates": len(qrows),
        "missed_count": len(missed), "regret_count": len(regret), "late_rise_count": len(late_rise), "risk_rise_count": len(risk_rise), "correct_count": len(correct), "pending_count": len(pending),
        "missed": _summ_rows(missed, 8), "regret": _summ_rows(regret, 8), "late_rise": _summ_rows(late_rise, 8), "risk_rise": _summ_rows(risk_rise, 8), "correct": _summ_rows(correct, 5), "pending": _summ_rows(pending, 8),
        "missed_reason_top": _reason_top(missed + regret, 8),
        "v655_active_pruned": pruned_active,
        "v655_policy": "중요 복기 후보는 유지하고 추적중/안산게맞음 active state만 짧게 순환해 CPU를 줄임. paper 장부 삭제 없음.",
        "v664_active_max": ACTIVE_REVIEW_MAX,
        "v664_source_snapshot_lines": SOURCE_SNAPSHOT_LINES,
        "v664_policy": "review_worker는 paper 장부를 지우지 않고 active missed-review 상태만 핵심/최근 후보 중심으로 제한해 CPU를 줄임.",
        "trigger_shadow_v665": trigger_shadow_v665,
        "market_miss_v667": market_miss_v667,
        "late_rise_reason_top": _reason_top(late_rise, 8),
        "risk_rise_reason_top": _reason_top(risk_rise, 8),
        "policy": "v457: 최고수익 착시를 분리한다. 진짜놓침은 5/10/20분 안에 상승한 후보만 남기고, 늦게 오른 후보는 S1 완화 근거에서 제외한다. 조건/청산숫자/paper 장부 변경 없음.",
        **legacy,
    }
    save_json(STATE, {"schema":"missed_review_state_v457_timing_split", "version":VERSION, "updated_ts":nowv, "active":active})
    save_json(SUMMARY, summary)
    save_json(OLD_SUMMARY, {"version":VERSION, "updated_ts":nowv, "updated_text":now_text(nowv), **legacy, "missed_review": summary})
    sec = now_ts() - st
    write_status("running", tracked=len(all_rows), missed=len(missed), regret=len(regret), late_rise=len(late_rise), risk_rise=len(risk_rise), correct=len(correct), pending=len(pending), closed_recent=legacy.get("closed_recent",0), big_loss=legacy.get("big_loss",0), good_win=legacy.get("good_win",0), active_pruned=pruned_active, active_max=ACTIVE_REVIEW_MAX, source_snapshot_lines=SOURCE_SNAPSHOT_LINES, trigger_shadow_active=(trigger_shadow_v665 or {}).get("active_count",0), trigger_shadow_entered=(trigger_shadow_v665 or {}).get("entered_count",0), trigger_shadow_pruned=(trigger_shadow_v665 or {}).get("pruned_count_v678",0), market_miss_tracking=(market_miss_v667 or {}).get("tracking_total",0), market_miss_rise=(market_miss_v667 or {}).get("rise_count",0), last_sec=round(sec,3), structure_enriched=sum(1 for r in active.values() if isinstance(r, dict) and _has_structure(r)))
    return {"tracked": len(all_rows), "missed": len(missed), "regret": len(regret), "late_rise": len(late_rise), "correct": len(correct)}

def main() -> None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc:
            append_error(ERROR, "loop", exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(10.0, INTERVAL_SEC))

# =============================================================================
# review_worker v0.19 / v675: preserve canonical values in missed-review state
# =============================================================================
VERSION = "review_worker_v0.720"

def _v675_first(*vals: Any, default: Any=None) -> Any:
    for v in vals:
        if v not in (None, '', '-', [], {}): return v
    return default

_v675_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v675_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}; candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
        by_ticker = {ticker_norm(c.get('ticker')): c for c in candidates if isinstance(c, dict) and ticker_norm(c.get('ticker'))}
        state = load_json(MARKET_MISS_STATE, {}) or {}; active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
        for t, rec in list(active.items()):
            if not isinstance(rec, dict): continue
            c = by_ticker.get(t) or {}
            rec['coin_quality_score'] = fnum(_v675_first(c.get('coin_quality_score'), c.get('q'), rec.get('coin_quality_score')), default=0.0); rec['q'] = rec['coin_quality_score']
            rec['execution_risk_score'] = fnum(_v675_first(c.get('execution_risk_score'), c.get('risk'), rec.get('execution_risk_score')), default=0.0); rec['risk'] = rec['execution_risk_score']
            for k in ('trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec'):
                if c.get(k) not in (None, '', '-'): rec[k] = c.get(k)
            maxp = fnum(rec.get('max_pct'), default=0.0); q=fnum(rec.get('coin_quality_score'), default=0.0); risk=fnum(rec.get('execution_risk_score'), default=0.0); bucket=str(rec.get('miss_bucket') or '-')
            if maxp >= 0.70 and q >= 60 and risk <= 40 and bucket not in ('risk_filter_candidate',): rec['miss_decision']='❌ 진짜놓침_후보'
            elif maxp >= 0.70 and bucket == 'risk_filter_candidate': rec['miss_decision']='✅ 위험필터_성공검토'
            elif maxp >= 0.40: rec['miss_decision']='⚠️ 아까운상승'
            else: rec['miss_decision']='관찰중'
            active[t]=rec
        rows=list(active.values()); matured=[r for r in rows if fnum(r.get('age_sec'), default=0)>=180]; risers=[r for r in rows if fnum(r.get('max_pct'), default=0)>=0.40]; true_missed=[r for r in rows if str(r.get('miss_decision'))=='❌ 진짜놓침_후보']
        buckets=Counter(str(r.get('miss_bucket') or '-') for r in risers); decisions=Counter(str(r.get('miss_decision') or '-') for r in rows)
        def slim(r: Dict[str, Any]) -> Dict[str, Any]:
            return {k:r.get(k) for k in ('ticker','initial_stage','miss_bucket','miss_decision','coin_quality_score','q','execution_risk_score','risk','first_price','latest_price','current_pct','max_pct','min_pct','age_sec','initial_reason','trigger_source','trigger_confidence','trigger_gap_pct','price_reaction_pct','buy_ratio','buy_sustain_1m','spread_pct','slippage_pct','candle_age_sec')}
        top=sorted(risers, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:12]; true_top=sorted(true_missed, key=lambda r:fnum(r.get('max_pct'), default=0.0), reverse=True)[:10]
        summary=dict(summary or {}); summary.update({'schema':'market_miss_review_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'tracking_total':len(rows),'matured_count':len(matured),'rise_count':len(risers),'true_missed_count':len(true_missed),'miss_bucket_counts':dict(buckets.most_common(10)),'decision_counts':dict(decisions.most_common(8)),'top_risers':[slim(r) for r in top],'true_missed_top':[slim(r) for r in true_top],'value_enriched_v675':True,'policy':'v675: missed candidates keep Q/R/trigger/execution values from canonical candidate snapshot. 실제 S1/paper OPEN/청산/자동매수 변경 없음.'})
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v675_value_enriched','version':VERSION,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active}); save_json(MARKET_MISS_SUMMARY, summary)
    except Exception as exc: append_error(ERROR, 'v675_market_miss_value_enrich', exc)
    return summary


# =============================================================================
# review_worker v0.20 / v676: market-miss CPU cache guard
# - Keep whole-market review, but do not rebuild the expensive 456-row maturity
#   summary every loop when the cache is still fresh.
# =============================================================================
VERSION = "review_worker_v0.720"
V676_MARKET_MISS_MIN_REFRESH_SEC = float(os.getenv('REVIEW_MARKET_MISS_MIN_REFRESH_SEC', '25'))
_v676_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    try:
        if MARKET_MISS_SUMMARY.exists():
            age = max(0.0, nowv - MARKET_MISS_SUMMARY.stat().st_mtime)
            if age < V676_MARKET_MISS_MIN_REFRESH_SEC:
                cached = load_json(MARKET_MISS_SUMMARY, {}) or {}
                if isinstance(cached, dict) and cached.get('tracking_total'):
                    cached = dict(cached)
                    cached['cache_reused_v676'] = True
                    cached['cache_age_sec_v676'] = round(age, 3)
                    return cached
    except Exception:
        pass
    out = _v676_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        if isinstance(out, dict):
            out['cache_reused_v676'] = False
            out['min_refresh_sec_v676'] = V676_MARKET_MISS_MIN_REFRESH_SEC
            save_json(MARKET_MISS_SUMMARY, out)
    except Exception as exc:
        append_error(ERROR, 'v676_market_miss_cache_mark', exc)
    return out




# =============================================================================
# review_worker v0.721 / v895: same-number seal for market-miss after review
# - 후보 row의 stable_event_key/candidate_follow_key/entry_build_key를 market-miss 결과에 보존한다.
# - 실제 S1/paper OPEN/청산/자동매수/조건은 변경하지 않는다.
# =============================================================================
VERSION = "review_worker_v0.721"
BUILD_LABEL = 'market_miss_same_key_seal_v895_2026-06-14'


def _v895_present(v: Any) -> bool:
    return v not in (None, '', '-', [], {})


def _v895_event_prefix_bucket(value: Any) -> tuple[str, Optional[int]]:
    s = str(value or '').strip()
    if not s or s == '-': return '', None
    parts = s.split(':')
    if len(parts) >= 2 and parts[-1].isdigit():
        try: return ':'.join(parts[:-1]), int(parts[-1])
        except Exception: return ':'.join(parts[:-1]), None
    return s, None


def _v895_stable_fields(c: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(c, dict): return {}
    eid = None
    for k in ('event_id','event_key','trace_id','handoff_id','candidate_uid','candidate_id','scan_id','source_scan_id','entry_build_key','build_key'):
        if _v895_present(c.get(k)):
            eid = c.get(k); break
    stable = None
    for k in ('stable_event_key_v894','candidate_follow_key_v894','stable_event_key_v895','candidate_follow_key_v895'):
        if _v895_present(c.get(k)):
            stable = c.get(k); break
    bucket = None
    for k in ('stable_event_bucket_v894','candidate_event_bucket_v894','stable_event_bucket_v895','candidate_event_bucket_v895'):
        if _v895_present(c.get(k)):
            bucket = c.get(k); break
    if not _v895_present(stable) and _v895_present(eid):
        stable, bucket2 = _v895_event_prefix_bucket(eid)
        if not _v895_present(bucket): bucket = bucket2
    out = {
        'event_id': eid,
        'stable_event_key_v894': stable,
        'candidate_follow_key_v894': stable,
        'stable_event_key_v895': stable,
        'candidate_follow_key_v895': stable,
        'entry_build_key': c.get('entry_build_key') or c.get('build_key') or eid,
        'score_patch_version': c.get('score_patch_version') or c.get('patch_version') or VERSION,
        'signal_ts': c.get('signal_ts') or c.get('created_at') or c.get('candidate_created_at') or c.get('source_created_at'),
        'same_key_sealed_v895': bool(_v895_present(stable) or _v895_present(eid)),
        'same_key_owner_v895': 'review_worker_market_miss_writer',
        'same_key_policy_v895': 'use candidate stable key for after metric review; no trading condition change',
    }
    if _v895_present(bucket):
        try: out['stable_event_bucket_v894'] = int(float(bucket)); out['stable_event_bucket_v895'] = int(float(bucket))
        except Exception: out['stable_event_bucket_v894'] = bucket; out['stable_event_bucket_v895'] = bucket
    return {k:v for k,v in out.items() if _v895_present(v) or k == 'same_key_sealed_v895'}


_v895_prev_miss_key = _v667_miss_key

def _v667_miss_key(c: Dict[str, Any]) -> str:  # type: ignore[override]
    fields = _v895_stable_fields(c)
    return str(fields.get('stable_event_key_v895') or fields.get('stable_event_key_v894') or fields.get('entry_build_key') or _v895_prev_miss_key(c))


def _v895_enrich_market_miss_outputs(summary: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    cand_obj = load_json(MARKET_MISS_CANDIDATES, {}) or {}
    candidates = cand_obj.get('rows') if isinstance(cand_obj, dict) and isinstance(cand_obj.get('rows'), list) else []
    by_key: Dict[str, Dict[str, Any]] = {}
    by_ticker: Dict[str, Dict[str, Any]] = {}
    for c in candidates:
        if not isinstance(c, dict): continue
        fields = _v895_stable_fields(c)
        key = str(fields.get('stable_event_key_v895') or fields.get('entry_build_key') or '')
        t = ticker_norm(c.get('ticker') or c.get('symbol') or c.get('market'))
        cc = dict(c); cc.update(fields)
        if key: by_key[key] = cc
        if t: by_ticker[t] = cc
    state = load_json(MARKET_MISS_STATE, {}) or {}
    active = state.get('active') if isinstance(state, dict) and isinstance(state.get('active'), dict) else {}
    sealed = 0
    rows = []
    for k, rec in list(active.items()):
        if not isinstance(rec, dict): continue
        t = ticker_norm(rec.get('ticker'))
        c = by_key.get(str(k)) or by_key.get(str(rec.get('stable_event_key_v895') or rec.get('stable_event_key_v894') or '')) or by_ticker.get(t)
        if isinstance(c, dict):
            fields = _v895_stable_fields(c)
            rec.update(fields)
        if rec.get('same_key_sealed_v895'): sealed += 1
        rows.append(rec)
    if isinstance(active, dict):
        save_json(MARKET_MISS_STATE, {'schema':'market_miss_state_v895_same_key','version':VERSION,'build':BUILD_LABEL,'updated_ts':nowv,'updated_text':now_text(nowv),'active':active})
    def enrich_arr(arr: Any) -> list:
        out=[]
        for r in arr if isinstance(arr, list) else []:
            if not isinstance(r, dict): continue
            t = ticker_norm(r.get('ticker'))
            c = by_key.get(str(r.get('stable_event_key_v895') or r.get('stable_event_key_v894') or '')) or by_ticker.get(t)
            rr = dict(r)
            if isinstance(c, dict): rr.update(_v895_stable_fields(c))
            out.append(rr)
        return out
    summary = dict(summary or {})
    for key in ('top_risers','true_missed_top','rows','items','missed','regret','late_rise'):
        if isinstance(summary.get(key), list):
            summary[key] = enrich_arr(summary.get(key))
    # main v889 reads rows too; publish a compact stable-key rows list without replacing existing summaries.
    summary['rows'] = sorted(rows, key=lambda x: fnum(x.get('max_pct'), default=0.0), reverse=True)[:240]
    summary['same_key_seal_v895'] = {'candidate_rows': len(candidates), 'active_rows': len(rows), 'sealed_rows': sealed, 'version': VERSION, 'build': BUILD_LABEL}
    summary['version'] = VERSION; summary['build'] = BUILD_LABEL
    save_json(MARKET_MISS_SUMMARY, summary)
    return summary


_v895_prev_market_miss_update = _v667_market_miss_update

def _v667_market_miss_update(nowv: float, fmap: Dict[str, Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:  # type: ignore[override]
    summary = _v895_prev_market_miss_update(nowv, fmap, ofmap)
    try:
        return _v895_enrich_market_miss_outputs(summary if isinstance(summary, dict) else {}, nowv)
    except Exception as exc:
        append_error(ERROR, 'v895_market_miss_same_key_seal', exc)
        return summary

if __name__ == "__main__": main()
