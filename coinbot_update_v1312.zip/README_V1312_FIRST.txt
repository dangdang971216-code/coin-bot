v1312: Review missed-state disk growth fix. Apply with /gupgrade_bundle. Then /grelease_verify, /gdeep_audit, /gdisk_full.
