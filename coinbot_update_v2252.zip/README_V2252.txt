코인봇 v2252 오류 우선 통합 복구본
- v2251이 Review 비활성 상태에서 v2248 환경주인 선검사에 막힌 실제 active-path 오류 수리
- 선택 manifest가 Review를 소유하고 재시작을 요구할 때만 pre-apply Review 비활성 복구 허용
- 적용 후 Main/Guard/Paper/Review 전체 active·토큰주인 strict proof
- 내부 __GUARD_RESTART_CONTINUE_SILENT_V2181__ Telegram 노출 차단
- Review target은 workers.review에서 매번 동적 선택; 고정 버전 없음
- v2249 OPEN 원본, 손실방어, Review 최대 500, Guard 시간/중복 수리 유지
- 전략·상승예측 식·후보·진입·청산·원장 변경 없음
- 자동매수 OFF
