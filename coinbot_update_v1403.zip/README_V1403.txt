코인봇 v1403
- 목적: v1401 복구 후 디스크 위험/Review 비핵심 파일 폭증 수리
- 기준: v1158 completed generation handoff 유지
- 변경: 비핵심 archive/cache/backup/trace/파생 index 정리 범위 확대, Review cost index/good-S2 active segment 상한 강화
- 금지: OPEN/CLOSED/trade_log/decision/change/issue 핵심 원장 삭제·축소, 전략수치 변경, 자동매수 ON
- 명령: /gupgrade_bundle 후 필요 시 /gdisk_full 또는 /gdisk, 검수 /gdeep_audit
