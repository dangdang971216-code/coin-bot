이 파일들은 release event/검수 지침이다. 서버의 live OPEN/CLOSED/trade_log/decision/change_verify/issue ledger를 덮어쓰거나 삭제하지 않는다.
