#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
paper_bot_v0.710.py

TRUE REBUILD PAPER RUNTIME
- Single owner of OPEN/CLOSED/exit/score/cleanup.
- No run_cycle wrapper chain.
- OPEN exit sweep runs before candidate intake.
- Existing ledger files are preserved.
"""
from __future__ import annotations

import json, os, time, traceback, glob, shutil, urllib.parse, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple
from collections import defaultdict

BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", Path(__file__).resolve().parent))
VERSION = "paper_bot_v0.710"
BUILD = "v710_true_clean_paper_runtime_2026-06-04"

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN", "").strip()
PAPER_CHAT_ID = os.getenv("PAPER_CHAT_ID", os.getenv("CHAT_ID", "")).strip()
MAIN_CHAT_ID = os.getenv("MAIN_CHAT_ID", "").strip()

LOOP_SLEEP_SEC = float(os.getenv("PAPER_LOOP_SLEEP_SEC", "1.0"))
CANDIDATE_INTERVAL_SEC = float(os.getenv("PAPER_CANDIDATE_INTERVAL_SEC", "2.0"))
STOP_LOSS_PCT = float(os.getenv("PAPER_STOP_LOSS_PCT", "-0.55"))
FAST_FAIL_PCT = float(os.getenv("PAPER_FAST_FAIL_PCT", "-0.35"))
TAKE_PROFIT_PCT = float(os.getenv("PAPER_TAKE_PROFIT_PCT", "1.20"))
TIME_EXIT_MIN = float(os.getenv("PAPER_TIME_EXIT_MIN", "60"))
MAX_OPEN = int(os.getenv("PAPER_MAX_OPEN", "12"))
MAX_EXPERIMENT_OPEN = int(os.getenv("PAPER_EXPERIMENT_MAX_OPEN", "8"))
EXPERIMENT_ENABLED = os.getenv("PAPER_EXPERIMENT_ENABLED", "1") != "0"
SCORE_HOT_HOURS = float(os.getenv("PAPER_SCORE_HOT_HOURS", "24"))
SCORE_HOT_TAIL = int(os.getenv("PAPER_SCORE_HOT_TAIL", "420"))

def now_ts() -> float: return time.time()

def fnum(v: Any, default: float = 0.0) -> float:
    try:
        if v is None or v == "": return default
        return float(str(v).replace(",", "").replace("%", ""))
    except Exception: return default

def load_json(name: str, default: Any = None) -> Any:
    p = BASE_DIR / name
    try:
        if not p.exists(): return default
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception: return default

def save_json(name: str, data: Any) -> None:
    p = BASE_DIR / name
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)

def append_jsonl(name: str, row: Dict[str, Any]) -> None:
    with (BASE_DIR / name).open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")

def read_jsonl_tail(name: str, limit: int = 2000) -> List[Dict[str, Any]]:
    p = BASE_DIR / name
    if not p.exists(): return []
    try:
        lines = p.read_text(encoding="utf-8", errors="ignore").splitlines()[-limit:]
    except Exception:
        return []
    out = []
    for line in lines:
        try:
            obj = json.loads(line)
            if isinstance(obj, dict): out.append(obj)
        except Exception: pass
    return out

def log_error(where: str, exc: Exception) -> None:
    append_jsonl("paper_bot_errorlog.jsonl", {"ts": now_ts(), "where": where, "error": repr(exc), "trace": traceback.format_exc()[-2000:]})

def send_telegram(text: str, chat_id: str = "") -> None:
    if not TELEGRAM_TOKEN:
        return
    chat_id = chat_id or PAPER_CHAT_ID
    if not chat_id:
        return
    try:
        data = urllib.parse.urlencode({"chat_id": chat_id, "text": text[:3900]}).encode()
        urllib.request.urlopen(f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage", data=data, timeout=5).read()
    except Exception:
        pass

def norm_symbol(r: Dict[str, Any]) -> str:
    for k in ["symbol","ticker","market","code"]:
        v = r.get(k)
        if v: return str(v).replace("KRW-","").upper()
    return ""

def extract_rows(data: Any) -> List[Dict[str, Any]]:
    if isinstance(data, list): return [x for x in data if isinstance(x, dict)]
    if not isinstance(data, dict): return []
    for k in ["rows","items","candidates","markets","tickers","data","results"]:
        v = data.get(k)
        if isinstance(v, list): return [x for x in v if isinstance(x, dict)]
        if isinstance(v, dict): return [x for x in v.values() if isinstance(x, dict)]
    return [v for v in data.values() if isinstance(v, dict) and ("symbol" in v or "ticker" in v or "market" in v)]

def first_num(r: Dict[str, Any], keys: List[str], default: float = 0.0) -> float:
    for k in keys:
        x = fnum(r.get(k), 0)
        if x: return x
    return default

def load_open_positions() -> Dict[str, Dict[str, Any]]:
    data = load_json("paper_bot_open.json", {}) or {}
    if isinstance(data, dict) and isinstance(data.get("positions"), dict):
        return {str(k).upper(): v for k, v in data["positions"].items() if isinstance(v, dict)}
    if isinstance(data, dict):
        return {str(k).upper(): v for k, v in data.items() if isinstance(v, dict) and ("symbol" in v or "ticker" in v)}
    return {}

def save_open_positions(pos: Dict[str, Dict[str, Any]]) -> None:
    data = {"schema":"paper_open_v710","ts":now_ts(),"version":VERSION,"build":BUILD,"open_count":len(pos),"positions":pos}
    save_json("paper_bot_open.json", data)
    save_json("paper_open_positions.json", data)

def current_price_for(symbol: str, fallback: float = 0.0) -> Tuple[float, float, str]:
    symbol = symbol.replace("KRW-","").upper()
    best_price, best_ts, source = 0.0, 0.0, ""
    for name in ["clean_orderflow_summary_cache.json","clean_feature_cache.json","clean_scanner_market_cache.json","clean_scanner_hot_rank_cache.json"]:
        for r in extract_rows(load_json(name, [])):
            if norm_symbol(r) != symbol: continue
            price = first_num(r, ["current_price","price","last_price","trade_price","close"], 0)
            row_ts = fnum(r.get("ts") or r.get("updated_at") or r.get("timestamp"), 0)
            if price > 0 and row_ts >= best_ts:
                best_price, best_ts, source = price, row_ts, name
    if best_price <= 0: best_price = fallback
    age = max(0.0, now_ts() - best_ts) if best_ts else 9999.0
    return best_price, age, source or "fallback"

def pnl_pct(entry: float, price: float) -> float:
    return (price/entry-1)*100 if entry else 0.0

def is_experiment_row(r: Dict[str, Any]) -> bool:
    lane = str(r.get("lane") or r.get("paper_experiment_lane") or r.get("experiment_lane") or "")
    return bool(r.get("is_experiment") or r.get("paper_experiment_open") or "experiment" in lane or "fast_quality" in lane)

def exit_sweep(pos: Dict[str, Dict[str, Any]]) -> int:
    closed = 0
    for key, p in list(pos.items()):
        sym = p.get("symbol") or p.get("ticker") or key
        entry = fnum(p.get("entry_price"), 0)
        cur, price_age, source = current_price_for(sym, fnum(p.get("current_price") or p.get("last_price"), entry))
        p["current_price"] = cur
        p["price_cache_age_sec"] = price_age
        p["price_source"] = source
        pnl = pnl_pct(entry, cur)
        p["pnl_pct"] = pnl
        p["max_pnl_pct"] = max(fnum(p.get("max_pnl_pct"), pnl), pnl)
        p["min_pnl_pct"] = min(fnum(p.get("min_pnl_pct"), pnl), pnl)
        last = fnum(p.get("last_update_ts"), fnum(p.get("entry_ts"), now_ts()))
        p["position_update_gap_sec"] = max(0, now_ts() - last)
        p["last_update_ts"] = now_ts()
        stop = fnum(p.get("stop_loss_pct"), STOP_LOSS_PCT)
        reason = ""
        if pnl <= stop: reason = "stop_loss"
        elif pnl <= FAST_FAIL_PCT and now_ts() - fnum(p.get("entry_ts"), now_ts()) <= 180: reason = "fast_fail"
        elif pnl >= fnum(p.get("take_profit_pct"), TAKE_PROFIT_PCT): reason = "take_profit"
        elif now_ts() - fnum(p.get("entry_ts"), now_ts()) >= TIME_EXIT_MIN * 60: reason = "time_exit"
        if reason:
            close_position(pos, key, p, reason, stop)
            closed += 1
    return closed

def close_position(pos: Dict[str, Dict[str, Any]], key: str, p: Dict[str, Any], reason: str, stop_loss: float) -> None:
    row = dict(p)
    row["exit_ts"] = now_ts()
    row["exit_reason"] = reason
    row["closed_by"] = "paper_bot_v710"
    row.setdefault("version", VERSION)
    row.setdefault("build", BUILD)
    append_jsonl("paper_bot_closed.jsonl", row)
    append_jsonl("paper_bot_close_alert_trace.jsonl", row)
    if reason == "stop_loss" and fnum(row.get("pnl_pct"), 0) < stop_loss:
        flags = []
        if fnum(row.get("price_cache_age_sec"), 0) > 10: flags.append("가격age의심")
        if fnum(row.get("position_update_gap_sec"), 0) > 10: flags.append("루프gap의심")
        if not row.get("lane"): flags.append("lane미분류")
        append_jsonl("paper_bot_stop_overrun_trace.jsonl", {
            "ts": now_ts(), "symbol": row.get("symbol"), "strategy": row.get("strategy"),
            "strategy_name": row.get("strategy_name"), "grade": row.get("grade"),
            "lane": row.get("lane"), "is_experiment": bool(row.get("is_experiment")),
            "stop_loss_pct": stop_loss, "pnl_pct": fnum(row.get("pnl_pct"), 0),
            "overrun_pct": fnum(row.get("pnl_pct"), 0) - stop_loss,
            "price_cache_age_sec": fnum(row.get("price_cache_age_sec"), 0),
            "position_update_gap_sec": fnum(row.get("position_update_gap_sec"), 0),
            "exit_reason": reason, "flags": flags,
        })
    pos.pop(key, None)
    text = f"📉 paper CLOSED\n- 종목: {row.get('symbol')}\n- 손익: {fnum(row.get('pnl_pct'),0):+.2f}%\n- 이유: {reason}\n- 전략: {row.get('strategy_name') or row.get('strategy')}"
    send_telegram(text)
    if MAIN_CHAT_ID and MAIN_CHAT_ID != PAPER_CHAT_ID:
        send_telegram(text, MAIN_CHAT_ID)

def candidate_rows() -> List[Dict[str, Any]]:
    rows = read_jsonl_tail("paper_candidates_latest.jsonl", 1000)
    data = load_json("clean_fast_quality_paper_handoff_v674.json", {}) or {}
    for r in extract_rows(data):
        rr = dict(r)
        rr["paper_experiment_open"] = True
        rr.setdefault("strategy", "fast_quality_paper_experiment")
        rr.setdefault("strategy_name", "고품질 빠른진입 paper 실험")
        rows.append(rr)
    # dedupe by symbol + lane
    out, seen = [], set()
    for r in rows:
        sym = norm_symbol(r)
        lane = "exp" if is_experiment_row(r) else "official"
        key = (sym, lane)
        if not sym or key in seen: continue
        seen.add(key); out.append(r)
    return out

def can_open(row: Dict[str, Any], pos: Dict[str, Dict[str, Any]]) -> Tuple[bool, str]:
    sym = norm_symbol(row)
    if not sym: return False, "symbol_missing"
    if sym in pos: return False, "already_open"
    if len(pos) >= MAX_OPEN: return False, "max_open"
    grade = str(row.get("stage") or row.get("grade") or "").upper()
    exp = is_experiment_row(row)
    if grade == "S1" and not exp: return True, "official_s1"
    if exp and EXPERIMENT_ENABLED and grade in {"S1","S2","S3","S3_WATCH"}:
        exp_n = sum(1 for v in pos.values() if v.get("is_experiment") or v.get("lane") == "experiment")
        if exp_n >= MAX_EXPERIMENT_OPEN: return False, "experiment_limit"
        return True, "experiment"
    return False, "not_open_grade"

def open_candidate(row: Dict[str, Any], pos: Dict[str, Dict[str, Any]]) -> bool:
    sym = norm_symbol(row)
    price = first_num(row, ["entry_price","current_price","price","trade_price","close","last_price"], 0)
    if not sym or price <= 0: return False
    trigger = fnum(row.get("trigger_price"), 0)
    if trigger > 0 and price < trigger: return False
    exp = is_experiment_row(row)
    pos[sym] = {
        "symbol": sym, "entry_ts": now_ts(), "last_update_ts": now_ts(),
        "entry_price": price, "current_price": price, "pnl_pct": 0.0,
        "max_pnl_pct": 0.0, "min_pnl_pct": 0.0,
        "grade": row.get("grade") or row.get("stage") or "-",
        "stage": row.get("stage") or row.get("grade") or "-",
        "strategy": row.get("strategy") or row.get("strategy_key") or ("fast_quality_paper_experiment" if exp else "-"),
        "strategy_name": row.get("strategy_name") or row.get("strategy_label") or ("고품질 빠른진입 paper 실험" if exp else "-"),
        "lane": "experiment" if exp else "official",
        "is_experiment": exp,
        "stop_loss_pct": fnum(row.get("stop_loss_pct"), STOP_LOSS_PCT),
        "take_profit_pct": fnum(row.get("take_profit_pct"), TAKE_PROFIT_PCT),
        "source": row.get("source") or "paper_candidates_latest",
        "version": VERSION, "build": BUILD,
    }
    append_jsonl("paper_bot_open_alert_trace.jsonl", pos[sym])
    text = f"🟢 paper OPEN\n- 종목: {sym}\n- 등급: {pos[sym]['grade']}\n- 전략: {pos[sym]['strategy_name']}\n- lane: {pos[sym]['lane']}\n- 진입가: {price:g}"
    send_telegram(text)
    return True

def select_and_open(pos: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    stats = {"seen": 0, "selected": 0, "limit_skip": 0, "hold": 0}
    for r in candidate_rows():
        stats["seen"] += 1
        ok, reason = can_open(r, pos)
        if not ok:
            if "limit" in reason or reason == "max_open": stats["limit_skip"] += 1
            else: stats["hold"] += 1
            continue
        if open_candidate(r, pos): stats["selected"] += 1
    return stats

def summarize(rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    n = len(rows)
    wins = sum(1 for r in rows if fnum(r.get("pnl_pct"), 0) > 0)
    total = sum(fnum(r.get("pnl_pct"), 0) for r in rows)
    return {"n": n, "wins": wins, "losses": n-wins, "sum_pct": total, "avg_pct": total/n if n else 0.0}

def build_score_cache() -> None:
    rows = read_jsonl_tail("paper_bot_closed.jsonl", 5000)
    t = now_ts()
    today = time.strftime("%Y-%m-%d", time.localtime(t))
    yday = time.strftime("%Y-%m-%d", time.localtime(t-86400))
    def row_ts(r): return fnum(r.get("exit_ts") or r.get("ts"), 0)
    def day(r): return time.strftime("%Y-%m-%d", time.localtime(row_ts(r))) if row_ts(r) else ""
    periods = {
        "today": summarize([r for r in rows if day(r) == today]),
        "yesterday": summarize([r for r in rows if day(r) == yday]),
        "recent_24h": summarize([r for r in rows if row_ts(r) >= t-86400]),
        "recent_3h": summarize([r for r in rows if row_ts(r) >= t-3*3600]),
        "recent_6h": summarize([r for r in rows if row_ts(r) >= t-6*3600]),
    }
    hot = [r for r in rows if row_ts(r) >= t-SCORE_HOT_HOURS*3600]
    if len(hot) < min(SCORE_HOT_TAIL, len(rows)): hot = rows[-SCORE_HOT_TAIL:]
    by_grade = defaultdict(list); official = defaultdict(list); exp = defaultdict(list)
    for r in hot:
        g = str(r.get("grade") or r.get("stage") or "-").upper()
        by_grade[g].append(r); by_grade["ALL"].append(r)
        name = r.get("strategy_name") or r.get("strategy") or "-"
        if r.get("is_experiment") or r.get("lane") == "experiment": exp[name].append(r)
        else: official[name].append(r)
    off_sum = sum(summarize(v)["sum_pct"] for v in official.values())
    exp_sum = sum(summarize(v)["sum_pct"] for v in exp.values())
    cache = {
        "schema": "paper_score_cache_v710", "owner": "paper_bot_v710", "ts": t,
        "version": VERSION, "build": BUILD,
        "periods": periods, "by_grade": {k: summarize(v) for k,v in by_grade.items()},
        "official_by_strategy": {k: summarize(v) for k,v in official.items()},
        "experiment_by_strategy": {k: summarize(v) for k,v in exp.items()},
        "interpretation": [f"정식/비실험 합산 {off_sum:+.2f}% / 실험 lane 합산 {exp_sum:+.2f}%", f"현재 OPEN 중 실험 추정: {sum(1 for x in load_open_positions().values() if x.get('is_experiment'))}개 / 전체 OPEN {len(load_open_positions())}개"],
    }
    save_json("paper_bot_score_cache.json", cache)
    save_json("paper_bot_trade_review_cache.json", cache)

def stop_summary() -> Dict[str, Any]:
    rows = read_jsonl_tail("paper_bot_stop_overrun_trace.jsonl", 200)
    n = len(rows); over = [fnum(r.get("overrun_pct"),0) for r in rows]
    official = sum(1 for r in rows if r.get("lane")=="official" and not r.get("is_experiment"))
    exp = sum(1 for r in rows if r.get("is_experiment") or r.get("lane")=="experiment")
    return {"n": n, "official": official, "experiment": exp, "unknown": n-official-exp, "avg_overrun": sum(over)/n if n else 0, "max_overrun": min(over) if over else 0, "price_age_suspect": sum(1 for r in rows if fnum(r.get("price_cache_age_sec"),0)>10), "loop_gap_suspect": sum(1 for r in rows if fnum(r.get("position_update_gap_sec"),0)>10)}

def cleanup() -> None:
    tmp_deleted = 0
    for p in BASE_DIR.glob("paper_hourly_raw_pack_*.txt"):
        try:
            if now_ts() - p.stat().st_mtime > 3600:
                p.unlink(); tmp_deleted += 1
        except Exception: pass
    save_json("paper_bot_cleanup_state.json", {"schema":"paper_cleanup_v710","owner":"paper_bot_v710","ts":now_ts(),"status":"✅","trace_deleted_lines":0,"tmp_deleted_files":tmp_deleted,"score_hot_hours":SCORE_HOT_HOURS,"score_hot_tail":SCORE_HOT_TAIL,"ledger_preserved":True})
    save_json("paper_bot_hourly_raw_pack_trace.json", {"ts": now_ts(), "deleted": "✅", "reason": "cleanup_checked_v710", "owner": "paper_bot_v710"})

def write_status(stats: Dict[str, int]) -> None:
    save_json("paper_bot_status.json", {"schema":"paper_status_v710","ts":now_ts(),"status":"running","version":VERSION,"build":BUILD,"open_count":len(load_open_positions()),"closed_count":len(read_jsonl_tail("paper_bot_closed.jsonl",300)),"fast_paper":stats,"stop_overrun_summary":stop_summary()})
    save_json("paper_bot_candidate_handoff_status.json", {"schema":"paper_handoff_status_v710","ts":now_ts(),"raw_fast":stats.get("seen",0),"filtered_fast":stats.get("seen",0),"seen":stats.get("seen",0),"selected":stats.get("selected",0),"limit_skip":stats.get("limit_skip",0),"hold":stats.get("hold",0)})

def main() -> None:
    last_candidate = last_score = last_cleanup = 0.0
    stats = {"seen":0,"selected":0,"limit_skip":0,"hold":0}
    while True:
        try:
            pos = load_open_positions()
            exit_sweep(pos)  # first priority
            if now_ts() - last_candidate >= CANDIDATE_INTERVAL_SEC:
                stats = select_and_open(pos)
                last_candidate = now_ts()
            save_open_positions(pos)
            if now_ts() - last_score >= 5:
                build_score_cache(); last_score = now_ts()
            if now_ts() - last_cleanup >= 60:
                cleanup(); last_cleanup = now_ts()
            write_status(stats)
        except Exception as exc:
            log_error("main_loop", exc)
        time.sleep(LOOP_SLEEP_SEC)

if __name__ == "__main__":
    main()
