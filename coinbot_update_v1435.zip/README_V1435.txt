# coinbot_update_v1435

목적: v1433 자동 이어가기 요청이 stale 상태로 남아 /gupgrade_bundle을 계속 막는 문제를 수리한다.

변경:
- /grelease_clear 추가: guard 자동 이어가기 request/lock/outbox만 정리
- /gunlock 범위 확대: 기존 deploy lock + 자동 이어가기 stale 상태 정리
- /gupgrade_bundle: zero-work stale continuation은 자동 정리 후 새 bundle 진행
- /gquick v1434 NameError fix 유지

변경 없음:
- 후보 흐름, S1/S2/S3, Gate, TTL, RR, trigger, invalid, target
- 실제 청산계약, OPEN limit, Paper OPEN/CLOSED 원장
- 자동매수 OFF
