#!/usr/bin/env python3
from pathlib import Path
from coinbot_core_v2.services import run_paper
VERSION='paper_bot_v1.001'; BUILD_LABEL='v1067_full_core_single_spine_2026-06-26'
if __name__=='__main__': run_paper(Path(__file__).resolve().parent)
