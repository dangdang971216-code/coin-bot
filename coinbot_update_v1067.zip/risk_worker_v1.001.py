#!/usr/bin/env python3
from pathlib import Path
from coinbot_core_v2.services import run_risk
VERSION='risk_worker_v1.001'; BUILD='v1067_full_core_single_spine_2026-06-26'
if __name__=='__main__': run_risk(Path(__file__).resolve().parent)
