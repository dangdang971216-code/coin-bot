#!/usr/bin/env python3
from pathlib import Path
from coinbot_core_v2.services import run_strategy
VERSION='strategy_worker_v1.001'; BUILD='v1067_full_core_single_spine_2026-06-26'
if __name__=='__main__': run_strategy(Path(__file__).resolve().parent)
