# CORE V2 v1067 전체 점검표

상태: LOCAL PASS / SERVER CHECK  
전략: ALT_SWING_V977 parity mode  
자동매수: OFF

## 1. 코인 생명주기

| 단계 | 단일 owner | 입력 | 출력 | 로컬검수 |
|---|---|---|---|---|
| 전체시장 발견 | 기존 scanner v0.945 | 거래소 시장 | market/pool/hot cache | 유지 |
| 완료봉 구조재료 | 기존 candle v0.960 | pool/targets | candle cache | 유지 |
| 장세 | 기존 market v0.1 | market/candle | regime cache | 유지 |
| 가격·상대강도 | 기존 feature v0.5 | scanner/candle/regime | feature cache | 유지 |
| 호가·체결 | 기존 orderflow/ws/micro | quote/target | execution cache | 유지 |
| 구조·S등급 | `core_v2.strategy_engine` | 위 cache | trigger/invalid/target/S1·S2·S3 | PASS |
| 최근손실·재진입 source | `core_v2.risk_engine` | CLOSED/OPEN | latest loss map/signature | PASS |
| OPEN 직전 검사 | `core_v2.execution_engine` | frozen gate + 최신 실행가 | entry/spread/slippage/actual RR | PASS |
| OPEN commit | `core_v2.paper_store` | selected candidate | OPEN + decision OPEN | PASS |
| 보유 추적 | `core_v2.exit_engine` | OPEN + current price | MFE/MAE/giveback | PASS |
| 청산 판정 | `core_v2.exit_engine` | frozen exit contract | invalid/target/trailing/time | PASS |
| CLOSED commit | `core_v2.paper_store` | close decision | CLOSED fsync → decision CLOSED → OPEN 제거 | PASS |
| 성과 | `core_v2.performance` | CLOSED + direct decision | canonical snapshot | PASS |
| 명령화면 | `core_v2.command_views` | command snapshot | Main/Paper 화면 | PASS |
| 배포·검수 | Guard v2.5.121 | manifest/verify | stage→verify→cutover/rollback | PASS |

## 2. 불변조건

- RR 1.5, target room 1.2%, spread 1.2%, chase 0.6% 유지.
- trailing +2.0% / 0.8%p 유지.
- 6시간 무반응·72시간 약한 흐름 유지.
- 실제 진입가 RR은 v1059 parity에 맞춰 기록만 하며 새 하드차단하지 않음.
- 장세·품질값은 기록/순위용이며 새 하드차단하지 않음.
- OPEN 총량·cycle 신규 한도 0=무제한 계약을 임의 변경하지 않음.
- 자동매수 OFF.

## 3. 원장 안전

- OPEN commit 실패 시 rollback.
- CLOSED는 append+fsync/tail 확인 → decision CLOSED → OPEN 제거.
- decision 저장 실패 시 OPEN 유지.
- 기존 OPEN/CLOSED/decision/change/issue 원장 포함·삭제·재작성 없음.
- `/gcore_v2_verify`는 임시 디렉터리에서만 writer를 실행하고 라이브 원장 signature 불변을 검사.
- `/gcore_v2_cutover`는 전체 active alias를 백업하고 실패 시 전부 rollback.

## 4. 명령어

- Main 기존 공개 명령: 26/26.
- Paper 기존 공개 명령: 27/27.
- Guard 기존 공개 명령: 154/154 + 신규 `/gcore_v2_verify`, `/gcore_v2_cutover`.
- Main/Paper는 동일 canonical command snapshot만 읽음.
- 같은 `/status`, `/batch`, `/help`는 봇별 namespace를 분리.

## 5. 로컬 결과

- `compileall`: PASS.
- pytest: 8/8 PASS.
- 합성 전체흐름 검증: PASS.
- candidate/decision identity: PASS.
- max numeric closed_ts owner: PASS.
- OPEN rollback: PASS.
- CLOSED exact commit: PASS.
- 성과 direct key 연결: PASS.
- 명령 렌더링: Main 26/26, Paper 27/27.
- 중복 top-level active 정의: 0.

## 6. 서버 전환 조건

`/gcore_v2_verify`에서 아래가 모두 PASS여야 `/gcore_v2_cutover`가 실행된다.

- 전체 흐름 모듈 존재.
- Main/Paper/Guard 명령 누락 0.
- candidate·decision key 누락 0.
- trigger·invalid·target 완전.
- 현재 본선과 S1 ticker overlap 75% 이상.
- 공통 S1 구조계약 일치 80% 이상.
- S1 수 차이가 25% 범위 이내.
- 라이브 원장 쓰기 0.
- 자동매수 OFF.

서버 증명 전 상태는 CHECK이며 DONE으로 기록하지 않는다.
