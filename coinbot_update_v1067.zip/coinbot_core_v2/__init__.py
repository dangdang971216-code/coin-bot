"""Coinbot CORE V2 — single-spine runtime."""
__version__ = "2.0.0-v1067"
BUILD = "v1067_full_core_single_spine_2026-06-26"
