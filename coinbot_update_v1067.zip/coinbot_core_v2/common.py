from __future__ import annotations
import hashlib, json, math, os, time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, Iterator, List, Mapping, Optional, Sequence, Tuple

def now_ts()->float: return time.time()
def now_text(ts:float|None=None)->str: return time.strftime('%Y-%m-%d %H:%M:%S',time.localtime(ts or now_ts()))

def num(*values:Any, default:Optional[float]=None)->Optional[float]:
    for value in values:
        if value in (None,'',[],{}): continue
        try:
            x=float(str(value).replace(',','').replace('%','').strip())
            if math.isfinite(x): return x
        except (ValueError,TypeError): pass
    return default

def integer(*values:Any, default:int=0)->int:
    x=num(*values,default=float(default)); return int(x if x is not None else default)

def text(*values:Any)->str:
    for value in values:
        if value in (None,'','-',[],{}): continue
        s=str(value).strip()
        if s: return s
    return ''

def boolean(*values:Any)->Optional[bool]:
    for value in values:
        if isinstance(value,bool): return value
        if isinstance(value,str) and value.lower() in {'true','false'}: return value.lower()=='true'
    return None

def ticker(value:Any)->str:
    s=str(value or '').strip().upper().replace('/','-').replace('_','-')
    if ':' in s: s=s.split(':')[-1]
    parts=[p for p in s.split('-') if p and p!='KRW']
    s=parts[-1] if parts else s
    if s.endswith('KRW') and len(s)>3: s=s[:-3]
    return s

def parse_ts(*values:Any)->float:
    for value in values:
        if value in (None,'',[],{}): continue
        if isinstance(value,(int,float)):
            x=float(value); x=x/1000 if x>1e12 else x
            if x>1e9: return x
        s=str(value).strip().replace(' KST','')
        try:
            x=float(s); x=x/1000 if x>1e12 else x
            if x>1e9: return x
        except ValueError: pass
        for fmt in ('%Y-%m-%d %H:%M:%S','%Y-%m-%dT%H:%M:%S','%Y-%m-%dT%H:%M:%S%z'):
            try: return datetime.strptime(s,fmt).timestamp()
            except ValueError: pass
    return 0.0

def pct(new:float|None, old:float|None)->float:
    if not new or not old: return 0.0
    return (float(new)/float(old)-1.0)*100.0

def read_json(path:Path, default:Any=None)->Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding='utf-8',errors='strict'))
    except (OSError,UnicodeDecodeError,json.JSONDecodeError): return default

def atomic_write_json(path:Path,obj:Any)->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    payload=json.dumps(obj,ensure_ascii=False,separators=(',',':'),default=str)+'\n'
    try:
        with tmp.open('w',encoding='utf-8') as fh:
            fh.write(payload); fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp,path)
        try:
            fd=os.open(str(path.parent),os.O_RDONLY); os.fsync(fd); os.close(fd)
        except OSError: pass
    finally:
        try: tmp.unlink(missing_ok=True)
        except OSError: pass

def append_jsonl_fsync(path:Path,row:Mapping[str,Any])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    payload=json.dumps(dict(row),ensure_ascii=False,separators=(',',':'),default=str)+'\n'
    with path.open('a',encoding='utf-8') as fh:
        fh.write(payload); fh.flush(); os.fsync(fh.fileno())

def read_jsonl_tail(path:Path,limit:int=2000,max_bytes:int=64*1024*1024)->List[Dict[str,Any]]:
    if not path.exists(): return []
    try:
        size=path.stat().st_size; take=min(size,max_bytes)
        with path.open('rb') as fh:
            if size>take: fh.seek(size-take); fh.readline()
            data=fh.read(take)
    except OSError: return []
    out=[]
    for raw in data.splitlines()[-max(1,limit):]:
        try:
            obj=json.loads(raw.decode('utf-8'))
            if isinstance(obj,dict): out.append(obj)
        except (UnicodeDecodeError,json.JSONDecodeError): pass
    return out

def replace_jsonl(path:Path,rows:Sequence[Mapping[str,Any]])->None:
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    try:
        with tmp.open('w',encoding='utf-8') as fh:
            for row in rows: fh.write(json.dumps(dict(row),ensure_ascii=False,separators=(',',':'),default=str)+'\n')
            fh.flush(); os.fsync(fh.fileno())
        os.replace(tmp,path)
    finally:
        try: tmp.unlink(missing_ok=True)
        except OSError: pass

def file_signature(path:Path)->Dict[str,int]:
    try:
        st=path.stat(); return {'inode':int(st.st_ino),'size':int(st.st_size),'mtime_ns':int(st.st_mtime_ns)}
    except OSError: return {'inode':-1,'size':-1,'mtime_ns':-1}

def sha256(path:Path)->str:
    h=hashlib.sha256()
    with path.open('rb') as fh:
        for chunk in iter(lambda:fh.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()

def rows(obj:Any)->List[Dict[str,Any]]:
    if isinstance(obj,list): return [dict(x) for x in obj if isinstance(x,dict)]
    if not isinstance(obj,dict): return []
    for key in ('rows','items','candidates','active_rows','display_rows','positions','open_positions','markets','data'):
        val=obj.get(key)
        if isinstance(val,list): return [dict(x) for x in val if isinstance(x,dict)]
        if isinstance(val,dict):
            out=[]
            for k,v in val.items():
                if isinstance(v,dict):
                    r=dict(v); r.setdefault('ticker',k); out.append(r)
            return out
    if obj and all(isinstance(v,dict) for v in obj.values()):
        return [dict(v,**({} if any(k in v for k in ('ticker','market','symbol')) else {'ticker':k})) for k,v in obj.items()]
    return []

def row_map(obj:Any)->Dict[str,Dict[str,Any]]:
    out={}
    for row in rows(obj):
        t=ticker(row.get('ticker') or row.get('market') or row.get('symbol'))
        if t: out[t]=row
    return out

def merge_nonempty(*parts:Mapping[str,Any])->Dict[str,Any]:
    out={}
    for part in parts:
        if not isinstance(part,Mapping): continue
        for k,v in part.items():
            if v not in (None,'',[],{}): out[k]=v
    return out

def unique(seq:Iterable[Any],limit:int=50)->List[Any]:
    out=[]; seen=set()
    for item in seq:
        key=json.dumps(item,sort_keys=True,default=str) if isinstance(item,(dict,list)) else str(item)
        if key in seen: continue
        seen.add(key); out.append(item)
        if len(out)>=limit: break
    return out
