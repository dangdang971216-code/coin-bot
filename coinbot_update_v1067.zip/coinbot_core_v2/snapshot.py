from __future__ import annotations
from typing import Any,Dict
import os,time
from .common import read_json,atomic_write_json,now_ts,now_text,num,text,rows,read_jsonl_tail
from .config import RuntimeConfig,BUILD,STRATEGY_MODE

class SnapshotWriter:
    def __init__(self,cfg:RuntimeConfig): self.cfg=cfg
    def build(self)->Dict[str,Any]:
        p=self.cfg.paths; now=now_ts()
        files={
          'scanner':p.base/'clean_scanner_status.json','candle':p.base/'clean_candle_status.json','market':p.base/'clean_market_regime_status.json','feature':p.base/'clean_feature_status.json','orderflow':p.base/'clean_orderflow_status.json',
          'risk':p.risk_status,'strategy':p.strategy_status,'review':p.review_status,'paper':p.paper_status,
        }
        workers={}
        for name,path in files.items():
            obj=read_json(path,{}) or {}; age=max(0.0,now-path.stat().st_mtime) if path.exists() else None
            workers[name]={'version':text(obj.get('version'),obj.get('worker_version')),'build':text(obj.get('build'),obj.get('build_label')),'state':text(obj.get('state'),obj.get('phase')),'age_sec':age,'pid':obj.get('pid'),'row_count':obj.get('row_count') or obj.get('evaluated') or obj.get('rows'),'error':text(obj.get('error'),obj.get('last_error')) or None}
        strategy=read_json(p.strategy_status,{}) or {}; gate=read_json(p.gate_status,{}) or {}; paper=read_json(p.paper_status,{}) or {}; risk=read_json(p.risk_cache,{}) or {}; perf=read_json(p.performance,{}) or {}; open_obj=read_json(p.paper_open,{}) or {}; open_rows=[r for r in open_obj.values() if isinstance(r,dict)] if isinstance(open_obj,dict) else []
        errors=[]
        for name,obj in workers.items():
            if obj.get('error'): errors.append(f'{name}:{obj["error"]}')
        snapshot={
          'schema':'coinbot_core_v2_command_snapshot_v1067','version':'core_v2_v1067','build':BUILD,'generated_ts':now,'generated_text':now_text(now),'strategy_mode':STRATEGY_MODE,'auto_buy':False,
          'workers':workers,'strategy':strategy,'gate':gate,'risk':risk,'paper':paper,'performance':perf,'open_positions':open_rows,'open_count':len(open_rows),
          'ledger':{'open_file':str(p.paper_open),'closed_file':str(p.paper_closed),'decision_file':str(p.paper_decision),'exact_duplicates':perf.get('duplicates'),'decision_key_missing':perf.get('decision_key_missing'),'unlinked':perf.get('unlinked')},
          'errors':errors,'runtime':{'pid':os.getpid(),'writer_owner':'core_v2.snapshot.single_writer'},
        }
        atomic_write_json(p.command_snapshot,snapshot); atomic_write_json(p.main_status,{'version':'수익형 v2.14.1067','build':BUILD,'state':'running','pid':os.getpid(),'updated_ts':now,'worker_count':len(workers),'error_count':len(errors),'auto_buy':False,'snapshot_owner':'core_v2.snapshot.single_writer'})
        return snapshot
