from __future__ import annotations
from typing import Any,Dict,Tuple
from .common import num,pct,parse_ts,now_ts,text
from .config import RuntimeConfig

def mark_position(position:Dict[str,Any],current_price:float,now:float|None=None)->Dict[str,Any]:
    now=float(now or now_ts()); row=dict(position); entry=num(row.get('entry_price'),default=0.0) or 0.0
    net=pct(current_price,entry) if entry>0 and current_price>0 else num(row.get('pnl_pct'),default=0.0) or 0.0
    peak=max(num(row.get('mfe_pct'),row.get('peak_pct'),default=net) or net,net)
    trough=min(num(row.get('mae_pct'),row.get('trough_pct'),default=net) or net,net)
    row.update({'current_price':current_price,'pnl_pct':net,'net_pct':net,'mfe_pct':peak,'mae_pct':trough,'giveback_pct':max(0.0,peak-net),'last_mark_ts':now})
    return row

def evaluate(position:Dict[str,Any],cfg:RuntimeConfig,now:float|None=None)->Dict[str,Any]:
    now=float(now or now_ts()); cur=num(position.get('current_price'),default=0.0) or 0.0; entry=num(position.get('entry_price'),default=0.0) or 0.0
    invalid=num(position.get('swing_invalid_price_v977'),position.get('invalid_price'),default=0.0) or 0.0; target=num(position.get('swing_target_price_v977'),position.get('target_price'),default=0.0) or 0.0
    net=num(position.get('net_pct'),position.get('pnl_pct'),default=pct(cur,entry) if cur and entry else 0.0) or 0.0
    peak=num(position.get('mfe_pct'),position.get('peak_pct'),default=net) or net; give=max(0.0,peak-net)
    opened=parse_ts(position.get('opened_ts'),position.get('opened_at'),position.get('entry_ts')); age=max(0.0,now-opened) if opened else 0.0
    contract=position.get('exit_contract_v1038') if isinstance(position.get('exit_contract_v1038'),dict) else {}
    reason='structure_hold'; action='hold'
    # Preserve documented current priority: invalid → target → trailing → 6h → 72h.
    if invalid>0 and cur>0 and cur<=invalid: action='close'; reason='structure_invalid'
    elif target>0 and cur>0 and cur>=target: action='close'; reason='structure_target'
    elif invalid<=0 and net<=cfg.thresholds.emergency_stop_pct: action='close'; reason='swing_emergency_stop'
    elif contract.get('trailing_exit') is True or contract.get('trailing_enabled') is True:
        trigger=num(contract.get('trailing_trigger_pct'),default=cfg.thresholds.trailing_trigger_pct) or cfg.thresholds.trailing_trigger_pct
        limit=num(contract.get('trailing_giveback_pct'),default=cfg.thresholds.trailing_giveback_pct) or cfg.thresholds.trailing_giveback_pct
        if peak>=trigger and give>=limit and net>0: action='close'; reason='swing_trailing'
    if action=='hold' and age>=cfg.thresholds.no_progress_sec and peak<0.5: action='close'; reason='swing_no_progress'
    if action=='hold' and age>=cfg.thresholds.max_weak_hold_sec and net<=0: action='close'; reason='swing_max_weak_hold'
    return {'schema':'exit_decision_v1067','action':action,'reason':reason,'current_price':cur or None,'entry_price':entry or None,'invalid_price':invalid or None,'target_price':target or None,'net_pct':net,'peak_pct':peak,'giveback_pct':give,'age_sec':age,'evaluated_ts':now}

def closed_row(position:Dict[str,Any],decision:Dict[str,Any],now:float|None=None)->Dict[str,Any]:
    now=float(now or now_ts()); row=dict(position)
    row.update({'closed_ts':now,'closed_at':now,'exit_price':decision.get('current_price'),'exit_reason':decision.get('reason'),'close_reason':decision.get('reason'),'pnl_pct':decision.get('net_pct'),'net_pct':decision.get('net_pct'),'final_realized_pnl_pct':decision.get('net_pct'),'hold_sec':decision.get('age_sec'),'giveback_pct':decision.get('giveback_pct'),'mfe_pct':decision.get('peak_pct'),'closed_exact_v1067':True})
    return row
