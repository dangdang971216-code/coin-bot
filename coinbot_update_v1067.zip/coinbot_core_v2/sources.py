from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import Any,Dict,List
from .common import read_json,read_jsonl_tail,row_map,rows,ticker,merge_nonempty,num,now_ts
from .config import RuntimeConfig

@dataclass
class SourceBundle:
    scanner: Dict[str,Dict[str,Any]]
    pool: Dict[str,Dict[str,Any]]
    hot: Dict[str,Dict[str,Any]]
    candle: Dict[str,Dict[str,Any]]
    market: Dict[str,Any]
    feature: Dict[str,Dict[str,Any]]
    orderflow: Dict[str,Dict[str,Any]]
    ws: Dict[str,Dict[str,Any]]
    micro: Dict[str,Dict[str,Any]]
    merged: Dict[str,Dict[str,Any]]

class SourceReader:
    def __init__(self,cfg:RuntimeConfig): self.cfg=cfg
    def load(self)->SourceBundle:
        p=self.cfg.paths
        scanner=row_map(read_json(p.scanner_market,{})); pool=row_map(read_json(p.scanner_pool,{})); hot=row_map(read_json(p.scanner_hot,{}))
        candle=row_map(read_json(p.candle_cache,{})); feature=row_map(read_json(p.feature_cache,{})); orderflow=row_map(read_json(p.orderflow_cache,{})); ws=row_map(read_json(p.ws_cache,{})); micro=row_map(read_json(p.micro_cache,{}))
        market=read_json(p.market_regime,{}) or {}; regime_rows=row_map(market)
        tickers=set(scanner)|set(pool)|set(hot)|set(candle)|set(feature)|set(orderflow)|set(ws)|set(micro)
        merged={}
        for t in tickers:
            row=merge_nonempty(scanner.get(t,{}),pool.get(t,{}),candle.get(t,{}),feature.get(t,{}),hot.get(t,{}),orderflow.get(t,{}),ws.get(t,{}),micro.get(t,{}))
            if t in regime_rows:
                row=merge_nonempty(row,regime_rows[t])
            elif isinstance(market,dict):
                global_regime=market.get('market_regime') or market.get('regime') or market.get('state')
                if global_regime not in (None,''):
                    row.setdefault('market_regime',global_regime)
            row['ticker']=t
            row['_sources_present']={name:bool(src.get(t)) for name,src in [('scanner',scanner),('pool',pool),('hot',hot),('candle',candle),('feature',feature),('orderflow',orderflow),('ws',ws),('micro',micro)]}
            merged[t]=row
        return SourceBundle(scanner,pool,hot,candle,market,feature,orderflow,ws,micro,merged)
