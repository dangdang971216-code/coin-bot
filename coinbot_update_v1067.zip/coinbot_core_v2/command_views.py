from __future__ import annotations
import json
from pathlib import Path
from typing import Any,Dict,List
from .common import read_json,read_jsonl_tail,num,text,ticker,parse_ts,now_ts
from .config import RuntimeConfig,STRATEGY_MODE

MAIN_COMMANDS={
'batch','batch_full','book_reset_status','change_verify','change_verify_full','commands','early_audit','errorlog','health','help','issue_history','issue_ledger','ledger_audit','line_audit','menu','open_book_audit','open_exposure_shadow','performance_lab','popen','profit_audit','status','structure','structure_board','swing_status','trade_review','version_score'}
PAPER_COMMANDS={'batch','candidate','candidate_summary','commands','error','guide','help','hot','hot_summary','hourly','log','open','paper_hourly','pbatch','pcandidate','perror','pguide','phot','phourly','plog','ponce','popen','pstatus','pversion','status','trade_review','version'}

def _snap(cfg:RuntimeConfig)->Dict[str,Any]: return read_json(cfg.paths.command_snapshot,{}) or {}
def _fmt_pct(v:Any)->str: return f'{num(v,default=0.0) or 0.0:+.2f}%'
def _worker_lines(s:Dict[str,Any])->List[str]:
    out=[]
    for name,obj in (s.get('workers') or {}).items():
        age=obj.get('age_sec'); ok=age is not None and age<180 and not obj.get('error')
        out.append(f"{'✅' if ok else '⚠️'} {name} · {obj.get('version') or '-'} · age {age:.1f}s" if isinstance(age,(int,float)) else f"⚠️ {name} · status 없음")
    return out

def health(cfg:RuntimeConfig)->str:
    s=_snap(cfg); paper=s.get('paper') or {}; perf=s.get('performance') or {}; led=s.get('ledger') or {}
    lines=['🧭 코인봇 상태 · CORE V2 v1067','', '[전체 상태]',f"{'✅' if not s.get('errors') else '⚠️'} worker 오류 {len(s.get('errors') or [])}",f"🔒 자동매수 OFF · 전략 {s.get('strategy_mode') or STRATEGY_MODE}",f"📦 OPEN {s.get('open_count',0)} · exact CLOSED {perf.get('exact_count',0)}",f"✅ 중복 {led.get('exact_duplicates',0)} · key 누락 {led.get('decision_key_missing',0)} · 미연결 {led.get('unlinked',0)}",'', '[워커별 상태]']
    lines+=_worker_lines(s)
    risk=(paper.get('risk_paper_contract_v1067') or paper.get('risk_paper_contract_v1059') or {})
    lines+=['','[Risk–Paper]',f"- source {'READY' if risk.get('ready') is True else 'CHECK'} / signature {risk.get('closed_signature_match')} / latest {risk.get('latest_loss_selection') or '-'}",'', '[현재 확인 필요]']
    if s.get('errors'): lines += [f'- {x}' for x in s['errors'][:8]]
    else: lines.append('- 없음')
    return '\n'.join(lines)

def swing_status(cfg:RuntimeConfig)->str:
    s=_snap(cfg); gate=s.get('gate') or {}; th=gate.get('thresholds') or {}
    return '\n'.join(['🧭 알트 스윙 설정 · ALT_SWING_V977','', '[운영 계약]','- 자동매수 OFF','- 4h·2h 대세/목표 → 1h·30m 셋업/무효 → 15m·5m trigger → 1m·호가 실행확인','- target 즉시 익절 · invalid 즉시 청산 · 최소 보유시간 없음','- 신규 OPEN 수익보호: 최고 +2.00% 후 0.80%p 반납, 현재 수익권','- 품질값·장세·전략명은 기록/우선순위용, parity 모드에서 새 하드차단 없음','', '[진입 계약]',f"- spread ≤ {th.get('untradable_spread_pct',1.2)}% / RR ≥ {th.get('minimum_risk_reward',1.5)} / 목표공간 ≥ {th.get('minimum_target_room_pct',1.2)}% / 추격 ≤ {th.get('maximum_trigger_overshoot_pct',.6)}%",'- 실제 진입가 RR은 현재 본선과 동일하게 기록만 함(parity); 조건 변경은 별도 승인 후','', '[단일 주인]','- Strategy: core_v2.strategy_engine','- Risk: core_v2.risk_engine','- Paper/원장/성과: core_v2.paper_engine + paper_store + performance'])

def version_score(cfg:RuntimeConfig)->str:
    s=_snap(cfg); p=s.get('performance') or {}; windows=p.get('windows') or {}; o=p.get('overall') or {}; op=p.get('current_open') or {}
    lines=['📊 성과 /version_score · canonical 단일본선']
    for label,key in [('최근 3시간','3h'),('최근 6시간','6h'),('최근 24시간','24h')]:
        x=windows.get(key) or {}; lines.append(f"- {label}: {x.get('count',0)}전 {x.get('wins',0)}승 {x.get('losses',0)}패 / 합산 {_fmt_pct(x.get('sum_pct'))} / 평균 {_fmt_pct(x.get('avg_pct'))}")
    lines += ['', '[전체 exact]',f"- {o.get('count',0)}전 {o.get('wins',0)}승 {o.get('losses',0)}패 / 합산 {_fmt_pct(o.get('sum_pct'))} / 평균 {_fmt_pct(o.get('avg_pct'))}",'', '[현재 OPEN]',f"- {op.get('count',0)}개 / 수익 {op.get('wins',0)} · 손실 {op.get('losses',0)} / 평가합 {_fmt_pct(op.get('sum_pct'))}",'', '[snapshot·원장]',f"- snapshot {p.get('snapshot_id') or '-'}",f"- raw {p.get('raw_count',0)} · exact {p.get('exact_count',0)} · 중복 {p.get('duplicates',0)} · key 누락 {p.get('decision_key_missing',0)} · 미연결 {p.get('unlinked',0)}",'- 거래별 % 단순합 · 계좌 누적수익률 아님']
    return '\n'.join(lines)

def structure_board(cfg:RuntimeConfig)->str:
    s=_snap(cfg); st=s.get('strategy') or {}; gate=s.get('gate') or {}; top=gate.get('hard_reason_top') or {}
    lines=['📐 /structure_board · CORE V2 canonical',f"- 평가 {st.get('evaluated',0)} / S1 {st.get('s1_count',0)} / S2 {st.get('s2_count',0)} / S3 {st.get('s3_count',0)}",f"- gate rows {gate.get('rows',0)} / source owner {gate.get('single_owner') or 'core_v2.strategy_engine'}",'', '[대기·차단 TOP]']
    if top:
        lines += [f'- {k}: {v}' for k,v in list(top.items())[:12]]
    else: lines.append('- 없음')
    lines += ['','[원칙]','- 구조선·trigger·invalid·target은 Strategy가 한 번 봉인','- Paper는 현재 구조를 다시 계산하지 않고 봉인 계약만 소비']
    return '\n'.join(lines)

def popen(cfg:RuntimeConfig)->str:
    s=_snap(cfg); arr=s.get('open_positions') or []
    lines=[f'📂 PAPER OPEN · CORE V2 v1067','- 기준: paper_bot_open.json active OPEN',f'- 정상 OPEN: {len(arr)}개']
    for i,row in enumerate(arr[:12],1):
        t=ticker(row.get('ticker')); entry=num(row.get('entry_price'),default=0.0) or 0.0; cur=num(row.get('current_price'),default=0.0) or 0.0; pnl=num(row.get('net_pct'),row.get('pnl_pct'),default=0.0) or 0.0
        lines += ['',f'[{i}] {t}',f"진입 방식: {text(row.get('actual_entry_method'),row.get('entry_method')) or '-'}",f'진입가 → 현재가: {entry:,.8g} → {cur:,.8g} · {pnl:+.2f}%',f"Trigger {num(row.get('trigger_price'),default=0):,.8g} / Invalid {num(row.get('invalid_price'),default=0):,.8g} / Target {num(row.get('target_price'),default=0):,.8g}",f"MFE {num(row.get('mfe_pct'),default=0):+.2f}% · MAE {num(row.get('mae_pct'),default=0):+.2f}% · 반납 {num(row.get('giveback_pct'),default=0):.2f}%p"]
    if len(arr)>12: lines += ['',f'외 {len(arr)-12}개 · 원장은 모두 보존']
    return '\n'.join(lines)

def trade_review(cfg:RuntimeConfig)->str:
    s=_snap(cfg); p=s.get('performance') or {}; rows=p.get('recent_closed') or []
    lines=['🧪 거래 복기 /trade_review · canonical 단일본선','', '[최근 CLOSED]']
    for row in reversed(rows[-10:]):
        lines.append(f"- {ticker(row.get('ticker'))} {_fmt_pct(row.get('pnl_pct') or row.get('net_pct'))} · {text(row.get('actual_entry_method'),row.get('entry_method'),row.get('strategy_label')) or '-'} · {text(row.get('exit_reason'),row.get('close_reason')) or '-'}")
    if not rows: lines.append('- 표본 없음')
    lines += ['','[판독]','- 진입 당시 봉인값과 CLOSED exact key만 사용','- 현재값으로 과거 거래 재계산·재분류 없음']
    return '\n'.join(lines)

def ledger_tail(path:Path,title:str,limit:int=8)->str:
    rows=read_jsonl_tail(path,limit=limit,max_bytes=4*1024*1024)
    lines=[title]
    for row in rows[-limit:]: lines.append(f"- {text(row.get('version'),row.get('change_id'),row.get('issue_id'),row.get('id')) or '-'} · {text(row.get('status'),row.get('state')) or '-'} · {text(row.get('summary'),row.get('title'),row.get('reason'))[:180]}")
    if not rows: lines.append('- 기록 없음')
    return '\n'.join(lines)

def errorlog(cfg:RuntimeConfig)->str:
    s=_snap(cfg); errors=s.get('errors') or []
    return '🧯 /errorlog · canonical\n\n'+('✅ 새 실행 중 오류 없음' if not errors else '\n'.join(['⚠️ 현재 오류']+[f'- {x}' for x in errors[:20]]))

def commands_text(scope:str)->str:
    cmds=sorted(MAIN_COMMANDS if scope=='main' else PAPER_COMMANDS)
    return f"🧭 CORE V2 {scope} 명령\n"+' '.join('/'+x for x in cmds)

def render_main(command:str,cfg:RuntimeConfig,args:List[str]|None=None)->str:
    c=command.lower().lstrip('/').split('@')[0]
    if c in {'health','status'}: return health(cfg)
    if c=='swing_status': return swing_status(cfg)
    if c=='version_score': return version_score(cfg)
    if c in {'structure','structure_board','line_audit'}: return structure_board(cfg)
    if c in {'popen','open_book_audit'}: return popen(cfg)
    if c=='trade_review': return trade_review(cfg)
    if c=='errorlog': return errorlog(cfg)
    if c in {'commands','help','menu'}: return commands_text('main')
    if c in {'change_verify','change_verify_full'}: return ledger_tail(cfg.paths.change_ledger,'🧾 /change_verify · append-only',20 if c.endswith('full') else 8)
    if c in {'issue_ledger','issue_history'}: return ledger_tail(cfg.paths.issue_ledger,'🧾 /issue_ledger · append-only',20 if c.endswith('history') else 8)
    if c in {'ledger_audit'}:
        s=_snap(cfg); l=s.get('ledger') or {}; return f"🧾 원장 감사\n- OPEN {s.get('open_count',0)}\n- 중복 {l.get('exact_duplicates',0)} / key 누락 {l.get('decision_key_missing',0)} / 미연결 {l.get('unlinked',0)}"
    if c in {'performance_lab','profit_audit','early_audit'}: return version_score(cfg)+'\n\n'+trade_review(cfg)
    if c=='open_exposure_shadow':
        s=_snap(cfg); ctrl=read_json(cfg.paths.paper_control,{}) or {}; return f"📦 OPEN 노출\n- 현재 OPEN {s.get('open_count',0)}\n- 전체 한도 {int(num(ctrl.get('max_open_strict'),default=0) or 0)} / cycle 신규 {int(num(ctrl.get('max_new_per_cycle'),default=0) or 0)}\n- 0은 현재 계약상 무제한"
    if c=='book_reset_status':
        e=read_json(cfg.paths.base/'paper_performance_epoch_v1045.json',{}) or {}; return f"🧹 장부 전환\n- 상태 {e.get('state') or 'CHECK'}\n- epoch {e.get('epoch_id') or '-'}\n- 원본 원장 보존"
    if c in {'batch','batch_full'}:
        parts=[health(cfg),version_score(cfg),structure_board(cfg)]
        if c=='batch_full': parts += [trade_review(cfg),ledger_tail(cfg.paths.change_ledger,'🧾 최신 변경',8),ledger_tail(cfg.paths.issue_ledger,'🧾 최신 이슈',8),commands_text('main')]
        return '\n\n'.join(parts)
    return commands_text('main')

def pstatus(cfg:RuntimeConfig)->str:
    s=_snap(cfg); p=s.get('paper') or {}; picks=p.get('pick_stats') or {}; ex=p.get('exit_monitor') or {}; risk=p.get('risk_paper_contract_v1067') or {}
    return '\n'.join(['🧪 paper 상태 /pstatus · paper_bot_v1.001',f"- runtime pid={p.get('pid')} / writer={p.get('writer_pid')} / owner={p.get('writer_owner')}",f"- OPEN {p.get('open_count',0)} / 이번 cycle OPEN {p.get('opened_count',0)} / CLOSED {p.get('closed_count',0)}",f"- S1 감지 {picks.get('s1_seen',0)} / 선택 {picks.get('selected_s1',0)} / OPEN {picks.get('opened',0)}",f"- Risk source {'READY' if risk.get('ready') is True else 'CHECK'} / signature {risk.get('closed_signature_match')} / latest {risk.get('latest_loss_selection') or '-'}",f"- exit checked {ex.get('checked',0)} / closed {ex.get('closed',0)} / failed {ex.get('failed',0)}",'- source: CORE V2 canonical snapshot + frozen OPEN contract'])

def candidate_summary(cfg:RuntimeConfig)->str:
    s=_snap(cfg); st=s.get('strategy') or {}; gate=s.get('gate') or {}; return f"🧪 후보판\n- 평가 {st.get('evaluated',0)} / S1 {st.get('s1_count',0)} / S2 {st.get('s2_count',0)} / S3 {st.get('s3_count',0)}\n- gate owner {gate.get('single_owner') or '-'}"

def render_paper(command:str,cfg:RuntimeConfig,args:List[str]|None=None)->str:
    c=command.lower().lstrip('/').split('@')[0]
    if c in {'pstatus','status','batch','pbatch'}: return pstatus(cfg)
    if c in {'popen','open'}: return popen(cfg)
    if c in {'perror','error'}: return errorlog(cfg).replace('/errorlog','/perror')
    if c in {'pcandidate','candidate','candidate_summary','hot','hot_summary','phot'}: return candidate_summary(cfg)
    if c in {'trade_review','hourly','paper_hourly','phourly'}: return trade_review(cfg)
    if c in {'commands','help','guide','pguide'}: return commands_text('paper')
    if c in {'pversion','version'}: return '📦 Paper 버전\n- paper_bot_v1.001\n- CORE V2 v1067\n- 자동매수 OFF'
    if c in {'ponce'}: return '🧪 1회 cycle은 Paper runtime 단일 owner가 수행 중\n- 수동 중복 실행 금지'
    if c in {'log','plog'}: return '📄 Paper 로그\n- /perror에서 canonical 오류 확인\n- 원본 오류로그는 서버에 보존'
    return commands_text('paper')
