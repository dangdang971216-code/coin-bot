from __future__ import annotations
import json,os,time,urllib.parse,urllib.request
from typing import Callable,List,Optional

class TelegramPoller:
    def __init__(self,token:str,allowed_chat_id:str,handler:Callable[[str,List[str]],str],name:str):
        self.token=token.strip(); self.allowed=str(allowed_chat_id or '').strip(); self.handler=handler; self.name=name; self.offset=0
    def api(self,method:str,params:dict,timeout:int=15):
        data=urllib.parse.urlencode(params).encode(); req=urllib.request.Request(f'https://api.telegram.org/bot{self.token}/{method}',data=data)
        with urllib.request.urlopen(req,timeout=timeout) as r: return json.loads(r.read().decode('utf-8',errors='ignore'))
    def send(self,chat_id:str,text:str)->None:
        remaining=str(text or '(empty)')
        while remaining:
            chunk=remaining[:3600]; remaining=remaining[3600:]
            try: self.api('sendMessage',{'chat_id':chat_id,'text':chunk,'disable_web_page_preview':'true'})
            except Exception: pass
    def poll_once(self)->int:
        if not self.token: return 0
        try: result=self.api('getUpdates',{'offset':self.offset,'timeout':1,'allowed_updates':'["message"]'},timeout=5)
        except Exception: return 0
        count=0
        for update in result.get('result') or []:
            self.offset=max(self.offset,int(update.get('update_id') or 0)+1); msg=update.get('message') or {}; chat=str((msg.get('chat') or {}).get('id') or ''); raw=str(msg.get('text') or '').strip()
            if not raw or (self.allowed and chat!=self.allowed): continue
            for line in [x.strip() for x in raw.splitlines() if x.strip().startswith('/')]:
                parts=line.split(); cmd=parts[0]; args=parts[1:]
                try: out=self.handler(cmd,args)
                except Exception as exc: out=f'오류: {type(exc).__name__}: {exc}'
                self.send(chat,out); count+=1
        return count
