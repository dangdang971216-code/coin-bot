from __future__ import annotations
import os,time,traceback
from collections import Counter
from typing import Any,Dict,List,Tuple
from .common import read_json,atomic_write_json,append_jsonl_fsync,file_signature,num,text,ticker,parse_ts,now_ts,now_text,rows,merge_nonempty
from .config import RuntimeConfig,BUILD,STRATEGY_MODE
from .sources import SourceReader
from .risk_engine import loss_reentry_decision
from .execution_engine import evaluate as evaluate_execution
from .paper_store import PaperStore
from .exit_engine import mark_position,evaluate as evaluate_exit,closed_row
from .performance import PerformanceWriter

class PaperEngine:
    def __init__(self,cfg:RuntimeConfig):
        self.cfg=cfg; self.sources=SourceReader(cfg); self.store=PaperStore(cfg); self.perf=PerformanceWriter(cfg); self.last_status={}
    def control(self)->Dict[str,Any]:
        obj=read_json(self.cfg.paths.paper_control,{}) or {}
        return obj if isinstance(obj,dict) else {}
    def _risk_contract(self,risk:Dict[str,Any])->Dict[str,Any]:
        contract=risk.get('loss_reentry_source_contract_v1057') if isinstance(risk.get('loss_reentry_source_contract_v1057'),dict) else {}
        current=file_signature(self.cfg.paths.paper_closed); sig=contract.get('closed_signature') if isinstance(contract.get('closed_signature'),dict) else {}
        checks={
          'contract_schema':contract.get('schema')=='loss_reentry_source_contract_v1057','owner':contract.get('owner')=='risk_worker','source_complete':contract.get('source_complete') is True,
          'selection_owner':contract.get('latest_loss_selection')=='max_numeric_closed_ts_per_ticker','event_map':isinstance(risk.get('last_loss_event_by_ticker'),dict),'signature_match':bool(sig and sig==current),
        }
        ready=all(checks.values())
        return {'schema':'paper_risk_contract_status_v1067','ready':ready,'closed_signature_match':checks['signature_match'],'latest_loss_selection':contract.get('latest_loss_selection'),'consumer_evidence_present':True,'heartbeat_preserve_mode':True,'checks':checks,'reason':'ready' if ready else 'contract_check_failed:'+','.join(k for k,v in checks.items() if not v),'owner':'paper_bot.write_status'}
    def _candidate_rows(self)->List[Dict[str,Any]]:
        obj=read_json(self.cfg.paths.s1_hold,{}) or {}
        return [r for r in rows(obj) if isinstance(r,dict)]
    def _position(self,row:Dict[str,Any],execution:Dict[str,Any],reentry:Dict[str,Any],now:float)->Dict[str,Any]:
        gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
        decision=text(row.get('swing_gate_decision_key_v977'),gate.get('decision_key'))
        candidate=text((row.get('trigger_occurrence_v1037') or {}).get('candidate_key') if isinstance(row.get('trigger_occurrence_v1037'),dict) else '',row.get('trigger_occurrence_candidate_key_v1037'),row.get('candidate_entry_build_key'),row.get('entry_build_key'))
        pos_id=decision if decision.startswith('decision:') else f'decision:{decision}'
        epoch=read_json(self.cfg.paths.base/'paper_performance_epoch_v1045.json',{}) or {}
        entry=execution.get('entry_price')
        costs={'configured_fee_pct':num(row.get('configured_fee_pct'),default=.1),'spread_pct':execution.get('spread_pct'),'slippage_pct':execution.get('confirmed_slippage_pct')}
        return {
          'schema':'paper_open_position_v1067','pos_id':pos_id,'ticker':ticker(row.get('ticker')),'strategy_mode':STRATEGY_MODE,
          'actual_entry_method':text(row.get('strategy_label'),row.get('strategy_key')) or STRATEGY_MODE,'canonical_lane':row.get('canonical_lane'),
          'candidate_key':candidate,'trigger_occurrence_candidate_key_v1037':candidate,'paper_decision_key_v926':decision,'swing_gate_decision_key_v977':decision,
          'entry_price':entry,'opened_ts':now,'opened_at':now,'current_price':entry,'net_pct':0.0,'pnl_pct':0.0,'mfe_pct':0.0,'mae_pct':0.0,'giveback_pct':0.0,
          'swing_trigger_price_v977':execution.get('trigger_price'),'swing_invalid_price_v977':execution.get('invalid_price'),'swing_target_price_v977':execution.get('target_price'),
          'trigger_price':execution.get('trigger_price'),'invalid_price':execution.get('invalid_price'),'target_price':execution.get('target_price'),
          'trigger_rr':gate.get('risk_reward'),'actual_entry_rr_v1034':execution.get('actual_entry_rr_v1034'),'target_room_pct':gate.get('target_room_pct'),
          'spread_pct':execution.get('spread_pct'),'paper_slippage_pct':execution.get('confirmed_slippage_pct'),'paper_slippage_source':execution.get('confirmed_slippage_source'),
          'trigger_chase_pct':execution.get('trigger_chase_pct'),'execution_cost':costs,
          'market_regime':text(row.get('market_regime'),row.get('regime')) or None,'quality_observation_v925':row.get('quality_observation_v925') or {},
          'trigger_occurrence_v1037':row.get('trigger_occurrence_v1037') or {},'loss_reentry_gate_v1037':reentry,
          'swing_entry_gate_v977':gate,'swing_structure_plan_v977':row.get('swing_structure_plan_v977') or {},
          'exit_contract_v1038':{'schema':'alt_swing_exit_contract_v1038','trailing_exit':True,'trailing_trigger_pct':self.cfg.thresholds.trailing_trigger_pct,'trailing_giveback_pct':self.cfg.thresholds.trailing_giveback_pct,'no_progress_sec':self.cfg.thresholds.no_progress_sec,'max_weak_hold_sec':self.cfg.thresholds.max_weak_hold_sec,'frozen_at_open':True},
          'performance_epoch_id':text(epoch.get('epoch_id')) or None,'performance_epoch_role':'post_reset_strategy_open','performance_epoch_started_at':epoch.get('started_at'),'performance_epoch_reset_batch_id':epoch.get('reset_batch_id'),'performance_epoch_sealed_at':now,'performance_epoch_sealed_by':'paper_single_open_writer_v1067',
          'auto_buy':False,'opened_by':'core_v2.paper_engine',
        }
    def write_status(self,status:Dict[str,Any])->None:
        out=dict(self.last_status); out.update(status); now=now_ts()
        out.update({'version':'paper_bot_v1.001','build':BUILD,'running':True,'pid':os.getpid(),'writer_pid':os.getpid(),'writer_owner':'paper_bot_single_status_writer_v1067','writer_count':1,'updated_ts':now,'updated_at':now,'updated_text':now_text(now),'auto_buy':False,'engine':'core_v2_single_spine'})
        self.last_status=out; atomic_write_json(self.cfg.paths.paper_status,out)
    def select_and_open(self,now:float|None=None)->Dict[str,Any]:
        started=time.monotonic(); now=float(now or now_ts()); ctrl=self.control(); open_pos=self.store.load_open(); decisions=self.store.load_decisions(); records=decisions.get('records') if isinstance(decisions.get('records'),dict) else {}
        risk=read_json(self.cfg.paths.risk_cache,{}) or {}; contract=self._risk_contract(risk); prior_map=risk.get('last_loss_event_by_ticker') if isinstance(risk.get('last_loss_event_by_ticker'),dict) else {}
        source=self.sources.load(); candidate_rows=self._candidate_rows(); stats=Counter(); blocks=Counter(); opened=[]; selected=[]
        max_open=int(num(ctrl.get('max_open_strict'),default=0) or 0); max_new=int(num(ctrl.get('max_new_per_cycle'),default=0) or 0); ttl=max(10.0,num(ctrl.get('candidate_ttl_sec'),default=120.0) or 120.0)
        pause=bool(ctrl.get('pause_new_open') or ctrl.get('new_open_paused') or ctrl.get('book_reset_entry_freeze'))
        open_tickers={ticker(r.get('ticker')) for r in open_pos.values() if isinstance(r,dict)}
        for raw in candidate_rows:
            stats['s1_seen']+=1
            if max_open>0 and len(open_pos)>=max_open: blocks['open_limit']+=1; continue
            if max_new>0 and len(opened)>=max_new: blocks['cycle_limit']+=1; continue
            if pause: blocks['new_open_paused']+=1; continue
            updated=parse_ts(raw.get('updated_ts'),raw.get('created_ts'),raw.get('ts'))
            if updated and now-updated>ttl: blocks['candidate_ttl_stale']+=1; continue
            t=ticker(raw.get('ticker'))
            if not t: blocks['ticker_missing']+=1; continue
            live=source.merged.get(t,{})
            merged=merge_nonempty(live,raw)  # frozen candidate contract wins over volatile worker fields
            for key in ('current_price','trade_price','price','close','best_ask','ask_price','quote_ask','micro_best_ask','best_bid','spread_pct','micro_spread_pct','orderbook_spread_pct','confirmed_slippage_pct','paper_slippage_pct','slippage_pct','paper_slippage_source'):
                if live.get(key) not in (None,'',[],{}): merged[key]=live.get(key)
            merged['_sources_present']=live.get('_sources_present') or merged.get('_sources_present') or {}
            merged['ticker']=t
            gate=merged.get('swing_entry_gate_v977') if isinstance(merged.get('swing_entry_gate_v977'),dict) else {}
            decision=text(merged.get('swing_gate_decision_key_v977'),gate.get('decision_key'))
            if not decision: blocks['decision_key_missing']+=1; continue
            if t in open_tickers: blocks['same_ticker_open']+=1; continue
            if ((records.get(decision) or {}).get('state') in {'OPEN','CLOSED'}): blocks['decision_already_handled']+=1; continue
            execution=evaluate_execution(merged,self.cfg)
            if not execution.get('allowed'):
                for reason in execution.get('reasons') or []: blocks[f'execution:{reason}']+=1
                continue
            if not contract.get('ready'): blocks['risk_contract_not_ready']+=1; continue
            reentry=loss_reentry_decision(merged,prior_map.get(t) if isinstance(prior_map,dict) else None)
            if not reentry.get('allowed'): blocks[f'reentry:{reentry.get("state")}']+=1; continue
            selected.append(t); position=self._position(merged,execution,reentry,now)
            try:
                self.store.commit_open(position); open_pos[position['pos_id']]=position; open_tickers.add(t); opened.append(t)
            except Exception as exc:
                blocks[f'open_commit:{type(exc).__name__}']+=1; append_jsonl_fsync(self.cfg.paths.paper_events,{'schema':'paper_core_v2_error_v1067','ts':now,'where':'commit_open','ticker':t,'error':f'{type(exc).__name__}: {exc}'})
        status={'phase':'cycle_done','open_count':len(self.store.load_open()),'open_total':len(self.store.load_open()),'opened_count':len(opened),'closed_count':0,'elapsed_sec':round(time.monotonic()-started,6),'pick_stats':dict(stats)|{'selected_s1':len(selected),'opened':len(opened),'block_reasons':dict(blocks),'max_open_strict':max_open,'max_new_per_cycle':max_new},'risk_paper_contract_v1059':contract,'risk_paper_contract_v1067':contract,'loss_reentry_source_ready_v1057':contract.get('ready'),'loss_reentry_source_closed_signature_match_v1057':contract.get('closed_signature_match'),'last_opened':opened[-10:]}
        self.write_status(status); return status
    def monitor_exits(self,now:float|None=None)->Dict[str,Any]:
        started=time.monotonic(); now=float(now or now_ts()); source=self.sources.load(); open_pos=self.store.load_open(); updated_all=dict(open_pos); closed=[]; checked=0; close_fail=[]
        for pid,position in list(open_pos.items()):
            if not isinstance(position,dict): continue
            t=ticker(position.get('ticker')); current_row=source.merged.get(t,{})
            current=num(current_row.get('current_price'),current_row.get('best_bid'),current_row.get('trade_price'),current_row.get('price'),current_row.get('close'),position.get('current_price'),default=0.0) or 0.0
            if current<=0: continue
            checked+=1; marked=mark_position(position,current,now); decision=evaluate_exit(marked,self.cfg,now); updated_all[pid]=marked
            if decision.get('action')!='close': continue
            row=closed_row(marked,decision,now); ok,reason=self.store.commit_closed(pid,marked,row,'paper_exact_exit_monitor_v1067')
            if ok: updated_all.pop(pid,None); closed.append({'ticker':t,'pos_id':pid,'reason':decision.get('reason'),'pnl_pct':decision.get('net_pct')})
            else: close_fail.append({'ticker':t,'pos_id':pid,'reason':reason})
        # Persist marks only after exact close commits have updated disk; reload and merge surviving marks.
        if checked:
            disk=self.store.load_open(); changed=False
            for pid,row in list(disk.items()):
                if pid in updated_all: disk[pid]=updated_all[pid]; changed=True
            if changed: self.store.save_open(disk)
        perf=self.perf.build(now) if closed else None
        status=dict(self.last_status); status.update({'phase':'exit_done','open_count':len(self.store.load_open()),'open_total':len(self.store.load_open()),'closed_count':len(closed),'exit_monitor':{'checked':checked,'closed':len(closed),'failed':len(close_fail),'elapsed_sec':round(time.monotonic()-started,6),'closed_rows':closed[-10:],'failures':close_fail[-10:]}})
        self.write_status(status); return status
    def cycle(self)->Dict[str,Any]:
        select=self.select_and_open(); exits=self.monitor_exits(); return {'select':select,'exit':exits}
