from __future__ import annotations
import os,time
from threading import RLock
from typing import Any,Dict,List,Mapping,Tuple
from .common import read_json,atomic_write_json,append_jsonl_fsync,read_jsonl_tail,text,now_ts,now_text
from .config import RuntimeConfig

class PaperStore:
    def __init__(self,cfg:RuntimeConfig): self.cfg=cfg; self.lock=RLock()
    def load_open(self)->Dict[str,Dict[str,Any]]:
        obj=read_json(self.cfg.paths.paper_open,{}) or {}
        return {str(k):dict(v) for k,v in obj.items() if isinstance(v,dict)} if isinstance(obj,dict) else {}
    def save_open(self,open_pos:Dict[str,Dict[str,Any]])->None:
        with self.lock:
            atomic_write_json(self.cfg.paths.paper_open,open_pos)
            verify=read_json(self.cfg.paths.paper_open,None)
            if not isinstance(verify,dict) or set(verify)!=set(open_pos): raise RuntimeError('OPEN persistence verification failed')
    def load_decisions(self)->Dict[str,Any]:
        obj=read_json(self.cfg.paths.paper_decision,{}) or {}
        if isinstance(obj,dict) and isinstance(obj.get('records'),dict): return obj
        return {'schema':'paper_decision_state_v1067','records':{},'updated_ts':0}
    def set_decision(self,decision_key:str,state:str,pos_id:str,reason:str='',extra:Dict[str,Any]|None=None)->None:
        if not decision_key: raise ValueError('decision_key required')
        with self.lock:
            obj=self.load_decisions(); records=obj.setdefault('records',{})
            row=dict(records.get(decision_key) or {}); row.update({'decision_key':decision_key,'state':state,'pos_id':pos_id,'reason':reason or None,'updated_ts':now_ts(),'updated_text':now_text()})
            if extra: row.update(extra)
            records[decision_key]=row; obj.update({'schema':'paper_decision_state_v1067','owner':'core_v2.paper_store','updated_ts':now_ts()})
            atomic_write_json(self.cfg.paths.paper_decision,obj)
            verify=read_json(self.cfg.paths.paper_decision,{}) or {}
            if ((verify.get('records') or {}).get(decision_key) or {}).get('state')!=state: raise RuntimeError('decision persistence verification failed')
            append_jsonl_fsync(self.cfg.paths.paper_decision_events,{'schema':'paper_decision_event_v1067','ts':now_ts(),'decision_key':decision_key,'state':state,'pos_id':pos_id,'reason':reason or None})
    def closed_has_key(self,pos_id:str,decision_key:str)->bool:
        for row in reversed(read_jsonl_tail(self.cfg.paths.paper_closed,limit=4000,max_bytes=64*1024*1024)):
            if text(row.get('pos_id'))==pos_id or text(row.get('paper_decision_key_v926'),row.get('swing_gate_decision_key_v977'),row.get('decision_key'))==decision_key: return True
        return False
    def commit_open(self,position:Dict[str,Any])->None:
        pos_id=text(position.get('pos_id')); decision=text(position.get('paper_decision_key_v926'),position.get('swing_gate_decision_key_v977'))
        if not pos_id or not decision: raise ValueError('OPEN identity missing')
        with self.lock:
            open_pos=self.load_open()
            if pos_id in open_pos: return
            open_pos[pos_id]=position
            self.save_open(open_pos)
            try: self.set_decision(decision,'OPEN',pos_id,'core_v2_open_commit')
            except Exception:
                rollback=self.load_open(); rollback.pop(pos_id,None); self.save_open(rollback); raise
            append_jsonl_fsync(self.cfg.paths.paper_events,{'schema':'paper_core_v2_event_v1067','ts':now_ts(),'kind':'OPEN','pos_id':pos_id,'decision_key':decision,'ticker':position.get('ticker')})
    def commit_closed(self,pos_id:str,updated:Dict[str,Any],closed:Dict[str,Any],owner:str)->Tuple[bool,str]:
        decision=text(closed.get('paper_decision_key_v926'),closed.get('swing_gate_decision_key_v977'),closed.get('decision_key'))
        if not decision: return False,'decision_key_missing'
        with self.lock:
            open_pos=self.load_open()
            if pos_id not in open_pos: return False,'open_position_missing'
            row=dict(closed); row.update({'closed_commit_owner':owner,'closed_commit_schema':'paper_closed_commit_v1067','pos_id':pos_id})
            if not self.closed_has_key(pos_id,decision):
                append_jsonl_fsync(self.cfg.paths.paper_closed,row)
                if not self.closed_has_key(pos_id,decision): return False,'closed_append_tail_verify_failed'
            try: self.set_decision(decision,'CLOSED',pos_id,'committed_exact_closed',{'closed_ts':row.get('closed_ts'),'exit_reason':row.get('exit_reason')})
            except Exception: return False,'decision_closed_commit_failed'
            remaining=dict(open_pos); remaining.pop(pos_id,None)
            try: self.save_open(remaining)
            except Exception: return False,'open_remove_persist_failed_after_exact_closed'
            append_jsonl_fsync(self.cfg.paths.paper_events,{'schema':'paper_core_v2_event_v1067','ts':now_ts(),'kind':'CLOSED','pos_id':pos_id,'decision_key':decision,'ticker':row.get('ticker'),'exit_reason':row.get('exit_reason')})
            return True,'committed_exact_closed'
