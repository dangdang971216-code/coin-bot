coinbot_update_v2109.zip

목적
1. 오늘 TOP을 KST 하루 전체 current-epoch exact CLOSED 기준으로 고정
   - bounded recent_rows fallback 제거
   - 오늘 성과판 건수와 TOP 원천 건수가 다르면 CHECK
   - 같은 ticker 재진입이 과거 CLOSED를 덮지 않음

2. v2107 Review snapshot 생성 경로 수리
   - run_once 완료 직후 entry_failure/shake snapshot 직접 저장
   - 기본 감사 명령은 전체 원장을 다시 읽지 않음

3. 약한 진입 재확인 Shadow
   - 기존 v2086/v2088 후보품질 bridge 재사용
   - 1축/2축/3축 약함, 1cycle 회복, 2cycle 연속약함 분리
   - exact CLOSED 연결 후 실제 차단 여부 판단
   - 신규 실제차단 0

4. v2107 고점안전막 exact 진단
   - ARMED / 최초 보호선 이탈 / 청산결정 시각 기록
   - 보호선 공식·target·invalid·trailing 변경 없음

버전
- Main: 수익형 v2.13.2091
- Paper: paper_bot_v2.062
- Review: review_worker_v2.038
- Strategy: strategy_worker_v2.029
- Guard: guard_v2.6.9
- 자동매수: OFF
