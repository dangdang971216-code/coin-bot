v2118 restores the existing direct candidate JSONL + S1 hold pipeline and removes v2111-v2117 transport layers. v2110 unified structure contract remains. Auto-buy OFF.
