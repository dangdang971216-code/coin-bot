코인봇 v2098 · 짧은 목표 돌파·추가수익 감사판

목적
- 목표공간이 5% 미만인 거래가 target 도달 뒤 얼마나 더 상승했는지 확인한다.
- target을 무조건 종착점으로 쓸지, 첫 수익확인점으로 바꿀 여지가 있는지 검증한다.
- target 도달 뒤 +5% runner로 이어진 거래와 target 수익을 반납한 거래를 분리한다.
- 새 Shadow·새 원장 없이 Paper canonical exact CLOSED snapshot만 읽는다.

/target_extension_audit
- 목표거리 <2 / 2~3 / 3~5 / 5~10 / 10%+별 성과와 target-first exact 비율
- target 도달 뒤 MFE 추가상승 중앙·75%·90%와 +0.5/+1/+2/+5%p 추가상승 비율
- 최종 target 이상 / 양수지만 target 미만 / 손실전환 분리
- 짧은 target 뒤 +5% 대수익과 반납형의 OPEN 당시 봉인값 비교
- target를 첫 확인점으로 보고 +0.5/+1/+2%p 확인 뒤 trailing하는 read-only proxy
- MFE +5%부터 기존 runner 허용범위 2.3%p로 전환하는 bridge proxy
- 추가상승 기회 TOP 15

중요
- target-first는 봉인된 최초 target/invalid 접촉시각으로만 판정한다.
- proxy는 MFE와 가정 반납폭을 사용한 상한 계산이며 중간 tick·비용·slippage exact가 아니다.
- 실제 연장은 target 순간 상대강도·거래대금·VWAP·5m/15m 지지 forward 자료가 확인된 뒤 별도 승인한다.

변경하지 않음
- Strategy target·구조선·trigger·invalid
- Paper 진입·청산·수익보호·재진입
- 기존 OPEN 계약과 v2086/v2089
- OPEN/CLOSED/decision/exact 원장
- 새 Shadow·generation·원장
- 자동매수 OFF

판정
- 로컬 py_compile·AST·synthetic import/fixture PASS
- 서버 적용·실제 target-first 결과 판독 전 CHECK
