#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import atexit
import fcntl
import hashlib
import json
import math
import os
import statistics
import time
import traceback
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

BASE_DIR = Path(os.getenv('TRADING_BOT_DIR', '/home/dangdang971216/trading_bot'))
VERSION = 'review_worker_v2.155'
BUILD_LABEL = 'live_probability_five_day_scoring_owner_2026-08-01'
MAIN_DEPLOY_VERSION = BUILD_LABEL
INTERVAL_SEC = max(5.0, float(os.getenv('REVIEW_WORKER_INTERVAL_SEC', '30')))
STATUS = BASE_DIR / 'clean_review_worker_status.json'
ERROR = BASE_DIR / 'clean_review_worker_error.log'
LOCK_PATH = BASE_DIR / 'runtime' / 'review_worker_singleton_v1121.lock'
SNAPSHOT = BASE_DIR / 'runtime' / 'current_candidate_snapshot_v2176.json'
CANDLE_CACHE = BASE_DIR / 'clean_candle_cache.json'
CANDLE_DELTA = BASE_DIR / 'clean_candle_delta_v1014.jsonl'
PAPER_EXACT_OPEN = BASE_DIR / 'paper_v2_exact_open_v2135.json'
PAPER_EXACT_CLOSED = BASE_DIR / 'paper_v2_exact_closed_v2135.jsonl'
LEDGER_DIR = BASE_DIR / 'rise_prediction_ledger'
ROLLUP_LEDGER = LEDGER_DIR / 'rollups.jsonl'
CHANGE_LEDGER = BASE_DIR / 'runtime' / 'change_verify_ledger.jsonl'
ISSUE_LEDGER = BASE_DIR / 'ledger' / 'issue_ledger_events.jsonl'
RAW_RETENTION_SEC = 5 * 24 * 3600.0
ROLLUP_RETENTION_SEC = 90 * 24 * 3600.0
HORIZONS = (('30m', 1800.0), ('1h', 3600.0), ('3h', 10800.0), ('6h', 21600.0))
MATERIAL_NAMES = (
    'return_30m_atr_adjusted',
    'price_acceleration_30m',
    'price_acceleration_1h',
    'relative_strength_1h',
    'relative_strength_acceleration_1h',
    'turnover_growth_recent1h_vs_prior3h',
    'turnover_acceleration_30m',
    'higher_low_strength_atr',
    'pullback_recovery_ratio',
    'target_path_consumed_ratio',
    'btc_price_acceleration_1h',
    'market_breadth_change',
    'market_liquidity_state',
)
OLD_RISE_DERIVED_PATHS = (
    BASE_DIR / 'strategy_v2_outcome_state_v2133.json',
    BASE_DIR / 'strategy_v2_outcome_status_v2133.json',
    BASE_DIR / 'strategy_v2_outcomes_v2133.jsonl',
    BASE_DIR / 'strategy_v2_actual_exact_status_v2168.json',
    BASE_DIR / 'prediction_material_recovery_status_v2339.json',
    BASE_DIR / 'runtime' / 'review_incremental_state.json',
    BASE_DIR / 'runtime' / 'review_incremental_snapshot.json',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-wal',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-shm',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-journal',
)

_LOCK_FH = None
_STATE_LOADED = False
_EVENTS: Dict[str, Dict[str, Any]] = {}
_LEGACY_EVENT_KEYS: set[str] = set()
_OUTCOMES: set[Tuple[str, str]] = set()
_OUTCOME_ROWS: Dict[Tuple[str, str], Dict[str, Any]] = {}
_ROLLED_DATES: set[str] = set()
_FINALIZED_DATES: set[str] = set()
_LAST_MAINTENANCE_DAY: Optional[str] = None
_CANDLE_SIGNATURE: Optional[Tuple[int, int]] = None
_CANDLE_INDEX: Dict[str, Dict[str, List[Dict[str, float]]]] = {}
_CANDLE_COUNT = 0
_COLLECTION_START_TS: Optional[float] = None


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts or now_ts()))


def num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or value == '' or isinstance(value, bool):
            return default
        result = float(value)
        return result if math.isfinite(result) else default
    except Exception:
        return default


def ticker(value: Any) -> str:
    return str(value or '').upper().strip().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '')


def load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    with tmp.open('w', encoding='utf-8') as handle:
        json.dump(obj, handle, ensure_ascii=False, separators=(',', ':'))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
        handle.flush()
        os.fsync(handle.fileno())


def read_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    try:
        with path.open('r', encoding='utf-8', errors='ignore') as handle:
            for line in handle:
                try:
                    item = json.loads(line)
                except Exception:
                    continue
                if isinstance(item, dict):
                    rows.append(item)
    except Exception:
        return []
    return rows


def append_error(where: str, exc: BaseException) -> None:
    ERROR.parent.mkdir(parents=True, exist_ok=True)
    with ERROR.open('a', encoding='utf-8') as handle:
        handle.write(f'[{now_text()}] {where}: {type(exc).__name__}: {exc}\n')
        handle.write(traceback.format_exc() + '\n')


def day_key(ts: float) -> str:
    return time.strftime('%Y-%m-%d', time.localtime(ts))


def raw_path(date_text: str) -> Path:
    return LEDGER_DIR / f'{date_text}.jsonl'


def file_signature(path: Path) -> int:
    try:
        stat = path.stat()
        return stat.st_mtime_ns ^ stat.st_size
    except OSError:
        return 0


def acquire_lock() -> None:
    global _LOCK_FH
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    handle = LOCK_PATH.open('a+', encoding='utf-8')
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit(0)
    handle.seek(0)
    handle.truncate()
    handle.write(json.dumps({'pid': os.getpid(), 'version': VERSION, 'build': BUILD_LABEL, 'ts': now_ts()}))
    handle.flush()
    _LOCK_FH = handle
    atexit.register(lambda: handle.close() if not handle.closed else None)


def _candidate_rows(snapshot: Any) -> List[Dict[str, Any]]:
    if not isinstance(snapshot, dict):
        return []
    rows = snapshot.get('rows')
    return [dict(row) for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []


def _rise_input(row: Dict[str, Any]) -> Dict[str, Any]:
    value = row.get('rise_prediction_input')
    if isinstance(value, dict):
        return value
    contract = row.get('trade_path_contract_v2149') if isinstance(row.get('trade_path_contract_v2149'), dict) else {}
    prediction = contract.get('prediction') if isinstance(contract.get('prediction'), dict) else {}
    value = prediction.get('rise_prediction_input')
    return value if isinstance(value, dict) else {}



def _clip_probability(value: float) -> float:
    return max(1.0, min(99.0, float(value)))


def _quantile(values: List[float], fraction: float) -> Optional[float]:
    clean=sorted(float(value) for value in values if num(value) is not None)
    if not clean:
        return None
    if len(clean)==1:
        return clean[0]
    pos=(len(clean)-1)*max(0.0,min(1.0,float(fraction)))
    lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi:
        return clean[lo]
    return clean[lo]+(clean[hi]-clean[lo])*(pos-lo)


def _model_material_value(value: Any) -> Tuple[str, Any]:
    numeric=num(value)
    if numeric is not None:
        return 'numeric', float(numeric)
    if isinstance(value,dict):
        risk=str(value.get('risk_state') or 'UNKNOWN')
        context=str(value.get('context_state') or 'UNKNOWN')
        concentration=num(value.get('turnover_concentration_top10_pct'))
        concentration_band='UNKNOWN' if concentration is None else ('HIGH' if concentration>=65 else 'MID' if concentration>=40 else 'LOW')
        return 'categorical', f'RISK_{risk}|CONTEXT_{context}|CONCENTRATION_{concentration_band}'
    if value is None:
        return 'missing', None
    return 'categorical', str(value)


def _numeric_bucket(value: float, edges: List[float]) -> str:
    if len(edges)<3:
        return 'ALL'
    if value<=edges[0]: return 'Q1'
    if value<=edges[1]: return 'Q2'
    if value<=edges[2]: return 'Q3'
    return 'Q4'


def _posterior_probability(positive: float, total: float, base_probability: float, prior_strength: float=8.0) -> float:
    if total<=0:
        return _clip_probability(base_probability*100.0)
    return _clip_probability((positive+base_probability*prior_strength)/(total+prior_strength)*100.0)


def _target_observations(target_name: str, nowv: float) -> List[Tuple[Dict[str,Any], Dict[str,Any], bool]]:
    horizon='3h' if target_name in {'probability_3h','late_capture_risk'} else '6h'
    rows=[]
    for (event_key,row_horizon),outcome in _OUTCOME_ROWS.items():
        if row_horizon!=horizon or str(outcome.get('outcome_state') or '')!='READY':
            continue
        event=_EVENTS.get(str(event_key))
        if not isinstance(event,dict) or _event_contract_generation(event)!='INFORMATION_CONTRACT_COMPLETE':
            continue
        event_ts=num(event.get('event_ts'))
        if event_ts is None or event_ts<nowv-RAW_RETENTION_SEC:
            continue
        final_return=num(outcome.get('final_return_pct'))
        if target_name in {'probability_3h','probability_6h'}:
            if final_return is None or final_return==0:
                continue
            actual=final_return>0
        elif target_name=='giveback_risk':
            mfe=num(outcome.get('mfe_pct'))
            giveback=num(outcome.get('giveback_pct'))
            if mfe is None or giveback is None or mfe<=0:
                continue
            actual=(giveback/max(mfe,1e-9))>=0.50
        else:
            early=num(outcome.get('early_capture_ratio'))
            if early is not None:
                actual=early<0.50
            else:
                pre=num(outcome.get('pre_signal_rise_pct'))
                mfe=num(outcome.get('mfe_pct'))
                if pre is None or mfe is None:
                    continue
                actual=pre>max(0.0,mfe)
        rows.append((event,outcome,bool(actual)))
    return rows


def _build_target_model(target_name: str, nowv: float) -> Dict[str,Any]:
    observations=_target_observations(target_name,nowv)
    episode_counts=Counter(str(event.get('episode_id') or event.get('event_key')) for event,_,_ in observations)
    weighted=[]
    for event,outcome,actual in observations:
        episode=str(event.get('episode_id') or event.get('event_key'))
        weight=1.0/max(1,int(episode_counts.get(episode) or 1))
        weighted.append((event,outcome,actual,weight))
    total=sum(weight for *_,weight in weighted)
    positive=sum(weight for _,_,actual,weight in weighted if actual)
    base=(positive/total) if total>0 else 0.5
    features={}
    for name in MATERIAL_NAMES:
        numeric_rows=[]; categorical_rows=[]
        for event,_,actual,weight in weighted:
            values=event.get('material_values') if isinstance(event.get('material_values'),dict) else {}
            kind,value=_model_material_value(values.get(name))
            if kind=='numeric': numeric_rows.append((float(value),actual,weight))
            elif kind=='categorical': categorical_rows.append((str(value),actual,weight))
        if numeric_rows:
            edges=[_quantile([value for value,_,_ in numeric_rows],fraction) for fraction in (0.25,0.50,0.75)]
            clean_edges=[float(value) for value in edges if value is not None]
            buckets=defaultdict(lambda:{'total':0.0,'positive':0.0})
            for value,actual,weight in numeric_rows:
                bucket=_numeric_bucket(value,clean_edges)
                buckets[bucket]['total']+=weight; buckets[bucket]['positive']+=weight*int(actual)
            public={}
            for bucket,counts in buckets.items():
                public[bucket]={'effective_sample':round(counts['total'],6),'positive_effective':round(counts['positive'],6),'probability_pct':round(_posterior_probability(counts['positive'],counts['total'],base),4)}
            features[name]={'kind':'numeric','edges':[round(value,10) for value in clean_edges],'buckets':public,'raw_sample_count':len(numeric_rows)}
        elif categorical_rows:
            buckets=defaultdict(lambda:{'total':0.0,'positive':0.0})
            for value,actual,weight in categorical_rows:
                buckets[value]['total']+=weight; buckets[value]['positive']+=weight*int(actual)
            public={key:{'effective_sample':round(counts['total'],6),'positive_effective':round(counts['positive'],6),'probability_pct':round(_posterior_probability(counts['positive'],counts['total'],base),4)} for key,counts in buckets.items()}
            features[name]={'kind':'categorical','buckets':public,'raw_sample_count':len(categorical_rows)}
    def categorical_model(values_fn):
        buckets=defaultdict(lambda:{'total':0.0,'positive':0.0})
        for event,_,actual,weight in weighted:
            values=values_fn(event)
            for value in values:
                if not value: continue
                buckets[str(value)]['total']+=weight; buckets[str(value)]['positive']+=weight*int(actual)
        return {key:{'effective_sample':round(counts['total'],6),'positive_effective':round(counts['positive'],6),'probability_pct':round(_posterior_probability(counts['positive'],counts['total'],base),4)} for key,counts in buckets.items()}
    tag_model=categorical_model(lambda event:list(event.get('explanation_tags') or []))
    tag_combo_model=categorical_model(lambda event:['+'.join(sorted(str(tag) for tag in (event.get('explanation_tags') or []))) or 'NONE'])
    sequence_model=categorical_model(lambda event:[str((event.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN')])
    return {
        'schema':'rise_probability_target_model', 'target':target_name,
        'horizon':'3h' if target_name in {'probability_3h','late_capture_risk'} else '6h',
        'state':'LIVE' if total>0 else 'NO_SAMPLE',
        'raw_sample_count':len(observations),'effective_sample':round(total,6),
        'positive_effective':round(positive,6),'base_probability_pct':round(base*100.0,4),
        'feature_models':features,'tag_models':tag_model,'tag_combination_models':tag_combo_model,'sequence_models':sequence_model,
        'episode_weighting':'1 / event_count_in_same_episode','candidate_gate_active':False,
    }


def build_live_prediction_model(nowv: float) -> Dict[str,Any]:
    targets={name:_build_target_model(name,nowv) for name in ('probability_3h','probability_6h','giveback_risk','late_capture_risk')}
    identity={'schema':'rise_prediction_live_model_identity','retention_days':5,'targets':targets}
    model_id=hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:20]
    return {
        'schema':'rise_prediction_live_model','state':'LIVE' if any((target.get('effective_sample') or 0)>0 for target in targets.values()) else 'NO_SAMPLE',
        'owner':'review_worker','model_id':model_id,'generated_ts':nowv,'generated_text':now_text(nowv),
        'retention_days':5,'retention_contract':'최근 5일 상승예측 관찰자료만 사용; 대기기간 아님',
        'targets':targets,'prediction_calculation_active':True,'candidate_gate_active':False,
        'candidate_penalty_active':False,'thresholds_applied':False,'historical_trade_recalculated':False,'auto_buy':False,
    }


def _directional_score_summary(rows: Iterable[Dict[str,Any]]) -> Dict[str,Any]:
    counts=Counter(); resolved=Counter(); correct=Counter(); brier_sum=defaultdict(float)
    for row in rows:
        horizon=str(row.get('horizon') or 'unknown')
        group=str(row.get('directional_score_group') or '')
        if group:
            counts[f'{horizon}:{group}']+=1
        if row.get('prediction_correct') in {True,False}:
            resolved[horizon]+=1; correct[horizon]+=int(row.get('prediction_correct') is True)
        brier=num(row.get('brier_score'))
        if brier is not None:
            brier_sum[horizon]+=brier
    return {
        'four_way_counts':dict(counts),
        'accuracy_by_horizon':{h:{'resolved':int(resolved[h]),'correct':int(correct[h]),'accuracy_pct':round(correct[h]/resolved[h]*100.0,3) if resolved[h] else None} for h in sorted(resolved)},
        'brier_by_horizon':{h:round(brier_sum[h]/resolved[h],8) for h in sorted(resolved) if resolved[h]},
        'scoring_contract':'UP_UP / UP_DOWN / DOWN_DOWN / DOWN_UP; 30m·1h·3h use sealed 3h probability, 6h uses sealed 6h probability',
    }



def _event_record(row: Dict[str, Any], snapshot: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    payload = _rise_input(row)
    event_key = str(payload.get('event_key') or '')
    event_ts = num(payload.get('event_bar_close_ts'))
    symbol = ticker(payload.get('ticker') or row.get('ticker'))
    if not event_key or event_ts is None or not symbol:
        return None
    materials = payload.get('materials') if isinstance(payload.get('materials'), dict) else {}
    material_names = list(payload.get('material_names') or [])
    contract_state = 'MATERIAL_CONTRACT_MISMATCH' if tuple(material_names) != MATERIAL_NAMES else str(payload.get('state') or 'MISSING')
    structure = payload.get('structure_contract') if isinstance(payload.get('structure_contract'), dict) else {}
    baseline = payload.get('baseline_decision') if isinstance(payload.get('baseline_decision'), dict) else {}
    probability_3h=num(payload.get('probability_3h'))
    probability_6h=num(payload.get('probability_6h'))
    giveback_risk=num(payload.get('giveback_risk'))
    late_capture_risk=num(payload.get('late_capture_risk'))
    return {
        'schema': 'rise_prediction_ledger_record','record_type': 'event','contract_generation': 'INFORMATION_CONTRACT_COMPLETE','information_contract_complete': True,
        'event_key': event_key,'event_ts': event_ts,'event_text': now_text(event_ts),'ticker': symbol,'event_price': num(payload.get('event_price')),
        'episode_id': payload.get('episode_id'),'episode_low_ts': num(payload.get('episode_low_ts')),'episode_low_price': num(payload.get('episode_low_price')),
        'pre_signal_rise_pct': num(payload.get('pre_signal_rise_pct')),'signal_position': payload.get('signal_position') if isinstance(payload.get('signal_position'), dict) else {},
        'price_volume_sequence': payload.get('price_volume_sequence') if isinstance(payload.get('price_volume_sequence'), dict) else {'state':'UNKNOWN'},
        'explanation_tags': list(payload.get('explanation_tags') or []),'explanation_tag_labels_ko': list(payload.get('explanation_tag_labels_ko') or []),
        'explanation_tag_evidence': payload.get('explanation_tag_evidence') if isinstance(payload.get('explanation_tag_evidence'), dict) else {},
        'tag_overlap_allowed': True,'tag_used_as_gate': False,'input_state': contract_state,'input_coverage_pct': num(payload.get('input_coverage_pct')),
        'usable_input_count':int(payload.get('usable_input_count') or 0),'source_state_counts': payload.get('source_state_counts') if isinstance(payload.get('source_state_counts'), dict) else {},
        'materials': materials,'material_values': payload.get('material_values') if isinstance(payload.get('material_values'), dict) else {},'material_names': material_names,
        'probability_3h': probability_3h,'probability_6h': probability_6h,'giveback_risk': giveback_risk,'late_capture_risk': late_capture_risk,
        'predicted_direction_3h':payload.get('predicted_direction_3h') or ('UP' if probability_3h is not None and probability_3h>50.0 else 'DOWN' if probability_3h is not None and probability_3h<50.0 else 'NEUTRAL' if probability_3h is not None else None),
        'predicted_direction_6h':payload.get('predicted_direction_6h') or ('UP' if probability_6h is not None and probability_6h>50.0 else 'DOWN' if probability_6h is not None and probability_6h<50.0 else 'NEUTRAL' if probability_6h is not None else None),
        'output_states': payload.get('output_states') if isinstance(payload.get('output_states'), dict) else {},
        'model_state': str(payload.get('model_state') or 'NO_MODEL'),'prediction_model_id':payload.get('prediction_model_id'),
        'prediction_model_generated_ts':num(payload.get('prediction_model_generated_ts')),'prediction_confidence_pct':num(payload.get('prediction_confidence_pct')),
        'prediction_confidence_state':payload.get('prediction_confidence_state'),'prediction_evidence_count':int(payload.get('prediction_evidence_count') or 0),
        'probability_calculated':probability_3h is not None and probability_6h is not None,
        'weights_applied': False,'thresholds_applied': False,'prediction_used_as_gate': False,
        'structure_contract': structure,'baseline_decision': baseline,'baseline_decision_reasons': list(baseline.get('reasons') or []),
        'execution_cost_observation': payload.get('execution_cost_observation') if isinstance(payload.get('execution_cost_observation'), dict) else {},
        'baseline_decision_basis': 'DYNAMIC_STRUCTURE_ONLY_PREDICTION_RECORDED_NOT_GATED',
        'candidate_snapshot_id': snapshot.get('snapshot_id'),'candidate_commit_id': snapshot.get('candidate_commit_id'),'cycle_id': snapshot.get('cycle_id'),
        'owner': 'review_worker','review_recomputed_inputs': False,'zero_fill_used': False,'auto_buy': False,
    }


def _load_rollup_dates() -> None:
    for row in read_jsonl(ROLLUP_LEDGER):
        source_date = str(row.get('source_date') or '')
        record_type = str(row.get('record_type') or '')
        if source_date and record_type == 'daily_rollup':
            _ROLLED_DATES.add(source_date)
        if source_date and record_type == 'daily_rollup_final':
            _FINALIZED_DATES.add(source_date)


def load_state_once() -> None:
    global _STATE_LOADED, _COLLECTION_START_TS
    if _STATE_LOADED:
        return
    LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    _load_rollup_dates()
    cutoff = now_ts() - RAW_RETENTION_SEC - 24 * 3600.0
    for path in sorted(LEDGER_DIR.glob('20??-??-??.jsonl')):
        try:
            date_ts = time.mktime(time.strptime(path.stem, '%Y-%m-%d'))
        except Exception:
            continue
        if date_ts < cutoff:
            continue
        for row in read_jsonl(path):
            record_type = str(row.get('record_type') or '')
            key = str(row.get('event_key') or '')
            if record_type == 'event' and key:
                if _event_contract_generation(row) != 'INFORMATION_CONTRACT_COMPLETE':
                    _LEGACY_EVENT_KEYS.add(key)
                existing = _EVENTS.get(key)
                # The append-once ledger may contain both a preserved legacy row
                # and a later complete information-contract row for the same
                # ticker+completed-30m event key.  Keep both on disk, but the
                # active in-memory reader must prefer the complete row.
                if existing is None or (
                    _event_contract_generation(existing) != 'INFORMATION_CONTRACT_COMPLETE'
                    and _event_contract_generation(row) == 'INFORMATION_CONTRACT_COMPLETE'
                ):
                    _EVENTS[key] = row
                event_ts = num(row.get('event_ts'))
                if event_ts is not None:
                    _COLLECTION_START_TS = event_ts if _COLLECTION_START_TS is None else min(_COLLECTION_START_TS, event_ts)
            elif record_type == 'outcome' and key and row.get('horizon'):
                outcome_key = (key, str(row.get('horizon')))
                # Only a terminal READY/FAILED outcome closes the retry loop.
                if str(row.get('outcome_state') or '') in {'READY', 'FAILED_SOURCE_MISSING'}:
                    _OUTCOMES.add(outcome_key)
                    _OUTCOME_ROWS[outcome_key] = row
    _STATE_LOADED = True


def _cache_pairs(obj: Any) -> Iterable[Tuple[str, Dict[str, Any]]]:
    if isinstance(obj, dict):
        rows = obj.get('rows')
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict):
                    yield ticker(row.get('ticker') or row.get('symbol') or row.get('market')), row
            return
        if isinstance(rows, dict):
            for key, row in rows.items():
                if isinstance(row, dict):
                    yield ticker(key or row.get('ticker')), row
            return
        for key, row in obj.items():
            if isinstance(row, dict) and isinstance(row.get('structure_lab_candles'), dict):
                yield ticker(key or row.get('ticker')), row
    elif isinstance(obj, list):
        for row in obj:
            if isinstance(row, dict):
                yield ticker(row.get('ticker') or row.get('symbol') or row.get('market')), row


def _apply_delta(row: Dict[str, Any], ops: Any) -> Dict[str, Any]:
    import copy
    out = copy.deepcopy(row) if isinstance(row, dict) else {}
    for op in ops if isinstance(ops, list) else []:
        if not isinstance(op, dict):
            continue
        kind = str(op.get('op') or '')
        path = [str(item) for item in (op.get('path') or [])]
        if not path:
            continue
        current = out
        valid = True
        for key in path[:-1]:
            if not isinstance(current, dict):
                valid = False
                break
            next_value = current.get(key)
            if not isinstance(next_value, dict):
                if kind == 'remove':
                    valid = False
                    break
                next_value = {}
                current[key] = next_value
            current = next_value
        if not valid or not isinstance(current, dict):
            continue
        key = path[-1]
        if kind == 'remove':
            current.pop(key, None)
        elif kind == 'set':
            current[key] = copy.deepcopy(op.get('value'))
        elif kind == 'list_roll':
            existing = current.get(key) if isinstance(current.get(key), list) else []
            drop = max(0, int(num(op.get('drop_front'), 0.0) or 0))
            additions = op.get('append') if isinstance(op.get('append'), list) else []
            current[key] = copy.deepcopy(existing[drop:] + additions)
    return out


def _normalize_frame(rows: Any) -> List[Dict[str, float]]:
    out = []
    for item in rows if isinstance(rows, list) else []:
        if isinstance(item, dict):
            ts = num(item.get('ts')); op = num(item.get('o')); close = num(item.get('c')); high = num(item.get('h')); low = num(item.get('l')); volume = num(item.get('v'), 0.0)
        elif isinstance(item, (list, tuple)) and len(item) >= 6:
            ts, op, close, high, low, volume = (num(item[0]), num(item[1]), num(item[2]), num(item[3]), num(item[4]), num(item[5], 0.0))
        else:
            continue
        if None in (ts, op, close, high, low) or min(float(op), float(close), float(high), float(low)) <= 0:
            continue
        out.append({'ts': float(ts), 'o': float(op), 'c': float(close), 'h': float(high), 'l': float(low), 'v': max(0.0, float(volume or 0.0))})
    out.sort(key=lambda item: item['ts'])
    return out


def candle_index() -> Tuple[Dict[str, Dict[str, List[Dict[str, float]]]], int]:
    global _CANDLE_SIGNATURE, _CANDLE_INDEX, _CANDLE_COUNT
    signature = (file_signature(CANDLE_CACHE), file_signature(CANDLE_DELTA))
    if _CANDLE_SIGNATURE == signature and _CANDLE_INDEX:
        return _CANDLE_INDEX, _CANDLE_COUNT
    base_obj = load_json(CANDLE_CACHE, {}) or {}
    source: Dict[str, Dict[str, Any]] = {}
    checkpoint = str(base_obj.get('delta_checkpoint_id_v1016') or '') if isinstance(base_obj, dict) else ''
    for symbol, row in _cache_pairs(base_obj):
        if symbol:
            source[symbol] = dict(row)
    if CANDLE_DELTA.exists():
        try:
            with CANDLE_DELTA.open('r', encoding='utf-8', errors='ignore') as handle:
                for line in handle:
                    try:
                        item = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(item, dict):
                        continue
                    symbol = ticker(item.get('ticker'))
                    if not symbol:
                        continue
                    schema = str(item.get('schema') or '')
                    if schema == 'candle_delta_ops_v1016':
                        base_checkpoint = str(item.get('base_checkpoint_id_v1016') or '')
                        if checkpoint and base_checkpoint and checkpoint != base_checkpoint:
                            continue
                        source[symbol] = _apply_delta(source.get(symbol, {}), item.get('ops'))
                    elif schema == 'candle_delta_patch_v1015' and isinstance(item.get('row'), dict):
                        source[symbol] = dict(item.get('row'))
        except Exception as exc:
            append_error('candle_delta', exc)
    index: Dict[str, Dict[str, List[Dict[str, float]]]] = {}
    count = 0
    for symbol, row in source.items():
        lab = row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'), dict) else {}
        frames = lab.get('frames') if isinstance(lab.get('frames'), dict) else {}
        normalized = {}
        for tf in ('m1', 'm3', 'm5', 'm15', 'm30', 'h1'):
            values = _normalize_frame(frames.get(tf))
            if values:
                normalized[tf] = values
                count += len(values)
        if normalized:
            index[symbol] = normalized
    _CANDLE_SIGNATURE = signature
    _CANDLE_INDEX = index
    _CANDLE_COUNT = count
    return index, count


def _select_path(frames: Dict[str, List[Dict[str, float]]], start_ts: float, end_ts: float) -> Tuple[str, List[Dict[str, float]], str]:
    choices = (('m1', 60.0), ('m3', 180.0), ('m5', 300.0), ('m15', 900.0), ('m30', 1800.0))
    best_tf = ''
    best_rows: List[Dict[str, float]] = []
    best_reason = 'CANDLE_PATH_MISSING'
    for tf, sec in choices:
        rows = [row for row in frames.get(tf, []) if start_ts <= row['ts'] < end_ts]
        if not rows:
            continue
        last_end = rows[-1]['ts'] + sec
        if last_end + sec * 0.25 < end_ts:
            best_reason = f'{tf}_HORIZON_INCOMPLETE'
            continue
        return tf, rows, 'READY'
    return best_tf, best_rows, best_reason


def _exact_rows(obj: Any) -> Iterable[Dict[str, Any]]:
    if isinstance(obj, list):
        for row in obj:
            if isinstance(row, dict):
                yield row
        return
    if not isinstance(obj, dict):
        return
    for key in ('rows', 'positions', 'open', 'records'):
        value = obj.get(key)
        if isinstance(value, list):
            for row in value:
                if isinstance(row, dict):
                    yield row
            return
        if isinstance(value, dict):
            for row in value.values():
                if isinstance(row, dict):
                    yield row
            return
    for row in obj.values():
        if isinstance(row, dict) and (row.get('decision_key') or row.get('source_decision_key')):
            yield row


def _decision_key(row: Dict[str, Any]) -> str:
    return str(row.get('decision_key') or row.get('source_decision_key') or row.get('direct_decision_key_v2149') or '').strip()


def paper_exact_index() -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    open_obj = load_json(PAPER_EXACT_OPEN, {}) or {}
    for row in _exact_rows(open_obj):
        key = _decision_key(row)
        if key:
            index[key] = {'state': 'OPEN', 'row': row}
    for row in read_jsonl(PAPER_EXACT_CLOSED):
        key = _decision_key(row)
        if key:
            index[key] = {'state': 'CLOSED', 'row': row}
    return index


def _paper_execution_result(event: Dict[str, Any], paper_index: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    baseline = event.get('baseline_decision') if isinstance(event.get('baseline_decision'), dict) else {}
    key = str(baseline.get('decision_key') or '').strip()
    if not baseline.get('entry_eligible'):
        return {'state':'NOT_APPLICABLE_BASELINE_HOLD','decision_key':key or None,'actual_execution':False,'after_cost_return_pct':None}
    if not key:
        return {'state':'MISSING_DECISION_KEY','decision_key':None,'actual_execution':None,'after_cost_return_pct':None}
    link = paper_index.get(key)
    if not isinstance(link, dict):
        return {'state':'NOT_EXECUTED_OR_NOT_YET_LINKED','decision_key':key,'actual_execution':False,'after_cost_return_pct':None}
    row = link.get('row') if isinstance(link.get('row'), dict) else {}
    preview = row.get('paper_execution_preview_v2149_at_open') if isinstance(row.get('paper_execution_preview_v2149_at_open'), dict) else {}
    exit_contract = row.get('v2_exit_contract_v2149') if isinstance(row.get('v2_exit_contract_v2149'), dict) else {}
    cost = num(preview.get('roundtrip_cost_pct'))
    if cost is None:
        cost = num(exit_contract.get('roundtrip_cost_pct'))
    after_cost = num(row.get('net_after_configured_fee_pct_v983'))
    if after_cost is None:
        after_cost = num(row.get('pnl_pct'))
    if after_cost is None:
        after_cost = num(row.get('last_pnl_pct'))
    return {
        'state': f"READY_ACTUAL_{str(link.get('state') or 'UNKNOWN')}",
        'decision_key': key,
        'actual_execution': True,
        'paper_state': link.get('state'),
        'entry_price': num(row.get('entry_price')),
        'opened_ts': num(row.get('paper_v2_exact_opened_ts'), num(row.get('opened_at'))),
        'closed_ts': num(row.get('closed_ts')),
        'spread_pct': num(preview.get('spread_pct')),
        'slippage_pct': num(preview.get('slippage_pct')),
        'fee_pct': num(preview.get('fee_pct')),
        'roundtrip_cost_pct': cost,
        'after_cost_return_pct': after_cost,
        'cost_source': 'paper exact sealed OPEN/CLOSED contract',
        'current_value_substitution_used': False,
    }



def resolve_outcome(event: Dict[str, Any], horizon: str, horizon_sec: float, index: Dict[str, Dict[str, List[Dict[str, float]]]], nowv: float, paper_index: Optional[Dict[str, Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    event_key=str(event.get('event_key') or ''); event_ts=num(event.get('event_ts')); event_price=num(event.get('event_price')); symbol=ticker(event.get('ticker'))
    if not event_key or event_ts is None or event_price is None or event_price<=0 or not symbol: return None
    if nowv<event_ts+horizon_sec: return None
    frames=index.get(symbol) or {}; frame_name,path,state=_select_path(frames,event_ts,event_ts+horizon_sec)
    prediction_field='probability_6h' if horizon=='6h' else 'probability_3h'
    prediction_probability=num(event.get(prediction_field))
    sealed_direction_field='predicted_direction_6h' if horizon=='6h' else 'predicted_direction_3h'
    predicted_direction=str(event.get(sealed_direction_field) or '').upper() or ('UP' if prediction_probability is not None and prediction_probability>50.0 else 'DOWN' if prediction_probability is not None and prediction_probability<50.0 else 'NEUTRAL' if prediction_probability is not None else None)
    if not path:
        return {'schema':'rise_prediction_ledger_record','record_type':'outcome','event_key':event_key,'event_ts':event_ts,'ticker':symbol,'horizon':horizon,'horizon_sec':horizon_sec,
                'outcome_state':'MISSING','missing_reason':state,'source_frame':frame_name or None,'prediction_probability_pct':prediction_probability,
                'prediction_probability_field':prediction_field,'predicted_direction':predicted_direction,'baseline_passed':bool((event.get('baseline_decision') or {}).get('entry_eligible')),
                'target_first':False,'invalid_first':False,'actual_rise_success':None,'completed_ts':nowv,'completed_text':now_text(nowv),'owner':'review_worker','zero_fill_used':False,'auto_buy':False}
    structure=event.get('structure_contract') if isinstance(event.get('structure_contract'),dict) else {}; target=num(structure.get('target_t1')); invalid=num(structure.get('execution_invalid'))
    first_target=None; first_invalid=None; ambiguous_ts=None; max_price=event_price; min_price=event_price; max_ts=event_ts; min_ts=event_ts
    for bar in path:
        high=float(bar['h']); low=float(bar['l'])
        if high>max_price: max_price=high; max_ts=float(bar['ts'])
        if low<min_price: min_price=low; min_ts=float(bar['ts'])
        hit_target=target is not None and high>=target; hit_invalid=invalid is not None and low<=invalid
        if hit_target and first_target is None: first_target=float(bar['ts'])
        if hit_invalid and first_invalid is None: first_invalid=float(bar['ts'])
        if hit_target and hit_invalid and ambiguous_ts is None: ambiguous_ts=float(bar['ts'])
    if first_target is not None and first_invalid is not None:
        touch_order='AMBIGUOUS_SAME_BAR' if first_target==first_invalid else 'TARGET_FIRST' if first_target<first_invalid else 'INVALID_FIRST'
    elif first_target is not None: touch_order='TARGET_FIRST'
    elif first_invalid is not None: touch_order='INVALID_FIRST'
    else: touch_order='NO_TOUCH'
    final_price=float(path[-1]['c']); final_return=(final_price/event_price-1.0)*100.0; mfe=(max_price/event_price-1.0)*100.0; mae=(min_price/event_price-1.0)*100.0; giveback=mfe-final_return
    pre_rise=num(event.get('pre_signal_rise_pct')); early_capture=None
    if pre_rise is not None and pre_rise>=0 and mfe>0 and pre_rise+mfe>0: early_capture=mfe/(pre_rise+mfe)
    passed=bool((event.get('baseline_decision') or {}).get('entry_eligible')); paper_result=_paper_execution_result(event,paper_index or {})
    success=True if touch_order=='TARGET_FIRST' else False if touch_order=='INVALID_FIRST' else None
    result_group='PASS_RISE' if passed and success is True else 'PASS_FAIL' if passed and success is False else 'HOLD_MISSED_RISE' if not passed and success is True else 'HOLD_CORRECT' if not passed and success is False else 'UNRESOLVED'
    actual_direction='UP' if final_return>0 else 'DOWN' if final_return<0 else 'FLAT'
    directional_group=None; prediction_correct=None; brier=None
    if predicted_direction and actual_direction in {'UP','DOWN'}:
        directional_group=f'{predicted_direction}_{actual_direction}'; prediction_correct=predicted_direction==actual_direction
        brier=(prediction_probability/100.0-(1.0 if actual_direction=='UP' else 0.0))**2 if prediction_probability is not None else None
    after_cost=num(paper_result.get('after_cost_return_pct')); after_cost_direction='UP' if after_cost is not None and after_cost>0 else 'DOWN' if after_cost is not None and after_cost<0 else 'FLAT' if after_cost==0 else None
    actual_giveback=bool(mfe>0 and giveback/max(mfe,1e-9)>=0.50)
    actual_late=bool(early_capture is not None and early_capture<0.50)
    return {
        'schema':'rise_prediction_ledger_record','record_type':'outcome','event_key':event_key,'event_ts':event_ts,'ticker':symbol,'episode_id':event.get('episode_id'),
        'horizon':horizon,'horizon_sec':horizon_sec,'outcome_state':'READY','touch_order':touch_order,'target_first':touch_order=='TARGET_FIRST','invalid_first':touch_order=='INVALID_FIRST',
        'actual_rise_success':success,'baseline_passed':passed,'baseline_decision_basis':'DYNAMIC_STRUCTURE_ONLY_PREDICTION_RECORDED_NOT_GATED','result_group':result_group,
        'prediction_model_id':event.get('prediction_model_id'),'prediction_probability_field':prediction_field,'prediction_probability_pct':prediction_probability,
        'predicted_direction':predicted_direction,'actual_direction':actual_direction,'directional_score_group':directional_group,'prediction_correct':prediction_correct,
        'brier_score':round(brier,10) if brier is not None else None,'score_available_immediately_at_horizon':True,
        'event_price':event_price,'final_price':final_price,'final_return_pct':round(final_return,8),'mfe_pct':round(mfe,8),'mae_pct':round(mae,8),
        'mfe_ts':max_ts,'mae_ts':min_ts,'mfe_delay_sec':round(max(0.0,max_ts-event_ts),3),'giveback_pct':round(giveback,8),
        'actual_giveback_risk':actual_giveback,'actual_late_capture_risk':actual_late,'post_signal_additional_rise_pct':round(mfe,8),
        'early_capture_ratio':round(early_capture,8) if early_capture is not None else None,'episode_event_index':event.get('episode_event_index'),'is_first_episode_event':event.get('is_first_episode_event'),
        'explanation_tags':list(event.get('explanation_tags') or []),'price_volume_sequence_state':(event.get('price_volume_sequence') or {}).get('state') if isinstance(event.get('price_volume_sequence'),dict) else 'UNKNOWN',
        'paper_execution_result':paper_result,'cost_result_state':paper_result.get('state'),'after_cost_return_pct':after_cost,'after_cost_actual_direction':after_cost_direction,
        'pre_signal_rise_pct':pre_rise,'first_target_ts':first_target,'first_invalid_ts':first_invalid,'ambiguous_same_bar_ts':ambiguous_ts,'source_frame':frame_name,
        'source_completed_candles_only':True,'completed_ts':nowv,'completed_text':now_text(nowv),'owner':'review_worker','review_recomputed_inputs':False,'zero_fill_used':False,'auto_buy':False,
    }


def append_new_events(snapshot: Dict[str, Any]) -> Tuple[int, int]:
    global _COLLECTION_START_TS
    created = 0
    duplicates = 0
    for row in _candidate_rows(snapshot):
        record = _event_record(row, snapshot)
        if not record:
            continue
        key = str(record['event_key'])
        existing = _EVENTS.get(key)
        if existing is not None and _event_contract_generation(existing) == 'INFORMATION_CONTRACT_COMPLETE':
            duplicates += 1
            continue
        # A legacy event with the same external event_key is not the same
        # contract row.  Preserve the legacy JSONL row, append the current
        # information-contract row once, and make the current row active.
        episode = str(record.get('episode_id') or key)
        prior_episode_events = [
            event for existing_key, event in _EVENTS.items()
            if existing_key != key and str(event.get('episode_id') or event.get('event_key')) == episode
        ]
        record['episode_event_index'] = len(prior_episode_events) + 1
        record['is_first_episode_event'] = not prior_episode_events
        record['episode_first_event_key'] = str(prior_episode_events[0].get('event_key')) if prior_episode_events else key
        append_jsonl(raw_path(day_key(float(record['event_ts']))), record)
        _EVENTS[key] = record
        _COLLECTION_START_TS = float(record['event_ts']) if _COLLECTION_START_TS is None else min(_COLLECTION_START_TS, float(record['event_ts']))
        created += 1
    return created, duplicates


def append_due_outcomes(nowv: float, index: Dict[str, Dict[str, List[Dict[str, float]]]], paper_index: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, int]:
    counts = Counter()
    for key, event in list(_EVENTS.items()):
        event_ts = num(event.get('event_ts'))
        if event_ts is None or nowv - event_ts > RAW_RETENTION_SEC + 24 * 3600.0:
            continue
        for horizon, sec in HORIZONS:
            outcome_key = (key, horizon)
            if outcome_key in _OUTCOMES or nowv < event_ts + sec:
                continue
            record = resolve_outcome(event, horizon, sec, index, nowv, paper_index or {})
            if record is None:
                continue
            state = str(record.get('outcome_state') or 'MISSING')
            if state != 'READY':
                # Candle outcome data can arrive late. Do not seal MISSING and do not
                # zero-fill; retry through the existing Candle cache on later cycles.
                counts[f'{horizon}:PENDING_{state}'] += 1
                continue
            append_jsonl(raw_path(day_key(event_ts)), record)
            _OUTCOMES.add(outcome_key)
            _OUTCOME_ROWS[outcome_key] = record
            counts[f'{horizon}:READY'] += 1
    return dict(counts)


def _weighted_average(rows: List[Tuple[float, float]]) -> Optional[float]:
    denominator = sum(weight for _, weight in rows)
    return sum(value * weight for value, weight in rows) / denominator if denominator > 0 else None


def _rate_rows(counter: Dict[str, Counter]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for key, values in counter.items():
        total = int(values.get('total') or 0)
        success = int(values.get('success') or 0)
        out[key] = {'total': total, 'success': success, 'target_first_rate_pct': round(success / total * 100.0, 3) if total else None}
    return out


def _material_bucket(value: Any) -> str:
    numeric = num(value)
    if numeric is not None:
        if numeric > 0: return 'POSITIVE'
        if numeric < 0: return 'NEGATIVE'
        return 'ZERO'
    if isinstance(value, dict):
        risk = str(value.get('risk_state') or 'UNKNOWN')
        context = str(value.get('context_state') or 'UNKNOWN')
        return f'RISK_{risk}|CONTEXT_{context}'
    return 'MISSING'


def build_rollup(date_text: str, records: List[Dict[str, Any]], *, final: bool = False) -> Dict[str, Any]:
    events = {str(row.get('event_key')): row for row in records if row.get('record_type') == 'event' and row.get('event_key')}
    outcomes = [row for row in records if row.get('record_type') == 'outcome']
    episode_counts = Counter(str(row.get('episode_id') or row.get('event_key')) for row in events.values())
    outcome_counts = Counter()
    input_states = Counter(str(row.get('input_state') or 'MISSING') for row in events.values())
    material_states = Counter()
    material_source_states = Counter()
    material_missing_reasons = Counter()
    tag_counts = Counter()
    sequence_counts = Counter()
    first_repeat_counts = Counter()
    cost_states = Counter()
    metrics: Dict[str, Dict[str, List[Tuple[float, float]]]] = defaultdict(lambda: defaultdict(list))
    material_groups: Dict[str, Dict[str, List[Tuple[float, float]]]] = defaultdict(lambda: defaultdict(list))
    tag_results: Dict[str, Counter] = defaultdict(Counter)
    sequence_results: Dict[str, Counter] = defaultdict(Counter)
    material_bucket_results: Dict[str, Counter] = defaultdict(Counter)
    cost_metrics: Dict[str, List[Tuple[float, float]]] = defaultdict(list)
    for event in events.values():
        for tag in event.get('explanation_tags') or []:
            tag_counts[str(tag)] += 1
        sequence = event.get('price_volume_sequence') if isinstance(event.get('price_volume_sequence'), dict) else {}
        sequence_counts[str(sequence.get('state') or 'UNKNOWN')] += 1
        first_repeat_counts['FIRST' if event.get('is_first_episode_event') else 'REPEAT'] += 1
        for name, item in (event.get('materials') or {}).items():
            if not isinstance(item, dict): continue
            material_states[f"{name}:{str(item.get('state') or 'MISSING')}"] += 1
            material_source_states[f"{name}:{str(item.get('source_state') or 'MISSING')}"] += 1
            if item.get('missing_reason'):
                material_missing_reasons[f"{name}:{str(item.get('missing_reason'))}"] += 1
    for row in outcomes:
        key = str(row.get('event_key') or '')
        event = events.get(key, {})
        episode = str(event.get('episode_id') or key)
        weight = 1.0 / max(1, episode_counts.get(episode, 1))
        horizon = str(row.get('horizon') or 'unknown')
        group = str(row.get('result_group') or row.get('outcome_state') or 'unknown')
        outcome_counts[f'{horizon}:{group}'] += 1
        success = row.get('actual_rise_success') is True
        resolved = row.get('actual_rise_success') in {True, False}
        for metric in ('final_return_pct', 'mfe_pct', 'mae_pct', 'giveback_pct', 'early_capture_ratio', 'post_signal_additional_rise_pct'):
            value = num(row.get(metric))
            if value is not None:
                metrics[horizon][metric].append((value, weight))
        values = event.get('material_values') if isinstance(event.get('material_values'), dict) else {}
        for name in MATERIAL_NAMES:
            value = values.get(name)
            numeric = num(value)
            if numeric is not None:
                material_groups[f'{horizon}:{group}'][name].append((numeric, weight))
            if resolved:
                bucket_key = f"{horizon}:{name}:{_material_bucket(value)}"
                material_bucket_results[bucket_key]['total'] += 1
                material_bucket_results[bucket_key]['success'] += int(success)
        if resolved:
            for tag in event.get('explanation_tags') or []:
                tag_key = f'{horizon}:{tag}'
                tag_results[tag_key]['total'] += 1
                tag_results[tag_key]['success'] += int(success)
            sequence = event.get('price_volume_sequence') if isinstance(event.get('price_volume_sequence'), dict) else {}
            sequence_key = f"{horizon}:{str(sequence.get('state') or 'UNKNOWN')}"
            sequence_results[sequence_key]['total'] += 1
            sequence_results[sequence_key]['success'] += int(success)
        cost_state = str(row.get('cost_result_state') or 'MISSING')
        cost_states[f'{horizon}:{cost_state}'] += 1
        after_cost = num(row.get('after_cost_return_pct'))
        if after_cost is not None:
            cost_metrics[horizon].append((after_cost, weight))
    public_metrics = {
        horizon: {name: round(value, 8) if value is not None else None for name, items in group.items() if (value := _weighted_average(items)) is not None}
        for horizon, group in metrics.items()
    }
    public_materials = {
        group: {name: round(value, 8) if value is not None else None for name, items in values.items() if (value := _weighted_average(items)) is not None}
        for group, values in material_groups.items()
    }
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'daily_rollup_final' if final else 'daily_rollup',
        'rollup_state': 'FINAL' if final else 'DAILY_02KST_SNAPSHOT',
        'source_date': date_text,
        'generated_ts': now_ts(),
        'generated_text': now_text(),
        'event_count': len(events),
        'unique_episode_count': len(episode_counts),
        'outcome_count': len(outcomes),
        'input_state_counts': dict(input_states),
        'material_state_counts': dict(material_states),
        'material_source_state_counts': dict(material_source_states),
        'material_missing_reason_counts': dict(material_missing_reasons),
        'explanation_tag_counts': dict(tag_counts),
        'price_volume_sequence_counts': dict(sequence_counts),
        'first_repeat_event_counts': dict(first_repeat_counts),
        'outcome_counts': dict(outcome_counts),
        'episode_weighted_metrics': public_metrics,
        'episode_weighted_material_means': public_materials,
        'material_bucket_target_first_rates': _rate_rows(material_bucket_results),
        'tag_target_first_rates': _rate_rows(tag_results),
        'sequence_target_first_rates': _rate_rows(sequence_results),
        'cost_result_state_counts': dict(cost_states),
        'episode_weighted_after_cost_return_pct': {h: round(v, 8) for h, items in cost_metrics.items() if (v := _weighted_average(items)) is not None},
        'directional_scoring': _directional_score_summary(outcomes),
        'probability_calibration_state': 'LIVE' if any(row.get('prediction_probability_pct') is not None for row in outcomes) else 'WAIT_NEW_PREDICTIONS',
        'material_names': list(MATERIAL_NAMES),
        'weights_applied_to_prediction': False,
        'thresholds_applied_to_prediction': False,
        'prediction_used_as_gate': False,
        'raw_retention_days': 5,
        'raw_retention_is_waiting_period': False,
        'owner': 'review_worker',
        'auto_buy': False,
    }


def append_due_daily_rollup(nowv: float) -> Dict[str, Any]:
    local = time.localtime(nowv)
    if local.tm_hour < 2:
        return {'state':'WAIT_02KST','created':0}
    previous_day_ts = nowv - 24 * 3600.0
    date_text = day_key(previous_day_ts)
    path = raw_path(date_text)
    if date_text in _ROLLED_DATES:
        return {'state':'ALREADY_DONE','source_date':date_text,'created':0}
    if not path.exists():
        return {'state':'SOURCE_NOT_READY','source_date':date_text,'created':0}
    append_jsonl(ROLLUP_LEDGER, build_rollup(date_text, list(read_jsonl(path)), final=False))
    _ROLLED_DATES.add(date_text)
    return {'state':'DONE','source_date':date_text,'created':1}

def _terminal_missing_outcome(event: Dict[str, Any], horizon: str, horizon_sec: float, nowv: float) -> Dict[str, Any]:
    baseline = event.get('baseline_decision') if isinstance(event.get('baseline_decision'), dict) else {}
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'outcome',
        'event_key': event.get('event_key'),
        'event_ts': event.get('event_ts'),
        'ticker': event.get('ticker'),
        'episode_id': event.get('episode_id'),
        'horizon': horizon,
        'horizon_sec': horizon_sec,
        'outcome_state': 'FAILED_SOURCE_MISSING',
        'missing_reason': 'CANDLE_PATH_NOT_COMPLETED_BEFORE_RAW_RETENTION',
        'baseline_passed': bool(baseline.get('entry_eligible')),
        'baseline_decision_basis': 'DYNAMIC_STRUCTURE_ONLY_OBSERVATION_NOT_NEW_PREDICTION',
        'target_first': False,
        'invalid_first': False,
        'actual_rise_success': None,
        'result_group': 'SOURCE_MISSING',
        'completed_ts': nowv,
        'completed_text': now_text(nowv),
        'owner': 'review_worker',
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'auto_buy': False,
    }


def rotate_ledgers(nowv: float) -> Dict[str, int]:
    rolled = deleted = terminal_missing = 0
    for path in sorted(LEDGER_DIR.glob('20??-??-??.jsonl')):
        try:
            date_start = time.mktime(time.strptime(path.stem, '%Y-%m-%d'))
        except Exception:
            continue
        # Delete only after the entire local date is older than 120 hours.
        if nowv - (date_start + 24 * 3600.0) <= RAW_RETENTION_SEC:
            continue
        date_text = path.stem
        records = list(read_jsonl(path))
        events = {str(row.get('event_key')): row for row in records if row.get('record_type') == 'event' and row.get('event_key')}
        terminal_keys = {
            (str(row.get('event_key')), str(row.get('horizon')))
            for row in records
            if row.get('record_type') == 'outcome' and str(row.get('outcome_state') or '') in {'READY', 'FAILED_SOURCE_MISSING'}
        }
        # A missing source remains retryable for the full raw-retention window.
        # Only at final rotation is it sealed as a source failure for the rollup.
        for key, event in events.items():
            for horizon, sec in HORIZONS:
                if (key, horizon) in terminal_keys:
                    continue
                record = _terminal_missing_outcome(event, horizon, sec, nowv)
                records.append(record)
                terminal_keys.add((key, horizon))
                terminal_missing += 1
        if date_text not in _FINALIZED_DATES:
            append_jsonl(ROLLUP_LEDGER, build_rollup(date_text, records, final=True))
            _FINALIZED_DATES.add(date_text)
            rolled += 1
        path.unlink(missing_ok=True)
        deleted += 1
        for key, event in list(_EVENTS.items()):
            event_ts = num(event.get('event_ts'))
            if event_ts is not None and day_key(event_ts) == date_text:
                _EVENTS.pop(key, None)
                _LEGACY_EVENT_KEYS.discard(key)
                for horizon, _ in HORIZONS:
                    outcome_key = (key, horizon)
                    _OUTCOMES.discard(outcome_key)
                    _OUTCOME_ROWS.pop(outcome_key, None)
    # Rollups are derived summaries; rewrite only this one derived file for retention.
    if ROLLUP_LEDGER.exists():
        keep = []
        cutoff = nowv - ROLLUP_RETENTION_SEC
        for row in read_jsonl(ROLLUP_LEDGER):
            generated = num(row.get('generated_ts'), nowv)
            if generated is not None and generated >= cutoff:
                keep.append(row)
        tmp = ROLLUP_LEDGER.with_name(f'.{ROLLUP_LEDGER.name}.{os.getpid()}.{time.time_ns()}.tmp')
        with tmp.open('w', encoding='utf-8') as handle:
            for row in keep:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
            handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp, ROLLUP_LEDGER)
    return {'rolled': rolled, 'raw_files_deleted': deleted, 'terminal_source_missing': terminal_missing}


def cleanup_old_rise_derived(allow: bool) -> List[str]:
    # Information-contract completion must be runtime-proven before any old
    # rise-prediction derived artifact is removed. Core trade ledgers are never touched.
    return []


def run_daily_maintenance(nowv: float) -> Dict[str, Any]:
    global _LAST_MAINTENANCE_DAY
    local_day = day_key(nowv)
    if time.localtime(nowv).tm_hour < 2:
        return {'state':'WAIT_02KST','daily_rollup':{'state':'WAIT_02KST','created':0},'rotation':{'rolled':0,'raw_files_deleted':0,'terminal_source_missing':0}}
    if _LAST_MAINTENANCE_DAY == local_day:
        return {'state':'ALREADY_DONE_TODAY','daily_rollup':{'state':'ALREADY_DONE_TODAY','created':0},'rotation':{'rolled':0,'raw_files_deleted':0,'terminal_source_missing':0}}
    daily = append_due_daily_rollup(nowv)
    rotation = rotate_ledgers(nowv)
    _LAST_MAINTENANCE_DAY = local_day
    return {'state':'DONE','daily_rollup':daily,'rotation':rotation}


def seed_change_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_single_ledger.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-CLEAN-BASELINE',
        'issue_id': 'OLD-RISE-PREDICTION-LATE-AND-WRONG',
        'version': 'v2364',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'The active rise prediction mixed old weighted layers and often recognized already-risen or re-rising coins late. Its results were split across multiple shadow and outcome views.',
        'fix': 'Remove the old rise-prediction active gate; collect only the agreed 13 materials; write one event/outcome ledger with episode dedupe, missed-rise tracking and five-day raw rotation.',
        'not_touched': ['dynamic trigger/invalid/target', 'Paper execution cost checks', 'OPEN/CLOSED/trade/decision exact ledgers', 'exit contract', 'Guard upgrade flow', 'auto-buy OFF'],
        'remaining': 'Server runtime proof of live probabilities, immediate four-way scoring, and five-day observation rotation. Candidate gate remains OFF.',
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'OLD-RISE-PREDICTION-LATE-AND-WRONG',
        'status': 'CHECK',
        'title': '기존 상승예측 폐기·최근 5일 관찰자료 순환',
        'detail': '최근 5일 관찰자료를 유지하면서 상승확률과 정오를 즉시 계산한다. 5일은 대기기간이 아니라 관찰자료 보존기간이며 Gate와 자동감점은 OFF다.',
        'version': 'v2364',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')



def seed_information_contract_change_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_information_contract_v2373.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-INFORMATION-CONTRACT-COMPLETE',
        'issue_id': 'RISE-PREDICTION-MISSING-MATERIAL-CONTEXT',
        'version': 'v2373',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'The clean 13-material baseline existed, but source freshness, missing reasons, price-volume order, overlapping phase tags, signal position, exact cost linkage and daily comparison fields were incomplete.',
        'fix': 'Complete the existing Strategy-to-Review canonical information contract without changing candidate, structure, entry, exit, weight, threshold or gate behavior.',
        'not_touched': ['candidate ranking', 'dynamic trigger/invalid/target/RR', 'Paper entry/exit and cost contract', 'OPEN/CLOSED/trade/decision/exact ledgers', 'auto-buy OFF'],
        'remaining': 'Server runtime proof of the complete information contract and live prediction scoring; five days is retention only.',
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'RISE-PREDICTION-MISSING-MATERIAL-CONTEXT',
        'status': 'CHECK',
        'title': '상승예측 재료·태그·결과 정보계약 완성',
        'detail': '13개 재료의 실제 상태와 누락 이유, 시간 순서, 중복 태그, 초입 위치, Paper exact 비용 결과와 02시 일별 비교를 canonical 장부에 연결한다.',
        'version': 'v2373',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')


def _event_contract_generation(event: Dict[str, Any]) -> str:
    explicit = str(event.get('contract_generation') or '').strip().upper()
    if explicit:
        return explicit
    required = ('signal_position', 'price_volume_sequence', 'explanation_tag_evidence', 'execution_cost_observation')
    if all(key in event for key in required):
        return 'INFORMATION_CONTRACT_COMPLETE'
    return 'LEGACY_PRE_CONTRACT'


def _current_snapshot_event_keys(snapshot: Dict[str, Any]) -> List[str]:
    keys = []
    for row in _candidate_rows(snapshot):
        payload = _rise_input(row)
        key = str(payload.get('event_key') or '').strip()
        if key:
            keys.append(key)
    return sorted(set(keys))


def _event_set_hash(keys: Iterable[str]) -> Optional[str]:
    values = sorted(set(str(key) for key in keys if str(key)))
    return hashlib.sha256('\n'.join(values).encode('utf-8')).hexdigest() if values else None


def _nested_material_state_counts(events: Iterable[Dict[str, Any]]) -> Dict[str, Dict[str, int]]:
    nested: Dict[str, Counter] = {name: Counter() for name in MATERIAL_NAMES}
    for event in events:
        for name in MATERIAL_NAMES:
            item = (event.get('materials') or {}).get(name) if isinstance(event.get('materials'), dict) else None
            if not isinstance(item, dict):
                nested[name]['MISSING'] += 1
                continue
            state = str(item.get('state') or item.get('value_state') or 'MISSING').upper()
            nested[name][state] += 1
    return {name: dict(values) for name, values in nested.items()}


def _nested_material_missing_reasons(events: Iterable[Dict[str, Any]]) -> Dict[str, Dict[str, int]]:
    nested: Dict[str, Counter] = {name: Counter() for name in MATERIAL_NAMES}
    for event in events:
        materials = event.get('materials') if isinstance(event.get('materials'), dict) else {}
        for name in MATERIAL_NAMES:
            item = materials.get(name) if isinstance(materials.get(name), dict) else {}
            reason = str(item.get('missing_reason') or '').strip()
            if reason:
                nested[name][reason] += 1
    return {name: dict(values) for name, values in nested.items() if values}


def run_once() -> Dict[str, Any]:
    started = time.monotonic()
    nowv = now_ts()
    load_state_once()
    snapshot = load_json(SNAPSHOT, {}) or {}
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    created, duplicates = append_new_events(snapshot)
    # Publish only the completed Review cycle. The original Guard does not need
    # a partial rise-contract status, and Main must never read a half-built
    # canonical as if material/outcome counts were zero.
    index, candle_count = candle_index()
    paper_index = paper_exact_index()
    outcome_counts = append_due_outcomes(nowv, index, paper_index)
    maintenance = run_daily_maintenance(nowv)
    rotation = maintenance.get('rotation') if isinstance(maintenance.get('rotation'), dict) else {'rolled':0,'raw_files_deleted':0,'terminal_source_missing':0}
    removed = cleanup_old_rise_derived(False)
    live_model = build_live_prediction_model(nowv)
    directional_scoring = _directional_score_summary(_OUTCOME_ROWS.values())
    raw_files = sorted(LEDGER_DIR.glob('20??-??-??.jsonl'))
    outcome_total = Counter(horizon for _, horizon in _OUTCOMES)
    result_groups = Counter()
    touch_orders = Counter()
    outcome_states = Counter()
    for record in _OUTCOME_ROWS.values():
        horizon = str(record.get('horizon') or 'unknown')
        outcome_states[f"{horizon}:{str(record.get('outcome_state') or 'MISSING')}"] += 1
        if record.get('result_group'):
            result_groups[f"{horizon}:{str(record.get('result_group'))}"] += 1
        if record.get('touch_order'):
            touch_orders[f"{horizon}:{str(record.get('touch_order'))}"] += 1
    input_states = Counter(str(event.get('input_state') or 'MISSING') for event in _EVENTS.values())
    tag_counts = Counter(tag for event in _EVENTS.values() for tag in (event.get('explanation_tags') or []))
    sequence_counts = Counter(str((event.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN') for event in _EVENTS.values())
    material_source_states = Counter()
    material_value_states = Counter()
    material_missing_reasons = Counter()
    for event in _EVENTS.values():
        for name, item in (event.get('materials') or {}).items():
            if not isinstance(item, dict): continue
            material_source_states[f"{name}:{str(item.get('source_state') or 'MISSING')}"] += 1
            material_value_states[f"{name}:{str(item.get('value_state') or 'MISSING')}"] += 1
            if item.get('missing_reason'):
                material_missing_reasons[f"{name}:{str(item.get('missing_reason'))}"] += 1
    cost_states = Counter(f"{str(row.get('horizon') or 'unknown')}:{str(row.get('cost_result_state') or 'MISSING')}" for row in _OUTCOME_ROWS.values())
    current_snapshot_keys = _current_snapshot_event_keys(snapshot)
    current_snapshot_key_set = set(current_snapshot_keys)
    current_snapshot_events = [event for key, event in _EVENTS.items() if key in current_snapshot_key_set]
    current_contract_events = [event for event in _EVENTS.values() if _event_contract_generation(event) == 'INFORMATION_CONTRACT_COMPLETE']
    legacy_events = [event for event in _EVENTS.values() if _event_contract_generation(event) != 'INFORMATION_CONTRACT_COMPLETE']
    current_snapshot_contract_events = [event for event in current_snapshot_events if _event_contract_generation(event) == 'INFORMATION_CONTRACT_COMPLETE']
    # Review may only prove events that it actually consumed from the append-once
    # ledger. Hashing the Strategy snapshot keys directly would create a false
    # PASS even when current completed-bar events were still absent or legacy.
    consumed_contract_keys = sorted({
        str(event.get('event_key') or '')
        for event in current_snapshot_contract_events
        if str(event.get('event_key') or '')
    })
    current_snapshot_contract_pass = bool(
        current_snapshot_keys
        and len(consumed_contract_keys) == len(current_snapshot_keys)
        and set(consumed_contract_keys) == current_snapshot_key_set
    )
    current_tag_counts = Counter(tag for event in current_contract_events for tag in (event.get('explanation_tags') or []))
    current_sequence_counts = Counter(str((event.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN') for event in current_contract_events)
    current_material_missing_reasons = Counter()
    for event in current_contract_events:
        for name, item in (event.get('materials') or {}).items():
            if isinstance(item, dict) and item.get('missing_reason'):
                current_material_missing_reasons[f"{name}:{str(item.get('missing_reason'))}"] += 1
    actual_cost_outcome_links = sum(1 for row in _OUTCOME_ROWS.values() if str(row.get('cost_result_state') or '').startswith('READY_ACTUAL_'))
    actual_cost_event_keys = {
        str(row.get('event_key') or '')
        for row in _OUTCOME_ROWS.values()
        if str(row.get('cost_result_state') or '').startswith('READY_ACTUAL_') and str(row.get('event_key') or '')
    }
    actual_cost_event_links = len(actual_cost_event_keys)
    pending = Counter()
    for key, event in _EVENTS.items():
        event_ts = num(event.get('event_ts'))
        if event_ts is None:
            continue
        for horizon, sec in HORIZONS:
            if (key, horizon) not in _OUTCOMES:
                pending[horizon] += 1
    elapsed = max(0.0, time.monotonic() - started)
    canonical = {
        'schema': 'rise_prediction_canonical_status',
        'state': 'ACTIVE' if _EVENTS else 'WAITING',
        'owner': 'review_worker',
        'ledger_root': str(LEDGER_DIR),
        'collection_start_ts': _COLLECTION_START_TS,
        'collection_start_text': now_text(_COLLECTION_START_TS) if _COLLECTION_START_TS else None,
        'event_count_in_retention': len(current_contract_events) + len(_LEGACY_EVENT_KEYS),
        'new_events': created,
        'duplicate_events_prevented': duplicates,
        'unique_episode_count': len({str(event.get('episode_id') or event.get('event_key')) for event in _EVENTS.values()}),
        'input_state_counts': dict(input_states),
        'material_source_state_counts': dict(material_source_states),
        'material_value_state_counts': dict(material_value_states),
        'material_missing_reason_counts': dict(material_missing_reasons),
        'explanation_tag_counts': dict(tag_counts),
        'price_volume_sequence_counts': dict(sequence_counts),
        'current_contract_explanation_tag_counts': dict(current_tag_counts),
        'current_contract_price_volume_sequence_counts': dict(current_sequence_counts),
        'current_contract_material_missing_reason_counts': dict(current_material_missing_reasons),
        'contract_generation_counts': {
            'INFORMATION_CONTRACT_COMPLETE': len(current_contract_events),
            'LEGACY_PRE_CONTRACT': len(_LEGACY_EVENT_KEYS),
        },
        'current_snapshot_event_set_hash': _event_set_hash(current_snapshot_keys),
        'review_consumed_event_set_hash': _event_set_hash(consumed_contract_keys),
        'review_consumed_event_set_count': len(consumed_contract_keys),
        'current_snapshot_expected_event_count': len(current_snapshot_keys),
        'current_snapshot_contract_complete_count': len(current_snapshot_contract_events),
        'current_snapshot_legacy_event_count': max(0, len(current_snapshot_events) - len(current_snapshot_contract_events)),
        'current_snapshot_contract_state': 'PASS' if current_snapshot_contract_pass else ('CURRENT_CONTRACT_INCOMPLETE' if current_snapshot_keys else 'WAITING'),
        'current_contract_material_state_by_name': _nested_material_state_counts(current_contract_events),
        'current_contract_missing_reasons_by_name': _nested_material_missing_reasons(current_contract_events),
        'cost_result_state_counts': dict(cost_states),
        'paper_exact_available_count': len(paper_index),
        'paper_exact_actual_event_link_count': actual_cost_event_links,
        'paper_exact_actual_outcome_link_count': actual_cost_outcome_links,
        'paper_exact_actual_link_count': actual_cost_event_links,
        'paper_exact_link_count': actual_cost_event_links,
        'outcome_counts': dict(outcome_total),
        'outcome_state_counts': dict(outcome_states),
        'result_group_counts': dict(result_groups),
        'touch_order_counts': dict(touch_orders),
        'new_outcome_counts': outcome_counts,
        'pending_outcome_counts': dict(pending),
        'raw_file_count': len(raw_files),
        'raw_retention_days': 5,
        'rollup_retention_days': 90,
        'rollup_count': len(_ROLLED_DATES),
        'maintenance_02kst': maintenance,
        'rotation': rotation,
        'old_rise_derived_removed': removed,
        'old_rise_derived_cleanup_state': 'PENDING_RUNTIME_PROOF_NO_DELETE',
        'material_names': list(MATERIAL_NAMES),
        'material_count': len(MATERIAL_NAMES),
        'event_key_contract': 'ticker + completed_30m_bar_close_ts',
        'episode_id_contract': 'ticker + latest_confirmed_m30_swing_low_ts',
        'information_contract_complete': True,
        'live_prediction_model': live_model,
        'live_prediction_model_id': live_model.get('model_id'),
        'probability_outputs_state': live_model.get('state'),
        'directional_scoring': directional_scoring,
        'weights_applied': False,
        'probability_model_applied': True,
        'thresholds_applied': False,
        'prediction_used_as_gate': False,
        'new_shadow_created': False,
        'new_worker_created': False,
        'new_service_created': False,
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'missing_outcome_retries_active': True,
        'historical_trade_ledgers_deleted': False,
        'auto_buy': False,
    }
    status = {
        'schema': 'clean_review_worker_status',
        'version': VERSION,
        'build': BUILD_LABEL,
        'state': 'running',
        'pid': os.getpid(),
        'active_owner': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'last_completed_ts': nowv,
        'cycle_complete': True,
        'cycle_complete_v2294': True,
        'analysis_ready': True,
        'analysis_ready_v2246': True,
        'cycle_elapsed_sec': round(elapsed, 3),
        'candidate_snapshot_id': snapshot.get('snapshot_id'),
        'candidate_commit_id': snapshot.get('candidate_commit_id'),
        'candidate_row_count': len(_candidate_rows(snapshot)),
        'candidate_event_set_hash': _event_set_hash(current_snapshot_keys),
        'candidate_event_set_count': len(current_snapshot_keys),
        'candle_ticker_count': len(index),
        'candle_row_count': candle_count,
        'rise_prediction_canonical': canonical,
        'review_status': {
            'schema': 'review_status',
            'owner': 'review',
            'version': VERSION,
            'build': BUILD_LABEL,
            'state': canonical['state'],
            'new_shadow_created': False,
            'historical_ledgers_rewritten': False,
            'historical_trade_ledgers_deleted': False,
            'auto_buy': False,
        },
        'writer_count': 1,
        'historical_ledgers_rewritten': False,
        'historical_trade_ledgers_deleted': False,
        'new_shadow_created': False,
        'auto_buy': False,
    }
    atomic_json(STATUS, status)
    return status



def seed_contract_split_truth_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_contract_split_event_set_v2375.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-CONTRACT-SPLIT-EVENT-SET-TRUTH',
        'issue_id': 'RISE-PREDICTION-LEGACY-CURRENT-AGGREGATE-MIX',
        'version': 'v2375',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'Main and Review mixed legacy pre-contract events with the completed information contract, used exact cycle IDs instead of the completed-bar event set, and displayed available Paper exact rows as if they were actual outcome links.',
        'fix': 'Preserve all old rows, classify generations without rewriting, prove only Review-consumed current event keys, separate available versus actually linked Paper exact results, and publish current-contract-only tag/sequence/material aggregates.',
        'not_touched': ['13-material calculations', 'candidate ranking and count', 'trigger/invalid/target/RR', 'entry/exit/cost contracts', 'OPEN/CLOSED/trade/decision/exact ledgers', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'RISE-PREDICTION-LEGACY-CURRENT-AGGREGATE-MIX',
        'status': 'CHECK',
        'title': '상승예측 구사건·새 정보계약 혼합 표시',
        'detail': '과거 사건은 보존하고 새 완료봉 사건만 정보계약 집계와 event-set 증명에 사용. 서버 Runtime PASS 대기.',
        'version': 'v2375',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')



def seed_link_count_truth_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_actual_link_count_v2376.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-ACTUAL-EVENT-OUTCOME-LINK-COUNT',
        'issue_id': 'RISE-PREDICTION-ACTUAL-LINK-COUNT-HORIZON-DUPLICATION',
        'version': 'v2376',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'Actual Paper links were counted per horizon outcome row but displayed as linked events, so one event could be counted up to four times.',
        'fix': 'Keep the outcome-row count and add one unique event-key count. Main displays available exact rows, unique linked events, and linked outcome rows separately.',
        'not_touched': ['Paper exact rows', 'outcome calculation', '13-material inputs', 'candidate/entry/exit rules', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'RISE-PREDICTION-ACTUAL-LINK-COUNT-HORIZON-DUPLICATION',
        'status': 'CHECK',
        'title': 'Paper 실제 연결 수가 horizon 결과행 수와 혼합 표시됨',
        'detail': '고유 사건 연결 수와 결과행 연결 수를 분리해 표시. 서버 Runtime 검증 대기.',
        'version': 'v2376',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')

def seed_review_first_contract_proof_once() -> None:
    marker = BASE_DIR / 'runtime' / 'review_first_contract_proof_v2378.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'REVIEW-FIRST-CONTRACT-PROOF-BEFORE-HEAVY-CYCLE',
        'issue_id': 'REVIEW-BOOTING-ONLY-RUNTIME-PROOF',
        'version': 'v2378',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'Review wrote only BOOTING until candle and outcome work finished, so the unchanged Guard could not see the already-consumed rise contract during deployment.',
        'fix': 'After append-once current events are consumed, publish the existing six canonical contract facts immediately, then continue the same candle and outcome cycle.',
        'not_touched': ['Guard code and service', '13-material formulas', 'candidate/entry/exit rules', 'historical rows', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'REVIEW-BOOTING-ONLY-RUNTIME-PROOF',
        'status': 'CHECK',
        'title': 'Review 첫 계약 증명 전 무거운 cycle로 배포 CHECK',
        'detail': '기존 Guard는 유지하고 Review가 append-once 사건 소비 직후 기존 계약 상태를 먼저 기록한다.',
        'version': 'v2378',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')


def seed_legacy_event_collision_fix_once() -> None:
    marker = BASE_DIR / 'runtime' / 'review_legacy_event_key_collision_fix_v2382.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'REVIEW-LEGACY-CURRENT-EVENT-KEY-COLLISION-FIX',
        'issue_id': 'REVIEW-CURRENT-CONTRACT-DROPPED-AS-LEGACY-DUPLICATE',
        'version': 'v2382',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'A preserved legacy row and the current information-contract row shared the same ticker+completed-30m event key. The active dictionary kept the legacy row and discarded the current row as a duplicate.',
        'fix': 'Preserve both append-only ledger rows, append the current contract when only a legacy row exists, and prefer the current contract row in the active reader and after restart.',
        'not_touched': ['Guard', 'Main', 'Paper', 'Strategy', 'Candle', 'candidate/entry/exit rules', 'historical row contents', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'REVIEW-CURRENT-CONTRACT-DROPPED-AS-LEGACY-DUPLICATE',
        'status': 'CHECK',
        'title': 'Review 새 정보계약이 구사건 중복으로 누락됨',
        'detail': '같은 event_key의 구사건은 보존하고 새 정보계약 행을 append한 뒤 현재 Reader가 새 행을 우선 사용한다. 서버 Runtime PASS 대기.',
        'version': 'v2382',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')



def seed_review_complete_cycle_truth_once() -> None:
    marker = BASE_DIR / 'runtime' / 'review_complete_cycle_status_truth.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'REVIEW-COMPLETE-CYCLE-STATUS-TRUTH',
        'issue_id': 'REVIEW-PARTIAL-CONTRACT-STATUS-HID-FULL-AGGREGATES',
        'version': 'v2383',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'The retired deployment workaround overwrote Review status with a partial contract proof before material, outcome and Paper-exact aggregation completed. Main therefore displayed truthful 466/466 keys together with missing aggregate fields as zero or dash.',
        'fix': 'Keep the legacy/current event collision repair, remove the partial status write, publish only the completed canonical cycle, and make Main compare the exact Strategy snapshot hash consumed by Review instead of the moving latest Strategy snapshot.',
        'not_touched': ['Guard', 'Paper', 'Strategy', 'Candle', 'candidate/entry/exit rules', 'historical ledger rows', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'REVIEW-PARTIAL-CONTRACT-STATUS-HID-FULL-AGGREGATES',
        'status': 'CHECK',
        'title': 'Review 부분 계약 상태가 완료 집계를 0으로 보이게 함',
        'detail': '부분 상태 writer를 제거하고 완료 cycle만 공개한다. 구사건 충돌 복구와 append-only 원장은 유지하며 서버 Runtime PASS를 확인한다.',
        'version': 'v2383',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')


def seed_live_probability_change_once() -> None:
    marker=BASE_DIR/'runtime'/'rise_prediction_live_probability_scoring.seeded'
    if marker.exists(): return
    ts=now_ts()
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'RISE-PREDICTION-LIVE-PROBABILITY-AND-SCORING','issue_id':'RISE-PREDICTION-WAS-OBSERVATION-ONLY','version':'v2385','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,
        'cause':'The active information contract recorded 13 materials but forced all probability outputs to None and misread five-day retention as a five-day waiting period. API success and completed-bar freshness were also conflated.',
        'fix':'Use the most recent five-day information-contract outcomes to publish live 3h/6h rise, giveback and late-capture probabilities; seal predictions at event time; score UP_UP, UP_DOWN, DOWN_DOWN and DOWN_UP as each horizon completes. Five days is retention only.',
        'not_touched':['candidate gate/penalty','dynamic trigger/invalid/target/RR','Paper exit contract','historical OPEN/CLOSED/trade/decision/exact ledgers','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event','event_type':'ISSUE','issue_id':'RISE-PREDICTION-WAS-OBSERVATION-ONLY','status':'CHECK','title':'상승예측 확률 미실행·5일 보존기간 오해','detail':'최근 5일 자료로 즉시 확률을 계산하고 네 방향 정오를 시간축 완료 즉시 채점한다. Gate와 자동감점은 OFF다.','version':'v2385','created_ts':ts,'created_at':now_text(ts),'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(now_text(ts),encoding='utf-8')


def main() -> None:
    acquire_lock()
    seed_change_once()
    seed_information_contract_change_once()
    seed_contract_split_truth_once()
    seed_link_count_truth_once()
    seed_legacy_event_collision_fix_once()
    seed_review_complete_cycle_truth_once()
    seed_live_probability_change_once()
    boot = now_ts()
    atomic_json(STATUS, {
        'schema': 'clean_review_worker_status', 'version': VERSION, 'build': BUILD_LABEL,
        'state': 'booting', 'pid': os.getpid(), 'active_owner': VERSION,
        'updated_ts': boot, 'updated_text': now_text(boot), 'writer_count': 1,
        'new_shadow_created': False, 'auto_buy': False,
    })
    while True:
        try:
            run_once()
        except Exception as exc:
            append_error('run_once', exc)
            atomic_json(STATUS, {
                'schema': 'clean_review_worker_status', 'version': VERSION, 'build': BUILD_LABEL,
                'state': 'ERROR', 'pid': os.getpid(), 'active_owner': VERSION,
                'updated_ts': now_ts(), 'updated_text': now_text(),
                'error': f'{type(exc).__name__}: {exc}', 'writer_count': 1,
                'new_shadow_created': False, 'auto_buy': False,
            })
        time.sleep(INTERVAL_SEC)


if __name__ == '__main__':
    main()
