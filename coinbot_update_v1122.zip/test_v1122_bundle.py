#!/usr/bin/env python3
from __future__ import annotations
import ast, importlib.util, json, os, subprocess, sys, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent
RESULT={}

def load(name,path,env=None):
    if env:
        os.environ.update(env)
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

# 1) compile
files=[ROOT/'review_worker_v1.000.py',ROOT/'paper_bot_v1.020.py',ROOT/'backga_guard_bot_v2_5_170.py']
for f in files:
    subprocess.run([sys.executable,'-m','py_compile',str(f)],check=True)
RESULT['py_compile']=True

# 2) no duplicate critical top-level functions
critical={
    'review_worker_v1.000.py':{'main','_acquire_review_singleton_v1122','_release_review_singleton_v1122','update_quality_shadow'},
    'paper_bot_v1.020.py':{'paper_final_safety','_v1099_compact_funnel_row','_v1099_record_funnel_block','_v1122_structured_reason_codes'},
    'backga_guard_bot_v2_5_170.py':{'find_worker_pids','_worker_family_match_v1122','_restart_review_atomic_v1122','apply_worker_latest'},
}
for fname,names in critical.items():
    tree=ast.parse((ROOT/fname).read_text())
    counts={n:0 for n in names}
    for node in tree.body:
        if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in counts:
            counts[node.name]+=1
    assert all(v==1 for v in counts.values()),(fname,counts)
RESULT['critical_single_definition']=True

# 2b) Candidate quality, selector, cycle and exit logic match the sealed v1121 AST digests.
def fn_hashes(path):
    tree=ast.parse(Path(path).read_text())
    import hashlib
    return {n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
expected_review={
 '_quality_policy_variants_v1120':'b224d0bb7e65894cf7529e050348d79a32c0f95a3eee3489c81bf3fa7989d70f',
 '_quality_policy_group_stats_v1120':'057955339db908ff12e98cabc12c48a5efbfd1bd5d4c338477555cb4e6ab7b34',
 'update_quality_shadow':'0db204e3d1a4508f9bbe78d12adf19ee61b8e21b71868ade339567fe8f29ea53',
}
expected_paper={
 'select_candidates__L22385':'fec0e9002b3ccb3bd15c6bab4a313de8d7eb9cbd9adb6aadb7eca7af5aef2db5',
 'select_candidates__L23042':'7b02000bef973e3b6833251703e16719540ca1cb6a394ce8d47ad807ffea5e78',
 'run_cycle__v1121_no_heavy_probe':'e7e8fe9b2007120a4c49382c5e50931556ad42b364bdc732ca7de1fa22aa4b6a',
 'run_exact_exit_monitor__v1121_no_heavy_probe':'9910eab8a34bd15bdcd64a213eb5f9706e316780dbafe4e3fc2f2845d3ca4826',
}
r_new=fn_hashes(ROOT/'review_worker_v1.000.py'); p_new=fn_hashes(ROOT/'paper_bot_v1.020.py')
for name,digest in expected_review.items(): assert r_new[name]==digest,name
for name,digest in expected_paper.items(): assert p_new[name]==digest,name
RESULT['trading_and_quality_ast_unchanged']=True

# 3) Paper final-safety decision text remains the sealed expected contract; code is now source-sealed.
new=load('paper_new',ROOT/'paper_bot_v1.020.py')

def configure(mod,reaction='0.100 0.200 0.300 0.400 0.500 0.600'):
    mod.copy_entry_context=lambda ev:{}
    mod.build_entry_diagnostics=lambda ev,ctx:{}
    mod.build_open_alert_freshness_snapshot=lambda ev,diag:{'overall':'fresh_ok'}
    mod._v988_is_s3_observation_only=lambda ev:False
    mod.read_strategy_entry_gate=lambda ev:{}
    mod.read_strategy_decision_key=lambda ev,gate:''
    mod.evaluate_frozen_trigger=lambda ev,diag:{'trigger_reached':False,'reason':'봉인 방아쇠 미도달','entry_price':0.0,'trigger_gap_pct':0.0}
    mod.micro_fresh=lambda ev,ctrl:False
    mod.ws_fresh=lambda ev:False
    mod._v925_confirmed_slippage=lambda ev:(None,None)
    mod._paper_v144_reaction_proof_block=lambda diag,ctrl:reaction
    mod._v628_append_hourly_event=lambda *a,**k:None
    mod.log_error=lambda *a,**k:None

configure(new)
ev={'strategy_mode':'ALT_SWING_V977'}; ctrl={'paper_final_reaction_proof_enabled':True}
new_ok,new_reasons,new_diag=new.paper_final_safety(dict(ev),dict(ctrl))
expected_reasons=['ALT_SWING 진입판 누락','봉인 방아쇠 미도달','실제 진입가 RR 계산불가','실제 진입가 목표공간 계산불가','OPEN 직전 호가·체결 자료 오래됨','OPEN 직전 스프레드 자료 없음','OPEN 직전 확정 미끄러짐 자료 없음','0.100 0.200 0.300 0.400 0.500 0.600']
assert new_ok is False and new_reasons==expected_reasons
codes=new_diag.get('paper_final_safety_reason_codes_v1122') or []
assert 'REACTION_UNSAFE' in codes
assert not ({'UNMAPPED_SAFETY_REASON','INFORMATION_UNAVAILABLE','SAFETY_REASON_CONTRACT_MISSING'} & set(codes))
stats={}
new._v1099_record_funnel_block(stats,ev,'paper_final_safety',new_reasons,new_diag)
counts=stats.get('paper_entry_hold_reason_counts_v1099') or {}
assert counts.get('REACTION_UNSAFE')==1 and counts.get('UNMAPPED_SAFETY_REASON',0)==0
RESULT['paper_decision_text_unchanged']=True
RESULT['paper_structured_reason_contract']=True

# 4) Review persistent epoch survives a clean restart and never deletes old state.
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    os.environ['TRADING_BOT_DIR']=str(td)
    rev=load('review_new',ROOT/'review_worker_v1.000.py')
    rev.REVIEW_SINGLETON_LOCK_V1122=td/'runtime'/'review_worker_singleton_v1121.lock'
    rev.REVIEW_SINGLETON_STATUS_V1122=td/'clean_review_singleton_status_v1122.json'
    rev.QUALITY_POLICY_EPOCH_STATUS_V1122=td/'clean_quality_policy_epoch_v1122.json'
    rev._review_process_family_v1122=lambda include_helpers=False:[os.getpid()]
    rev._acquire_review_singleton_v1122()
    first=(rev._QUALITY_POLICY_EPOCH_ID_V1121,rev._QUALITY_POLICY_EPOCH_START_V1121)
    rev._release_review_singleton_v1122()
    rev._acquire_review_singleton_v1122()
    second=(rev._QUALITY_POLICY_EPOCH_ID_V1121,rev._QUALITY_POLICY_EPOCH_START_V1121)
    rev._release_review_singleton_v1122()
    assert first==second and first[0]
    payload=json.loads(rev.QUALITY_POLICY_EPOCH_STATUS_V1122.read_text())
    assert payload['persistent_across_clean_restarts_v1122'] is True
    assert payload['old_rows_deleted'] is False and payload['old_ledgers_rewritten'] is False
RESULT['review_persistent_clean_epoch']=True

# 4b) Kernel lock contention blocks a second v1122 owner.
with tempfile.TemporaryDirectory() as td:
    td=Path(td); os.environ['TRADING_BOT_DIR']=str(td)
    a=load('review_lock_a',ROOT/'review_worker_v1.000.py')
    b=load('review_lock_b',ROOT/'review_worker_v1.000.py')
    for mod in (a,b):
        mod.REVIEW_SINGLETON_LOCK_V1122=td/'runtime'/'review_worker_singleton_v1121.lock'
        mod.REVIEW_SINGLETON_STATUS_V1122=td/f'clean_review_singleton_status_{mod.__name__}.json'
        mod.QUALITY_POLICY_EPOCH_STATUS_V1122=td/f'clean_quality_policy_epoch_{mod.__name__}.json'
        mod._review_process_family_v1122=lambda include_helpers=False:[os.getpid()]
    a._acquire_review_singleton_v1122()
    try:
        try:
            b._acquire_review_singleton_v1122()
            raise AssertionError('second lock owner was not blocked')
        except SystemExit as exc:
            assert exc.code==73
    finally:
        a._release_review_singleton_v1122()
RESULT['review_kernel_lock_contention']=True

# 5) Review fails closed when an old sibling exists before any SQLite prepare.
with tempfile.TemporaryDirectory() as td:
    td=Path(td)
    os.environ['TRADING_BOT_DIR']=str(td)
    rev2=load('review_sibling',ROOT/'review_worker_v1.000.py')
    rev2.REVIEW_SINGLETON_LOCK_V1122=td/'runtime'/'review_worker_singleton_v1121.lock'
    rev2.REVIEW_SINGLETON_STATUS_V1122=td/'clean_review_singleton_status_v1122.json'
    rev2.QUALITY_POLICY_EPOCH_STATUS_V1122=td/'clean_quality_policy_epoch_v1122.json'
    rev2._review_process_family_v1122=lambda include_helpers=False:[os.getpid(),999999]
    try:
        rev2._acquire_review_singleton_v1122()
        raise AssertionError('sibling was not blocked')
    except SystemExit as exc:
        assert exc.code==74
    payload=json.loads(rev2.REVIEW_SINGLETON_STATUS_V1122.read_text())
    assert payload['state']=='BLOCKED_OLD_REVIEW_RUNTIME'
RESULT['review_old_sibling_fail_closed']=True

# 6) Guard matcher includes old versioned Review filenames and excludes helpers from exact-one.
os.environ['GUARD_BOT_TOKEN']='test'; os.environ['GUARD_CHAT_ID']='1'; os.environ['BOT_DIR']=str(ROOT)
guard=load('guard_new',ROOT/'backga_guard_bot_v2_5_170.py',{'GUARD_BOT_TOKEN':'test','GUARD_CHAT_ID':'1','BOT_DIR':str(ROOT)})
guard.pid_alive=lambda pid:True
cmds={
  101:'/usr/bin/python3 /srv/review_worker_v0.998.py',
  102:'/usr/bin/python3 /srv/review_worker_v1.000.py --build-dedup-index-v1013 /tmp/x',
  103:'/usr/bin/python3 /srv/review_worker.py',
}
guard._proc_cmdline_v1111=lambda pid:cmds.get(pid,'')
assert guard._worker_family_match_v1122('review',101,False)
assert not guard._worker_family_match_v1122('review',102,False)
assert guard._worker_family_match_v1122('review',102,True)
assert guard._worker_family_match_v1122('review',103,False)
RESULT['guard_old_version_family_match']=True
RESULT['guard_review_helper_exclusion']=True

# 6b) Atomic Review restart includes old family PIDs, TERM/KILL, zero proof, then one start.
state={'pids':[201,202],'signals':[],'runs':[],'clock':0.0}
def fake_time():
    state['clock']+=10.0
    return state['clock']
def fake_find(name,include_helpers=False):
    return list(state['pids'])
def fake_kill(pid,sig):
    state['signals'].append((pid,sig))
    if sig==guard.signal.SIGKILL and pid in state['pids']:
        state['pids'].remove(pid)
def fake_run(args,timeout=None,**kwargs):
    state['runs'].append(tuple(args))
    return 0,''
guard.find_worker_pids=fake_find
guard.os.kill=fake_kill
guard.run=fake_run
guard.time.time=fake_time
guard.time.sleep=lambda *_:None
guard._wait_worker_fresh_boot_v1111=lambda *a,**k:(True,['fresh'],{'ok':True,'main_pid':303,'pids':[303]})
ok,notes,evidence=guard._restart_review_atomic_v1122('review_worker_v1.000',timeout=1)
assert ok and not state['pids']
assert any(sig==guard.signal.SIGTERM for _pid,sig in state['signals'])
assert any(sig==guard.signal.SIGKILL for _pid,sig in state['signals'])
assert ('systemctl','stop','tradingbot-review-worker') in state['runs']
assert ('systemctl','start','tradingbot-review-worker') in state['runs']
RESULT['guard_review_atomic_restart_simulated']=True

# 7) Static deployment transaction proof.
gtxt=(ROOT/'backga_guard_bot_v2_5_170.py').read_text()
for needle in [
    "run(['systemctl','stop',service]",
    "find_worker_pids(name,include_helpers=True)",
    "os.kill(pid,signal.SIGKILL)",
    "zero Review family PID proven before start",
    "run(['systemctl','start',service]",
    "lock_path = BOT_DIR / 'clean_review_singleton_status_v1122.json'",
]:
    assert needle in gtxt,needle
RESULT['review_atomic_stop_drain_kill_start_static']=True

print(json.dumps(RESULT,ensure_ascii=False,sort_keys=True))
