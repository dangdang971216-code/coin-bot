# v1122 scope and verification

## Proven root causes

### Review SQLite multi-writer
The deployment/runtime matcher only recognized `review_worker.py` and the newest versioned target. An older direct process such as `review_worker_v0.998.py` was outside that matcher, survived a restart, and retained an open descriptor to `review_append_dedup_v1013.sqlite3`.

The runtime proof also required `lockPID=MainPID` only for Strategy, not Review. Therefore a Review deployment could be reported ready without proving the Review process lock.

### Paper unmapped safety reason
`paper_final_safety` knew the exact blocking branch but returned only free-text messages. The funnel later guessed reason codes from those strings. Numeric-heavy or formatting-heavy messages could be classified as `UNMAPPED_SAFETY_REASON`.

## Changes

1. Review deployment transaction
   - Match the complete stable `review_worker*.py` family, including old versioned filenames.
   - Exclude intentional short-lived helper modes from long-lived exact-one runtime counting.
   - During Review apply: systemd stop -> drain -> TERM/KILL every remaining Review-family PID -> prove zero -> start once.
   - Require `MainPID = statusPID = lockPID = the only long-lived Review PID` before deployment PASS.

2. Review runtime fail-closed
   - Reuse the same kernel lock path as v1121.
   - Before opening SQLite, scan for old Review-family siblings that do not know the lock.
   - If a sibling exists, exit before dedup/quality writers start.
   - If a sibling appears later, close SQLite and exit instead of continuing to write.

3. Persistent clean quality epoch
   - Start a new v1122 epoch only after exact-one Review proof.
   - Preserve previous rows/ledgers without rewrite or deletion.
   - Reuse the v1122 epoch across ordinary clean restarts so samples are not discarded on every restart.

4. Paper structured safety reasons
   - `paper_final_safety` now seals `code + message + source` at the branch that creates the block.
   - Funnel accounting consumes the sealed code instead of reverse-parsing free text.
   - User-facing reason text and the allow/block decision are unchanged.

## Explicitly unchanged
- Current candidate quality thresholds and formula
- Three-way quality shadow formula
- Rank formula and selector ordering
- trigger / invalid / target
- actual-entry RR / room / chase / spread / slippage / cost thresholds
- OPEN 30 / cycle 3
- exit contract
- OPEN/CLOSED/decision/performance ledgers
- auto-buy OFF

## Local proof
- py_compile PASS for Review, Paper, Guard.
- Critical active functions have one top-level definition.
- Old and new Paper final-safety return identical allow/block result and identical reason text under the same inputs.
- Final-safety funnel uses source-sealed codes and produces no unmapped code in the reproduced case.
- Candidate quality formula, quality group statistics, quality state update, Paper selectors, Paper cycle, and exact exit monitor AST are unchanged.
- Review kernel lock rejects a second owner.
- Review refuses an old-version sibling before SQLite initialization.
- Persistent v1122 quality epoch is reused after a clean restart.
- Guard matches old versioned Review filenames and excludes helper modes from long-lived runtime counts.
- Guard atomic Review stop/drain/kill/start transaction passes simulation.

## Server DONE proof
- Review version `review_worker_v1.000`.
- Review runtime has exactly one long-lived PID.
- `MainPID = statusPID = lockPID` and Review lock/status are fresh after deployment.
- `MULTI_WRITER` for `review_append_dedup_v1013.sqlite3` is zero.
- New v1122 quality epoch is active and remains the same across a clean Review restart.
- `UNMAPPED_SAFETY_REASON` and `BLOCK_REASON_INFORMATION_MISSING` are zero after a completed Paper cycle.
- Paper funnel accounting remains exact; runtime mismatch and new execution errors are zero.
