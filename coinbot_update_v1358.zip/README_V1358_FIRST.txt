v1358 OLD_BASE_REBUILD_BOOT_COMPAT_FIX
- Fixes v1357 partial apply: strategy singleton proof for current Guard.
- Bumps old-base main/paper/strategy runtime labels.
- Paper stays alive and pauses new OPEN if startup reconcile is not proven.
- Auto-buy OFF. No live ledgers included.
