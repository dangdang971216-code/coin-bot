#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

VERSION="orderflow_worker_v0.9"
INTERVAL_SEC=float(os.getenv("ORDERFLOW_WORKER_INTERVAL_SEC","2.0"))
WS_TTL_SEC=float(os.getenv("ORDERFLOW_WS_TTL_SEC","45"))
MICRO_TTL_SEC=float(os.getenv("ORDERFLOW_MICRO_TTL_SEC","60"))
STATUS=BASE_DIR/"clean_orderflow_status.json"; OUT=BASE_DIR/"clean_orderflow_summary_cache.json"; ERROR=BASE_DIR/"clean_orderflow_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; WS=BASE_DIR/"clean_ws_live_cache.json"; MICRO=BASE_DIR/"clean_bithumb_micro_cache.json"; TARGET_QUEUE=BASE_DIR/"clean_target_router_queue.json"
MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"
MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"
STRATEGY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"
SUSTAIN_STATE=BASE_DIR/"clean_orderflow_buy_sustain_state.json"
SUSTAIN_WINDOW_SEC=float(os.getenv("ORDERFLOW_BUY_SUSTAIN_WINDOW_SEC","60"))
SUSTAIN_KEEP_SEC=float(os.getenv("ORDERFLOW_BUY_SUSTAIN_KEEP_SEC","75"))
SUSTAIN_READY_MIN_SPAN=float(os.getenv("ORDERFLOW_BUY_SUSTAIN_MIN_SPAN_SEC","45"))
SUSTAIN_READY_MIN_SAMPLES=int(float(os.getenv("ORDERFLOW_BUY_SUSTAIN_MIN_SAMPLES","8")))
def write_status(state:str, **extra:Any)->None: save_json(STATUS,{"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),**extra})
def row_age_sec(row:Dict[str,Any])->float:
    ts=fnum(row.get("updated_ts"), row.get("ts"), row.get("fresh_ts"), row.get("timestamp"), row.get("time"), default=0)
    return max(0.0, now_ts()-ts) if ts>0 else 999999.0

def is_fresh(row:Dict[str,Any], ttl:float)->bool:
    ts=fnum(row.get("updated_ts"), row.get("ts"), row.get("fresh_ts"), row.get("timestamp"), row.get("time"), default=0)
    return ts>0 and now_ts()-ts <= ttl


def _obj_updated_ts(obj: Any, fallback_path: Path) -> float:
    if isinstance(obj, dict):
        for k in ("updated_ts", "ts", "timestamp", "created_at"):
            try:
                v = obj.get(k)
                if v not in (None, ""):
                    return float(v)
            except Exception:
                pass
    try:
        return fallback_path.stat().st_mtime
    except Exception:
        return 0.0


def _row_ts(row: Dict[str, Any], global_ts: float = 0.0) -> float:
    for k in ("updated_ts", "orderflow_ts", "ts", "timestamp", "created_at", "detected_ts"):
        try:
            v = row.get(k)
            if v not in (None, ""):
                return float(v)
        except Exception:
            pass
    return global_ts or 0.0


def _scanner_quote(row: Dict[str, Any], global_ts: float, ttl: float = 35.0) -> Dict[str, Any]:
    """WS가 바로 안 들어오는 active 후보에 대해 scanner/feature REST 현재가를 표준 시세로 보강한다.
    fake fresh가 아니라 이미 scanner/feature worker가 만든 최신 REST 값을 쓰는 것이다.
    """
    price = fnum(row.get("current_price"), row.get("price"), row.get("close"), row.get("trade_price"), default=0.0)
    rts = _row_ts(row, global_ts)
    fresh = bool(price > 0 and rts > 0 and (now_ts() - rts) <= ttl)
    return {"rest_price": price, "rest_ts": rts, "rest_fresh": fresh, "rest_age_sec": round(max(0.0, now_ts() - rts), 3) if rts else None}

def _ratio01(v: Any, default: float = -1.0) -> float:
    x = fnum(v, default=default)
    if x > 1.5:
        x = x / 100.0
    if x < 0:
        return default
    return max(0.0, min(1.0, x))


def _load_sustain_state() -> Dict[str, List[List[float]]]:
    obj = load_json(SUSTAIN_STATE, {}) or {}
    raw = obj.get("history") if isinstance(obj, dict) and isinstance(obj.get("history"), dict) else obj
    out: Dict[str, List[List[float]]] = {}
    if isinstance(raw, dict):
        for k, vals in raw.items():
            t = ticker_norm(k)
            if not t or not isinstance(vals, list):
                continue
            hist: List[List[float]] = []
            for item in vals[-80:]:
                try:
                    if isinstance(item, (list, tuple)) and len(item) >= 2:
                        ts = float(item[0]); ratio = _ratio01(item[1], default=-1.0)
                    elif isinstance(item, dict):
                        ts = fnum(item.get("ts"), item.get("updated_ts"), default=0.0)
                        ratio = _ratio01(item.get("buy_ratio"), default=-1.0)
                    else:
                        continue
                    if ts > 0 and ratio >= 0:
                        hist.append([ts, round(ratio, 6)])
                except Exception:
                    continue
            if hist:
                out[t] = hist
    return out


def _save_sustain_state(history: Dict[str, List[List[float]]], ts: float) -> None:
    # Keep compact rolling state only. This is a producer state, not a long-term log.
    compact = {k: v[-80:] for k, v in history.items() if v}
    save_json(SUSTAIN_STATE, {
        "version": VERSION,
        "schema": "orderflow_buy_sustain_state_v527",
        "updated_ts": ts,
        "window_sec": SUSTAIN_WINDOW_SEC,
        "keep_sec": SUSTAIN_KEEP_SEC,
        "ready_min_span_sec": SUSTAIN_READY_MIN_SPAN,
        "ready_min_samples": SUSTAIN_READY_MIN_SAMPLES,
        "history": compact,
    })


def _direct_sustain_from_micro(m: Dict[str, Any]) -> Tuple[Optional[float], str]:
    # If micro sidecar already provides a real 60s/1m field, use it directly.
    for k in ("buy_sustain_1m", "buy_sustain_60s", "buy_persist_1m", "buy_flow_1m", "buy_pressure_1m", "micro_buy_sustain_1m"):
        v = _ratio01(m.get(k), default=-1.0)
        if v >= 0:
            return v, k
    return None, ""


def _update_sustain(history: Dict[str, List[List[float]]], ticker: str, buy_ratio: float, ts: float, micro_fresh: bool, m: Dict[str, Any]) -> Dict[str, Any]:
    direct, direct_src = _direct_sustain_from_micro(m)
    if direct is not None:
        return {
            "value": direct,
            "real": True,
            "source": direct_src,
            "sample_count": 1,
            "span_sec": 60.0,
            "persist": 1.0 if direct >= 0.70 else 0.0,
            "ready": True,
        }

    hist = history.get(ticker, [])
    if micro_fresh and buy_ratio >= 0:
        hist.append([ts, round(buy_ratio, 6)])
    cutoff = ts - SUSTAIN_KEEP_SEC
    hist = [[a, b] for a, b in hist if a >= cutoff and b >= 0]
    history[ticker] = hist

    win_cut = ts - SUSTAIN_WINDOW_SEC
    win = [[a, b] for a, b in hist if a >= win_cut]
    if not win:
        return {"value": None, "real": False, "source": "insufficient_history", "sample_count": 0, "span_sec": 0.0, "persist": None, "ready": False}

    vals = [b for _, b in win]
    span = max(0.0, win[-1][0] - win[0][0])
    ready = bool(len(vals) >= SUSTAIN_READY_MIN_SAMPLES and span >= SUSTAIN_READY_MIN_SPAN)
    avg = sum(vals) / len(vals)
    persist = sum(1 for x in vals if x >= 0.70) / len(vals)
    if ready:
        return {"value": avg, "real": True, "source": "orderflow_rolling_60s", "sample_count": len(vals), "span_sec": span, "persist": persist, "ready": True}
    return {"value": None, "real": False, "source": "insufficient_history", "sample_count": len(vals), "span_sec": span, "persist": persist, "ready": False}

def run_once()->Dict[str,Any]:
    st=now_ts(); ts=now_ts()
    feature_obj = load_json(FEATURE,{}) or {}
    feature_ts = _obj_updated_ts(feature_obj, FEATURE)
    fmap = map_rows(feature_obj)
    qobj=load_json(TARGET_QUEUE,{}) or {}
    mtargets_obj=load_json(MICRO_TARGETS,{}) or {}
    murgent_obj=load_json(MICRO_URGENT,{}) or {}
    sreq_obj=load_json(STRATEGY_REQ,{}) or {}
    qrows = qobj.get("active_rows") if isinstance(qobj,dict) and isinstance(qobj.get("active_rows"), list) else []
    micro_target_rows = mtargets_obj.get("rows") if isinstance(mtargets_obj,dict) and isinstance(mtargets_obj.get("rows"), list) else []
    micro_urgent_set = {ticker_norm(x) for x in (murgent_obj.get("targets") if isinstance(murgent_obj,dict) and isinstance(murgent_obj.get("targets"), list) else []) if ticker_norm(x)}
    strategy_req_rows = sreq_obj.get("requests") if isinstance(sreq_obj,dict) and isinstance(sreq_obj.get("requests"), list) else []
    strategy_req_map = {ticker_norm(r.get("ticker")): r for r in strategy_req_rows if isinstance(r,dict) and ticker_norm(r.get("ticker"))}
    micro_target_map = {ticker_norm(r.get("ticker")): r for r in micro_target_rows if isinstance(r,dict) and ticker_norm(r.get("ticker"))}
    qmap={ticker_norm(r.get("ticker")):r for r in qrows if isinstance(r,dict) and ticker_norm(r.get("ticker"))}
    # active target을 먼저, 그 뒤 feature 전체를 붙여 canonical rows를 만든다.
    ordered=[]; seen=set()
    for t,qr in qmap.items():
        base = dict(fmap.get(t, {}) or {})
        base.setdefault("ticker", t)
        base["router_priority"] = fnum(qr.get("priority"), default=0)
        base["router_bucket"] = qr.get("bucket")
        base["router_need"] = qr.get("need")
        base["router_active"] = True
        ordered.append(base); seen.add(t)
    for t,r in fmap.items():
        if t not in seen:
            rr=dict(r); rr.setdefault("ticker", t); rr["router_active"] = False
            ordered.append(rr); seen.add(t)
    ws=map_rows(load_json(WS,{}) or {}); micro=map_rows(load_json(MICRO,{}) or {})
    sustain_history = _load_sustain_state()
    rows=[]; fresh_ws=0; fresh_micro=0; quote_fresh_count=0; info_ready_count=0; router_fresh=0; active_count=0
    buy_sustain_ready_count=0; buy_sustain_pending_count=0; buy_sustain_direct_count=0; buy_sustain_rolling_count=0
    micro_target_count=micro_target_fresh=0; micro_urgent_count=micro_urgent_fresh=0; strategy_req_count=strategy_req_micro_ready=strategy_req_info_ready=0
    for r in ordered:
        t=ticker_norm(r.get("ticker"));
        if not t: continue
        w=ws.get(t,{}) or {}; m=micro.get(t,{}) or {}
        wf=is_fresh(w,WS_TTL_SEC); mf=is_fresh(m,MICRO_TTL_SEC)
        ws_age=row_age_sec(w) if w else 999999.0
        micro_age=row_age_sec(m) if m else 999999.0
        rest = _scanner_quote(r, feature_ts)
        quote_fresh = bool(wf or rest.get("rest_fresh"))
        quote_source = "ws" if wf else ("scanner_rest" if rest.get("rest_fresh") else "missing")
        fresh_ws += 1 if wf else 0
        fresh_micro += 1 if mf else 0
        quote_fresh_count += 1 if quote_fresh else 0
        info_ready = bool(quote_fresh and mf)
        info_ready_count += 1 if info_ready else 0
        active = bool(r.get("router_active"))
        micro_target = t in micro_target_map
        micro_urgent = t in micro_urgent_set or bool((micro_target_map.get(t) or {}).get("micro_urgent"))
        strategy_req = t in strategy_req_map
        active_count += 1 if active else 0
        micro_target_count += 1 if micro_target else 0
        micro_target_fresh += 1 if micro_target and mf else 0
        micro_urgent_count += 1 if micro_urgent else 0
        micro_urgent_fresh += 1 if micro_urgent and mf else 0
        strategy_req_count += 1 if strategy_req else 0
        strategy_req_micro_ready += 1 if strategy_req and mf else 0
        strategy_req_info_ready += 1 if strategy_req and info_ready else 0
        if active and info_ready: router_fresh += 1
        price=fnum(r.get("current_price"), r.get("price"), default=0)
        ws_price=fnum(w.get("price"),w.get("current_price"),w.get("trade_price"),w.get("close"), default=0)
        quote_price = ws_price if wf and ws_price else fnum(rest.get("rest_price"), default=0.0)
        spread=fnum(m.get("spread_pct"),m.get("orderbook_spread_pct"),m.get("micro_spread_pct"), default=0.0)
        ask=fnum(m.get("ask_price"),m.get("best_ask"), default=0); bid=fnum(m.get("bid_price"),m.get("best_bid"), default=0)
        if not spread and ask and bid: spread=pct(ask,bid)
        buy_ratio=fnum(m.get("buy_ratio"),m.get("trade_buy_ratio_30"),m.get("micro_trade_buy_ratio_30"),m.get("buy_trade_ratio"),m.get("buy_ratio_30s"), default=0.0)
        if buy_ratio>1.5: buy_ratio=buy_ratio/100.0
        bid_wall=fnum(m.get("bid_ask_wall_ratio"),m.get("micro_bid_ask_wall_ratio"),m.get("buy_wall_ratio"), default=0.0)
        ask_wall_raw=fnum(m.get("ask_wall_ratio"),m.get("micro_ask_wall_ratio"),m.get("sell_wall_ratio"), default=-1.0)
        ask_wall_ratio = ask_wall_raw if ask_wall_raw >= 0 else ((1.0/bid_wall) if bid_wall>0 else (1.0 if mf else None))
        sustain_info = _update_sustain(sustain_history, t, buy_ratio, ts, mf, m)
        buy_sustain_1m = sustain_info.get("value") if sustain_info.get("real") else None
        buy_sustain_ready_count += 1 if sustain_info.get("real") else 0
        buy_sustain_pending_count += 1 if not sustain_info.get("real") else 0
        buy_sustain_direct_count += 1 if str(sustain_info.get("source") or "").startswith(("buy_", "micro_")) and sustain_info.get("real") else 0
        buy_sustain_rolling_count += 1 if sustain_info.get("source") == "orderflow_rolling_60s" else 0
        slip_raw=fnum(m.get("slippage_est_pct"),m.get("expected_slippage_pct"),m.get("tick_pct_est"), default=-1.0)
        slippage_est_pct = slip_raw if slip_raw >= 0 else (spread if mf and spread>=0 else None)
        sell_pressure=bool(m.get("ask_wall_pressure") or m.get("micro_ask_wall_pressure") or m.get("sell_trade_pressure") or m.get("micro_sell_trade_pressure") or m.get("ask_pressure"))
        gap=pct(quote_price,price) if price and quote_price else 0.0
        strength_score=0
        strength_score += 2 if quote_fresh else -1
        strength_score += 2 if mf else -1
        strength_score += 1 if 0<spread<=0.22 else (-1 if spread>0.35 else 0)
        strength_score += 1 if buy_ratio>=0.62 else (-1 if buy_ratio and buy_ratio<0.5 else 0)
        strength_score += -1 if sell_pressure else 1
        rr={
            "ticker":t,
            "orderflow_ts":ts,
            "schema":"orderflow_canonical_v5_s123",
            "quote_fresh":quote_fresh,
            "quote_source":quote_source,
            "quote_price":quote_price,
            "quote_gap_pct":round(gap,3),
            "quote_age_sec": 0.0 if wf else rest.get("rest_age_sec"),
            "ws_age_sec": round(ws_age, 3) if ws_age < 999999 else None,
            "micro_age_sec": round(micro_age, 3) if micro_age < 999999 else None,
            "ws_fresh":wf,
            "micro_fresh":mf,
            "info_ready":info_ready,
            "ws_price":ws_price,
            "ws_gap_pct":round(pct(ws_price,price),3) if price and ws_price else 0.0,
            "rest_fresh":bool(rest.get("rest_fresh")),
            "rest_price":rest.get("rest_price"),
            "rest_age_sec":rest.get("rest_age_sec"),
            "spread_pct":round(spread,3),
            "buy_ratio":round(buy_ratio,3),
            "buy_sustain_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_sustain_60s":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_persist_1m":round(sustain_info.get("persist"),3) if sustain_info.get("persist") is not None else None,
            "buy_flow_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_pressure_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "micro_buy_sustain_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_ratio_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_ratio_60":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "micro_buy_ratio_sustain_1m":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_ratio_sustain":round(buy_sustain_1m,3) if buy_sustain_1m is not None else None,
            "buy_sustain_1m_real":bool(sustain_info.get("real")),
            "buy_sustain_1m_source":sustain_info.get("source"),
            "buy_sustain_1m_ready":bool(sustain_info.get("ready")),
            "buy_sustain_sample_count":int(sustain_info.get("sample_count") or 0),
            "buy_sustain_span_sec":round(float(sustain_info.get("span_sec") or 0.0),3),
            "slippage_est_pct":round(slippage_est_pct,3) if slippage_est_pct is not None else None,
            "tick_pct_est":round(slippage_est_pct,3) if slippage_est_pct is not None else None,
            "expected_slippage_pct":round(slippage_est_pct,3) if slippage_est_pct is not None else None,
            "bid_wall_ratio":round(bid_wall,3),
            "ask_wall_ratio":round(ask_wall_ratio,3) if ask_wall_ratio is not None else None,
            "micro_ask_wall_ratio":round(ask_wall_ratio,3) if ask_wall_ratio is not None else None,
            "canonical_orderflow_ready": bool(mf and buy_sustain_1m is not None and slippage_est_pct is not None and ask_wall_ratio is not None),
            "canonical_missing": [x for x,v in {"buy_sustain_1m":buy_sustain_1m,"slippage_est_pct":slippage_est_pct,"ask_wall_ratio":ask_wall_ratio}.items() if v is None],
            "sell_pressure":sell_pressure,
            "orderflow_score":strength_score,
            "micro_status":"fresh" if mf else ("stale" if m else "missing"),
            "ws_status":"fresh" if wf else ("stale" if w else "missing"),
            "quote_status":"fresh" if quote_fresh else "missing",
            "router_active": active,
            "micro_target": micro_target,
            "micro_urgent": micro_urgent,
            "strategy_request": strategy_req,
            "strategy_request_bucket": (strategy_req_map.get(t) or {}).get("bucket"),
            "strategy_request_need": (strategy_req_map.get(t) or {}).get("need"),
            "router_priority":r.get("router_priority"),
            "router_bucket":r.get("router_bucket"),
            "router_need":r.get("router_need"),
        }
        rows.append(rr)
    _save_sustain_state(sustain_history, ts)
    save_json(OUT,{"version":VERSION,"schema":"orderflow_canonical_v527_buy_sustain","updated_ts":ts,"updated_text":now_text(ts),"row_count":len(rows),"active_count":active_count,"fresh_ws":fresh_ws,"fresh_micro":fresh_micro,"quote_fresh":quote_fresh_count,"info_ready":info_ready_count,"buy_sustain_ready_count":buy_sustain_ready_count,"buy_sustain_pending_count":buy_sustain_pending_count,"buy_sustain_direct_count":buy_sustain_direct_count,"buy_sustain_rolling_count":buy_sustain_rolling_count,"buy_sustain_window_sec":SUSTAIN_WINDOW_SEC,"buy_sustain_ready_min_span_sec":SUSTAIN_READY_MIN_SPAN,"buy_sustain_ready_min_samples":SUSTAIN_READY_MIN_SAMPLES,"router_queue_age":age_sec(TARGET_QUEUE),"router_target_count":qobj.get("active_target_count", qobj.get("target_count","-")),"router_queue_count":qobj.get("queue_count","-"),"router_backlog_count":qobj.get("backlog_count","-"),"router_fresh_ready":router_fresh,"micro_target_count":micro_target_count,"micro_target_fresh":micro_target_fresh,"micro_urgent_count":micro_urgent_count,"micro_urgent_fresh":micro_urgent_fresh,"strategy_req_count":strategy_req_count,"strategy_req_micro_ready":strategy_req_micro_ready,"strategy_req_info_ready":strategy_req_info_ready,"ws_cache_count":len(ws),"micro_cache_count":len(micro),"feature_age_sec":round(max(0.0, ts-feature_ts),3) if feature_ts else None,"ws_ttl_sec":WS_TTL_SEC,"micro_ttl_sec":MICRO_TTL_SEC,"note":"v0.9/v527: orderflow가 60초 rolling history로 buy_sustain_1m 실측값을 생산한다. buy_ratio fallback은 strategy에서 실측으로 보지 않는다.","rows":rows})
    sec=now_ts()-st
    write_status("running", row_count=len(rows), active_count=active_count, fresh_ws=fresh_ws, fresh_micro=fresh_micro, quote_fresh=quote_fresh_count, info_ready=info_ready_count, buy_sustain_ready_count=buy_sustain_ready_count, buy_sustain_pending_count=buy_sustain_pending_count, buy_sustain_direct_count=buy_sustain_direct_count, buy_sustain_rolling_count=buy_sustain_rolling_count, buy_sustain_window_sec=SUSTAIN_WINDOW_SEC, router_target_count=qobj.get("active_target_count", qobj.get("target_count","-")), router_queue_count=qobj.get("queue_count","-"), router_backlog_count=qobj.get("backlog_count","-"), router_fresh_ready=router_fresh, micro_target_count=micro_target_count, micro_target_fresh=micro_target_fresh, micro_urgent_count=micro_urgent_count, micro_urgent_fresh=micro_urgent_fresh, strategy_req_count=strategy_req_count, strategy_req_micro_ready=strategy_req_micro_ready, strategy_req_info_ready=strategy_req_info_ready, ws_cache_count=len(ws), micro_cache_count=len(micro), feature_age_sec=round(max(0.0, ts-feature_ts),3) if feature_ts else None, ws_ttl_sec=WS_TTL_SEC, micro_ttl_sec=MICRO_TTL_SEC, last_sec=round(sec,3))
    return {"rows":len(rows), "active":active_count, "quote_fresh":quote_fresh_count, "info_ready":info_ready_count}

def main()->None:
    write_status("initializing")
    while True:
        try: run_once()
        except KeyboardInterrupt: write_status("stopping"); raise
        except Exception as exc: append_error(ERROR,"loop",exc); write_status("error", error=f"{exc.__class__.__name__}: {exc}")
        time.sleep(max(0.5,INTERVAL_SEC))
if __name__=="__main__": main()
