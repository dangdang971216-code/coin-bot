v2083: Main command registry crash guard. Removes invalid over-32-char command alias; keeps /instant_death_audit and /instant_death_audit_full. No strategy/ledger/autobuy change.
