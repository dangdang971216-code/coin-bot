v2085: fix instant-death fast data connection and show missing source/Paper freshness. No candidate or trading-rule change. Auto-buy OFF.
