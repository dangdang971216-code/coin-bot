v2084: connect existing sealed trade diagnostics to instant-death audit. No strategy/ledger/auto-buy change.
