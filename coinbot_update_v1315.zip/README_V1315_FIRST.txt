v1315 restores the original deploy manifest contract: paper is top-level paper, not a generic worker. Runtime code is carried forward from v1314.
