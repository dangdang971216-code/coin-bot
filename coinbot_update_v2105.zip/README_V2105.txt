coinbot_update_v2105

목적
- target에 닿기 전에도 고점을 만든 뒤 힘이 꺾이면 수익으로 끝내는 조건 찾기
- 새 Shadow를 만들거나 기존 자료를 초기화하지 않고 기존 profit_giveback Shadow 재사용
- 같은 시작점 forward 후보 9개
  · MFE +1.5%: 반납 0.6 / 0.8 / 1.0%p
  · MFE +3.0%: 반납 1.0 / 1.2 / 1.5%p
  · MFE +5.0% Runner: 반납 1.8 / 2.0 / 2.3%p
- v2105 첫 관찰값에서 별도 peak를 시작해 과거 peak를 exact처럼 재계산하지 않음
- /peak_exit_audit: forward 발동·exact CLOSED 비교·개선·수익훼손·현재 OPEN 조건충족 표시
- /version_score: 기존 Shadow 현재 표본/선두 한 줄 표시
- v2104 단계형 수익보존 Paper v2.060은 함께 적용
- v2105 고점반납 후보는 실제 target/trailing/exit/OPEN 변경 없음
- 자동매수 OFF

서버 기준
- Main 수익형 v2.13.2087
- Review review_worker_v2.036
- Paper paper_bot_v2.060 적용·검수
- /peak_exit_audit /version_score /errorlog
