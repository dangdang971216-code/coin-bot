coinbot_update_v1424
====================
목적:
- v1423에서 진짜놓침 ticker가 다음 cycle에서 S1/S3로 drift되면, 우선재확인이 같은 유형의 다른 S2 후보로 밀릴 수 있었다.
- v1424는 원래 진짜놓침 S2 ticker/key를 먼저 carry-forward해서 feature/candle/quote/micro/orderflow 우선재확인으로 보낸다.
- 실제 Paper/OPEN 진입은 열지 않고 Paper-shadow만 유지한다.
- Paper status_write 메모리 경고는 full status 파일 저장 후 process 안의 _LAST_STATUS만 가볍게 보관하도록 줄였다.

변경 없음:
- Gate, TTL, RR, trigger, invalid, target, 청산계약, OPEN limit, 자동매수 OFF.
- OPEN/CLOSED/trade_log/decision/exact 원장 수정 없음.

검수:
- py_compile PASS: bot.py, strategy_worker.py, paper_bot.py
- 서버 적용 후 /flow_map_full /candidate_standard /missed_where /s2_recheck /version_score /errorlog 확인.
