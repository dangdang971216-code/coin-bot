v1355 error-only Paper status/S1 input fix. No trading rule changes. Auto-buy OFF. No live ledgers included.
