import json
from pathlib import Path
bundle=json.loads(Path('DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert bundle['release']=='v1267'
assert bundle['paper']=='paper_bot_v1.080.py'
assert bundle['workers']['strategy']=='strategy_worker_v1.064.py'
assert bundle['auto_buy'] is False
assert bundle['trigger_invalid_target_rr_changed'] is False
assert bundle['paper_preopen_safety_enforced'] is True
assert bundle['entry_quality_material_required_for_new_open'] is True
assert bundle['historical_trade_ledgers_rewritten'] is False

assert bundle['guard']=='backga_guard_bot_v2_5_245.py'
assert bundle['guard_ledger_verify_command']=='/gledger_v1267'
