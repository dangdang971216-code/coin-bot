from pathlib import Path
s = Path('backga_guard_bot_v2_5_245.py').read_text(encoding='utf-8')
assert 'guard_v2.5.245_v1267_entry_quality_material_2026-07-06' in s
assert 'def gledger_v1267_text' in s
assert '/gledger_v1267' in s
assert 'V1267_EXPECTED_ISSUE_EVENTS' in s
assert 'V1267_EXPECTED_CHANGE_EVENTS' in s
assert 'live 원장을 읽기만 하며 수정·재작성하지 않음' in s
