from pathlib import Path
s = Path('strategy_worker_v1.064.py').read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.064'" in s
assert "entry_quality_material_contract_v1267" in s
assert "paper_new_open_quality_material_required_v1267" in s
assert "'trigger_invalid_target_rr_changed_v1267':False" in s
assert "'strategy_s1_pass_changed': False" in s
assert "'global_rank_changed': False" in s
