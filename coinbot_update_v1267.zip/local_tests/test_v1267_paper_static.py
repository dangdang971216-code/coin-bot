from pathlib import Path
s = Path('paper_bot_v1.080.py').read_text(encoding='utf-8')
assert "VERSION = 'paper_bot_v1.080'" in s
assert "_v1267_quality_material_contract_from_event" in s
assert "ENTRY_QUALITY_MATERIAL_BLOCK" in s
assert "if not ok:" in s
assert "paper_final_safety_block_v1267" in s
assert "continue" in s[s.index("paper_final_safety_block_v1267"):s.index("stats['paper_final_safety_pass_v1099']")]
assert "paper_final_safety_active_v1267" in s
