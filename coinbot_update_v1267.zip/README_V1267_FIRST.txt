v1267은 후보 기준 완화판이 아니다. Strategy가 기존 진입 품질 재료를 계약으로 봉인하고, Paper가 신규 OPEN 직전 실제 차단에 연결한다. Guard는 /gledger_v1267로 live 장부 tail만 읽는다. 자동매수 OFF, trigger/invalid/target/RR/청산/OPEN cap 변경 없음.
