v1319 applies the v1318 main/paper runtime files only, using the original top-level deploy contract. Review v1.042 was already applied in v1318 and is intentionally not in workers.
