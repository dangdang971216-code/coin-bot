coinbot_update_v1606
- 후보 삭제/차단 방향 폐기
- 구조 좋은 후보는 보존하고 실행만 재확인 대기
- v1605는 적용하지 않는 전제
- TTL/Gate/RR/trigger/invalid/target/청산/OPEN/자동매수 변경 없음
