from __future__ import annotations
import ast, hashlib, json, re, tempfile, time
from pathlib import Path
from typing import Any, Dict, Optional

ROOT=Path(__file__).resolve().parent
MAIN=ROOT/'coinbot_main_v2_13_1105.py'
GUARD=ROOT/'backga_guard_bot_v2_5_179.py'

def load_funcs(path: Path, names: set[str], ns: dict):
    src=path.read_text(encoding='utf-8')
    tree=ast.parse(src)
    nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name in names]
    found={n.name for n in nodes}
    missing=names-found
    assert not missing, f'missing functions {missing}'
    mod=ast.Module(body=nodes,type_ignores=[])
    ast.fix_missing_locations(mod)
    exec(compile(mod,str(path),'exec'),ns)

# Main trust gate
main_ns={'Any':Any,'Dict':Dict,'Optional':Optional,'List':list,'now_ts':lambda:1000.0,
         'FILES':{'paper_status':Path('/tmp/paper_bot_status.json')},'BASE_DIR':Path('/tmp'),
         '_v650_file_age':lambda path:300.0}
load_funcs(MAIN,{'_v1138_public_score_trust_contract','_v1138_score_trust_lines'},main_ns)
contract=main_ns['_v1138_public_score_trust_contract']
base_snapshot={'schema':'canonical_alt_swing_performance_snapshot_v987','snapshot_id':'perf-x','generated_at':900.0,
 'performance_epoch_v1045':{'epoch_id':'epoch-new','reset_batch_id':'batch-new','zero_open_proof':True,'windows':{'all':{'n':31,'wins':20,'losses':11,'total':10.0,'avg':0.32}}}}
paper={'paper_performance_semantic_heartbeat_v1117':{'semantic_current':True,'last_check_at':995.0,'state':'EVENT_DRIVEN_IDLE'}}
status={'batch_id':'batch-new'}; manifest={'batch_id':'batch-new'}; control={'batch_id':'batch-new'}; execution={'batch_id':'batch-new'}
epoch={'epoch_id':'epoch-new','reset_batch_id':'batch-new','zero_open_proof':True,'state':'ACTIVE'}
# stale public status must block
r=contract(base_snapshot,paper,status,manifest,control,execution,epoch,1000.0)
assert r['state']=='CHECK' and 'paper_status_stale' in r['reasons']
# fresh aligned >=30 becomes reviewable
main_ns['_v650_file_age']=lambda path:10.0
r=contract(base_snapshot,paper,status,manifest,control,execution,epoch,1000.0)
assert r['state']=='NORMAL' and r['recovery_judgement_state']=='REVIEWABLE'
# aligned but small sample remains CHECK without changing data truth
small=json.loads(json.dumps(base_snapshot)); small['performance_epoch_v1045']['windows']['all']['n']=5
r=contract(small,paper,status,manifest,control,execution,epoch,1000.0)
assert r['state']=='NORMAL' and r['recovery_judgement_state']=='CHECK' and 'fresh_epoch_sample_below_30' in r['reasons']
text='\n'.join(main_ns['_v1138_score_trust_lines'](r))
assert '수익 회복 판단' in text and '과거 ALT_SWING 누적 참고값' in text

# Guard public score + approved deploy target
with tempfile.TemporaryDirectory() as td:
    bot=Path(td)
    def writej(name,obj): (bot/name).write_text(json.dumps(obj),encoding='utf-8')
    writej('canonical_performance_snapshot_v987.json',base_snapshot)
    writej('paper_bot_status.json',paper)
    writej('paper_quality_rebuild_epoch_v1095.json',epoch)
    approved=bot/'coinbot_main_v2_13_1105.py'; approved.write_text('approved',encoding='utf-8')
    generic=bot/'coinbot_main_v2_14_1067.py'; generic.write_text('old higher archive',encoding='utf-8')
    (bot/'bot.py').write_text('approved',encoding='utf-8')
    (bot/'DEPLOY_TARGET.txt').write_text(approved.name+'\n',encoding='utf-8')
    (bot/'.deployed_target').write_text(approved.name+'\n',encoding='utf-8')
    def read_file(path):
        try:return Path(path).read_text(encoding='utf-8').strip()
        except OSError:return ''
    def version_from_filename(path):
        m=re.search(r'v(\d+)[_\.](\d+)[_\.](\d+)',Path(path).name)
        return tuple(map(int,m.groups())) if m else None
    def read_json(path):
        try:return json.loads(Path(path).read_text(encoding='utf-8'))
        except Exception:return {}
    def sha(path):
        try:return hashlib.sha256(Path(path).read_bytes()).hexdigest()
        except OSError:return ''
    guard_ns={'Path':Path,'Optional':Optional,'BOT_DIR':bot,'read_file':read_file,'version_from_filename':version_from_filename,
              '_ops_read_json':read_json,'_ops_sha256':sha,'time':time}
    load_funcs(GUARD,{'_approved_main_target_v1138','_generic_highest_main_source_v1138','find_latest_source_file',
                      '_ops_public_score_trust_contract_v1138','_ops_main_deploy_target_contract_v1138'},guard_ns)
    assert guard_ns['find_latest_source_file']().name==approved.name
    dep=guard_ns['_ops_main_deploy_target_contract_v1138']()
    assert dep['state']=='NORMAL' and dep['generic_archive_conflict'] is True
    reset={'state':'NORMAL','manifest_batch_id':'batch-new'}
    score=guard_ns['_ops_public_score_trust_contract_v1138'](reset)
    # paper status mtime is fresh; heartbeat timestamp in test is ancient relative to real time -> correctly blocked
    assert score['state']=='CHECK' and 'performance_semantic_heartbeat_not_current' in score['reasons']

# Version/contract static assertions
mt=MAIN.read_text(encoding='utf-8'); gt=GUARD.read_text(encoding='utf-8')
assert "BOT_VERSION = '수익형 v2.13.1105'" in mt
assert "guard_v2.5.179_public_score_trust_map_v1138" in gt
assert 'PUBLIC_SCORE_TRUST_BLOCKED' in gt
assert 'UNAPPROVED_ARCHIVE_DO_NOT_DEPLOY' in gt
assert 'Paper v1.023 runtime' in mt
assert 'quality Gate/rank' in mt
print('V1138_CONTRACT_PASS')
