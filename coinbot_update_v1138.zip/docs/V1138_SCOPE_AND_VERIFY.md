# v1138 scope

## Root cause
`/version_score` read the canonical performance snapshot but did not propagate upstream trust failures. It could therefore show an improved historical win rate while Paper status/semantic heartbeat was stale, reset generations were mismatched, and the post-v1135 epoch was not active.

A separate Guard discovery path treated the numerically highest `coinbot_main_v*.py` archive as the latest approved source even when `DEPLOY_TARGET.txt`, `.deployed_target`, active `bot.py`, and the successful release all pointed to another file.

## Mainline
- Paper canonical semantic heartbeat
- matching reset status/manifest/control/execution/epoch generation
- active zero-open-proven epoch
- canonical snapshot epoch match
- `/version_score` trust state and fresh epoch stats
- Guard full-map `PUBLIC_SCORE_TRUST_BLOCKED`

Top-level historical performance remains reference-only. Post-v1135 recovery is judged only from `performance_epoch_v1045`. Fewer than 30 fresh CLOSED rows remains a display-confidence CHECK.

## Not changed
Paper, Strategy, quality Gate, rank, TTL, invalid, target, trailing, OPEN 30, cycle 3, protected ledgers, automatic buying.
