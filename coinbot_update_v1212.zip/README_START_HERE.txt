코인봇 업데이트 v1212 · 서버 적용 전 CHECK
===========================================
작성: 2026-07-03 20:38:24 KST
전략모드: ALT_SWING
자동매수: OFF

목적
- 코인마다 변동성·실제 반응 구조·거래비용이 다른 점을 반영해 Trigger/Invalid/Target을 동적으로 생성합니다.
- 전략별 우선순서와 Runner 전용 자리를 없애고, 거래 가능한 전체 S1 후보를 한 점수표에서 비교해 최대 2개를 선택합니다.
- 이전 v1211 구조선과 새 v1212 구조선 성과를 OPEN 당시 계약 기준으로 /version_score에서 분리합니다.
- 예전 % 구조선 writer와 최종선에 쓰이지 않는 중복 helper를 제거합니다.

핵심 파일
- strategy_worker_v1.044.py
- paper_bot_v1.063.py
- coinbot_main_v2_13_1141.py
- backga_guard_bot_v2_5_210.py

유지한 계약
- 전체시장 후보 생성과 기존 S1 기본 배관 유지
- 전체 OPEN 한도 10, 같은 generation 신규 OPEN 최대 2 유지
- 좋은 후보가 없으면 신규 OPEN 0개 가능
- 기존 OPEN의 trigger/invalid/target/청산계약 재작성 없음
- v1207 동적청산 유지
- 라이브 원장 포함·삭제·재작성 없음
- 자동매수 OFF

로컬 검수
- 적용 가능한 검사 69/69 PASS
- py_compile PASS
- 버전 파일과 실행 별칭 hash 일치 확인
- 서버 runtime·PID·실제 다음 cycle은 아직 미검증이므로 CHECK

자세한 내용
- docs/V1212_WORK_LOCK_AND_DESIGN.txt
- LOCAL_TEST_RESULT_V1212.txt
- V1212_BASELINE_AND_COMPARISON.json
