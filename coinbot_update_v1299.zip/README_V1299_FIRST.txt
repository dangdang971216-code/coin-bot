Purpose: make /version_score default view a clean 0-trade active epoch board. Old CLOSED/reset rows remain in ledgers but are not shown as default strategy score.
