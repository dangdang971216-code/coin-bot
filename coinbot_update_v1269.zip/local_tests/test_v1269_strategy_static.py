from pathlib import Path
s=Path('strategy_worker_v1.066.py').read_text(encoding='utf-8')
assert "VERSION = 'strategy_worker_v1.066'" in s
assert "invalid_distance_uses_buffered_stop_line_v1269" in s
assert "candidate_line = _v1212_line_from_zone(zone, 'setup', 'zone_low', -float(invalid_buffer))" in s
assert "target_role_class_v1225'] = 't1_near_resistance_v1268'" in s
assert "V925_MIN_TARGET_ROOM_PCT" in s
