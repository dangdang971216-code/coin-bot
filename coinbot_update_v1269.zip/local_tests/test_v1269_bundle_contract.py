import json
from pathlib import Path
b=json.loads(Path('DEPLOY_BUNDLE.json').read_text(encoding='utf-8'))
assert b['release']=='v1269'
assert b['runtime_files']['strategy']=='strategy_worker_v1.066.py'
assert b['runtime_files']['guard']=='backga_guard_bot_v2_5_247.py'
assert b['target_selection_changed'] is False
assert b['rr_threshold_changed'] is False
assert b['auto_buy'] is False
