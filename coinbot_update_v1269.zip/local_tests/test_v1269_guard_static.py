from pathlib import Path
s=Path('backga_guard_bot_v2_5_247.py').read_text(encoding='utf-8')
assert 'guard_v2.5.247_v1269_invalid_line_buffered_distance_2026-07-06' in s
assert '/gledger_v1269' in s
assert 'V1269-INVALID-LINE-BUFFERED-DISTANCE' in s
