from pathlib import Path
s=Path('paper_bot_v1.081.py').read_text(encoding='utf-8')
assert "add_reason_v1122('ENTRY_QUALITY_MATERIAL_BLOCK'" not in s
assert 'shadow_only_v1268' in s
assert 'paper_bot_v1.081' in s
