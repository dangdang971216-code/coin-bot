#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# Auto-flattened v1181 active dependency graph; historical unreachable definitions removed.

"""
backga_guard_bot_v2.py
- 메인 코인봇(tradingbot)이 죽어도 따로 살아있는 관리 전용 텔레그램 봇
- 표준 라이브러리만 사용
- GUARD_CHAT_ID에서 온 명령만 처리

핵심 개선:
- DEPLOY_TARGET 없이 GitHub 최신 수익형_v*.py 자동 선택
- fast validate: py_compile + BOT_VERSION + command string 중심 검사
- 필수 명령어 문자열 검사
- bot.py 백업/교체/hash 검증/재시작/실패 시 자동 롤백
- 가드봇 메뉴 등록
"""

import ast

import builtins

import gzip

import fcntl

import http.client

import hashlib

import json

import math

import os

import pwd

import re

import shutil

import signal

import subprocess

import sys

import tempfile

import threading

import time

import urllib.parse

import urllib.request

import zipfile

from collections import Counter

from dataclasses import dataclass

from datetime import datetime

from pathlib import Path

from typing import Any, Iterable, Optional

ENV_PATH = Path(__file__).with_name("guard.env")

VERSION = "guard_v2.5.247_v1269_invalid_line_buffered_distance_2026-07-06"
OPEN_LIMIT_POLICY_V1199 = "TOTAL50_GLOBAL_SCORE_CYCLE5_AUTO_BUY_OFF"

UPGRADE_STATUS_FILE = ".guard_upgrade_status.json"

GUARD_OFFSET_FILE = ".guard_update_offset.json"

GUARD_RUNTIME_STATUS_FILE = "clean_guard_runtime_status_v1010.json"

GUARD_RUNTIME_WRITE_INTERVAL_SEC = 20.0

_GUARD_CPU_SAMPLE_V1010 = None

_GUARD_PROC_IO_SAMPLE_V1011 = {}

_GUARD_DISK_IO_SAMPLE_V1011 = None

_GUARD_RUNTIME_WRITE_SEQUENCE_V1033 = 0

GUARD_START_NOTICE_FILE = ".guard_start_notice.json"

GUARD_POST_UPGRADE_FILE = ".guard_post_upgrade_request.json"

GUARD_RELEASE_RESULT_FILE = "guard_release_last_result_v1000.json"

GUARD_DEEP_AUDIT_STATE_FILE = ".guard_deep_audit_state.json"

GUARD_DEEP_AUDIT_JSON = "clean_guard_deep_audit.json"

GUARD_DEEP_AUDIT_TEXT = "clean_guard_deep_audit.txt"

GUARD_EXPORT_LAST_RESULT_V1129 = "guard_profitability_export_last_result_v1129.json"

GUARD_EXPORT_LOCK_V1129 = ".guard_profitability_export_v1129.lock"

GUARD_EXPORT_TMP_PREFIX_V1129 = ".guard_profitability_export_v1129_"

GUARD_EXPORT_MAX_DOCUMENT_BYTES_V1129 = 49 * 1024 * 1024

S1_ZERO_AUDIT_STATUS_V1214 = "clean_s1_zero_root_audit_v1214.json"
STRUCTURE_MISSING_AUDIT_STATUS_V1216 = "clean_structure_missing_exact_audit_v1216.json"
ENTRY_GEOMETRY_AUDIT_STATUS_V1219 = "clean_entry_geometry_exact_audit_v1219.json"
ENTRY_FLOW_AUDIT_STATUS_V1221 = "clean_entry_flow_contract_audit_v1221.json"
STRUCTURE_PAIRING_AUDIT_STATUS_V1222 = "clean_structure_pairing_compare_audit_v1222.json"
PAIR_EXCLUSION_AUDIT_STATUS_V1232 = "clean_pair_exclusion_audit_v1232.json"
PAPER_ACTIVE_CONTRACT_V1221 = "paper_active_contract_snapshot_v1208.json"
S1_ZERO_AUDIT_GATE_STATUS_V1214 = "clean_strategy_swing_gate_status_v977.json"
S1_ZERO_AUDIT_CANDIDATES_V1214 = "paper_candidates_latest.jsonl"
S1_ZERO_AUDIT_WRITER_STATUS_V1214 = "clean_strategy_paper_latest_writer_status.json"

AUTO_RETENTION_STATE_V1196 = "clean_guard_auto_retention_v1196.json"
AUTO_RETENTION_CHECK_INTERVAL_SEC_V1196 = 15 * 60
AUTO_RETENTION_RUN_INTERVAL_SEC_V1196 = 6 * 3600
AUTO_RETENTION_LOW_FREE_RUN_INTERVAL_SEC_V1196 = 60 * 60
AUTO_RETENTION_LOW_FREE_BYTES_V1196 = 4 * 1024 * 1024 * 1024
AUTO_RETENTION_NOTIFY_FREED_BYTES_V1196 = 100 * 1024 * 1024
AUTO_RETENTION_SYSTEM_LOG_INTERVAL_SEC_V1228 = 24 * 3600
DISK_ALERT_STATE_V1228 = "clean_guard_disk_alert_v1228.json"
DISK_WARNING_FREE_BYTES_V1228 = 4 * 1024 * 1024 * 1024
DISK_DANGER_FREE_BYTES_V1228 = 2 * 1024 * 1024 * 1024
DISK_CRITICAL_FREE_BYTES_V1228 = 1 * 1024 * 1024 * 1024
DISK_ALERT_COOLDOWN_SEC_V1228 = {"WARNING": 6 * 3600, "DANGER": 2 * 3600, "CRITICAL": 3600}

PROFITABILITY_EXPORT_FILES_V1129 = (
    "paper_bot_closed.jsonl",
    "paper_bot_open.json",
    "paper_decision_state_v926.json",
    "canonical_performance_snapshot_v987.json",
    "paper_bot_trade_log.jsonl",
    "paper_trade_log.json",
    "paper_bot_trade_detail_v798.jsonl",
    "paper_bot_control.json",
    "paper_exit_replay_poll_v1242.jsonl",
    "paper_exit_replay_close_v1242.jsonl",
    "paper_exit_replay_status_v1242.json",
)

PROFITABILITY_EXPORT_SPECS_V1130 = (
    ("paper_bot_closed.jsonl", ("paper_bot_closed.jsonl",)),
    ("paper_bot_open.json", ("paper_bot_open.json",)),
    ("paper_decision_state_v926.json", ("paper_decision_state_v926.json",)),
    ("canonical_performance_snapshot_v987.json", ("canonical_performance_snapshot_v987.json",)),
    ("paper_bot_trade_log.jsonl", (
        "paper_bot_trade_log.jsonl",
        "paper_trade_log.json",
        "paper_bot_trade_detail_v798.jsonl",
    )),
    ("paper_bot_control.json", ("paper_bot_control.json",)),
    ("paper_exit_replay_poll_v1242.jsonl", ("paper_exit_replay_poll_v1242.jsonl",)),
    ("paper_exit_replay_close_v1242.jsonl", ("paper_exit_replay_close_v1242.jsonl",)),
    ("paper_exit_replay_status_v1242.json", ("paper_exit_replay_status_v1242.json",)),
)

def load_env(path: Path = ENV_PATH) -> dict:
    data = {}
    if path.exists():
        for raw in path.read_text(encoding="utf-8", errors="ignore").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            data[k.strip()] = v.strip().strip('"').strip("'")
    allowed = {
        "MAIN_SERVICE", "BOT_DIR", "PYTHON_BIN", "GUARD_POLL_SEC",
        "GIT_BRANCH", "GUARD_AUTO_ROLLBACK", "GUARD_RESTART_WAIT_SEC",
        "GUARD_BOT_TOKEN", "GUARD_CHAT_ID",
        "PAPER_SERVICE", "PAPER_ACTIVE_FILE", "PAPER_PID_FILE", "PAPER_BOT_TOKEN", "PAPER_PYTHON_BIN", "TELEGRAM_TOKEN",
        "GUARD_SERVICE", "GUARD_ACTIVE_FILE",
        "WS_ACTIVE_FILE", "WS_PID_FILE", "WS_LOG_FILE", "WS_STATUS_FILE", "WS_CACHE_FILE",
        "MICRO_ACTIVE_FILE", "MICRO_PID_FILE", "MICRO_LOG_FILE", "MICRO_STATUS_FILE", "MICRO_CACHE_FILE", "MICRO_PYTHON_BIN", "WS_SERVICE", "MICRO_SERVICE", "WORKER_PYTHON_BIN"
    }
    data.update({k: v for k, v in os.environ.items() if k.startswith("GUARD_") or k in allowed})
    return data

ENV = load_env()

TOKEN = ENV.get("GUARD_BOT_TOKEN", "")

ALLOWED_CHAT_ID = str(ENV.get("GUARD_CHAT_ID", "")).strip()

MAIN_SERVICE = ENV.get("MAIN_SERVICE", "tradingbot")

MAIN_ACTIVE_FILE = ENV.get("MAIN_ACTIVE_FILE", "bot.py")

BOT_DIR = Path(ENV.get("BOT_DIR", "/home/dangdang971216/trading_bot"))

PYTHON_BIN = ENV.get("PYTHON_BIN", "python3")

POLL_SEC = int(ENV.get("GUARD_POLL_SEC", "2") or "2")

GIT_BRANCH = ENV.get("GIT_BRANCH", "main")

AUTO_ROLLBACK = str(ENV.get("GUARD_AUTO_ROLLBACK", "1")).strip().lower() not in {"0", "false", "no", "off"}

RESTART_WAIT_SEC = int(ENV.get("GUARD_RESTART_WAIT_SEC", "18") or "18")

STATIC_ALIAS_CHECK_ENABLED = str(ENV.get("GUARD_STATIC_ALIAS_CHECK", "0")).strip().lower() in {"1", "true", "yes", "on"}

PAPER_SERVICE = ENV.get("PAPER_SERVICE", "tradingbot-paper")

PAPER_ACTIVE_FILE = ENV.get("PAPER_ACTIVE_FILE", "paper_bot.py")

PAPER_PID_FILE = ENV.get("PAPER_PID_FILE", "paper_bot.pid")

PAPER_PROCESS_LOG = ENV.get("PAPER_PROCESS_LOG", "paper_bot_process.log")

PAPER_PROCESS_ERR = ENV.get("PAPER_PROCESS_ERR", "paper_bot_process.err")

PAPER_PYTHON_BIN = ENV.get("PAPER_PYTHON_BIN", ENV.get("PYTHON_BIN", "/usr/bin/python3")).strip() or "/usr/bin/python3"

GUARD_SERVICE = ENV.get("GUARD_SERVICE", "tradingbot-guard")

GUARD_ACTIVE_FILE = ENV.get("GUARD_ACTIVE_FILE", "backga_guard_bot.py")

DEPLOY_TARGETS_FILE = "DEPLOY_TARGETS.json"

DEPLOYED_PAPER_FILE = ".deployed_paper_target"

DEPLOYED_GUARD_FILE = ".deployed_guard_target"

DEPLOYED_WS_FILE = ".deployed_ws_sidecar_target"

DEPLOYED_MICRO_FILE = ".deployed_micro_sidecar_target"

WS_ACTIVE_FILE = ENV.get("WS_ACTIVE_FILE", "ws_sidecar.py")

WS_PID_FILE = ENV.get("WS_PID_FILE", "clean_ws_sidecar.pid")

WS_LOG_FILE = ENV.get("WS_LOG_FILE", "clean_ws_sidecar.out")

WS_STATUS_FILE = ENV.get("WS_STATUS_FILE", "clean_ws_sidecar_status.json")

WS_CACHE_FILE = ENV.get("WS_CACHE_FILE", "clean_ws_live_cache.json")

WS_PYTHON_BIN = ENV.get("WS_PYTHON_BIN", "/usr/bin/python3").strip() or "/usr/bin/python3"

MICRO_ACTIVE_FILE = ENV.get("MICRO_ACTIVE_FILE", "bithumb_micro_sidecar.py")

MICRO_PID_FILE = ENV.get("MICRO_PID_FILE", "clean_bithumb_micro.pid")

MICRO_LOG_FILE = ENV.get("MICRO_LOG_FILE", "clean_bithumb_micro.log")

MICRO_STATUS_FILE = ENV.get("MICRO_STATUS_FILE", "clean_bithumb_micro_status.json")

MICRO_CACHE_FILE = ENV.get("MICRO_CACHE_FILE", "clean_bithumb_micro_cache.json")

MICRO_DESIRED_FILE = ENV.get("MICRO_DESIRED_FILE", ".micro_sidecar_enabled")

MICRO_PYTHON_BIN = ENV.get("MICRO_PYTHON_BIN", ENV.get("PYTHON_BIN", "/usr/bin/python3.10")).strip() or "/usr/bin/python3.10"

WS_SERVICE = ENV.get("WS_SERVICE", "tradingbot-ws-sidecar")

MICRO_SERVICE = ENV.get("MICRO_SERVICE", "tradingbot-micro-sidecar")

WORKER_PYTHON_BIN = ENV.get("WORKER_PYTHON_BIN", ENV.get("PYTHON_BIN", "/usr/bin/python3")).strip() or "/usr/bin/python3"

if not WORKER_PYTHON_BIN.startswith("/"):
    WORKER_PYTHON_BIN = shutil.which(WORKER_PYTHON_BIN) or "/usr/bin/python3"

RETIRED_SERVICES_V1257 = ['tradingbot-policy-competition-worker','tradingbot-structure-rebuild-worker']

WORKER_SPECS = {
    "scanner": {"label": "스캐너", "prefix": "scanner_worker", "active": "scanner_worker.py", "service": "tradingbot-scanner-worker", "status": "clean_scanner_status.json", "log": "clean_scanner_worker_service.log"},
    "candle": {"label": "캔들", "prefix": "candle_worker", "active": "candle_worker.py", "service": "tradingbot-candle-worker", "status": "clean_candle_status.json", "log": "clean_candle_worker_service.log", "fresh_limit": 120, "ready_timeout": 45},
    "market": {"label": "장세", "prefix": "market_regime_worker", "active": "market_regime_worker.py", "service": "tradingbot-market-regime-worker", "status": "clean_market_regime_status.json", "log": "clean_market_regime_worker_service.log"},
    "feature": {"label": "특징", "prefix": "feature_worker", "active": "feature_worker.py", "service": "tradingbot-feature-worker", "status": "clean_feature_status.json", "log": "clean_feature_worker_service.log"},
    "orderflow": {"label": "호가요약", "prefix": "orderflow_worker", "active": "orderflow_worker.py", "service": "tradingbot-orderflow-worker", "status": "clean_orderflow_status.json", "log": "clean_orderflow_worker_service.log"},
    "risk": {"label": "위험", "prefix": "risk_worker", "active": "risk_worker.py", "service": "tradingbot-risk-worker", "status": "clean_risk_status.json", "log": "clean_risk_worker_service.log", "fresh_limit": 180, "ready_timeout": 30},
    "strategy": {"label": "전략판정", "prefix": "strategy_worker", "active": "strategy_worker.py", "service": "tradingbot-strategy-worker", "status": "clean_strategy_worker_status.json", "log": "clean_strategy_worker_service.log", "ready_timeout": 30},
    "target_router": {"label": "정보배차", "prefix": "target_router_worker", "active": "target_router_worker.py", "service": "tradingbot-target-router-worker", "status": "clean_target_router_status.json", "log": "clean_target_router_worker_service.log", "ready_timeout": 20},
    "review": {"label": "복기", "prefix": "review_worker", "active": "review_worker.py", "service": "tradingbot-review-worker", "status": "clean_review_worker_status.json", "log": "clean_review_worker_service.log", "fresh_limit": 240, "ready_timeout": 90},
    "exact_replay": {"label": "정확청산복기", "prefix": "exact_replay_worker", "active": "exact_replay_worker.py", "service": "tradingbot-exact-replay-worker", "status": "clean_exact_replay_worker_status.json", "log": "clean_exact_replay_worker_service.log", "fresh_limit": 180, "ready_timeout": 90},
}

@dataclass(frozen=True, order=True)
class BotVersion:
    major: int
    minor: int
    patch: int

    @classmethod
    def parse(cls, text: str) -> Optional["BotVersion"]:
        m = re.search(r"v(\d+)[._](\d+)[._](\d+)", text or "")
        if not m:
            return None
        return cls(int(m.group(1)), int(m.group(2)), int(m.group(3)))

    def __str__(self) -> str:
        return f"v{self.major}.{self.minor}.{self.patch}"

@dataclass(frozen=True, order=True)
class PaperVersion:
    major: int
    minor: int

    @classmethod
    def parse(cls, text: str) -> Optional["PaperVersion"]:
        m = re.search(r"paper_bot_v(\d+)\.(\d+)", text or "")
        if not m:
            return None
        return cls(int(m.group(1)), int(m.group(2)))

    def __str__(self) -> str:
        return f"paper_bot_v{self.major}.{self.minor}"

def paper_version_from_filename(path: Path) -> Optional[PaperVersion]:
    return PaperVersion.parse(path.name)

def now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def perf_now() -> float:
    return time.perf_counter()

def fmt_sec(sec: float) -> str:
    try:
        return f"{sec:.1f}s"
    except Exception:
        return "?s"

def systemctl_value(prop: str, service: str = None) -> str:
    service = service or MAIN_SERVICE
    rc, out = run(["systemctl", "show", "-p", prop, "--value", service], timeout=8)
    return (out or "").strip() if rc == 0 else ""

def service_start_since() -> Optional[str]:
    # journalctl --since accepts systemd timestamp strings. This reduces old-log version false positives.
    val = systemctl_value("ExecMainStartTimestamp") or systemctl_value("ActiveEnterTimestamp")
    return val or None

def autodeploy_status() -> dict:
    names = ["tradingbot-autodeploy.timer", "tradingbot-autodeploy.service"]
    rows = []
    problem = False
    for name in names:
        rc_a, active = run(["systemctl", "is-active", name], timeout=5)
        rc_e, enabled = run(["systemctl", "is-enabled", name], timeout=5)
        active = (active or "unknown").strip()
        enabled = (enabled or "unknown").strip()
        rows.append(f"{name}: active={active}, enabled={enabled}")
        if active in {"active", "activating"} or enabled in {"enabled", "static"}:
            problem = True
    rc, timers = run(["systemctl", "list-timers", "--all"], timeout=8)
    if "tradingbot-autodeploy" in (timers or ""):
        problem = True
        rows.append("list-timers: tradingbot-autodeploy 표시됨")
    return {"problem": problem, "text": "\n".join(rows)}

def run(cmd: list[str], cwd: Optional[Path] = None, timeout: int = 20):
    try:
        p = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
        )
        return p.returncode, (p.stdout or "").strip()
    except subprocess.TimeoutExpired as e:
        out = e.stdout or ""
        return 124, f"TIMEOUT after {timeout}s\n{out}".strip()
    except Exception as e:
        return 1, f"{type(e).__name__}: {e}"

def api(method: str, params: dict, timeout: int = 20):
    url = f"https://api.telegram.org/bot{TOKEN}/{method}"
    data = urllib.parse.urlencode(params).encode()
    req = urllib.request.Request(url, data=data)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="ignore"))

def send(chat_id, text: str) -> bool:
    text = str(text or "(empty)")
    chunks = []
    while len(text) > 3600:
        chunks.append(text[:3600]); text = text[3600:]
    chunks.append(text)
    all_ok = True
    for chunk in chunks:
        delivered = False
        for attempt in range(3):
            try:
                resp = api("sendMessage", {"chat_id": chat_id, "text": chunk, "disable_web_page_preview": "true"}, timeout=12)
                delivered = bool(isinstance(resp, dict) and resp.get("ok", True))
                if delivered: break
            except Exception as e:
                print(f"send failed attempt={attempt+1}: {e}", file=sys.stderr, flush=True)
            time.sleep(1.0 + attempt)
        all_ok = all_ok and delivered
    return all_ok

def tail(text: str, n: int = 3500) -> str:
    text = text or ""
    return text if len(text) <= n else "...\n" + text[-n:]

def read_file(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8", errors="ignore").strip()
    except Exception:
        return ""

def read_file_tail(path: Path, max_bytes: int = 120_000) -> str:
    """큰 로그파일을 통째로 읽지 않고 끝부분만 읽는다.
    v2.5.5: /gpaperlog 무반응 방지용.
    """
    try:
        if not path.exists():
            return ""
        size = path.stat().st_size
        with path.open("rb") as f:
            if size > max_bytes:
                f.seek(max(0, size - max_bytes))
            raw = f.read(max_bytes)
        return raw.decode("utf-8", errors="ignore").strip()
    except Exception as e:
        return f"read_tail_failed {path.name}: {type(e).__name__}: {e}"

def write_json(path: Path, data: dict):
    """Process-safe atomic JSON writer.

    Guard self-restarts can briefly overlap old/new processes. A fixed .tmp name lets
    those processes steal each other's temporary file, so every write uses a unique
    pid+time_ns temporary and fsync before replace.
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp.{os.getpid()}.{time.time_ns()}")
    payload = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    try:
        with tmp.open("w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
        try:
            dfd = os.open(str(path.parent), os.O_RDONLY)
            try:
                os.fsync(dfd)
            finally:
                os.close(dfd)
        except Exception:
            pass
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass

def read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        return {}

def _fmt_bytes(n) -> str:
    try:
        n = float(n)
    except Exception:
        return "-"
    units = ["B", "KB", "MB", "GB", "TB"]
    i = 0
    while n >= 1024 and i < len(units) - 1:
        n /= 1024.0
        i += 1
    return f"{n:.1f}{units[i]}" if i >= 2 else f"{n:.0f}{units[i]}"

def _read_meminfo() -> dict:
    out = {}
    try:
        for line in Path("/proc/meminfo").read_text(encoding="utf-8", errors="ignore").splitlines():
            if ":" not in line:
                continue
            k, v = line.split(":", 1)
            parts = v.strip().split()
            if parts:
                out[k] = float(parts[0]) * 1024.0
    except Exception:
        pass
    return out

def _proc_rss_bytes(pid) -> float:
    try:
        pid = int(pid)
        if pid <= 0:
            return 0.0
        for line in Path(f"/proc/{pid}/status").read_text(encoding="utf-8", errors="ignore").splitlines():
            if line.startswith("VmRSS:"):
                return float(line.split()[1]) * 1024.0
    except Exception:
        pass
    return 0.0

def server_resource_snapshot() -> dict:
    try:
        du = shutil.disk_usage(str(BOT_DIR))
        disk_total, disk_used, disk_free = float(du.total), float(du.used), float(du.free)
        disk_pct = (disk_used / disk_total * 100.0) if disk_total > 0 else 0.0
    except Exception:
        disk_total = disk_used = disk_free = disk_pct = 0.0
    mem = _read_meminfo()
    mem_total = mem.get("MemTotal", 0.0)
    mem_avail = mem.get("MemAvailable", 0.0)
    mem_used = max(0.0, mem_total - mem_avail) if mem_total else 0.0
    mem_pct = (mem_used / mem_total * 100.0) if mem_total else 0.0
    try:
        load1, load5, load15 = os.getloadavg()
    except Exception:
        load1 = load5 = load15 = 0.0
    pids = {"main": _service_main_pid(MAIN_SERVICE), "paper": _service_main_pid(PAPER_SERVICE), "guard": _service_main_pid(GUARD_SERVICE)}
    rss = {k: _proc_rss_bytes(v) for k, v in pids.items()}
    return {"disk_total": disk_total, "disk_used": disk_used, "disk_free": disk_free, "disk_pct": disk_pct, "mem_total": mem_total, "mem_used": mem_used, "mem_avail": mem_avail, "mem_pct": mem_pct, "load1": load1, "load5": load5, "load15": load15, "pids": pids, "rss": rss}

def _guard_cpu_counters_v1010() -> tuple[int, int, int]:
    """Return total, idle and iowait jiffies from the aggregate /proc/stat row."""
    try:
        first=Path('/proc/stat').read_text(encoding='utf-8',errors='ignore').splitlines()[0].split()
        values=[int(x) for x in first[1:]]
        total=sum(values)
        idle=(values[3] if len(values)>3 else 0)+(values[4] if len(values)>4 else 0)
        iowait=values[4] if len(values)>4 else 0
        return total,idle,iowait
    except Exception:
        return 0,0,0

def _guard_cpu_percent_v1010() -> dict:
    global _GUARD_CPU_SAMPLE_V1010
    now_mono=time.monotonic(); total,idle,iowait=_guard_cpu_counters_v1010()
    previous=_GUARD_CPU_SAMPLE_V1010
    _GUARD_CPU_SAMPLE_V1010=(now_mono,total,idle,iowait)
    if not previous or total<=previous[1]:
        return {'cpu_pct':None,'iowait_pct':None,'sample_sec':0.0}
    dt=total-previous[1]; didle=idle-previous[2]; diowait=iowait-previous[3]
    return {
        'cpu_pct':round(max(0.0,min(100.0,(dt-didle)/dt*100.0)),2) if dt else None,
        'iowait_pct':round(max(0.0,min(100.0,diowait/dt*100.0)),2) if dt else None,
        'sample_sec':round(max(0.0,now_mono-previous[0]),3),
    }

def _guard_pid_io_counters_v1011(pid: int) -> dict:
    out={'read_bytes':0,'write_bytes':0,'rchar':0,'wchar':0}
    if int(pid or 0)<=0: return out
    try:
        for line in Path(f'/proc/{int(pid)}/io').read_text(encoding='utf-8',errors='ignore').splitlines():
            if ':' not in line: continue
            key,value=line.split(':',1)
            normalized='rchar' if key=='char' else key
            if normalized in out: out[normalized]=int(value.strip() or 0)
    except Exception:
        pass
    return out

def _guard_component_io_rate_v1011(component: str, pids: list[int], now_mono: float) -> dict:
    global _GUARD_PROC_IO_SAMPLE_V1011
    totals={'read_bytes':0,'write_bytes':0,'rchar':0,'wchar':0}
    for pid in sorted(set(int(x) for x in pids if int(x or 0)>0)):
        row=_guard_pid_io_counters_v1011(pid)
        for key in totals: totals[key]+=int(row.get(key) or 0)
    previous=_GUARD_PROC_IO_SAMPLE_V1011.get(component)
    _GUARD_PROC_IO_SAMPLE_V1011[component]=(now_mono,tuple(sorted(set(int(x) for x in pids if int(x or 0)>0))),totals)
    result={
        'io_read_total_mb':round(totals['read_bytes']/1048576.0,2),
        'io_write_total_mb':round(totals['write_bytes']/1048576.0,2),
        'io_logical_read_total_mb':round(totals['rchar']/1048576.0,2),
        'io_logical_write_total_mb':round(totals['wchar']/1048576.0,2),
        'io_read_mb_s':None,'io_write_mb_s':None,'io_logical_read_mb_s':None,'io_logical_write_mb_s':None,'io_sample_sec':0.0,
    }
    if not previous or previous[1]!=tuple(sorted(set(int(x) for x in pids if int(x or 0)>0))):
        return result
    elapsed=max(0.0,now_mono-float(previous[0]))
    if elapsed<=0: return result
    old=previous[2] if isinstance(previous[2],dict) else {}
    result.update({
        'io_read_mb_s':round(max(0,int(totals['read_bytes'])-int(old.get('read_bytes',0)))/1048576.0/elapsed,3),
        'io_write_mb_s':round(max(0,int(totals['write_bytes'])-int(old.get('write_bytes',0)))/1048576.0/elapsed,3),
        'io_logical_read_mb_s':round(max(0,int(totals['rchar'])-int(old.get('rchar',0)))/1048576.0/elapsed,3),
        'io_logical_write_mb_s':round(max(0,int(totals['wchar'])-int(old.get('wchar',0)))/1048576.0/elapsed,3),
        'io_sample_sec':round(elapsed,3),
    })
    return result

def _guard_diskstats_counters_v1011() -> dict:
    totals={'read_sectors':0,'write_sectors':0,'io_ms':0,'devices':[]}
    try:
        for line in Path('/proc/diskstats').read_text(encoding='utf-8',errors='ignore').splitlines():
            parts=line.split()
            if len(parts)<14: continue
            name=parts[2]
            if not re.fullmatch(r'(?:sd[a-z]+|vd[a-z]+|xvd[a-z]+|nvme\d+n\d+|mmcblk\d+)',name):
                continue
            totals['read_sectors']+=int(parts[5]); totals['write_sectors']+=int(parts[9]); totals['io_ms']+=int(parts[12]); totals['devices'].append(name)
    except Exception:
        pass
    return totals

def _guard_disk_io_rate_v1011(now_mono: float) -> dict:
    global _GUARD_DISK_IO_SAMPLE_V1011
    current=_guard_diskstats_counters_v1011(); previous=_GUARD_DISK_IO_SAMPLE_V1011
    _GUARD_DISK_IO_SAMPLE_V1011=(now_mono,current)
    result={'disk_read_mb_s':None,'disk_write_mb_s':None,'disk_busy_pct':None,'disk_io_sample_sec':0.0,'disk_devices':current.get('devices',[])}
    if not previous: return result
    elapsed=max(0.0,now_mono-float(previous[0]))
    if elapsed<=0: return result
    old=previous[1] if isinstance(previous[1],dict) else {}
    result.update({
        'disk_read_mb_s':round(max(0,int(current.get('read_sectors',0))-int(old.get('read_sectors',0)))*512/1048576.0/elapsed,3),
        'disk_write_mb_s':round(max(0,int(current.get('write_sectors',0))-int(old.get('write_sectors',0)))*512/1048576.0/elapsed,3),
        'disk_busy_pct':round(max(0.0,min(100.0,(int(current.get('io_ms',0))-int(old.get('io_ms',0)))/(elapsed*1000.0)*100.0)),2),
        'disk_io_sample_sec':round(elapsed,3),
    })
    return result

def _guard_service_show_batch_v1010(services: dict[str,str]) -> dict[str,dict]:
    unique=[]
    for svc in services.values():
        if svc and svc not in unique: unique.append(svc)
    if not unique: return {}
    props='Id,LoadState,ActiveState,SubState,MainPID,NRestarts,MemoryCurrent,TasksCurrent,CPUUsageNSec,ExecMainStartTimestamp,FragmentPath'
    rc,out=run(['systemctl','show',*unique,'--no-pager',f'--property={props}'],timeout=12)
    if rc!=0: return {}
    blocks=[]; current={}
    for line in (out or '').splitlines()+['']:
        if not line.strip():
            if current: blocks.append(current); current={}
            continue
        if '=' in line:
            k,v=line.split('=',1); current[k.strip()]=v.strip()
    by_unit={str(row.get('Id') or ''):row for row in blocks if row.get('Id')}
    result={}
    for comp,svc in services.items():
        row=by_unit.get(svc) or by_unit.get(svc+'.service') or {}
        result[comp]=row
    return result

def _guard_status_path_v1010(component: str) -> Path|None:
    fixed={
        'main':BOT_DIR/'clean_brain_status.json',
        'paper':BOT_DIR/'paper_bot_status.json',
        'ws':BOT_DIR/WS_STATUS_FILE,
        'micro':BOT_DIR/MICRO_STATUS_FILE,
    }
    if component in fixed: return fixed[component]
    spec=WORKER_SPECS.get(component)
    return BOT_DIR/str(spec.get('status')) if spec else None

def _guard_file_age_v1010(path: Path|None, nowv: float) -> float|None:
    try: return round(max(0.0,nowv-path.stat().st_mtime),3) if path and path.exists() else None
    except Exception: return None

def _guard_active_alias_v1010(component: str) -> Path|None:
    fixed={
        'main':BOT_DIR/MAIN_ACTIVE_FILE,
        'paper':BOT_DIR/PAPER_ACTIVE_FILE,
        'guard':BOT_DIR/GUARD_ACTIVE_FILE,
        'ws':BOT_DIR/WS_ACTIVE_FILE,
        'micro':BOT_DIR/MICRO_ACTIVE_FILE,
    }
    if component in fixed: return fixed[component]
    spec=WORKER_SPECS.get(component)
    return BOT_DIR/str(spec.get('active')) if spec else None

def _guard_file_hash_v1010(path: Path|None) -> str:
    try: return hashlib.sha256(path.read_bytes()).hexdigest() if path and path.exists() else ''
    except Exception: return ''

def _guard_source_info_v1010(args: str) -> dict:
    tokens=[tok.strip('\"\'') for tok in str(args or '').split()]
    py=next((tok for tok in tokens if tok.endswith('.py')), '')
    if not py: return {'source':'','source_hash':''}
    path=Path(py)
    if not path.is_absolute(): path=BOT_DIR/path
    digest=''
    try:
        if path.exists(): digest=hashlib.sha256(path.read_bytes()).hexdigest()
    except Exception: pass
    return {'source':str(path),'source_hash':digest}

def guard_runtime_snapshot_v1010(write_reason: str = "periodic") -> dict:
    """Single runtime owner for process/service/server facts used by main read-only boards."""
    nowv=time.time(); now_mono=time.monotonic(); resources=server_resource_snapshot(); cpu=_guard_cpu_percent_v1010(); disk_io=_guard_disk_io_rate_v1011(now_mono)
    mem=_read_meminfo(); swap_total=float(mem.get('SwapTotal',0.0)); swap_free=float(mem.get('SwapFree',0.0))
    services={'main':MAIN_SERVICE,'paper':PAPER_SERVICE,'guard':GUARD_SERVICE,'ws':WS_SERVICE,'micro':MICRO_SERVICE}
    services.update({name:str(spec.get('service') or '') for name,spec in WORKER_SPECS.items()})
    service_rows=_guard_service_show_batch_v1010(services)
    proc_rows=_audit_proc_rows(); proc_by={}
    for row in proc_rows: proc_by.setdefault(str(row.get('component') or ''),[]).append(row)
    components={}
    for component,service in services.items():
        props=service_rows.get(component) or {}; prows=proc_by.get(component,[])
        main_pid=_audit_int(props.get('MainPID'),0)
        main_proc=next((r for r in prows if int(r.get('pid') or 0)==main_pid),prows[0] if prows else {})
        status_path=_guard_status_path_v1010(component); raw=read_json(status_path) if status_path else {}
        status_age=_guard_file_age_v1010(status_path,nowv)
        active=str(props.get('ActiveState') or 'unknown'); sub=str(props.get('SubState') or 'unknown')
        process_count=len(prows); runtime_state='OK' if active=='active' and main_pid>0 and process_count>=1 else ('CHECK' if active in ('activating','reloading','unknown') else 'FAIL')
        source=_guard_source_info_v1010(str(main_proc.get('args') or ''))
        alias_path=_guard_active_alias_v1010(component); alias_hash=_guard_file_hash_v1010(alias_path)
        source_hash=str(source.get('source_hash') or '')
        alias_match=(alias_hash==source_hash) if alias_hash and source_hash else None
        component_io=_guard_component_io_rate_v1011(component,[int(r.get('pid') or 0) for r in prows],now_mono)
        components[component]={
            'service':service,'active_state':active,'sub_state':sub,'runtime_state':runtime_state,
            'main_pid':main_pid,'restart_count':_audit_int(props.get('NRestarts'),0),
            'process_count':process_count,'pids':[int(r.get('pid') or 0) for r in prows],
            'cpu_pct':round(sum(float(r.get('cpu_pct') or 0.0) for r in prows),2),
            'rss_mb':round(sum(int(r.get('rss_bytes') or 0) for r in prows)/1024/1024,2),
            'threads':sum(int(r.get('threads') or 0) for r in prows),
            'status_file':status_path.name if status_path else None,'status_age_sec':status_age,
            'status_state':raw.get('state') if isinstance(raw,dict) else None,'status_version':raw.get('version') if isinstance(raw,dict) else None,
            'status_pid':_audit_int(raw.get('pid'),0) if isinstance(raw,dict) else 0,
            'cmdline':str(main_proc.get('args') or '')[:500],**source,
            'active_alias':str(alias_path) if alias_path else '',
            'active_alias_hash':alias_hash,
            'source_alias_hash_match':alias_match,
            **component_io,
        }
    try: uptime=float(Path('/proc/uptime').read_text().split()[0])
    except Exception: uptime=0.0
    io_rank=[]
    for component,row in components.items():
        logical=float(row.get('io_logical_read_mb_s') or 0.0)+float(row.get('io_logical_write_mb_s') or 0.0)
        physical=float(row.get('io_read_mb_s') or 0.0)+float(row.get('io_write_mb_s') or 0.0)
        io_rank.append({'component':component,'logical_mb_s':round(logical,3),'physical_mb_s':round(physical,3),'read_mb_s':row.get('io_read_mb_s'),'write_mb_s':row.get('io_write_mb_s')})
    io_rank.sort(key=lambda item:(item['physical_mb_s'],item['logical_mb_s']),reverse=True)
    global _GUARD_RUNTIME_WRITE_SEQUENCE_V1033
    _GUARD_RUNTIME_WRITE_SEQUENCE_V1033 += 1
    return {
        'schema':'guard_runtime_status_v1011_io_owner','version':VERSION,'owner':'guard_single_runtime_status_writer',
        'generated_at':nowv,'generated_at_text':now(),'guard_pid':os.getpid(),
        'write_reason_v1033':str(write_reason or 'periodic'),
        'write_sequence_v1033':int(_GUARD_RUNTIME_WRITE_SEQUENCE_V1033),
        'release_refresh_owner_v1033':'same guard MainPID before post-upgrade command continuation',
        'server':{
            'cpu_pct':cpu.get('cpu_pct'),'iowait_pct':cpu.get('iowait_pct'),'cpu_sample_sec':cpu.get('sample_sec'),
            'load1':round(float(resources.get('load1') or 0.0),2),'load5':round(float(resources.get('load5') or 0.0),2),'load15':round(float(resources.get('load15') or 0.0),2),
            'cpu_count':os.cpu_count() or 0,'mem_total_mb':round(float(resources.get('mem_total') or 0.0)/1024/1024,2),
            'mem_available_mb':round(float(resources.get('mem_avail') or 0.0)/1024/1024,2),'mem_used_pct':round(float(resources.get('mem_pct') or 0.0),2),
            'swap_total_mb':round(swap_total/1024/1024,2),'swap_used_mb':round(max(0.0,swap_total-swap_free)/1024/1024,2),
            'disk_total_gb':round(float(resources.get('disk_total') or 0.0)/1024**3,2),'disk_free_gb':round(float(resources.get('disk_free') or 0.0)/1024**3,2),'disk_used_pct':round(float(resources.get('disk_pct') or 0.0),2),
            'uptime_sec':round(uptime,1),
            **disk_io,
        },
        'components':components,
        'io_top_components_v1011':io_rank[:8],
        'resource_contract_v1074':{
            'schema':'guard_resource_owner_v1074',
            'canonical_owner':'guard_single_runtime_status_writer',
            'pid_owner':'systemd MainPID',
            'process_cpu_rss_owner':'guard /proc + ps snapshot',
            'component_status_rss_role':'diagnostic_self_sample_only',
            'missing_component_status_rss':'CHECK_not_zero',
            'same_source_for_main_guard_boards':True,
        },
        'invariants':{'single_writer':True,'main_reader_read_only':True,'missing_is_not_zero':True,'pid_owner':'systemd MainPID','process_metrics_owner':'guard ps snapshot','io_owner':'guard /proc/<pid>/io and /proc/diskstats interval delta','resource_owner_v1074':'guard canonical process snapshot'},
    }

def write_guard_runtime_snapshot_v1010(write_reason: str = 'periodic') -> dict:
    snapshot=guard_runtime_snapshot_v1010(write_reason=write_reason)
    write_json(BOT_DIR/GUARD_RUNTIME_STATUS_FILE,snapshot)
    return snapshot

def refresh_guard_runtime_before_followup_v1033(reason: str) -> str:
    """Refresh the existing canonical snapshot from the same guard MainPID.

    Telegram long-poll and bundle application can delay the periodic writer.  The
    release continuation therefore refreshes the same canonical file once before
    executing validation commands.  No second process or second writer exists.
    """
    try:
        snap = write_guard_runtime_snapshot_v1010(write_reason=f'pre_followup:{reason}')
        return f"runtime snapshot refreshed seq={snap.get('write_sequence_v1033')} reason={snap.get('write_reason_v1033')}"
    except Exception as exc:
        return f"runtime snapshot refresh failed {exc.__class__.__name__}: {exc}"

def resource_status_lines(prefix: str = "") -> list[str]:
    r = server_resource_snapshot()
    disk_icon = "✅" if r["disk_pct"] < 85 else ("⚠️" if r["disk_pct"] < 95 else "❌")
    mem_icon = "✅" if r["mem_pct"] < 80 else ("⚠️" if r["mem_pct"] < 92 else "❌")
    load_icon = "✅" if float(r.get("load1", 0.0)) < 1.5 else ("⚠️" if float(r.get("load1", 0.0)) < 3.0 else "❌")
    rss = r.get("rss", {}) or {}
    return [
        f"{disk_icon} 디스크: 사용 {r['disk_pct']:.1f}% / 남음 {_fmt_bytes(r['disk_free'])} / 전체 {_fmt_bytes(r['disk_total'])}",
        f"{mem_icon} 메모리: 사용 {r['mem_pct']:.1f}% / 남음 {_fmt_bytes(r['mem_avail'])} / 전체 {_fmt_bytes(r['mem_total'])}",
        f"{load_icon} CPU/load: {r['load1']:.2f} / {r['load5']:.2f} / {r['load15']:.2f}",
        f"- RSS: main {_fmt_bytes(rss.get('main',0))} / paper {_fmt_bytes(rss.get('paper',0))} / guard {_fmt_bytes(rss.get('guard',0))}",
    ]

def _safe_unlink(path: Path) -> tuple[bool, int, str]:
    try:
        size = path.stat().st_size if path.exists() else 0
        path.unlink(missing_ok=True)
        return True, size, path.name
    except Exception as e:
        return False, 0, f"{path.name}: {type(e).__name__}"

RETIRED_LIVE_CACHE_FILES_V942 = (
    'clean_candidate_reason_compact_cache.json',
    'clean_recheck_candidates_state.json',
    'clean_recheck_candidates_cache.json',
    'clean_s1_lifecycle_state.json',
    'clean_s1_lifecycle_trace.json',
)

def cleanup_retired_live_cache_files_v942(dry_run: bool = False) -> dict:
    """Delete only the five noncore files whose active strategy/candle paths were removed in v942."""
    result = {'checked':0,'deleted':0,'freed':0,'errors':0,'samples':[]}
    for name in RETIRED_LIVE_CACHE_FILES_V942:
        path = BOT_DIR / name
        if not path.exists() or not path.is_file():
            continue
        result['checked'] += 1
        try:
            size = path.stat().st_size
            if dry_run:
                result['deleted'] += 1; result['freed'] += size
                result['samples'].append(f'retired live 삭제예정 {name} {_fmt_bytes(size)}')
            else:
                ok, got, msg = _safe_unlink(path)
                if ok:
                    result['deleted'] += 1; result['freed'] += got
                    result['samples'].append(f'retired live 삭제 {msg} {_fmt_bytes(got)}')
                else:
                    result['errors'] += 1; result['samples'].append(msg)
        except Exception as exc:
            result['errors'] += 1; result['samples'].append(f'{name}: {type(exc).__name__}')
    return result

LEGACY_NONCORE_CACHE_SOURCES = (
    'clean_candidate_reason_compact_cache.json',
    'clean_recheck_candidates_state.json',
    'clean_recheck_candidates_cache.json',
    'clean_s1_lifecycle_state.json',
    'clean_s1_lifecycle_trace.json',
    'paper_bot_hourly_event_trace.jsonl',
)

def cleanup_redundant_legacy_cache_archives(dry_run: bool = False) -> dict:
    """Remove repeated snapshots created by retired one-time cache migrations.

    These files are cache/state/history snapshots, not OPEN/CLOSED/trade/score ledgers.
    Across both legacy roots, keep at most one newest compressed copy per source.
    Stale uncompressed/tmp leftovers are removed only when the current live source exists.
    """
    nowv = time.time()
    result = {'checked':0, 'deleted':0, 'freed':0, 'errors':0, 'samples':[], 'kept':{}}
    roots = [BOT_DIR / 'legacy_v839_archive', BOT_DIR / 'legacy_v840_archive']
    grouped = {name: [] for name in LEGACY_NONCORE_CACHE_SOURCES}
    for root in roots:
        if not root.exists() or not root.is_dir():
            continue
        for path in root.rglob('*'):
            if not path.is_file():
                continue
            name = path.name
            source = next((x for x in LEGACY_NONCORE_CACHE_SOURCES if name.startswith(x + '.')), None)
            if source is None:
                continue
            result['checked'] += 1
            grouped[source].append(path)
    for source, files in grouped.items():
        if not files:
            continue
        files.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0.0, reverse=True)
        compressed = [p for p in files if p.name.endswith(('.gz','.gzip')) and not p.name.endswith('.tmp')]
        keep = compressed[:1] if compressed else files[:1]
        result['kept'][source] = [str(p.relative_to(BOT_DIR)) for p in keep]
        live_exists = (BOT_DIR / source).exists()
        for path in files:
            if path in keep:
                continue
            try:
                age = max(0.0, nowv - path.stat().st_mtime)
                is_tmp = path.name.endswith(('.tmp','.part'))
                is_uncompressed = '.legacy' in path.name and not path.name.endswith(('.gz','.gzip'))
                if (is_tmp or is_uncompressed) and (age < 600.0 or not live_exists):
                    continue
                size = path.stat().st_size
                if dry_run:
                    result['samples'].append(f'중복 legacy 삭제예정 {path.name} {_fmt_bytes(size)}')
                    result['deleted'] += 1; result['freed'] += size
                    continue
                ok, got, label = _safe_unlink(path)
                if ok:
                    result['deleted'] += 1; result['freed'] += got
                    result['samples'].append(f'중복 legacy 삭제 {label} {_fmt_bytes(got)}')
                else:
                    result['errors'] += 1; result['samples'].append(label)
            except Exception as exc:
                result['errors'] += 1
                result['samples'].append(f'{path.name}: {type(exc).__name__}')
    return result

def cleanup_v1007_noncore_growth(dry_run: bool = False) -> dict:
    """Only noncore cache/archive cleanup. Never touches OPEN/CLOSED/trade/decision/exact ledgers."""
    result={'deleted':0,'freed':0,'errors':0,'samples':[]}
    def remove(path: Path, label: str) -> None:
        if not path.exists() or not path.is_file(): return
        try:
            size=path.stat().st_size
            if dry_run:
                result['deleted']+=1; result['freed']+=size; result['samples'].append(f'{label} 삭제예정 {path.name} {_fmt_bytes(size)}')
            else:
                ok,got,msg=_safe_unlink(path)
                if ok: result['deleted']+=1; result['freed']+=got; result['samples'].append(f'{label} 삭제 {msg} {_fmt_bytes(got)}')
                else: result['errors']+=1; result['samples'].append(msg)
        except Exception as exc:
            result['errors']+=1; result['samples'].append(f'{path.name}: {type(exc).__name__}')
    # Superseded review states are safe only when current compact v956/v1007 owners exist.
    current_ok=(BOT_DIR/'clean_structure_lab_active_state_v956.json').exists() and (BOT_DIR/'clean_structure_lab_review_status_v956.json').exists()
    if current_ok:
        for name in ('clean_structure_lab_state_v950.json','clean_structure_lab_state_v951.json','clean_structure_lab_state_v952.json','clean_structure_lab_state_v955.json','clean_structure_missed_state_v952.json','clean_structure_missed_state_v955.json'):
            remove(BOT_DIR/name,'retired review state')
    # Review-owned archives: 2-day retention, newest 20 always preserved.
    for root in (BOT_DIR/'quality_shadow_archive', BOT_DIR/'archive', BOT_DIR/'legacy_v839_archive', BOT_DIR/'legacy_v840_archive'):
        if not root.exists() or not root.is_dir(): continue
        try:
            files=[p for p in root.rglob('*') if p.is_file()]
            files.sort(key=lambda p:p.stat().st_mtime if p.exists() else 0, reverse=True)
            for idx,path in enumerate(files):
                age=max(0.0,(time.time()-path.stat().st_mtime)/86400.0)
                low=path.name.lower()
                noncore=low.endswith(('.gz','.old','.tmp','.part')) or 'guard_removed' in low or 'legacy' in low or 'backup' in low
                if not noncore: continue
                if idx < 20: continue
                if age > 2.0 or idx >= 1000:
                    remove(path,'archive retention')
        except Exception as exc:
            result['errors']+=1; result['samples'].append(f'{root.name}: {type(exc).__name__}')
    return result

def _tree_size_no_follow_v1196(path: Path) -> int:
    total = 0
    try:
        if path.is_symlink():
            return int(path.lstat().st_size)
        for root, dirs, files in os.walk(path, topdown=True, followlinks=False):
            # Never descend through symlinks.
            dirs[:] = [d for d in dirs if not (Path(root) / d).is_symlink()]
            for name in files:
                item = Path(root) / name
                try:
                    total += int(item.lstat().st_size)
                except Exception:
                    continue
    except Exception:
        return 0
    return total


def cleanup_stale_workdirs_v1196(dry_run: bool = False) -> dict:
    """Remove only abandoned implementation workdirs, never live ledgers.

    Prefix + minimum age is the contract. The current bundle/continuation path
    cannot reach the age threshold while it is active, and Guard executes these
    operations in one process rather than concurrently with bundle apply.
    """
    specs = (
        (".bundle_unpack_", 30 * 60),
        (".bundle_continue_once_", 2 * 3600),
        (GUARD_EXPORT_TMP_PREFIX_V1129, 6 * 3600),
        (".paper_runtime_reset_", 2 * 86400),
    )
    result = {"checked": 0, "deleted": 0, "freed": 0, "errors": 0, "samples": []}
    nowv = time.time()
    try:
        children = list(BOT_DIR.iterdir())
    except Exception as exc:
        result["errors"] += 1
        result["samples"].append(f"iterdir:{type(exc).__name__}")
        return result
    for path in children:
        spec = next(((prefix, age) for prefix, age in specs if path.name.startswith(prefix)), None)
        if spec is None:
            continue
        prefix, min_age = spec
        try:
            if not path.is_dir() and not path.is_symlink():
                continue
            age = max(0.0, nowv - path.lstat().st_mtime)
            if age < min_age:
                continue
            result["checked"] += 1
            size = _tree_size_no_follow_v1196(path)
            if dry_run:
                result["deleted"] += 1
                result["freed"] += size
                result["samples"].append(f"작업폴더 삭제예정 {path.name} {_fmt_bytes(size)}")
                continue
            if path.is_symlink():
                path.unlink(missing_ok=True)
            else:
                shutil.rmtree(path)
            result["deleted"] += 1
            result["freed"] += size
            result["samples"].append(f"작업폴더 삭제 {path.name} {_fmt_bytes(size)}")
        except Exception as exc:
            result["errors"] += 1
            result["samples"].append(f"{path.name}:{type(exc).__name__}")
    return result


def _backup_group_key_v1196(name: str) -> tuple[str, bool]:
    temp_tokens = (".guard_tmp_", ".v399_tmp_", ".guardtmp")
    for token in temp_tokens:
        if token in name:
            return name.split(token, 1)[0] + token, True
    for token in (".backup_guard_apply_", ".backup_guard_worker_apply_", ".before_guard_rollback_", ".backup_", ".bad_", ".bak_"):
        if token in name:
            return name.split(token, 1)[0] + token, False
    return name, False


def cleanup_bounded_backups_v1196(dry_run: bool = False) -> dict:
    """Bound non-ledger rollback artifacts by group.

    Keep three newest backups per active alias. Temporary partial-copy files are
    not rollback evidence and are removed after 30 minutes. Extra backups are
    removed only after 30 minutes so an immediate rollback window remains.
    """
    result = {"checked": 0, "deleted": 0, "freed": 0, "errors": 0, "samples": [], "kept": 0}
    groups = {}
    try:
        for path in BOT_DIR.iterdir():
            if not path.is_file() and not path.is_symlink():
                continue
            key, is_temp = _backup_group_key_v1196(path.name)
            if key == path.name:
                continue
            groups.setdefault((key, is_temp), []).append(path)
    except Exception as exc:
        result["errors"] += 1
        result["samples"].append(f"backup_scan:{type(exc).__name__}")
        return result
    nowv = time.time()
    for (key, is_temp), files in groups.items():
        files.sort(key=lambda x: x.lstat().st_mtime if x.exists() else 0.0, reverse=True)
        keep_count = 0 if is_temp else 3
        result["kept"] += min(keep_count, len(files))
        for idx, path in enumerate(files):
            result["checked"] += 1
            if idx < keep_count:
                continue
            try:
                age = max(0.0, nowv - path.lstat().st_mtime)
                if age < 30 * 60:
                    continue
                size = int(path.lstat().st_size)
                if dry_run:
                    result["deleted"] += 1
                    result["freed"] += size
                    result["samples"].append(f"중복백업 삭제예정 {path.name} {_fmt_bytes(size)}")
                    continue
                path.unlink(missing_ok=True)
                result["deleted"] += 1
                result["freed"] += size
                result["samples"].append(f"중복백업 삭제 {path.name} {_fmt_bytes(size)}")
            except Exception as exc:
                result["errors"] += 1
                result["samples"].append(f"{path.name}:{type(exc).__name__}")
    return result



def cleanup_retired_review_artifacts_v1263(dry_run: bool = False) -> dict:
    """Delete only retired Review analysis state after v1263 migration proof.

    Core OPEN/CLOSED/trade/decision/exact/change/issue ledgers are outside this
    allow-list.  The active v1263 state and the Paper exact replay sources are
    never touched.
    """
    result = {'state':'CHECK','checked':0,'deleted':0,'freed':0,'errors':0,'samples':[],
              'fresh_state_proof':False,'review_runtime_proof':False,'protected_core_deleted':0}
    status = read_json(BOT_DIR / 'clean_review_worker_status.json') or {}
    state = read_json(BOT_DIR / 'version_score_current_missed_state_v1263.json') or {}
    runtime_ok = isinstance(status, dict) and str(status.get('version') or '') == 'review_worker_v1.039'
    fresh_ok = (
        isinstance(state, dict)
        and state.get('schema') == 'current_strategy_missed_state_v1263'
        and state.get('fresh_start_v1263') is True
        and state.get('retired_state_imported') is False
        and isinstance(state.get('events'), dict)
    )
    result['review_runtime_proof'] = runtime_ok
    result['fresh_state_proof'] = fresh_ok
    if not (runtime_ok and fresh_ok):
        result['samples'].append('보류: Review 1.039 runtime + v1263 fresh state 증거 필요')
        return result

    open_owners = {}
    try:
        snap = _audit_open_fd_snapshot()
        open_owners = snap.get('owners') if isinstance(snap, dict) and isinstance(snap.get('owners'), dict) else {}
    except Exception as exc:
        result['errors'] += 1
        result['samples'].append(f'fd_snapshot:{type(exc).__name__}')

    exact_files = (
        'version_score_current_missed_state_v1261.json',
        'version_score_current_missed_state_v1262.json',
        'version_score_review_state_v1233.json',
        'canonical_version_score_review_v1261.json',
        'canonical_version_score_review_v1233.json',
        'review_append_dedup_v1013.sqlite3',
        'review_append_dedup_v1013.sqlite3-wal',
        'review_append_dedup_v1013.sqlite3-shm',
    )
    paths = [BOT_DIR / name for name in exact_files]
    # Atomic leftovers from retired v1261/v1262 state writers. Active v1263 tmp is excluded.
    for pattern in ('.version_score_current_missed_state_v1261.json.tmp.*',
                    '.version_score_current_missed_state_v1262.json.tmp.*'):
        paths.extend(BOT_DIR.glob(pattern))
    seen = set()
    nowv = time.time()
    for path in paths:
        try:
            key = str(path.resolve())
        except Exception:
            key = str(path)
        if key in seen:
            continue
        seen.add(key)
        if not path.exists() or not path.is_file():
            continue
        result['checked'] += 1
        try:
            owners = open_owners.get(key, []) if isinstance(open_owners, dict) else []
            if owners:
                result['samples'].append(f'보류 열린파일 {path.name}')
                continue
            age = max(0.0, nowv - path.stat().st_mtime)
            if '.tmp.' in path.name and age < 300.0:
                result['samples'].append(f'보류 최근tmp {path.name}')
                continue
            size = int(path.stat().st_size)
            if dry_run:
                result['deleted'] += 1
                result['freed'] += size
                result['samples'].append(f'퇴역Review 삭제예정 {path.name} {_fmt_bytes(size)}')
                continue
            ok, got, label = _safe_unlink(path)
            if ok:
                result['deleted'] += 1
                result['freed'] += got
                result['samples'].append(f'퇴역Review 삭제 {label} {_fmt_bytes(got)}')
            else:
                result['errors'] += 1
                result['samples'].append(label)
        except Exception as exc:
            result['errors'] += 1
            result['samples'].append(f'{path.name}:{type(exc).__name__}')
    result['state'] = 'DONE' if result['errors'] == 0 else 'PARTIAL'
    return result


def run_retention_cleanup(dry_run: bool = False) -> dict:
    """v2.5.34 순환정리 본선.
    - 내부 로그/이벤트성 파일은 오늘이 지나면 gzip 압축한다.
    - gzip·archive 파일은 2일 초과 시 순환정리한다.
    - active 품질/복기 snapshot은 유지하고 명시된 retired state만 정리한다.
    - paper OPEN/CLOSED/trade_log 장부는 삭제하지 않는다.
    """
    now_s = time.time()
    today = datetime.now().strftime("%Y-%m-%d")
    deleted = truncated = errors = compressed = 0
    freed = 0
    samples = []

    stale_workdirs_v1196 = cleanup_stale_workdirs_v1196(dry_run=dry_run)
    deleted += int(stale_workdirs_v1196.get('deleted') or 0)
    errors += int(stale_workdirs_v1196.get('errors') or 0)
    freed += int(stale_workdirs_v1196.get('freed') or 0)
    samples.extend(list(stale_workdirs_v1196.get('samples') or [])[:12])

    bounded_backups_v1196 = cleanup_bounded_backups_v1196(dry_run=dry_run)
    deleted += int(bounded_backups_v1196.get('deleted') or 0)
    errors += int(bounded_backups_v1196.get('errors') or 0)
    freed += int(bounded_backups_v1196.get('freed') or 0)
    samples.extend(list(bounded_backups_v1196.get('samples') or [])[:12])

    retired_review_cleanup_v1263 = cleanup_retired_review_artifacts_v1263(dry_run=dry_run)
    deleted += int(retired_review_cleanup_v1263.get('deleted') or 0)
    errors += int(retired_review_cleanup_v1263.get('errors') or 0)
    freed += int(retired_review_cleanup_v1263.get('freed') or 0)
    samples.extend(list(retired_review_cleanup_v1263.get('samples') or [])[:12])

    growth_cleanup_v1007 = cleanup_v1007_noncore_growth(dry_run=dry_run)
    deleted += int(growth_cleanup_v1007.get('deleted') or 0)
    errors += int(growth_cleanup_v1007.get('errors') or 0)
    freed += int(growth_cleanup_v1007.get('freed') or 0)
    samples.extend(list(growth_cleanup_v1007.get('samples') or [])[:12])

    retired_live_cleanup = cleanup_retired_live_cache_files_v942(dry_run=dry_run)
    deleted += int(retired_live_cleanup.get('deleted') or 0)
    errors += int(retired_live_cleanup.get('errors') or 0)
    freed += int(retired_live_cleanup.get('freed') or 0)
    samples.extend(list(retired_live_cleanup.get('samples') or [])[:12])

    legacy_cleanup = cleanup_redundant_legacy_cache_archives(dry_run=dry_run)
    deleted += int(legacy_cleanup.get('deleted') or 0)
    errors += int(legacy_cleanup.get('errors') or 0)
    freed += int(legacy_cleanup.get('freed') or 0)
    samples.extend(list(legacy_cleanup.get('samples') or [])[:12])

    def age_days(path: Path) -> float:
        try:
            return max(0.0, (now_s - path.stat().st_mtime) / 86400.0)
        except Exception:
            return 0.0

    def mday(path: Path) -> str:
        try:
            return datetime.fromtimestamp(path.stat().st_mtime).strftime("%Y-%m-%d")
        except Exception:
            return today

    protected_names = {
        "paper_bot_open.json", "paper_bot_closed.jsonl", "paper_bot_status.json", "paper_bot_control.json",
        "paper_candidates.jsonl", "paper_candidates_latest.jsonl", "shadow_candidates.jsonl", "shadow_candidates_latest.jsonl",
    }

    def protected(path: Path) -> bool:
        name = path.name
        if name in protected_names:
            return True
        low = name.lower()
        # trade_log/open/closed 원장은 직접 삭제 금지. 별도 장기 archive 정책에서만 다룬다.
        if "trade_log" in low or "paper_bot_open" in low or "paper_bot_closed" in low:
            return True
        if any(token in low for token in (
            "paper_score", "score_ledger", "change_verify", "issue_ledger",
            "good_s2_observation_ledger", "good_s2_result_ledger",
            "paper_execution_cost_ledger", "closed_result", "decision",
            "exact", "exit_replay", "canonical_performance", "closed_commit", "closed_append",
        )):
            return True
        return False

    def note_sample(text: str) -> None:
        if len(samples) < 12:
            samples.append(text)

    def gzip_file(path: Path) -> tuple[bool, int, str]:
        try:
            if not path.exists() or not path.is_file() or protected(path) or path.suffix == ".gz":
                return True, 0, path.name
            old_size = path.stat().st_size
            if old_size <= 0:
                return True, 0, path.name
            gz = path.with_name(path.name + f".{mday(path).replace('-', '')}.gz")
            if dry_run:
                return True, 0, f"압축예정 {path.name}"
            with path.open("rb") as src, gzip.open(gz, "wb", compresslevel=6) as dst:
                shutil.copyfileobj(src, dst)
            path.unlink(missing_ok=True)
            new_size = gz.stat().st_size if gz.exists() else 0
            return True, max(0, old_size - new_size), gz.name
        except Exception as e:
            return False, 0, f"{path.name}: {type(e).__name__}"

    # 1) v1228: abandoned temp files only. Active atomic-writer temps are protected by age.
    orphan_temp_cleanup_v1228 = {'checked':0, 'deleted':0, 'freed':0, 'errors':0, 'samples':[]}
    temp_candidates = []
    try:
        temp_candidates.extend([p for p in BOT_DIR.iterdir() if p.is_file()])
        runtime_root = BOT_DIR / 'runtime'
        if runtime_root.exists() and runtime_root.is_dir():
            temp_candidates.extend([p for p in runtime_root.rglob('*') if p.is_file()])
    except Exception as exc:
        orphan_temp_cleanup_v1228['errors'] += 1
        orphan_temp_cleanup_v1228['samples'].append(f'temp_scan:{type(exc).__name__}')
    seen_temp = set()
    for path in temp_candidates:
        try:
            key = str(path.resolve())
        except Exception:
            key = str(path)
        if key in seen_temp:
            continue
        seen_temp.add(key)
        name = path.name
        is_temp = ('.tmp.' in name or '.tmp.runtime.' in name or name.endswith(('.tmp','.swp','.part','.guardtmp','~')))
        if not is_temp or protected(path):
            continue
        try:
            age_sec = max(0.0, now_s - path.stat().st_mtime)
            if age_sec < 3600.0:
                continue
            orphan_temp_cleanup_v1228['checked'] += 1
            size = int(path.stat().st_size)
            if dry_run:
                orphan_temp_cleanup_v1228['deleted'] += 1
                orphan_temp_cleanup_v1228['freed'] += size
                orphan_temp_cleanup_v1228['samples'].append(f'고아임시 삭제예정 {path.name} {_fmt_bytes(size)}')
                continue
            ok, got, label = _safe_unlink(path)
            if ok:
                orphan_temp_cleanup_v1228['deleted'] += 1
                orphan_temp_cleanup_v1228['freed'] += got
                orphan_temp_cleanup_v1228['samples'].append(f'고아임시 삭제 {label} {_fmt_bytes(got)}')
            else:
                orphan_temp_cleanup_v1228['errors'] += 1
                orphan_temp_cleanup_v1228['samples'].append(label)
        except Exception as exc:
            orphan_temp_cleanup_v1228['errors'] += 1
            orphan_temp_cleanup_v1228['samples'].append(f'{path.name}:{type(exc).__name__}')
    deleted += int(orphan_temp_cleanup_v1228.get('deleted') or 0)
    freed += int(orphan_temp_cleanup_v1228.get('freed') or 0)
    errors += int(orphan_temp_cleanup_v1228.get('errors') or 0)
    samples.extend(list(orphan_temp_cleanup_v1228.get('samples') or [])[:12])

    # 2) 오래된 backup은 2일 초과 시 삭제
    for pat in ["bot.py.backup*", "*.backup_guard_apply_*", "ws_sidecar.py.backup*", "bithumb_micro_sidecar.py.backup*", "paper_bot.py.backup*", "backga_guard_bot*.backup*"]:
        for path in BOT_DIR.glob(pat):
            if not path.is_file() or protected(path) or age_days(path) <= 2:
                continue
            size = path.stat().st_size if path.exists() else 0
            ok, size, name = (True, size, path.name) if dry_run else _safe_unlink(path)
            if ok:
                deleted += 1; freed += size; note_sample(f"삭제 {name}")
            else:
                errors += 1; note_sample(name)

    # 3) 내부 로그/이벤트성 파일은 날짜가 지나면 비우지 말고 압축한다.
    internal_names = [
        "clean_ws_sidecar.out", "clean_ws_sidecar.log", "ws_sidecar.log",
        "clean_bithumb_micro.log", "clean_brain_runtime.log", "clean_brain_error.log",
        "clean_runtime_events.jsonl", "runtime_events.jsonl",
    ]
    for name in internal_names:
        path = BOT_DIR / name
        if not path.exists() or not path.is_file() or protected(path):
            continue
        if mday(path) == today:
            continue
        ok, saved, gzname = gzip_file(path)
        if ok:
            if saved > 0:
                compressed += 1; freed += saved; note_sample(f"압축 {gzname}")
        else:
            errors += 1; note_sample(gzname)

    # 4) v1197: active candidate/path files are owned by Strategy/Paper writers.
    # Guard must never tail-rewrite them while the owner may publish/append.
    # Historical growth is handled only through rotated/archive files.
    active_candidate_retention_protected_v1197 = [
        "paper_candidates.jsonl", "paper_candidates_latest.jsonl",
        "paper_candidates_handoff_merged.jsonl", "candidate_events.jsonl",
        "paper_bot_candidate_handoff_trace.jsonl",
        "paper_candidate_path_events_v1153.jsonl",
    ]

    # 5) 후보품질/복기/요약 계열 active snapshot은 유지한다. 명시된 retired state는 v1007 cleanup에서만 정리한다.
    quality_patterns = [
        "candidate_events*.jsonl", "clean_candidate_review*.jsonl", "candidate_review*.jsonl",
        "clean_quality*.json", "quality_*.json", "clean_external_snapshot*.json", "clean_version_score_summary*.json",
        "clean_reject_summary*.json", "review_*.json", "missed_*.jsonl",
    ]
    keep_active = {"clean_quality_summary.json", "clean_external_snapshot.json", "clean_version_score_summary.json", "clean_health_snapshot.json", "clean_resource_status.json", "clean_reject_summary.json"}
    for pat in quality_patterns:
        for path in BOT_DIR.glob(pat):
            if not path.is_file() or protected(path) or path.name in keep_active:
                continue
            low = path.name.lower()
            rotated = bool(re.search(r'(?:^|[._-])20\d{6}(?:[._-]|$)', low)) or any(tok in low for tok in ('.old','backup','archive','legacy','guard_removed')) or low.endswith(('.gz','.gzip'))
            if not rotated or age_days(path) <= 2:
                continue
            size = path.stat().st_size if path.exists() else 0
            ok, size, name = (True, size, path.name) if dry_run else _safe_unlink(path)
            if ok:
                deleted += 1; freed += size; note_sample(f"회전본2일 삭제 {name}")
            else:
                errors += 1; note_sample(name)

    # 6) 2일 지난 gzip/old/log rotate 파일 삭제
    for pat in ["*.gz", "*.old", "*.log.*", "*.out.*"]:
        for path in BOT_DIR.glob(pat):
            if not path.is_file() or protected(path) or age_days(path) <= 2:
                continue
            size = path.stat().st_size if path.exists() else 0
            ok, size, name = (True, size, path.name) if dry_run else _safe_unlink(path)
            if ok:
                deleted += 1; freed += size; note_sample(f"압축2일 삭제 {name}")
            else:
                errors += 1; note_sample(name)

    # 6-1) v928: archive/legacy archive는 재귀 순환한다.
    # 기존 cleanup은 BOT_DIR 최상단만 봐 5월 debug archive가 계속 남았다.
    archive_roots = [BOT_DIR / 'archive', BOT_DIR / 'legacy_v839_archive', BOT_DIR / 'legacy_v840_archive']
    for root in archive_roots:
        if not root.exists() or not root.is_dir():
            continue
        try:
            for path in root.rglob('*'):
                if not path.is_file() or protected(path):
                    continue
                low = path.name.lower()
                if not (low.endswith(('.gz','.old')) or '.log.' in low or '.out.' in low or 'guard_removed' in low or 'legacy' in low):
                    continue
                if age_days(path) <= 2:
                    continue
                size = path.stat().st_size if path.exists() else 0
                ok, got, name = (True, size, path.name) if dry_run else _safe_unlink(path)
                if ok:
                    deleted += 1; freed += got; note_sample(f"archive2일 삭제 {name}")
                else:
                    errors += 1; note_sample(name)
        except Exception as e:
            errors += 1; note_sample(f"archive_recursive: {type(e).__name__}")

    # 7) v427: 가드봇 전담 활성파일 다이어트. OPEN 장부는 절대 대상에 넣지 않는다.
    def trim_jsonl_tail(path: Path, keep_lines: int, label: str, min_lines: int = 0) -> None:
        nonlocal truncated, errors, freed
        try:
            if not path.exists() or not path.is_file():
                return
            low = path.name.lower()
            if "open" in low and "closed" not in low:
                note_sample(f"OPEN보호 {path.name}")
                return
            data = path.read_bytes()
            lines = [ln for ln in data.splitlines() if ln.strip()]
            keep_lines = max(20, int(keep_lines or 300))
            min_lines = max(keep_lines + 1, int(min_lines or keep_lines + 1))
            if len(lines) < min_lines or len(lines) <= keep_lines:
                return
            old_size = path.stat().st_size
            if dry_run:
                note_sample(f"활성축소예정 {label} {len(lines)}→{keep_lines}")
                return
            arch_dir = BOT_DIR / "archive"
            arch_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            gz = arch_dir / f"{path.stem}_guard_removed_v427_{stamp}.jsonl.gz"
            with gzip.open(gz, "wb", compresslevel=6) as dst:
                dst.write(b"\n".join(lines[:-keep_lines]) + b"\n")
            tmp = path.with_suffix(path.suffix + ".guardtmp")
            tmp.write_bytes(b"\n".join(lines[-keep_lines:]) + b"\n")
            os.replace(tmp, path)
            new_size = path.stat().st_size if path.exists() else 0
            truncated += 1
            freed += max(0, old_size - new_size)
            note_sample(f"활성축소 {label} {len(lines)}→{keep_lines}")
        except Exception as e:
            errors += 1
            note_sample(f"{label}: {type(e).__name__}")

    def trim_text_tail(path: Path, keep_bytes: int, label: str) -> None:
        nonlocal truncated, errors, freed
        try:
            if not path.exists() or not path.is_file():
                return
            size = path.stat().st_size
            keep_bytes = max(80_000, int(keep_bytes or 300_000))
            if size <= keep_bytes:
                return
            if dry_run:
                note_sample(f"로그축소예정 {label} {_fmt_bytes(size)}→{_fmt_bytes(keep_bytes)}")
                return
            data = path.read_bytes()
            arch_dir = BOT_DIR / "archive"
            arch_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            gz = arch_dir / f"{path.stem}_guard_removed_v427_{stamp}.log.gz"
            with gzip.open(gz, "wb", compresslevel=6) as dst:
                dst.write(data[:-keep_bytes])
            tmp = path.with_suffix(path.suffix + ".guardtmp")
            tmp.write_bytes(data[-keep_bytes:])
            os.replace(tmp, path)
            truncated += 1
            freed += max(0, size - path.stat().st_size)
            note_sample(f"로그축소 {label}")
        except Exception as e:
            errors += 1
            note_sample(f"{label}: {type(e).__name__}")

    # v1197: active candidate snapshots and path ledgers are canonical/owner-written.
    # Never read-tail-replace them from Guard; a concurrent writer race can lose
    # the current generation or path events. Only ordinary text logs are bounded here.
    trim_text_tail(BOT_DIR / "clean_brain_runtime.log", 300_000, "brain runtime")
    trim_text_tail(BOT_DIR / "clean_brain_error.log", 160_000, "brain error")
    trim_text_tail(BOT_DIR / "paper_bot.log", 300_000, "paper log")
    trim_text_tail(BOT_DIR / "paper_bot_error.log", 160_000, "paper error")

    # 8) 서버 작업폴더 update zip은 최신 3개만 유지한다. GitHub history는 건드리지 않는다.
    try:
        zips = sorted(BOT_DIR.glob("coinbot_update_v*.zip"), key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
        for i, path in enumerate(zips):
            if i < 3:
                continue
            size = path.stat().st_size if path.exists() else 0
            if dry_run:
                note_sample(f"zip삭제예정 {path.name}")
                continue
            ok, size, name = _safe_unlink(path)
            if ok:
                deleted += 1; freed += size; note_sample(f"zip삭제 {name}")
            else:
                errors += 1; note_sample(name)
    except Exception as e:
        errors += 1; note_sample(f"zip_cleanup: {type(e).__name__}")

    # 9) v1007: 버전 보관 코드는 컴포넌트별 최신 3개를 남기고 2일 지난 것만 삭제한다.
    version_prefixes = (
        'coinbot_main_', '수익형_', 'strategy_worker_', 'paper_bot_', 'review_worker_', 'candle_worker_',
        'scanner_worker_', 'feature_worker_', 'orderflow_worker_', 'target_router_worker_',
        'risk_worker_', 'market_regime_worker_', 'backga_guard_bot_',
    )
    try:
        for prefix in version_prefixes:
            files = [x for x in BOT_DIR.glob(prefix + 'v*.py') if x.is_file()]
            files.sort(key=lambda x: x.stat().st_mtime if x.exists() else 0, reverse=True)
            for path in files[3:]:
                if age_days(path) <= 2:
                    continue
                size = path.stat().st_size if path.exists() else 0
                ok, got, name = (True, size, path.name) if dry_run else _safe_unlink(path)
                if ok:
                    deleted += 1; freed += got; note_sample(f"구코드2일 삭제 {name}")
                else:
                    errors += 1; note_sample(name)
    except Exception as e:
        errors += 1; note_sample(f"old_code_cleanup: {type(e).__name__}")

    try:
        write_json(BOT_DIR / "clean_retention_state.json", {
            "ok": errors == 0, "time": now(), "ts": time.time(), "version": VERSION,
            "deleted": deleted, "truncated": truncated, "compressed": compressed, "errors": errors,
            "freed": freed, "samples": samples[:12],
            "policy": {"owner": "guard", "open_deleted": False, "closed_live_truncate": False, "trade_log_live_truncate": False, "decision_exact_change_issue_truncate": False, "active_candidate_snapshot_truncate": False, "active_candidate_path_truncate": False, "update_zip_keep": 3, "backup_keep_per_group": 3, "auto_retention_v1196": True, "v1197_owner_safe_retention": True, "v1228_orphan_temp_age_sec": 3600, "v1228_system_log_auto": True},
            "orphan_temp_cleanup_v1228": orphan_temp_cleanup_v1228,
            "stale_workdirs_v1196": stale_workdirs_v1196,
            "bounded_backups_v1196": bounded_backups_v1196,
        })
    except Exception:
        pass

    return {"deleted": deleted, "truncated": truncated, "compressed": compressed, "errors": errors, "freed": freed, "samples": samples, "dry_run": dry_run, "legacy_cleanup": legacy_cleanup, "retired_live_cleanup_v942": retired_live_cleanup, "noncore_growth_cleanup_v1007": growth_cleanup_v1007, "orphan_temp_cleanup_v1228": orphan_temp_cleanup_v1228, "stale_workdirs_v1196": stale_workdirs_v1196, "bounded_backups_v1196": bounded_backups_v1196, "retired_review_cleanup_v1263": retired_review_cleanup_v1263}

def cleanup_text(dry_run: bool = False) -> str:
    before = server_resource_snapshot()
    res = run_retention_cleanup(dry_run=dry_run)
    after = server_resource_snapshot()
    lines = ["🧹 디스크 순환정리 /gcleanup", "- 오래 남은 bundle/export 작업폴더 자동 삭제", "- rollback backup은 컴포넌트별 최신 3개 유지", "- 일반 텍스트 로그는 archive 후 순환", "- 현재 후보판·후보경로·OPEN/CLOSED/trade/decision/exact/change/issue는 활성축소 금지", f"- 삭제 {res['deleted']}개 / 압축 {res.get('compressed',0)}개 / 비움·축소 {res['truncated']}개 / 오류 {res['errors']}개", f"- 확보 추정: {_fmt_bytes(res['freed'])}", f"- 전: 디스크 {before['disk_pct']:.1f}% / 남음 {_fmt_bytes(before['disk_free'])}", f"- 후: 디스크 {after['disk_pct']:.1f}% / 남음 {_fmt_bytes(after['disk_free'])}"]
    if res.get("samples"):
        lines += ["", "처리 예시", *[f"- {x}" for x in res["samples"][:10]]]
    return "\n".join(lines)

V928_STORAGE_FIX_JSON = 'clean_guard_storage_fix_v928.json'

V928_STORAGE_FIX_TEXT = 'clean_guard_storage_fix_v928.txt'

def _v928_install_root_text(target: str, content: str) -> tuple[int, str]:
    tmp = BOT_DIR / ('.v928_' + Path(target).name + '.tmp')
    try:
        tmp.write_text(content, encoding='utf-8')
        parent = str(Path(target).parent)
        rc_dir, out_dir = _run_privileged(['install', '-d', '-m', '0755', parent], timeout=30)
        if rc_dir != 0:
            return rc_dir, f"mkdir {parent}: {out_dir}"
        rc, out = _run_privileged(['install', '-m', '0644', str(tmp), str(target)], timeout=30)
        return rc, out
    finally:
        try: tmp.unlink(missing_ok=True)
        except Exception: pass

def _v928_system_log_fix(dry_run: bool = False) -> dict:
    before_journal, before_journal_text = _audit_journal_bytes() if '_audit_journal_bytes' in globals() else (0, '')
    before_log = _audit_du_bytes(Path('/var/log'), timeout=15) if '_audit_du_bytes' in globals() else 0
    actions = []
    if dry_run:
        return {
            'dry_run': True, 'before_journal': before_journal, 'before_var_log': before_log,
            'actions': ['journald 256MB persistent cap', 'journal vacuum 256MB', 'google ops logrotate 32MB x2', 'old rotated google ops logs >12h delete', 'system logrotate'],
            'errors': 0,
        }
    errors = 0
    journald_conf = """[Journal]\nSystemMaxUse=256M\nRuntimeMaxUse=64M\nMaxRetentionSec=3day\nCompress=yes\n"""
    rc, out = _v928_install_root_text('/etc/systemd/journald.conf.d/99-coinbot-storage.conf', journald_conf)
    actions.append({'action':'install_journald_cap','rc':rc,'out':tail(out,500)})
    if rc != 0: errors += 1
    else:
        rc2, out2 = _run_privileged(['systemctl','restart','systemd-journald'], timeout=40)
        actions.append({'action':'restart_journald','rc':rc2,'out':tail(out2,500)})
        if rc2 != 0: errors += 1
    rc, out = _run_privileged(['journalctl','--vacuum-size=256M'], timeout=90)
    actions.append({'action':'vacuum_journal','rc':rc,'out':tail(out,700)})
    if rc != 0: errors += 1

    logrotate_conf = """/var/log/google-cloud-ops-agent/subagents/*.log {\n    size 32M\n    rotate 2\n    compress\n    nodelaycompress\n    missingok\n    notifempty\n    copytruncate\n    su root root\n}\n"""
    rc, out = _v928_install_root_text('/etc/logrotate.d/coinbot-google-ops-agent', logrotate_conf)
    actions.append({'action':'install_google_ops_logrotate','rc':rc,'out':tail(out,500)})
    if rc != 0:
        errors += 1
    else:
        rc2, out2 = _run_privileged(['logrotate','-f','/etc/logrotate.d/coinbot-google-ops-agent'], timeout=120)
        actions.append({'action':'rotate_google_ops','rc':rc2,'out':tail(out2,700)})
        if rc2 != 0: errors += 1
    rc, out = _run_privileged(['logrotate','-f','/etc/logrotate.conf'], timeout=120)
    actions.append({'action':'rotate_system_logs','rc':rc,'out':tail(out,700)})
    if rc != 0: errors += 1
    rc, out = _run_privileged(['find','/var/log/google-cloud-ops-agent/subagents','-maxdepth','1','-type','f','-name','*.log.*','-mmin','+720','-delete'], timeout=60)
    actions.append({'action':'delete_old_rotated_google_ops_logs_12h','rc':rc,'out':tail(out,500)})
    if rc != 0: errors += 1
    after_journal, after_journal_text = _audit_journal_bytes() if '_audit_journal_bytes' in globals() else (0, '')
    after_log = _audit_du_bytes(Path('/var/log'), timeout=15) if '_audit_du_bytes' in globals() else 0
    return {
        'dry_run': False, 'before_journal': before_journal, 'after_journal': after_journal,
        'before_var_log': before_log, 'after_var_log': after_log,
        'journal_freed': max(0, before_journal-after_journal),
        'var_log_freed': max(0, before_log-after_log),
        'before_journal_text': before_journal_text, 'after_journal_text': after_journal_text,
        'actions': actions, 'errors': errors,
    }

def gopen_policy_v1264_text() -> str:
    """Read-only proof for the user-approved 50 OPEN / 5 per generation contract."""
    active = read_json(BOT_DIR / 'paper_active_contract_snapshot_v1208.json') or {}
    paper = read_json(BOT_DIR / 'paper_bot_status.json') or {}
    entry = active.get('entry') if isinstance(active, dict) and isinstance(active.get('entry'), dict) else {}
    version = str(paper.get('version') or paper.get('paper_version') or '') if isinstance(paper, dict) else ''
    total = int(entry.get('total_cap') or 0)
    cycle = int(entry.get('cycle_new_open_cap') or 0)
    ranking = str(entry.get('entry_mode') or '')
    auto_buy = bool(active.get('auto_buy') or paper.get('auto_buy')) if isinstance(active, dict) and isinstance(paper, dict) else True
    state = 'DONE' if version == 'paper_bot_v1.079' and total == 50 and cycle == 5 and not auto_buy else 'CHECK'
    return '\n'.join([
        '📦 OPEN 표본계약 검수 /gopen_policy_v1264',
        f'- 상태: {state}',
        f'- Paper runtime: {version or "정보없음"}',
        f'- 전체 OPEN 최대: {total}',
        f'- 같은 generation 신규 최대: {cycle}',
        f'- 선발: {ranking or "정보없음"}',
        '- 순서: 기존 global score 높은 순서 그대로',
        f'- 자동매수: {"ON" if auto_buy else "OFF"}',
        '- trigger·invalid·target·RR·진입가·청산계약 변경 없음',
        '- 기존 OPEN 계약과 과거 원장 재작성 없음',
    ])


def gcontract_v1265_text() -> str:
    """Read-only proof that the active completed S1 handoff carries the v1257 contract."""
    pipeline = read_json(BOT_DIR / 'strategy_candidate_pipeline_commit_v1150.json') or {}
    scope = pipeline if isinstance(pipeline, dict) and pipeline.get('state') == 'NORMAL' else (
        pipeline.get('last_complete_cycle_v1152') if isinstance(pipeline, dict) and isinstance(pipeline.get('last_complete_cycle_v1152'), dict) else {}
    )
    handoff_name = str(scope.get('committed_handoff_file_v1158') or '').strip() if isinstance(scope, dict) else ''
    handoff_path = Path(handoff_name) if handoff_name else None
    if handoff_path is not None and not handoff_path.is_absolute():
        handoff_path = BOT_DIR / handoff_path
    handoff = read_json(handoff_path) if handoff_path is not None else {}
    rows = handoff.get('s1_rows') if isinstance(handoff, dict) and isinstance(handoff.get('s1_rows'), list) else []
    valid = []
    missing = []
    digest_missing = []
    for row in rows:
        if not isinstance(row, dict):
            missing.append(row)
            continue
        contract = row.get('unified_strategy_contract_v1257') if isinstance(row.get('unified_strategy_contract_v1257'), dict) else {}
        if contract.get('schema') != 'unified_alt_swing_contract_v1257':
            missing.append(row)
            continue
        valid.append(row)
        if not str(contract.get('contract_digest') or '').strip():
            digest_missing.append(row)
    paper = read_json(BOT_DIR / 'paper_bot_status.json') or {}
    paper_version = str(paper.get('version') or paper.get('paper_version') or '') if isinstance(paper, dict) else ''
    opened = read_json(BOT_DIR / 'paper_bot_open.json') or {}
    open_rows = list(opened.values()) if isinstance(opened, dict) else ([x for x in opened if isinstance(x, dict)] if isinstance(opened, list) else [])
    contracted = [r for r in open_rows if isinstance(r.get('exit_contract_v1257'), dict) and r.get('exit_contract_v1257', {}).get('schema') == 'paper_unified_exit_contract_v1257']
    verified = [r for r in contracted if r.get('unified_contract_transport_verified_v1265') is True]
    transport_missing = [r for r in open_rows if str(r.get('unified_contract_state_v1257') or '') == 'LEGACY_CANDIDATE_CONTRACT_PRESERVED']
    preexisting = [r for r in open_rows if r not in contracted and r not in transport_missing]
    if paper_version != 'paper_bot_v1.079':
        state = 'CHECK'
    elif not rows:
        state = 'COLLECTING'
    elif missing or digest_missing:
        state = 'FAIL'
    else:
        state = 'DONE'
    return '\n'.join([
        '🔐 통합계약 전달·OPEN 봉인 검수 /gcontract_v1265',
        f'- 상태: {state}',
        f'- Paper runtime: {paper_version or "정보없음"}',
        f'- 완료 cycle: {scope.get("cycle_id") or "정보없음"}',
        f'- 완료 handoff S1: {len(rows)} / 계약 포함 {len(valid)} / 계약 누락 {len(missing)} / digest 누락 {len(digest_missing)}',
        f'- 현재 OPEN: 전체 {len(open_rows)} / 통합계약 {len(contracted)} / v1265 전달검증 {len(verified)}',
        f'- 과거 전달유실 OPEN: {len(transport_missing)} / 적용 전 계약 OPEN: {len(preexisting)}',
        '- 과거 OPEN은 재작성하지 않음 · v1265 이후 계약 누락 신규 OPEN은 fail-closed',
        '- trigger·invalid·target·RR·점수순·청산수치 변경 없음 · 자동매수 OFF',
    ])


def gstorage_fix_text(dry_run: bool = False) -> str:
    before = server_resource_snapshot()
    bot = run_retention_cleanup(dry_run=dry_run)
    system = _v928_system_log_fix(dry_run=dry_run)
    after = server_resource_snapshot()
    result = {
        'schema':'guard_storage_fix_v942', 'version':VERSION, 'time':now(), 'ts':time.time(),
        'dry_run':dry_run, 'before':before, 'after':after, 'bot_cleanup':bot, 'system_log_fix':system,
        'protected':'OPEN/CLOSED/trade_log/decision/exact/score/change/issue/good-S2 core ledgers untouched; only allow-listed retired Review state deleted',
    }
    lines = [
        '🧹 불필요파일·로그 정리 /gstorage_fix · v1263',
        f"- 모드: {'미리보기' if dry_run else '실행'}",
        f"- 전: 사용 {before.get('disk_pct',0):.1f}% / 남음 {_fmt_bytes(before.get('disk_free',0))}",
        f"- 후: 사용 {after.get('disk_pct',0):.1f}% / 남음 {_fmt_bytes(after.get('disk_free',0))}",
        f"- 봇폴더: 삭제 {bot.get('deleted',0)} / 압축 {bot.get('compressed',0)} / 축소 {bot.get('truncated',0)} / 확보 {_fmt_bytes(bot.get('freed',0))} / 오류 {bot.get('errors',0)}",
        f"- 퇴역 Review 원장: 상태 {(bot.get('retired_review_cleanup_v1263') or {}).get('state','CHECK')} / 삭제 {(bot.get('retired_review_cleanup_v1263') or {}).get('deleted',0)} / 확보 {_fmt_bytes((bot.get('retired_review_cleanup_v1263') or {}).get('freed',0))}",
        f"- retired live cache 5종: 삭제 {(bot.get('retired_live_cleanup_v942') or {}).get('deleted',0)} / 확보 {_fmt_bytes((bot.get('retired_live_cleanup_v942') or {}).get('freed',0))}",
        f"- 중복 legacy cache archive: 삭제 {(bot.get('legacy_cleanup') or {}).get('deleted',0)} / 확보 {_fmt_bytes((bot.get('legacy_cleanup') or {}).get('freed',0))}",
        f"- v1007 noncore growth: 삭제 {(bot.get('noncore_growth_cleanup_v1007') or {}).get('deleted',0)} / 확보 {_fmt_bytes((bot.get('noncore_growth_cleanup_v1007') or {}).get('freed',0))}",
        f"- v1228 고아 임시파일: 삭제 {(bot.get('orphan_temp_cleanup_v1228') or {}).get('deleted',0)} / 확보 {_fmt_bytes((bot.get('orphan_temp_cleanup_v1228') or {}).get('freed',0))}",
        f"- journal: {_fmt_bytes(system.get('before_journal',0))} → {_fmt_bytes(system.get('after_journal',system.get('before_journal',0)))} / 확보 {_fmt_bytes(system.get('journal_freed',0))}",
        f"- /var/log: {_fmt_bytes(system.get('before_var_log',0))} → {_fmt_bytes(system.get('after_var_log',system.get('before_var_log',0)))} / 확보 {_fmt_bytes(system.get('var_log_freed',0))}",
        f"- system 작업 오류: {system.get('errors',0)}",
        '', '[보존]', '- OPEN/CLOSED/trade_log/decision/exact/score/change/issue/good-S2 핵심 장부는 정리 대상 아님',
    ]
    if bot.get('samples'):
        lines += ['', '[봇폴더 처리 예시]'] + [f"- {x}" for x in bot.get('samples',[])[:12]]
    acts = system.get('actions') or []
    if acts:
        lines += ['', '[시스템 로그 처리]']
        for a in acts[:8]:
            if isinstance(a, dict): lines.append(f"- {a.get('action')}: rc {a.get('rc')}")
            else: lines.append(f"- {a}")
    text='\n'.join(lines)
    try:
        write_json(BOT_DIR / V928_STORAGE_FIX_JSON, result)
        (BOT_DIR / V928_STORAGE_FIX_TEXT).write_text(text+'\n', encoding='utf-8')
    except Exception:
        pass
    return text

def preupgrade_disk_guard(force: bool = False) -> tuple[bool, str]:
    before = server_resource_snapshot()
    cleanup = run_retention_cleanup(dry_run=False)
    after = server_resource_snapshot()
    ok = bool(after.get("disk_pct", 100.0) < 93.0 and after.get("disk_free", 0.0) > 300 * 1024 * 1024)
    text = "\n".join(["[0/5] 디스크 사전점검·순환정리", f"- 전: 사용 {before['disk_pct']:.1f}% / 남음 {_fmt_bytes(before['disk_free'])}", f"- 정리: 삭제 {cleanup['deleted']}개 / 압축 {cleanup.get('compressed',0)}개 / 비움 {cleanup['truncated']}개 / 확보 {_fmt_bytes(cleanup['freed'])}", f"- 후: 사용 {after['disk_pct']:.1f}% / 남음 {_fmt_bytes(after['disk_free'])}"])
    if ok or force:
        return True, text
    return False, text + "\n❌ 디스크 여유 부족: 업그레이드 중단. /gcleanup 후 큰 파일 확인 필요"

def _offset_path() -> Path:
    return BOT_DIR / GUARD_OFFSET_FILE

def load_guard_offset() -> Optional[int]:
    data = read_json(_offset_path())
    try:
        val = int(data.get("offset", 0) or 0)
        return val if val > 0 else None
    except Exception:
        return None

def save_guard_offset(offset: Optional[int], reason: str = "") -> None:
    if not offset:
        return
    try:
        write_json(_offset_path(), {"offset": int(offset), "updated_at": now(), "reason": reason, "version": VERSION})
    except Exception as e:
        print(f"[{now()}] save_guard_offset failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)

def init_guard_offset_if_empty(offset: Optional[int]) -> Optional[int]:
    """가드봇 재시작 후 같은 /gguard_upgrade를 다시 먹는 루프를 막는다.
    저장된 offset이 없으면 텔레그램 서버에 남은 업데이트를 한 번 비우고 최신 다음부터 받는다.
    """
    if offset is not None:
        return offset
    try:
        data = api("getUpdates", {"timeout": 0}, timeout=5)
        results = data.get("result", []) if isinstance(data, dict) else []
        if results:
            latest = max(int(u.get("update_id", 0) or 0) for u in results)
            offset = latest + 1
            save_guard_offset(offset, "startup_drop_pending")
            return offset
    except Exception as e:
        print(f"[{now()}] init_guard_offset failed: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
    return None

def send_guard_start_notice() -> None:
    """systemd 재시작 루프 때 시작 알림이 연속 도배되지 않게 제한한다."""
    p = BOT_DIR / GUARD_START_NOTICE_FILE
    data = read_json(p)
    try:
        last_ts = float(data.get("ts", 0) or 0)
    except Exception:
        last_ts = 0
    last_version = str(data.get("version", ""))
    # 같은 버전 20초 이내 재시작 알림은 생략. 실제 상태는 /guard에서 확인.
    if last_version == VERSION and time.time() - last_ts < 20:
        return
    try:
        write_json(p, {"ts": time.time(), "time": now(), "version": VERSION})
    except Exception:
        pass
    send(ALLOWED_CHAT_ID, f"🛡 백가 가드봇 시작\n- {VERSION}\n- 관리대상: {MAIN_SERVICE}\n- 업그레이드: /gupgrade_menu 또는 /gupgrade\n- 상태확인: /guard")

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def short_hash(path: Path) -> str:
    try:
        return sha256_file(path)[:12]
    except Exception:
        return "?"

def extract_bot_version_from_text(text: str) -> str:
    vals = re.findall(r'^\s*BOT_VERSION\s*=\s*[\'\"]([^\'\"]+)', text or "", flags=re.M)
    if vals:
        return vals[-1]
    m = re.search(r"수익형\s*v\d+\.\d+\.\d+", text or "")
    return m.group(0) if m else "?"

def extract_bot_version(path: Path) -> str:
    if not path.exists():
        return "?"
    return extract_bot_version_from_text(path.read_text(encoding="utf-8", errors="ignore"))

def get_bot_versions():
    bot_py = BOT_DIR / "bot.py"
    bot_version = extract_bot_version(bot_py)
    deployed = read_file(BOT_DIR / ".deployed_target")
    resolved = resolve_main_source_v1196()
    latest = resolved.get("path") if isinstance(resolved, dict) else None
    latest_name = latest.name if isinstance(latest, Path) else "?"
    # The canonical target is the resolver result. DEPLOY_TARGET.txt is only a
    # legacy/advisory marker and must never overwrite the proven deployed target.
    target = latest_name
    return bot_version, target or "?", deployed or "?", latest_name

def _runtime_version_parts(text: str) -> Optional[tuple[int, ...]]:
    """Normalize the first semantic v-number with two or three numeric segments."""
    match = re.search(r"v(\d+(?:[._]\d+){1,2})(?=$|[^0-9])", str(text or ""), flags=re.I)
    if not match:
        return None
    try:
        return tuple(int(part) for part in re.split(r"[._]", match.group(1)))
    except (TypeError, ValueError):
        return None

def same_version_label(a: str, b: str) -> bool:
    av = _runtime_version_parts(a)
    bv = _runtime_version_parts(b)
    return bool(av is not None and bv is not None and av == bv)

def write_deploy_markers(target_name: str) -> None:
    # v2.2: DEPLOY_TARGET은 참고값이지만 오래된 값이 남으면 사람이 헷갈리고
    # 일부 구 배포 경로가 다시 잡을 수 있어 최신 적용 성공 시 같이 맞춘다.
    for name in [".deployed_target", "DEPLOY_TARGET.txt"]:
        try:
            (BOT_DIR / name).write_text(str(target_name).strip() + "\n", encoding="utf-8")
        except Exception:
            pass

def extract_recent_runtime_version(lines: int = 220, since: Optional[str] = None) -> str:
    try:
        if since is None:
            since = service_start_since()
        log = recent_journal(lines=lines, since=since) if since else recent_journal(lines=lines)
        vals = re.findall(r"수익형\s*v\d+\.\d+\.\d+", log or "")
        return vals[-1] if vals else "시작로그 대기"
    except Exception:
        return "시작로그 확인불가"

def version_from_filename(path: Path) -> Optional[BotVersion]:
    return BotVersion.parse(path.name)

def _main_source_contract_v1196(path: Optional[Path]) -> dict:
    """Validate one Main versioned source without trusting filename or mtime alone."""
    result = {"ok": False, "path": path, "name": path.name if isinstance(path, Path) else "-", "reason": "missing"}
    if not isinstance(path, Path) or not path.exists() or not path.is_file():
        return result
    filename_version = version_from_filename(path)
    internal_label = extract_bot_version(path)
    internal_version = BotVersion.parse(internal_label)
    result.update(filename_version=filename_version, internal_version=internal_version, internal_label=internal_label)
    if filename_version is None:
        result["reason"] = "filename_version_missing"
        return result
    if internal_version is None:
        result["reason"] = "internal_version_missing"
        return result
    if filename_version != internal_version:
        result["reason"] = f"filename_internal_mismatch:{filename_version}!={internal_version}"
        return result
    result.update(ok=True, reason="exact")
    return result


def _main_marker_path_v1196(name: str) -> Optional[Path]:
    value = str(name or "").strip().splitlines()[0] if str(name or "").strip() else ""
    if not value or not value.endswith(".py"):
        return None
    if not (value.startswith("coinbot_main_v") or value.startswith("수익형_v")):
        return None
    return BOT_DIR / value


def _deployed_main_proof_v1196() -> dict:
    """Return the versioned source proven to be the current active bot.py bytes."""
    active = BOT_DIR / "bot.py"
    marker = _main_marker_path_v1196(read_file(BOT_DIR / ".deployed_target"))
    contract = _main_source_contract_v1196(marker)
    if not contract.get("ok"):
        contract["owner"] = "deployed_marker_invalid"
        return contract
    if not active.exists():
        contract.update(ok=False, owner="deployed_marker_unproven", reason="active_bot_missing")
        return contract
    try:
        if sha256_file(active) != sha256_file(marker):
            contract.update(ok=False, owner="deployed_marker_unproven", reason="active_hash_mismatch")
            return contract
    except Exception as exc:
        contract.update(ok=False, owner="deployed_marker_unproven", reason=f"hash_error:{type(exc).__name__}")
        return contract
    contract["owner"] = "deployed_hash_exact"
    return contract


def _successful_bundle_main_v1196() -> Optional[Path]:
    status = read_json(BOT_DIR / UPGRADE_STATUS_FILE)
    if not isinstance(status, dict) or not bool(status.get("ok")):
        return None
    manifest = status.get("manifest") if isinstance(status.get("manifest"), dict) else {}
    return _main_marker_path_v1196(str(manifest.get("main") or ""))


def _deploy_targets_main_v1196() -> Optional[Path]:
    # DEPLOY_TARGETS.json is explicit configuration. DEPLOY_TARGET.txt is not;
    # it is retained only for display/backward compatibility.
    data = read_json(BOT_DIR / DEPLOY_TARGETS_FILE)
    if not isinstance(data, dict):
        return None
    value = data.get("main_bot") or data.get("main") or data.get("target")
    return _main_marker_path_v1196(str(value or ""))


def _generic_main_bootstrap_v1196() -> Optional[Path]:
    """Bootstrap only when no active deployed source can be proven.

    Modern coinbot_main_v files are eligible. Legacy 수익형_v archives are never
    auto-selected; they remain available only through an explicit bundle target.
    """
    rows = []
    for path in BOT_DIR.glob("coinbot_main_v*.py"):
        contract = _main_source_contract_v1196(path)
        if contract.get("ok"):
            rows.append((contract.get("filename_version"), path))
    return sorted(rows, key=lambda item: item[0])[-1][1] if rows else None


def resolve_main_source_v1196() -> dict:
    """Single Main target resolver used by display and direct upgrade.

    Order:
    1) successful bundle/DEPLOY_TARGETS explicit target, but never a downgrade;
    2) current .deployed_target only when its bytes exactly match bot.py;
    3) modern numeric bootstrap only when no deployed proof exists.
    Stale DEPLOY_TARGET.txt is reported and ignored.
    """
    active_path = BOT_DIR / "bot.py"
    active_version = BotVersion.parse(extract_bot_version(active_path)) if active_path.exists() else None
    deployed = _deployed_main_proof_v1196()
    rejected = []
    approved = []

    for owner, path in (
        ("successful_bundle_manifest", _successful_bundle_main_v1196()),
        ("deploy_targets_json", _deploy_targets_main_v1196()),
    ):
        if path is None:
            continue
        contract = _main_source_contract_v1196(path)
        if not contract.get("ok"):
            rejected.append({"owner": owner, "name": path.name, "reason": contract.get("reason")})
            continue
        ver = contract.get("filename_version")
        if active_version is not None and ver is not None and ver < active_version:
            rejected.append({"owner": owner, "name": path.name, "reason": f"downgrade:{ver}<{active_version}"})
            continue
        approved.append((ver, 2 if owner == "successful_bundle_manifest" else 1, owner, path))

    raw_legacy = _main_marker_path_v1196(read_file(BOT_DIR / "DEPLOY_TARGET.txt"))
    if raw_legacy is not None:
        legacy_contract = _main_source_contract_v1196(raw_legacy)
        legacy_ver = legacy_contract.get("filename_version")
        if not legacy_contract.get("ok"):
            rejected.append({"owner": "legacy_DEPLOY_TARGET", "name": raw_legacy.name, "reason": legacy_contract.get("reason")})
        elif active_version is not None and legacy_ver is not None and legacy_ver < active_version:
            rejected.append({"owner": "legacy_DEPLOY_TARGET", "name": raw_legacy.name, "reason": f"stale_downgrade:{legacy_ver}<{active_version}"})
        else:
            # A legacy marker may describe the same currently deployed file, but
            # it never outranks an exact deployed hash or explicit JSON/manifest.
            rejected.append({"owner": "legacy_DEPLOY_TARGET", "name": raw_legacy.name, "reason": "advisory_only"})

    if approved:
        approved.sort(key=lambda row: (row[0], row[1]))
        ver, _priority, owner, path = approved[-1]
        if not deployed.get("ok") or deployed.get("filename_version") is None or ver > deployed.get("filename_version"):
            return {"path": path, "owner": owner, "active_version": active_version, "deployed": deployed, "rejected": rejected}

    if deployed.get("ok"):
        return {"path": deployed.get("path"), "owner": deployed.get("owner"), "active_version": active_version, "deployed": deployed, "rejected": rejected}

    if approved:
        ver, _priority, owner, path = approved[-1]
        return {"path": path, "owner": owner, "active_version": active_version, "deployed": deployed, "rejected": rejected}

    bootstrap = _generic_main_bootstrap_v1196()
    if bootstrap is not None:
        return {"path": bootstrap, "owner": "modern_numeric_bootstrap", "active_version": active_version, "deployed": deployed, "rejected": rejected}
    return {"path": None, "owner": "CHECK_NO_APPROVED_MAIN", "active_version": active_version, "deployed": deployed, "rejected": rejected}


def reconcile_main_markers_v1196() -> dict:
    """Repair only the legacy advisory marker from exact active deployment proof."""
    proof = _deployed_main_proof_v1196()
    result = {"ok": bool(proof.get("ok")), "changed": False, "owner": proof.get("owner"), "target": "-"}
    if not proof.get("ok") or not isinstance(proof.get("path"), Path):
        result["reason"] = proof.get("reason") or "deployed_proof_missing"
        return result
    target = proof["path"].name
    result["target"] = target
    legacy_path = BOT_DIR / "DEPLOY_TARGET.txt"
    current = read_file(legacy_path)
    if current == target:
        result["reason"] = "already_match"
        return result
    tmp = legacy_path.with_name(f".{legacy_path.name}.tmp.{os.getpid()}.{time.time_ns()}")
    try:
        with tmp.open("w", encoding="utf-8") as handle:
            handle.write(target + "\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(tmp, legacy_path)
        result.update(changed=True, reason="legacy_marker_reconciled")
        write_json(BOT_DIR / "clean_main_target_reconcile_v1196.json", {
            "schema": "main_target_reconcile_v1196", "version": VERSION,
            "time": now(), "target": target, "old_legacy_target": current or "-",
            "owner": "deployed_hash_exact", "changed": True,
        })
    except Exception as exc:
        result.update(ok=False, reason=f"{type(exc).__name__}:{exc}")
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
    return result


def _approved_main_target_v1138() -> Optional[Path]:
    resolved = resolve_main_source_v1196()
    path = resolved.get("path") if isinstance(resolved, dict) else None
    return path if isinstance(path, Path) else None


def _generic_highest_main_source_v1138() -> Optional[Path]:
    return _generic_main_bootstrap_v1196()


def find_latest_source_file() -> Optional[Path]:
    return _approved_main_target_v1138()

def find_latest_paper_file() -> Optional[Path]:
    files = []
    for p in BOT_DIR.glob("paper_bot_v*.py"):
        ver = paper_version_from_filename(p)
        if ver:
            files.append((ver, p))
    if not files:
        return None
    return sorted(files, key=lambda x: x[0])[-1][1]

def find_latest_ws_sidecar_file() -> Optional[Path]:
    files = []
    for p in BOT_DIR.glob("ws_sidecar_v*.py"):
        m = re.search(r"ws_sidecar_v(\d+)\.(\d+)", p.name)
        if m:
            files.append(((int(m.group(1)), int(m.group(2)), p.stat().st_mtime), p))
    if not files:
        return None
    return sorted(files, key=lambda x: x[0])[-1][1]

def find_latest_micro_sidecar_file() -> Optional[Path]:
    """bithumb_micro_sidecar_v*.py 중 가장 높은 버전을 찾는다.

    v2.5.28: v2.5.27에서 /gupgrade 자동 이어가기 중 이 함수가 누락되어
    NameError가 났다. micro 파일은 수정하지 않더라도 DEPLOY_TARGETS의 최신 상태
    확인 단계에서 항상 필요하므로 가드봇 본선에 고정한다.
    """
    files = []
    for p in BOT_DIR.glob("bithumb_micro_sidecar_v*.py"):
        m = re.search(r"bithumb_micro_sidecar_v(\d+)\.(\d+)", p.name)
        if m:
            files.append(((int(m.group(1)), int(m.group(2)), p.stat().st_mtime), p))
    if not files:
        return None
    return sorted(files, key=lambda x: x[0])[-1][1]

def find_latest_guard_file() -> Optional[Path]:
    files = []
    for p in BOT_DIR.glob("backga_guard_bot_v*.py"):
        if p.name == GUARD_ACTIVE_FILE:
            continue
        m = re.search(r"v(\d+)[._](\d+)", p.name)
        if m:
            files.append(((int(m.group(1)), int(m.group(2)), p.stat().st_mtime), p))
    if not files:
        return None
    return sorted(files, key=lambda x: x[0])[-1][1]

def extract_assignment(path: Path, key: str) -> str:
    text = read_file(path)
    vals = re.findall(rf"^\s*{re.escape(key)}\s*=\s*[\'\"]([^\'\"]+)", text or "", flags=re.M)
    return vals[-1] if vals else "?"

def extract_paper_version(path: Path) -> str:
    if not path.exists():
        return "?"
    val = extract_assignment(path, "VERSION")
    if val != "?":
        return val
    pv = PaperVersion.parse(path.name)
    return str(pv) if pv else "?"

def read_deploy_targets() -> dict:
    data = read_json(BOT_DIR / DEPLOY_TARGETS_FILE)
    out = {}
    if isinstance(data, dict):
        main = data.get("main_bot") or data.get("main") or data.get("target")
        paper = data.get("paper_bot") or data.get("paper")
        if main:
            out["main"] = str(main).strip()
        if paper:
            out["paper"] = str(paper).strip()
        ws = data.get("ws_sidecar") or data.get("ws") or data.get("websocket")
        if ws:
            out["ws"] = str(ws).strip()
        micro = data.get("micro_sidecar") or data.get("micro") or data.get("bithumb_micro")
        if micro:
            out["micro"] = str(micro).strip()
    if "main" not in out:
        t = read_file(BOT_DIR / "DEPLOY_TARGET.txt")
        if t:
            out["main"] = t.splitlines()[0].strip()
    return out

def choose_latest_paper_target(explicit: Optional[str] = None) -> Optional[Path]:
    """메인봇처럼 paper_bot도 최신 파일을 자동 선택한다.
    DEPLOY_TARGETS.json의 paper 값이 낡아 있어도 BOT_DIR 안의 paper_bot_v*.py 중
    가장 높은 버전이 있으면 그 파일을 우선한다. explicit이 있으면 explicit만 사용한다.
    """
    if explicit:
        return BOT_DIR / explicit
    latest = find_latest_paper_file()
    targets = read_deploy_targets()
    configured = BOT_DIR / targets["paper"] if targets.get("paper") else None
    if latest and configured and configured.exists():
        latest_v = paper_version_from_filename(latest)
        cfg_v = paper_version_from_filename(configured)
        if latest_v and cfg_v:
            return latest if latest_v >= cfg_v else configured
    return latest or configured

def get_paper_versions() -> dict:
    latest = find_latest_paper_file()
    targets = read_deploy_targets()
    chosen = choose_latest_paper_target()
    configured = targets.get("paper") or "?"
    active_path = BOT_DIR / PAPER_ACTIVE_FILE
    return {
        "service": is_service_active(PAPER_SERVICE) if service_exists(PAPER_SERVICE) else "no_service",
        "active_file": PAPER_ACTIVE_FILE,
        "active_version": extract_paper_version(active_path),
        "target": chosen.name if chosen else configured,
        "configured_target": configured,
        "deployed": read_file(BOT_DIR / DEPLOYED_PAPER_FILE) or "?",
        "latest": latest.name if latest else "?",
        "latest_version": extract_paper_version(latest) if latest else "?",
        "active_hash": short_hash(active_path),
        "latest_hash": short_hash(latest) if latest else "?",
    }

def _systemd_unit_names(service: str) -> list[str]:
    raw = str(service or "").strip()
    if not raw:
        return []
    out = [raw]
    if not raw.endswith(".service"):
        out.append(raw + ".service")
    return list(dict.fromkeys(out))

def _systemctl_show_map(service: str, timeout: int = 4) -> dict:
    """systemctl status보다 가벼운 단일 본선 조회.

    v399: /gpaper_state에서 exists=False, /gpaperlog에서 exists=True처럼 갈리는 문제를
    줄이기 위해 show(LoadState/ActiveState/MainPID)만 쓴다.
    """
    last = {}
    for name in _systemd_unit_names(service):
        rc, out = run(["systemctl", "show", name, "--no-pager", "--property=LoadState,ActiveState,SubState,MainPID,FragmentPath"], timeout=timeout)
        d = {"rc": rc, "unit": name}
        for line in str(out or "").splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                d[k.strip()] = v.strip()
        last = d
        if d.get("LoadState") and d.get("LoadState") != "not-found":
            return d
    return last

def service_exists(service: str) -> bool:
    d = _systemctl_show_map(service, timeout=4)
    if d.get("LoadState") and d.get("LoadState") != "not-found":
        return True
    for name in _systemd_unit_names(service):
        if Path(f"/etc/systemd/system/{name}").exists() or Path(f"/lib/systemd/system/{name}").exists():
            return True
    return False

def is_service_active(service: str) -> str:
    d = _systemctl_show_map(service, timeout=4)
    active = str(d.get("ActiveState") or "").strip()
    if active:
        return active
    rc, out = run(["systemctl", "is-active", service], timeout=4)
    return (out or "?").strip()

def _service_main_pid(service: str) -> int:  # type: ignore[override]
    d = _systemctl_show_map(service, timeout=4)
    try:
        return int(str(d.get("MainPID") or "0").strip() or "0")
    except Exception:
        return 0

def validate_paper_target(path: Path) -> tuple[bool, list[str], list[str]]:
    checks, warnings = [], []
    if not path.exists():
        return False, [f"대상 파일 없음: {path.name}"], warnings
    filename_version_obj = paper_version_from_filename(path)
    if not filename_version_obj:
        return False, [f"파일명 형식 오류: {path.name}"], warnings
    # v1075: PaperVersion is numeric-only for sorting, so str(PaperVersion)
    # normalizes paper_bot_v1.000 to paper_bot_v1.0. Deployment identity must
    # compare the exact version token written in the filename instead.
    filename_match = re.search(r"(paper_bot_v\d+\.\d+)", path.name)
    filename_version = filename_match.group(1) if filename_match else "?"
    internal_version = extract_paper_version(path)
    if internal_version != filename_version:
        return False, [
            f"paper 파일명/내부 VERSION 불일치: file={filename_version} internal={internal_version}",
            "적용 전 중단: 파일명만 새 버전이고 최종 활성 VERSION이 구버전인 패키지는 배포하지 않음",
        ], warnings
    ok, out = py_compile(path)
    checks.append("✅ paper py_compile 통과" if ok else "❌ paper py_compile 실패\n" + tail(out, 1600))
    if not ok:
        return False, checks, warnings
    src = read_file(path)
    for required in ["VERSION", "paper_bot_status.json", "/pstatus", "/pbatch"]:
        if required not in src:
            warnings.append(f"paper 필수 문자열 확인 필요: {required}")
    checks.append(f"✅ paper identity exact: filename={filename_version} / internal={internal_version}")
    return True, checks, warnings

def read_pid(path: Path) -> Optional[int]:
    try:
        if not path.exists():
            return None
        pid = int(path.read_text(encoding="utf-8", errors="ignore").strip())
        return pid if pid > 1 else None
    except Exception:
        return None

def pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except Exception:
        return False

def proc_cmdline(pid: int) -> str:
    try:
        raw = Path(f"/proc/{int(pid)}/cmdline").read_bytes()
        return raw.replace(b"\x00", b" ").decode("utf-8", errors="ignore")
    except Exception:
        return ""

def proc_cgroup(pid: Optional[int]) -> str:
    try:
        if not pid:
            return ""
        return Path(f"/proc/{int(pid)}/cgroup").read_text(encoding="utf-8", errors="ignore").strip()
    except Exception:
        return ""

def short_cgroup(text: str) -> str:
    raw = str(text or "").replace("\n", " | ")
    if len(raw) > 180:
        return "..." + raw[-180:]
    return raw or "-"

def sidecar_management(pid: Optional[int], service: str) -> dict:
    cg = proc_cgroup(pid)
    svc_exists = service_exists(service) if service else False
    in_service = bool(pid and svc_exists and service in cg)
    if in_service:
        mode = f"systemd:{service}"
    elif svc_exists:
        mode = "direct-fallback"
    else:
        mode = "direct-fallback"
    warnings = []
    if not svc_exists:
        warnings.append("direct-fallback: systemd 서비스 미등록")
    elif not in_service and pid:
        warnings.append(f"service 등록됨 but 실행 pid가 {service} 밖에 있음")
    if cg and GUARD_SERVICE in cg:
        warnings.append(f"guard cgroup 안에서 실행중: {GUARD_SERVICE} 재시작 연동 종료 의심")
    return {"mode": mode, "service_exists": svc_exists, "in_service": in_service, "cgroup": cg, "cgroup_short": short_cgroup(cg), "warning": " / ".join(warnings) if warnings else "-"}

def service_action(service: str, action: str, timeout: int = 30) -> tuple[int, str]:
    return run(["systemctl", action, service], timeout=timeout)

def _run_privileged(cmd: list[str], timeout: int = 20) -> tuple[int, str]:
    """systemd unit 설치에 필요한 명령은 root면 바로, 아니면 sudo -n으로만 시도한다."""
    rc, out = run(cmd, timeout=timeout)
    if rc == 0:
        return rc, out
    low = str(out or "").lower()
    if os.geteuid() != 0 and ("permission" in low or "authentication" in low or "access denied" in low or "denied" in low or rc != 0):
        return run(["sudo", "-n"] + cmd, timeout=timeout)
    return rc, out

def _guess_bot_user() -> str:
    try:
        if len(BOT_DIR.parts) >= 3 and BOT_DIR.parts[1] == "home":
            return BOT_DIR.parts[2]
    except Exception:
        pass
    return ENV.get("BOT_USER", "") or ENV.get("USER", "") or os.environ.get("USER", "")

def _sidecar_unit_content(kind: str, python_bin: str, active_file: str, service: str) -> str:
    home = _guess_bot_owner_home() or str(BOT_DIR.parent)
    user = _guess_bot_user()
    pyver = "python3.10" if "3.10" in str(python_bin) else f"python{sys.version_info.major}.{sys.version_info.minor}"
    py_paths = [
        str(Path(home) / ".local" / "lib" / pyver / "site-packages"),
        str(Path(home) / ".local" / "lib" / "python3.10" / "site-packages"),
        str(Path(home) / ".local" / "lib" / "python3" / "site-packages"),
    ]
    py_paths = [x for x in dict.fromkeys(py_paths) if x]
    user_line = f"User={user}\n" if user and user != "root" else ""
    desc = "TradingBot websocket sidecar" if kind == "ws" else "TradingBot Bithumb micro sidecar"
    return f"""[Unit]
Description={desc}
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
{user_line}WorkingDirectory={BOT_DIR}
EnvironmentFile=-{ENV_PATH}
Environment=TRADING_BOT_DIR={BOT_DIR}
Environment=HOME={home}
Environment=PYTHONPATH={os.pathsep.join(py_paths)}
ExecStart={python_bin} {BOT_DIR / active_file}
Restart=always
RestartSec=3
KillSignal=SIGTERM
TimeoutStopSec=15

[Install]
WantedBy=multi-user.target
"""

def ensure_sidecar_service_installed(kind: str, *, force: bool = False) -> tuple[bool, list[str]]:
    """WS/micro를 guard direct-fallback이 아니라 systemd 독립 서비스로 관리하게 만든다.

    실패하면 기존 direct-fallback을 막지는 않지만, 상태판에는 계속 구조경고가 남는다.
    """
    if kind == "ws":
        service, active_file = WS_SERVICE, WS_ACTIVE_FILE
        pyinfo = resolve_ws_python(runtime_env=ws_runtime_env())
        python_bin = str(pyinfo.get("python") or "/usr/bin/python3.10") if pyinfo.get("ok") else "/usr/bin/python3.10"
    else:
        service, active_file = MICRO_SERVICE, MICRO_ACTIVE_FILE
        python_bin = MICRO_PYTHON_BIN or "/usr/bin/python3.10"
    notes = []
    unit_path = Path(f"/etc/systemd/system/{service}.service")
    content = _sidecar_unit_content(kind, python_bin, active_file, service)
    existing = ""
    try:
        existing = unit_path.read_text(encoding="utf-8", errors="ignore") if unit_path.exists() else ""
    except Exception:
        existing = ""
    if service_exists(service) and existing.strip() == content.strip() and not force:
        notes.append(f"service already installed: {service}")
        return True, notes
    tmp = BOT_DIR / f".{service}.service.tmp"
    try:
        tmp.write_text(content, encoding="utf-8")
    except Exception as exc:
        return False, [f"unit tmp write failed: {exc.__class__.__name__}: {str(exc)[:120]}"]
    try:
        if os.geteuid() == 0:
            unit_path.write_text(content, encoding="utf-8")
            rc_cp, out_cp = 0, ""
        else:
            rc_cp, out_cp = _run_privileged(["cp", str(tmp), str(unit_path)], timeout=10)
        if rc_cp != 0:
            return False, [f"unit install failed: {tail(out_cp, 600)}"]
        _run_privileged(["chmod", "0644", str(unit_path)], timeout=8)
        rc_daemon, out_daemon = _run_privileged(["systemctl", "daemon-reload"], timeout=20)
        rc_enable, out_enable = _run_privileged(["systemctl", "enable", service], timeout=20)
        notes.append(f"service installed: {service} / python={python_bin}")
        if rc_daemon != 0: notes.append("daemon-reload: " + tail(out_daemon, 300))
        if rc_enable != 0: notes.append("enable: " + tail(out_enable, 300))
        return True, notes
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass

def cleanup_direct_sidecar_pids(kind: str) -> list[str]:
    """systemd 서비스 전환 뒤 guard cgroup/direct 잔류 pid를 정리한다."""
    if kind == "ws":
        service, finder = WS_SERVICE, find_ws_sidecar_pids
    else:
        service, finder = MICRO_SERVICE, find_micro_sidecar_pids
    notes = []
    if not service_exists(service):
        return notes
    for pid in list(finder()):
        if not pid_alive(pid):
            continue
        cg = proc_cgroup(pid)
        if service not in cg:
            stop_pid(pid)
            notes.append(f"direct 잔류 pid 종료: {pid}")
    return notes

def _sidecar_target_sync(kind: str, active_version: str, active_hash: str, target: Optional[Path], deployed_marker: str) -> dict:
    target_name = target.name if target and target.exists() else "?"
    target_version = (ws_target_version(target) if kind == "ws" else micro_target_version(target)) if target and target.exists() else "?"
    target_hash = short_hash(target) if target and target.exists() else "?"
    marker_ok = target_name == "?" or deployed_marker in {target_name, "?", ""}
    hash_ok = target_hash == "?" or active_hash == target_hash
    version_ok = target_version == "?" or active_version == target_version
    return {
        "target_name": target_name,
        "target_version": target_version,
        "target_hash": target_hash,
        "marker_ok": marker_ok,
        "hash_ok": hash_ok,
        "version_ok": version_ok,
        "ok": bool(marker_ok and hash_ok and version_ok),
    }

def find_paperbot_pids() -> list[int]:
    out = []
    try:
        for p in Path("/proc").iterdir():
            if not p.name.isdigit():
                continue
            pid = int(p.name)
            low = proc_cmdline(pid).lower()
            if "paper_bot.py" in low and "python" in low:
                out.append(pid)
    except Exception:
        pass
    return sorted(set(out))

def repair_paper_pid_file(pid: int) -> None:
    try:
        if pid and pid > 1:
            (BOT_DIR / PAPER_PID_FILE).write_text(str(int(pid)), encoding="utf-8")
    except Exception:
        pass

def stop_pid(pid: int) -> None:
    try:
        os.kill(pid, signal.SIGTERM)
    except Exception:
        return
    for _ in range(20):
        if not pid_alive(pid):
            return
        time.sleep(0.2)
    try:
        os.kill(pid, signal.SIGKILL)
    except Exception:
        pass

def format_paper_apply_result(res: dict) -> str:
    ok = "✅" if res.get("ok") else "❌"
    changed = "교체+재시작" if res.get("changed") else ("변경없음/재시작생략" if res.get("skipped_restart") else "유지")
    lines = [f"{ok} paper_bot {changed}"]
    for k in ["target", "version", "active", "backup", "hash", "error", "warning"]:
        if res.get(k):
            lines.append(f"- {k}: {res.get(k)}")
    if res.get("notes"):
        lines.append("- notes:")
        lines.extend(f"  · {str(x)[:220]}" for x in res.get("notes", [])[:6])
    if res.get("warnings"):
        lines.append("- warnings:")
        lines.extend(f"  · {str(x)[:220]}" for x in res.get("warnings", [])[:6])
    return "\n".join(lines)

def ws_target_version(path: Path) -> str:
    if not path.exists():
        return "?"
    val = extract_assignment(path, "VERSION")
    if val != "?":
        return val
    m = re.search(r"ws_sidecar_v(\d+\.\d+)", path.name)
    return f"ws_sidecar_v{m.group(1)}" if m else path.name

def ws_status_ts(st: dict) -> float:
    try:
        return float(st.get("updated_ts") or st.get("updated_at") or st.get("ts") or 0)
    except Exception:
        return 0.0

def ws_count(st: dict, *keys: str) -> int:
    for k in keys:
        try:
            if k in st and st.get(k) not in (None, ""):
                return int(float(st.get(k) or 0))
        except Exception:
            continue
    return 0

def ws_runtime_file_note(path: Path, label: str, remove_if_not_writable: bool = False) -> str:
    """runtime 파일 권한을 가볍게 점검한다. root 소유 파일이면 unlink 후 재생성 가능하게 만든다."""
    try:
        if not path.exists():
            return f"{label}=missing"
        try:
            with path.open("a", encoding="utf-8"):
                pass
            return f"{label}=writable"
        except PermissionError:
            if remove_if_not_writable:
                try:
                    path.unlink()
                    return f"{label}=permission_fixed_by_unlink"
                except Exception as exc:
                    return f"{label}=permission_blocked:{exc.__class__.__name__}"
            return f"{label}=permission_blocked"
    except Exception as exc:
        return f"{label}=check_failed:{exc.__class__.__name__}"

def write_ws_pid_file(pid: int) -> str:
    pid_path = BOT_DIR / WS_PID_FILE
    try:
        pid_path.unlink(missing_ok=True)
    except Exception:
        pass
    try:
        pid_path.write_text(str(int(pid)), encoding="utf-8")
        return "pid_file_written"
    except Exception as exc:
        return f"pid_file_write_failed:{exc.__class__.__name__}:{str(exc)[:120]}"

def proc_exe(pid: Optional[int]) -> str:
    try:
        if not pid:
            return ""
        return os.path.realpath(f"/proc/{int(pid)}/exe")
    except Exception:
        return ""

def _dedupe_keep_order(items: Iterable[str]) -> list[str]:
    seen = set()
    out = []
    for item in items:
        s = str(item or "").strip()
        if not s or s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out

def ws_python_candidates() -> list[str]:
    """ws_sidecar 실행에 쓸 python 후보를 실제 성공 경로 중심으로 잡는다.
    v2.5.18: /usr/bin/python3 하나만 믿지 않는다. 현재 살아 있는 sidecar의
    /proc/<pid>/exe 경로를 우선 보고, 그 다음 설정값과 흔한 python3.10 경로를 본다.
    """
    pids = find_ws_sidecar_pids()
    running = [proc_exe(pid) for pid in pids if pid_alive(pid)]
    return _dedupe_keep_order([
        *(list(reversed(running)) if running else []),
        ENV.get("WS_PYTHON_BIN", ""),
        WS_PYTHON_BIN,
        "/usr/bin/python3.10",
        "/usr/local/bin/python3.10",
        "/usr/bin/python3",
        sys.executable,
        "python3.10",
        "python3",
    ])

def proc_environ(pid: Optional[int]) -> dict:
    """현재 정상 실행 중인 ws_sidecar의 환경을 읽어 업그레이드/재시작에 재사용한다.
    v2.5.19: guard systemd 환경과 수동 실행 환경이 달라 websockets import가 실패하던 원인 보정.
    """
    out = {}
    try:
        if not pid:
            return out
        raw = Path(f"/proc/{int(pid)}/environ").read_bytes()
        for part in raw.split(b"\x00"):
            if not part or b"=" not in part:
                continue
            k, v = part.split(b"=", 1)
            key = k.decode("utf-8", errors="ignore")
            val = v.decode("utf-8", errors="ignore")
            if key:
                out[key] = val
    except Exception:
        pass
    return out

def _guess_bot_owner_home() -> str:
    try:
        # /home/dangdang971216/trading_bot -> /home/dangdang971216
        if len(BOT_DIR.parts) >= 3 and BOT_DIR.parts[1] == "home":
            return str(Path("/") / BOT_DIR.parts[1] / BOT_DIR.parts[2])
    except Exception:
        pass
    return os.environ.get("HOME", "")

def _append_pythonpath(env: dict, paths: list[str]) -> dict:
    cur = [x for x in str(env.get("PYTHONPATH", "")).split(os.pathsep) if x]
    seen = set(cur)
    for path in paths:
        if path and Path(path).exists() and path not in seen:
            cur.append(path)
            seen.add(path)
    if cur:
        env["PYTHONPATH"] = os.pathsep.join(cur)
    return env

def ws_runtime_env() -> dict:
    """ws_sidecar 실행/검사에 쓰는 환경.
    핵심은 guard 자신의 환경이 아니라, 이미 정상수신 중인 sidecar의 HOME/PYTHONPATH/VIRTUAL_ENV를 우선 보존하는 것.
    """
    env = os.environ.copy()
    env.update(ENV)
    # 현재 정상 실행 중인 sidecar 환경을 가능한 한 복원한다.
    running_pids = [pid for pid in find_ws_sidecar_pids() if pid_alive(pid)]
    penv = {}
    if running_pids:
        penv = proc_environ(running_pids[-1])
        for key in ("HOME", "PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "PATH", "LD_LIBRARY_PATH"):
            if penv.get(key):
                env[key] = penv[key]
    # v2.5.24: sidecar가 죽은 상태에서 guard가 root HOME을 쓰면 사용자 site-packages를 못 찾아 import_failed가 난다.
    # 실행 중인 sidecar HOME이 있으면 그것을 쓰고, 없으면 BOT_DIR 기준 소유자 홈(/home/dangdang...)을 우선한다.
    owner_home = _guess_bot_owner_home()
    home = penv.get("HOME") or owner_home or env.get("HOME")
    if home:
        env["HOME"] = home
    # 사용자 계정에 설치된 websockets를 guard systemd 환경에서도 찾게 한다.
    pyver = f"{sys.version_info.major}.{sys.version_info.minor}"
    user_paths = []
    if home:
        user_paths.extend([
            str(Path(home) / ".local" / "lib" / f"python{pyver}" / "site-packages"),
            str(Path(home) / ".local" / "lib" / "python3.10" / "site-packages"),
            str(Path(home) / ".local" / "lib" / "python3" / "site-packages"),
        ])
    env = _append_pythonpath(env, user_paths)
    env["TRADING_BOT_DIR"] = str(BOT_DIR)
    return env

def run_with_env(cmd: list[str], cwd: Optional[Path] = None, timeout: int = 20, env: Optional[dict] = None):
    try:
        p = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=timeout,
            env=env,
        )
        return p.returncode, (p.stdout or "").strip()
    except subprocess.TimeoutExpired as e:
        out = e.stdout or ""
        return 124, f"TIMEOUT after {timeout}s\n{out}".strip()
    except Exception as e:
        return 1, f"{type(e).__name__}: {e}"

def ws_import_check_for(python_bin: str, runtime_env: Optional[dict] = None) -> tuple[bool, str]:
    code = (
        "import sys, os; "
        "print(sys.executable); "
        "print('HOME=' + str(os.environ.get('HOME',''))); "
        "print('PYTHONPATH=' + str(os.environ.get('PYTHONPATH',''))[:260]); "
        "import websockets; "
        "print('websockets OK', getattr(websockets, '__version__', '?'), getattr(websockets, '__file__', '?'))"
    )
    env = runtime_env or ws_runtime_env()
    rc, out = run_with_env([python_bin, "-c", code], cwd=BOT_DIR, timeout=10, env=env)
    return rc == 0, (out or "").strip()

def resolve_ws_python(preferred: Optional[str] = None, runtime_env: Optional[dict] = None) -> dict:
    """웹소켓 실행용 python을 결정한다.
    v2.5.24: 기존 sidecar를 멈추기 전의 실행환경을 잡아두고 그 환경으로 import 검사/시작까지 이어간다.
    기존 버그는 preflight 때는 성공했지만, stop 이후 실행환경이 바뀌어 start 단계에서 import_failed가 난 것이었다.
    """
    env = runtime_env or ws_runtime_env()
    candidates = _dedupe_keep_order(([preferred] if preferred else []) + ws_python_candidates())
    notes = []
    for py in candidates:
        ok, out = ws_import_check_for(py, runtime_env=env)
        first = (out.splitlines()[0] if out else "출력없음")
        notes.append(f"try {py}: {'OK' if ok else 'FAIL'} / {first}")
        if ok:
            return {"ok": True, "python": py, "notes": notes, "output": out, "candidates": candidates, "env": env}
    return {"ok": False, "python": preferred or WS_PYTHON_BIN, "notes": notes, "output": "", "candidates": candidates, "env": env}

def ws_import_check() -> tuple[bool, list[str]]:
    info = resolve_ws_python()
    lines = [f"selected={info.get('python')}", "candidates=" + ", ".join(info.get("candidates") or [])]
    lines.extend(info.get("notes") or [])
    if info.get("output"):
        lines.append(tail(str(info.get("output")), 700))
    return bool(info.get("ok")), lines

def init_ws_status_file(reason: str = "guard_restart") -> str:
    try:
        write_json(BOT_DIR / WS_STATUS_FILE, {
            "version": "guard_prestart_v2.5.14",
            "pid": 0,
            "state": "guard_starting",
            "targets": 0,
            "cached": 0,
            "fresh": 0,
            "raw_total": 0,
            "parse_ok": 0,
            "price_ok": 0,
            "amount_ok": 0,
            "match_ok": 0,
            "last_error": "-",
            "last_notice": "-",
            "last_format": "-",
            "python_path": (resolve_ws_python().get("python") if reason not in {"import_failed", "apply_import_failed"} else WS_PYTHON_BIN),
            "guard_reason": reason,
            "updated_ts": time.time(),
        })
        return "status_initialized"
    except Exception as exc:
        return f"status_init_failed:{exc.__class__.__name__}:{str(exc)[:120]}"

def choose_latest_ws_sidecar_target(explicit: Optional[str] = None) -> Optional[Path]:
    if explicit:
        return BOT_DIR / explicit
    targets = read_deploy_targets()
    configured = BOT_DIR / targets["ws"] if targets.get("ws") else None
    latest = find_latest_ws_sidecar_file()
    return latest or configured

def find_ws_sidecar_pids() -> list[int]:
    out = []
    try:
        for p in Path("/proc").iterdir():
            if not p.name.isdigit():
                continue
            pid = int(p.name)
            low = proc_cmdline(pid).lower()
            if "python" in low and ("ws_sidecar.py" in low or "ws_sidecar_v" in low):
                out.append(pid)
    except Exception:
        pass
    return sorted(set(out))

def stop_ws_sidecar() -> tuple[bool, list[str]]:
    notes = []
    if service_exists(WS_SERVICE):
        rc, out = service_action(WS_SERVICE, "stop", timeout=25)
        time.sleep(1)
        notes += cleanup_direct_sidecar_pids("ws")
        alive = [p for p in find_ws_sidecar_pids() if pid_alive(p)]
        try:
            (BOT_DIR / WS_PID_FILE).unlink(missing_ok=True)
        except Exception:
            pass
        notes.append(f"관리방식=systemd:{WS_SERVICE}")
        notes.append(f"systemctl stop rc={rc} active={is_service_active(WS_SERVICE)}")
        if out:
            notes.append(tail(out, 500))
        return (not alive), notes + ([f"잔류 pid: {alive}"] if alive else [])
    pid_path = BOT_DIR / WS_PID_FILE
    pid = read_pid(pid_path)
    pids = set(find_ws_sidecar_pids())
    if pid:
        pids.add(pid)
    for p in sorted(pids):
        if p and pid_alive(p):
            stop_pid(p)
            notes.append(f"pid 종료: {p}")
    try:
        pid_path.unlink(missing_ok=True)
        notes.append("pid 파일 제거")
    except Exception as exc:
        notes.append(f"pid 파일 제거 실패: {exc.__class__.__name__}: {str(exc)[:100]}")
    alive = [p for p in find_ws_sidecar_pids() if pid_alive(p)]
    return (not alive), notes + ([f"잔류 pid: {alive}"] if alive else [])

def start_ws_sidecar(python_bin: Optional[str] = None, runtime_env: Optional[dict] = None, skip_import_check: bool = False) -> tuple[str, list[str]]:
    notes = []
    svc_ok, svc_notes = ensure_sidecar_service_installed("ws")
    notes += svc_notes
    if service_exists(WS_SERVICE):
        notes += cleanup_direct_sidecar_pids("ws")
        rc, out = service_action(WS_SERVICE, "start", timeout=25)
        time.sleep(2)
        st = ws_sidecar_state_dict()
        notes.append(f"관리방식=systemd:{WS_SERVICE}")
        notes.append(f"systemctl start rc={rc} active={is_service_active(WS_SERVICE)}")
        notes.append(f"state={st.get('verdict')} / raw={st.get('raw_total')} / match={st.get('match_ok')} / age={st.get('age_text')}")
        if out:
            notes.append(tail(out, 500))
        return ("active" if st.get("alive") else "failed"), notes
    if not svc_ok:
        notes.append("systemd service 설치 실패 → direct-fallback 임시 사용")
    active_path = BOT_DIR / WS_ACTIVE_FILE
    if not active_path.exists():
        return "missing", [f"active file 없음: {WS_ACTIVE_FILE}"]
    ok, out = py_compile(active_path)
    if not ok:
        return "compile_failed", [tail(out, 1200)]

    # 이미 살아 있으면 새로 띄우지 않고 pid만 보정한다.
    pids = find_ws_sidecar_pids()
    if pids:
        used = pids[-1]
        pid_note = write_ws_pid_file(used)
        return "active", [f"이미 실행중 pid={used}", pid_note, f"python_exe={proc_exe(used) or '-'}"]

    selected_env = runtime_env or ws_runtime_env()
    if skip_import_check and python_bin:
        selected_py = str(python_bin)
        notes += ["python auto-detect", f"  · preflight OK 재사용: {selected_py}"]
    else:
        pyinfo = resolve_ws_python(preferred=python_bin, runtime_env=selected_env)
        notes += ["python auto-detect"] + [f"  · {x}" for x in pyinfo.get("notes", [])[:8]]
        selected_env = pyinfo.get("env") or selected_env
        if not pyinfo.get("ok"):
            init_ws_status_file("import_failed")
            return "import_failed", notes + ["websockets import 가능한 python 없음 → sidecar 실행 중단"]
        selected_py = str(pyinfo.get("python") or WS_PYTHON_BIN)

    notes.append(init_ws_status_file("guard_start"))
    notes.append(ws_runtime_file_note(BOT_DIR / WS_PID_FILE, "pid", remove_if_not_writable=True))
    notes.append(ws_runtime_file_note(BOT_DIR / WS_LOG_FILE, "out", remove_if_not_writable=True))
    notes.append(ws_runtime_file_note(BOT_DIR / "clean_ws_sidecar.log", "log", remove_if_not_writable=False))

    try:
        log_f = open(BOT_DIR / WS_LOG_FILE, "a", encoding="utf-8")
    except Exception as exc:
        return "log_open_failed", notes + [f"log open failed: {exc.__class__.__name__}: {str(exc)[:120]}"]
    try:
        env = dict(selected_env)
        env["TRADING_BOT_DIR"] = str(BOT_DIR)
        env["WS_PYTHON_BIN_RESOLVED"] = selected_py
        p = subprocess.Popen([selected_py, str(active_path)], cwd=str(BOT_DIR), env=env, stdout=log_f, stderr=subprocess.STDOUT, start_new_session=True)
        pid_note = write_ws_pid_file(p.pid)
        time.sleep(3)
        alive = pid_alive(p.pid)
        notes.append(f"direct start pid={p.pid} alive={alive}")
        notes.append(pid_note)
        notes.append(f"python_selected={selected_py}")
        notes.append(f"python_exe={proc_exe(p.pid) or selected_py}")
        state = ws_sidecar_state_dict()
        notes.append(f"state={state.get('verdict')} / raw={state.get('raw_total')} / match={state.get('match_ok')} / age={state.get('age_text')}")
        return "active" if alive else "failed", notes
    finally:
        try:
            log_f.close()
        except Exception:
            pass

def restart_ws_sidecar(python_bin: Optional[str] = None) -> tuple[str, list[str]]:
    svc_ok, notes = ensure_sidecar_service_installed("ws")
    if service_exists(WS_SERVICE):
        notes += cleanup_direct_sidecar_pids("ws")
        rc, out = service_action(WS_SERVICE, "restart", timeout=35)
        time.sleep(3)
        st = ws_sidecar_state_dict()
        notes += [f"관리방식=systemd:{WS_SERVICE}", f"systemctl restart rc={rc} active={is_service_active(WS_SERVICE)}", f"state={st.get('verdict')} / raw={st.get('raw_total')} / match={st.get('match_ok')} / age={st.get('age_text')}"]
        if out:
            notes.append(tail(out, 500))
        return ("active" if st.get("alive") else "failed"), notes
    if not svc_ok:
        notes.append("systemd service 설치 실패 → direct-fallback 임시 재시작")
    # v2.5.24: 기존 sidecar가 살아 있을 때의 PYTHONPATH/HOME을 멈추기 전에 잡아두고,
    # 같은 환경으로 새 sidecar를 시작한다. stop 이후 import 재검사로 실패하던 문제를 막는다.
    pre_env = ws_runtime_env()
    pyinfo = resolve_ws_python(preferred=python_bin, runtime_env=pre_env)
    pre_notes = ["python auto-detect before stop"] + [f"  · {x}" for x in pyinfo.get("notes", [])[:8]]
    if not pyinfo.get("ok"):
        return "import_failed", pre_notes + ["websockets import 가능한 python 없음 → 기존 sidecar는 건드리지 않음"]
    selected_py = str(pyinfo.get("python") or python_bin or WS_PYTHON_BIN)
    selected_env = pyinfo.get("env") or pre_env
    _ok, stop_notes = stop_ws_sidecar()
    active, start_notes = start_ws_sidecar(python_bin=selected_py, runtime_env=selected_env, skip_import_check=True)
    return active, pre_notes + [f"selected_python={selected_py}"] + stop_notes + start_notes

def ws_sidecar_state_dict() -> dict:
    active_path = BOT_DIR / WS_ACTIVE_FILE
    pid_file = read_pid(BOT_DIR / WS_PID_FILE)
    proc_pids = find_ws_sidecar_pids()
    used = pid_file if (pid_file and pid_alive(pid_file)) else (proc_pids[-1] if proc_pids else None)
    pid_repair = "-"
    if used and (not pid_file or pid_file != used):
        pid_repair = write_ws_pid_file(used)
    st = read_json(BOT_DIR / WS_STATUS_FILE)
    if not isinstance(st, dict):
        st = {}
    ts = ws_status_ts(st)
    age = time.time() - ts if ts > 0 else -1
    alive = bool(used and pid_alive(used))
    raw_total = ws_count(st, "raw_total", "raw_count", "raw")
    parse_ok = ws_count(st, "parse_ok", "parse")
    price_ok = ws_count(st, "price_ok", "price")
    amount_ok = ws_count(st, "amount_ok", "amount")
    match_ok = ws_count(st, "match_ok", "match")
    cached = ws_count(st, "cached", "cache")
    fresh = ws_count(st, "fresh")
    last_error = str(st.get("last_error") or "-")
    last_notice = str(st.get("last_notice") or "-")
    # v2.5.25: 구 ws_sidecar가 정상 재구독 문구를 last_error에 남긴 경우도 상태판에서 오류로 보지 않는다.
    if _is_reconnect_notice(last_error):
        if last_notice in {"", "-", "None", "none"}:
            last_notice = last_error
        last_error = "-"
    last_format = str(st.get("last_format") or "-")
    state = str(st.get("state") or "-")
    status_version = str(st.get("version") or "-")
    age_ok = 0 <= age <= 30
    rx_ok = parse_ok > 0 and price_ok > 0 and match_ok > 0
    err_ok = last_error in {"", "-", "None", "none"} or _is_reconnect_notice(last_error)
    mgmt = sidecar_management(used, WS_SERVICE)
    latest_target = choose_latest_ws_sidecar_target()
    deployed_marker = read_file(BOT_DIR / DEPLOYED_WS_FILE) or "?"
    sync = _sidecar_target_sync("ws", ws_target_version(active_path), short_hash(active_path), latest_target, deployed_marker)
    stop_suspect = (not alive) and (state == "종료" or "normal stop" in last_notice.lower() or "signal" in last_error.lower() or "signal" in last_notice.lower())
    if not active_path.exists():
        verdict = "❌ active file 없음"
        ok = False
    elif not sync.get("ok"):
        verdict = f"⚠️ active/latest 불일치: active {ws_target_version(active_path)} / latest {sync.get('target_version')} / deployed {deployed_marker}"
        ok = False
    elif not alive:
        verdict = "❌ 정지"
        ok = False
    elif age_ok and rx_ok and err_ok:
        verdict = "✅ 정상수신"
        ok = True
    elif age_ok and state in {"연결", "수신대기", "대상준비", "guard_starting", "재구독중", "대상변경"} and err_ok:
        verdict = "❔ 실행중 / 수신대기"
        ok = False
    elif age_ok and not err_ok:
        verdict = "⚠️ 실행중 / 수신오류"
        ok = False
    elif alive:
        verdict = "⚠️ 실행중이나 status 오래됨"
        ok = False
    else:
        verdict = "❌ 확인불가"
        ok = False
    return {
        "ok": ok,
        "verdict": verdict,
        "active_file": WS_ACTIVE_FILE,
        "active_exists": active_path.exists(),
        "version": ws_target_version(active_path),
        "status_version": status_version,
        "deployed_marker": deployed_marker,
        "target": sync.get("target_name"),
        "target_version": sync.get("target_version"),
        "target_hash": sync.get("target_hash"),
        "sync_ok": sync.get("ok"),
        "hash": short_hash(active_path),
        "pid_file": pid_file,
        "proc_pids": proc_pids,
        "used_pid": used,
        "alive": alive,
        "python_path": proc_exe(used) or WS_PYTHON_BIN,
        "configured_python": WS_PYTHON_BIN,
        "pid_repair": pid_repair,
        "status": st,
        "age": age,
        "age_text": f"{age:.1f}s" if age >= 0 else "-",
        "raw_total": raw_total,
        "parse_ok": parse_ok,
        "price_ok": price_ok,
        "amount_ok": amount_ok,
        "match_ok": match_ok,
        "cached": cached,
        "fresh": fresh,
        "state": state,
        "last_error": last_error,
        "last_notice": last_notice,
        "last_format": last_format,
        "target_hash": st.get("target_hash", "-"),
        "management": mgmt.get("mode"),
        "service_exists": mgmt.get("service_exists"),
        "in_service": mgmt.get("in_service"),
        "cgroup": mgmt.get("cgroup_short"),
        "management_warning": mgmt.get("warning"),
        "stop_suspect": stop_suspect,
    }

def wait_ws_ready(prev_raw: int = 0, prev_match: int = 0, timeout: float = 22.0) -> tuple[dict, list[str]]:
    """v2.5.20: /gws_upgrade 직후 raw 0이라고 바로 실패로 보지 않고 수신 시작을 기다린다."""
    notes = []
    deadline = time.time() + max(5.0, timeout)
    best = ws_sidecar_state_dict()
    while time.time() < deadline:
        st = ws_sidecar_state_dict()
        best = st
        raw = int(st.get("raw_total") or 0)
        match = int(st.get("match_ok") or 0)
        alive = bool(st.get("alive"))
        err = str(st.get("last_error") or "-")
        err_ok = err in {"", "-", "None", "none"} or _is_reconnect_notice(err)
        if alive and err_ok and (raw > prev_raw or match > prev_match or (raw > 0 and match > 0)):
            notes.append(f"ready raw={raw} match={match} age={st.get('age_text')}")
            return st, notes
        if not alive:
            notes.append("wait: process not alive")
            break
        time.sleep(2)
    notes.append(f"wait_timeout raw={best.get('raw_total',0)} match={best.get('match_ok',0)} verdict={best.get('verdict')}")
    return best, notes

def apply_ws_sidecar_latest(force: bool = False, explicit: Optional[str] = None, restart: bool = True) -> dict:
    """WS sidecar 최신 적용 단일 본선.

    v2.5.29 원칙:
    - hash 동일 + 프로세스 alive + status 최신/오류없음이면 여기서 즉시 return 한다.
    - 이 경우 py_compile/import/old restart path/restart_ws_sidecar()로 절대 내려가지 않는다.
    - 실제 재시작은 hash 변경, force, 프로세스 정지, status 오래됨/오류처럼 이유가 있을 때만 한다.
    """
    target = choose_latest_ws_sidecar_target(explicit=explicit)
    service_notes: list[str] = []
    if target and target.exists():
        _svc_ok, service_notes = ensure_sidecar_service_installed("ws")
    before_state = ws_sidecar_state_dict()
    before_raw = int(before_state.get("raw_total") or 0)
    before_match = int(before_state.get("match_ok") or 0)
    active_path = BOT_DIR / WS_ACTIVE_FILE
    if not target or not target.exists():
        return {"ok": True, "changed": False, "target": explicit or "?", "active": before_state.get("verdict", "유지"), "warning": "ws_sidecar_v*.py 최신 파일 없음 → 기존 상태 유지", "notes": ["대상 파일 없음: 기존 실행은 건드리지 않음"]}

    same_hash = active_path.exists() and short_hash(active_path) == short_hash(target)
    before_age = float(before_state.get("age") or -1)
    alive = bool(before_state.get("alive"))
    err = str(before_state.get("last_error") or "-")
    err_ok = err in {"", "-", "None", "none"} or _is_reconnect_notice(err)
    status_recent = 0 <= before_age <= 90
    state_text = str(before_state.get("state") or "")
    waiting_recent = 0 <= before_age <= 20 and state_text in {"연결", "수신대기", "대상준비", "재구독중", "대상변경"}
    has_rx = int(before_state.get("match_ok") or 0) > 0 or int(before_state.get("raw_total") or 0) > 0 or int(before_state.get("fresh") or 0) > 0 or waiting_recent
    management_ok = str(before_state.get("management") or "").startswith("systemd:") and bool(before_state.get("in_service"))
    ws_healthy_enough = bool(alive and status_recent and err_ok and has_rx and management_ok and before_state.get("sync_ok", True))

    if same_hash and not force and ws_healthy_enough:
        try:
            (BOT_DIR / DEPLOYED_WS_FILE).write_text(target.name + "\n", encoding="utf-8")
        except Exception:
            pass
        return {
            "ok": True, "changed": False, "target": target.name, "version": ws_target_version(target),
            "active": "restart 생략", "backup": "없음", "hash": short_hash(active_path),
            "notes": service_notes + [
                "single-path fast-skip: hash 동일 + alive + status 최신 + 수신흔적 있음 + systemd service pid",
                "py_compile/import/stop/start/restart 경로 완전 우회",
                f"pid 유지: {before_state.get('used_pid') or '-'} / raw {before_state.get('raw_total',0)} / match {before_state.get('match_ok',0)} / age {before_state.get('age_text','-')}",
            ],
            "warning": "변경 없음 → 실행중인 WS 유지 / 재시작 생략",
            "state": before_state.get("verdict"), "raw": before_state.get("raw_total"), "match": before_state.get("match_ok"),
            "selected_python": before_state.get("python_path") or WS_PYTHON_BIN,
            "restart_reason": "-",
        }

    restart_reasons = []
    if force:
        restart_reasons.append("force")
    if not same_hash:
        restart_reasons.append("hash 변경")
    if not alive:
        restart_reasons.append("프로세스 정지")
    if alive and not status_recent:
        restart_reasons.append(f"status 오래됨 {before_state.get('age_text','-')}")
    if alive and not err_ok:
        restart_reasons.append(f"수신오류 {err[:80]}")
    if alive and status_recent and err_ok and not has_rx:
        restart_reasons.append("수신흔적 부족")
    if not management_ok:
        restart_reasons.append("direct-fallback → systemd service 전환")
    if not before_state.get("sync_ok", True):
        restart_reasons.append("active/deployed/latest 불일치")

    okc, comp_out = py_compile(target)
    if not okc:
        return {"ok": False, "changed": False, "target": target.name, "error": "ws_sidecar py_compile 실패", "notes": [tail(comp_out, 1000)], "restart_reason": " / ".join(restart_reasons) or "검수실패"}

    backup = "없음"
    backup_path = None
    changed = False
    previous_deployed_ws = (read_file(BOT_DIR / DEPLOYED_WS_FILE) or "").strip()
    if not same_hash or force:
        if active_path.exists():
            backup_path = BOT_DIR / f"{active_path.name}.backup_guard_apply_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copy2(active_path, backup_path)
            backup = backup_path.name
        tmp = BOT_DIR / f"{active_path.name}.guard_tmp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(target, tmp)
        if sha256_file(tmp) != sha256_file(target):
            tmp.unlink(missing_ok=True)
            return {"ok": False, "changed": False, "target": target.name, "error": "ws 임시복사 hash 불일치", "restart_reason": " / ".join(restart_reasons)}
        os.replace(tmp, active_path)
        changed = True
    try:
        (BOT_DIR / DEPLOYED_WS_FILE).write_text(target.name + "\n", encoding="utf-8")
    except Exception:
        pass

    notes = service_notes + ["restart path entered only because: " + (" / ".join(restart_reasons) or "unknown")]
    selected_py = before_state.get("python_path") or WS_PYTHON_BIN
    active = "restart 생략"
    ready_state = before_state
    if restart:
        active, restart_notes = restart_ws_sidecar(python_bin=str(selected_py))
        notes += restart_notes
        ready_state, wait_notes = wait_ws_ready(prev_raw=0 if changed else before_raw, prev_match=0 if changed else before_match, timeout=18.0)
        notes += wait_notes
    else:
        ready_state = ws_sidecar_state_dict()
        notes.append("restart=False → 교체만 하고 재시작 생략")

    ready_err = str(ready_state.get("last_error") or "-")
    ws_ok = bool(ready_state.get("alive")) and (int(ready_state.get("parse_ok") or 0) > 0 or int(ready_state.get("raw_total") or 0) > 0) and (ready_err in {"", "-", "None", "none"} or _is_reconnect_notice(ready_err))
    rollback_note = ""
    if not ws_ok and changed and backup_path and backup_path.exists():
        try:
            shutil.copy2(backup_path, active_path)
            rollback_note = f"rollback={backup_path.name}"
            (BOT_DIR / DEPLOYED_WS_FILE).write_text((previous_deployed_ws or target.name) + "\n", encoding="utf-8")
            active2, rb_notes = restart_ws_sidecar(python_bin=str(selected_py))
            rb_state, rb_wait = wait_ws_ready(timeout=14.0)
            notes += [rollback_note, f"rollback_restart={active2}"] + rb_notes + rb_wait
            ready_state = rb_state
        except Exception as exc:
            notes.append(f"rollback 실패: {exc.__class__.__name__}: {str(exc)[:160]}")
    final_ok = bool(ready_state.get("alive")) and (int(ready_state.get("parse_ok") or 0) > 0 or int(ready_state.get("raw_total") or 0) > 0)
    return {"ok": final_ok, "changed": changed, "target": target.name, "version": ws_target_version(target), "active": active, "backup": backup, "hash": short_hash(active_path), "notes": notes, "warning": rollback_note or ("재시작 수행: " + (" / ".join(restart_reasons) or "unknown")), "state": ready_state.get("verdict"), "raw": ready_state.get("raw_total"), "match": ready_state.get("match_ok"), "selected_python": selected_py, "restart_reason": " / ".join(restart_reasons) or "-"}

def gws_state_text() -> str:
    d = ws_sidecar_state_dict()
    proc = ",".join(map(str, d.get("proc_pids") or [])) or "-"
    return "\n".join([
        "🛰 웹소켓 직원 /gws_state",
        str(d.get("verdict", "?")),
        f"- active_file: {d.get('active_file')} / exists={d.get('active_exists')} / active_version={d.get('version')} / status_version={d.get('status_version','-')} / hash={d.get('hash')}",
        f"- deployed_marker: {d.get('deployed_marker','?')} / target {d.get('target','?')} / target_version {d.get('target_version','?')} / target_hash {d.get('target_hash','-')} / sync={d.get('sync_ok')}",
        f"- pid_file: {d.get('pid_file') or '-'} / proc: {proc} / used: {d.get('used_pid') or '-'} / alive={d.get('alive')}",
        f"- 관리방식: {d.get('management','-')} / 경고: {d.get('management_warning','-')}",
        f"- cgroup: {d.get('cgroup','-')}",
        f"- python: {d.get('python_path') or '-'} / configured: {d.get('configured_python') or '-'}",
        f"- python후보: {', '.join(ws_python_candidates()[:4])}",
        f"- status_age: {d.get('age_text','-')} / state: {d.get('state','-')} / last_error: {d.get('last_error','-')}",
        f"- notice: {d.get('last_notice','-')}",
        f"- raw {d.get('raw_total',0)} / parse {d.get('parse_ok',0)} / price {d.get('price_ok',0)} / amount {d.get('amount_ok',0)} / match {d.get('match_ok',0)} / format {d.get('last_format','-')}",
        f"- cache {d.get('cached',0)} / fresh {d.get('fresh',0)} / pid_note {d.get('pid_repair','-')}",
        f"- files: cache={WS_CACHE_FILE} / status={WS_STATUS_FILE} / log={WS_LOG_FILE}",
        "- 시작: /gws_start / 중지: /gws_stop / 재시작: /gws_restart / 업그레이드: /gws_upgrade",
    ])

def gws_log(lines: int = 80) -> str:
    txt = read_file_tail(BOT_DIR / WS_LOG_FILE, max_bytes=120_000)
    return f"🧾 웹소켓 직원 로그 /gwslog {lines}\n" + (tail(txt, 2600) if txt.strip() else "- 로그 없음")

def gws_start_text() -> str:
    active, notes = start_ws_sidecar()
    return "\n".join(["▶️ 웹소켓 직원 시작 /gws_start", f"- active: {active}", f"- version: {ws_target_version(BOT_DIR / WS_ACTIVE_FILE)}"] + [f"- {x}" for x in notes] + ["", "다음 확인: /gws_state /ws_status"])

def gws_stop_text() -> str:
    ok, notes = stop_ws_sidecar()
    return "\n".join(["⏹ 웹소켓 직원 중지 /gws_stop", f"- ok: {ok}"] + [f"- {x}" for x in notes])

def gws_restart_text() -> str:
    active, notes = restart_ws_sidecar()
    return "\n".join(["🔁 웹소켓 직원 재시작 /gws_restart", f"- active: {active}", f"- version: {ws_target_version(BOT_DIR / WS_ACTIVE_FILE)}"] + [f"- {x}" for x in notes] + ["", "다음 확인: /gws_state /ws_status"])

def format_ws_apply_result(res: dict) -> str:
    ok = "✅" if res.get("ok") else "❌"
    changed = "교체+재시작" if res.get("changed") else ("변경없음/재시작생략" if str(res.get("active")) == "restart 생략" else "변경없음/필요재시작")
    lines = [f"{ok} ws_sidecar {changed}"]
    for k in ["target", "version", "active", "restart_reason", "selected_python", "state", "raw", "match", "backup", "hash", "error", "warning"]:
        if res.get(k) not in (None, ""):
            lines.append(f"- {k}: {res.get(k)}")
    if res.get("notes"):
        lines.append("- notes:")
        lines.extend(f"  · {str(x)[:220]}" for x in res.get("notes", [])[:8])
    return "\n".join(lines)

def gpaper_log(lines: int = 80) -> str:
    """페이퍼봇 로그를 실행방식과 무관하게 확인한다.
    systemd journal이 비어도 paper_bot.log / process.err / process.log / pid 상태를 같이 보여준다.
    """
    lines = max(20, min(300, int(lines or 80)))
    parts = [f"🧾 페이퍼봇 로그 /gpaperlog {lines}", ""]
    active_path = BOT_DIR / PAPER_ACTIVE_FILE
    pid_path = BOT_DIR / PAPER_PID_FILE
    pid = read_pid(pid_path)
    alive = bool(pid and pid_alive(pid))
    svc_exists = service_exists(PAPER_SERVICE)
    svc_active = is_service_active(PAPER_SERVICE) if svc_exists else "no_service"
    st = read_json(BOT_DIR / "paper_bot_status.json")
    age = "-"
    try:
        uts = float(st.get("updated_at", 0) or 0)
        age = f"{max(0, time.time()-uts):.0f}s" if uts > 0 else "-"
    except Exception:
        pass
    parts += [
        "상태",
        "- 방식: fast-tail 읽기 / 큰 로그 통째읽기 안 함",
        f"- service: {PAPER_SERVICE} / exists={svc_exists} / active={svc_active}",
        f"- active_file: {PAPER_ACTIVE_FILE} / version={extract_paper_version(active_path)} / hash={short_hash(active_path)}",
        f"- pid: {pid or '-'} / alive={alive} / status_age={age}",
        "",
    ]

    shown = False
    if svc_exists:
        _rc, out = run(["journalctl", "-u", PAPER_SERVICE, "--no-pager", "-n", str(lines)], timeout=20)
        if (out or "").strip():
            parts += ["journalctl", tail(out, 1800), ""]
            shown = True
    for label, path in [
        ("paper_bot_error.log", BOT_DIR / "paper_bot_error.log"),
        ("paper_bot.log", BOT_DIR / "paper_bot.log"),
        (PAPER_PROCESS_ERR, BOT_DIR / PAPER_PROCESS_ERR),
        (PAPER_PROCESS_LOG, BOT_DIR / PAPER_PROCESS_LOG),
    ]:
        txt = read_file_tail(path, max_bytes=120_000)
        if txt.strip():
            parts += [label, tail(txt, 1800), ""]
            shown = True
            if len("\n".join(parts)) > 3300:
                break
    if not shown:
        parts += [
            "❔ 로그 내용이 비어있음",
            "- 흔한 원인: paper_bot이 direct 실행인데 journal만 본 경우, 또는 시작 직후 아직 로그가 적히지 않은 경우",
            "- 다음 확인: /gpaper_restart 후 /gpaperlog 120",
        ]
    return "\n".join(parts).strip()

def gpaper_state_text() -> str:
    snap = paper_runtime_snapshot()
    reasons = list(snap.get('reasons') or [])
    verdict = '✅ 정상: paper runtime 단일선 exact 일치' if snap.get('ok') else '⚠️ CHECK: ' + (' / '.join(reasons[:5]) if reasons else 'runtime 증거 부족')
    started = snap.get('process_started_at')
    try:
        started_text = datetime.fromtimestamp(float(started)).strftime('%Y-%m-%d %H:%M:%S') if started else '-'
    except Exception:
        started_text = '-'
    return '\n'.join([
        '🧪 페이퍼봇 상태 /gpaper_state · v995 one-command release spine',
        verdict,
        f"- service: {snap.get('service')} / active={snap.get('service_active')} / MainPID={snap.get('main_pid') or '-'} / alive={snap.get('main_alive')}",
        f"- active_file: {snap.get('active_file')} / version={snap.get('active_version')} / build={snap.get('active_build')} / hash={snap.get('active_hash')}",
        f"- pid identity: pid_file={snap.get('pid_file') or '-'} / status={snap.get('status_pid') or '-'} / writer={snap.get('writer_pid') or '-'} / proc={','.join(map(str,snap.get('proc_pids') or [])) or '-'}",
        f"- writer: owner={snap.get('writer_owner') or '-'} / expected={snap.get('expected_owner') or '-'} / count={snap.get('writer_count')} / seq={snap.get('write_seq') or '-'}",
        f"- status: version={snap.get('status_version') or '-'} / build={snap.get('status_build') or '-'} / age={float(snap.get('status_age') or 0):.1f}s / running={snap.get('running')} / stop_reason={snap.get('stop_reason') or '-'}",
        f"- process start: {started_text} / instance={snap.get('runtime_instance_id') or '-'}",
        f"- cmdline: {str(snap.get('cmdline') or '-')[:220]}",
        (lambda io: f"- I/O v1018: decision save {io.get('decision_save_calls',0)} / write {io.get('decision_write_count',0)} / skip {io.get('decision_noop_skip_count',0)} · seed {io.get('seed_calls_v1018',0)} / no-op {io.get('seed_noop_count_v1018',0)} / OPEN변경 {io.get('seed_open_change_count_v1018',0)} / CLOSED변경 {io.get('seed_closed_change_count_v1018',0)} · CLOSED증분읽기 {io.get('closed_incremental_read_calls_v1018',0)}회 {io.get('closed_incremental_read_bytes_v1018',0)}B / rows {io.get('closed_incremental_rows_v1018',0)} / 복구tail {io.get('closed_recovery_tail_scans_v1018',0)} · performance check {io.get('performance_check_count',0)} / write {io.get('performance_write_count_v1017',0)} / skip {io.get('performance_skip_count_v1017',0)} · reason={io.get('performance_last_reason','-')}")(snap.get('paper_io_v1018') or snap.get('paper_io_v1017') or {}),
        '- 판정: 불일치를 자동 보정하지 않고 CHECK로 공개 · 원장은 건드리지 않음',
        '- 로그 확인: /gpaperlog 120',
        '- 재시작: /gpaper_restart',
    ])

def gpaper_service_text() -> str:
    svc_exists = service_exists(PAPER_SERVICE)
    svc_active = is_service_active(PAPER_SERVICE) if svc_exists else "no_service"
    unit_path = f"/etc/systemd/system/{PAPER_SERVICE}.service"
    lines = [
        "🧩 페이퍼봇 서비스화 /gpaper_service",
        ("✅ systemd 등록됨" if svc_exists else "⚠️ systemd 미등록: paper 실행 금지 / service 설치 필요"),
        f"- service: {PAPER_SERVICE} / exists={svc_exists} / active={svc_active}",
        f"- unit: {unit_path}",
        f"- active_file: {BOT_DIR / PAPER_ACTIVE_FILE}",
        f"- env: {ENV_PATH}",
        "",
        "설치가 필요하면 SSH에서 전달한 install_paper_service.sh를 실행",
        "설치 후 확인",
        f"- systemctl status {PAPER_SERVICE} --no-pager",
        "- /gpaper_state",
        "- /pstatus",
    ]
    return "\n".join(lines)

def gpaper_restart_text() -> str:
    active, notes = restart_paper_bot()
    return "\n".join(["🔁 페이퍼봇 재시작 /gpaper_restart", f"- active: {active}", f"- version: {extract_paper_version(BOT_DIR / PAPER_ACTIVE_FILE)}"] + [f"- {n}" for n in notes])

def guard_self_upgrade(force: bool = False, explicit: Optional[str] = None) -> str:
    ok, steps = git_update()
    if not ok:
        return "❌ 가드봇 자체 업그레이드 실패\n- GitHub 갱신 실패\n\n" + "\n\n".join(steps)
    target = BOT_DIR / explicit if explicit else find_latest_guard_file()
    if not target or not target.exists():
        return "❌ 가드봇 자체 업그레이드 실패\n- backga_guard_bot_v*.py 파일을 못 찾음"
    active = BOT_DIR / GUARD_ACTIVE_FILE
    okc, out = py_compile(target)
    if not okc:
        return f"❌ 가드봇 자체 업그레이드 실패\n- py_compile 실패: {target.name}\n{tail(out, 1800)}"
    same = active.exists() and short_hash(active) == short_hash(target)
    if same and not force:
        return f"✅ 가드봇 자체 업그레이드 불필요\n- target: {target.name}\n- active: {GUARD_ACTIVE_FILE}\n- hash: {short_hash(active)}\n- 필요하면 /gguard_restart"
    backup = None
    if active.exists():
        backup = BOT_DIR / f"{active.name}.backup_guard_self_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(active, backup)
    shutil.copy2(target, active)
    (BOT_DIR / DEPLOYED_GUARD_FILE).write_text(target.name + "\n", encoding="utf-8")
    rc, out = run(["systemctl", "restart", GUARD_SERVICE], timeout=30)
    # 재시작되면 이 응답이 끝까지 못 갈 수 있어도, 대부분은 전송 후 처리된다.
    return f"🛡 가드봇 자체 업그레이드 실행\n- target: {target.name}\n- active: {GUARD_ACTIVE_FILE}\n- backup: {backup.name if backup else '없음'}\n- restart rc: {rc}\n- 다음 확인: /guard /gdeploy"

def progress_notify(text: str) -> None:
    """긴 업그레이드 중 사용자가 멈춘 것으로 오해하지 않게 즉시 단계 메시지를 보낸다."""
    try:
        send(ALLOWED_CHAT_ID, str(text or ""))
    except Exception:
        pass

def guard_post_upgrade_path() -> Path:
    return BOT_DIR / GUARD_POST_UPGRADE_FILE

def _release_inflight_path() -> Path:
    """Legacy v1002 claim file. v1003 never uses it for active releases."""
    return BOT_DIR / '.guard_post_upgrade_request.inflight.json'

def _release_result_path() -> Path:
    return BOT_DIR / GUARD_RELEASE_RESULT_FILE

def _release_final_pending_path() -> Path:
    """Saved final message outbox only. It never triggers apply or verify."""
    return BOT_DIR / '.guard_release_final_pending.json'

def _release_apply_lock_path() -> Path:
    """One-shot claim for the post-restart apply.

    The pending request is never renamed to an inflight stage.  A separate
    O_EXCL lock prevents duplicate entry without turning a live same-PID call
    into a false "process died" result.
    """
    return BOT_DIR / '.guard_release_apply.lock'

def _read_release_apply_lock() -> dict:
    try:
        obj = json.loads(_release_apply_lock_path().read_text(encoding='utf-8'))
        return obj if isinstance(obj, dict) else {}
    except Exception:
        return {}

def _claim_release_apply(req: dict) -> tuple[bool, dict, str]:
    path = _release_apply_lock_path()
    payload = {
        'schema': 'guard_release_apply_lock_v1005',
        'request_id': req.get('request_id'),
        'bundle': req.get('explicit'),
        'pid': os.getpid(),
        'started_ts': time.time(),
        'started_at': now(),
    }
    try:
        fd = os.open(str(path), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError:
        lock = _read_release_apply_lock()
        try:
            lock_pid = int(lock.get('pid') or 0)
        except Exception:
            lock_pid = 0
        if lock_pid and pid_alive(lock_pid):
            return False, lock, 'active'
        return False, lock, 'stale'
    try:
        raw = (json.dumps(payload, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
        os.write(fd, raw)
        os.fsync(fd)
    finally:
        os.close(fd)
    return True, payload, 'claimed'

def _release_apply_lock(req: dict) -> None:
    path = _release_apply_lock_path()
    lock = _read_release_apply_lock()
    if str(lock.get('request_id') or '') != str(req.get('request_id') or ''):
        return
    try:
        if int(lock.get('pid') or 0) != os.getpid():
            return
    except Exception:
        return
    try:
        path.unlink(missing_ok=True)
    except Exception:
        pass

def _release_bundle_path(explicit: Optional[str]) -> Optional[Path]:
    name = Path(str(explicit or '')).name
    if not name or not name.startswith('coinbot_update_v') or not name.endswith('.zip'):
        return None
    path = BOT_DIR / name
    return path if path.exists() else None

def _release_bundle_digest(explicit: Optional[str]) -> str:
    path = _release_bundle_path(explicit)
    try:
        return sha256_file(path) if path else ''
    except Exception:
        return ''

def _simple_release_request(data: dict) -> dict:
    """Normalize the single v1004 post-restart request.

    The active request stays in one pending file until the new guard is fully
    running and has finished the remaining bundle apply. There is no pending →
    inflight rename and no startup-time apply.
    """
    if not isinstance(data, dict) or data.get('action') != 'continue_gupgrade':
        return {}
    explicit = Path(str(data.get('explicit') or '')).name
    if not explicit:
        return {}
    digest = str(data.get('bundle_digest') or _release_bundle_digest(explicit))
    raw_stage = str(data.get('stage') or 'waiting_guard_ready')
    # v1002 and earlier guards wrote `pending_apply` before handing the same
    # request file to the newly restarted guard. v1003 introduced the clearer
    # `waiting_guard_ready` name but accidentally preserved the legacy value,
    # causing a false stage error before the remainder could run.
    if raw_stage in {'pending_apply', 'pending', 'waiting_guard'}:
        raw_stage = 'waiting_guard_ready'
    return {
        'schema': 'guard_release_after_ready_v1005',
        'action': 'continue_gupgrade',
        'request_id': str(data.get('request_id') or data.get('job_id') or f"ready-{digest[:12]}-{int(time.time()*1000)}"),
        'explicit': explicit,
        'bundle_digest': digest,
        'force': bool(data.get('force')),
        'stage': raw_stage,
        'created_ts': float(data.get('created_ts') or time.time()),
        'created_at': str(data.get('created_at') or now()),
        'started_pid': int(data.get('started_pid') or 0),
        'started_ts': float(data.get('started_ts') or 0),
        'source_schema': str(data.get('schema') or 'legacy'),
        'post_commands': _normalize_post_upgrade_commands_v1030(data.get('post_commands') or []),
    }

def _load_release_job(max_age_sec: float = 7200.0) -> dict:
    obj = _simple_release_request(read_json(guard_post_upgrade_path()) or {})
    if not obj:
        return {}
    try:
        age = time.time() - float(obj.get('created_ts') or 0)
    except Exception:
        return {}
    if age < -60 or age > max_age_sec:
        return {}
    return obj

def write_guard_post_upgrade_request(force: bool = False, explicit: Optional[str] = None, post_commands=None) -> dict:
    explicit_name = Path(str(explicit or '')).name
    if not explicit_name:
        raise ValueError('continuation bundle name missing')
    digest = _release_bundle_digest(explicit_name)
    req = {
        'schema': 'guard_release_after_ready_v1005',
        'action': 'continue_gupgrade',
        'request_id': f"ready-{digest[:12]}-{int(time.time()*1000)}",
        'explicit': explicit_name,
        'bundle_digest': digest,
        'force': bool(force),
        'stage': 'waiting_guard_ready',
        'created_ts': time.time(),
        'created_at': now(),
        'started_pid': 0,
        'started_ts': 0,
        'post_commands': _normalize_post_upgrade_commands_v1030(post_commands),
    }
    # Start a clean one-shot handoff. Old v996-v1002 claim/outbox files must
    # never block or resume the new request. The previous final result remains
    # preserved in GUARD_RELEASE_RESULT_FILE.
    for stale in (_release_inflight_path(), _release_final_pending_path()):
        try:
            stale.unlink(missing_ok=True)
        except Exception:
            pass
    write_json(guard_post_upgrade_path(), req)
    return req

def _write_release_result(req: dict, ok: bool, text: str, delivered: bool = False, delivery_attempts: int = 0) -> dict:
    result = {
        'schema': 'guard_release_after_ready_result_v1005',
        'request_id': req.get('request_id'),
        'bundle': req.get('explicit'),
        'bundle_digest': req.get('bundle_digest'),
        'ok': bool(ok),
        'stage': ('done' if ok else 'failed') if delivered else 'result_ready',
        'delivered': bool(delivered),
        'delivery_attempts': int(delivery_attempts or 0),
        'finished_ts': time.time(),
        'finished_at': now(),
        'text': str(text or ''),
        'post_commands': _normalize_post_upgrade_commands_v1030(req.get('post_commands') or []),
    }
    if delivered:
        result['delivered_ts'] = time.time()
        result['delivered_at'] = now()
    write_json(_release_result_path(), result)
    return result

def _queue_release_final(req: dict, ok: bool, text: str) -> dict:
    payload = {
        'schema': 'guard_release_final_pending_v1003',
        'request_id': req.get('request_id'),
        'bundle': req.get('explicit'),
        'bundle_digest': req.get('bundle_digest'),
        'ok': bool(ok),
        'text': str(text or ''),
        'delivery_attempts': 0,
        'created_ts': time.time(),
        'created_at': now(),
        'post_commands': _normalize_post_upgrade_commands_v1030(req.get('post_commands') or []),
    }
    write_json(_release_final_pending_path(), payload)
    _write_release_result(req, ok, text, delivered=False, delivery_attempts=0)
    return payload

def _deliver_pending_release_result_once() -> bool:
    """Send only the saved final message; never reapply or reverify."""
    path = _release_final_pending_path()
    obj = read_json(path) or {}
    if not isinstance(obj, dict) or not str(obj.get('text') or '').strip():
        return False
    attempts = int(obj.get('delivery_attempts') or 0) + 1
    obj['delivery_attempts'] = attempts
    obj['last_attempt_ts'] = time.time()
    obj['last_attempt_at'] = now()
    write_json(path, obj)
    delivered = bool(send(ALLOWED_CHAT_ID, str(obj.get('text') or '')))
    req = {
        'request_id': obj.get('request_id'),
        'explicit': obj.get('bundle'),
        'bundle_digest': obj.get('bundle_digest'),
        'post_commands': _normalize_post_upgrade_commands_v1030(obj.get('post_commands') or []),
    }
    _write_release_result(req, bool(obj.get('ok')), str(obj.get('text') or ''), delivered=delivered, delivery_attempts=attempts)
    if delivered:
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass
    return delivered

def _v1165_apply_text_failed(text: str) -> bool:
    """Classify a component apply response without hiding rollback/failure text."""
    value = str(text or "").strip()
    if not value:
        return False
    if value.startswith(("❌", "🚀 ❌", "⚠️ 적용 실패")):
        return True
    return any(token in value for token in (
        "업그레이드 실패 후 자동복구",
        "적용 실패 후 자동복구",
        "Main process exited, code=exited",
    ))


def _bundle_ledger_event_key_v1238(kind: str, row: dict) -> str:
    """Stable append-only duplicate key for packaged ledger events."""
    if kind == "issue":
        parts = (
            row.get("issue_id"), row.get("ts") or row.get("time"),
            row.get("status") or row.get("event_type"), row.get("title"),
        )
    else:
        parts = (
            row.get("change_id") or row.get("issue_id"), row.get("ts") or row.get("time"),
            row.get("event") or row.get("event_type"), row.get("version"), row.get("status"),
        )
    stable = json.dumps(parts, ensure_ascii=False, separators=(",", ":"), default=str)
    return hashlib.sha256(stable.encode("utf-8")).hexdigest()


def _bundle_ledger_specs_v1238(manifest: dict) -> list[tuple[str, str]]:
    raw = manifest.get("ledger_event_files")
    specs: list[tuple[str, str]] = []
    if isinstance(raw, dict):
        for kind, values in raw.items():
            canonical = "change_verify" if str(kind).strip().lower() in {"change", "change_verify", "change_verify_ledger"} else "issue" if str(kind).strip().lower() in {"issue", "issue_ledger"} else ""
            if not canonical:
                continue
            seq = values if isinstance(values, list) else [values]
            for value in seq:
                if isinstance(value, str) and value.strip():
                    specs.append((canonical, value.strip()))
    elif isinstance(raw, list):
        for item in raw:
            if not isinstance(item, dict):
                continue
            kind = str(item.get("kind") or "").strip().lower()
            canonical = "change_verify" if kind in {"change", "change_verify", "change_verify_ledger"} else "issue" if kind in {"issue", "issue_ledger"} else ""
            path = str(item.get("path") or "").strip()
            if canonical and path:
                specs.append((canonical, path))
    return specs


def _append_packaged_ledger_events_v1238(bundle_dir: Path, manifest: dict) -> tuple[bool, list[str]]:
    """Validate every packaged event file before any append, then append once.

    Parsing/path/schema failures are detected across the complete declared set
    before either canonical ledger is opened for append. Existing ledgers are
    never rewritten; duplicate events are skipped by stable keys.
    """
    specs = _bundle_ledger_specs_v1238(manifest)
    if not specs:
        return True, ["ledger events: SKIP(미지정)"]
    targets = {
        "issue": BOT_DIR / "issue_ledger.jsonl",
        "change_verify": BOT_DIR / "change_verify_ledger.jsonl",
    }
    notes: list[str] = []
    prepared: list[tuple[str, str, list[dict]]] = []

    # Phase 1: preflight every source. Do not touch either live ledger here.
    for kind, rel_text in specs:
        rel = Path(rel_text)
        if rel.is_absolute() or ".." in rel.parts:
            return False, notes + [f"ledger events invalid path: {rel_text}"]
        src = bundle_dir / rel
        if not src.exists() or not src.is_file():
            return False, notes + [f"ledger events missing: {rel_text}"]
        rows: list[dict] = []
        try:
            for line_no, raw_line in enumerate(src.read_text(encoding="utf-8").splitlines(), start=1):
                if not raw_line.strip():
                    continue
                row = json.loads(raw_line)
                if not isinstance(row, dict):
                    raise ValueError(f"line {line_no} is not an object")
                if kind == "issue" and not str(row.get("issue_id") or "").strip():
                    raise ValueError(f"line {line_no} missing issue_id")
                if kind == "change_verify" and not str(row.get("issue_id") or row.get("change_id") or "").strip():
                    raise ValueError(f"line {line_no} missing issue_id/change_id")
                rows.append(row)
        except Exception as exc:
            return False, notes + [f"ledger events preflight fail {rel_text}: {type(exc).__name__}: {exc}"]
        prepared.append((kind, rel_text, rows))

    notes.append(f"ledger events preflight: PASS files={len(prepared)}")

    # Phase 2: append only after the complete declared set passed preflight.
    for kind, rel_text, rows in prepared:
        target = targets[kind]
        target.parent.mkdir(parents=True, exist_ok=True)
        appended = duplicate = 0
        try:
            with target.open("a+", encoding="utf-8") as fh:
                fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
                fh.seek(0)
                existing: set[str] = set()
                for existing_line in fh:
                    try:
                        obj = json.loads(existing_line)
                    except Exception:
                        continue
                    if isinstance(obj, dict):
                        existing.add(_bundle_ledger_event_key_v1238(kind, obj))
                fh.seek(0, os.SEEK_END)
                for row in rows:
                    key = _bundle_ledger_event_key_v1238(kind, row)
                    if key in existing:
                        duplicate += 1
                        continue
                    fh.write(json.dumps(row, ensure_ascii=False, separators=(",", ":"), default=str) + "\n")
                    existing.add(key)
                    appended += 1
                fh.flush()
                os.fsync(fh.fileno())
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        except Exception as exc:
            return False, notes + [f"ledger append fail {target.name}: {type(exc).__name__}: {exc}"]
        notes.append(f"ledger {target.name}: append {appended} / duplicate {duplicate} / source {rel_text}")
    return True, notes

def _apply_release_bundle_once(req: dict) -> tuple[bool, str]:
    """Apply the bundle remainder once after the guard self restart."""
    bundle = _release_bundle_path(str(req.get('explicit') or ''))
    if not bundle:
        return False, f"bundle missing: {req.get('explicit') or '-'}"
    actual_digest = sha256_file(bundle)
    expected_digest = str(req.get('bundle_digest') or '')
    if expected_digest and expected_digest != actual_digest:
        return False, f"bundle digest mismatch {expected_digest[:12]}->{actual_digest[:12]}"
    work = BOT_DIR / f".bundle_continue_once_{os.getpid()}_{time.time_ns()}"
    results=[]; notes=[]; manifest={}
    try:
        work.mkdir(parents=True, exist_ok=False)
        with zipfile.ZipFile(bundle, 'r') as z:
            bad = z.testzip()
            if bad:
                return False, f"zip damage: {bad}"
            z.extractall(work)
        manifest_path = work / 'DEPLOY_BUNDLE.json'
        manifest = read_json(manifest_path) if manifest_path.exists() else _bundle_manifest_defaults(work)
        if not isinstance(manifest, dict):
            return False, 'DEPLOY_BUNDLE.json invalid'
        manifest = _normalize_bundle_manifest(manifest, work)
        ledger_ok, ledger_notes = _append_packaged_ledger_events_v1238(work, manifest)
        notes += ledger_notes
        if not ledger_ok:
            return False, "\n".join(notes)
        notes += _copy_bundle_files_to_repo(work, manifest)

        manifest_py=set()
        for key in ('main','paper','guard','ws','micro','ws_sidecar','micro_sidecar'):
            if manifest.get(key): manifest_py.add(str(manifest.get(key)))
        workers = manifest.get('workers') if isinstance(manifest.get('workers'), dict) else {}
        for fname in workers.values():
            if fname: manifest_py.add(str(fname))
        support_files = manifest.get('support_files') if isinstance(manifest.get('support_files'), list) else []
        for rel in support_files:
            if isinstance(rel,str) and rel.endswith('.py'):
                manifest_py.add(rel)
        for name in [x for x in os.listdir(work) if x.endswith('.py') and x not in manifest_py]:
            okc,out=py_compile(BOT_DIR/name)
            if not okc:
                return False, f"py_compile failed {name}: {tail(out,600)}"

        for name,fname in workers.items():
            if name not in WORKER_SPECS or not fname:
                continue
            raw=apply_worker_latest(name, force=bool(req.get('force')), explicit=fname, restart=True)
            rendered=format_worker_apply_result(raw)
            results.append(f"worker:{name}\n{tail(rendered,1000)}")
            if isinstance(raw,dict) and not bool(raw.get('ok', True)):
                return False, '\n\n'.join(results)

        if manifest.get('main'):
            rendered=apply_main_latest_auto(force=bool(req.get('force')), explicit=str(manifest.get('main')), skip_git=True)
            results.append(f"main\n{tail(rendered,1200)}")
            if _v1165_apply_text_failed(rendered):
                return False, '\n\n'.join(results)
        if manifest.get('paper'):
            raw=apply_paper_latest(force=bool(req.get('force')), explicit=str(manifest.get('paper')))
            rendered=format_paper_apply_result(raw)
            results.append(f"paper\n{tail(rendered,1200)}")
            if isinstance(raw,dict) and not bool(raw.get('ok',True)):
                return False, '\n\n'.join(results)
        ws_manifest=manifest.get('ws') or manifest.get('ws_sidecar')
        if ws_manifest:
            raw=apply_ws_sidecar_latest(force=bool(req.get('force')), explicit=str(ws_manifest), restart=True)
            rendered=format_ws_apply_result(raw)
            results.append(f"ws\n{tail(rendered,900)}")
            if isinstance(raw,dict) and not bool(raw.get('ok',True)):
                return False, '\n\n'.join(results)
        micro_manifest=manifest.get('micro') or manifest.get('micro_sidecar')
        if micro_manifest:
            raw=apply_micro_sidecar_latest(force=bool(req.get('force')), explicit=str(micro_manifest), restart=True)
            rendered=format_micro_apply_result(raw)
            results.append(f"micro\n{tail(rendered,900)}")
            if isinstance(raw,dict) and not bool(raw.get('ok',True)):
                return False, '\n\n'.join(results)

        # v1257: guard-changing bundles continue through this path after the
        # guard self-restart. Retired experiment services must be stopped and
        # disabled here before the single final verification; otherwise a
        # correct v1257 bundle would always finish CHECK while old workers keep
        # writing competing shadow state. Files and historical ledgers remain.
        if manifest.get('retire_services'):
            retire_ok, retire_notes = _retire_services_v1257(manifest.get('retire_services'))
            results.append('retire_services\n' + '\n'.join(retire_notes))
            if not retire_ok:
                return False, '\n\n'.join(results)

        # One verification pass only. A failed verification is reported once;
        # it never restarts or reapplies components.
        verify = grelease_verify_text(manifest)
        verify_ok = str(verify).startswith('✅')
        body = '\n'.join([
            f"{'✅' if verify_ok else '⚠️'} 자동 배포 최종결과 {'PASS' if verify_ok else 'CHECK'}",
            f"- bundle: {bundle.name}",
            '- 방식: 가드 재시작 뒤 나머지 1회 적용 · 검수 1회 · 재시도 없음',
            f"- 적용 대상: {', '.join([x for x in ['workers' if workers else '', 'main' if manifest.get('main') else '', 'paper' if manifest.get('paper') else '', 'ws' if ws_manifest else '', 'micro' if micro_manifest else ''] if x]) or 'guard only'}",
            verify,
        ])
        return verify_ok, body + ('\n\n[적용]\n' + '\n\n'.join(results) if results else '')
    except Exception as exc:
        return False, f"⚠️ 자동 이어가기 예외: {exc.__class__.__name__}: {exc}\n{tail(traceback.format_exc(),5000)}"
    finally:
        shutil.rmtree(work, ignore_errors=True)

def _guard_is_stable_release_owner() -> tuple[bool, str]:
    """Only the fully started systemd MainPID may apply the bundle remainder."""
    pid = os.getpid()
    main_pid = _service_main_pid(GUARD_SERVICE)
    if not main_pid:
        return False, 'guard MainPID unavailable'
    if int(main_pid) != int(pid):
        return False, f'guard MainPID mismatch {main_pid}!={pid}'
    return True, f'guard MainPID={pid}'

def resume_guard_release_job() -> bool:
    """Apply the post-restart remainder once under an exclusive claim.

    v1004 persisted ``stage=applying`` and then treated every later read of that
    stage as a dead process, even when ``started_pid == os.getpid()``.  The
    server output proved that false diagnosis.  v1005 keeps the request in one
    waiting stage and uses a separate O_EXCL lock.  A live lock means another
    call is already working and is never reported as a failure.
    """
    pending = guard_post_upgrade_path()
    req = _load_release_job()
    if not req:
        try:
            _release_inflight_path().unlink(missing_ok=True)
        except Exception:
            pass
        return False

    stable, stable_note = _guard_is_stable_release_owner()
    if not stable:
        return False

    stage = str(req.get('stage') or 'waiting_guard_ready')
    if stage in {'pending_apply', 'pending', 'waiting_guard'}:
        stage = 'waiting_guard_ready'
    if stage == 'applying':
        # Legacy v1004 evidence.  Do not call it a dead process when the stored
        # PID equals the current MainPID; close only truly abandoned legacy work.
        try:
            legacy_pid = int(req.get('started_pid') or 0)
        except Exception:
            legacy_pid = 0
        if legacy_pid == os.getpid():
            return False
        text = '\n'.join([
            '⚠️ 이전 자동배포 적용 기록 정리',
            f"- bundle: {req.get('explicit') or '-'}",
            f"- request: {req.get('request_id') or '-'}",
            f"- 이전 PID: {legacy_pid or '-'} / 현재 MainPID: {os.getpid()}",
            '- 구 applying 기록은 재적용하지 않고 종료',
        ])
        _queue_release_final(req, False, text)
        try:
            pending.unlink(missing_ok=True)
        except Exception:
            pass
        _deliver_pending_release_result_once()
        return True
    if stage != 'waiting_guard_ready':
        text = f"⚠️ 자동 배포 요청 stage 오류: {stage}"
        _queue_release_final(req, False, text)
        try:
            pending.unlink(missing_ok=True)
        except Exception:
            pass
        _deliver_pending_release_result_once()
        return True

    claimed, lock, lock_state = _claim_release_apply(req)
    if not claimed:
        if lock_state == 'active':
            # Includes the same PID.  This is an active claim, not a failure.
            return False
        text = '\n'.join([
            '⚠️ 자동 배포 최종결과 CHECK',
            f"- bundle: {req.get('explicit') or '-'}",
            f"- request: {req.get('request_id') or '-'}",
            f"- 중단된 1회 적용 lock PID: {lock.get('pid') or '-'}",
            '- 자동 재적용 없음 · pending과 stale lock만 정리',
        ])
        _queue_release_final(req, False, text)
        try:
            pending.unlink(missing_ok=True)
        except Exception:
            pass
        try:
            _release_apply_lock_path().unlink(missing_ok=True)
        except Exception:
            pass
        _deliver_pending_release_result_once()
        return True

    progress_notify('\n'.join([
        '🛡 새 가드 정상기동 확인 · 나머지 적용 시작',
        f"- bundle: {req.get('explicit') or '-'}",
        f"- request: {req.get('request_id') or '-'}",
        f"- {stable_note}",
        '- 단일 claim · 적용 1회 · 검수 1회',
    ]))

    try:
        ok, body = _apply_release_bundle_once(req)
        if ok:
            refresh_note = refresh_guard_runtime_before_followup_v1033('restart_bundle')
            body = body + "\n\n[runtime snapshot]\n- " + refresh_note
            command_ok, command_text = _execute_guard_commands_once_v1030(req.get('post_commands') or [])
            if _normalize_post_upgrade_commands_v1030(req.get('post_commands') or []):
                body = body + "\n\n" + command_text
            ok = bool(ok and command_ok)
            retention = _prune_update_bundle_cache_v1030(str(req.get('explicit') or ''), keep=3)
            body = body + "\n\n[로컬 bundle 보관]\n" + \
                f"- 최신 3개 유지 / 삭제 {retention.get('deleted',0)}개 / 확보 {_fmt_bytes(retention.get('freed_bytes',0))}\n" + \
                f"- 오류 {len(retention.get('errors') or [])}개"
        elif _normalize_post_upgrade_commands_v1030(req.get('post_commands') or []):
            body = body + "\n\n[이어실행] 실행 안 함\n- bundle 적용 또는 검수 실패"
        _queue_release_final(req, ok, body)
        try:
            pending.unlink(missing_ok=True)
        except Exception:
            pass
        _deliver_pending_release_result_once()
        return True
    finally:
        _release_apply_lock(req)

def grelease_last_text() -> str:
    pending_final = read_json(_release_final_pending_path()) or {}
    obj = read_json(_release_result_path()) or {}
    pending = _load_release_job()
    if isinstance(obj, dict) and obj:
        delivery = '완료' if bool(obj.get('delivered')) else '대기'
        lines = [
            str(obj.get('text') or '📦 최근 자동 배포 결과'),
            '',
            f"- stage: {obj.get('stage') or '-'}",
            f"- request: {obj.get('request_id') or '-'}",
            f"- bundle digest: {str(obj.get('bundle_digest') or '-')[:16]}",
            f"- 이어실행 명령: {len(_normalize_post_upgrade_commands_v1030(obj.get('post_commands') or []))}개",
            f"- 최종결과 전송: {delivery}",
            f"- 전송 시도: {int(obj.get('delivery_attempts') or 0)}",
            f"- finished: {obj.get('finished_at') or '-'}",
        ]
        if pending:
            lines.append(f"- 현재 요청: {pending.get('stage')} / {pending.get('explicit')}")
        if isinstance(pending_final, dict) and pending_final:
            lines.append('- 최종 메시지 outbox: 재전송 대기 · 재적용/재검수 없음')
        return '\n'.join(lines)
    if pending:
        return '\n'.join([
            '📦 자동 배포 요청 대기',
            f"- stage: {pending.get('stage') or '-'}",
            f"- request: {pending.get('request_id') or '-'}",
            f"- bundle: {pending.get('explicit') or '-'}",
        ])
    return '📦 최근 자동 배포 결과 없음'

def apply_guard_first_for_smart_upgrade(force: bool = False, continuation_bundle: Optional[str] = None, post_commands=None) -> dict:
    """스마트 업그레이드 1단계: 가드봇부터 최신인지 확인한다.

    가드봇이 바뀌었으면 active 파일만 교체하고, post-upgrade 요청 파일을 남긴 뒤
    가드봇을 재시작한다. 새 가드봇이 부팅되면 남은 main/paper/ws/micro 적용을 이어간다.
    이미 최신이면 아무것도 끊지 않는다.
    """
    target = find_latest_guard_file()
    active = BOT_DIR / GUARD_ACTIVE_FILE
    if not target or not target.exists():
        return {"ok": True, "changed": False, "target": "?", "action": "skip", "warning": "backga_guard_bot_v*.py 최신 파일 없음"}
    okc, out = py_compile(target)
    if not okc:
        return {"ok": False, "changed": False, "target": target.name, "action": "error", "error": "guard py_compile 실패", "notes": [tail(out, 1200)]}
    same = active.exists() and short_hash(active) == short_hash(target)
    if same:
        try:
            (BOT_DIR / DEPLOYED_GUARD_FILE).write_text(target.name + "\n", encoding="utf-8")
        except Exception:
            pass
        return {"ok": True, "changed": False, "target": target.name, "action": "skip", "hash": short_hash(active), "warning": "가드봇 hash 동일 → 재시작 생략"}
    backup = None
    if active.exists():
        backup = BOT_DIR / f"{active.name}.backup_guard_smart_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(active, backup)
    tmp = BOT_DIR / f"{active.name}.guard_tmp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(target, tmp)
    if sha256_file(tmp) != sha256_file(target):
        tmp.unlink(missing_ok=True)
        return {"ok": False, "changed": False, "target": target.name, "action": "error", "error": "guard 임시복사 hash 불일치"}
    os.replace(tmp, active)
    (BOT_DIR / DEPLOYED_GUARD_FILE).write_text(target.name + "\n", encoding="utf-8")
    # v2.5.78: one-command release. Persist the exact bundle request before self restart;
    # the new guard resumes the remaining component apply from the local verified zip.
    release_job = write_guard_post_upgrade_request(force=force, explicit=continuation_bundle, post_commands=post_commands)
    rc, out = run(["systemctl", "restart", GUARD_SERVICE], timeout=30)
    return {"ok": rc == 0, "changed": True, "target": target.name, "action": "restart_then_auto_continue", "backup": backup.name if backup else "없음", "hash": short_hash(active), "restart_rc": rc, "restart_out": tail(out, 500), "job_id": release_job.get("request_id"), "restart_warning": "새 가드봇은 정상 MainPID 확인 후 pending bundle을 1회 적용하고 결과 저장 뒤 요청파일을 삭제함"}

def _local_upgrade_targets_present() -> tuple[bool, str]:
    """v2.5.42: GitHub fetch가 일시 timeout일 때 로컬 repo에 적용 대상이 이미 있는지 확인한다."""
    checks = []
    patterns = [
        "수익형_v*.py",
        "paper_bot_v*.py",
        "backga_guard_bot_v*.py",
        "scanner_worker_v*.py",
        "candle_worker_v*.py",
        "market_regime_worker_v*.py",
        "feature_worker_v*.py",
        "orderflow_worker_v*.py",
        "risk_worker_v*.py",
        "strategy_worker_v*.py",
        "review_worker_v*.py",
        "coinbot_update_v*.zip",
    ]
    ok = False
    for pat in patterns:
        matches = sorted(BOT_DIR.glob(pat))
        if matches:
            ok = True
            checks.append(f"{pat}: {matches[-1].name}")
        else:
            checks.append(f"{pat}: 없음")
    return ok, "\n".join(checks[:30])

def git_update(allow_local_fallback: bool = False, fetch_timeout: int = 60) -> tuple[bool, list[str]]:
    steps = []
    # v2.2: GitHub 최신 파일 자동선택 전에 dubious ownership으로 fetch가 막히지 않게 고정한다.
    rc, out = run(["git", "config", "--global", "--add", "safe.directory", str(BOT_DIR)], cwd=BOT_DIR, timeout=15)
    steps.append(f"git safe.directory: rc={rc}\n{tail(out, 300)}")
    # v2.5.62: 25초 fetch timeout이 반복되어 bundle 적용 전 단계에서 계속 막히던 문제 수정.
    # 기본 fetch 대기시간을 늘리되, 오래된 로컬 zip을 무조건 적용하는 fallback은 하지 않는다.
    rc, out = run(["git", "fetch", "--prune", "origin"], cwd=BOT_DIR, timeout=int(fetch_timeout or 60))
    steps.append(f"git fetch --prune origin: rc={rc} / timeout={int(fetch_timeout or 60)}s\n{tail(out, 900)}")
    if rc != 0:
        if allow_local_fallback:
            present, detail = _local_upgrade_targets_present()
            steps.append("로컬 fallback 확인:\n" + detail)
            if present:
                steps.append("⚠️ GitHub fetch 실패/timeout이지만, 로컬 repo의 기존 파일 기준으로 적용을 계속합니다. 새로 push한 파일이 로컬에 없으면 적용되지 않을 수 있으므로 /gdeploy hash와 target을 반드시 확인하세요.")
                return True, steps
        return False, steps
    rc, out = run(["git", "reset", "--hard", f"origin/{GIT_BRANCH}"], cwd=BOT_DIR, timeout=60)
    steps.append(f"git reset --hard origin/{GIT_BRANCH}: rc={rc} / timeout=60s\n{tail(out, 900)}")
    if rc != 0:
        if allow_local_fallback:
            present, detail = _local_upgrade_targets_present()
            steps.append("로컬 fallback 확인:\n" + detail)
            if present:
                steps.append("⚠️ GitHub reset 실패지만 로컬 파일 기준으로 적용을 계속합니다. /gdeploy로 target/hash를 확인하세요.")
                return True, steps
        return False, steps
    return True, steps

def py_compile(path: Path) -> tuple[bool, str]:
    rc, out = run([PYTHON_BIN, "-m", "py_compile", str(path)], cwd=BOT_DIR, timeout=45)
    return rc == 0, out

def static_alias_check(path: Path) -> list[str]:
    """Catch import-time NameError patterns like: build_x = build_deleted_y."""
    text = path.read_text(encoding="utf-8", errors="ignore")
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as e:
        return [f"SyntaxError: {e}"]

    known = set(dir(builtins)) | {"__name__", "__file__", "Path", "datetime", "time", "os", "sys", "json", "re"}
    problems = []

    def add_target(t):
        if isinstance(t, ast.Name):
            known.add(t.id)
        elif isinstance(t, (ast.Tuple, ast.List)):
            for sub in t.elts:
                add_target(sub)

    watch_prefix = ("build_", "format_", "handle_", "cmd_", "summary_", "render_")
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            for alias in node.names:
                known.add(alias.asname or alias.name.split(".")[0])
            continue
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            known.add(node.name)
            continue
        if isinstance(node, ast.Assign):
            if isinstance(node.value, ast.Name):
                rhs = node.value.id
                if rhs not in known and (rhs.startswith(watch_prefix) or rhs.endswith("_command")):
                    lhs = ",".join(t.id for t in node.targets if isinstance(t, ast.Name)) or "?"
                    problems.append(f"line {node.lineno}: {lhs} = {rhs} / RHS 미정의 가능")
            for t in node.targets:
                add_target(t)
            continue
        if isinstance(node, ast.AnnAssign):
            add_target(node.target)
            continue
    return problems[:30]

def required_command_check(path: Path) -> list[str]:
    text = path.read_text(encoding="utf-8", errors="ignore")
    # v2.13.319+ clean worker hub는 /core,/trade,/deploy 중심이 아니라
    # /health,/score,/quality,/strategy_watch,/errorlog 캐시 전용 명령 중심이다.
    modern_required = ["health", "score", "quality", "strategy_watch", "errorlog"]
    if all(c in text for c in modern_required):
        return []
    legacy_required = ["/core", "/trade", "/deploy", "/upgradestatus"]
    missing = [c for c in legacy_required if c not in text]
    if missing:
        return ["필수 명령어 문자열 없음: " + ", ".join(missing)]
    return []

def validate_target(path: Path) -> tuple[bool, list[str], list[str]]:
    checks = []
    warnings = []
    if not path.exists():
        return False, [f"대상 파일 없음: {path.name}"], warnings
    if not version_from_filename(path):
        return False, [f"파일명 형식 오류: {path.name}"], warnings

    # v2.4: 기존 validate 병목은 전체 AST alias 검사였다.
    # 기본은 빠른 검증(py_compile + BOT_VERSION + 필수 문자열)만 하고,
    # 필요할 때만 GUARD_STATIC_ALIAS_CHECK=1로 무거운 검사를 켠다.
    ok, out = py_compile(path)
    checks.append("✅ py_compile 통과" if ok else "❌ py_compile 실패\n" + tail(out, 1600))
    if not ok:
        return False, checks, warnings

    if STATIC_ALIAS_CHECK_ENABLED:
        alias_problems = static_alias_check(path)
        if alias_problems:
            checks.append("❌ 미정의 alias 의심\n" + "\n".join(alias_problems[:10]))
            return False, checks, warnings
        checks.append("✅ 미정의 alias 사전검사 통과")
    else:
        checks.append("✅ alias 정적검사 생략(fast mode)")

    cmd_missing = required_command_check(path)
    if cmd_missing:
        warnings.extend(cmd_missing)
    else:
        checks.append("✅ 필수 명령어 문자열 확인")

    bot_version = extract_bot_version(path)
    if bot_version == "?":
        warnings.append("BOT_VERSION을 못 찾음")
    else:
        checks.append(f"✅ BOT_VERSION: {bot_version}")
    return True, checks, warnings

def is_main_service_active() -> str:
    rc, active = run(["systemctl", "is-active", MAIN_SERVICE], timeout=8)
    return (active or "?").strip()

def is_status_timeout_value(active: str) -> bool:
    s = str(active or "").strip().lower()
    return s.startswith("timeout after") or "timeout after" in s or s in {"timeout", "timed_out"}

def recent_journal(lines: int = 80, since: Optional[str] = None, timeout_sec: int = 4) -> str:
    """메인봇 journal tail을 짧게만 읽는다.
    v2.5.7: journalctl이 막히면 가드봇 polling까지 멈추므로 timeout을 짧게 두고
    status fallback만 반환한다.
    """
    lines = max(20, min(160, int(lines or 80)))
    cmd = ["journalctl", "-u", MAIN_SERVICE, "--no-pager", "-n", str(lines)]
    if since:
        cmd = ["journalctl", "-u", MAIN_SERVICE, "--no-pager", "--since", since, "-n", str(lines)]
    rc, out = run(cmd, timeout=max(2, int(timeout_sec)))
    if rc == 124:
        rc2, st = run(["systemctl", "status", MAIN_SERVICE, "--no-pager", "-l"], timeout=3)
        return (
            f"journalctl timeout after {timeout_sec}s - 가드봇 보호용으로 중단\n"
            f"systemctl status fallback rc={rc2}\n"
            f"{tail(st, 1800)}"
        )
    return out or ""

def has_fatal_log(text: str) -> bool:
    patterns = ["Traceback (most recent call last)", "NameError:", "SyntaxError:", "ImportError:", "ModuleNotFoundError:", "PyCompileError"]
    return any(p in (text or "") for p in patterns)

def restart_service(short: bool = False) -> str:
    rc, out = run(["systemctl", "restart", MAIN_SERVICE], timeout=30)
    time.sleep(3)
    active = is_main_service_active()
    bot_version, target, deployed, latest = get_bot_versions()
    if short:
        return f"🔁 재시작\n- rc: {rc}\n- active: {active}\n- bot.py: {bot_version}\n- deployed: {deployed}"
    log = recent_journal(40)
    return (
        f"🔁 재시작 /grestart\n"
        f"- restart rc: {rc}\n"
        f"- active: {active}\n"
        f"- bot.py: {bot_version}\n"
        f"- 최신파일: {latest}\n"
        f"- .deployed_target: {deployed}\n\n"
        f"[recent log]\n{tail(log, 2600)}"
    )

def _v1165_matching_main_source_for_active(active_path: Path) -> Optional[Path]:
    """Return the versioned Main source whose bytes exactly match active bot.py.

    Rollback files are temporary implementation artifacts, never approved deploy
    targets.  A marker may name only a versioned source that matches the active
    alias hash.  If no such source exists, callers must leave the marker empty
    and report CHECK rather than writing a backup filename as deployment truth.
    """
    if not active_path.exists():
        return None
    try:
        active_digest = sha256_file(active_path)
    except Exception:
        return None
    matches = []
    for pattern in ("coinbot_main_v*.py", "수익형_v*.py"):
        for candidate in BOT_DIR.glob(pattern):
            try:
                ver = version_from_filename(candidate)
                if ver is not None and sha256_file(candidate) == active_digest:
                    matches.append((ver, candidate))
            except Exception:
                continue
    return sorted(matches, key=lambda item: item[0])[-1][1] if matches else None

def rollback_to_file(src: Path, reason: str = "") -> str:
    dst = BOT_DIR / "bot.py"
    if not src.exists():
        return f"↩️ 롤백 실패\n- 백업 없음: {src.name}"
    safety = BOT_DIR / f"bot.py.before_guard_rollback_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    if dst.exists():
        shutil.copy2(dst, safety)
    shutil.copy2(src, dst)
    ok, out = py_compile(dst)
    if not ok:
        if safety.exists():
            shutil.copy2(safety, dst)
        return f"↩️ 롤백 실패\n- 대상: {src.name}\n- py_compile 실패, 원복함\n{tail(out, 1800)}"

    matched_source = _v1165_matching_main_source_for_active(dst)
    marker_note = ""
    if matched_source is not None:
        write_deploy_markers(matched_source.name)
        marker_note = f"- 활성 source marker: {matched_source.name}"
    else:
        for marker_name in (".deployed_target", "DEPLOY_TARGET.txt"):
            try:
                (BOT_DIR / marker_name).unlink(missing_ok=True)
            except Exception:
                pass
        marker_note = "- 활성 source marker: CHECK(일치하는 versioned source 없음)"

    msg = restart_service(short=True)
    data = {
        "time": now(), "ok": False, "action": "rollback",
        "rollback_file": src.name,
        "active_source": matched_source.name if matched_source is not None else None,
        "marker_state": "MATCHED_VERSIONED_SOURCE" if matched_source is not None else "CHECK_SOURCE_MISSING",
        "reason": reason, "active": is_main_service_active(),
    }
    write_json(BOT_DIR / UPGRADE_STATUS_FILE, data)
    return f"↩️ 롤백 완료\n- 적용 백업: {src.name}\n{marker_note}\n- 이유: {reason or '-'}\n\n{msg}"

def list_backups_text() -> str:
    files = collect_backups()
    if not files:
        return "📦 백업 /gbackups\n- 백업 파일 없음"
    lines = ["📦 백업 /gbackups"]
    for i, p in enumerate(files[:10], 1):
        ts = datetime.fromtimestamp(p.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        lines.append(f"{i}. {p.name} / {p.stat().st_size:,} bytes / {ts}")
    return "\n".join(lines)

def collect_backups() -> list[Path]:
    files = []
    for pat in ["bot.py.backup_*", "bot.py.bad_*", "bot.py.bak_*", "bot.py.before_guard_rollback_*"]:
        files.extend(BOT_DIR.glob(pat))
    return sorted(files, key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)

def rollback_latest() -> str:
    files = collect_backups()
    if not files:
        return "↩️ 롤백 /grollback\n- 백업 파일 없음"
    return rollback_to_file(files[0], reason="수동 /grollback")

def apply_main_latest_auto(force: bool = False, explicit: Optional[str] = None, skip_git: bool = False) -> str:
    started = now()
    total_t0 = perf_now()
    steps = []
    timings = []
    status_path = BOT_DIR / UPGRADE_STATUS_FILE
    target = None
    backup = None

    def mark(stage: str, t0: float):
        timings.append((stage, perf_now() - t0))

    try:
        auto = autodeploy_status()
        if auto.get("problem"):
            write_json(status_path, {"time": now(), "ok": False, "stage": "autodeploy_alive", "detail": auto.get("text", "")})
            return (
                "❌ 업그레이드 중단 /gupgrade\n"
                "- 구 1분 자동배포 timer/service가 살아있거나 표시됨\n"
                "- 이 상태에서 업그레이드하면 v31 회귀 위험이 있음\n\n"
                f"[autodeploy]\n{auto.get('text','?')}\n\n"
                "먼저 tradingbot-autodeploy.timer/service를 stop/disable/mask 또는 격리해야 함"
            )

        if skip_git:
            steps.append("git: smart /gupgrade에서 이미 갱신 완료 → 메인 단계 git 생략")
            timings.append(("git_skip", 0.0))
        else:
            t0 = perf_now()
            ok, git_steps = git_update()
            mark("git", t0)
            steps.extend(git_steps)
            if not ok:
                write_json(status_path, {"time": now(), "ok": False, "stage": "git", "steps": steps, "timings": timings})
                return "❌ 업그레이드 실패 /gupgrade\n- GitHub 갱신 실패\n\n" + "\n\n".join(steps)

        t0 = perf_now()
        target = BOT_DIR / explicit if explicit else find_latest_source_file()
        mark("find_latest", t0)
        if not target:
            write_json(status_path, {"time": now(), "ok": False, "stage": "find_latest", "timings": timings})
            return "❌ 업그레이드 실패 /gupgrade\n- 수익형_v*.py 파일을 못 찾음"
        if not target.exists():
            write_json(status_path, {"time": now(), "ok": False, "stage": "target_missing", "target": str(target), "timings": timings})
            return f"❌ 업그레이드 실패 /gupgrade\n- 대상 파일 없음: {target.name}"

        target_ver = version_from_filename(target)
        current_ver = BotVersion.parse(extract_bot_version(BOT_DIR / "bot.py"))
        if current_ver and target_ver and target_ver < current_ver and not force:
            return f"❌ 업그레이드 중단\n- 최신 파일이 현재보다 낮음: {target.name} < {current_ver}\n- 강제 적용은 /gupgrade force {target.name}"

        t0 = perf_now()
        valid, checks, warnings = validate_target(target)
        mark("validate", t0)
        target_version_text = extract_bot_version(target)
        if not valid:
            write_json(status_path, {"time": now(), "ok": False, "stage": "validate", "target": target.name, "checks": checks, "warnings": warnings, "timings": timings})
            return "❌ 업그레이드 실패 /gupgrade\n- 적용 전 검수 실패\n\n" + "\n".join(checks + warnings)

        dst = BOT_DIR / "bot.py"
        # v2.5.3: 대상 파일과 active bot.py가 같으면 교체/재시작하지 않는다.
        # 메인봇만 안 바뀐 경우 paper_bot 작업만 진행하고, 반대도 마찬가지다.
        if dst.exists() and short_hash(dst) == short_hash(target) and not force:
            active = is_main_service_active()
            runtime_version = extract_recent_runtime_version()
            marker_target = read_file(BOT_DIR / ".deployed_target") or "?"
            write_deploy_markers(target.name)
            write_json(status_path, {
                "time": now(), "ok": True, "target": target.name,
                "target_version": target_version_text, "bot_version": extract_bot_version(dst),
                "runtime_version": runtime_version, "active": active,
                "changed": False, "skipped_restart": True, "timings": timings,
            })
            timing_text = "\n".join(f"- {name}: {fmt_sec(sec)}" for name, sec in timings) or "- skip: 0.0s"
            return (
                "🚀 ✅ 메인봇 변경 없음 /gupgrade\n"
                f"- target: {target.name}\n"
                f"- bot.py: {extract_bot_version(dst)}\n"
                f"- 실행로그: {runtime_version}\n"
                f"- active: {active}\n"
                "- 처리: hash 동일 → 교체/재시작 생략\n"
                f"- 단계별 시간:\n{timing_text}"
            )

        if not dst.exists():
            write_json(status_path, {"time": now(), "ok": False, "stage": "bot_missing", "target": target.name, "timings": timings})
            return "❌ 업그레이드 실패\n- bot.py가 없음"

        t0 = perf_now()
        backup = BOT_DIR / f"bot.py.backup_guard_apply_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(dst, backup)
        tmp = BOT_DIR / f"bot.py.guard_tmp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(target, tmp)
        if sha256_file(target) != sha256_file(tmp):
            tmp.unlink(missing_ok=True)
            write_json(status_path, {"time": now(), "ok": False, "stage": "tmp_hash", "target": target.name, "backup": backup.name, "timings": timings})
            return "❌ 업그레이드 실패\n- 임시파일 복사 hash 검증 실패"
        os.replace(tmp, dst)
        if sha256_file(target) != sha256_file(dst):
            shutil.copy2(backup, dst)
            write_json(status_path, {"time": now(), "ok": False, "stage": "replace_hash", "target": target.name, "backup": backup.name, "timings": timings})
            return f"❌ 업그레이드 실패\n- bot.py 교체 후 hash 검증 실패, 백업 복구: {backup.name}"
        mark("copy/hash", t0)

        bot_version_after_copy = extract_bot_version(dst)
        if not same_version_label(bot_version_after_copy, target_version_text):
            shutil.copy2(backup, dst)
            write_json(status_path, {"time": now(), "ok": False, "stage": "bot_version_after_copy", "target": target.name, "target_version": target_version_text, "bot_version": bot_version_after_copy, "backup": backup.name, "timings": timings})
            return (
                "❌ 업그레이드 실패\n"
                "- bot.py 교체 직후 내부버전이 대상과 다름\n"
                f"- target: {target.name} / {target_version_text}\n"
                f"- bot.py: {bot_version_after_copy}\n"
                f"- 백업 복구: {backup.name}"
            )

        t0 = perf_now()
        ok, out = py_compile(dst)
        mark("post_compile", t0)
        if not ok:
            shutil.copy2(backup, dst)
            write_json(status_path, {"time": now(), "ok": False, "stage": "post_compile", "target": target.name, "backup": backup.name, "timings": timings})
            return f"❌ 업그레이드 실패\n- 교체된 bot.py compile 실패, 백업 복구: {backup.name}\n{tail(out, 1800)}"

        write_deploy_markers(target.name)

        t0 = perf_now()
        # v2.5.48: systemctl restart가 stop job 대기 때문에 30초를 꽉 채우던 병목을 줄인다.
        # timeout이 나도 아래 active/hash/version 검증으로 실제 기동 여부를 확인한다.
        rc, out = run(["systemctl", "restart", MAIN_SERVICE], timeout=16)
        mark("restart_cmd", t0)

        active = "unknown"
        fatal = False
        log_since = ""
        waited = 0
        wait_limit = max(8, min(22, int(RESTART_WAIT_SEC)))
        target_hash = short_hash(target)
        bot_hash = short_hash(dst)
        quick_ok = False
        t0 = perf_now()
        while waited < wait_limit:
            time.sleep(2)
            waited += 2
            active = is_main_service_active()
            bot_version_now = extract_bot_version(dst)
            hash_ok = (short_hash(target) == short_hash(dst))
            version_ok = same_version_label(bot_version_now, target_version_text)
            # journalctl은 느리므로 매 2초마다 읽지 않는다. active/hash/version이 맞으면 빠르게 성공 처리한다.
            if active == "active" and hash_ok and version_ok:
                quick_ok = True
                break
            if active in {"failed", "inactive"}:
                log_since = recent_journal(since=started)
                fatal = has_fatal_log(log_since)
                if fatal:
                    break
        if not log_since:
            log_since = recent_journal(since=started)
            fatal = has_fatal_log(log_since)
        mark("verify_wait", t0)

        bot_version_after_restart = extract_bot_version(dst)
        runtime_version = extract_recent_runtime_version(since=started)
        target_hash = short_hash(target)
        bot_hash = short_hash(dst)

        force_recover_notes = []
        if active == "deactivating" and not fatal:
            # v2.5.35: 기존 main이 긴 scan/factory 작업 중이면 systemctl restart가 deactivating에 머문다.
            # 메인봇은 후보생성 brain이고 paper/장부/WS/micro와 분리되어 있으므로, 업그레이드 시 현재 scan 1회만 버리고
            # 새 target을 빠르게 올리기 위해 main service에만 SIGKILL 후 start를 수행한다.
            reason0 = f"main stop hang active=deactivating waited={waited}s"
            krc, kout = run(["systemctl", "kill", "-s", "SIGKILL", MAIN_SERVICE], timeout=10)
            time.sleep(1)
            src2, sout2 = run(["systemctl", "start", MAIN_SERVICE], timeout=35)
            force_recover_notes += [f"deactivating_recover={reason0}", f"systemctl kill rc={krc}", f"systemctl start rc={src2}"]
            t_force = perf_now()
            waited2 = 0
            while waited2 < 25:
                time.sleep(5)
                waited2 += 5
                active = is_main_service_active()
                log_since = recent_journal(since=started)
                fatal = has_fatal_log(log_since)
                bot_version_now = extract_bot_version(dst)
                hash_ok = (short_hash(target) == short_hash(dst))
                version_ok = same_version_label(bot_version_now, target_version_text)
                if active == "active" and not fatal and hash_ok and version_ok:
                    quick_ok = True
                    break
                if fatal:
                    break
            mark("deactivating_recover_wait", t_force)

        if active != "active" or fatal:
            reason = f"재시작 후 active={active}, fatal_log={fatal}, waited={waited}s"
            if force_recover_notes:
                reason += " / " + " / ".join(force_recover_notes)
            bad = BOT_DIR / f"bot.py.bad_guard_apply_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            try:
                shutil.copy2(dst, bad)
            except Exception:
                pass
            if AUTO_ROLLBACK and backup and backup.exists():
                rb = rollback_to_file(backup, reason=reason)
                write_json(status_path, {"time": now(), "ok": False, "stage": "post_restart", "target": target.name, "target_version": target_version_text, "backup": backup.name, "rolled_back": True, "reason": reason, "runtime_version": runtime_version, "timings": timings})
                return (
                    f"❌ 업그레이드 실패 후 자동복구\n"
                    f"- target: {target.name} / {target_version_text}\n"
                    f"- reason: {reason}\n"
                    f"- bad backup: {bad.name if bad.exists() else '?'}\n\n"
                    f"{rb}\n\n[최근 로그]\n{tail(log_since, 2200)}"
                )
            write_json(status_path, {"time": now(), "ok": False, "stage": "post_restart", "target": target.name, "target_version": target_version_text, "backup": backup.name if backup else "?", "rolled_back": False, "reason": reason, "runtime_version": runtime_version, "timings": timings})
            return f"❌ 업그레이드 실패\n- target: {target.name} / {target_version_text}\n- reason: {reason}\n- 자동복구 꺼짐\n\n[최근 로그]\n{tail(log_since, 2600)}"

        marker_target = read_file(BOT_DIR / ".deployed_target") or "?"
        total_elapsed = perf_now() - total_t0
        data = {
            "time": now(), "ok": True, "target": target.name, "target_version": target_version_text,
            "backup": backup.name if backup else "?", "target_hash": target_hash, "bot_hash": bot_hash,
            "bot_version": bot_version_after_restart, "runtime_version": runtime_version,
            "active": active, "warnings": warnings, "waited_sec": waited,
            "timings": timings, "total_sec": total_elapsed, "quick_ok": quick_ok,
        }
        write_json(status_path, data)

        warn_lines = list(warnings or [])
        if not same_version_label(bot_version_after_restart, target_version_text):
            warn_lines.append(f"bot.py 내부버전 불일치: {bot_version_after_restart} != {target_version_text}")
        if 'force_recover_notes' in locals() and force_recover_notes:
            warn_lines.append("main deactivating fast-recover 수행: " + " / ".join(force_recover_notes))
        if runtime_version not in {"시작로그 대기", "시작로그 확인불가"} and not same_version_label(runtime_version, target_version_text):
            warn_lines.append(f"실행로그 버전 확인 필요: {runtime_version} != {target_version_text}")
        if marker_target != target.name:
            warn_lines.append(f".deployed_target 갱신 확인 필요: {marker_target}")
        warn_text = "\n".join(f"- ❔ {w}" for w in warn_lines) if warn_lines else "- 없음"
        timing_text = "\n".join(f"- {name}: {fmt_sec(sec)}" for name, sec in timings)

        verdict = "✅ 업그레이드 성공"
        if warn_lines:
            verdict = "❔ 업그레이드 적용, 확인 필요"
        return (
            f"🚀 {verdict} /gupgrade\n"
            f"- target: {target.name}\n"
            f"- target 내부: {target_version_text}\n"
            f"- bot.py 내부: {bot_version_after_restart}\n"
            f"- 실행로그: {runtime_version}\n"
            f"- .deployed_target: {marker_target}\n"
            f"- backup: {backup.name if backup else '?'}\n"
            f"- active: {active}\n"
            f"- wait: {waited}s / limit {wait_limit}s / quick: {'yes' if quick_ok else 'no'}\n"
            f"- total: {fmt_sec(total_elapsed)}\n"
            f"- hash: target {target_hash} / bot.py {bot_hash}\n"
            f"- 단계별 시간:\n{timing_text}\n"
            f"- 경고:\n{warn_text}\n\n"
            f"다음 확인: /gdeploy 또는 메인봇 /health /score /quality /errorlog"
        )
    except Exception as e:
        write_json(status_path, {"time": now(), "ok": False, "stage": "exception", "target": target.name if target else "?", "backup": backup.name if backup else "?", "error": f"{type(e).__name__}: {e}", "timings": timings})
        return f"❌ 업그레이드 예외\n- {type(e).__name__}: {e}"

def format_guard_apply_result(res: dict) -> str:
    ok = "✅" if res.get("ok") else "❌"
    if res.get("action") in {"restart_guard", "restart_guard_only"}:
        mode = "교체+재시작"
    elif res.get("changed"):
        mode = "교체"
    else:
        mode = "변경없음/재시작생략"
    lines = [f"{ok} guard_bot {mode}"]
    for k in ["target", "backup", "hash", "restart_rc", "error", "warning"]:
        if res.get(k) not in (None, ""):
            lines.append(f"- {k}: {res.get(k)}")
    if res.get("notes"):
        lines.append("- notes:")
        lines.extend(f"  · {str(x)[:220]}" for x in res.get("notes", [])[:8])
    return "\n".join(lines)

def choose_latest_micro_sidecar_target(explicit: Optional[str] = None) -> Optional[Path]:
    if explicit:
        return BOT_DIR / explicit
    targets = read_deploy_targets()
    configured = BOT_DIR / targets["micro"] if targets.get("micro") else None
    latest = find_latest_micro_sidecar_file()
    return latest or configured

def micro_target_version(path: Path) -> str:
    if not path or not path.exists():
        return "?"
    val = extract_assignment(path, "VERSION")
    if val != "?":
        return val
    m = re.search(r"bithumb_micro_sidecar_v(\d+\.\d+)", path.name)
    return f"bithumb_micro_sidecar_v{m.group(1)}" if m else path.name

def micro_desired_enabled() -> bool:
    p = BOT_DIR / MICRO_DESIRED_FILE
    if not p.exists():
        return False
    raw = read_file(p).strip().lower()
    val = raw.splitlines()[0].strip() if raw else ""
    return val in {"1", "on", "true", "enabled", "yes"}

def set_micro_desired(enabled: bool, reason: str = "manual") -> None:
    try:
        text = ("enabled" if enabled else "disabled") + "\n" + f"reason={reason}\ntime={now()}\n"
        (BOT_DIR / MICRO_DESIRED_FILE).write_text(text, encoding="utf-8")
    except Exception:
        pass

def _micro_write_starting_status(reason: str = "guard_starting") -> None:
    try:
        write_json(BOT_DIR / MICRO_STATUS_FILE, {
            "version": micro_target_version(BOT_DIR / MICRO_ACTIVE_FILE),
            "pid": os.getpid(),
            "state": "시작중",
            "last_error": "-",
            "targets": 0,
            "cached": 0,
            "fresh": 0,
            "orderbook_ok": 0,
            "trade_ok": 0,
            "poll_count": 0,
            "updated_ts": time.time(),
            "reason": reason,
        })
    except Exception:
        pass

def _is_reconnect_notice(err: str) -> bool:
    e = str(err or "").lower()
    return "target file changed" in e or "reconnect" in e or "재구독" in e

def find_micro_sidecar_pids() -> list[int]:
    out = []
    try:
        for p in Path("/proc").iterdir():
            if not p.name.isdigit():
                continue
            pid = int(p.name)
            low = proc_cmdline(pid).lower()
            if "python" in low and ("bithumb_micro_sidecar.py" in low or "bithumb_micro_sidecar_v" in low):
                out.append(pid)
    except Exception:
        pass
    return sorted(set(out))

def micro_state_dict() -> dict:
    active = BOT_DIR / MICRO_ACTIVE_FILE
    pid_file = read_pid(BOT_DIR / MICRO_PID_FILE)
    proc_pids = find_micro_sidecar_pids()
    used = pid_file if pid_file and pid_alive(pid_file) else (proc_pids[-1] if proc_pids else None)
    st = read_json(BOT_DIR / MICRO_STATUS_FILE)
    ts = ws_status_ts(st)
    age = time.time() - ts if ts else -1
    fresh = ws_count(st, "fresh")
    cached = ws_count(st, "cached")
    orderbook_ok = ws_count(st, "orderbook_ok")
    trade_ok = ws_count(st, "trade_ok")
    last_error = str(st.get("last_error") or "-") if isinstance(st, dict) else "-"
    alive = bool(used and pid_alive(used))
    mgmt = sidecar_management(used, MICRO_SERVICE)
    latest_target = choose_latest_micro_sidecar_target()
    deployed_marker = read_file(BOT_DIR / DEPLOYED_MICRO_FILE) or "?"
    sync = _sidecar_target_sync("micro", micro_target_version(active), short_hash(active), latest_target, deployed_marker)
    stop_suspect = (not alive) and (str(st.get("state") or "") == "종료" or "signal" in last_error.lower() or "normal stop" in last_error.lower())
    if active.exists() and not sync.get("ok"):
        verdict = f"⚠️ active/latest 불일치: active {micro_target_version(active)} / latest {sync.get('target_version')} / deployed {deployed_marker}"
        ok = False
    elif alive and age >= 0 and age <= 30 and (fresh > 0 or cached > 0):
        verdict = "✅ 정상수집"
        ok = True
    elif alive and (age < 0 or age > 60):
        verdict = "⚠️ 실행중이나 상태갱신 없음"
        ok = False
    elif alive:
        verdict = "⚠️ 실행중이나 수집대기"
        ok = False
    else:
        verdict = "❌ 정지"
        ok = False
    return {
        "ok": ok,
        "verdict": verdict,
        "active_file": MICRO_ACTIVE_FILE,
        "active_exists": active.exists(),
        "version": micro_target_version(active),
        "hash": short_hash(active),
        "deployed_marker": deployed_marker,
        "target": sync.get("target_name"),
        "target_version": sync.get("target_version"),
        "target_hash": sync.get("target_hash"),
        "sync_ok": sync.get("ok"),
        "pid_file": pid_file,
        "proc_pids": proc_pids,
        "used_pid": used,
        "alive": alive,
        "python_path": proc_exe(used) or MICRO_PYTHON_BIN,
        "configured_python": MICRO_PYTHON_BIN,
        "age_text": f"{age:.1f}s" if age >= 0 else "-",
        "state": str(st.get("state") or "-") if isinstance(st, dict) else "-",
        "last_error": last_error,
        "targets": ws_count(st, "targets"),
        "cached": cached,
        "fresh": fresh,
        "orderbook_ok": orderbook_ok,
        "trade_ok": trade_ok,
        "poll_count": ws_count(st, "poll_count"),
        "target_source": str(st.get("target_source") or "-") if isinstance(st, dict) else "-",
        "reload_count": ws_count(st, "target_reload_count"),
        "desired_enabled": micro_desired_enabled(),
        "status_age_num": age,
        "management": mgmt.get("mode"),
        "service_exists": mgmt.get("service_exists"),
        "in_service": mgmt.get("in_service"),
        "cgroup": mgmt.get("cgroup_short"),
        "management_warning": mgmt.get("warning"),
        "stop_suspect": stop_suspect,
    }

def stop_micro_sidecar() -> tuple[bool, list[str]]:
    set_micro_desired(False, "gmicro_stop")
    notes = []
    if service_exists(MICRO_SERVICE):
        rc, out = service_action(MICRO_SERVICE, "stop", timeout=25)
        time.sleep(1)
        notes += cleanup_direct_sidecar_pids("micro")
        alive = [p for p in find_micro_sidecar_pids() if pid_alive(p)]
        try:
            (BOT_DIR / MICRO_PID_FILE).unlink(missing_ok=True)
        except Exception:
            pass
        notes.append(f"관리방식=systemd:{MICRO_SERVICE}")
        notes.append(f"systemctl stop rc={rc} active={is_service_active(MICRO_SERVICE)}")
        if out:
            notes.append(tail(out, 500))
        return (not alive), notes
    pid_path = BOT_DIR / MICRO_PID_FILE
    pid = read_pid(pid_path)
    pids = set(find_micro_sidecar_pids())
    if pid:
        pids.add(pid)
    for p in sorted(pids):
        if p and pid_alive(p):
            stop_pid(p)
            notes.append(f"pid 종료: {p}")
    try:
        pid_path.unlink(missing_ok=True)
        notes.append("pid 파일 제거")
    except Exception as exc:
        notes.append(f"pid 파일 제거 실패: {exc.__class__.__name__}: {str(exc)[:100]}")
    alive = [p for p in find_micro_sidecar_pids() if pid_alive(p)]
    return (not alive), notes

def start_micro_sidecar(python_bin: Optional[str] = None) -> tuple[str, list[str]]:
    notes = []
    set_micro_desired(True, "gmicro_start")
    svc_ok, svc_notes = ensure_sidecar_service_installed("micro")
    notes += svc_notes
    if service_exists(MICRO_SERVICE):
        notes += cleanup_direct_sidecar_pids("micro")
        rc, out = service_action(MICRO_SERVICE, "start", timeout=25)
        time.sleep(2)
        st = micro_state_dict()
        notes.append(f"관리방식=systemd:{MICRO_SERVICE}")
        notes.append(f"systemctl start rc={rc} active={is_service_active(MICRO_SERVICE)}")
        notes.append(f"state={st.get('verdict')} / fresh={st.get('fresh')} / cached={st.get('cached')} / poll={st.get('poll_count')} / age={st.get('age_text')}")
        if out:
            notes.append(tail(out, 500))
        return ("started" if st.get("alive") else "failed"), notes
    if not svc_ok:
        notes.append("systemd service 설치 실패 → direct-fallback 임시 사용")
    active_path = BOT_DIR / MICRO_ACTIVE_FILE
    if not active_path.exists():
        return "missing", [f"active file 없음: {MICRO_ACTIVE_FILE}"]
    py = python_bin or MICRO_PYTHON_BIN
    okc, out = py_compile(active_path)
    if not okc:
        return "compile_failed", [tail(out, 1000)]
    # v2.5.25: pid_file 하나만 믿지 않고 기존 micro 프로세스를 전부 정리한 뒤 1개만 띄운다.
    old_pids = [p for p in find_micro_sidecar_pids() if pid_alive(p)]
    for p in old_pids:
        stop_pid(p)
        notes.append(f"기존 pid 정리: {p}")
    try:
        (BOT_DIR / MICRO_PID_FILE).unlink(missing_ok=True)
    except Exception:
        pass
    notes.append(ws_runtime_file_note(BOT_DIR / MICRO_PID_FILE, "pid", remove_if_not_writable=True))
    notes.append(ws_runtime_file_note(BOT_DIR / MICRO_LOG_FILE, "log", remove_if_not_writable=True))
    _micro_write_starting_status("guard_start")
    notes.append("status_initialized")
    env = os.environ.copy(); env.update(ENV); env["TRADING_BOT_DIR"] = str(BOT_DIR)
    try:
        log_f = open(BOT_DIR / MICRO_LOG_FILE, "a", encoding="utf-8")
        p = subprocess.Popen([py, str(active_path)], cwd=str(BOT_DIR), stdout=log_f, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        try:
            (BOT_DIR / MICRO_PID_FILE).write_text(str(int(p.pid)), encoding="utf-8")
            notes.append("pid_file_written")
        except Exception as exc:
            notes.append(f"pid_file_write_failed:{exc.__class__.__name__}:{str(exc)[:120]}")
        notes.append(f"pid={p.pid}")
    except Exception as exc:
        return "start_failed", [f"{exc.__class__.__name__}: {str(exc)[:160]}"] + notes
    time.sleep(2)
    alive = pid_alive(p.pid)
    dup = [x for x in find_micro_sidecar_pids() if x != p.pid and pid_alive(x)]
    if dup:
        notes.append(f"중복 pid 경고: {dup}")
    return "started" if alive else "exited", notes

def restart_micro_sidecar(python_bin: Optional[str] = None) -> tuple[str, list[str]]:
    set_micro_desired(True, "gmicro_restart")
    ok, notes = stop_micro_sidecar()
    # stop은 desired를 disabled로 남기므로 restart 의도를 다시 enabled로 복구한다.
    set_micro_desired(True, "gmicro_restart")
    active, start_notes = start_micro_sidecar(python_bin=python_bin)
    return active, notes + start_notes

def wait_micro_ready(prev_poll: int = 0, timeout: float = 45.0, target_version: str = "") -> tuple[dict, list[str]]:
    """micro 재시작 후 준비확인.

    v2.5.33: v0.7은 wide target REST 수집 때문에 첫 poll/cache가 늦을 수 있다.
    이전 v2.5.32는 잠깐 started 후 fresh/cache/poll이 0인 준비구간을 실패로 보고
    정상 적용된 v0.7을 v0.5 백업으로 되돌렸다. 이제는 아래를 분리한다.
    - 확정 성공: alive + 수집흔적(fresh/cache/poll/orderbook/trade)
    - 준비중 성공: alive + status 최신 + active/latest sync + last_error 없음
    - 확정 실패: 프로세스 사망 또는 status가 오래되고 오류가 명확함
    """
    notes = []
    deadline = time.time() + max(12.0, timeout)
    best = micro_state_dict()
    target_version = str(target_version or "")
    while time.time() < deadline:
        st = micro_state_dict()
        best = st
        poll = int(st.get("poll_count") or 0)
        fresh = int(st.get("fresh") or 0)
        cached = int(st.get("cached") or 0)
        order_ok = int(st.get("orderbook_ok") or 0)
        trade_ok = int(st.get("trade_ok") or 0)
        age = float(st.get("status_age_num") or -1)
        err = str(st.get("last_error") or "-")
        err_ok = err in {"", "-", "None", "none"}
        synced = bool(st.get("sync_ok", False))
        version_ok = (not target_version) or str(st.get("version") or "") == target_version or str(st.get("target_version") or "") == target_version
        has_collection = fresh > 0 or cached > 0 or poll > prev_poll or order_ok > 0 or trade_ok > 0
        if st.get("alive") and has_collection and synced:
            notes.append(f"ready fresh={fresh} cached={cached} poll={poll} age={st.get('age_text')} sync={synced}")
            return st, notes
        if st.get("alive") and synced and version_ok and 0 <= age <= 30 and err_ok:
            state = str(st.get("state") or "-")
            if state in {"시작", "수집중", "대상준비", "guard_starting", "재시도대기"} or not has_collection:
                notes.append(f"warmup_ok version={st.get('version')} fresh={fresh} cached={cached} poll={poll} age={st.get('age_text')} sync={synced}")
                return st, notes
        if not st.get("alive"):
            notes.append("wait: process not alive")
            break
        time.sleep(3)
    notes.append(f"wait_timeout fresh={best.get('fresh',0)} cached={best.get('cached',0)} poll={best.get('poll_count',0)} sync={best.get('sync_ok')} version={best.get('version')}")
    return best, notes

def apply_micro_sidecar_latest(force: bool = False, explicit: Optional[str] = None, restart: bool = True) -> dict:
    """micro sidecar 최신 적용 단일 본선.

    v2.5.29 원칙:
    - hash 동일 + 프로세스 alive + status 최신/수집흔적 있으면 즉시 return.
    - 이 경우 py_compile/stop/start/restart_micro_sidecar()로 절대 내려가지 않는다.
    - 재시작은 hash 변경, force, 정지, status 오래됨/오류처럼 이유가 있을 때만 한다.
    """
    target = choose_latest_micro_sidecar_target(explicit=explicit)
    service_notes: list[str] = []
    if target and target.exists():
        _svc_ok, service_notes = ensure_sidecar_service_installed("micro")
    before = micro_state_dict()
    prev_poll = int(before.get("poll_count") or 0)
    active_path = BOT_DIR / MICRO_ACTIVE_FILE
    if not target or not target.exists():
        return {"ok": True, "changed": False, "target": explicit or "?", "active": before.get("verdict", "유지"), "warning": "bithumb_micro_sidecar_v*.py 최신 파일 없음 → 기존 상태 유지", "notes": ["대상 파일 없음: 기존 실행은 건드리지 않음"]}

    same_hash = active_path.exists() and short_hash(active_path) == short_hash(target)
    before_age = float(before.get("status_age_num") or -1)
    alive = bool(before.get("alive"))
    err = str(before.get("last_error") or "-")
    err_ok = err in {"", "-", "None", "none"}
    status_recent = 0 <= before_age <= 90
    state_text = str(before.get("state") or "")
    waiting_recent = 0 <= before_age <= 20 and state_text in {"수집중", "시작", "guard_starting"}
    has_collection = int(before.get("fresh") or 0) > 0 or int(before.get("cached") or 0) > 0 or int(before.get("poll_count") or 0) > 0 or int(before.get("orderbook_ok") or 0) > 0 or int(before.get("trade_ok") or 0) > 0 or waiting_recent
    management_ok = str(before.get("management") or "").startswith("systemd:") and bool(before.get("in_service"))
    micro_healthy_enough = bool(alive and status_recent and err_ok and has_collection and management_ok and before.get("sync_ok", True))

    if same_hash and not force and micro_healthy_enough:
        try:
            (BOT_DIR / DEPLOYED_MICRO_FILE).write_text(target.name + "\n", encoding="utf-8")
        except Exception:
            pass
        set_micro_desired(True, "gupgrade_fastskip_keep_running")
        return {
            "ok": True, "changed": False, "target": target.name, "version": micro_target_version(target),
            "active": "restart 생략", "backup": "없음", "hash": short_hash(active_path),
            "notes": service_notes + [
                "single-path fast-skip: hash 동일 + alive + status 최신 + 수집흔적 있음 + systemd service pid",
                "py_compile/stop/start/restart 경로 완전 우회",
                f"pid 유지: {before.get('used_pid') or '-'} / fresh {before.get('fresh',0)} / cached {before.get('cached',0)} / poll {before.get('poll_count',0)} / age {before.get('age_text','-')}",
            ],
            "warning": "변경 없음 → 실행중인 micro 유지 / 재시작 생략",
            "state": before.get("verdict"), "fresh": before.get("fresh"), "cached": before.get("cached"),
            "orderbook_ok": before.get("orderbook_ok"), "trade_ok": before.get("trade_ok"),
            "restart_reason": "-",
        }

    restart_reasons = []
    if force:
        restart_reasons.append("force")
    if not same_hash:
        restart_reasons.append("hash 변경")
    if not alive:
        restart_reasons.append("프로세스 정지")
    if alive and not status_recent:
        restart_reasons.append(f"status 오래됨 {before.get('age_text','-')}")
    if alive and not err_ok:
        restart_reasons.append(f"수집오류 {err[:80]}")
    if alive and status_recent and err_ok and not has_collection:
        restart_reasons.append("수집흔적 부족")
    if not management_ok:
        restart_reasons.append("direct-fallback → systemd service 전환")
    if not before.get("sync_ok", True):
        restart_reasons.append("active/deployed/latest 불일치")

    okc, comp_out = py_compile(target)
    if not okc:
        return {"ok": False, "changed": False, "target": target.name, "error": "micro py_compile 실패", "notes": [tail(comp_out, 1000)], "restart_reason": " / ".join(restart_reasons) or "검수실패"}

    backup = "없음"
    backup_path = None
    changed = False
    if not same_hash or force:
        if active_path.exists():
            backup_path = BOT_DIR / f"{active_path.name}.backup_guard_apply_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copy2(active_path, backup_path)
            backup = backup_path.name
        tmp = BOT_DIR / f"{active_path.name}.guard_tmp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(target, tmp)
        if sha256_file(tmp) != sha256_file(target):
            tmp.unlink(missing_ok=True)
            return {"ok": False, "changed": False, "target": target.name, "error": "micro 임시복사 hash 불일치", "restart_reason": " / ".join(restart_reasons)}
        os.replace(tmp, active_path)
        changed = True
    try:
        (BOT_DIR / DEPLOYED_MICRO_FILE).write_text(target.name + "\n", encoding="utf-8")
    except Exception:
        pass

    notes = service_notes + ["restart path entered only because: " + (" / ".join(restart_reasons) or "unknown"), f"python={MICRO_PYTHON_BIN}"]
    active = "restart 생략"
    state = before
    if restart:
        set_micro_desired(True, "gupgrade_restart_needed")
        active, rn = restart_micro_sidecar(python_bin=MICRO_PYTHON_BIN)
        notes += rn
        state, wn = wait_micro_ready(prev_poll=0 if changed else prev_poll, timeout=60.0, target_version=micro_target_version(target))
        notes += wn
    else:
        state = micro_state_dict()
        notes.append("restart=False → 교체만 하고 재시작 생략")
    def _micro_apply_ok(st: dict) -> bool:
        if not st.get("alive"):
            return False
        fresh = int(st.get("fresh") or 0)
        cached = int(st.get("cached") or 0)
        poll = int(st.get("poll_count") or 0)
        order_ok = int(st.get("orderbook_ok") or 0)
        trade_ok = int(st.get("trade_ok") or 0)
        age = float(st.get("status_age_num") or -1)
        err = str(st.get("last_error") or "-")
        err_ok = err in {"", "-", "None", "none"}
        synced = bool(st.get("sync_ok", False))
        has_collection = fresh > 0 or cached > 0 or poll > 0 or order_ok > 0 or trade_ok > 0
        warmup_ok = synced and 0 <= age <= 45 and err_ok
        return bool(synced and (has_collection or warmup_ok))

    ok = _micro_apply_ok(state)
    rollback_note = ""
    # v2.5.33: active/latest가 맞고 프로세스가 살아 있으면 warm-up으로 인정한다.
    # 캐시 0만으로 즉시 rollback하지 않는다. rollback은 sync가 깨지거나 프로세스가 죽은 확정 실패 때만 수행한다.
    if not ok and changed and backup_path and backup_path.exists():
        hard_fail = (not state.get("alive")) or (not state.get("sync_ok", False) and str(state.get("version") or "") != micro_target_version(target))
        if hard_fail:
            try:
                shutil.copy2(backup_path, active_path)
                rollback_note = f"rollback={backup_path.name}"
                active2, rn = restart_micro_sidecar(python_bin=MICRO_PYTHON_BIN)
                state, wn = wait_micro_ready(timeout=20.0, target_version=micro_target_version(backup_path) if backup_path else "")
                notes += [rollback_note, f"rollback_restart={active2}"] + rn + wn
            except Exception as exc:
                notes.append(f"rollback 실패: {exc.__class__.__name__}: {str(exc)[:160]}")
        else:
            notes.append("rollback 생략: active/latest sync + process alive 상태라 micro warm-up으로 판단")
            ok = True
    final_ok = _micro_apply_ok(state) or ok
    return {"ok": final_ok, "changed": changed, "target": target.name, "version": micro_target_version(target), "active": active, "backup": backup, "hash": short_hash(active_path), "notes": notes, "warning": rollback_note or ("재시작 수행: " + (" / ".join(restart_reasons) or "unknown")), "state": state.get("verdict"), "fresh": state.get("fresh"), "cached": state.get("cached"), "orderbook_ok": state.get("orderbook_ok"), "trade_ok": state.get("trade_ok"), "restart_reason": " / ".join(restart_reasons) or "-"}

def format_micro_apply_result(res: dict) -> str:
    ok = "✅" if res.get("ok") else "❌"
    changed = "교체+재시작" if res.get("changed") else ("변경없음/재시작생략" if str(res.get("active")) == "restart 생략" else "변경없음/필요재시작")
    lines = [f"{ok} micro_sidecar {changed}"]
    for k in ["target", "version", "active", "restart_reason", "state", "fresh", "cached", "orderbook_ok", "trade_ok", "backup", "hash", "error", "warning"]:
        if res.get(k) not in (None, ""):
            lines.append(f"- {k}: {res.get(k)}")
    if res.get("notes"):
        lines.append("- notes:")
        lines += ["  · " + str(x) for x in res.get("notes", [])[:12]]
    return "\n".join(lines)

def gmicro_state_text() -> str:
    d = micro_state_dict()
    proc = ",".join(map(str, d.get("proc_pids") or [])) or "-"
    dup_note = "⚠️ 중복 pid 있음" if len(d.get("proc_pids") or []) > 1 else "✅ pid 단일"
    return "\n".join([
        "🔎 빗썸 호가·체결 직원 /gmicro_state",
        str(d.get("verdict", "?")),
        f"- active_file: {d.get('active_file')} / exists={d.get('active_exists')} / version={d.get('version')} / hash={d.get('hash')}",
        f"- latest: {d.get('target','?')} / {d.get('target_version','?')} / target_hash={d.get('target_hash','?')} / deployed={d.get('deployed_marker','?')} / sync={d.get('sync_ok')}",
        f"- pid_file: {d.get('pid_file') or '-'} / proc: {proc} / used: {d.get('used_pid') or '-'} / alive={d.get('alive')}",
        f"- 관리방식: {d.get('management','-')} / 경고: {d.get('management_warning','-')}",
        f"- cgroup: {d.get('cgroup','-')}",
        f"- python: {d.get('python_path') or '-'} / configured: {d.get('configured_python') or '-'}",
        f"- desired: {'enabled' if d.get('desired_enabled') else 'disabled'} / {dup_note}",
        f"- status_age: {d.get('age_text','-')} / state: {d.get('state','-')} / last_error: {d.get('last_error','-')}",
        f"- targets {d.get('targets',0)} / cache {d.get('cached',0)} / fresh {d.get('fresh',0)} / orderbook_ok {d.get('orderbook_ok',0)} / trade_ok {d.get('trade_ok',0)} / poll {d.get('poll_count',0)}",
        f"- target_source: {d.get('target_source','-')} / reload {d.get('reload_count',0)}",
        f"- files: cache={MICRO_CACHE_FILE} / status={MICRO_STATUS_FILE} / log={MICRO_LOG_FILE}",
        "- 시작: /gmicro_start / 중지: /gmicro_stop / 재시작: /gmicro_restart / 업그레이드: /gmicro_upgrade",
    ])

def gmicro_log(lines: int = 80) -> str:
    txt = read_file_tail(BOT_DIR / MICRO_LOG_FILE, max_bytes=120_000)
    return f"🧾 빗썸 호가·체결 직원 로그 /gmicrolog {lines}\n" + (tail(txt, 2600) if txt.strip() else "- 로그 없음")

def gmicro_start_text() -> str:
    active, notes = start_micro_sidecar()
    return "\n".join(["▶️ 빗썸 호가·체결 직원 시작 /gmicro_start", f"- active: {active}", f"- desired: {'enabled' if micro_desired_enabled() else 'disabled'}", f"- version: {micro_target_version(BOT_DIR / MICRO_ACTIVE_FILE)}"] + [f"- {x}" for x in notes] + ["", "다음 확인: /gmicro_state /quality"])

def gmicro_stop_text() -> str:
    ok, notes = stop_micro_sidecar()
    return "\n".join(["⏹ 빗썸 호가·체결 직원 중지 /gmicro_stop", f"- ok: {ok}", f"- desired: {'enabled' if micro_desired_enabled() else 'disabled'}"] + [f"- {x}" for x in notes])

def gmicro_restart_text() -> str:
    active, notes = restart_micro_sidecar()
    return "\n".join(["🔁 빗썸 호가·체결 직원 재시작 /gmicro_restart", f"- active: {active}", f"- desired: {'enabled' if micro_desired_enabled() else 'disabled'}", f"- version: {micro_target_version(BOT_DIR / MICRO_ACTIVE_FILE)}"] + [f"- {x}" for x in notes] + ["", "다음 확인: /gmicro_state /quality"])

def main_brain_state_dict() -> dict:
    """메인봇 내부 status 파일에서 Telegram polling 상태를 읽는다.

    v2.5.38: systemd active/hash만 정상이고 메인봇 명령이 무반응인 상태를
    /gdeploy에서 바로 보이게 한다. journalctl이 지연돼도 clean_brain_status.json을
    fallback source로 사용한다.
    """
    path = BOT_DIR / "clean_brain_status.json"
    obj = read_json(path)
    if not isinstance(obj, dict) or not obj:
        return {"exists": False, "path": path.name, "state": "missing", "verdict": "❔ 상태파일 없음", "age_text": "-", "version": "?", "error": "-"}
    ts = 0.0
    for k in ("telegram_updated_ts", "last_done_scan_ts", "scan_last_ts", "updated_ts", "started_at"):
        try:
            ts = float(obj.get(k) or 0)
        except Exception:
            ts = 0.0
        if ts > 0:
            break
    age = time.time() - ts if ts > 0 else -1.0
    state = str(obj.get("telegram_state") or "unknown")
    error = str(obj.get("telegram_error") or "-")
    version = str(obj.get("version") or obj.get("brain_version") or "?")
    ok_states = {"polling_started", "running", "polling_started_notify_failed"}
    warn_states = {"initializing", "commands_installed", "stopping"}
    if state in ok_states:
        verdict = "✅ 명령수신 준비"
    elif state in warn_states:
        verdict = "⚠️ 시작 중/확인 필요"
    elif state in {"disabled", "error"}:
        verdict = "❌ Telegram 문제"
    elif state in {"missing", "unknown", ""}:
        verdict = "❔ Telegram 상태 미기록"
    else:
        verdict = "⚠️ Telegram 상태 확인"
    return {
        "exists": True,
        "path": path.name,
        "state": state,
        "error": error,
        "version": version,
        "age": age,
        "age_text": f"{age:.1f}s" if age >= 0 else "-",
        "verdict": verdict,
        "command_count": obj.get("command_count", "-"),
        "scan_stage": obj.get("scan_last_stage", "-"),
        "scan_running": bool(obj.get("scan_running")),
        "note": str(obj.get("telegram_note") or "-")[:160],
    }

def main_file_log_focus(max_chars: int = 1600) -> str:
    """journalctl timeout 때 볼 메인봇 내부 파일 로그 요약."""
    parts = []
    for name in ("clean_brain_error.log", "clean_brain_runtime.log"):
        txt = read_file_tail(BOT_DIR / name, max_bytes=80_000)
        if not txt.strip():
            continue
        lines = []
        for line in txt.splitlines():
            if any(x in line for x in ["Traceback", "NameError", "SyntaxError", "ImportError", "ModuleNotFoundError", "telegram_state", "telegram_not_ready", "main_v305_boot", "telegram_send_api", "polling_started"]):
                lines.append(line)
        if lines:
            parts.append(f"[{name}]\n" + "\n".join(lines[-8:]))
    out = "\n".join(parts).strip()
    return tail(out, max_chars) if out else "없음"

def worker_marker_path(name: str) -> Path:
    return BOT_DIR / f".deployed_{name}_worker_target"

def worker_service_unit_path(name: str) -> Path:
    spec = WORKER_SPECS[name]
    return Path("/etc/systemd/system") / f"{spec['service']}.service"

def worker_latest_file(name: str, explicit: Optional[str] = None, prefer_deployed: bool = False) -> Optional[Path]:
    """Resolve a worker source without confusing staged files with the deployed target.

    Upgrade selection keeps the historical highest-version scan. Runtime/status
    verification instead follows the deployed marker written by the successful
    copy step. This prevents an unrelated staged file (for example v1.001) from
    making an explicitly deployed v0.11 alias look mismatched.
    """
    if explicit:
        p = BOT_DIR / explicit
        return p if p.exists() else p
    if prefer_deployed:
        marker_name = (read_file(worker_marker_path(name)) or "").strip()
        if marker_name:
            deployed = BOT_DIR / marker_name
            if deployed.exists() and deployed.is_file():
                return deployed
    spec = WORKER_SPECS[name]
    prefix = str(spec["prefix"])
    files = []
    for p in BOT_DIR.glob(f"{prefix}_v*.py"):
        nums = tuple(int(x) for x in re.findall(r"\d+", p.name))
        files.append((nums, p.stat().st_mtime, p))
    if not files:
        # 최신 파일명이 없더라도 active 파일이 있으면 상태 확인은 가능하게 한다.
        active = BOT_DIR / str(spec["active"])
        return active if active.exists() else None
    return sorted(files, key=lambda x: (x[0], x[1]))[-1][2]

def worker_version(path: Optional[Path]) -> str:
    if not path or not path.exists():
        return "?"
    val = extract_assignment(path, "VERSION")
    if val != "?":
        return val
    return path.name

def worker_active_path(name: str) -> Path:
    return BOT_DIR / str(WORKER_SPECS[name]["active"])

def worker_status_path(name: str) -> Path:
    return BOT_DIR / str(WORKER_SPECS[name]["status"])

def worker_status_age(name: str) -> tuple[float, str]:
    p = worker_status_path(name)
    if not p.exists():
        return 999999.0, "없음"
    st = read_json(p)
    ts = st.get("updated_ts") or st.get("ts")
    try:
        age = max(0.0, time.time() - float(ts)) if ts else max(0.0, time.time() - p.stat().st_mtime)
    except Exception:
        age = max(0.0, time.time() - p.stat().st_mtime)
    return age, fmt_sec(age)

def _proc_cmdline_v1111(pid: int) -> str:
    try:
        return (Path("/proc") / str(int(pid)) / "cmdline").read_bytes().decode("utf-8", errors="ignore").replace("\x00", " ").strip()
    except Exception:
        return ""

def _worker_family_match_v1122(name: str, pid: int, include_helpers: bool=False) -> bool:
    """Match the stable worker filename family, not only active/latest aliases.

    The old matcher missed a live review_worker_v0.998.py after v0.999 was
    deployed.  That process survived restart and retained the Review SQLite
    writer.  Versioned historical filenames are now part of cleanup/runtime
    truth.  Intentional short-lived Review helper modes are excluded from the
    long-lived exact-one count but included in stop/drain cleanup.
    """
    if not pid or not pid_alive(int(pid)) or name not in WORKER_SPECS:
        return False
    cmdline=_proc_cmdline_v1111(int(pid))
    low=cmdline.lower()
    if not low or 'python' not in low:
        return False
    spec=WORKER_SPECS[name]
    prefix=str(spec.get('prefix') or '').lower()
    active=str(spec.get('active') or '').lower()
    tokens=cmdline.split()
    scripts=[Path(tok).name.lower() for tok in tokens if tok.lower().endswith('.py')]
    family=any(script==active or (prefix and script.startswith(prefix+'_v') and script.endswith('.py')) for script in scripts)
    if not family:
        return False
    if name=='review' and not include_helpers:
        helper_flags={'--build-dedup-index-v1013','--compact-quality-state-v1012','--build-good-s2-summary-v1014'}
        if any(flag in tokens for flag in helper_flags):
            return False
    return True

def _pid_matches_worker_v1111(name: str, pid: int) -> bool:
    return _worker_family_match_v1122(name,pid,include_helpers=False)

def find_worker_pids(name: str, include_helpers: bool=False) -> list[int]:
    """Return all live long-lived runtimes in the stable worker family."""
    out: list[int] = []
    spec=WORKER_SPECS[name]
    service=str(spec.get('service') or '')
    if service:
        _rc, mainpid_txt=run(['systemctl','show',service,'-p','MainPID','--value'],timeout=5)
        try: mainpid=int((mainpid_txt or '0').strip() or '0')
        except Exception: mainpid=0
        if mainpid and _worker_family_match_v1122(name,mainpid,include_helpers=include_helpers):
            out.append(mainpid)
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try: pid=int(entry.name)
        except Exception: continue
        if _worker_family_match_v1122(name,pid,include_helpers=include_helpers):
            out.append(pid)
    return sorted(set(out))

def cleanup_direct_worker_pids(name: str) -> list[str]:
    """systemd 서비스 시작 전 구 direct/subprocess worker를 끊는다.

    v319 메인봇이 worker를 subprocess로 켤 수 있으므로, guard가 systemd 본선으로 전환할 때
    동일 worker가 두 개 도는 문제를 막는다. 단, systemd MainPID는 죽이지 않는다.
    """
    spec = WORKER_SPECS[name]
    svc = str(spec["service"])
    rc, mainpid_txt = run(["systemctl", "show", svc, "-p", "MainPID", "--value"], timeout=5)
    mainpid = 0
    try:
        mainpid = int((mainpid_txt or "0").strip() or "0")
    except Exception:
        mainpid = 0
    notes = []
    for pid in find_worker_pids(name, include_helpers=True):
        if mainpid and pid == mainpid:
            continue
        try:
            os.kill(pid, signal.SIGTERM)
            notes.append(f"direct pid {pid} TERM")
        except Exception as e:
            notes.append(f"direct pid {pid} TERM 실패 {type(e).__name__}")
    time.sleep(0.2)
    for pid in find_worker_pids(name, include_helpers=True):
        if mainpid and pid == mainpid:
            continue
        if pid_alive(pid):
            try:
                os.kill(pid, signal.SIGKILL)
                notes.append(f"direct pid {pid} KILL")
            except Exception as e:
                notes.append(f"direct pid {pid} KILL 실패 {type(e).__name__}")
    return notes

def ensure_worker_service_installed(name: str) -> tuple[bool, list[str]]:
    spec = WORKER_SPECS[name]
    active = worker_active_path(name)
    svc = str(spec["service"])
    unit_path = worker_service_unit_path(name)
    log_path = BOT_DIR / str(spec.get("log") or f"clean_{name}_worker_service.log")
    err_path = BOT_DIR / f"clean_{name}_worker_service.err"
    unit = f"""[Unit]
Description=TradingBot {spec['label']} worker
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory={BOT_DIR}
EnvironmentFile=-{BOT_DIR / 'guard.env'}
Environment=TRADING_BOT_DIR={BOT_DIR}
ExecStart={WORKER_PYTHON_BIN} {active}
Restart=always
RestartSec=3
KillMode=control-group
TimeoutStopSec=15
SendSIGKILL=yes
StandardOutput=append:{log_path}
StandardError=append:{err_path}

[Install]
WantedBy=multi-user.target
"""
    notes = []
    try:
        old = unit_path.read_text(encoding="utf-8", errors="ignore") if unit_path.exists() else ""
        if old != unit:
            unit_path.write_text(unit, encoding="utf-8")
            notes.append(f"unit write {unit_path.name}")
            rc, out = run(["systemctl", "daemon-reload"], timeout=20)
            notes.append(f"daemon-reload rc={rc}")
        rc, out = run(["systemctl", "enable", svc], timeout=20)
        if rc not in {0, 1}:  # 이미 enabled일 때도 배포판에 따라 0/1 혼재 가능
            notes.append(f"enable rc={rc} {tail(out,180)}")
        return True, notes
    except Exception as e:
        return False, [f"service install failed {type(e).__name__}: {e}"] + notes

def worker_semantic_ready(state_obj: dict) -> bool:
    """Treat healthy collection states as runtime-ready without hiding CHECK/FAIL states.

    Worker status writers are allowed to expose semantic state=NORMAL with a more
    specific health_state such as COLLECTING_*. Deployment readiness must verify
    liveness, freshness, version/hash and the absence of CHECK/FAIL/ERROR, rather
    than requiring the transport-only literal state=running.
    """
    if not isinstance(state_obj, dict):
        return False
    raw = state_obj.get("raw") if isinstance(state_obj.get("raw"), dict) else state_obj
    state = str(raw.get("state") or state_obj.get("state") or "").strip().upper()
    health = str(raw.get("health_state") or "").strip().upper()
    if state not in {"RUNNING", "READY", "NORMAL"}:
        return False
    if health.startswith(("CHECK", "FAIL", "ERROR")):
        return False
    return True

def worker_state_dict(name: str) -> dict:
    spec = WORKER_SPECS[name]
    active = worker_active_path(name)
    latest = worker_latest_file(name, prefer_deployed=True)
    st = read_json(worker_status_path(name))
    age, age_text = worker_status_age(name)
    rc_active, active_txt = run(["systemctl", "is-active", str(spec["service"])], timeout=5)
    service_active = (active_txt or "").strip()
    rc_enabled, enabled_txt = run(["systemctl", "is-enabled", str(spec["service"])], timeout=5)
    rc_pid, mainpid_txt = run(["systemctl", "show", str(spec["service"]), "-p", "MainPID", "--value"], timeout=5)
    try:
        mainpid = int((mainpid_txt or "0").strip() or "0")
    except Exception:
        mainpid = 0
    state = str(st.get("state") or "missing") if st else "missing"
    active_ver = worker_version(active)
    latest_ver = worker_version(latest)
    fresh_limit = float(spec.get("fresh_limit") or 45)
    alive = bool(mainpid and pid_alive(mainpid))
    sync_ok = bool(latest and active.exists() and short_hash(latest) == short_hash(active))
    runtime_error = str((st.get("error") or st.get("last_error") or "") if isinstance(st, dict) else "").strip()
    error_ok = runtime_error in {"", "-", "None", "null"}
    ok = bool(service_active == "active" and alive and worker_semantic_ready(st if isinstance(st, dict) else {}) and age <= fresh_limit and sync_ok and error_ok)
    verdict = "✅ 정상" if ok else "⚠️ 확인 필요"
    if service_active not in {"active", "activating"}:
        verdict = "❌ 꺼짐"
    elif not error_ok:
        verdict = "❌ 실행 오류"
    elif age > fresh_limit:
        verdict = "⚠️ stale"
    elif not sync_ok:
        verdict = "⚠️ 파일 불일치"
    metrics = []
    for k in ["row_count", "pool_count", "evaluated", "s_count", "target_count", "request_count", "near_s_count", "fresh_recovered", "need_ws", "need_micro", "fresh_ws", "fresh_micro", "closed_recent", "big_loss", "good_win", "health_state", "replay_results", "current_actual_exact", "complete_pair_exact", "unresolved", "poll_records_total", "open_events", "closed_events", "last_sec", "scanner_age"]:
        if k in st:
            metrics.append(f"{k}={st.get(k)}")
    return {
        "name": name,
        "label": spec["label"],
        "service": spec["service"],
        "active_file": active.name,
        "active_exists": active.exists(),
        "active_version": active_ver,
        "active_hash": short_hash(active),
        "latest": latest.name if latest else "?",
        "latest_version": latest_ver,
        "latest_hash": short_hash(latest) if latest else "?",
        "deployed": read_file(worker_marker_path(name)) or "?",
        "sync_ok": sync_ok,
        "service_active": service_active or "?",
        "enabled": (enabled_txt or "?").strip(),
        "pid": mainpid or (st.get("pid") if isinstance(st, dict) else 0),
        "alive": alive,
        "state": state,
        "age": age,
        "age_text": age_text,
        "status_version": st.get("version", "?") if isinstance(st, dict) else "?",
        "metrics": " / ".join(metrics) if metrics else "-",
        "ok": ok,
        "verdict": verdict,
        "last_error": runtime_error[:160] if runtime_error else "-",
        "error_ok_v1165": error_ok,
        "raw": st if isinstance(st, dict) else {},
    }

def format_worker_state_line(w: dict) -> str:
    return (
        f"- {w['label']}({w['name']}): {w['verdict']} / svc {w['service_active']} / pid {w.get('pid') or '-'} / age {w['age_text']}\n"
        f"  · active {w['active_file']} {w['active_version']} / latest {w['latest']} {w['latest_version']} / sync {w['sync_ok']}\n"
        f"  · metrics {w['metrics']} / err {w['last_error']}"
    )

def _gworker_val(st: dict, *keys: str):
    # v2.5.52: 일부 상태 dict는 raw가 비어 있고 metrics 문자열만 남아 한눈요약이 '-'로 보였다.
    # raw -> 직접필드 -> metrics 문자열 순서로 읽어 숫자를 복원한다.
    raw = st.get("raw") if isinstance(st.get("raw"), dict) else {}
    for k in keys:
        v = raw.get(k)
        if v not in (None, "", "-"):
            return v
    for k in keys:
        v = st.get(k)
        if v not in (None, "", "-"):
            return v
    metrics = str(st.get("metrics") or "")
    if metrics:
        import re
        for k in keys:
            m = re.search(rf"(?:^|/)\s*{re.escape(k)}=([^/]+)", metrics)
            if m:
                val = m.group(1).strip()
                if val and val != "-":
                    return val
    return "-"

def gworker_state_text(name: Optional[str] = None) -> str:
    names = [name] if name else list(WORKER_SPECS.keys())
    states = {n: worker_state_dict(n) for n in names if n in WORKER_SPECS}
    ok_all = all(s.get("ok") for s in states.values()) if states else False
    title = "🧩 worker 상태 /gworker_state" if not name else f"🧩 {WORKER_SPECS[name]['label']} worker 상태"
    if name:
        lines = [title, "✅ 정상" if ok_all else "⚠️ 확인 필요", "", *[format_worker_state_line(s) for s in states.values()]]
        if name == "strategy":
            writer = read_json(BOT_DIR / "clean_strategy_paper_latest_writer_status.json")
            writer = writer if isinstance(writer, dict) else {}
            io = read_json(BOT_DIR / "clean_strategy_io_status_v1021.json")
            io = io if isinstance(io, dict) else {}
            raw = states.get("strategy", {}).get("raw") if isinstance(states.get("strategy", {}).get("raw"), dict) else {}
            if writer:
                rows = writer.get('candidate_rows_v1021', writer.get('rows_written', writer.get('compact_rows',0)))
                out_bytes = writer.get('candidate_bytes_v1021', writer.get('output_bytes',0))
                total_state = str(writer.get('candidate_total_commit_count_state_v1026') or '')
                total_raw = writer.get('candidate_total_commit_count_v1026')
                total_text = str(total_raw) if total_state == 'recorded' and total_raw is not None else '기록 없음(구 상태)'
                process_text = str(writer.get('candidate_process_commit_count_v1026')) if 'candidate_process_commit_count_v1026' in writer else '기록 없음(구 상태)'
                last_commit_text = str(writer.get('candidate_last_commit_text_v1026') or '기록 없음')
                last_commit_id = str(writer.get('candidate_last_commit_id_v1026') or '-')
                last_pid_state = str(writer.get('candidate_last_commit_pid_state_v1028') or '')
                last_pid_raw = writer.get('candidate_last_commit_pid_v1028')
                last_commit_pid = str(last_pid_raw) if last_pid_state == 'recorded' and last_pid_raw is not None else '기록 없음(구 상태)'
                runtime_pid = str(writer.get('candidate_runtime_pid_v1028') or writer.get('candidate_writer_pid_v1026') or '-')
                lines += [
                    "",
                    "[Strategy 후보 commit · canonical writer]",
                    f"- 후보파일: {rows}행 / {out_bytes}B / 평균 {writer.get('candidate_avg_row_bytes_v1021',0)}B / 최대 {writer.get('candidate_max_row_bytes_v1021',0)}B",
                    f"- commit: 누적 {total_text} / 현재 실행 {process_text} / 범위 {writer.get('candidate_total_commit_scope_v1026','v1026부터 기록')}",
                    f"- 마지막 commit: {last_commit_text} / PID {last_commit_pid} / ID {last_commit_id}",
                    f"- 현재 runtime PID: {runtime_pid} / 마지막 commit PID와 분리 v1028", 
                    f"- 크기상한: soft 초과 {writer.get('candidate_over_soft_ceiling_v1021',0)} / hard 초과 {writer.get('candidate_over_hard_ceiling_v1021',0)} / 계약검수 실패 {writer.get('candidate_validation_failures_v1021',0)}",
                    f"- 압축기 v1029: single-pass {writer.get('candidate_compactor_single_pass_budget_v1029',False)} / full-row JSON 검사 {writer.get('candidate_compactor_full_row_json_checks_per_row_v1029','-')}회 / owner {writer.get('candidate_writer_phase_owner_v1029','-')}",
                    f"- 마지막 결과: {writer.get('result','-')} / role·source 원본감사 {writer.get('role_source_from_full_rows_v1021',False)}",
                    "- 원천: clean_strategy_paper_latest_writer_status.json · legacy 누락은 0이 아니라 기록 없음",
                ]
            lines += [
                "",
                "[Strategy 구조 cache I/O]",
                f"- write {io.get('source_cache_write_count_v1021',0)} / skip {io.get('source_cache_skip_count_v1021',0)} / checkpoint {io.get('source_cache_checkpoint_sec_v1021',300)}초",
                f"- 원천분리: {io.get('status_source_split_owner_v1025','candidate=writer_status; cache=io_status; liveness=worker_status')}",
            ]
            if isinstance(raw, dict):
                cache_v1032 = raw.get('candle_overlay_cache_v1032') if isinstance(raw.get('candle_overlay_cache_v1032'), dict) else {}
                lab_v1032 = raw.get('structure_lab_v956') if isinstance(raw.get('structure_lab_v956'), dict) else {}
                lab_phase_v1032 = lab_v1032.get('structure_lab_subphase_v1032') if isinstance(lab_v1032.get('structure_lab_subphase_v1032'), dict) else {}
                if cache_v1032 or lab_v1032:
                    lines += [
                        "",
                        "[Strategy 입력 재사용 · v1032]",
                        f"- candle overlay cache: entry {int(cache_v1032.get('entries') or 0)} / hit {int(cache_v1032.get('hits') or 0)} / miss {int(cache_v1032.get('misses') or 0)} / age refresh {int(cache_v1032.get('age_refreshes') or 0)}",
                        f"- structure candle map: {lab_v1032.get('candle_map_source_v1032','-')} / 같은 cycle map 재사용 {lab_v1032.get('canonical_candle_map_reused_v1032',False)}",
                        f"- structure 세부: source {float(lab_phase_v1032.get('source_load_wall_sec') or 0.0):.3f}s / context {float(lab_phase_v1032.get('context_build_wall_sec') or 0.0):.3f}s / refresh {float(lab_phase_v1032.get('map_live_refresh_wall_sec') or 0.0):.3f}s / scan {float(lab_phase_v1032.get('scanner_gap_wall_sec') or 0.0):.3f}s / write {float(lab_phase_v1032.get('state_payload_write_wall_sec') or 0.0):.3f}s",
                    ]
            if isinstance(raw, dict) and raw.get('strategy_live_phase_v1028'):
                live_name = str(raw.get('strategy_live_phase_v1028') or '-')
                live_elapsed = float(raw.get('strategy_live_phase_elapsed_sec_v1028') or 0.0)
                live_cycle_age = float(raw.get('strategy_live_cycle_age_sec_v1028') or 0.0)
                last_done = str(raw.get('strategy_live_last_completed_phase_v1028') or '-')
                last_done_wall = float(raw.get('strategy_live_last_completed_wall_sec_v1028') or 0.0)
                live_state = '병목 의심' if live_elapsed >= 30.0 and live_name not in {'sleep_wait_v1028','boot_v1028'} else '진행 중'
                lines += [
                    "",
                    "[Strategy 실시간 실행 위치 · v1032]",
                    f"- 현재: {live_name} / 경과 {live_elapsed:.1f}초 / cycle {live_cycle_age:.1f}초 / 순번 {int(raw.get('strategy_live_phase_sequence_v1028') or 0)}",
                    f"- 직전 완료: {last_done} / wall {last_done_wall:.3f}초 / 판정 {live_state}",
                    f"- owner: {raw.get('strategy_live_phase_owner_v1028','-')} / 추가 writer {raw.get('strategy_live_phase_extra_writer_v1028',False)}",
                ]
            cpu_profile = read_json(BOT_DIR / 'clean_strategy_cpu_profile_v1027.json')
            cpu_profile = cpu_profile if isinstance(cpu_profile, dict) else {}
            if cpu_profile:
                top = cpu_profile.get('top_phases') if isinstance(cpu_profile.get('top_phases'), list) else []
                top_text = ' / '.join(
                    f"{x.get('phase','-')} CPU {float(x.get('cpu_sec') or 0.0):.3f}s·wall {float(x.get('wall_sec') or 0.0):.3f}s·call {int(x.get('calls') or 0)}·row {int(x.get('rows') or 0)}"
                    for x in top[:6] if isinstance(x, dict)
                ) or '-'
                restart = cpu_profile.get('candidate_commit_restart_check_v1027') if isinstance(cpu_profile.get('candidate_commit_restart_check_v1027'), dict) else {}
                lines += [
                    "",
                    "[Strategy CPU 구간 측정 · v1032]",
                    f"- cycle wall {float(cpu_profile.get('cycle_wall_sec') or 0.0):.3f}s / CPU {float(cpu_profile.get('cycle_cpu_sec') or 0.0):.3f}s / busy {float(cpu_profile.get('measured_cpu_busy_pct_of_cycle') or 0.0):.1f}% / phase {int(cpu_profile.get('phase_count') or 0)}",
                    f"- 범위 단일화: 후보 commit {float(cpu_profile.get('candidate_commit_elapsed_sec_v1031') or raw.get('candidate_commit_sec_v1031') or 0.0):.3f}s / 후처리 {float(cpu_profile.get('post_commit_elapsed_sec_v1031') or raw.get('post_commit_sec_v1031') or 0.0):.3f}s / 전체 {float(cpu_profile.get('full_cycle_elapsed_sec_v1031') or raw.get('full_cycle_sec_v1031') or cpu_profile.get('cycle_wall_sec') or 0.0):.3f}s / status last 범위 {raw.get('last_sec_scope_v1031','-')}",
                    f"- TOP: {top_text}",
                    f"- 재시작 영속성: 이전 누적 {restart.get('prior_process_total','-')} / 현재 process {restart.get('current_process_commit_count','-')} / 총 {restart.get('total_commit_count','-')} / PID 일치 {restart.get('writer_pid_matches_current',False)} / 증명 {restart.get('restart_persistence_proven',False)}",
                    "- 측정 전용: 전략조건·후보내용·Paper 원장 변경 없음",
                ]
            if isinstance(raw, dict) and raw:
                lines += [
                    "",
                    "[Strategy 생존 상태]",
                    f"- 현재 phase: {raw.get('phase','-')} / heartbeat-only {raw.get('status_heartbeat_only_v1022',False)}",
                    f"- heartbeat: {raw.get('status_heartbeat_count_v1022',0)}회 / 주기 {raw.get('status_heartbeat_sec_v1022','-')}초 / owner {raw.get('status_heartbeat_owner_v1022','-')}",
                    f"- 상태 writer: {raw.get('status_writer_owner_v1022',raw.get('status_writer_owner_v1008','-'))} / candidate commit {raw.get('candidate_commit_status_v1022',False)}",
                    f"- canonical 보존: {raw.get('status_canonical_payload_preserved_v1023',False)} / stale timestamp 차단 {raw.get('status_volatile_timestamp_blocked_v1023',False)} / field {raw.get('status_canonical_field_count_v1023',0)}",
                    "",
                    "[Strategy 구조 reader · canonical writer]",
                    f"- context: 전체 {writer.get('structure_context_rows_v871',0)} / 발견 {writer.get('structure_context_found_rows_v1024',0)} / top {writer.get('structure_context_top_rows_v1024',0)} / nested {writer.get('structure_context_nested_rows_v1024',0)}",
                    f"- 준비도: major {writer.get('major_ready_rows_v871',0)} / setup {writer.get('setup_ready_rows_v871',0)} / execution {writer.get('execution_ready_rows_v871',0)}",
                    f"- reader: {writer.get('structure_context_reader_owner_v1024','-')} / 합계일치 {writer.get('structure_context_reader_consistency_v1024',False)}",
                ]
        return "\n".join(lines)
    def st(n): return states.get(n, {})
    lines = [title, "✅ 정상" if ok_all else "⚠️ 확인 필요", "", "[한눈요약]"]
    lines.append(f"- 스캐너: 전체 {_gworker_val(st('scanner'),'row_count','pool_count')}개 / {_gworker_val(st('scanner'),'last_sec')}초")
    lines.append(f"- 특징: {_gworker_val(st('feature'),'row_count')}개 표준값 / {_gworker_val(st('feature'),'last_sec')}초")
    lines.append(f"- 캔들: {_gworker_val(st('candle'),'row_count')}개 보강 / target {_gworker_val(st('candle'),'target_count')} / {_gworker_val(st('candle'),'last_sec')}초")
    lines.append(f"- 호가요약: 전체 {_gworker_val(st('orderflow'),'row_count')}개 / WS {_gworker_val(st('orderflow'),'fresh_ws')} / micro {_gworker_val(st('orderflow'),'fresh_micro')} / {_gworker_val(st('orderflow'),'last_sec')}초")
    lines.append(f"- 정보배차: target {_gworker_val(st('target_router'),'target_count')}개 / S근접 {_gworker_val(st('target_router'),'near_s_count')} / micro필요 {_gworker_val(st('target_router'),'need_micro')} / {_gworker_val(st('target_router'),'last_sec')}초")
    lines.append(f"- 전략판정: 평가 {_gworker_val(st('strategy'),'evaluated')}개 / S {_gworker_val(st('strategy'),'s_count')} / target {_gworker_val(st('strategy'),'target_count')} / {_gworker_val(st('strategy'),'last_sec')}초")
    lines.append(f"- 위험/복기: risk {_gworker_val(st('risk'),'last_sec')}초 / review 최근완료 {_gworker_val(st('review'),'closed_recent')}개, 큰손실 {_gworker_val(st('review'),'big_loss')}, 좋은승리 {_gworker_val(st('review'),'good_win')}")
    lines += ["", "[원본 상세]"]
    lines += [format_worker_state_line(s) for s in states.values()]
    lines += ["", "명령", "- /gscanner_state /gcandle_state /gmarket_state /gfeature_state", "- /gorderflow_state /grisk_state /gstrategy_state /gtarget_state /greview_state /gexact_replay"]
    return "\n".join(lines)

def wait_worker_ready(name: str, target_version: str = "", timeout: float = 9.0) -> tuple[dict, list[str]]:
    spec = WORKER_SPECS.get(name, {})
    timeout = float(spec.get("ready_timeout") or timeout)
    t0 = time.time()
    notes = []
    last = {}
    while time.time() - t0 < timeout:
        last = worker_state_dict(name)
        if last.get("service_active") == "active" and worker_semantic_ready(last) and last.get("age", 9999) < max(20, timeout):
            if not target_version or str(last.get("status_version")) == str(target_version):
                notes.append(f"ready {name} age={last.get('age_text')} version={last.get('status_version')}")
                return last, notes
        time.sleep(0.6)
    notes.append(f"ready_timeout {name} last={last.get('state','?')} age={last.get('age_text','?')} ver={last.get('status_version','?')}")
    return last, notes

def _status_event_ts_v1111(obj: Any, path: Path) -> float:
    if isinstance(obj, dict):
        for key in ("updated_ts", "ts", "acquired_ts", "created_ts"):
            try:
                value = float(obj.get(key) or 0.0)
            except Exception:
                value = 0.0
            if value > 0:
                return value
    try:
        return float(path.stat().st_mtime)
    except Exception:
        return 0.0

def _review_sqlite_writer_pids_v1123() -> list[int]:
    """Return current live write-FD owners of the Review dedup SQLite file."""
    target=str((BOT_DIR/'review_append_dedup_v1013.sqlite3').resolve())
    try:
        snapshot=_audit_open_fd_snapshot()
        rows=(snapshot.get('owners') or {}).get(target,[]) if isinstance(snapshot,dict) else []
    except Exception:
        rows=[]
    out=[]
    for row in rows:
        if str(row.get('mode') or '')!='write':
            continue
        try: pid=int(row.get('pid') or 0)
        except Exception: pid=0
        if pid>0 and pid_alive(pid): out.append(pid)
    return sorted(set(out))

def _review_kernel_lock_evidence_v1123(mainpid: int) -> dict:
    """Prove the live Review lock from the kernel, not a mutable status JSON."""
    path=BOT_DIR/'runtime'/'review_worker_singleton_v1121.lock'
    out={'path':str(path),'main_pid':int(mainpid or 0),'exists':path.exists(),'payload_pid':0,
         'payload_version':'','payload_acquired_ts':0.0,'mainpid_has_lock_fd':False,
         'guard_lock_blocked':False,'ok':False}
    try:
        payload=json.loads(path.read_text(encoding='utf-8',errors='ignore') or '{}') if path.exists() else {}
        if isinstance(payload,dict):
            out['payload_pid']=int(payload.get('pid') or 0)
            out['payload_version']=str(payload.get('version') or '')
            out['payload_acquired_ts']=float(payload.get('acquired_ts') or 0.0)
    except Exception as exc:
        out['payload_error']=f'{type(exc).__name__}: {exc}'
    try:
        st=path.stat(); target=(int(st.st_dev),int(st.st_ino))
        fdroot=Path('/proc')/str(int(mainpid or 0))/'fd'
        for fd in fdroot.iterdir():
            try:
                fst=os.stat(fd)
                if (int(fst.st_dev),int(fst.st_ino))==target:
                    out['mainpid_has_lock_fd']=True; out['mainpid_lock_fd']=fd.name; break
            except Exception:
                continue
    except Exception as exc:
        out['fd_error']=f'{type(exc).__name__}: {exc}'
    fh=None
    try:
        path.parent.mkdir(parents=True,exist_ok=True)
        fh=path.open('a+',encoding='utf-8')
        try:
            fcntl.flock(fh.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
            out['guard_lock_blocked']=False
            fcntl.flock(fh.fileno(),fcntl.LOCK_UN)
        except BlockingIOError:
            out['guard_lock_blocked']=True
    except Exception as exc:
        out['probe_error']=f'{type(exc).__name__}: {exc}'
    finally:
        try:
            if fh is not None: fh.close()
        except Exception: pass
    out['ok']=bool(mainpid and pid_alive(int(mainpid)) and out['mainpid_has_lock_fd'] and out['guard_lock_blocked'] and out['payload_pid']==int(mainpid))
    return out

def _worker_singleton_evidence_v1111(
    name: str,
    target_version: str = "",
    started_after_ts: float = 0.0,
) -> dict:
    """Canonical per-worker fresh-boot proof.

    This is one direct contract, not a version-specific wrapper.  Every worker
    proves service/PID/status/version/freshness.  Strategy and Review also
    prove their existing canonical singleton lock.
    """
    spec = WORKER_SPECS.get(name) or {}
    service = str(spec.get("service") or "")
    mainpid = 0
    if service:
        _rc, text = run(["systemctl", "show", service, "-p", "MainPID", "--value"], timeout=5)
        try:
            mainpid = int((text or "0").strip() or "0")
        except Exception:
            mainpid = 0
    pids = find_worker_pids(name) if name in WORKER_SPECS else []
    if mainpid and _pid_matches_worker_v1111(name, mainpid) and mainpid not in pids:
        pids.append(mainpid)
        pids = sorted(set(pids))
    status_path = worker_status_path(name) if name in WORKER_SPECS else BOT_DIR / "missing"
    status = read_json(status_path) if name in WORKER_SPECS else {}
    status = status if isinstance(status, dict) else {}
    try:
        status_pid = int(status.get("pid") or 0)
    except Exception:
        status_pid = 0
    status_version = str(status.get("version") or "")
    status_ts = _status_event_ts_v1111(status, status_path)
    kernel_lock_v1123 = {}
    if name == "strategy":
        lock_path = BOT_DIR / "clean_strategy_singleton_status_v1111.json"
        lock_status = read_json(lock_path)
        lock_status = lock_status if isinstance(lock_status, dict) else {}
        try:
            lock_pid = int(lock_status.get("pid") or 0)
        except Exception:
            lock_pid = 0
        lock_version = str(lock_status.get("version") or "")
        lock_ts = _status_event_ts_v1111(lock_status, lock_path)
    elif name == "review":
        lock_path = BOT_DIR / "runtime" / "review_worker_singleton_v1121.lock"
        kernel_lock_v1123 = _review_kernel_lock_evidence_v1123(mainpid)
        lock_pid = int(kernel_lock_v1123.get("payload_pid") or 0) if kernel_lock_v1123.get("ok") else 0
        lock_version = str(kernel_lock_v1123.get("payload_version") or "")
        lock_ts = float(kernel_lock_v1123.get("payload_acquired_ts") or 0.0)
    else:
        lock_path = BOT_DIR / "missing_worker_singleton_status.json"
        lock_pid = 0
        lock_version = ""
        lock_ts = 0.0
    cmdline = _proc_cmdline_v1111(mainpid) if mainpid else ""
    exact_one = len(pids) == 1
    pid_match = bool(exact_one and mainpid and pids[0] == mainpid)
    cmdline_match = bool(mainpid and _pid_matches_worker_v1111(name, mainpid))
    status_pid_match = bool(mainpid and status_pid == mainpid)
    requires_lock = name in {"strategy", "review"}
    lock_pid_match = bool(
        not requires_lock
        or (kernel_lock_v1123.get("ok") if name == "review" else (mainpid and lock_pid == mainpid))
    )
    status_version_match = bool(not target_version or status_version == target_version)
    lock_version_match = bool(not requires_lock or not target_version or lock_version == target_version)
    freshness_floor = max(0.0, float(started_after_ts or 0.0) - 1.0)
    status_fresh_boot = bool(not started_after_ts or status_ts >= freshness_floor)
    lock_fresh_boot = bool(not requires_lock or not started_after_ts or lock_ts >= freshness_floor)
    state_running = worker_semantic_ready(status)
    service_active = False
    if service:
        _rc, active_text = run(["systemctl", "is-active", service], timeout=5)
        service_active = (active_text or "").strip() == "active"
    checks = {
        "service_active": service_active,
        "mainpid_alive": bool(mainpid and pid_alive(mainpid)),
        "cmdline_match": cmdline_match,
        "exact_one": exact_one,
        "pid_match": pid_match,
        "status_state_running": state_running,
        "status_pid_match": status_pid_match,
        "status_version_match": status_version_match,
        "status_fresh_boot": status_fresh_boot,
        "lock_pid_match": lock_pid_match,
        "lock_version_match": lock_version_match,
        "lock_fresh_boot": lock_fresh_boot,
    }
    reasons = [key for key, value in checks.items() if not value]
    return {
        "name": name,
        "service": service,
        "main_pid": mainpid,
        "pids": pids,
        "cmdline": cmdline,
        "status_pid": status_pid,
        "status_version": status_version,
        "status_ts": status_ts,
        "lock_pid": lock_pid,
        "lock_version": lock_version,
        "lock_ts": lock_ts,
        "kernel_lock_v1123": kernel_lock_v1123,
        "target_version": target_version,
        "started_after_ts": started_after_ts,
        "checks": checks,
        "reasons": reasons,
        "ok": not reasons,
    }

def _wait_worker_fresh_boot_v1111(
    name: str,
    target_version: str,
    started_after_ts: float,
    timeout: float = 65.0,
) -> tuple[bool, list[str], dict]:
    """Prove that the canonical systemd restart produced one fresh target runtime.

    v1111 deliberately keeps the long-used worker deployment path:
    cleanup non-systemd duplicates -> systemctl restart -> wait for target status.
    The only new part is strict fresh-boot evidence, so an old status row can
    never be accepted as the new process.
    """
    notes: list[str] = []
    service = str(WORKER_SPECS[name]["service"])
    deadline = time.time() + max(30.0, float(timeout))
    evidence: dict = {}
    while time.time() < deadline:
        evidence = _worker_singleton_evidence_v1111(
            name,
            target_version=target_version,
            started_after_ts=started_after_ts,
        )
        if evidence.get("ok"):
            notes.append(
                "fresh boot proven "
                f"MainPID={evidence.get('main_pid')} pids={evidence.get('pids')} "
                f"statusPID={evidence.get('status_pid')} lockPID={evidence.get('lock_pid')} "
                f"version={evidence.get('status_version')}"
            )
            return True, notes, evidence
        time.sleep(0.6)
    notes.append(
        "fresh boot timeout "
        f"MainPID={evidence.get('main_pid')} pids={evidence.get('pids')} "
        f"statusPID={evidence.get('status_pid')} statusVer={evidence.get('status_version')} "
        f"lockPID={evidence.get('lock_pid')} lockVer={evidence.get('lock_version')} "
        f"reasons={evidence.get('reasons')}"
    )
    _rc, journal = run(["journalctl", "-u", service, "-n", "30", "--no-pager"], timeout=8)
    if journal:
        notes.append("journal tail: " + tail(journal, 900).replace("\n", " | "))
    return False, notes, evidence

def _restart_worker_canonical_v1111(
    name: str,
    target_version: str,
    timeout: float = 65.0,
) -> tuple[bool, list[str], dict]:
    """Use the original canonical worker restart path plus fresh proof."""
    notes = cleanup_direct_worker_pids(name)
    service = str(WORKER_SPECS[name]["service"])
    restart_requested_ts = time.time()
    rc, out = run(["systemctl", "restart", service], timeout=35)
    notes.append(f"restart rc={rc} {tail(out,160)}".strip())
    if rc != 0:
        evidence = _worker_singleton_evidence_v1111(
            name, target_version=target_version, started_after_ts=restart_requested_ts
        )
        return False, notes, evidence
    ok, wait_notes, evidence = _wait_worker_fresh_boot_v1111(
        name,
        target_version=target_version,
        started_after_ts=restart_requested_ts,
        timeout=timeout,
    )
    notes.extend(wait_notes)
    return ok, notes, evidence

def _restart_review_atomic_v1122(target_version: str, timeout: float=100.0) -> tuple[bool, list[str], dict]:
    """Stop -> prove zero Review family PID -> start once -> prove exact one.

    Unlike the generic restart path, this transaction includes the previous
    systemd MainPID and every historical review_worker_v*.py direct process.
    No SQLite writer is allowed to survive across the alias replacement.
    """
    name='review'; service=str(WORKER_SPECS[name]['service']); notes=[]
    rc,out=run(['systemctl','stop',service],timeout=35)
    notes.append(f'stop rc={rc} {tail(out,180)}'.strip())
    deadline=time.time()+8.0
    while time.time()<deadline and find_worker_pids(name,include_helpers=True):
        time.sleep(0.25)
    survivors=find_worker_pids(name,include_helpers=True)
    for pid in survivors:
        try: os.kill(pid,signal.SIGTERM); notes.append(f'family pid {pid} TERM')
        except Exception as exc: notes.append(f'family pid {pid} TERM failed {type(exc).__name__}')
    deadline=time.time()+3.0
    while time.time()<deadline and find_worker_pids(name,include_helpers=True):
        time.sleep(0.2)
    survivors=find_worker_pids(name,include_helpers=True)
    for pid in survivors:
        try: os.kill(pid,signal.SIGKILL); notes.append(f'family pid {pid} KILL')
        except Exception as exc: notes.append(f'family pid {pid} KILL failed {type(exc).__name__}')
    time.sleep(0.25)
    remaining=find_worker_pids(name,include_helpers=True)
    sqlite_writers=_review_sqlite_writer_pids_v1123()
    for pid in sqlite_writers:
        if pid==os.getpid():
            continue
        try: os.kill(pid,signal.SIGTERM); notes.append(f'sqlite writer pid {pid} TERM')
        except Exception as exc: notes.append(f'sqlite writer pid {pid} TERM failed {type(exc).__name__}')
    deadline=time.time()+3.0
    while time.time()<deadline and _review_sqlite_writer_pids_v1123():
        time.sleep(0.2)
    sqlite_writers=_review_sqlite_writer_pids_v1123()
    for pid in sqlite_writers:
        if pid==os.getpid():
            continue
        try: os.kill(pid,signal.SIGKILL); notes.append(f'sqlite writer pid {pid} KILL')
        except Exception as exc: notes.append(f'sqlite writer pid {pid} KILL failed {type(exc).__name__}')
    time.sleep(0.2)
    sqlite_writers=_review_sqlite_writer_pids_v1123()
    if remaining or sqlite_writers:
        evidence=_worker_singleton_evidence_v1111(name,target_version=target_version)
        notes.append(f'zero writer proof failed remaining_family={remaining} sqlite_writers={sqlite_writers}')
        return False,notes,evidence
    notes.append('zero Review family PID and zero SQLite writer proven before start')
    start_requested_ts=time.time()
    rc,out=run(['systemctl','start',service],timeout=35)
    notes.append(f'start rc={rc} {tail(out,180)}'.strip())
    if rc!=0:
        return False,notes,_worker_singleton_evidence_v1111(name,target_version=target_version,started_after_ts=start_requested_ts)
    ok,wait_notes,evidence=_wait_worker_fresh_boot_v1111(name,target_version=target_version,started_after_ts=start_requested_ts,timeout=timeout)
    notes.extend(wait_notes)
    return ok,notes,evidence

def apply_worker_latest(name: str, force: bool = False, explicit: Optional[str] = None, restart: bool = True) -> dict:
    t0 = perf_now()
    if name not in WORKER_SPECS:
        return {"ok": False, "name": name, "error": "unknown worker"}
    spec = WORKER_SPECS[name]
    target = worker_latest_file(name, explicit=explicit)
    if not target or not target.exists():
        return {"ok": False, "name": name, "error": "target missing", "target": str(target or "?")}
    active = worker_active_path(name)
    target_ver = worker_version(target)
    notes = []
    changed = force or (not active.exists()) or (short_hash(active) != short_hash(target))
    before = worker_state_dict(name)
    before_singleton = _worker_singleton_evidence_v1111(name)
    # v1110: fast-skip is forbidden when runtime has duplicate/mismatched PIDs.
    if not changed and not force and before.get("service_active") == "active" and before.get("alive") and before.get("sync_ok") and before_singleton.get("ok"):
        return {
            "ok": True,
            "name": name,
            "label": spec["label"],
            "target": target.name,
            "target_version": target_ver,
            "active": active.name,
            "changed": False,
            "restarted": False,
            "hash": f"target {short_hash(target)} / active {short_hash(active)}",
            "service": spec["service"],
            "state": before,
            "notes": ["fast-skip: hash 동일 + service active + sync → py_compile/복사/재시작/ready wait 생략"],
            "total_sec": perf_now() - t0,
        }
    rc, out = run([WORKER_PYTHON_BIN, "-m", "py_compile", str(target)], timeout=18)
    if rc != 0:
        return {"ok": False, "name": name, "target": target.name, "error": "py_compile failed", "compile": tail(out, 700)}
    if changed:
        backup = None
        if active.exists():
            backup = BOT_DIR / f"{active.name}.backup_guard_worker_apply_{time.strftime('%Y%m%d_%H%M%S')}"
            try:
                shutil.copy2(active, backup)
                notes.append(f"backup {backup.name}")
            except Exception as e:
                notes.append(f"backup failed {type(e).__name__}: {e}")
        shutil.copy2(target, active)
        worker_marker_path(name).write_text(target.name + "\n", encoding="utf-8")
        notes.append(f"copy {target.name} -> {active.name}")
    ok_unit, unit_notes = ensure_worker_service_installed(name)
    notes += unit_notes
    if not ok_unit:
        return {"ok": False, "name": name, "target": target.name, "changed": changed, "error": "service install failed", "notes": notes}
    need_restart = bool(restart and (changed or force or before.get("service_active") != "active" or not before.get("alive") or not before.get("sync_ok") or not before_singleton.get("ok")))
    singleton_apply_ok = True
    if need_restart and name == "strategy":
        singleton_apply_ok, singleton_notes, singleton_runtime = _restart_worker_canonical_v1111(name, target_version=target_ver)
        notes += singleton_notes
        rc, out = (0 if singleton_apply_ok else 1), "strategy canonical restart + fresh-boot proof"
    elif need_restart and name == 'review':
        singleton_apply_ok, singleton_notes, singleton_runtime = _restart_review_atomic_v1122(target_version=target_ver)
        notes += singleton_notes
        rc, out = (0 if singleton_apply_ok else 1), 'review stop-drain-kill-start + fresh singleton proof'
    elif need_restart:
        notes += cleanup_direct_worker_pids(name)
        rc, out = run(["systemctl", "restart", str(spec["service"])], timeout=35)
        notes.append(f"restart rc={rc} {tail(out,160)}".strip())
    else:
        rc, out = run(["systemctl", "start", str(spec["service"])], timeout=20)
        if rc not in {0, 1}:
            notes.append(f"start-check rc={rc} {tail(out,160)}")
    after, wait_notes = wait_worker_ready(name, target_version=target_ver, timeout=9)
    notes += wait_notes
    singleton_after = _worker_singleton_evidence_v1111(name, target_version=target_ver)
    if name in {'strategy','review'}:
        notes.append(f"post-apply singleton={singleton_after}")
    ok = bool(singleton_apply_ok and after.get("service_active") == "active" and worker_semantic_ready(after) and after.get("sync_ok") and singleton_after.get("ok"))
    return {
        "ok": ok,
        "name": name,
        "label": spec["label"],
        "target": target.name,
        "target_version": target_ver,
        "active": active.name,
        "changed": changed,
        "restarted": need_restart,
        "hash": f"target {short_hash(target)} / active {short_hash(active)}",
        "service": spec["service"],
        "state": after,
        "singleton": singleton_after,
        "error": None if ok else (f'{name} singleton verification failed' if name in {'strategy','review'} and not singleton_after.get('ok') else None),
        "notes": notes[:28],
        "total_sec": perf_now() - t0,
    }

def format_worker_apply_result(res: dict) -> str:
    ok = "✅" if res.get("ok") else "❌"
    mode = "교체+재시작" if res.get("changed") and res.get("restarted") else ("교체" if res.get("changed") else ("재시작" if res.get("restarted") else "변경없음/유지"))
    lines = [f"{ok} {res.get('label', res.get('name','worker'))} worker {mode}"]
    for k in ["target", "target_version", "active", "hash", "service", "error"]:
        if res.get(k) not in (None, ""):
            lines.append(f"- {k}: {res.get(k)}")
    st = res.get("state") or {}
    if st:
        lines.append(f"- state: {st.get('verdict','-')} / svc {st.get('service_active','-')} / age {st.get('age_text','-')} / metrics {st.get('metrics','-')}")
    if res.get("notes"):
        lines.append("- notes:")
        lines.extend(f"  · {str(x)[:260]}" for x in res.get("notes", [])[:16])
    lines.append(f"- total: {fmt_sec(res.get('total_sec',0))}")
    return "\n".join(lines)

def apply_workers_latest(force: bool = False, explicit: Optional[str] = None, restart: bool = True) -> dict:
    t0 = perf_now()
    results = {}
    for name in WORKER_SPECS:
        results[name] = apply_worker_latest(name, force=force, explicit=None, restart=restart)
    ok = all(bool(r.get("ok")) for r in results.values())
    status = read_json(BOT_DIR / UPGRADE_STATUS_FILE)
    status["workers"] = results
    status["workers_upgrade_time"] = now()
    status["workers_upgrade_total_sec"] = perf_now() - t0
    write_json(BOT_DIR / UPGRADE_STATUS_FILE, status)
    return {"ok": ok, "results": results, "total_sec": perf_now() - t0}

def gworker_upgrade_text(force: bool = False) -> str:
    res = apply_workers_latest(force=force, restart=True)
    title = "🧩 ✅ worker 최신화 완료 /gworker_upgrade" if res.get("ok") else "🧩 ❔ worker 최신화 확인 필요 /gworker_upgrade"
    parts = [title, f"- guard: {VERSION}", f"- 대상: scanner → candle → market → feature → orderflow → risk → strategy → target_router → review", f"- total: {fmt_sec(res.get('total_sec',0))}"]
    for name in WORKER_SPECS:
        parts.append("\n" + format_worker_apply_result(res["results"].get(name, {})))
    parts.append("\n다음 확인: /gworker_state 또는 메인봇 /health")
    return "\n".join(parts)

def gworker_restart_text(name: Optional[str] = None) -> str:
    names = [name] if name else list(WORKER_SPECS.keys())
    lines = ["🔁 worker 재시작 /gworker_restart"]
    for n in names:
        if n not in WORKER_SPECS:
            continue
        if n == "strategy":
            target_ver = worker_version(worker_latest_file(n, prefer_deployed=True))
            singleton_ok, notes, _singleton_runtime = _restart_worker_canonical_v1111(n, target_version=target_ver)
            rc, out = (0 if singleton_ok else 1), "strategy canonical restart + fresh-boot proof"
        elif n == 'review':
            target_ver = worker_version(worker_latest_file(n, prefer_deployed=True))
            singleton_ok, notes, _singleton_runtime = _restart_review_atomic_v1122(target_version=target_ver)
            rc, out = (0 if singleton_ok else 1), 'review atomic singleton restart'
        else:
            notes = cleanup_direct_worker_pids(n)
            rc, out = run(["systemctl", "restart", str(WORKER_SPECS[n]["service"])], timeout=35)
        st, wn = wait_worker_ready(n, timeout=15)
        ev = _worker_singleton_evidence_v1111(n, target_version=worker_version(worker_latest_file(n, prefer_deployed=True)))
        icon = "✅" if st.get("service_active") == "active" and st.get("state") == "running" and ev.get("ok") else "⚠️"
        lines.append(f"- {icon} {WORKER_SPECS[n]['label']} rc={rc} / age {st.get('age_text','-')} / state {st.get('state','-')}")
        for x in (notes + wn)[:8]:
            lines.append(f"  · {x}")
    lines.append("\n다음 확인: /gworker_state")
    return "\n".join(lines)

def gworker_log_text(name: str, n: int = 80) -> str:
    if name not in WORKER_SPECS:
        return "알 수 없는 worker야."
    spec = WORKER_SPECS[name]
    log_path = BOT_DIR / str(spec.get("log") or f"clean_{name}_worker_service.log")
    service_err_path = BOT_DIR / f"clean_{name}_worker_service.err"
    runtime_err_path = BOT_DIR / f"clean_{name}_worker_error.log"
    rc, journal = run(["journalctl", "-u", str(spec["service"]), "-n", str(max(20, min(300, n))), "--no-pager"], timeout=4)
    sections = []
    runtime_error = read_file_tail(runtime_err_path, max_bytes=50_000)
    if runtime_error.strip():
        sections.append("[실제 worker 오류파일]\n" + tail(runtime_error, 2600))
    service_text = read_file_tail(log_path, max_bytes=30_000) + "\n" + read_file_tail(service_err_path, max_bytes=20_000)
    if service_text.strip():
        sections.append("[worker 파일로그]\n" + tail(service_text, 1400))
    if journal.strip():
        sections.append("[systemd 기록]\n" + tail(journal, 1200))
    if not sections and rc == 124:
        sections.append("로그 읽기 시간초과")
    return f"🧾 {spec['label']} worker 로그\n" + ("\n\n".join(sections) if sections else "없음")

def deploy_status() -> str:
    bot_version, target, deployed, latest = get_bot_versions()
    main_resolution_v1196 = resolve_main_source_v1196()
    main_resolution_owner_v1196 = str(main_resolution_v1196.get("owner") or "-") if isinstance(main_resolution_v1196, dict) else "-"
    main_resolution_rejected_v1196 = main_resolution_v1196.get("rejected") if isinstance(main_resolution_v1196, dict) else []
    legacy_deploy_target_v1196 = read_file(BOT_DIR / "DEPLOY_TARGET.txt") or "?"
    pv = get_paper_versions()
    wsv = ws_sidecar_state_dict()
    msv = micro_state_dict()
    workers = {name: worker_state_dict(name) for name in WORKER_SPECS}
    active = is_main_service_active()
    status = read_json(BOT_DIR / UPGRADE_STATUS_FILE)
    latest_path = BOT_DIR / latest if latest != "?" else None
    latest_ver = extract_bot_version(latest_path) if latest_path else "?"
    runtime_ver = extract_recent_runtime_version(lines=260, since=service_start_since())
    brain = main_brain_state_dict()
    bot_hash = short_hash(BOT_DIR / "bot.py")
    latest_hash = short_hash(latest_path) if latest_path else "?"

    verdict_bits = []
    if active != "active":
        verdict_bits.append("메인봇 inactive")
    if latest_path and not same_version_label(bot_version, latest_ver):
        verdict_bits.append("최신파일 내부버전과 bot.py 버전 다름")
    if latest != "?" and deployed != latest:
        verdict_bits.append(".deployed_target이 최신파일과 다름")
    if pv["latest"] != "?" and pv["deployed"] not in {pv["latest"], "?"}:
        verdict_bits.append(".deployed_paper_target이 최신 paper와 다름")
    if pv["latest_version"] != "?" and pv["active_version"] != "?" and pv["latest_version"] != pv["active_version"]:
        verdict_bits.append("paper_bot 활성버전과 최신버전 다름")
    if pv.get("service") == "no_service":
        verdict_bits.append("paper_bot systemd 서비스 미등록(runtime 금지)")
    if runtime_ver not in {"시작로그 대기", "시작로그 확인불가"} and latest_path and not same_version_label(runtime_ver, bot_version):
        verdict_bits.append("bot.py 파일버전과 실제 실행로그 버전 불일치")
    if active == "active":
        bstate = str(brain.get("state") or "")
        if bstate in {"disabled", "error"}:
            verdict_bits.append("메인봇 Telegram 수신 문제: " + str(brain.get("error") or bstate)[:120])
        elif bstate not in {"polling_started", "running", "polling_started_notify_failed"}:
            verdict_bits.append("메인봇 Telegram 상태 확인 필요: " + (bstate or "미기록"))
    if not wsv.get("ok"):
        verdict_bits.append("웹소켓직원 확인 필요: " + str(wsv.get("verdict", "?")))
    if str(wsv.get("management_warning") or "-") != "-":
        verdict_bits.append("웹소켓직원 구조 확인: " + str(wsv.get("management_warning")))
    if msv.get("active_exists") and not msv.get("ok"):
        verdict_bits.append("호가체결직원 확인 필요: " + str(msv.get("verdict", "?")))
    if str(msv.get("management_warning") or "-") != "-":
        verdict_bits.append("호가체결직원 구조 확인: " + str(msv.get("management_warning")))
    for _wn, _ws in workers.items():
        if not _ws.get("ok"):
            verdict_bits.append(f"worker 확인 필요: {_ws.get('label', _wn)} {_ws.get('verdict','?')}")
    retired_service_states={name:is_service_active(name) for name in RETIRED_SERVICES_V1257}
    for _service,_state in retired_service_states.items():
        if str(_state) in {'active','activating'}:
            verdict_bits.append(f"폐기 worker가 아직 실행 중: {_service} {_state}")

    conclusion = "✅ 정상" if not verdict_bits else "❔ 확인 필요"
    last = "없음"
    if status:
        last = f"{status.get('time','?')} / {'성공' if status.get('ok') else '실패/확인필요'} / {status.get('target') or status.get('stage') or '?'}"
        if status.get("paper"):
            last += f" / paper {status.get('paper',{}).get('target','?')}"
    recent = recent_journal(lines=80, since=service_start_since())
    focus = []
    for line in (recent or "").splitlines():
        if any(x in line for x in ["Traceback", "NameError", "SyntaxError", "ImportError", "ModuleNotFoundError", "Failed", "failed", "exit-code"]):
            focus.append(line)
    focus_file = main_file_log_focus()
    if focus:
        focus_text = "\n".join(focus[-5:])
        if focus_file != "없음":
            focus_text += "\n" + focus_file
    else:
        focus_text = focus_file
    verdict_text = "\n".join(f"- ❌ {x}" for x in verdict_bits) if verdict_bits else "- 이상 없음"

    return (
        f"🧭 가드 배포상태 /gdeploy\n"
        f"{conclusion}\n\n"
        f"📊 메인봇\n"
        f"- active: {active}\n"
        f"- 최신 코드파일: {latest}\n"
        f"- 최신 내부 BOT_VERSION: {latest_ver}\n"
        f"- bot.py 내부 BOT_VERSION: {bot_version}\n"
        f"- 실제 실행 로그 버전: {runtime_ver}\n"
        f"- 내부 상태파일 버전: {brain.get('version','?')} / age {brain.get('age_text','-')}\n"
        f"- Telegram 상태: {brain.get('verdict','-')} / {brain.get('state','-')} / err {brain.get('error','-')}\n"
        f"- 명령등록: {brain.get('command_count','-')}개 / scan {brain.get('scan_stage','-')} / running {brain.get('scan_running','-')}\n"
        f"- canonical target: {target}\n"
        f"- target owner: {main_resolution_owner_v1196}\n"
        f"- legacy DEPLOY_TARGET.txt: {legacy_deploy_target_v1196}\n"
        f"- .deployed_target: {deployed}\n"
        f"- rejected target: {str(main_resolution_rejected_v1196[:3])[:360] if main_resolution_rejected_v1196 else '-'}\n"
        f"- latest hash: {latest_hash}\n"
        f"- bot.py hash: {bot_hash}\n\n"
        f"🧪 페이퍼봇\n"
        f"- service: {pv['service']}\n"
        f"- active file: {pv['active_file']}\n"
        f"- active VERSION: {pv['active_version']}\n"
        f"- target: {pv['target']}\n"
        f"- latest: {pv['latest']} / {pv['latest_version']}\n"
        f"- .deployed_paper_target: {pv['deployed']}\n"
        f"- hash: active {pv['active_hash']} / latest {pv['latest_hash']}\n\n"
        f"🛰 웹소켓직원\n"
        f"- 상태: {wsv.get('verdict')}\n"
        f"- active file: {wsv.get('active_file')} / version: {wsv.get('version')} / hash: {wsv.get('hash')}\n"
        f"- latest: {wsv.get('target','?')} / {wsv.get('target_version','?')} / target_hash {wsv.get('target_hash','?')} / sync {wsv.get('sync_ok')}\n"
        f"- 관리방식: {wsv.get('management','-')} / 경고 {wsv.get('management_warning','-')}\n"
        f"- pid: {wsv.get('used_pid') or '-'} / alive: {wsv.get('alive')} / status_age: {wsv.get('age_text','-')}\n"
        f"- python: {wsv.get('python_path') or '-'} / configured: {wsv.get('configured_python') or '-'}\n"
        f"- 수신: raw {wsv.get('raw_total',0)} / parse {wsv.get('parse_ok',0)} / price {wsv.get('price_ok',0)} / amount {wsv.get('amount_ok',0)} / match {wsv.get('match_ok',0)} / format {wsv.get('last_format','-')}\n"
        f"- cache {wsv.get('cached',0)} / fresh {wsv.get('fresh',0)} / last_error {wsv.get('last_error','-')}\n"
        f"- deployed: {read_file(BOT_DIR / DEPLOYED_WS_FILE) or '?'}\n\n"
        f"🔎 호가·체결직원\n"
        f"- 상태: {msv.get('verdict')}\n"
        f"- active file: {msv.get('active_file')} / version: {msv.get('version')} / hash: {msv.get('hash')}\n"
        f"- latest: {msv.get('target','?')} / {msv.get('target_version','?')} / target_hash {msv.get('target_hash','?')} / sync {msv.get('sync_ok')}\n"
        f"- 관리방식: {msv.get('management','-')} / 경고 {msv.get('management_warning','-')}\n"
        f"- pid: {msv.get('used_pid') or '-'} / alive: {msv.get('alive')} / status_age: {msv.get('age_text','-')}\n"
        f"- 수집: targets {msv.get('targets',0)} / cache {msv.get('cached',0)} / fresh {msv.get('fresh',0)} / orderbook_ok {msv.get('orderbook_ok',0)} / trade_ok {msv.get('trade_ok',0)}\n"
        f"- deployed: {read_file(BOT_DIR / DEPLOYED_MICRO_FILE) or '?'}\n\n"
        f"🧩 리뉴얼 worker\n"
        + "\n".join(format_worker_state_line(workers[n]) for n in WORKER_SPECS)
        + "\n\n"
        f"🧹 폐기 worker\n"
        + "\n".join(
            f"- {name}: {state} / 실행금지·파일보존"
            for name, state in retired_service_states.items()
        )
        + "\n\n"
        f"📌 판정\n{verdict_text}\n\n"
        f"📌 최근 업그레이드\n- {last}\n\n"
        f"🧾 최근 오류 의심\n{focus_text}\n\n"
        f"명령\n"
        f"- /gupgrade : 전체 최신화. 변경분만 교체/재시작\n"
        f"- /gpaper_restart : 페이퍼봇 재시작\n"
        f"- /gws_upgrade : 웹소켓직원만 최신 적용\n"
        f"- /gmicro_upgrade : 빗썸 호가·체결직원만 최신 적용\n"
        f"- /gguard_upgrade : 가드봇 자체 최신 적용\n"
        f"- /glog : 메인봇 최근 오류로그"
    )

def gexternal_state_text() -> str:
    w = ws_sidecar_state_dict()
    m = micro_state_dict()
    w_ok = bool(w.get("ok") or (w.get("alive") and int(w.get("fresh") or 0) > 0 and (str(w.get("last_error") or "-") in {"", "-", "None", "none"} or _is_reconnect_notice(w.get("last_error")))))
    m_ok = bool(m.get("ok"))
    overall = "✅ 정상" if w_ok and m_ok else ("⚠️ 확인 필요" if (w_ok or m_ok) else "❌ 외부직원 문제")
    notes = []
    if w.get("stop_suspect"):
        notes.append("- WS 마지막 종료가 signal/normal stop 계열: 가드 재시작 연동 종료 의심")
    if m.get("stop_suspect"):
        notes.append("- 호가·체결 마지막 종료가 signal/normal stop 계열: 가드 재시작 연동 종료 의심")
    if str(w.get("management_warning") or "-") != "-":
        notes.append("- WS 구조경고: " + str(w.get("management_warning")))
    if str(m.get("management_warning") or "-") != "-":
        notes.append("- 호가·체결 구조경고: " + str(m.get("management_warning")))
    if not w.get("alive"):
        notes.append("- WS 꺼짐: /gws_start 또는 /gws_restart")
    elif not w_ok:
        notes.append("- WS 확인 필요: /gws_state")
    if m.get("desired_enabled") and not m.get("alive"):
        notes.append("- 호가·체결은 켜져 있어야 하는데 꺼짐: /gmicro_start")
    elif not m_ok:
        notes.append("- 호가·체결 확인 필요: /gmicro_state")
    if any("구조경고" in str(x) for x in notes):
        overall = "⚠️ 구조 확인 필요"
    if not notes:
        notes.append("- 이상 없음")
    return "\n".join([
        "🛰 외부직원 통합상태 /gexternal_state",
        overall,
        "",
        "[0/2] 서버자원",
        *resource_status_lines(),
        "",
        "[1/2] 웹소켓 직원",
        f"{'✅' if w_ok else '⚠️'} 상태: {w.get('verdict','-')}",
        f"- pid {w.get('used_pid') or '-'} / alive {w.get('alive')} / age {w.get('age_text','-')}",
        f"- 관리방식 {w.get('management','-')} / 구조경고 {w.get('management_warning','-')}",
        f"- 수신 raw {w.get('raw_total',0)} / match {w.get('match_ok',0)} / cache {w.get('cached',0)} / fresh {w.get('fresh',0)}",
        f"- 상태메모 {('재구독 중' if _is_reconnect_notice(w.get('last_error','-')) else w.get('last_error','-'))}",
        "",
        "[2/2] 호가·체결 직원",
        f"{'✅' if m_ok else '⚠️'} 상태: {m.get('verdict','-')}",
        f"- pid {m.get('used_pid') or '-'} / alive {m.get('alive')} / age {m.get('age_text','-')}",
        f"- 관리방식 {m.get('management','-')} / 구조경고 {m.get('management_warning','-')}",
        f"- desired {'enabled' if m.get('desired_enabled') else 'disabled'}",
        f"- 수집 targets {m.get('targets',0)} / cache {m.get('cached',0)} / fresh {m.get('fresh',0)}",
        f"- 호가OK {m.get('orderbook_ok',0)} / 체결OK {m.get('trade_ok',0)} / 오류 {m.get('last_error','-')}",
        "",
        "판독",
        *notes,
        "",
        "",
        "[worker]",
        *[format_worker_state_line(worker_state_dict(n)) for n in WORKER_SPECS],
        "",
        "명령",
        "- /gws_state: 웹소켓 상세",
        "- /gmicro_state: 호가·체결 상세",
        "- /gworker_state: 리뉴얼 worker 상세",
    ])

def service_status() -> str:
    active = is_main_service_active()
    bot_version, target, deployed, latest = get_bot_versions()
    pv = get_paper_versions()
    wsv = ws_sidecar_state_dict()
    msv = micro_state_dict()
    status = read_json(BOT_DIR / UPGRADE_STATUS_FILE)
    last_ok = "없음"
    if status:
        last_ok = f"{status.get('time','?')} / {'성공' if status.get('ok') else '실패/확인필요'} / {status.get('target') or status.get('stage') or '?'}"
    issue_bits = []
    if active != "active": issue_bits.append("메인봇 inactive")
    if not wsv.get("ok"): issue_bits.append("WS 확인 필요")
    if str(wsv.get("management_warning") or "-") != "-": issue_bits.append("WS 구조경고")
    if not msv.get("ok"): issue_bits.append("micro 확인 필요")
    if str(msv.get("management_warning") or "-") != "-": issue_bits.append("micro 구조경고")
    head = "✅ 결론" if not issue_bits else "❔ 결론: 확인 필요 - " + ", ".join(issue_bits[:4])
    return (
        f"🛡 가드봇 /guard\n"
        f"{head}\n"
        f"- 메인봇: {active} / {bot_version}\n"
        f"- 페이퍼봇: {pv['service']} / {pv['active_version']}\n"
        f"- 웹소켓직원: {wsv.get('verdict')} / active {wsv.get('version')} / status {wsv.get('status_version','-')}\n"
        f"- 호가·체결직원: {msv.get('verdict')} / {msv.get('version')}\n"
        f"- 업그레이드: /gupgrade 전체 또는 /gupgrade_menu에서 개별 적용\n\n"
        f"📊 상태\n"
        f"- guard: {VERSION}\n"
        f"- main service: {MAIN_SERVICE}\n"
        f"- paper service: {PAPER_SERVICE}\n"
        f"- 최신 수익형 파일: {latest}\n"
        f"- 최신 paper 파일: {pv['latest']}\n"
        f"- 웹소켓 pid: {wsv.get('used_pid') or '-'} / alive: {wsv.get('alive')}\n"
        f"- 호가·체결 pid: {msv.get('used_pid') or '-'} / alive: {msv.get('alive')}\n"
        f"- 최근 적용: {last_ok}\n\n"
        f"🧭 자주 쓰는 명령\n"
        f"- /gdeploy 배포상태\n"
        f"- /gupgrade 전체 최신화(변경분만 교체/재시작)\n"
        f"- /gpaper_restart 페이퍼봇 재시작\n"
        f"- /gpaper_reset 페이퍼 실행연결 재설치\n"
        f"- /gpaper_service 페이퍼봇 서비스화 안내\n"
        f"- /gws_state 웹소켓직원 상태\n"
        f"- /gws_restart 웹소켓직원 재시작\n"
        f"- /gmicro_state 호가·체결직원 상태\n"
        f"- /gmicro_upgrade 호가·체결직원 최신 적용\n"
        f"- /gguard_upgrade 가드봇 자체 업그레이드\n"
        f"- /glog 최근 오류\n"
        f"- /gdeep_audit 작업자 지연·디스크 증가 원인 통합감사\n"
        f"- /gresource_owner Paper·Strategy·Review·Candle 자원 owner 정밀감사\n"
        f"- /gcleanup 디스크 순환정리"
    )

def glog(lines: int = 80) -> str:
    lines = max(20, min(160, int(lines or 80)))
    started = perf_now()
    out = recent_journal(lines=lines, timeout_sec=4)
    took = perf_now() - started
    focus = []
    for line in (out or "").splitlines():
        if any(x in line for x in ["Traceback", "NameError", "SyntaxError", "ImportError", "Exception", "ERROR", "Failed", "failure", "timeout"]):
            focus.append(line)
    if "journalctl timeout" in (out or ""):
        head = "⚠️ journalctl 지연 - 가드봇 보호를 위해 status fallback만 표시"
    elif focus:
        head = "❌ 오류 의심 줄\n" + "\n".join(focus[-16:])
    else:
        head = "✅ 최근 로그에서 뚜렷한 Python 오류 줄 없음"
    return f"🧾 최근 로그 /glog {lines}\n- 방식: 짧은 timeout journal tail / {took:.1f}s\n\n{head}\n\n[tail]\n{tail(out, 2200)}"

def unlock_deploy() -> str:
    removed = []
    for p in [Path("/tmp/tradingbot_auto_deploy.lock"), BOT_DIR / "tradingbot_auto_deploy.lock"]:
        try:
            if p.exists():
                p.unlink()
                removed.append(str(p))
        except Exception as e:
            removed.append(f"{p}: {type(e).__name__}: {e}")
    return "🔓 lock 해제 /gunlock\n- removed: " + (", ".join(removed) if removed else "없음")

def _audit_int(value, default: int = 0) -> int:
    try:
        return int(float(value))
    except Exception:
        return int(default)

def _audit_float(value, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)

def _audit_rel(path) -> str:
    try:
        pp = Path(path)
        return str(pp.relative_to(BOT_DIR))
    except Exception:
        return str(path)

def _audit_fmt_delta(value) -> str:
    n = _audit_int(value, 0)
    sign = "+" if n >= 0 else "-"
    return sign + _fmt_bytes(abs(n))

def _audit_scan_files(root: Path, max_files: int = 50000) -> dict:
    files: dict[str, int] = {}
    errors = 0
    scanned = 0
    truncated = False
    try:
        root = root.resolve()
    except Exception:
        root = Path(root)
    if not root.exists():
        return {"root": str(root), "files": files, "total": 0, "scanned": 0, "errors": 0, "truncated": False}
    try:
        for dirpath, dirnames, filenames in os.walk(str(root), followlinks=False):
            # 가상/마운트 하위가 섞이지 않도록 symlink directory는 내려가지 않는다.
            safe_dirs = []
            for name in dirnames:
                dp = Path(dirpath) / name
                try:
                    if not dp.is_symlink():
                        safe_dirs.append(name)
                except Exception:
                    errors += 1
            dirnames[:] = safe_dirs
            for name in filenames:
                if scanned >= max_files:
                    truncated = True
                    break
                fp = Path(dirpath) / name
                scanned += 1
                try:
                    if fp.is_symlink() or not fp.is_file():
                        continue
                    files[str(fp)] = int(fp.stat().st_size)
                except Exception:
                    errors += 1
            if truncated:
                break
    except Exception:
        errors += 1
    return {"root": str(root), "files": files, "total": int(sum(files.values())), "scanned": scanned, "errors": errors, "truncated": truncated}

def _audit_category(path: str) -> str:
    low = str(path).lower()
    name = Path(path).name.lower()
    if any(x in name for x in ("paper_bot_open", "paper_bot_closed", "trade_log", "closed_result", "score_ledger", "exit_replay")):
        return "핵심원장"
    if ".paper_runtime_reset_" in low:
        return "paper_runtime_reset"
    if "backup" in name or name.endswith(".bak"):
        return "backup"
    if name.startswith("coinbot_update_v") and name.endswith(".zip"):
        return "update_zip"
    if name.endswith(".zip"):
        return "zip"
    if name.endswith((".log", ".out", ".err")):
        return "log"
    if name.endswith(".jsonl"):
        return "jsonl_trace"
    if name.endswith(".gz"):
        return "gzip_archive"
    if name.endswith(".json"):
        return "json_cache_status"
    if name.endswith(".py"):
        return "python_code"
    return "other"

def _audit_category_totals(files: dict[str, int]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for path, size in files.items():
        cat = _audit_category(path)
        row = out.setdefault(cat, {"bytes": 0, "count": 0})
        row["bytes"] += int(size)
        row["count"] += 1
    return dict(sorted(out.items(), key=lambda kv: kv[1]["bytes"], reverse=True))

def _audit_top_files(files: dict[str, int], limit: int = 15) -> list[dict]:
    return [
        {"path": _audit_rel(path), "bytes": int(size), "category": _audit_category(path)}
        for path, size in sorted(files.items(), key=lambda kv: kv[1], reverse=True)[:max(1, limit)]
    ]

def _audit_du_bytes(path: Path, timeout: int = 12) -> int:
    if not path.exists():
        return 0
    rc, out = run(["du", "-sx", "-B1", str(path)], timeout=timeout)
    if rc == 0 and out:
        try:
            return int(out.split()[0])
        except Exception:
            pass
    return 0

def _audit_journal_bytes() -> tuple[int, str]:
    rc, out = run(["journalctl", "--disk-usage", "--no-pager"], timeout=8)
    text = (out or "").strip()
    if rc != 0:
        return 0, tail(text, 300)
    # 예: Archived and active journals take up 1.2G in the file system.
    m = re.search(r"([0-9]+(?:\.[0-9]+)?)\s*([KMGT])(?:i?B|B)?", text, re.I)
    if not m:
        return 0, text
    val = float(m.group(1))
    unit = m.group(2).upper()
    mult = {"K": 1024, "M": 1024**2, "G": 1024**3, "T": 1024**4}.get(unit, 1)
    return int(val * mult), text

def _audit_proc_rows() -> list[dict]:
    rc, out = run(["ps", "-eo", "pid=,ppid=,etimes=,pcpu=,pmem=,rss=,nlwp=,args="], timeout=8)
    rows = []
    if rc != 0:
        return rows
    def classify(args: str) -> str:
        tokens = [Path(tok.strip("'\"")).name for tok in args.split() if tok.strip("'\"").endswith(".py")]
        for base in tokens:
            if base == "backga_guard_bot.py" or base.startswith("backga_guard_bot_v"):
                return "guard"
            if base == "paper_bot.py" or base.startswith("paper_bot_v"):
                return "paper"
            if base == "ws_sidecar.py" or base.startswith("ws_sidecar_v"):
                return "ws"
            if base == "bithumb_micro_sidecar.py" or base.startswith("bithumb_micro_sidecar_v"):
                return "micro"
            for n, spec in WORKER_SPECS.items():
                active = str(spec.get("active") or "")
                prefix = str(spec.get("prefix") or "")
                if base == active or (prefix and base.startswith(prefix + "_v")):
                    return n
            if base == "bot.py" or base.startswith("coinbot_main_v"):
                return "main"
        return ""

    for line in (out or "").splitlines():
        parts = line.strip().split(None, 7)
        if len(parts) < 8:
            continue
        pid, ppid, etimes, pcpu, pmem, rss, nlwp, args = parts
        first_exec = Path(args.split()[0]).name.lower() if args.split() else ""
        if "python" not in first_exec:
            continue
        component = classify(args)
        if not component:
            continue
        rows.append({
            "component": component,
            "pid": _audit_int(pid),
            "ppid": _audit_int(ppid),
            "elapsed_sec": _audit_int(etimes),
            "cpu_pct": _audit_float(pcpu),
            "mem_pct": _audit_float(pmem),
            "rss_bytes": _audit_int(rss) * 1024,
            "threads": _audit_int(nlwp),
            "args": args[:500],
        })
    return rows

def _audit_open_fd_snapshot() -> dict:
    owners: dict[str, list[dict]] = {}
    deleted: list[dict] = []
    proc_root = Path("/proc")
    checked = 0
    errors = 0
    try:
        bot_real = str(BOT_DIR.resolve())
    except Exception:
        bot_real = str(BOT_DIR)
    for pd in proc_root.iterdir():
        if not pd.name.isdigit():
            continue
        pid = _audit_int(pd.name)
        if pid <= 0:
            continue
        try:
            cmd_raw = (pd / "cmdline").read_bytes().replace(b"\x00", b" ").decode("utf-8", errors="ignore").strip()
            comm = (pd / "comm").read_text(encoding="utf-8", errors="ignore").strip()
        except Exception:
            cmd_raw, comm = "", ""
        fd_dir = pd / "fd"
        try:
            fds = list(fd_dir.iterdir())
        except Exception:
            continue
        for fd in fds:
            checked += 1
            try:
                target = os.readlink(str(fd))
            except Exception:
                errors += 1
                continue
            is_deleted = target.endswith(" (deleted)")
            clean = target[:-10] if is_deleted else target
            try:
                real = os.path.realpath(clean) if clean.startswith("/") else clean
            except Exception:
                real = clean
            if is_deleted:
                try:
                    size = int(os.stat(str(fd)).st_size)
                except Exception:
                    size = 0
                deleted.append({"pid": pid, "fd": fd.name, "bytes": size, "target": clean, "cmd": (cmd_raw or comm)[:300]})
            if real.startswith(bot_real + os.sep) or real == bot_real or real.startswith("/var/log/"):
                flags_val=0
                try:
                    info=(pd/'fdinfo'/fd.name).read_text(encoding='utf-8',errors='ignore')
                    for line in info.splitlines():
                        if line.startswith('flags:'):
                            flags_val=int(line.split(':',1)[1].strip(),8); break
                except Exception:
                    flags_val=0
                mode_bits=flags_val & 3
                low=(cmd_raw or comm).lower()
                component='unknown'
                patterns=(('review',r'review_worker(?:_v[^ /]+)?\.py'),('strategy',r'strategy_worker(?:_v[^ /]+)?\.py'),('paper',r'paper_bot(?:_v[^ /]+)?\.py'),('guard',r'backga_guard_bot(?:_v[^ /]+)?\.py'),('main',r'(?:coinbot_main_v[^ /]+|bot)\.py'))
                for cname,pat in patterns:
                    if re.search(pat,low): component=cname; break
                if component=='unknown':
                    for n,spec in WORKER_SPECS.items():
                        prefix=str(spec.get('prefix') or '').lower()
                        active=str(spec.get('active') or '').lower()
                        if active and active in low or (prefix and re.search(re.escape(prefix)+r'(?:_v[^ /]+)?\.py',low)):
                            component=n; break
                owners.setdefault(real, []).append({"pid": pid, "cmd": (cmd_raw or comm)[:240], "mode": "write" if mode_bits in (1,2) else "read", "component": component})
    deleted.sort(key=lambda r: r.get("bytes", 0), reverse=True)
    return {"owners": owners, "deleted": deleted, "deleted_bytes": sum(int(r.get("bytes", 0)) for r in deleted), "checked": checked, "errors": errors}

def _audit_worker_rows(proc_rows: list[dict]) -> list[dict]:
    by_component: dict[str, list[dict]] = {}
    for row in proc_rows:
        by_component.setdefault(str(row.get("component")), []).append(row)
    out = []
    for name in WORKER_SPECS:
        st = worker_state_dict(name)
        raw = st.get("raw") if isinstance(st.get("raw"), dict) else {}
        cycle = None
        for key in ("last_sec", "cycle_sec", "last_cycle_sec", "loop_sec", "elapsed_sec"):
            if raw.get(key) not in (None, "", "-"):
                cycle = _audit_float(raw.get(key), -1.0)
                break
        prows = by_component.get(name, [])
        out.append({
            "name": name,
            "label": st.get("label"),
            "service": st.get("service"),
            "service_active": st.get("service_active"),
            "status_age_sec": _audit_float(st.get("age"), 999999.0),
            "cycle_sec": cycle,
            "row_count": raw.get("row_count", raw.get("evaluated", "-")),
            "phase": raw.get("phase", raw.get("last_phase", "-")),
            "process_count": len(prows),
            "cpu_pct": sum(_audit_float(x.get("cpu_pct")) for x in prows),
            "rss_bytes": sum(_audit_int(x.get("rss_bytes")) for x in prows),
            "threads": sum(_audit_int(x.get("threads")) for x in prows),
            "pids": [x.get("pid") for x in prows],
            "error": st.get("last_error"),
            "status_rss_bytes": int(_audit_float(raw.get("rss_mb"),0.0)*1024*1024),
            "rss_delta_bytes": sum(_audit_int(x.get("rss_bytes")) for x in prows)-int(_audit_float(raw.get("rss_mb"),0.0)*1024*1024),
        })
    out.sort(key=lambda r: max(_audit_float(r.get("cycle_sec"), 0.0), _audit_float(r.get("status_age_sec"), 0.0)), reverse=True)
    return out

def _audit_service_rows(proc_rows: list[dict]) -> list[dict]:
    services = {
        "main": MAIN_SERVICE,
        "paper": PAPER_SERVICE,
        "guard": GUARD_SERVICE,
        "ws": WS_SERVICE,
        "micro": MICRO_SERVICE,
    }
    services.update({n: str(spec["service"]) for n, spec in WORKER_SPECS.items()})
    by_comp: dict[str, list[dict]] = {}
    for row in proc_rows:
        by_comp.setdefault(str(row.get("component")), []).append(row)
    out = []
    for comp, svc in services.items():
        rc, txt = run(["systemctl", "show", svc, "-p", "ActiveState", "-p", "SubState", "-p", "MainPID", "-p", "NRestarts", "-p", "MemoryCurrent", "-p", "TasksCurrent", "-p", "CPUUsageNSec"], timeout=6)
        props = {}
        if rc == 0:
            for line in (txt or "").splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    props[k.strip()] = v.strip()
        prows = by_comp.get(comp, [])
        out.append({
            "component": comp,
            "service": svc,
            "active": props.get("ActiveState", "?"),
            "sub": props.get("SubState", "?"),
            "main_pid": _audit_int(props.get("MainPID")),
            "restart_count": _audit_int(props.get("NRestarts")),
            "memory_bytes": _audit_int(props.get("MemoryCurrent")),
            "tasks": _audit_int(props.get("TasksCurrent")),
            "cpu_total_sec": _audit_float(props.get("CPUUsageNSec")) / 1_000_000_000.0,
            "process_count": len(prows),
            "pids": [r.get("pid") for r in prows],
            "cpu_pct": sum(_audit_float(r.get("cpu_pct")) for r in prows),
            "rss_bytes": sum(_audit_int(r.get("rss_bytes")) for r in prows),
        })
    return out

def _audit_file_deltas(before: dict[str, int], after: dict[str, int], owners: dict[str, list[dict]], limit: int = 18) -> list[dict]:
    rows = []
    for path in set(before) | set(after):
        delta = int(after.get(path, 0)) - int(before.get(path, 0))
        if delta == 0:
            continue
        owner_rows = owners.get(os.path.realpath(path), [])
        rows.append({
            "path": _audit_rel(path),
            "before": int(before.get(path, 0)),
            "after": int(after.get(path, 0)),
            "delta": delta,
            "category": _audit_category(path),
            "owners": owner_rows[:4],
        })
    rows.sort(key=lambda r: abs(int(r.get("delta", 0))), reverse=True)
    return rows[:max(1, limit)]

def _audit_previous_delta(current_files: dict[str, int], current_disk_used: int) -> dict:
    state = read_json(BOT_DIR / GUARD_DEEP_AUDIT_STATE_FILE)
    prev_files = state.get("files") if isinstance(state.get("files"), dict) else {}
    prev_ts = _audit_float(state.get("ts"), 0.0)
    prev_used = _audit_int(state.get("disk_used"), 0)
    deltas = []
    if prev_files:
        for rel, size in current_files.items():
            old = _audit_int(prev_files.get(rel), 0)
            d = int(size) - old
            if d:
                deltas.append({"path": rel, "delta": d, "before": old, "after": int(size), "category": _audit_category(rel)})
        for rel, old in prev_files.items():
            if rel not in current_files:
                deltas.append({"path": rel, "delta": -_audit_int(old), "before": _audit_int(old), "after": 0, "category": _audit_category(rel)})
        deltas.sort(key=lambda r: abs(int(r.get("delta", 0))), reverse=True)
    return {
        "available": bool(prev_files and prev_ts),
        "age_sec": max(0.0, time.time() - prev_ts) if prev_ts else None,
        "disk_used_delta": int(current_disk_used) - prev_used if prev_used else None,
        "file_deltas": deltas[:20],
    }

def _audit_save_baseline(files: dict[str, int], disk_used: int) -> None:
    # 64KB 이상만 저장해 상태파일 자체가 새 디스크 문제를 만들지 않게 제한한다.
    rows = [(_audit_rel(path), int(size)) for path, size in files.items() if int(size) >= 64 * 1024]
    rows.sort(key=lambda kv: kv[1], reverse=True)
    write_json(BOT_DIR / GUARD_DEEP_AUDIT_STATE_FILE, {
        "schema": "guard_deep_audit_state_v928",
        "ts": time.time(),
        "time": now(),
        "disk_used": int(disk_used),
        "files": dict(rows[:5000]),
    })

def _audit_suspicions(report: dict) -> list[str]:
    out = []
    sample = report.get("sample") or {}
    delta = _audit_int(sample.get("disk_used_delta"), 0)
    if delta > 25 * 1024 * 1024:
        out.append(f"짧은 표본 동안 디스크 사용량이 {_fmt_bytes(delta)} 증가")
    growth = [r for r in sample.get("file_deltas", []) if _audit_int(r.get("delta"), 0) > 5 * 1024 * 1024]
    if growth:
        out.append("빠르게 커진 파일 있음: " + ", ".join(f"{r['path']} +{_fmt_bytes(r['delta'])}" for r in growth[:3]))
    deleted_bytes = _audit_int((report.get("open_fds") or {}).get("deleted_bytes"), 0)
    if deleted_bytes > 20 * 1024 * 1024:
        out.append(f"삭제됐지만 프로세스가 잡고 있는 파일 {_fmt_bytes(deleted_bytes)}")
    journal = _audit_int((report.get("areas") or {}).get("journal_bytes"), 0)
    if journal > 512 * 1024 * 1024:
        out.append(f"systemd journal 사용량 큼: {_fmt_bytes(journal)}")
    dup = [r for r in report.get("services", []) if _audit_int(r.get("process_count"), 0) > 1]
    if dup:
        out.append("중복 프로세스 의심: " + ", ".join(f"{r['component']} {r['process_count']}개" for r in dup[:6]))
    slow = [r for r in report.get("workers", []) if _audit_float(r.get("status_age_sec"), 999999.0) < 900000 and (_audit_float(r.get("cycle_sec"), 0.0) > 30 or _audit_float(r.get("status_age_sec"), 0.0) > 60)]
    if slow:
        out.append("느린 작업자: " + ", ".join(f"{r['name']} cycle {r.get('cycle_sec')}s/age {r.get('status_age_sec'):.1f}s" for r in slow[:5]))
    resets = _audit_int((report.get("categories") or {}).get("paper_runtime_reset", {}).get("bytes"), 0)
    if resets > 100 * 1024 * 1024:
        out.append(f"paper runtime reset 백업 누적 {_fmt_bytes(resets)}")
    if not out:
        out.append("현재 20초 표본에서 단일 급증 원인은 확정되지 않음. 이전 감사 대비 증가량을 다음 호출에서 대조")
    return out

def _audit_format(report: dict) -> str:
    r0 = report.get("resource_before") or {}
    r1 = report.get("resource_after") or {}
    sample = report.get("sample") or {}
    prev = report.get("previous") or {}
    lines = [
        f"🔬 작업자·디스크 통합감사 /gdeep_audit · {VERSION}",
        f"- 읽기 전용 / 표본 {report.get('sample_sec')}초 / 삭제·정리 0건",
        f"- 디스크: 사용 {_fmt_bytes(r1.get('disk_used',0))} / 남음 {_fmt_bytes(r1.get('disk_free',0))} / {r1.get('disk_pct',0):.1f}%",
        f"- 표본 변화: 사용량 {_audit_fmt_delta(sample.get('disk_used_delta',0))}",
    ]
    if prev.get("available"):
        d = prev.get("disk_used_delta")
        lines.append(f"- 이전 감사 대비: {prev.get('age_sec',0)/60:.1f}분 / 디스크 {_audit_fmt_delta(d or 0)}")
    auto_retention = read_json(BOT_DIR / AUTO_RETENTION_STATE_V1196) or {}
    if isinstance(auto_retention, dict):
        free_now = int(r1.get('disk_free') or 0)
        lines.append(
            f"- 자동정리 v1228: {'활성' if auto_retention.get('auto_storage_policy_v1228') is True else '적용 대기'} / 단계 {_v1228_disk_pressure_level(free_now)} / 마지막 {auto_retention.get('last_run_at') or '기록 없음'} / trigger {auto_retention.get('trigger') or '-'}"
        )
        lines.append(
            f"- 자동정리 보호: 핵심 원장 삭제 {1 if auto_retention.get('core_ledger_deleted') else 0} / 정리 오류 {int(auto_retention.get('errors') or 0)}"
        )
    lines += ["", "[판정]"] + [f"- {x}" for x in report.get("suspicions", [])]

    lines += ["", "[느린 작업자 TOP]"]
    for row in (report.get("workers") or [])[:9]:
        cycle = row.get("cycle_sec")
        cycle_text = "-" if cycle is None or cycle < 0 else f"{cycle:.1f}s"
        lines.append(
            f"- {row['name']}: cycle {cycle_text} / status age {row['status_age_sec']:.1f}s / CPU {row['cpu_pct']:.1f}% / canonical RSS {_fmt_bytes(row['rss_bytes'])} / worker self-sample {(_fmt_bytes(row.get('status_rss_bytes',0)) if row.get('status_rss_bytes',0) else 'not_published')} / proc {row['process_count']} / phase {row.get('phase','-')}"
        )

    lines += ["", "[중복·서비스]"]
    duplicate_found = False
    for row in report.get("services", []):
        if row.get("component") in {"main", "paper", "guard", "ws", "micro", *WORKER_SPECS.keys()} and (_audit_int(row.get("process_count"),0) != 1 or _audit_int(row.get("restart_count"),0) > 0):
            duplicate_found = True
            lines.append(f"- {row['component']}: svc {row['active']}/{row['sub']} / proc {row['process_count']} / pid {row.get('pids') or '-'} / restart {row['restart_count']} / mem {_fmt_bytes(row['memory_bytes'])}")
    if not duplicate_found:
        lines.append("- 확인된 관리대상 중복 프로세스 없음")

    lines += ["", f"[파일 증가 TOP · {report.get('sample_sec')}초]"]
    growth_rows = sample.get("file_deltas", [])
    if not growth_rows:
        lines.append("- BOT_DIR 안에서 크기 변화 파일 없음")
    else:
        for row in growth_rows[:12]:
            d = _audit_int(row.get("delta"))
            owner = row.get("owners") or []
            owner_text = ",".join(str(x.get("pid")) for x in owner) if owner else "-"
            lines.append(f"- {row['path']}: {_audit_fmt_delta(d)} / {row['category']} / writer PID {owner_text}")
    log_growth = sample.get("var_log_file_deltas", [])
    if log_growth:
        lines += ["", f"[/var/log 증가 TOP · {report.get('sample_sec')}초]"]
        for row in log_growth[:8]:
            d = _audit_int(row.get("delta"))
            owner = row.get("owners") or []
            owner_text = ",".join(str(x.get("pid")) for x in owner) if owner else "-"
            lines.append(f"- {row['path']}: {_audit_fmt_delta(d)} / writer PID {owner_text}")

    # v1016: read the candle writer's own proof. lsof sampling often misses an
    # append-only file because it is opened only for milliseconds. The status
    # writer is the canonical evidence for PID/source/operation bytes/reset.
    candle_status=read_json(BOT_DIR / "clean_candle_status.json") or {}
    if isinstance(candle_status,dict):
        lines += ["", "[Candle delta v1016 증거]"]
        lines.append(
            f"- writer PID {candle_status.get('delta_writer_pid_v1016','-')} / version {candle_status.get('delta_writer_version_v1016','-')} / build {candle_status.get('delta_writer_build_v1016','-')}"
        )
        lines.append(f"- source {candle_status.get('delta_writer_source_v1016','-')} / base {candle_status.get('delta_base_checkpoint_id_v1016','-')}")
        lines.append(
            f"- changed {candle_status.get('delta_changed_tickers_v1016',0)} / prepared {candle_status.get('delta_prepared_records_v1016',0)} / appended {candle_status.get('delta_appended_records_v1016',0)} records · {_fmt_bytes(candle_status.get('delta_appended_bytes_v1016',0))}"
        )
        lines.append(
            f"- ops avg/max {candle_status.get('delta_avg_ops_v1016',0)}/{candle_status.get('delta_max_ops_v1016',0)} / record avg/max {_fmt_bytes(candle_status.get('delta_avg_record_bytes_v1016',0))}/{_fmt_bytes(candle_status.get('delta_max_record_bytes_v1016',0))}"
        )
        lines.append(
            f"- delta before/projected/after {_fmt_bytes(candle_status.get('delta_size_before_v1016',0))}/{_fmt_bytes(candle_status.get('delta_projected_bytes_v1016',0))}/{_fmt_bytes(candle_status.get('delta_size_after_v1016',0))} / cap {_fmt_bytes(candle_status.get('delta_max_bytes_v1016',0))}"
        )
        lines.append(
            f"- checkpoint due={candle_status.get('checkpoint_due_v1016')} reason={candle_status.get('checkpoint_reason_v1016') or '-'} success={candle_status.get('checkpoint_success_v1016')} error={candle_status.get('checkpoint_error_v1016') or '-'}"
        )
        lines.append(
            f"- reset count {candle_status.get('reset_count_v1016',0)} / last bytes {_fmt_bytes(candle_status.get('last_reset_bytes_v1016',0))} / reset before→after {_fmt_bytes(candle_status.get('checkpoint_reset_before_bytes_v1016',0))}→{_fmt_bytes(candle_status.get('checkpoint_reset_after_bytes_v1016',0))}"
        )

    compact = report.get('runtime_compaction_v928') or {}
    st = compact.get('strategy') if isinstance(compact.get('strategy'), dict) else {}
    rt = compact.get('target_router') if isinstance(compact.get('target_router'), dict) else {}
    lines += ['', '[v928 경량화 상태]']
    if not st and not rt:
        lines.append('- v928 worker status 생성 대기')
    else:
        if st:
            fb = st.get('file_bytes') if isinstance(st.get('file_bytes'), dict) else {}
            hold = st.get('hold') if isinstance(st.get('hold'), dict) else {}
            lines.append(f"- strategy cycle {st.get('cycle_sec','-')}s / trace {_fmt_bytes(fb.get('single_pass_trace',0))} / reject {_fmt_bytes(fb.get('reject_summary',0))}")
            lines.append(f"- S1 hold {hold.get('count',0)}개 / 원본추정 {_fmt_bytes(hold.get('full_row_bytes_before_v928',0))} → compact {_fmt_bytes(hold.get('compact_row_bytes_after_v928',0))} / JSONL mirror retired")
        if rt:
            lines.append(f"- target_router source {rt.get('recheck_source','-')} / source rows {rt.get('recheck_source_rows',0)} / queue {_fmt_bytes(rt.get('queue_file_bytes',0))}")
            lines.append(f"- full JSONL 매 cycle 읽기: {rt.get('full_jsonl_read_each_cycle')} / candidate lite {_fmt_bytes(rt.get('candidate_lite_file_bytes',0))}")

    areas = report.get("areas") or {}
    lines += [
        "",
        "[현재 용량 위치]",
        f"- 봇폴더: {_fmt_bytes(areas.get('bot_dir_bytes',0))}",
        f"- 봇 상위 홈: {_fmt_bytes(areas.get('bot_parent_bytes',0))}",
        f"- /var/log: {_fmt_bytes(areas.get('var_log_bytes',0))}",
        f"- systemd journal: {_fmt_bytes(areas.get('journal_bytes',0))}",
        f"- /var/cache: {_fmt_bytes(areas.get('var_cache_bytes',0))} / docker: {_fmt_bytes(areas.get('docker_bytes',0))}",
        f"- /tmp: {_fmt_bytes(areas.get('tmp_bytes',0))} / /var/tmp: {_fmt_bytes(areas.get('var_tmp_bytes',0))}",
    ]
    lines += ["", "[봇폴더 종류별]"]
    for cat, row in list((report.get("categories") or {}).items())[:10]:
        lines.append(f"- {cat}: {_fmt_bytes(row.get('bytes',0))} / {row.get('count',0)}개")

    fd = report.get("open_fds") or {}
    lines += ["", "[삭제됐지만 열린 파일]"]
    if not fd.get("deleted"):
        lines.append("- 없음")
    else:
        lines.append(f"- 합계 {_fmt_bytes(fd.get('deleted_bytes',0))} / {len(fd.get('deleted') or [])}개")
        for row in (fd.get("deleted") or [])[:8]:
            lines.append(f"- PID {row['pid']} / {_fmt_bytes(row['bytes'])} / {row['target']}")

    lines += ["", "[큰 파일 TOP]"]
    for row in (report.get("top_files") or [])[:12]:
        lines.append(f"- {row['path']}: {_fmt_bytes(row['bytes'])} / {row['category']}")
    if report.get("var_log_top_files"):
        lines += ["", "[/var/log 큰 파일 TOP]"]
        for row in (report.get("var_log_top_files") or [])[:8]:
            lines.append(f"- {row['path']}: {_fmt_bytes(row['bytes'])}")
    lines += [
        "",
        "[보존]",
        "- OPEN/CLOSED/trade_log/decision/exact/change/issue/good-S2 핵심 원장 수정·삭제 없음",
        f"- 전체 JSON: {GUARD_DEEP_AUDIT_JSON}",
        f"- 전체 TXT: {GUARD_DEEP_AUDIT_TEXT}",
        "- 다음 호출은 이전 감사 대비 증가량까지 비교",
    ]
    return "\n".join(lines)

def gdeep_audit_text(sample_sec: int = 20) -> str:
    sample_sec = max(5, min(30, _audit_int(sample_sec, 20)))
    t0 = perf_now()
    before_res = server_resource_snapshot()
    before_scan = _audit_scan_files(BOT_DIR, max_files=60000)
    before_var_log = _audit_scan_files(Path("/var/log"), max_files=25000)
    prev_map = {_audit_rel(k): int(v) for k, v in before_scan.get("files", {}).items() if int(v) >= 64 * 1024}
    previous = _audit_previous_delta(prev_map, _audit_int(before_res.get("disk_used")))
    proc_rows = _audit_proc_rows()
    workers = _audit_worker_rows(proc_rows)
    services = _audit_service_rows(proc_rows)
    journal_bytes, journal_text = _audit_journal_bytes()
    areas = {
        "bot_dir_bytes": _audit_int(before_scan.get("total")),
        "bot_parent_bytes": _audit_du_bytes(BOT_DIR.parent, timeout=14),
        "var_log_bytes": _audit_du_bytes(Path("/var/log"), timeout=12),
        "journal_bytes": journal_bytes,
        "journal_text": journal_text,
        "var_cache_bytes": _audit_du_bytes(Path("/var/cache"), timeout=10),
        "docker_bytes": _audit_du_bytes(Path("/var/lib/docker"), timeout=10),
        "tmp_bytes": _audit_du_bytes(Path("/tmp"), timeout=8),
        "var_tmp_bytes": _audit_du_bytes(Path("/var/tmp"), timeout=8),
    }
    # 실제 증가 파일을 잡기 위한 짧은 동일구간 재측정.
    time.sleep(sample_sec)
    after_res = server_resource_snapshot()
    after_scan = _audit_scan_files(BOT_DIR, max_files=60000)
    after_var_log = _audit_scan_files(Path("/var/log"), max_files=25000)
    fd_snapshot = _audit_open_fd_snapshot()
    file_deltas = _audit_file_deltas(before_scan.get("files", {}), after_scan.get("files", {}), fd_snapshot.get("owners", {}), limit=24)
    var_log_deltas = _audit_file_deltas(before_var_log.get("files", {}), after_var_log.get("files", {}), fd_snapshot.get("owners", {}), limit=16)
    report = {
        "schema": "guard_deep_runtime_disk_audit_v928",
        "time": now(),
        "ts": time.time(),
        "guard_version": VERSION,
        "sample_sec": sample_sec,
        "elapsed_sec": perf_now() - t0,
        "read_only": True,
        "resource_before": before_res,
        "resource_after": after_res,
        "sample": {
            "disk_used_delta": _audit_int(after_res.get("disk_used")) - _audit_int(before_res.get("disk_used")),
            "disk_free_delta": _audit_int(after_res.get("disk_free")) - _audit_int(before_res.get("disk_free")),
            "bot_dir_delta": _audit_int(after_scan.get("total")) - _audit_int(before_scan.get("total")),
            "file_deltas": file_deltas,
            "var_log_file_deltas": var_log_deltas,
            "scan_before": {k: v for k, v in before_scan.items() if k != "files"},
            "scan_after": {k: v for k, v in after_scan.items() if k != "files"},
        },
        "previous": previous,
        "workers": workers,
        "services": services,
        "processes": proc_rows,
        "areas": areas,
        "categories": _audit_category_totals(after_scan.get("files", {})),
        "top_files": _audit_top_files(after_scan.get("files", {}), limit=24),
        "var_log_top_files": _audit_top_files(after_var_log.get("files", {}), limit=16),
        "open_fds": fd_snapshot,
        "runtime_compaction_v928": {
            "strategy": read_json(BOT_DIR / "clean_strategy_storage_status_v928.json"),
            "target_router": read_json(BOT_DIR / "clean_target_router_compact_status_v928.json"),
            "storage_fix": read_json(BOT_DIR / V928_STORAGE_FIX_JSON),
        },
    }
    report["suspicions"] = _audit_suspicions(report)
    text = _audit_format(report)
    try:
        write_json(BOT_DIR / GUARD_DEEP_AUDIT_JSON, report)
        (BOT_DIR / GUARD_DEEP_AUDIT_TEXT).write_text(text + "\n", encoding="utf-8")
        current_map = {_audit_rel(k): int(v) for k, v in after_scan.get("files", {}).items()}
        _audit_save_baseline(current_map, _audit_int(after_res.get("disk_used")))
    except Exception as exc:
        text += f"\n- 감사 결과파일 저장 실패: {exc.__class__.__name__}: {str(exc)[:160]}"
    return text

_V1064_CORE_NS = {'__name__': 'coinbot_core_v2_full_shadow_v1064_embedded'}

CORE_V2_FULL_SHADOW_OUTPUT_DIR_V1064 = BOT_DIR.parent / 'coinbot_core_v2_shadow_output'

CORE_V2_FULL_SHADOW_INTERVAL_SEC_V1064 = 30.0

def _v1064_run_full_shadow_cycle():
    return _V1064_CORE_NS['run_full_shadow_cycle'](BOT_DIR, CORE_V2_FULL_SHADOW_OUTPUT_DIR_V1064)

def _v1064_render_full_shadow(report, ticker='') -> str:
    return _V1064_CORE_NS['render_report'](report, ticker)

def gcore_shadow_text(args=None) -> str:
    args = list(args or [])
    ticker = str(args[0]) if args else ''
    try:
        report = _v1064_run_full_shadow_cycle()
        return _v1064_render_full_shadow(report, ticker)
    except Exception as exc:
        return '\n'.join([
            '🧬 ❌ CORE V2 전체 Shadow 실패',
            f'- {exc.__class__.__name__}: {exc}',
            '- 라이브 OPEN/CLOSED/decision 쓰기 0',
            '- 확인: /gworker_state /gdeep_audit /gcore_shadow',
        ])

def _sha256_file_v1129(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()

def _telegram_send_document_once_v1129(chat_id: str, path: Path, caption: str = "", timeout: int = 180) -> dict:
    """Stream one document with stdlib only; never load the archive into Guard RSS."""
    file_size = int(path.stat().st_size)
    boundary = "----CoinbotGuard" + hashlib.sha256(
        f"{os.getpid()}:{time.time_ns()}:{path.name}".encode("utf-8")
    ).hexdigest()[:24]
    safe_name = path.name.replace('"', "_").replace("\r", "_").replace("\n", "_")
    fields = []
    for key, value in (("chat_id", str(chat_id)), ("caption", str(caption or "")[:1000])):
        fields.append(
            f"--{boundary}\r\n"
            f"Content-Disposition: form-data; name=\"{key}\"\r\n\r\n"
            f"{value}\r\n".encode("utf-8")
        )
    file_head = (
        f"--{boundary}\r\n"
        f"Content-Disposition: form-data; name=\"document\"; filename=\"{safe_name}\"\r\n"
        "Content-Type: application/zip\r\n\r\n"
    ).encode("utf-8")
    tail_bytes = f"\r\n--{boundary}--\r\n".encode("utf-8")
    content_length = sum(len(x) for x in fields) + len(file_head) + file_size + len(tail_bytes)
    conn = http.client.HTTPSConnection("api.telegram.org", timeout=timeout)
    try:
        conn.putrequest("POST", f"/bot{TOKEN}/sendDocument")
        conn.putheader("Content-Type", f"multipart/form-data; boundary={boundary}")
        conn.putheader("Content-Length", str(content_length))
        conn.putheader("User-Agent", "coinbot-guard-v1130")
        conn.endheaders()
        for value in fields:
            conn.send(value)
        conn.send(file_head)
        with path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                conn.send(chunk)
        conn.send(tail_bytes)
        response = conn.getresponse()
        body = response.read().decode("utf-8", errors="ignore")
        try:
            payload = json.loads(body or "{}")
        except Exception:
            payload = {"ok": False, "description": body[:500]}
        payload["http_status"] = int(response.status)
        return payload
    finally:
        try:
            conn.close()
        except Exception:
            pass

def telegram_send_document_v1129(chat_id: str, path: Path, caption: str = "") -> tuple[bool, str]:
    last = ""
    for attempt in range(3):
        try:
            result = _telegram_send_document_once_v1129(chat_id, path, caption=caption)
            if isinstance(result, dict) and result.get("ok") is True:
                return True, "OK"
            last = str((result or {}).get("description") or result)[:500]
        except Exception as exc:
            last = f"{type(exc).__name__}: {exc}"
        time.sleep(1.0 + attempt)
    return False, last or "sendDocument failed"

def _cleanup_old_profitability_exports_v1129(max_age_sec: int = 6 * 3600) -> list[str]:
    removed = []
    cutoff = time.time() - max_age_sec
    try:
        for path in BOT_DIR.glob(GUARD_EXPORT_TMP_PREFIX_V1129 + "*"):
            try:
                if not path.is_dir() or path.stat().st_mtime >= cutoff:
                    continue
                shutil.rmtree(path)
                removed.append(path.name)
            except Exception:
                continue
    except Exception:
        pass
    return removed

def _trim_jsonl_snapshot_tail_v1129(path: Path, scan_bytes: int = 2 * 1024 * 1024) -> tuple[int, str]:
    """Keep only complete JSONL records in the exported point-in-time prefix."""
    size = int(path.stat().st_size)
    if size <= 0:
        return 0, "EMPTY"
    with path.open("r+b") as handle:
        handle.seek(size - 1)
        if handle.read(1) == b"\n":
            return 0, "COMPLETE_LINE_TAIL"
        take = min(size, scan_bytes)
        handle.seek(size - take)
        tail_data = handle.read(take)
        index = tail_data.rfind(b"\n")
        if index < 0:
            return 0, "TAIL_NEWLINE_NOT_FOUND_UNCHANGED"
        new_size = size - take + index + 1
        handle.truncate(new_size)
        handle.flush()
        os.fsync(handle.fileno())
    return size - new_size, "TRIMMED_INCOMPLETE_TRAILING_RECORD"

def _snapshot_profitability_file_v1129(name: str, snapshot_dir: Path) -> dict:
    src = BOT_DIR / name
    result = {
        "name": name,
        "source": str(src),
        "exists": False,
        "approved": name in PROFITABILITY_EXPORT_FILES_V1129,
    }
    if name not in PROFITABILITY_EXPORT_FILES_V1129:
        result.update(status="REJECTED_NOT_ALLOWLISTED")
        return result
    try:
        lst = src.lstat()
    except FileNotFoundError:
        result.update(status="MISSING")
        return result
    except Exception as exc:
        result.update(status="STAT_FAILED", error=f"{type(exc).__name__}: {exc}")
        return result
    if src.is_symlink() or not src.is_file() or src.resolve().parent != BOT_DIR.resolve():
        result.update(status="REJECTED_PATH_OR_TYPE", is_symlink=src.is_symlink())
        return result
    size_start = int(lst.st_size)
    inode_start = int(lst.st_ino)
    mtime_ns_start = int(lst.st_mtime_ns)
    result.update(
        exists=True,
        size_start=size_start,
        inode_start=inode_start,
        mtime_ns_start=mtime_ns_start,
        mtime_start=datetime.fromtimestamp(lst.st_mtime).isoformat(timespec="seconds"),
    )
    dest = snapshot_dir / name
    copied = 0
    try:
        with src.open("rb", buffering=0) as reader, dest.open("wb", buffering=0) as writer:
            remaining = size_start
            while remaining > 0:
                chunk = reader.read(min(1024 * 1024, remaining))
                if not chunk:
                    break
                writer.write(chunk)
                copied += len(chunk)
                remaining -= len(chunk)
            writer.flush()
            os.fsync(writer.fileno())
        os.chmod(dest, 0o600)
        trimmed = 0
        tail_state = "NOT_JSONL"
        if name.endswith(".jsonl"):
            trimmed, tail_state = _trim_jsonl_snapshot_tail_v1129(dest)
        try:
            end_lst = src.lstat()
            size_end = int(end_lst.st_size)
            inode_end = int(end_lst.st_ino)
            mtime_ns_end = int(end_lst.st_mtime_ns)
        except Exception:
            size_end = -1
            inode_end = -1
            mtime_ns_end = -1
        copied_final = int(dest.stat().st_size)
        if copied < size_start:
            status = "CHECK_SOURCE_SHRANK_OR_SHORT_READ"
        elif inode_end != inode_start:
            status = "SNAPSHOT_OLD_ATOMIC_GENERATION"
        elif size_end > size_start:
            status = "PREFIX_SNAPSHOT_SOURCE_GREW"
        elif size_end == size_start and mtime_ns_end == mtime_ns_start:
            status = "STABLE_POINT_IN_TIME_COPY"
        else:
            status = "POINT_IN_TIME_COPY_SOURCE_CHANGED"
        result.update(
            status=status,
            snapshot_path=str(dest),
            copied_bytes=copied_final,
            read_bytes_before_tail_trim=copied,
            tail_trimmed_bytes=int(trimmed),
            tail_state=tail_state,
            sha256=_sha256_file_v1129(dest),
            size_end=size_end,
            inode_end=inode_end,
            mtime_ns_end=mtime_ns_end,
            source_changed_during_copy=bool(
                inode_end != inode_start or size_end != size_start or mtime_ns_end != mtime_ns_start
            ),
            original_content_modified=False,
        )
    except Exception as exc:
        result.update(status="COPY_FAILED", error=f"{type(exc).__name__}: {exc}", copied_bytes=copied)
        try:
            dest.unlink(missing_ok=True)
        except Exception:
            pass
    return result

def _resolve_profitability_export_specs_v1130() -> list[dict]:
    rows: list[dict] = []
    for logical_name, candidates in PROFITABILITY_EXPORT_SPECS_V1130:
        resolved = None
        for candidate in candidates:
            path = BOT_DIR / candidate
            try:
                if path.exists() and path.is_file() and not path.is_symlink() and path.resolve().parent == BOT_DIR.resolve():
                    resolved = candidate
                    break
            except Exception:
                continue
        rows.append({
            "logical_name": logical_name,
            "candidates": list(candidates),
            "resolved_name": resolved,
            "used_fallback": bool(resolved and resolved != logical_name),
        })
    return rows

def _snapshot_profitability_specs_v1130(snapshot_dir: Path) -> list[dict]:
    out: list[dict] = []
    for spec in _resolve_profitability_export_specs_v1130():
        logical_name = str(spec["logical_name"])
        resolved_name = spec.get("resolved_name")
        if not resolved_name:
            out.append({
                "name": logical_name,
                "logical_name": logical_name,
                "resolved_name": None,
                "candidates": list(spec.get("candidates") or []),
                "exists": False,
                "approved": True,
                "status": "MISSING_ALL_ALIASES",
                "used_fallback": False,
            })
            continue
        row = _snapshot_profitability_file_v1129(str(resolved_name), snapshot_dir)
        row["name"] = logical_name
        row["logical_name"] = logical_name
        row["resolved_name"] = str(resolved_name)
        row["candidates"] = list(spec.get("candidates") or [])
        row["used_fallback"] = bool(spec.get("used_fallback"))
        row["archive_name"] = f"data/{logical_name}"
        out.append(row)
    return out

def _write_export_single_zip_v1130(path: Path, manifest: dict, file_rows: list[dict]) -> dict:
    readme = (
        "Coinbot profitability audit export v1132\n"
        "- One Android-compatible standard ZIP contains all available approved audit files.\n"
        "- Compression method is classic DEFLATE (ZIP method 8), not ZIP-LZMA.\n"
        "- EXPORT_MANIFEST.json records logical and resolved server filenames, SHA256 and snapshot status.\n"
        "- Source ledgers were copied as read-only point-in-time prefixes; originals were not modified.\n"
    )
    # Android/Samsung My Files compatibility: classic ZIP_DEFLATED only.
    with zipfile.ZipFile(
        path,
        "w",
        compression=zipfile.ZIP_DEFLATED,
        compresslevel=9,
        allowZip64=True,
    ) as archive:
        archive.writestr("EXPORT_MANIFEST.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
        archive.writestr("README_EXPORT.txt", readme)
        for row in file_rows:
            snapshot_path = row.get("snapshot_path")
            if not snapshot_path:
                continue
            source = Path(str(snapshot_path))
            if not source.exists():
                continue
            archive.write(source, arcname=str(row.get("archive_name") or f"data/{row.get('name')}"))
    os.chmod(path, 0o600)

    # Fail closed before Telegram delivery unless every member uses method 0 or 8,
    # no encryption flag is set, and the full archive CRC test passes.
    with zipfile.ZipFile(path, "r") as check:
        bad = check.testzip()
        infos = check.infolist()
        unsupported = [info.filename for info in infos if info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED)]
        encrypted = [info.filename for info in infos if int(info.flag_bits) & 0x1]
        method_ids = sorted({int(info.compress_type) for info in infos})
        if bad:
            raise RuntimeError(f"zip CRC validation failed: {bad}")
        if unsupported:
            raise RuntimeError(f"non-Android ZIP compression method found: {unsupported[:5]}")
        if encrypted:
            raise RuntimeError(f"encrypted ZIP member found: {encrypted[:5]}")

    return {
        "name": path.name,
        "size": int(path.stat().st_size),
        "sha256": _sha256_file_v1129(path),
        "item_count": len([row for row in file_rows if row.get("snapshot_path")]),
        "compression": "ZIP_DEFLATED_STANDARD",
        "compression_method_ids": method_ids,
        "crc_test": "PASS",
        "encrypted_members": 0,
        "android_compatible_contract": True,
    }

def _append_profitability_export_ledger_v1132(status: str, summary: str, remaining: str, proof: str) -> None:
    common = {
        "version": "v1132",
        "ts": time.time(),
        "time": now(),
        "status": status,
        "strategy_impact": "none_read_only_export_transport_compatibility_only",
        "auto_buy": False,
    }
    try:
        _ops_issue_append_once("profitability_export_v1132_open", BOT_DIR / "issue_ledger.jsonl", dict(
            common,
            schema="issue_event_v1132",
            event_type="ISSUE",
            issue_id="GUARD-PROFITABILITY-EXPORT-1132",
            status="OPEN",
            title="Guard Android-compatible standard ZIP export",
            summary="Replace ZIP-LZMA with classic ZIP DEFLATE and verify CRC/method/encryption before Telegram delivery.",
            remaining="Run /gexport_profitability and prove Android-compatible ZIP method 8, one archive, source immutability and successful temporary cleanup.",
        ))
        status_key = str(status or "CHECK").lower()
        _ops_issue_append_once(f"profitability_export_v1132_{status_key}", BOT_DIR / "issue_ledger.jsonl", dict(
            common,
            schema="issue_event_v1132",
            event_type="ISSUE",
            issue_id="GUARD-PROFITABILITY-EXPORT-1132",
            title="Guard Android-compatible standard ZIP export",
            summary=summary,
            remaining=remaining,
            proof=proof,
        ))
        suffix = "server-proof" if status == "DONE" else status_key
        _ops_issue_append_once(f"profitability_export_change_v1132_{status_key}", BOT_DIR / "change_verify_ledger.jsonl", dict(
            common,
            schema="change_verify_event_v1132",
            event_type="CHANGE_VERIFY",
            change_id=f"v1132-guard-android-standard-zip-{suffix}-001",
            issue_id="GUARD-PROFITABILITY-EXPORT-1132",
            summary=summary,
            remaining=remaining,
            proof=proof,
        ))
    except Exception as exc:
        print(f"[{now()}] profitability export v1132 ledger append failed: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)

def gexport_profitability_text_v1129() -> str:
    """v1132 Android-compatible single-ZIP read-only fixed-allowlist export."""
    lock_path = BOT_DIR / GUARD_EXPORT_LOCK_V1129
    lock_handle = None
    root: Optional[Path] = None
    zip_path: Optional[Path] = None
    preserve_temp_on_failure = False
    started = time.time()
    result: dict = {
        "schema": "guard_profitability_export_result_v1132",
        "version": "v1132",
        "guard_version": VERSION,
        "started_ts": started,
        "started_time": now(),
        "status": "CHECK",
        "approved_files": [spec[0] for spec in PROFITABILITY_EXPORT_SPECS_V1130],
        "delivery_contract": "one Android-compatible classic DEFLATE ZIP; fail closed before send on CRC/method/encryption/size error",
        "original_files_modified": False,
        "auto_buy_changed": False,
    }
    try:
        lock_handle = lock_path.open("a+")
        try:
            fcntl.flock(lock_handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return "📦 수익성 감사파일 생성 중\n- 기존 export 1건이 끝난 뒤 다시 실행해줘."
        _cleanup_old_profitability_exports_v1129()
        resolved_specs = _resolve_profitability_export_specs_v1130()
        sizes = []
        for spec in resolved_specs:
            resolved = spec.get("resolved_name")
            if not resolved:
                continue
            path = BOT_DIR / str(resolved)
            try:
                sizes.append(int(path.stat().st_size))
            except Exception:
                pass
        total_source_bytes = sum(sizes)
        free_before = int(shutil.disk_usage(BOT_DIR).free)
        required_free = total_source_bytes * 2 + 128 * 1024 * 1024
        result.update(total_source_bytes=total_source_bytes, disk_free_before=free_before, required_free=required_free)
        if free_before < required_free:
            raise RuntimeError(f"insufficient temporary disk: free={free_before} required={required_free}")

        root = Path(tempfile.mkdtemp(prefix=GUARD_EXPORT_TMP_PREFIX_V1129, dir=str(BOT_DIR)))
        os.chmod(root, 0o700)
        snapshot_dir = root / "snapshot"
        snapshot_dir.mkdir(mode=0o700)
        progress_notify(
            "📦 수익성 감사파일 Android 호환 ZIP 생성 시작\n"
            f"- 승인 항목 {len(PROFITABILITY_EXPORT_SPECS_V1130)}개 읽기 전용 snapshot\n"
            "- 표준 DEFLATE 단일 ZIP · 원본 수정/삭제 없음"
        )
        file_rows = _snapshot_profitability_specs_v1130(snapshot_dir)
        existing = [row for row in file_rows if row.get("snapshot_path")]
        missing = [str(row.get("name")) for row in file_rows if not row.get("snapshot_path")]
        failed = [row for row in file_rows if row.get("status") in {"COPY_FAILED", "STAT_FAILED", "REJECTED_PATH_OR_TYPE"}]
        fallback_rows = [row for row in file_rows if row.get("used_fallback")]
        export_id = datetime.now().strftime("%Y%m%d_%H%M%S") + f"_{os.getpid()}"
        manifest = {
            "schema": "coinbot_profitability_audit_export_v1132",
            "export_id": export_id,
            "generated_ts": time.time(),
            "generated_time": now(),
            "guard_version": VERSION,
            "bot_dir": str(BOT_DIR),
            "command": "/gexport_profitability",
            "delivery_contract": "single classic DEFLATE ZIP, Android/Samsung compatible method 8; no LZMA; no encryption",
            "snapshot_contract": "fixed logical allowlist; read-only point-in-time prefix; complete JSONL records; originals unchanged",
            "files": file_rows,
            "missing_files": missing,
            "fallback_files": [
                {"logical_name": row.get("logical_name"), "resolved_name": row.get("resolved_name")}
                for row in fallback_rows
            ],
            "failed_files": [
                {"name": row.get("name"), "status": row.get("status"), "error": row.get("error")}
                for row in failed
            ],
            "archive_count": 1,
            "compression": "ZIP_DEFLATED_STANDARD",
            "zip_method": 8,
            "encrypted": False,
            "original_files_modified": False,
            "temporary_cleanup_required": True,
            "temporary_retained_only_on_send_failure": True,
            "auto_buy_changed": False,
        }
        manifest_digest = hashlib.sha256(
            json.dumps(manifest, ensure_ascii=False, sort_keys=True).encode("utf-8")
        ).hexdigest()
        manifest["manifest_sha256"] = manifest_digest
        zip_path = root / f"coinbot_profitability_audit_{export_id}.zip"
        package_meta = _write_export_single_zip_v1130(zip_path, manifest, file_rows)
        result["archive"] = package_meta
        if int(package_meta["size"]) > GUARD_EXPORT_MAX_DOCUMENT_BYTES_V1129:
            preserve_temp_on_failure = True
            raise RuntimeError(
                "single standard ZIP exceeds Telegram document cap after DEFLATE compression: "
                f"{package_meta['size']} > {GUARD_EXPORT_MAX_DOCUMENT_BYTES_V1129}"
            )
        ok, detail = telegram_send_document_v1129(
            ALLOWED_CHAT_ID,
            zip_path,
            caption=(
                "코인봇 수익성 감사 원장 Android 호환 ZIP\n"
                f"export {export_id}\nmanifest {manifest_digest[:12]}"
            ),
        )
        package_meta.update(sent=ok, send_detail=detail)
        if not ok:
            preserve_temp_on_failure = True
            result["retained_temp_path"] = str(zip_path)
        status = "DONE" if len(existing) == len(PROFITABILITY_EXPORT_SPECS_V1130) and not missing and not failed and ok else "PARTIAL"
        result.update(
            status=status,
            export_id=export_id,
            manifest_sha256=manifest_digest,
            files=file_rows,
            existing_count=len(existing),
            missing_files=missing,
            fallback_files=manifest["fallback_files"],
            failed_files=failed,
            archive_count=1,
            sent_archives=1 if ok else 0,
            send_failure=None if ok else detail,
            completed_ts=time.time(),
            completed_time=now(),
        )
        proof = hashlib.sha256(json.dumps({
            "export_id": export_id,
            "manifest": manifest_digest,
            "archive": package_meta.get("sha256"),
            "compression": package_meta.get("compression"),
            "methods": package_meta.get("compression_method_ids"),
            "status": status,
        }, sort_keys=True).encode("utf-8")).hexdigest()[:16]
        summary = (
            f"Android-standard ZIP export {status}: {len(existing)} files, one archive sent={ok}, "
            f"methods={package_meta.get('compression_method_ids')}, missing {len(missing)}, original mutation 0."
        )
        remaining = "None" if status == "DONE" else "Resolve only missing/copy/send/size failure and rerun export."
        _append_profitability_export_ledger_v1132(status, summary, remaining, proof)
        fallback_text = ", ".join(
            f"{item.get('logical_name')}←{item.get('resolved_name')}"
            for item in manifest["fallback_files"]
        ) if fallback_rows else "0"
        cleanup_text = "임시파일 정리 완료" if ok else f"전송 실패 임시 ZIP 유지: {zip_path}"
        return (
            f"📦 수익성 감사파일 Android 호환 ZIP export {status}\n"
            f"- 파일 {len(existing)}/{len(PROFITABILITY_EXPORT_SPECS_V1130)} · ZIP 전송 {1 if ok else 0}/1\n"
            f"- ZIP {package_meta['size'] / (1024 * 1024):.2f}MB · 표준 DEFLATE(method 8) · CRC PASS\n"
            f"- 누락 {', '.join(missing) if missing else '0'} · 대체 원장 {fallback_text}\n"
            f"- manifest {manifest_digest[:16]}\n"
            f"- 원본 변경 0 · {cleanup_text}"
        )
    except Exception as exc:
        if zip_path is not None and zip_path.exists():
            preserve_temp_on_failure = True
            result["retained_temp_path"] = str(zip_path)
        result.update(
            status="FAIL",
            error=f"{type(exc).__name__}: {exc}",
            completed_ts=time.time(),
            completed_time=now(),
        )
        proof = hashlib.sha256(str(result.get("error") or "fail").encode("utf-8")).hexdigest()[:16]
        _append_profitability_export_ledger_v1132(
            "FAIL",
            f"Android-standard profitability export failed: {result.get('error')}",
            "Fix only the export compression/transport path; protected ledgers remain unchanged.",
            proof,
        )
        retained = f"\n- 임시 ZIP 유지: {zip_path}" if preserve_temp_on_failure and zip_path is not None else ""
        return (
            "📦 ❌ 수익성 감사파일 Android 호환 ZIP export 실패\n"
            f"- {result.get('error')}\n"
            "- 원본 원장 변경 없음"
            f"{retained}"
        )
    finally:
        result["duration_sec"] = round(time.time() - started, 3)
        try:
            write_json(BOT_DIR / GUARD_EXPORT_LAST_RESULT_V1129, result)
        except Exception:
            pass
        if root is not None and not preserve_temp_on_failure:
            try:
                shutil.rmtree(root)
            except Exception as exc:
                print(f"[{now()}] export temp cleanup failed: {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
        if lock_handle is not None:
            try:
                fcntl.flock(lock_handle.fileno(), fcntl.LOCK_UN)
            except Exception:
                pass
            try:
                lock_handle.close()
            except Exception:
                pass

def _v1214_candidate_rows(path: Path) -> tuple[list[dict], list[str]]:
    rows: list[dict] = []
    errors: list[str] = []
    if not path.exists():
        return rows, ["candidate_file_missing"]
    try:
        with path.open("r", encoding="utf-8", errors="strict") as fh:
            for line_no, raw in enumerate(fh, 1):
                text = raw.strip()
                if not text:
                    continue
                try:
                    obj = json.loads(text)
                except Exception as exc:
                    errors.append(f"line_{line_no}:{type(exc).__name__}")
                    continue
                if isinstance(obj, dict):
                    rows.append(obj)
                elif isinstance(obj, list):
                    rows.extend(x for x in obj if isinstance(x, dict))
    except Exception as exc:
        errors.append(f"read:{type(exc).__name__}:{exc}")
    return rows, errors


def _v1214_reason_list(row: dict) -> list[str]:
    sources = []
    gate = row.get("swing_entry_gate_v977")
    if isinstance(gate, dict):
        sources.append(gate.get("hard_block_reasons"))
    decision = row.get("canonical_entry_decision")
    if isinstance(decision, dict):
        sources.append(decision.get("hard_block_reasons"))
    sources.extend((row.get("hard_block_reasons"), row.get("final_trade_reasons"), row.get("final_entry_reasons")))
    out: list[str] = []
    for source in sources:
        values = source if isinstance(source, list) else ([source] if source not in (None, "") else [])
        for value in values:
            reason = str(value or "").strip()
            if reason and reason not in out:
                out.append(reason)
    return out


def _v1214_observation_flag(row: dict) -> bool:
    sources = [row]
    for key in ("entry_context", "canonical_entry_decision", "common_entry_decision"):
        obj = row.get(key)
        if isinstance(obj, dict):
            sources.append(obj)
    flags = (
        "s3_observe_v732", "s3_observe_v730", "s3_observe_v729", "s3_observe_v728", "s3_observe_v727",
        "s3_observation_only_v988", "s3_review_only_v988", "observation_open_forbidden_v988",
    )
    for source in sources:
        if any(source.get(key) is True for key in flags):
            return True
        for key in ("strategy_key", "paper_strategy_key", "route", "strategy", "strategy_label", "setup_type"):
            text = str(source.get(key) or "").strip().lower()
            if text.startswith("coin_quality_s3_observe") or text in {"s3_observe", "coin_quality_s3_observation"}:
                return True
            if "s3 관찰/복기 후보" in text or "s3 관찰 후보" in text:
                return True
    return False


def _v1214_stage(row: dict) -> str:
    value = str(row.get("s_stage") or row.get("candidate_stage") or row.get("candidate_grade") or row.get("grade") or "-").upper()
    return value if value in {"S1", "S2", "S3"} else "OTHER"


def _v1214_structure_presence(row: dict) -> dict:
    gate = row.get("swing_entry_gate_v977") if isinstance(row.get("swing_entry_gate_v977"), dict) else {}
    plan = gate.get("structure_plan") if isinstance(gate.get("structure_plan"), dict) else {}
    if not plan and isinstance(row.get("swing_structure_plan_v977"), dict):
        plan = row.get("swing_structure_plan_v977")
    trigger = plan.get("trigger") if isinstance(plan.get("trigger"), dict) else {}
    invalid = plan.get("invalid") if isinstance(plan.get("invalid"), dict) else {}
    target = plan.get("target") if isinstance(plan.get("target"), dict) else {}
    trigger_price = gate.get("trigger_price") or row.get("swing_trigger_price_v977") or row.get("trigger_price")
    invalid_price = gate.get("invalid_price") or row.get("swing_invalid_price_v977") or row.get("invalid_price")
    target_price = gate.get("target_price") or row.get("swing_target_price_v977") or row.get("target_price")
    def positive(value) -> bool:
        try:
            return float(value) > 0
        except Exception:
            return False
    return {
        "trigger_object": bool(trigger), "invalid_object": bool(invalid), "target_object": bool(target),
        "trigger_price": positive(trigger_price), "invalid_price": positive(invalid_price), "target_price": positive(target_price),
    }


def collect_s1_zero_root_audit_v1214() -> dict:
    candidate_path = BOT_DIR / S1_ZERO_AUDIT_CANDIDATES_V1214
    gate_path = BOT_DIR / S1_ZERO_AUDIT_GATE_STATUS_V1214
    writer_path = BOT_DIR / S1_ZERO_AUDIT_WRITER_STATUS_V1214
    rows: list[dict] = []
    read_errors: list[str] = []
    stable_read = False
    candidate_stat = None
    for _ in range(3):
        before = candidate_path.stat() if candidate_path.exists() else None
        rows, read_errors = _v1214_candidate_rows(candidate_path)
        after = candidate_path.stat() if candidate_path.exists() else None
        if before and after and before.st_ino == after.st_ino and before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns:
            stable_read = True
            candidate_stat = after
            break
        time.sleep(0.05)
    gate_status = read_json(gate_path) or {}
    writer_status = read_json(writer_path) or {}
    scope = writer_status.get("candidate_snapshot_scope") if isinstance(writer_status.get("candidate_snapshot_scope"), dict) else {}
    reason_counts: Counter[str] = Counter()
    stage_counts: Counter[str] = Counter()
    observation_flag_count = 0
    severe_rows = 0
    nonsevere_only_rows = 0
    no_reason_rows = 0
    trigger_object_missing = invalid_object_missing = target_object_missing = 0
    trigger_price_missing = invalid_price_missing = target_price_missing = 0
    cycle_ids: Counter[str] = Counter()
    severe_reasons = {
        "s3_observation_only_no_open", "stable_market_state_key_missing", "structure_integrity_quarantine_v1048",
        "dynamic_structure_source_missing", "frozen_structure_invalidated", "frozen_target_completed",
        "actual_structural_trigger_missing", "actual_structural_invalid_missing", "next_structural_target_missing",
        "coherent_structure_plan_incomplete", "invalid_trigger_target_order_invalid", "untradable_spread",
        "untradable_liquidity", "confirmed_slippage_untradable", "extreme_quality_execution_trap",
    }
    for row in rows:
        stage_counts[_v1214_stage(row)] += 1
        cycle_id = str(row.get("candidate_pipeline_cycle_id_v1150") or "").strip()
        if cycle_id:
            cycle_ids[cycle_id] += 1
        if _v1214_observation_flag(row):
            observation_flag_count += 1
        reasons = _v1214_reason_list(row)
        for reason in reasons:
            reason_counts[reason] += 1
        if not reasons:
            no_reason_rows += 1
        elif any(reason in severe_reasons for reason in reasons):
            severe_rows += 1
        else:
            nonsevere_only_rows += 1
        presence = _v1214_structure_presence(row)
        trigger_object_missing += int(not presence["trigger_object"])
        invalid_object_missing += int(not presence["invalid_object"])
        target_object_missing += int(not presence["target_object"])
        trigger_price_missing += int(not presence["trigger_price"])
        invalid_price_missing += int(not presence["invalid_price"])
        target_price_missing += int(not presence["target_price"])
    total = len(rows)
    s1 = int(stage_counts.get("S1", 0)); s2 = int(stage_counts.get("S2", 0)); s3 = int(stage_counts.get("S3", 0))
    observation_reason_count = int(reason_counts.get("s3_observation_only_no_open", 0))
    dynamic_missing_count = int(reason_counts.get("dynamic_structure_source_missing", 0))
    writer_rows = int(scope.get("rows_written") or writer_status.get("rows_written") or writer_status.get("compact_rows") or 0)
    writer_cycle = str(scope.get("pipeline_cycle_id_v1150") or "").strip()
    writer_commit = str(scope.get("commit_id") or writer_status.get("candidate_last_commit_id_v1026") or "").strip()
    row_cycle = cycle_ids.most_common(1)[0][0] if cycle_ids else ""
    row_cycle_consistent = len(cycle_ids) <= 1
    gate_rows = int(gate_status.get("rows") or 0)
    gate_s1 = int(gate_status.get("pass_s1") or 0); gate_s2 = int(gate_status.get("recheck_s2") or 0); gate_s3 = int(gate_status.get("observe_s3") or 0)
    gate_observation = int(gate_status.get("observation_only_blocked_v988") or 0)
    gate_reason_top = gate_status.get("hard_reason_top") if isinstance(gate_status.get("hard_reason_top"), list) else []
    same_rows = total > 0 and total == writer_rows == gate_rows
    same_stage = (s1, s2, s3) == (gate_s1, gate_s2, gate_s3)
    same_cycle = bool(row_cycle and writer_cycle and row_cycle == writer_cycle and row_cycle_consistent)
    observation_consistent = observation_reason_count == observation_flag_count == gate_observation
    s3_severe_accounted = s3 == severe_rows and s3 > 0
    if read_errors or not stable_read or not same_rows or not same_stage or not same_cycle:
        verdict = "CHECK_SOURCE_MISMATCH"
        easy = "현재 cycle 원문 연결부터 다시 확인 필요"
    elif total > 0 and observation_reason_count == total and s3 == total:
        verdict = "PROVEN_OBSERVATION_ONLY_ALL"
        easy = "전체 후보가 옛 S3 관찰표시 때문에 강제 탈락"
    elif total > 0 and dynamic_missing_count == total and s3 == total:
        verdict = "PROVEN_DYNAMIC_STRUCTURE_MISSING_ALL"
        easy = "전체 후보의 동적 구조선 계약이 비어 강제 탈락"
    elif s3_severe_accounted:
        verdict = "PROVEN_MIXED_SEVERE"
        easy = "모든 S3가 강한 차단 사유로 설명됨"
    else:
        verdict = "PARTIAL_UNACCOUNTED"
        easy = "일부 S3 원인이 아직 원문 사유로 설명되지 않음"
    nowv = time.time()
    report = {
        "schema": "s1_zero_root_audit_v1214", "version": "v1214", "guard_version": VERSION,
        "created_ts": nowv, "created_text": now(), "verdict": verdict, "easy_verdict": easy,
        "read_only": True, "strategy_changed": False, "entry_exit_changed": False, "auto_buy": False,
        "source": {
            "candidate_file": candidate_path.name, "candidate_rows": total, "candidate_size": candidate_stat.st_size if candidate_stat else None,
            "candidate_mtime": candidate_stat.st_mtime if candidate_stat else None, "stable_read": stable_read, "read_errors": read_errors,
            "row_cycle_id": row_cycle or None, "row_cycle_count": len(cycle_ids), "row_cycle_consistent": row_cycle_consistent,
            "writer_cycle_id": writer_cycle or None, "writer_commit_id": writer_commit or None, "writer_rows": writer_rows,
            "gate_rows": gate_rows, "same_rows": same_rows, "same_stage": same_stage, "same_cycle": same_cycle,
            "gate_updated_ts": gate_status.get("updated_ts"), "writer_updated_ts": scope.get("updated_ts") or writer_status.get("updated_ts"),
        },
        "stage": {"total": total, "s1": s1, "s2": s2, "s3": s3, "other": int(stage_counts.get("OTHER", 0))},
        "root_counts": {
            "observation_flag_rows": observation_flag_count, "s3_observation_only_no_open": observation_reason_count,
            "gate_observation_only_blocked": gate_observation, "observation_count_consistent": observation_consistent,
            "dynamic_structure_source_missing": dynamic_missing_count,
            "actual_structural_trigger_missing": int(reason_counts.get("actual_structural_trigger_missing", 0)),
            "actual_structural_invalid_missing": int(reason_counts.get("actual_structural_invalid_missing", 0)),
            "next_structural_target_missing": int(reason_counts.get("next_structural_target_missing", 0)),
            "coherent_structure_plan_incomplete": int(reason_counts.get("coherent_structure_plan_incomplete", 0)),
            "severe_rows": severe_rows, "nonsevere_only_rows": nonsevere_only_rows, "no_reason_rows": no_reason_rows,
        },
        "structure_presence": {
            "trigger_object_missing": trigger_object_missing, "invalid_object_missing": invalid_object_missing, "target_object_missing": target_object_missing,
            "trigger_price_missing": trigger_price_missing, "invalid_price_missing": invalid_price_missing, "target_price_missing": target_price_missing,
        },
        "reason_counts": dict(reason_counts.most_common()),
        "reason_top": [{"reason": k, "count": v} for k, v in reason_counts.most_common(16)],
        "gate_reason_top": gate_reason_top,
        "checks": {
            "stable_candidate_read": stable_read, "same_row_count": same_rows, "same_stage_count": same_stage,
            "same_cycle": same_cycle, "observation_count_consistent": observation_consistent,
            "s3_severe_accounted": s3_severe_accounted,
            "candidate_standard_zero_warning": "기존 candidate_standard 구조·누락 0은 S1 row만 검사하므로 S1=0일 때 전체 463 증거가 아님",
        },
        "policy": "evidence only; no gate, threshold, candidate, OPEN, exit, auto-buy or live ledger mutation",
    }
    write_json(BOT_DIR / S1_ZERO_AUDIT_STATUS_V1214, report)
    return report


def gs1_zero_audit_text_v1214() -> str:
    try:
        report = collect_s1_zero_root_audit_v1214()
    except Exception as exc:
        return "\n".join([
            "🔎 ❌ S1 0 원인감사 실패 /gs1_zero_audit",
            f"- {type(exc).__name__}: {exc}",
            "- 전략·진입·청산·원장 변경 없음 / 자동매수 OFF",
        ])
    src = report.get("source") or {}; stage = report.get("stage") or {}; root = report.get("root_counts") or {}; structure = report.get("structure_presence") or {}
    top = report.get("reason_top") if isinstance(report.get("reason_top"), list) else []
    top_text = " / ".join(f"{x.get('reason')} {x.get('count')}" for x in top[:10] if isinstance(x, dict)) or "-"
    return "\n".join([
        f"🔎 S1 0 원인감사 /gs1_zero_audit · {VERSION}",
        f"- 판정: {report.get('verdict')} · {report.get('easy_verdict')}",
        f"- cycle: {src.get('row_cycle_id') or '-'} / commit {src.get('writer_commit_id') or '-'}",
        f"- 전체 {stage.get('total',0)} → S1 {stage.get('s1',0)} / S2 {stage.get('s2',0)} / S3 {stage.get('s3',0)}",
        f"- 옛 S3 관찰표시: row {root.get('observation_flag_rows',0)} / 실제 차단 {root.get('s3_observation_only_no_open',0)} / Gate {root.get('gate_observation_only_blocked',0)}",
        f"- 동적 구조선 누락: 전체계약 {root.get('dynamic_structure_source_missing',0)} / trigger {root.get('actual_structural_trigger_missing',0)} / invalid {root.get('actual_structural_invalid_missing',0)} / target {root.get('next_structural_target_missing',0)}",
        f"- 구조 객체 누락: trigger {structure.get('trigger_object_missing',0)} / invalid {structure.get('invalid_object_missing',0)} / target {structure.get('target_object_missing',0)}",
        f"- 강한 차단으로 설명: {root.get('severe_rows',0)} / 일반 S2 사유만 {root.get('nonsevere_only_rows',0)} / 사유없음 {root.get('no_reason_rows',0)}",
        f"- 탈락 사유 TOP: {top_text}",
        f"- 원문 연결: stable {src.get('stable_read')} / rows일치 {src.get('same_rows')} / stage일치 {src.get('same_stage')} / cycle일치 {src.get('same_cycle')}",
        "- 주의: 기존 후보 기준판의 구조선 누락 0은 S1만 검사한 값이라 S1 0일 때 전체 후보 증거가 아님",
        "- 읽기 전용 · 기준/ATR/RR/청산/OPEN 변경 0 · 자동매수 OFF",
    ])


def _v1216_plan(row: dict) -> dict:
    plan = row.get("dynamic_structure_plan_v1212") if isinstance(row.get("dynamic_structure_plan_v1212"), dict) else {}
    if not plan and isinstance(row.get("structure_contract_v1212"), dict):
        plan = row.get("structure_contract_v1212")
    return plan if isinstance(plan, dict) else {}


def _v1216_float(value) -> Optional[float]:
    try:
        number = float(value)
        return number if math.isfinite(number) else None
    except Exception:
        return None


def _v1216_median(values: list[float]) -> Optional[float]:
    cleaned = sorted(float(x) for x in values if isinstance(x, (int, float)) and math.isfinite(float(x)))
    if not cleaned:
        return None
    mid = len(cleaned) // 2
    return cleaned[mid] if len(cleaned) % 2 else (cleaned[mid - 1] + cleaned[mid]) / 2.0


def collect_structure_missing_exact_audit_v1216() -> dict:
    candidate_path = BOT_DIR / S1_ZERO_AUDIT_CANDIDATES_V1214
    gate_path = BOT_DIR / S1_ZERO_AUDIT_GATE_STATUS_V1214
    writer_path = BOT_DIR / S1_ZERO_AUDIT_WRITER_STATUS_V1214
    rows: list[dict] = []
    read_errors: list[str] = []
    stable_read = False
    candidate_stat = None
    for _ in range(3):
        before = candidate_path.stat() if candidate_path.exists() else None
        rows, read_errors = _v1214_candidate_rows(candidate_path)
        after = candidate_path.stat() if candidate_path.exists() else None
        if before and after and before.st_ino == after.st_ino and before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns:
            stable_read = True
            candidate_stat = after
            break
        time.sleep(0.05)
    gate_status = read_json(gate_path) or {}
    writer_status = read_json(writer_path) or {}
    scope = writer_status.get("candidate_snapshot_scope") if isinstance(writer_status.get("candidate_snapshot_scope"), dict) else {}
    cycle_ids: Counter[str] = Counter()
    stage_counts: Counter[str] = Counter()
    dynamic_rows: list[dict] = []
    for row in rows:
        stage_counts[_v1214_stage(row)] += 1
        cycle_id = str(row.get("candidate_pipeline_cycle_id_v1150") or "").strip()
        if cycle_id:
            cycle_ids[cycle_id] += 1
        if "dynamic_structure_source_missing" in _v1214_reason_list(row):
            dynamic_rows.append(row)

    axis_patterns: Counter[str] = Counter()
    reason_codes: Counter[str] = Counter()
    link_modes: Counter[str] = Counter()
    frame_lt5: Counter[str] = Counter()
    frame_zero: Counter[str] = Counter()
    diag_ready = 0
    missing_diag = 0
    trigger_source_zero = invalid_source_zero = target_source_zero = 0
    normal_noise_values: list[float] = []
    max_risk_values: list[float] = []
    chase_values: list[float] = []
    reach_values: list[float] = []
    samples: list[dict] = []
    for row in dynamic_rows:
        plan = _v1216_plan(row)
        evidence = row.get("dynamic_structure_material_evidence_v1215") if isinstance(row.get("dynamic_structure_material_evidence_v1215"), dict) else {}
        link_mode = str(plan.get("material_link_mode_v1215") or evidence.get("link_mode") or "UNKNOWN")
        link_modes[link_mode] += 1
        frames = plan.get("frame_counts_v1215") if isinstance(plan.get("frame_counts_v1215"), dict) else evidence.get("frame_counts") if isinstance(evidence.get("frame_counts"), dict) else {}
        for tf in ("m5", "m15", "m30", "h1", "h2", "h4"):
            try:
                count = int(frames.get(tf) or 0)
            except Exception:
                count = 0
            if count == 0:
                frame_zero[tf] += 1
            if count < 5:
                frame_lt5[tf] += 1
        diag = plan.get("selection_diagnostics_v1216") if isinstance(plan.get("selection_diagnostics_v1216"), dict) else {}
        if not diag and isinstance(row.get("candidate_structure_diagnostic_v1218"), dict):
            diag = row.get("candidate_structure_diagnostic_v1218")
        if not diag:
            missing_diag += 1
            continue
        diag_ready += 1
        axes = [str(x) for x in (diag.get("missing_axes") or []) if str(x)]
        pattern = "+".join(sorted(axes)) if axes else "none"
        axis_patterns[pattern] += 1
        codes = [str(x) for x in (diag.get("missing_reason_codes") or []) if str(x) and str(x) != "complete"]
        for code in codes:
            reason_codes[code] += 1
        trig = diag.get("trigger") if isinstance(diag.get("trigger"), dict) else {}
        inv = diag.get("invalid") if isinstance(diag.get("invalid"), dict) else {}
        tgt = diag.get("target") if isinstance(diag.get("target"), dict) else {}
        trigger_source_zero += int(int(trig.get("source_zones") or 0) == 0)
        invalid_source_zero += int(int(inv.get("source_zones") or 0) == 0)
        target_source_zero += int(int(tgt.get("source_zones") or 0) == 0)
        for value, bucket in (
            (plan.get("normal_noise_pct"), normal_noise_values),
            (plan.get("maximum_risk_pct"), max_risk_values),
            (plan.get("dynamic_chase_limit_pct"), chase_values),
            (plan.get("target_reach_limit_pct"), reach_values),
        ):
            number = _v1216_float(value)
            if number is not None:
                bucket.append(number)
        if len(samples) < 8:
            samples.append({
                "ticker": str(row.get("ticker") or row.get("market") or row.get("symbol") or "-"),
                "axes": axes,
                "reasons": codes,
                "frames": {tf: int(frames.get(tf) or 0) for tf in ("m5", "m15", "m30", "h1", "h2", "h4")},
                "zones": dict(plan.get("zone_counts") or {}),
                "normal_noise_pct": plan.get("normal_noise_pct"),
                "maximum_risk_pct": plan.get("maximum_risk_pct"),
            })

    total = len(rows)
    gate_rows = int(gate_status.get("rows") or 0)
    gate_dynamic = 0
    for item in gate_status.get("hard_reason_top") if isinstance(gate_status.get("hard_reason_top"), list) else []:
        if isinstance(item, dict) and item.get("reason") == "dynamic_structure_source_missing":
            gate_dynamic = int(item.get("count") or 0)
            break
    writer_rows = int(scope.get("rows_written") or writer_status.get("rows_written") or writer_status.get("compact_rows") or 0)
    has_v1218_writer = bool(writer_status.get("candidate_final_blob_schema_v1218"))
    writer_evidence_v1218 = {
        "schema": writer_status.get("candidate_final_blob_schema_v1218") or writer_status.get("candidate_final_blob_schema_v1217"),
        "expected_plan": int(writer_status.get("candidate_expected_plan_rows_v1218") if has_v1218_writer else writer_status.get("candidate_expected_plan_rows_v1217") or 0),
        "compact_plan": int(writer_status.get("candidate_compact_plan_rows_v1218") if has_v1218_writer else writer_status.get("candidate_compact_plan_rows_v1217") or 0),
        "encoded_plan": int(writer_status.get("candidate_encoded_plan_rows_v1218") if has_v1218_writer else writer_status.get("candidate_encoded_plan_rows_v1217") or 0),
        "expected_diag": int(writer_status.get("candidate_expected_diag_rows_v1218") if has_v1218_writer else writer_status.get("candidate_expected_diag_rows_v1217") or 0),
        "compact_diag": int(writer_status.get("candidate_compact_diag_rows_v1218") if has_v1218_writer else writer_status.get("candidate_compact_diag_rows_v1217") or 0),
        "encoded_diag": int(writer_status.get("candidate_encoded_diag_rows_v1218") if has_v1218_writer else writer_status.get("candidate_encoded_diag_rows_v1217") or 0),
        "expected_material": int(writer_status.get("candidate_expected_material_rows_v1218") if has_v1218_writer else writer_status.get("candidate_expected_material_rows_v1217") or 0),
        "compact_material": int(writer_status.get("candidate_compact_material_rows_v1218") if has_v1218_writer else writer_status.get("candidate_compact_material_rows_v1217") or 0),
        "encoded_material": int(writer_status.get("candidate_encoded_material_rows_v1218") if has_v1218_writer else writer_status.get("candidate_encoded_material_rows_v1217") or 0),
        "expected_contract": int(writer_status.get("candidate_expected_contract_rows_v1218") or 0),
        "compact_contract": int(writer_status.get("candidate_compact_contract_rows_v1218") or 0),
        "encoded_contract": int(writer_status.get("candidate_encoded_contract_rows_v1218") or 0),
        "exact": (writer_status.get("candidate_encoded_evidence_exact_v1218") is True) if has_v1218_writer else (writer_status.get("candidate_encoded_evidence_exact_v1217") is True),
        "single_plan_compact_contract": writer_status.get("candidate_full_contract_duplicate_retired_v1218") is True,
        "stale_blob_retired": (writer_status.get("candidate_stale_pre_wrapper_blob_retired_v1218") is True) if has_v1218_writer else (writer_status.get("candidate_stale_pre_wrapper_blob_retired_v1217") is True),
    }
    writer_cycle = str(scope.get("pipeline_cycle_id_v1150") or "").strip()
    writer_commit = str(scope.get("commit_id") or writer_status.get("candidate_last_commit_id_v1026") or "").strip()
    row_cycle = cycle_ids.most_common(1)[0][0] if cycle_ids else ""
    same_rows = total > 0 and total == writer_rows == gate_rows
    same_cycle = bool(row_cycle and writer_cycle and row_cycle == writer_cycle and len(cycle_ids) <= 1)
    same_dynamic = len(dynamic_rows) == gate_dynamic
    source_mismatch = bool(read_errors or not stable_read or not same_rows or not same_cycle or not same_dynamic)
    linked_missing = int(link_modes.get("SOURCE_MISSING", 0))
    if source_mismatch:
        verdict = "CHECK_SOURCE_MISMATCH"
        easy = "현재 cycle 원문 연결부터 다시 확인 필요"
    elif not writer_evidence_v1218.get("schema"):
        verdict = "CHECK_WAIT_V1218_WRITER_EVIDENCE"
        easy = "v1218 최종 writer 증거가 아직 새 완료 cycle에 기록되지 않음"
    elif not writer_evidence_v1218.get("exact"):
        verdict = "FAIL_V1218_ENCODED_EVIDENCE_MISMATCH"
        easy = "Strategy 메모리 후보와 실제 JSONL 저장값이 불일치"
    elif not dynamic_rows:
        verdict = "NORMAL_NO_DYNAMIC_MISSING"
        easy = "현재 cycle에는 동적 구조계약 누락 후보가 없음"
    elif diag_ready != len(dynamic_rows):
        verdict = "FAIL_V1218_CANDIDATE_EVIDENCE_MISSING"
        easy = "writer는 정상이라 했지만 실제 누락 후보 row의 진단값이 부족함"
    elif linked_missing > 0:
        verdict = "PROVEN_MIXED_MATERIAL_AND_SELECTION"
        easy = "일부는 Candle 연결 누락, 나머지는 구조선 선택조건에서 빈 계약"
    else:
        verdict = "PROVEN_SELECTION_FILTER_EMPTY"
        easy = "Candle 자료는 연결됐지만 실제 구역 선택조건을 통과한 선이 없어 빈 계약"
    nowv = time.time()
    report = {
        "schema":"structure_missing_exact_audit_v1218", "version":"v1218", "guard_version":VERSION,
        "created_ts":nowv, "created_text":now(), "verdict":verdict, "easy_verdict":easy,
        "read_only":True, "strategy_formula_changed":False, "entry_exit_changed":False, "auto_buy":False,
        "source":{
            "candidate_file":candidate_path.name, "candidate_rows":total, "candidate_size":candidate_stat.st_size if candidate_stat else None,
            "stable_read":stable_read, "read_errors":read_errors, "row_cycle_id":row_cycle or None,
            "writer_cycle_id":writer_cycle or None, "writer_commit_id":writer_commit or None,
            "same_rows":same_rows, "same_cycle":same_cycle, "same_dynamic_count":same_dynamic,
            "writer_evidence_v1218":writer_evidence_v1218,
        },
        "stage":{"total":total,"s1":int(stage_counts.get("S1",0)),"s2":int(stage_counts.get("S2",0)),"s3":int(stage_counts.get("S3",0))},
        "dynamic_missing_rows":len(dynamic_rows), "diagnostic_ready_rows":diag_ready, "diagnostic_missing_rows":missing_diag,
        "material_link_modes":dict(link_modes.most_common()), "axis_patterns":dict(axis_patterns.most_common()),
        "missing_reason_counts":dict(reason_codes.most_common()),
        "frame_less_than_5":dict(frame_lt5), "frame_zero":dict(frame_zero),
        "zone_source_zero":{"trigger":trigger_source_zero,"invalid":invalid_source_zero,"target":target_source_zero},
        "range_medians":{
            "normal_noise_pct":_v1216_median(normal_noise_values), "maximum_risk_pct":_v1216_median(max_risk_values),
            "dynamic_chase_limit_pct":_v1216_median(chase_values), "target_reach_limit_pct":_v1216_median(reach_values),
        },
        "samples":samples,
        "policy":"evidence only; no ATR/RR/zone formula, gate, rank, OPEN, exit, ledger or auto-buy mutation",
    }
    write_json(BOT_DIR / STRUCTURE_MISSING_AUDIT_STATUS_V1216, report)
    return report


_V1216_REASON_KO = {
    "trigger_current_price_missing":"Trigger 계산 현재가 없음",
    "trigger_entry_frames_insufficient":"5m·15m 완료봉 부족",
    "trigger_resistance_zone_absent":"5m·15m 저항구역 없음",
    "trigger_all_zones_far_below_after_breakout":"저항구역을 이미 너무 멀리 돌파",
    "trigger_selection_empty_other":"Trigger 선택 기타",
    "invalid_ceiling_missing":"Invalid 기준가격 없음",
    "invalid_setup_frames_insufficient":"30m·1h·2h·4h 완료봉 부족",
    "invalid_support_zone_absent":"상위시간 지지구역 없음",
    "invalid_supports_inside_normal_noise":"지지가 정상 흔들림 안쪽이라 제외",
    "invalid_supports_beyond_max_risk":"지지가 최대 위험 밖이라 제외",
    "invalid_supports_not_below_entry_ceiling":"지지가 현재가·Trigger 아래가 아님",
    "invalid_selection_empty_other":"Invalid 선택 기타",
    "target_projection_unavailable_without_trigger":"Trigger 없음으로 동적 Target 확장 불가",
    "target_floor_missing":"Target 기준가격 없음",
    "target_resistance_zone_absent":"상위시간 저항구역 없음",
    "target_nearest_resistance_too_close_after_capture":"가장 가까운 저항이 Trigger와 너무 가까워 Target 보정 후 역전",
    "target_selection_empty_other":"Target 선택 기타",
}


def gstructure_missing_audit_text_v1216() -> str:
    try:
        report = collect_structure_missing_exact_audit_v1216()
    except Exception as exc:
        return "\n".join([
            "🧩 ❌ 구조선 빈 계약 정밀감사 실패 /gstructure_missing_audit",
            f"- {type(exc).__name__}: {exc}",
            "- 전략·진입·청산·원장 변경 없음 / 자동매수 OFF",
        ])
    src = report.get("source") or {}; stage = report.get("stage") or {}
    reasons = report.get("missing_reason_counts") if isinstance(report.get("missing_reason_counts"), dict) else {}
    reason_text = " / ".join(f"{_V1216_REASON_KO.get(k,k)} {v}" for k,v in list(reasons.items())[:8]) or "-"
    patterns = report.get("axis_patterns") if isinstance(report.get("axis_patterns"), dict) else {}
    pattern_text = " / ".join(f"{k} {v}" for k,v in list(patterns.items())[:6]) or "-"
    links = report.get("material_link_modes") if isinstance(report.get("material_link_modes"), dict) else {}
    frames = report.get("frame_less_than_5") if isinstance(report.get("frame_less_than_5"), dict) else {}
    frame_text = " / ".join(f"{k} {v}" for k,v in frames.items() if v) or "0"
    zone_zero = report.get("zone_source_zero") or {}; med = report.get("range_medians") or {}
    return "\n".join([
        f"🧩 동적 구조선 누락 정밀감사 /gstructure_missing_audit · {VERSION}",
        f"- 판정: {report.get('verdict')} · {report.get('easy_verdict')}",
        f"- cycle: {src.get('row_cycle_id') or '-'} / commit {src.get('writer_commit_id') or '-'}",
        f"- 전체 {stage.get('total',0)} → S1 {stage.get('s1',0)} / S2 {stage.get('s2',0)} / S3 {stage.get('s3',0)} · 빈 계약 {report.get('dynamic_missing_rows',0)}",
        f"- Candle 연결방식: {links}",
        f"- 누락축 조합: {pattern_text}",
        f"- 실제 원인: {reason_text}",
        f"- 완료봉 5개 미만: {frame_text}",
        f"- 구조구역 자체 0건: Trigger {zone_zero.get('trigger',0)} / Invalid {zone_zero.get('invalid',0)} / Target {zone_zero.get('target',0)}",
        f"- 중앙값: 정상흔들림 {med.get('normal_noise_pct')}% / 최대위험 {med.get('maximum_risk_pct')}% / 추격한도 {med.get('dynamic_chase_limit_pct')}% / 목표도달한도 {med.get('target_reach_limit_pct')}%",
        f"- 원문 연결: stable {src.get('stable_read')} / rows일치 {src.get('same_rows')} / cycle일치 {src.get('same_cycle')} / 누락건수일치 {src.get('same_dynamic_count')}",
        f"- writer 증거: {((src.get('writer_evidence_v1218') or {}).get('schema') or '-')} / exact {((src.get('writer_evidence_v1218') or {}).get('exact'))} / diag expected·compact·encoded {((src.get('writer_evidence_v1218') or {}).get('expected_diag',0))}·{((src.get('writer_evidence_v1218') or {}).get('compact_diag',0))}·{((src.get('writer_evidence_v1218') or {}).get('encoded_diag',0))}",
        "- 읽기 전용 · ATR/RR/구조선식/청산/OPEN 변경 0 · 자동매수 OFF",
    ])


def _v1219_quantile(values: list[float], q: float) -> Optional[float]:
    cleaned = sorted(float(x) for x in values if isinstance(x, (int, float)) and math.isfinite(float(x)))
    if not cleaned:
        return None
    if len(cleaned) == 1:
        return cleaned[0]
    pos = max(0.0, min(1.0, float(q))) * (len(cleaned) - 1)
    lo = int(math.floor(pos)); hi = int(math.ceil(pos))
    if lo == hi:
        return cleaned[lo]
    weight = pos - lo
    return cleaned[lo] * (1.0 - weight) + cleaned[hi] * weight


def _v1219_distribution(values: list[float]) -> dict:
    cleaned = [float(x) for x in values if isinstance(x, (int, float)) and math.isfinite(float(x))]
    if not cleaned:
        return {"n": 0, "min": None, "p10": None, "p25": None, "median": None, "p75": None, "p90": None, "max": None}
    return {
        "n": len(cleaned),
        "min": min(cleaned),
        "p10": _v1219_quantile(cleaned, 0.10),
        "p25": _v1219_quantile(cleaned, 0.25),
        "median": _v1219_quantile(cleaned, 0.50),
        "p75": _v1219_quantile(cleaned, 0.75),
        "p90": _v1219_quantile(cleaned, 0.90),
        "max": max(cleaned),
    }


def _v1219_line_price(value: Any) -> Optional[float]:
    if isinstance(value, dict):
        for key in ("rounded_price", "raw_price", "price"):
            number = _v1216_float(value.get(key))
            if number is not None and number > 0:
                return number
    return None


def _v1219_first_number(*values: Any) -> Optional[float]:
    for value in values:
        number = _v1216_float(value)
        if number is not None:
            return number
    return None


def _v1219_pct_distance(high: Optional[float], low: Optional[float]) -> Optional[float]:
    if high is None or low is None or high <= 0:
        return None
    return (high - low) / high * 100.0


def _v1219_move_pct(current: Optional[float], frozen: Optional[float]) -> Optional[float]:
    if current is None or frozen is None or frozen <= 0:
        return None
    return abs(current - frozen) / frozen * 100.0


def _v1219_fmt(value: Any, digits: int = 3) -> str:
    number = _v1216_float(value)
    return "정보없음" if number is None else f"{number:.{digits}f}"


def _v1229_exact_candidate_commit_scope() -> dict:
    """Bind the atomic candidate file directly to its canonical writer commit.

    Gate status is not commit-scoped, so geometry/flow audits must derive rows,
    stages and thresholds from the same candidate bytes instead of mixing a
    later status snapshot.  The short retry covers the atomic file/status handoff.
    """
    candidate_path = BOT_DIR / S1_ZERO_AUDIT_CANDIDATES_V1214
    writer_path = BOT_DIR / S1_ZERO_AUDIT_WRITER_STATUS_V1214
    result = {
        'candidate_path': candidate_path, 'rows': [], 'read_errors': [],
        'stable_read': False, 'candidate_stat': None, 'writer_status': {},
        'scope': {}, 'cycle_ids': Counter(), 'row_cycle': '', 'writer_cycle': '',
        'writer_commit': '', 'writer_rows': 0, 'writer_bytes': 0,
        'same_rows': False, 'same_cycle': False, 'writer_exact': False,
    }
    for _ in range(8):
        before = candidate_path.stat() if candidate_path.exists() else None
        rows, errors = _v1214_candidate_rows(candidate_path)
        after = candidate_path.stat() if candidate_path.exists() else None
        stable = bool(before and after and before.st_ino == after.st_ino and before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns)
        writer = read_json(writer_path) or {}
        scope = writer.get('candidate_snapshot_scope') if isinstance(writer.get('candidate_snapshot_scope'), dict) else {}
        cycles = Counter()
        for row in rows:
            cid = str(row.get('candidate_pipeline_cycle_id_v1150') or '').strip()
            if cid:
                cycles[cid] += 1
        row_cycle = cycles.most_common(1)[0][0] if cycles else ''
        writer_cycle = str(scope.get('pipeline_cycle_id_v1150') or '').strip()
        writer_rows = int(scope.get('rows_written') or 0)
        writer_bytes = int(scope.get('output_bytes') or 0)
        same_rows = bool(rows and len(rows) == writer_rows)
        same_cycle = bool(row_cycle and writer_cycle and row_cycle == writer_cycle and len(cycles) == 1)
        size_exact = bool(after and writer_bytes > 0 and int(after.st_size) == writer_bytes)
        writer_exact = bool(
            writer.get('result') == 'OK'
            and scope.get('complete_snapshot') is True
            and scope.get('atomic_replace') is True
            and scope.get('pipeline_cycle_id_consistent_v1150') is True
            and same_rows and same_cycle and size_exact
        )
        result = {
            'candidate_path': candidate_path, 'rows': rows, 'read_errors': errors,
            'stable_read': stable, 'candidate_stat': after, 'writer_status': writer,
            'scope': scope, 'cycle_ids': cycles, 'row_cycle': row_cycle,
            'writer_cycle': writer_cycle,
            'writer_commit': str(scope.get('commit_id') or writer.get('candidate_last_commit_id_v1026') or '').strip(),
            'writer_rows': writer_rows, 'writer_bytes': writer_bytes,
            'same_rows': same_rows, 'same_cycle': same_cycle, 'writer_exact': writer_exact,
        }
        if stable and not errors and writer_exact:
            break
        time.sleep(0.06)
    return result


def _v1229_candidate_thresholds(rows: list[dict]) -> tuple[float, float, bool]:
    rr_values = set(); room_values = set()
    for row in rows:
        gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
        rr = _v1219_first_number(gate.get('minimum_risk_reward'))
        room = _v1219_first_number(gate.get('minimum_target_room_pct'))
        if rr is not None: rr_values.add(round(float(rr), 8))
        if room is not None: room_values.add(round(float(room), 8))
    rr = next(iter(rr_values)) if len(rr_values) == 1 else 1.50
    room = next(iter(room_values)) if len(room_values) == 1 else 1.20
    return float(rr), float(room), bool(len(rr_values) == 1 and len(room_values) == 1)



_V1232_REASON_KO = {
    'trigger_current_price_missing': '현재가격 없음',
    'trigger_entry_frames_insufficient': '진입봉 부족',
    'trigger_resistance_zone_absent': '진입 저항선 없음',
    'trigger_all_zones_far_below_after_breakout': '진입선이 이미 너무 아래',
    'trigger_selection_empty_other': '진입선 선택 기타',
    'paper_fee_source_missing_v1229': '수수료 자료 없음',
    'invalid_ceiling_missing': '손절선 기준가격 없음',
    'invalid_setup_frames_insufficient': '손절선용 봉 부족',
    'invalid_support_zone_absent': '실제 지지선 없음',
    'invalid_supports_inside_normal_noise': '지지선이 정상 흔들림 안쪽',
    'invalid_supports_beyond_max_risk': '지지선이 최대 손실범위 밖',
    'invalid_supports_not_below_entry_ceiling': '지지선이 진입선 아래가 아님',
    'invalid_selection_empty_other': '손절선 선택 기타',
    'target_selection_unavailable_without_trigger_v1225': '진입선 없어 목표선 계산 불가',
    'target_floor_missing': '목표선 기준가격 없음',
    'target_resistance_zone_absent': '실제 저항선 없음',
    'target_only_intermediate_resistance_v1225': '가까운 중간 저항만 있음',
    'target_resistance_beyond_dynamic_reach_v1225': '목표 저항이 도달범위 밖',
    'coherent_stop_profit_pair_absent_v1229': '손절선·목표선 짝 기준 미달',
    'complete': '완전계약',
}


def _v1232_positive_line(plan: dict, key: str) -> bool:
    line = plan.get(key) if isinstance(plan.get(key), dict) else {}
    return bool((_v1219_line_price(line) or 0.0) > 0.0)


def collect_pair_exclusion_audit_v1232() -> dict:
    """Explain why current coherent-pair candidates are excluded.

    Read-only.  It uses the exact committed candidate bytes and the diagnostic
    evidence already written by Strategy.  It does not recalculate a trading
    line or change a threshold, stage, OPEN, exit, ledger or auto-buy state.
    """
    exact = _v1229_exact_candidate_commit_scope()
    rows = exact['rows']
    stage_counts: Counter[str] = Counter()
    primary: Counter[str] = Counter()
    detail: Counter[str] = Counter()
    mode_counts: Counter[str] = Counter()
    samples: dict[str, list[dict]] = {}
    complete = excluded = check_required = normal_structure_exclusion = 0

    check_reason_codes = {
        'trigger_current_price_missing','trigger_entry_frames_insufficient',
        'trigger_selection_empty_other','paper_fee_source_missing_v1229',
        'invalid_ceiling_missing','invalid_setup_frames_insufficient',
        'invalid_selection_empty_other','target_floor_missing',
    }

    for row in rows:
        stage_counts[_v1214_stage(row)] += 1
        plan = _v1216_plan(row)
        diag = row.get('candidate_structure_diagnostic_v1218') if isinstance(row.get('candidate_structure_diagnostic_v1218'), dict) else {}
        if not diag and isinstance(plan.get('selection_diagnostics_v1216'), dict):
            diag = plan.get('selection_diagnostics_v1216') or {}
        pairing = plan.get('pairing_contract_v1229') if isinstance(plan.get('pairing_contract_v1229'), dict) else {}
        reasons = [str(x) for x in (diag.get('missing_reason_codes') or []) if str(x)]
        for reason in reasons:
            detail[reason] += 1
        mode = str(plan.get('target_mode_v1225') or plan.get('target_mode_v1212') or '').strip()
        if mode:
            mode_counts[mode] += 1

        has_trigger = _v1232_positive_line(plan, 'trigger')
        has_stop = _v1232_positive_line(plan, 'invalid')
        has_target = _v1232_positive_line(plan, 'target')
        if has_trigger and has_stop and has_target:
            complete += 1
            continue

        excluded += 1
        inv_n = int(pairing.get('invalid_candidates') or 0)
        tgt_n = int(pairing.get('target_candidates') or 0)
        combos = int(pairing.get('combinations') or 0)
        passing = int(pairing.get('passing') or 0)
        cost_complete = pairing.get('cost_complete') is True

        if not has_trigger or mode == 'trigger_price_missing_no_pair':
            bucket = '진입 기준선 없음'
        elif not cost_complete or 'paper_fee_source_missing_v1229' in reasons or mode == 'cost_source_missing_no_pair':
            bucket = '비용자료 없음'
        elif inv_n <= 0 and tgt_n <= 0:
            bucket = '손절선·목표선 둘 다 없음'
        elif inv_n <= 0:
            bucket = '쓸 수 있는 손절선 없음'
        elif tgt_n <= 0:
            if 'target_only_intermediate_resistance_v1225' in reasons:
                bucket = '가까운 중간 저항만 있음'
            elif 'target_resistance_beyond_dynamic_reach_v1225' in reasons:
                bucket = '목표선이 도달범위 밖'
            elif 'target_resistance_zone_absent' in reasons:
                bucket = '실제 목표 저항 없음'
            else:
                bucket = '쓸 수 있는 목표선 없음'
        elif combos > 0 and passing <= 0:
            bucket = '손해 대비 먹을 폭 부족'
        elif passing > 0 and not (has_stop and has_target):
            bucket = '통과 조합은 있으나 봉인 누락'
        else:
            bucket = '기타 조합 미완성'
        primary[bucket] += 1

        is_check = (not diag) or any(reason in check_reason_codes for reason in reasons) or bucket in {
            '비용자료 없음','통과 조합은 있으나 봉인 누락','기타 조합 미완성'
        }
        if is_check:
            check_required += 1
        else:
            normal_structure_exclusion += 1

        arr = samples.setdefault(bucket, [])
        if len(arr) < 3:
            arr.append({
                'ticker': str(row.get('ticker') or row.get('market') or row.get('symbol') or '-'),
                'stage': _v1214_stage(row), 'stop_candidates': inv_n,
                'target_candidates': tgt_n, 'combinations': combos,
                'passing': passing, 'reasons': reasons[:5],
            })

    source_ok = bool(exact['stable_read'] and not exact['read_errors'] and exact['same_rows'] and exact['same_cycle'] and exact['writer_exact'])
    verdict = 'PROVEN_PAIR_EXCLUSION_BREAKDOWN' if source_ok else 'CHECK_SOURCE_MISMATCH'
    report = {
        'schema':'pair_exclusion_exact_audit_v1232','version':'v1232','guard_version':VERSION,
        'created_ts':time.time(),'created_text':now(),'verdict':verdict,'read_only':True,
        'source':{
            'candidate_file':exact['candidate_path'].name,'candidate_rows':len(rows),
            'stable_read':exact['stable_read'],'read_errors':exact['read_errors'],
            'row_cycle_id':exact['row_cycle'] or None,'writer_cycle_id':exact['writer_cycle'] or None,
            'writer_commit_id':exact['writer_commit'] or None,'same_rows':exact['same_rows'],
            'same_cycle':exact['same_cycle'],'writer_exact':exact['writer_exact'],
        },
        'stage':{'total':len(rows),'s1':int(stage_counts.get('S1',0)),'s2':int(stage_counts.get('S2',0)),'s3':int(stage_counts.get('S3',0))},
        'summary':{'complete':complete,'excluded':excluded,'normal_structure_exclusion_like':normal_structure_exclusion,'check_required':check_required},
        'primary_reason_counts':dict(primary.most_common()),
        'detail_reason_counts':dict(detail.most_common()),
        'selection_mode_counts':dict(mode_counts.most_common()),
        'samples':samples,
        'policy':'same committed candidate bytes and Strategy-owned diagnostic evidence only; no independent line recalculation',
        'threshold_changed':False,'entry_flow_changed':False,'exit_changed':False,'existing_open_changed':False,'auto_buy':False,
    }
    write_json(BOT_DIR / PAIR_EXCLUSION_AUDIT_STATUS_V1232, report)
    return report


def gpair_exclusion_audit_text_v1232() -> str:
    try:
        report = collect_pair_exclusion_audit_v1232()
    except Exception as exc:
        return '\n'.join([
            '🧩 ❌ 제외 후보 원인감사 실패 /gpair_exclusion_audit',
            f'- {type(exc).__name__}: {exc}',
            '- 읽기 전용 · 후보기준·진입·청산·원장 변경 없음 / 자동매수 OFF',
        ])
    src = report.get('source') or {}; stage = report.get('stage') or {}; summary = report.get('summary') or {}
    reasons = report.get('primary_reason_counts') or {}; details = report.get('detail_reason_counts') or {}
    reason_text = ' / '.join(f'{k} {v}' for k,v in list(reasons.items())[:8]) or '-'
    detail_text = ' / '.join(f'{_V1232_REASON_KO.get(k,k)} {v}' for k,v in list(details.items())[:8]) or '-'
    return '\n'.join([
        f'🧩 제외 후보 원인감사 /gpair_exclusion_audit · {VERSION}',
        f"- 판정: {report.get('verdict')} · 새 조합 방식에서 제외된 후보를 이유별로 분리",
        f"- cycle: {src.get('row_cycle_id') or '-'} / commit {src.get('writer_commit_id') or '-'}",
        f"- 전체 {stage.get('total',0)} → 완전계약 {summary.get('complete',0)} / 제외 {summary.get('excluded',0)} / S1 {stage.get('s1',0)}",
        f"- 큰 원인: {reason_text}",
        f"- 세부 원인 TOP: {detail_text}",
        f"- 구조상 거래 제외로 볼 수 있는 쪽 {summary.get('normal_structure_exclusion_like',0)} / 자료·배관 추가확인 {summary.get('check_required',0)}",
        f"- 원문 연결: stable {src.get('stable_read')} / rows {src.get('same_rows')} / cycle {src.get('same_cycle')} / writer exact {src.get('writer_exact')}",
        '- 예전 v1216 감사의 선 누락 원인과, 현재 손절선×목표선 조합 실패를 같은 완료 후보에서 연결',
        '- 읽기 전용 · 기준완화·강제진입·진입흐름·청산·기존 OPEN 변경 0 · 자동매수 OFF',
    ])


def collect_entry_geometry_exact_audit_v1219() -> dict:
    """Read-only exact audit of the frozen entry geometry already used by Strategy.

    This command never creates or changes a trigger, invalid, target, threshold,
    rank, OPEN or exit.  It only separates incomplete contracts, invalid price
    ordering, trigger state, RR and target-room distributions on one committed
    candidate generation.
    """
    exact_scope = _v1229_exact_candidate_commit_scope()
    candidate_path = exact_scope['candidate_path']
    rows = exact_scope['rows']
    read_errors = exact_scope['read_errors']
    stable_read = bool(exact_scope['stable_read'])
    candidate_stat = exact_scope['candidate_stat']
    writer_status = exact_scope['writer_status']
    scope = exact_scope['scope']
    rr_threshold, room_threshold, thresholds_exact_v1229 = _v1229_candidate_thresholds(rows)

    cycle_ids: Counter[str] = Counter()
    stage_counts: Counter[str] = Counter()
    reason_counts: Counter[str] = Counter()
    target_modes: Counter[str] = Counter()
    trigger_tfs: Counter[str] = Counter(); invalid_tfs: Counter[str] = Counter(); target_tfs: Counter[str] = Counter()
    order_reasons: Counter[str] = Counter()
    incomplete_axes: Counter[str] = Counter()
    rr_buckets: Counter[str] = Counter(); room_buckets: Counter[str] = Counter(); risk_buckets: Counter[str] = Counter()

    all_gate_rr: list[float] = []
    all_gate_room: list[float] = []
    applicable_gate_rr_below = 0
    applicable_gate_room_below = 0
    valid_rr: list[float] = []
    valid_room: list[float] = []
    valid_risk: list[float] = []
    valid_cost: list[float] = []
    not_reached_gap: list[float] = []
    reached_overshoot: list[float] = []
    current_vs_frozen_trigger: list[float] = []
    current_vs_frozen_invalid: list[float] = []
    current_vs_frozen_target: list[float] = []

    complete_rows = 0
    order_valid_rows = 0
    order_invalid_rows = 0
    incomplete_rows = 0
    trigger_reached_rows = 0
    trigger_not_reached_rows = 0
    trigger_metric_not_reached_all = 0
    rr_below_valid = 0
    room_below_valid = 0
    both_below_valid = 0
    moved_any_rows = 0
    pairing_invalid_candidates = 0
    pairing_target_candidates = 0
    pairing_combinations = 0
    pairing_passing = 0
    pairing_major_passing = 0
    pairing_setup_passing = 0
    pairing_rows = 0
    s1_samples: list[dict] = []
    near_samples: list[dict] = []
    order_samples: list[dict] = []

    for row in rows:
        stage = _v1214_stage(row)
        stage_counts[stage] += 1
        cycle_id = str(row.get("candidate_pipeline_cycle_id_v1150") or "").strip()
        if cycle_id:
            cycle_ids[cycle_id] += 1
        reasons = _v1214_reason_list(row)
        for reason in reasons:
            reason_counts[reason] += 1

        gate = row.get("swing_entry_gate_v977") if isinstance(row.get("swing_entry_gate_v977"), dict) else {}
        plan = _v1216_plan(row)
        pairing = plan.get('pairing_contract_v1229') if isinstance(plan.get('pairing_contract_v1229'), dict) else {}
        if pairing:
            pairing_rows += 1
            pairing_invalid_candidates += int(pairing.get('invalid_candidates') or 0)
            pairing_target_candidates += int(pairing.get('target_candidates') or 0)
            pairing_combinations += int(pairing.get('combinations') or 0)
            pairing_passing += int(pairing.get('passing') or 0)
            pairing_major_passing += int(pairing.get('major_passing') or 0)
            pairing_setup_passing += int(pairing.get('setup_passing') or 0)
        price = _v1219_first_number(row.get("current_price"), row.get("price"), row.get("detected_price"), plan.get("current_price"))
        trigger = _v1219_first_number(gate.get("trigger_price"), row.get("trigger_price"), row.get("swing_trigger_price_v977"))
        invalid = _v1219_first_number(gate.get("invalid_price"), row.get("invalid_price"), row.get("swing_invalid_price_v977"))
        target = _v1219_first_number(gate.get("target_price"), row.get("target_price"), row.get("swing_target_price_v977"))
        gate_rr = _v1219_first_number(gate.get("risk_reward"), row.get("risk_reward"), row.get("risk_reward_ratio"))
        gate_room = _v1219_first_number(gate.get("target_room_pct"), row.get("target_room_pct"))
        if gate_rr is not None:
            all_gate_rr.append(gate_rr)
        if gate_room is not None:
            all_gate_room.append(gate_room)
        # Strategy appends RR/room reasons only when the legacy integrity block
        # is not active.  Compare the same scope instead of all rows.
        metric_reason_applicable = gate.get('structure_integrity_block_v1048') is not True
        if metric_reason_applicable and gate_rr is not None and gate_rr < rr_threshold:
            applicable_gate_rr_below += 1
        if metric_reason_applicable and gate_room is not None and gate_room < room_threshold:
            applicable_gate_room_below += 1
        if not (trigger is not None and trigger > 0 and price is not None and price > 0 and price >= trigger):
            trigger_metric_not_reached_all += 1

        missing = []
        if trigger is None or trigger <= 0: missing.append("trigger")
        if invalid is None or invalid <= 0: missing.append("invalid")
        if target is None or target <= 0: missing.append("target")
        if price is None or price <= 0: missing.append("price")
        if missing:
            incomplete_rows += 1
            incomplete_axes["+".join(sorted(missing))] += 1
            continue
        complete_rows += 1

        floor = min(price, trigger)
        local_order_reasons = []
        if invalid >= floor:
            local_order_reasons.append("invalid_not_below_current_or_trigger")
        if target <= trigger:
            local_order_reasons.append("target_not_above_trigger")
        if local_order_reasons:
            order_invalid_rows += 1
            for code in local_order_reasons:
                order_reasons[code] += 1
            if len(local_order_reasons) > 1:
                order_reasons["multiple_order_errors"] += 1
            if len(order_samples) < 6:
                order_samples.append({
                    "ticker": str(row.get("ticker") or row.get("market") or row.get("symbol") or "-"),
                    "stage": stage, "price": price, "trigger": trigger, "invalid": invalid, "target": target,
                    "reasons": local_order_reasons,
                })
            continue
        order_valid_rows += 1

        risk_pct = ((trigger - invalid) / trigger * 100.0) if trigger > 0 else None
        room_pct = ((target - trigger) / trigger * 100.0) if trigger > 0 else None
        rr = (room_pct / risk_pct) if risk_pct is not None and room_pct is not None and risk_pct > 0 else None
        if rr is not None:
            valid_rr.append(rr)
            if rr < 0.50: rr_buckets["<0.50"] += 1
            elif rr < 1.00: rr_buckets["0.50-0.99"] += 1
            elif rr < rr_threshold: rr_buckets[f"1.00-{rr_threshold:.2f}미만"] += 1
            else: rr_buckets[f">={rr_threshold:.2f}"] += 1
        if room_pct is not None:
            valid_room.append(room_pct)
            if room_pct < 0.50: room_buckets["<0.50%"] += 1
            elif room_pct < room_threshold: room_buckets[f"0.50-{room_threshold:.2f}%미만"] += 1
            elif room_pct < 2.00: room_buckets[f"{room_threshold:.2f}-1.99%"] += 1
            else: room_buckets[">=2.00%"] += 1
        if risk_pct is not None:
            valid_risk.append(risk_pct)
            if risk_pct < 1.20: risk_buckets["<1.20%"] += 1
            elif risk_pct < 3.00: risk_buckets["1.20-2.99%"] += 1
            elif risk_pct < 5.00: risk_buckets["3.00-4.99%"] += 1
            elif risk_pct <= 8.00: risk_buckets["5.00-8.00%"] += 1
            else: risk_buckets[">8.00%"] += 1

        rr_fail = rr is None or rr < rr_threshold
        room_fail = room_pct is None or room_pct < room_threshold
        rr_below_valid += int(rr_fail)
        room_below_valid += int(room_fail)
        both_below_valid += int(rr_fail and room_fail)

        reached = price >= trigger
        if reached:
            trigger_reached_rows += 1
            reached_overshoot.append((price - trigger) / trigger * 100.0)
        else:
            trigger_not_reached_rows += 1
            not_reached_gap.append((trigger - price) / price * 100.0)

        cost_inputs = plan.get("cost_inputs") if isinstance(plan.get("cost_inputs"), dict) else {}
        cost = _v1216_float(cost_inputs.get("estimated_roundtrip_cost_pct"))
        if cost is not None:
            valid_cost.append(cost)

        mode = str(plan.get("target_mode_v1212") or "UNKNOWN")
        target_modes[mode] += 1
        for obj, counter in ((plan.get("trigger"), trigger_tfs), (plan.get("invalid"), invalid_tfs), (plan.get("target"), target_tfs)):
            if isinstance(obj, dict):
                counter[str(obj.get("tf") or "UNKNOWN")] += 1

        cur_trigger = _v1219_line_price(plan.get("trigger"))
        cur_invalid = _v1219_line_price(plan.get("invalid"))
        cur_target = _v1219_line_price(plan.get("target"))
        mt = _v1219_move_pct(cur_trigger, trigger); mi = _v1219_move_pct(cur_invalid, invalid); mg = _v1219_move_pct(cur_target, target)
        if mt is not None: current_vs_frozen_trigger.append(mt)
        if mi is not None: current_vs_frozen_invalid.append(mi)
        if mg is not None: current_vs_frozen_target.append(mg)
        if any(x is not None and x > 0.0001 for x in (mt, mi, mg)):
            moved_any_rows += 1

        sample = {
            "ticker": str(row.get("ticker") or row.get("market") or row.get("symbol") or "-"),
            "stage": stage, "price": price, "trigger": trigger, "invalid": invalid, "target": target,
            "risk_pct": risk_pct, "target_room_pct": room_pct, "risk_reward": rr,
            "trigger_reached": reached, "reasons": reasons[:6],
        }
        if stage == "S1" and len(s1_samples) < 6:
            s1_samples.append(sample)
        if stage != "S1":
            near_samples.append(sample)

    near_samples.sort(key=lambda x: (-(x.get("risk_reward") or -1.0), -(x.get("target_room_pct") or -1.0)))
    near_samples = near_samples[:8]

    total = len(rows)
    writer_rows = int(exact_scope.get('writer_rows') or 0)
    writer_cycle = str(exact_scope.get('writer_cycle') or '')
    writer_commit = str(exact_scope.get('writer_commit') or '')
    row_cycle = str(exact_scope.get('row_cycle') or '')
    same_rows = bool(exact_scope.get('same_rows'))
    same_cycle = bool(exact_scope.get('same_cycle'))
    stage_accounted = sum(int(stage_counts.get(name, 0)) for name in ('S1','S2','S3'))
    same_stage = bool(total > 0 and stage_accounted == total)
    writer_exact = bool(exact_scope.get('writer_exact'))

    rr_reason_count = int(reason_counts.get("risk_reward_below_minimum", 0))
    room_reason_count = int(reason_counts.get("target_room_below_minimum", 0))
    order_reason_count = int(reason_counts.get("invalid_trigger_target_order_invalid", 0))
    trigger_reason_count = int(reason_counts.get("frozen_trigger_not_reached", 0))
    rr_metric_below_all = applicable_gate_rr_below
    room_metric_below_all = applicable_gate_room_below
    rr_balance = rr_reason_count == rr_metric_below_all
    room_balance = room_reason_count == room_metric_below_all
    order_balance = order_reason_count == order_invalid_rows
    trigger_balance = trigger_reason_count == trigger_metric_not_reached_all

    source_mismatch = bool(read_errors or not stable_read or not same_rows or not same_cycle or not same_stage or not writer_exact)
    metric_mismatch = not (rr_balance and room_balance and order_balance and trigger_balance)
    valid_n = max(1, order_valid_rows)
    rr_fail_rate = rr_below_valid / valid_n
    room_fail_rate = room_below_valid / valid_n
    order_conflict_rate = order_invalid_rows / max(1, complete_rows)
    if source_mismatch:
        verdict = "CHECK_SOURCE_MISMATCH"
        easy = "현재 완료 cycle 원문·Gate·writer 연결부터 다시 확인 필요"
    elif metric_mismatch:
        verdict = "CHECK_GATE_METRIC_MISMATCH"
        easy = "Gate 사유 건수와 실제 저장된 구조값 계산이 일치하지 않음"
    elif order_valid_rows <= 0:
        verdict = "PROVEN_NO_ORDER_VALID_CONTRACT"
        easy = "완전한 계약 중 가격 순서까지 정상인 후보가 없음"
    elif rr_fail_rate >= 0.90 and room_fail_rate >= 0.75:
        verdict = "PROVEN_SYSTEMIC_RR_AND_TARGET_ROOM_SHORTAGE"
        easy = "가격 순서가 정상인 후보 대부분도 위험 대비 목표공간이 함께 부족"
    elif rr_fail_rate >= 0.90:
        verdict = "PROVEN_SYSTEMIC_RR_SHORTAGE"
        easy = "가격 순서가 정상인 후보 대부분의 RR이 기준 미달"
    elif order_conflict_rate >= 0.25:
        verdict = "PROVEN_MIXED_ORDER_CONFLICT"
        easy = "가격 순서 충돌과 RR·목표공간 부족이 함께 존재"
    else:
        verdict = "PROVEN_MIXED_ENTRY_GEOMETRY"
        easy = "구조값은 연결됐고 후보별 거리·Trigger 상태 차이로 선별됨"

    report = {
        "schema": "entry_geometry_exact_audit_v1220", "version": "v1220", "guard_version": VERSION,
        "created_ts": time.time(), "created_text": now(), "verdict": verdict, "easy_verdict": easy,
        "read_only": True, "strategy_formula_changed": False, "threshold_changed": False,
        "entry_exit_changed": False, "auto_buy": False,
        "source": {
            "candidate_file": candidate_path.name, "candidate_rows": total,
            "candidate_size": candidate_stat.st_size if candidate_stat else None,
            "stable_read": stable_read, "read_errors": read_errors,
            "row_cycle_id": row_cycle or None, "writer_cycle_id": writer_cycle or None,
            "writer_commit_id": writer_commit or None, "same_rows": same_rows,
            "same_cycle": same_cycle, "same_stage": same_stage, "writer_exact_v1218": writer_exact,
            "thresholds_exact_v1229": thresholds_exact_v1229, "gate_status_commit_binding_removed_v1229": True,
        },
        "stage": {"total": total, "s1": int(stage_counts.get("S1", 0)), "s2": int(stage_counts.get("S2", 0)), "s3": int(stage_counts.get("S3", 0))},
        "scope_counts": {
            "incomplete": incomplete_rows, "complete": complete_rows,
            "order_valid": order_valid_rows, "order_invalid": order_invalid_rows,
            "trigger_reached": trigger_reached_rows, "trigger_not_reached": trigger_not_reached_rows,
        },
        "thresholds": {"minimum_risk_reward": rr_threshold, "minimum_target_room_pct": room_threshold},
        "reason_balance": {
            "rr_reason": rr_reason_count, "rr_metric_below": rr_metric_below_all, "rr_exact": rr_balance,
            "room_reason": room_reason_count, "room_metric_below": room_metric_below_all, "room_exact": room_balance,
            "order_reason": order_reason_count, "order_actual": order_invalid_rows, "order_exact": order_balance,
            "trigger_reason": trigger_reason_count, "trigger_actual": trigger_metric_not_reached_all, "trigger_exact": trigger_balance,
        },
        "valid_contract_failures": {
            "rr_below": rr_below_valid, "target_room_below": room_below_valid,
            "both_below": both_below_valid, "valid_count": order_valid_rows,
        },
        "pairing_v1229": {
            "rows": pairing_rows,
            "invalid_candidates": pairing_invalid_candidates,
            "target_candidates": pairing_target_candidates,
            "combinations": pairing_combinations,
            "passing": pairing_passing,
            "major_passing": pairing_major_passing,
            "setup_passing": pairing_setup_passing,
        },
        "distributions": {
            "strategy_gate_rr_all": _v1219_distribution(all_gate_rr),
            "strategy_gate_target_room_all_pct": _v1219_distribution(all_gate_room),
            "order_valid_rr": _v1219_distribution(valid_rr),
            "order_valid_risk_pct": _v1219_distribution(valid_risk),
            "order_valid_target_room_pct": _v1219_distribution(valid_room),
            "estimated_roundtrip_cost_pct": _v1219_distribution(valid_cost),
            "trigger_not_reached_gap_pct": _v1219_distribution(not_reached_gap),
            "trigger_reached_overshoot_pct": _v1219_distribution(reached_overshoot),
            "current_vs_frozen_trigger_move_pct": _v1219_distribution(current_vs_frozen_trigger),
            "current_vs_frozen_invalid_move_pct": _v1219_distribution(current_vs_frozen_invalid),
            "current_vs_frozen_target_move_pct": _v1219_distribution(current_vs_frozen_target),
        },
        "buckets": {"rr": dict(rr_buckets), "target_room": dict(room_buckets), "risk": dict(risk_buckets)},
        "incomplete_axes": dict(incomplete_axes.most_common()),
        "order_invalid_reasons": dict(order_reasons.most_common()),
        "target_modes": dict(target_modes.most_common()),
        "line_timeframes": {"trigger": dict(trigger_tfs.most_common()), "invalid": dict(invalid_tfs.most_common()), "target": dict(target_tfs.most_common())},
        "current_plan_moved_from_frozen_rows": moved_any_rows,
        "samples": {"s1": s1_samples, "near_pass": near_samples, "order_invalid": order_samples},
        "policy": "read Strategy frozen contract and same-cycle candidate rows only; no independent trading value write, threshold change, OPEN, exit or auto-buy mutation",
        "rr_note": "Strategy gate RR is price geometry reward/risk from frozen trigger-invalid-target; estimated roundtrip cost is shown separately and is not subtracted by this audit",
        "v1220_scope_note": "RR/target reason balance uses the same structure_integrity_block_v1048 applicability scope as Strategy",
    }
    write_json(BOT_DIR / ENTRY_GEOMETRY_AUDIT_STATUS_V1219, report)
    return report


def gentry_geometry_audit_text_v1219() -> str:
    try:
        report = collect_entry_geometry_exact_audit_v1219()
    except Exception as exc:
        return "\n".join([
            "🧮 ❌ 진입 구조값 정밀감사 실패 /gentry_geometry_audit",
            f"- {type(exc).__name__}: {exc}",
            "- 전략 기준·ATR·RR·진입·청산·원장 변경 없음 / 자동매수 OFF",
        ])
    src = report.get("source") or {}; stage = report.get("stage") or {}; scope = report.get("scope_counts") or {}
    thresholds = report.get("thresholds") or {}; failures = report.get("valid_contract_failures") or {}
    dist = report.get("distributions") or {}; balance = report.get("reason_balance") or {}
    rr = dist.get("order_valid_rr") or {}; risk = dist.get("order_valid_risk_pct") or {}; room = dist.get("order_valid_target_room_pct") or {}
    cost = dist.get("estimated_roundtrip_cost_pct") or {}; gap = dist.get("trigger_not_reached_gap_pct") or {}; over = dist.get("trigger_reached_overshoot_pct") or {}
    order = report.get("order_invalid_reasons") or {}; modes = report.get("target_modes") or {}; pairing = report.get("pairing_v1229") or {}
    s1 = ((report.get("samples") or {}).get("s1") or [])[:3]
    s1_text = " / ".join(f"{x.get('ticker')} RR {_v1219_fmt(x.get('risk_reward'),2)}·목표 {_v1219_fmt(x.get('target_room_pct'),2)}%" for x in s1) or "없음"
    return "\n".join([
        f"🧮 진입 구조값 정밀감사 /gentry_geometry_audit · {VERSION}",
        f"- 판정: {report.get('verdict')} · {report.get('easy_verdict')}",
        f"- cycle: {src.get('row_cycle_id') or '-'} / commit {src.get('writer_commit_id') or '-'}",
        f"- 전체 {stage.get('total',0)} → S1 {stage.get('s1',0)} / S2 {stage.get('s2',0)} / S3 {stage.get('s3',0)}",
        f"- 계산범위: 완전계약 {scope.get('complete',0)} / 가격순서 정상 {scope.get('order_valid',0)} / 불완전 {scope.get('incomplete',0)} / 순서오류 {scope.get('order_invalid',0)}",
        f"- RR 기준 {thresholds.get('minimum_risk_reward')}: 전체 Gate 미달 {balance.get('rr_reason',0)} / 정상계약 미달 {failures.get('rr_below',0)}/{failures.get('valid_count',0)}",
        f"- RR 분포(정상계약): p25 {_v1219_fmt(rr.get('p25'),2)} / 중앙 {_v1219_fmt(rr.get('median'),2)} / p75 {_v1219_fmt(rr.get('p75'),2)} / 최대 {_v1219_fmt(rr.get('max'),2)}",
        f"- 거리 분포: 손절 중앙 {_v1219_fmt(risk.get('median'),3)}% / 목표 중앙 {_v1219_fmt(room.get('median'),3)}% / 비용 중앙 {_v1219_fmt(cost.get('median'),3)}%",
        f"- 조합 비교: 손절선 후보 {pairing.get('invalid_candidates',0)} × 목표선 후보 {pairing.get('target_candidates',0)} → 전체 {pairing.get('combinations',0)} / 기준 통과 {pairing.get('passing',0)}",
        f"- 목표공간 기준 {thresholds.get('minimum_target_room_pct')}%: 전체 Gate 미달 {balance.get('room_reason',0)} / 정상계약 미달 {failures.get('target_room_below',0)}/{failures.get('valid_count',0)} / RR·목표 둘 다 {failures.get('both_below',0)}",
        f"- Trigger: 도달 {scope.get('trigger_reached',0)} / 미도달 {scope.get('trigger_not_reached',0)} · 미도달 거리 중앙 {_v1219_fmt(gap.get('median'),3)}% / 도달 후 초과 중앙 {_v1219_fmt(over.get('median'),3)}%",
        f"- 가격순서 오류: Invalid가 현재가·Trigger 아래 아님 {order.get('invalid_not_below_current_or_trigger',0)} / Target이 Trigger 위 아님 {order.get('target_not_above_trigger',0)}",
        f"- Target 방식: {modes}",
        f"- S1 예시: {s1_text}",
        f"- 사유·값 일치: RR {balance.get('rr_exact')} / 목표 {balance.get('room_exact')} / 순서 {balance.get('order_exact')} / Trigger {balance.get('trigger_exact')}",
        f"- 원문 연결: stable {src.get('stable_read')} / rows {src.get('same_rows')} / stage {src.get('same_stage')} / cycle {src.get('same_cycle')} / writer exact {src.get('writer_exact_v1218')}",
        "- RR은 Strategy가 실제 사용한 봉인 Trigger·Invalid·Target 가격비율이며 비용은 별도 표시",
        "- 읽기 전용 · 기준/ATR/RR/구조선식/순위/청산/OPEN 변경 0 · 자동매수 OFF",
    ])


# -----------------------------------------------------------------------------
# v1266 - read-only structure case audit for actual candidate quality review
# -----------------------------------------------------------------------------
STRUCTURE_CASE_AUDIT_STATUS_V1266 = "clean_structure_case_audit_v1266.json"


def _v1266_num(*values: Any, default: Optional[float] = None) -> Optional[float]:
    for value in values:
        try:
            if value in (None, "", [], {}):
                continue
            number = float(value)
            if math.isfinite(number):
                return number
        except Exception:
            continue
    return default


def _v1266_ticker(row: dict) -> str:
    return str(
        row.get('ticker') or row.get('market') or row.get('symbol')
        or row.get('coin') or row.get('code') or '-'
    ).strip() or '-'


def _v1266_contract_flag(row: dict) -> str:
    if isinstance(row.get('exit_contract_v1257'), dict) and row.get('exit_contract_v1257', {}).get('schema') == 'paper_unified_exit_contract_v1257':
        return '통합계약'
    if isinstance(row.get('unified_strategy_contract_v1257'), dict) and row.get('unified_strategy_contract_v1257', {}).get('schema') == 'unified_alt_swing_contract_v1257':
        return '통합계약'
    if str(row.get('unified_contract_state_v1257') or '') == 'LEGACY_CANDIDATE_CONTRACT_PRESERVED':
        return '계약전달유실'
    return '기타/적용전'


def _v1266_line(line: Any) -> dict:
    if not isinstance(line, dict):
        return {}
    return {
        'price': _v1219_line_price(line),
        'tf': str(line.get('tf') or line.get('timeframe') or '').strip() or None,
        'source': str(line.get('source') or line.get('role') or line.get('type') or '').strip() or None,
        'score': _v1266_num(line.get('zone_score'), line.get('score'), line.get('quality_score'), default=None),
        'raw': {k: line.get(k) for k in ('rounded_price','raw_price','price','tf','timeframe','source','role','zone_score','score') if line.get(k) not in (None,'',[],{})},
    }


def _v1266_fmt_price(value: Any) -> str:
    number = _v1266_num(value, default=None)
    if number is None:
        return '-'
    if abs(number) >= 1000:
        return f'{number:.2f}'
    if abs(number) >= 1:
        return f'{number:.6f}'.rstrip('0').rstrip('.')
    return f'{number:.10f}'.rstrip('0').rstrip('.')


def _v1266_plan_summary(row: dict) -> dict:
    gate = row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'), dict) else {}
    plan = _v1216_plan(row)
    diag = row.get('candidate_structure_diagnostic_v1218') if isinstance(row.get('candidate_structure_diagnostic_v1218'), dict) else {}
    if not diag and isinstance(plan.get('selection_diagnostics_v1216'), dict):
        diag = plan.get('selection_diagnostics_v1216') or {}
    pairing = plan.get('pairing_contract_v1229') if isinstance(plan.get('pairing_contract_v1229'), dict) else {}
    reasons = [str(x) for x in (diag.get('missing_reason_codes') or []) if str(x)]
    reasons_ko = [_V1232_REASON_KO.get(x, x) for x in reasons]
    trigger = _v1266_line(plan.get('trigger'))
    invalid = _v1266_line(plan.get('invalid'))
    target = _v1266_line(plan.get('target'))
    intermediate = plan.get('intermediate_resistance_v1225') if isinstance(plan.get('intermediate_resistance_v1225'), dict) else {}
    out = {
        'ticker': _v1266_ticker(row),
        'stage': _v1214_stage(row),
        'route': str(row.get('strategy_key') or row.get('paper_strategy_key') or row.get('route') or row.get('setup_type') or '').strip() or '-',
        'rank_score': _v1266_num(row.get('swing_quality_rank_score'), row.get('rank_score'), row.get('global_rank_score'), row.get('swing_quality_rank'), default=None),
        'current_price': _v1266_num(plan.get('current_price'), row.get('current_price'), row.get('price'), default=None),
        'trigger': trigger,
        'invalid': invalid,
        'target': target,
        'rr': _v1266_num(gate.get('risk_reward'), row.get('risk_reward'), plan.get('risk_reward'), plan.get('pairing_contract_v1229',{}).get('raw_rr') if isinstance(plan.get('pairing_contract_v1229'), dict) else None, default=None),
        'target_room_pct': _v1266_num(gate.get('target_room_pct'), row.get('target_room_pct'), plan.get('target_room_pct'), pairing.get('selected_room_pct'), default=None),
        'risk_pct': _v1266_num(plan.get('risk_pct'), pairing.get('selected_risk_pct'), row.get('invalid_distance_pct'), default=None),
        'normal_noise_pct': _v1266_num(plan.get('normal_noise_pct'), default=None),
        'maximum_risk_pct': _v1266_num(plan.get('maximum_risk_pct'), default=None),
        'target_reach_limit_pct': _v1266_num(plan.get('target_reach_limit_pct'), default=None),
        'chase_limit_pct': _v1266_num(plan.get('dynamic_chase_limit_pct'), default=None),
        'target_mode': str(plan.get('target_mode_v1225') or plan.get('target_mode_v1212') or pairing.get('selection_mode') or '').strip() or '-',
        'pairing': {
            'invalid_candidates': int(pairing.get('invalid_candidates') or 0),
            'target_candidates': int(pairing.get('target_candidates') or 0),
            'combinations': int(pairing.get('combinations') or 0),
            'passing': int(pairing.get('passing') or 0),
            'major_passing': int(pairing.get('major_passing') or 0),
            'setup_passing': int(pairing.get('setup_passing') or 0),
            'best_failed_rr': _v1266_num(pairing.get('best_failed_rr'), default=None),
        },
        'intermediate_resistance': _v1266_line(intermediate),
        'missing_reasons': reasons,
        'missing_reasons_ko': reasons_ko,
        'hard_reasons': _v1214_reason_list(row),
        'observation_only': _v1214_observation_flag(row),
        'quality': {
            'relative_strength': _v1266_num(row.get('relative_strength'), row.get('relative_strength_score'), row.get('rs_score'), default=None),
            'money_flow': _v1266_num(row.get('money_flow'), row.get('money_flow_score'), row.get('money_flow_index'), default=None),
            'price_reaction_pct': _v1266_num(row.get('price_reaction_pct'), row.get('price_reaction'), default=None),
            'vwap_gap_pct': _v1266_num(row.get('vwap_gap_pct'), row.get('vwap_distance_pct'), default=None),
            'ema5_gap_pct': _v1266_num(row.get('ema5_gap_pct'), row.get('ema5_distance_pct'), default=None),
            'volume_change_pct': _v1266_num(row.get('volume_change_pct'), row.get('volume_delta_pct'), default=None),
        },
    }
    return out


def _v1266_read_jsonl_tail(path: Path, max_bytes: int = 8 * 1024 * 1024) -> list[dict]:
    if not path.exists() or not path.is_file():
        return []
    try:
        size = path.stat().st_size
        with path.open('rb') as fh:
            if size > max_bytes:
                fh.seek(size - max_bytes)
                fh.readline()
            raw = fh.read()
    except Exception:
        return []
    rows = []
    for line in raw.decode('utf-8', errors='replace').splitlines():
        if not line.strip():
            continue
        try:
            obj = json.loads(line)
        except Exception:
            continue
        if isinstance(obj, dict):
            rows.append(obj)
    return rows


def _v1266_pnl(row: dict) -> Optional[float]:
    return _v1266_num(row.get('pnl_pct'), row.get('net_pnl_pct'), row.get('profit_pct'), row.get('realized_pnl_pct'), row.get('current_pnl_pct'), row.get('unrealized_pnl_pct'), default=None)


def _v1266_perf_case(row: dict) -> dict:
    pnl = _v1266_pnl(row)
    return {
        'ticker': _v1266_ticker(row),
        'contract': _v1266_contract_flag(row),
        'pnl_pct': pnl,
        'exit_reason': str(row.get('exit_reason') or row.get('reason') or row.get('closed_reason') or '').strip() or '-',
        'mfe_pct': _v1266_num(row.get('mfe_pct'), row.get('mfe_pct_v983'), row.get('peak_pct'), default=None),
        'mae_pct': _v1266_num(row.get('mae_pct'), row.get('mae_pct_v983'), row.get('trough_pct'), default=None),
        'giveback_pct': _v1266_num(row.get('giveback_pct'), row.get('giveback_pct_v983'), default=None),
        'entry_price': _v1266_num(row.get('entry_price'), row.get('open_price'), default=None),
        'trigger_price': _v1266_num(row.get('trigger_price'), row.get('swing_trigger_price_v977'), default=None),
        'invalid_price': _v1266_num(row.get('invalid_price'), row.get('swing_invalid_price_v977'), default=None),
        'target_price': _v1266_num(row.get('target_price'), row.get('swing_target_price_v977'), default=None),
        'decision_key': str(row.get('decision_key') or row.get('candidate_decision_key') or row.get('entry_decision_key') or '').strip() or '-',
    }


def collect_structure_case_audit_v1266() -> dict:
    exact = _v1229_exact_candidate_commit_scope()
    rows = [r for r in exact.get('rows') or [] if isinstance(r, dict)]
    stage_counts: Counter[str] = Counter(_v1214_stage(r) for r in rows)
    complete_cases = []
    empty_cases = []
    s1_cases = []
    for row in rows:
        case = _v1266_plan_summary(row)
        has_contract = bool(case.get('trigger',{}).get('price') and case.get('invalid',{}).get('price') and case.get('target',{}).get('price'))
        if has_contract:
            complete_cases.append(case)
            if case.get('stage') == 'S1':
                s1_cases.append(case)
        else:
            empty_cases.append(case)

    s1_cases.sort(key=lambda x: float(x.get('rank_score') or -999999.0), reverse=True)
    complete_cases.sort(key=lambda x: float(x.get('rank_score') or -999999.0), reverse=True)
    empty_cases.sort(key=lambda x: int((x.get('pairing') or {}).get('combinations') or 0), reverse=True)

    opened_raw = read_json(BOT_DIR / 'paper_bot_open.json') or {}
    open_rows = list(opened_raw.values()) if isinstance(opened_raw, dict) else ([x for x in opened_raw if isinstance(x, dict)] if isinstance(opened_raw, list) else [])
    open_cases = [_v1266_perf_case(r) for r in open_rows]
    unified_open = [c for c in open_cases if c.get('contract') == '통합계약']
    unified_open_losses = [c for c in unified_open if (c.get('pnl_pct') is not None and float(c.get('pnl_pct') or 0.0) < 0)]
    unified_open_losses.sort(key=lambda c: float(c.get('pnl_pct') or 0.0))

    closed_rows = _v1266_read_jsonl_tail(BOT_DIR / 'paper_bot_closed.jsonl')
    closed_cases = [_v1266_perf_case(r) for r in closed_rows]
    unified_closed = [c for c in closed_cases if c.get('contract') == '통합계약']
    unified_closed.sort(key=lambda c: float(c.get('pnl_pct') if c.get('pnl_pct') is not None else 999.0))
    unified_closed_losses = [c for c in unified_closed if (c.get('pnl_pct') is not None and float(c.get('pnl_pct') or 0.0) < 0)]

    source_ok = bool(exact.get('stable_read') and not exact.get('read_errors') and exact.get('same_rows') and exact.get('same_cycle') and exact.get('writer_exact'))
    verdict = 'CASE_AUDIT_READY' if source_ok else 'CHECK_SOURCE_MISMATCH'
    report = {
        'schema': 'structure_case_audit_v1266',
        'version': 'v1266',
        'guard_version': VERSION,
        'created_ts': time.time(),
        'created_text': now(),
        'verdict': verdict,
        'read_only': True,
        'strategy_changed': False,
        'threshold_changed': False,
        'entry_changed': False,
        'exit_changed': False,
        'ledger_mutated': False,
        'auto_buy': False,
        'source': {
            'candidate_file': str((exact.get('candidate_path') or Path('-')).name),
            'candidate_rows': len(rows),
            'row_cycle_id': exact.get('row_cycle'),
            'writer_cycle_id': exact.get('writer_cycle'),
            'writer_commit_id': exact.get('writer_commit'),
            'stable_read': exact.get('stable_read'),
            'same_rows': exact.get('same_rows'),
            'same_cycle': exact.get('same_cycle'),
            'writer_exact': exact.get('writer_exact'),
            'read_errors': exact.get('read_errors'),
        },
        'stage': {'total': len(rows), 's1': int(stage_counts.get('S1',0)), 's2': int(stage_counts.get('S2',0)), 's3': int(stage_counts.get('S3',0))},
        'counts': {
            'complete_contract': len(complete_cases),
            'empty_contract': len(empty_cases),
            's1_cases': len(s1_cases),
            'unified_open': len(unified_open),
            'unified_open_losses': len(unified_open_losses),
            'unified_closed_tail': len(unified_closed),
            'unified_closed_losses_tail': len(unified_closed_losses),
        },
        'cases': {
            's1_top': s1_cases[:12],
            'complete_top': complete_cases[:12],
            'empty_contract_samples': empty_cases[:12],
            'unified_closed_worst_tail': unified_closed[:12],
            'unified_open_worst': unified_open_losses[:12],
        },
        'purpose': 'Inspect whether selected trigger/invalid/target lines make sense before any strategy threshold or target/invalid formula change.',
        'next_decision': 'Use this report to label losses as trigger problem, invalid problem, target problem, or candidate-quality problem; do not loosen empty-contract filters first.',
    }
    write_json(BOT_DIR / STRUCTURE_CASE_AUDIT_STATUS_V1266, report)
    return report


def _v1266_case_line(case: dict) -> str:
    trig = case.get('trigger') or {}; inv = case.get('invalid') or {}; tgt = case.get('target') or {}; pair = case.get('pairing') or {}
    return (
        f"{case.get('ticker')} · {case.get('stage')} · 점수 {_v1219_fmt(case.get('rank_score'),1)} · "
        f"RR {_v1219_fmt(case.get('rr'),2)} · 목표 {_v1219_fmt(case.get('target_room_pct'),2)}% · 손절 {_v1219_fmt(case.get('risk_pct'),2)}% · "
        f"T/I/G {_v1266_fmt_price(trig.get('price'))}/{_v1266_fmt_price(inv.get('price'))}/{_v1266_fmt_price(tgt.get('price'))} · "
        f"tf {trig.get('tf') or '-'}/{inv.get('tf') or '-'}/{tgt.get('tf') or '-'} · "
        f"mode {case.get('target_mode') or '-'} · pair {pair.get('passing',0)}/{pair.get('combinations',0)}"
    )


def _v1266_empty_line(case: dict) -> str:
    pair = case.get('pairing') or {}; reasons = case.get('missing_reasons_ko') or []
    inter = (case.get('intermediate_resistance') or {}).get('price')
    return (
        f"{case.get('ticker')} · {case.get('stage')} · 손절후보 {pair.get('invalid_candidates',0)} / 목표후보 {pair.get('target_candidates',0)} / "
        f"조합 {pair.get('combinations',0)} / 통과 {pair.get('passing',0)} · bestRR {_v1219_fmt(pair.get('best_failed_rr'),2)} · "
        f"중간저항 {_v1266_fmt_price(inter)} · 이유 {', '.join(reasons[:3]) or '-'}"
    )


def _v1266_perf_line(case: dict) -> str:
    return (
        f"{case.get('ticker')} · {case.get('contract')} · 손익 {_v1219_fmt(case.get('pnl_pct'),3)}% · "
        f"MFE {_v1219_fmt(case.get('mfe_pct'),3)} / MAE {_v1219_fmt(case.get('mae_pct'),3)} / 반납 {_v1219_fmt(case.get('giveback_pct'),3)} · "
        f"청산 {case.get('exit_reason') or '-'} · 진입/손절/목표 {_v1266_fmt_price(case.get('entry_price'))}/{_v1266_fmt_price(case.get('invalid_price'))}/{_v1266_fmt_price(case.get('target_price'))}"
    )


def gstructure_case_audit_text_v1266() -> str:
    try:
        report = collect_structure_case_audit_v1266()
    except Exception as exc:
        return '\n'.join([
            '🧭 ❌ 구조선 케이스 감사 실패 /gstructure_case_audit',
            f'- {type(exc).__name__}: {exc}',
            '- 읽기 전용 · 구조선식·진입·청산·원장 변경 없음 / 자동매수 OFF',
        ])
    src = report.get('source') or {}; stage = report.get('stage') or {}; counts = report.get('counts') or {}; cases = report.get('cases') or {}
    s1_lines = [_v1266_case_line(x) for x in (cases.get('s1_top') or [])[:8]] or ['없음']
    closed_lines = [_v1266_perf_line(x) for x in (cases.get('unified_closed_worst_tail') or [])[:8]] or ['없음']
    open_lines = [_v1266_perf_line(x) for x in (cases.get('unified_open_worst') or [])[:8]] or ['없음']
    empty_lines = [_v1266_empty_line(x) for x in (cases.get('empty_contract_samples') or [])[:8]] or ['없음']
    return '\n'.join([
        f'🧭 구조선 케이스 감사 /gstructure_case_audit · {VERSION}',
        f"- 판정: {report.get('verdict')} · 읽기전용 구조선 실제 점검판",
        f"- cycle: {src.get('row_cycle_id') or '-'} / commit {src.get('writer_commit_id') or '-'}",
        f"- 전체 {stage.get('total',0)} → S1 {stage.get('s1',0)} / S2 {stage.get('s2',0)} / S3 {stage.get('s3',0)}",
        f"- 완전계약 {counts.get('complete_contract',0)} / 빈 계약 {counts.get('empty_contract',0)} / S1 케이스 {counts.get('s1_cases',0)}",
        f"- 통합계약 OPEN {counts.get('unified_open',0)} / OPEN 손실 {counts.get('unified_open_losses',0)} / CLOSED tail 통합 {counts.get('unified_closed_tail',0)} / 손실 {counts.get('unified_closed_losses_tail',0)}",
        '',
        '[1. 현재 S1 구조선 TOP]',
        *[f'- {line}' for line in s1_lines],
        '',
        '[2. 통합계약 CLOSED 손실/나쁜 순서]',
        *[f'- {line}' for line in closed_lines],
        '',
        '[3. 통합계약 OPEN 손실 큰 순서]',
        *[f'- {line}' for line in open_lines],
        '',
        '[4. 빈 계약 대표 케이스]',
        *[f'- {line}' for line in empty_lines],
        '',
        f"- 원문 연결: stable {src.get('stable_read')} / rows {src.get('same_rows')} / cycle {src.get('same_cycle')} / writer exact {src.get('writer_exact')}",
        '- 목적: trigger·invalid·target이 실제 차트 구조와 맞는지 손실 거래부터 확인하기 위함',
        '- 다음 판단: trigger 문제 / invalid 문제 / target 문제 / 후보품질 문제로 손실을 분류',
        '- 읽기 전용 · 기준완화·후보강제·진입·청산·OPEN/CLOSED 원장 변경 0 · 자동매수 OFF',
    ])


V1266_EXPECTED_ISSUE_EVENTS = (
    ('V1266-STRUCTURE-CASE-AUDIT', 'OPEN'),
    ('V1266-STRUCTURE-CASE-AUDIT', 'DONE_LOCAL'),
)
V1266_EXPECTED_CHANGE_EVENTS = (
    ('V1266-STRUCTURE-CASE-AUDIT', 'START'),
    ('V1266-STRUCTURE-CASE-AUDIT', 'LOCAL_VERIFY'),
)


def gledger_v1266_text() -> str:
    issue_path = BOT_DIR / 'issue_ledger.jsonl'
    change_path = BOT_DIR / 'change_verify_ledger.jsonl'
    issue_rows, issue_meta = _v1262_tail_json_objects(issue_path)
    change_rows, change_meta = _v1262_tail_json_objects(change_path)
    issue_events = {(str(row.get('issue_id') or '').strip(), str(row.get('event') or '').strip()) for row in issue_rows}
    change_events = {(str(row.get('change_id') or row.get('issue_id') or '').strip(), str(row.get('event') or '').strip()) for row in change_rows}
    missing_issue = [value for value in V1266_EXPECTED_ISSUE_EVENTS if value not in issue_events]
    missing_change = [value for value in V1266_EXPECTED_CHANGE_EVENTS if value not in change_events]
    state = 'DONE' if not missing_issue and not missing_change and issue_meta['bad_json_tail'] == 0 and change_meta['bad_json_tail'] == 0 else 'CHECK'
    lines = [
        f'📚 v1266 live 장부 append·fsync·tail 증거 · {VERSION}',
        f'- 상태: {state}',
        f"- issue tail: {len(issue_rows)}행 / 파일 {issue_meta['size']}B / bad JSON {issue_meta['bad_json_tail']}",
        f"- change tail: {len(change_rows)}행 / 파일 {change_meta['size']}B / bad JSON {change_meta['bad_json_tail']}",
        f'- issue 사건 확인: {len(V1266_EXPECTED_ISSUE_EVENTS)-len(missing_issue)}/{len(V1266_EXPECTED_ISSUE_EVENTS)}',
        f'- change 사건 확인: {len(V1266_EXPECTED_CHANGE_EVENTS)-len(missing_change)}/{len(V1266_EXPECTED_CHANGE_EVENTS)}',
        '- append writer 계약: flock → append → flush → os.fsync → unlock',
        '- 이 명령은 live 원장을 읽기만 하며 수정·재작성하지 않음',
    ]
    if missing_issue:
        lines.append('- issue tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_issue))
    if missing_change:
        lines.append('- change tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_change))
    lines.append('- DONE은 실제 live tail에서 모든 v1266 사건을 찾았을 때만 표시')
    return '\n'.join(lines)



V1267_EXPECTED_ISSUE_EVENTS = (
    ('V1267-ENTRY-QUALITY-MATERIAL', 'OPEN'),
    ('V1267-ENTRY-QUALITY-MATERIAL', 'DONE_LOCAL'),
)
V1267_EXPECTED_CHANGE_EVENTS = (
    ('V1267-ENTRY-QUALITY-MATERIAL', 'START'),
    ('V1267-ENTRY-QUALITY-MATERIAL', 'LOCAL_VERIFY'),
)


def gledger_v1267_text() -> str:
    issue_path = BOT_DIR / 'issue_ledger.jsonl'
    change_path = BOT_DIR / 'change_verify_ledger.jsonl'
    issue_rows, issue_meta = _v1262_tail_json_objects(issue_path)
    change_rows, change_meta = _v1262_tail_json_objects(change_path)
    issue_events = {(str(row.get('issue_id') or '').strip(), str(row.get('event') or row.get('status') or '').strip()) for row in issue_rows}
    change_events = {(str(row.get('change_id') or row.get('issue_id') or '').strip(), str(row.get('event') or row.get('status') or '').strip()) for row in change_rows}
    missing_issue = [value for value in V1267_EXPECTED_ISSUE_EVENTS if value not in issue_events]
    missing_change = [value for value in V1267_EXPECTED_CHANGE_EVENTS if value not in change_events]
    state = 'DONE' if not missing_issue and not missing_change and issue_meta['bad_json_tail'] == 0 and change_meta['bad_json_tail'] == 0 else 'CHECK'
    lines = [
        f'📚 v1267 live 장부 append·fsync·tail 증거 · {VERSION}',
        f'- 상태: {state}',
        f"- issue tail: {len(issue_rows)}행 / 파일 {issue_meta['size']}B / bad JSON {issue_meta['bad_json_tail']}",
        f"- change tail: {len(change_rows)}행 / 파일 {change_meta['size']}B / bad JSON {change_meta['bad_json_tail']}",
        f'- issue 사건 확인: {len(V1267_EXPECTED_ISSUE_EVENTS)-len(missing_issue)}/{len(V1267_EXPECTED_ISSUE_EVENTS)}',
        f'- change 사건 확인: {len(V1267_EXPECTED_CHANGE_EVENTS)-len(missing_change)}/{len(V1267_EXPECTED_CHANGE_EVENTS)}',
        '- 목적: 진입 품질 재료를 Strategy 계약 → Paper 최종 OPEN 직전 차단으로 연결했는지 장부 확인',
        '- append writer 계약: flock → append → flush → os.fsync → unlock',
        '- 이 명령은 live 원장을 읽기만 하며 수정·재작성하지 않음',
    ]
    if missing_issue:
        lines.append('- issue tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_issue))
    if missing_change:
        lines.append('- change tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_change))
    lines.append('- DONE은 실제 live tail에서 모든 v1267 사건을 찾았을 때만 표시')
    return '\n'.join(lines)




V1269_EXPECTED_ISSUE_EVENTS = (
    ('V1269-INVALID-LINE-BUFFERED-DISTANCE', 'OPEN'),
    ('V1269-INVALID-LINE-BUFFERED-DISTANCE', 'DONE_LOCAL'),
)
V1269_EXPECTED_CHANGE_EVENTS = (
    ('V1269-INVALID-LINE-BUFFERED-DISTANCE', 'START'),
    ('V1269-INVALID-LINE-BUFFERED-DISTANCE', 'LOCAL_VERIFY'),
)


def gledger_v1269_text() -> str:
    issue_path = BOT_DIR / 'issue_ledger.jsonl'
    change_path = BOT_DIR / 'change_verify_ledger.jsonl'
    issue_rows, issue_meta = _v1262_tail_json_objects(issue_path)
    change_rows, change_meta = _v1262_tail_json_objects(change_path)
    issue_events = {(str(row.get('issue_id') or '').strip(), str(row.get('event') or row.get('status') or '').strip()) for row in issue_rows}
    change_events = {(str(row.get('change_id') or row.get('issue_id') or '').strip(), str(row.get('event') or row.get('status') or '').strip()) for row in change_rows}
    missing_issue = [value for value in V1269_EXPECTED_ISSUE_EVENTS if value not in issue_events]
    missing_change = [value for value in V1269_EXPECTED_CHANGE_EVENTS if value not in change_events]
    state = 'DONE' if not missing_issue and not missing_change and issue_meta['bad_json_tail'] == 0 and change_meta['bad_json_tail'] == 0 else 'CHECK'
    lines = [
        f'📚 v1269 live 장부 append·fsync·tail 증거 · {VERSION}',
        f'- 상태: {state}',
        f"- issue tail: {len(issue_rows)}행 / 파일 {issue_meta['size']}B / bad JSON {issue_meta['bad_json_tail']}",
        f"- change tail: {len(change_rows)}행 / 파일 {change_meta['size']}B / bad JSON {change_meta['bad_json_tail']}",
        f'- issue 사건 확인: {len(V1269_EXPECTED_ISSUE_EVENTS)-len(missing_issue)}/{len(V1269_EXPECTED_ISSUE_EVENTS)}',
        f'- change 사건 확인: {len(V1269_EXPECTED_CHANGE_EVENTS)-len(missing_change)}/{len(V1269_EXPECTED_CHANGE_EVENTS)}',
        '- 목적: v1268 단순 T1 유지 + invalid 거리판정 buffered stop line live 장부 확인',
        '- append writer 계약: flock → append → flush → os.fsync → unlock',
        '- 이 명령은 live 원장을 읽기만 하며 수정·재작성하지 않음',
    ]
    if missing_issue:
        lines.append('- issue tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_issue))
    if missing_change:
        lines.append('- change tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_change))
    lines.append('- DONE은 실제 live tail에서 모든 v1269 사건을 찾았을 때만 표시')
    return '\n'.join(lines)


def collect_entry_flow_contract_audit_v1221() -> dict:
    """Prove that v1211 trigger-watch lifecycle still owns dynamic structures.

    Read-only: no threshold, candidate, OPEN, exit, ledger or auto-buy write.
    """
    exact_scope = _v1229_exact_candidate_commit_scope()
    candidate_path = exact_scope['candidate_path']
    paper_contract_path = BOT_DIR / PAPER_ACTIVE_CONTRACT_V1221
    rows = exact_scope['rows']
    read_errors = exact_scope['read_errors']
    stable_read = bool(exact_scope['stable_read'])
    candidate_stat = exact_scope['candidate_stat']
    writer_status = exact_scope['writer_status']
    scope = exact_scope['scope']
    paper_contract = read_json(paper_contract_path) or {}
    cycle_ids: Counter[str] = Counter()
    stage_counts: Counter[str] = Counter()
    flow_states: Counter[str] = Counter()
    trigger_watch_rows = 0
    trigger_reached_rows = 0
    s1_before_trigger = 0
    open_before_trigger = 0
    s1_after_trigger = 0
    s2_watch_rows = 0
    s3_watch_rows = 0
    target_not_above_trigger = 0
    flow_evidence_missing = 0
    unexpected_flow_state = 0
    samples: dict[str, list[dict]] = {"watch": [], "s1": [], "violation": []}
    allowed_states = {
        "STRUCTURE_CONTRACT_INCOMPLETE", "WATCHING_FROZEN_TRIGGER",
        "TRIGGER_REACHED_S1_READY", "TRIGGER_REACHED_HARD_BLOCK",
        "TRIGGER_REACHED_RECHECK",
    }
    for row in rows:
        if not isinstance(row, dict):
            continue
        cycle_id = str(row.get("candidate_pipeline_cycle_id_v1150") or "").strip()
        if cycle_id:
            cycle_ids[cycle_id] += 1
        stage = _v1214_stage(row)
        stage_counts[stage] += 1
        gate = row.get("swing_entry_gate_v977") if isinstance(row.get("swing_entry_gate_v977"), dict) else {}
        flow = row.get("entry_flow_contract_v1221") if isinstance(row.get("entry_flow_contract_v1221"), dict) else {}
        flow_state = str(row.get("entry_flow_state_v1221") or flow.get("current_state") or gate.get("entry_flow_state_v1221") or "").strip()
        if flow_state:
            flow_states[flow_state] += 1
            if flow_state not in allowed_states:
                unexpected_flow_state += 1
        else:
            flow_evidence_missing += 1
        trigger_reached = bool(row.get("trigger_reached") is True or gate.get("trigger_reached") is True or flow.get("trigger_reached") is True)
        open_eligible = bool(row.get("open_eligible") or row.get("paper_bot_open") or row.get("trade_ready") or gate.get("hard_pass") is True)
        trigger_price = _v1219_first_number(row.get("trigger_price"), row.get("swing_trigger_price_v977"), gate.get("trigger_price")) or 0.0
        invalid_price = _v1219_first_number(row.get("invalid_price"), row.get("swing_invalid_price_v977"), gate.get("invalid_price")) or 0.0
        target_price = _v1219_first_number(row.get("target_price"), row.get("swing_target_price_v977"), gate.get("target_price")) or 0.0
        price = _v1219_first_number(row.get("current_price"), row.get("price"), row.get("entry_price")) or 0.0
        complete = trigger_price > 0 and invalid_price > 0 and target_price > 0
        if complete and target_price <= trigger_price:
            target_not_above_trigger += 1
        if trigger_reached:
            trigger_reached_rows += 1
        elif complete:
            trigger_watch_rows += 1
        if stage == "S1" and not trigger_reached:
            s1_before_trigger += 1
        if open_eligible and not trigger_reached:
            open_before_trigger += 1
        if stage == "S1" and trigger_reached:
            s1_after_trigger += 1
        if complete and not trigger_reached and stage == "S2":
            s2_watch_rows += 1
        if complete and not trigger_reached and stage == "S3":
            s3_watch_rows += 1
        sample = {"ticker": row.get("ticker") or row.get("market"), "stage": stage, "price": price, "trigger": trigger_price, "invalid": invalid_price, "target": target_price, "flow_state": flow_state}
        if complete and not trigger_reached and len(samples["watch"]) < 4:
            samples["watch"].append(sample)
        if stage == "S1" and trigger_reached and len(samples["s1"]) < 4:
            samples["s1"].append(sample)
        if ((stage == "S1" or open_eligible) and not trigger_reached) and len(samples["violation"]) < 4:
            samples["violation"].append(sample)
    total = len(rows)
    writer_rows = int(exact_scope.get('writer_rows') or 0)
    writer_cycle = str(exact_scope.get('writer_cycle') or '')
    writer_commit = str(exact_scope.get('writer_commit') or '')
    row_cycle = str(exact_scope.get('row_cycle') or '')
    same_rows = bool(exact_scope.get('same_rows'))
    same_cycle = bool(exact_scope.get('same_cycle'))
    stage_accounted = sum(int(stage_counts.get(name,0)) for name in ('S1','S2','S3'))
    same_stage = bool(total > 0 and stage_accounted == total)
    writer_exact_v1229 = bool(exact_scope.get('writer_exact'))
    paper_integrity = paper_contract.get("integrity") if isinstance(paper_contract.get("integrity"), dict) else {}
    paper_entry = paper_contract.get("entry") if isinstance(paper_contract.get("entry"), dict) else {}
    paper_exact_s1 = paper_integrity.get("exact_s1") is True
    paper_entry_mode = str(paper_entry.get("entry_mode") or "")
    paper_s1_only = paper_exact_s1 and "Strategy exact S1" in paper_entry_mode
    source_ok = stable_read and not read_errors and same_rows and same_stage and same_cycle and writer_exact_v1229
    if not source_ok:
        verdict = "CHECK_SOURCE_MISMATCH"
        easy = "현재 완료 cycle 원문 연결부터 다시 확인 필요"
    elif s1_before_trigger or open_before_trigger or unexpected_flow_state:
        verdict = "FAIL_ENTRY_FLOW_BYPASS"
        easy = "Trigger 도달 전 S1·OPEN 또는 새 대기상태가 발견됨"
    elif target_not_above_trigger:
        verdict = "FAIL_TARGET_ORDER"
        easy = "롱 계약에서 Target이 Trigger 위가 아닌 후보가 남아 있음"
    elif flow_evidence_missing:
        verdict = "PARTIAL_FLOW_EVIDENCE"
        easy = "진입 흐름은 위반이 없지만 v1221 증거가 일부 후보에서 누락"
    elif not paper_s1_only:
        verdict = "FAIL_PAPER_S1_CONTRACT"
        easy = "Paper의 Strategy exact S1 전용 계약을 확인할 수 없음"
    else:
        verdict = "PROVEN_V1211_FLOW_PRESERVED"
        easy = "구조선 값만 동적으로 바뀌고 Trigger 감시→S1→Paper 즉시진입 흐름은 유지"
    report = {
        "schema":"entry_flow_contract_audit_v1221", "version":"v1221", "guard_version":VERSION,
        "created_ts":time.time(), "created_text":now(), "verdict":verdict, "easy_verdict":easy,
        "read_only":True, "strategy_threshold_changed":False, "entry_exit_changed":False, "auto_buy":False,
        "source":{
            "candidate_file":candidate_path.name, "candidate_rows":total, "candidate_size":candidate_stat.st_size if candidate_stat else None,
            "stable_read":stable_read, "read_errors":read_errors, "row_cycle_id":row_cycle or None,
            "writer_cycle_id":writer_cycle or None, "writer_commit_id":writer_commit or None,
            "same_rows":same_rows, "same_stage":same_stage, "same_cycle":same_cycle,
            "writer_exact_v1229":writer_exact_v1229, "gate_status_commit_binding_removed_v1229":True,
        },
        "stage":{"total":total, "s1":int(stage_counts.get("S1",0)), "s2":int(stage_counts.get("S2",0)), "s3":int(stage_counts.get("S3",0))},
        "flow":{
            "trigger_watch_complete_rows":trigger_watch_rows, "trigger_reached_rows":trigger_reached_rows,
            "s2_trigger_watch_rows":s2_watch_rows, "s3_trigger_watch_rows":s3_watch_rows,
            "s1_after_trigger":s1_after_trigger, "s1_before_trigger_violation":s1_before_trigger,
            "open_before_trigger_violation":open_before_trigger, "target_not_above_trigger":target_not_above_trigger,
            "flow_evidence_missing":flow_evidence_missing, "unexpected_flow_state":unexpected_flow_state,
            "states":dict(flow_states.most_common()),
        },
        "paper":{
            "contract_file":paper_contract_path.name, "version":paper_contract.get("version"),
            "exact_s1":paper_exact_s1, "entry_mode":paper_entry_mode or None, "strategy_exact_s1_only":paper_s1_only,
            "actual_entry_recheck":"Paper OPEN writer and actual_entry_evidence",
        },
        "samples":samples,
        "contract":{
            "baseline":"v1211_before_structure_change",
            "flow":"candidate plan freeze -> watch trigger -> trigger reached -> Strategy S1 -> Paper exact final recheck -> immediate OPEN",
            "changed_in_v1221":"dynamic structure Target uses actual resistance line; pre-capture offset removed from structural contract",
            "new_wait_state_added":False, "early_entry_allowed":False, "auto_buy":False,
        },
    }
    write_json(BOT_DIR / ENTRY_FLOW_AUDIT_STATUS_V1221, report)
    return report


def gentry_flow_audit_text_v1221() -> str:
    try:
        report = collect_entry_flow_contract_audit_v1221()
    except Exception as exc:
        return "\n".join([
            "🚦 ❌ 진입 흐름 계약감사 실패 /gentry_flow_audit",
            f"- {type(exc).__name__}: {exc}",
            "- 읽기 전용 · 구조선 수치·진입·청산·원장 변경 없음 / 자동매수 OFF",
        ])
    src = report.get("source") or {}; stage = report.get("stage") or {}; flow = report.get("flow") or {}; paper = report.get("paper") or {}
    return "\n".join([
        f"🚦 진입 흐름 계약감사 /gentry_flow_audit · {VERSION}",
        f"- 판정: {report.get('verdict')} · {report.get('easy_verdict')}",
        f"- cycle: {src.get('row_cycle_id') or '-'} / commit {src.get('writer_commit_id') or '-'}",
        f"- 전체 {stage.get('total',0)} → S1 {stage.get('s1',0)} / S2 {stage.get('s2',0)} / S3 {stage.get('s3',0)}",
        f"- Trigger 감시중 완전계약 {flow.get('trigger_watch_complete_rows',0)} / 도달 {flow.get('trigger_reached_rows',0)} / 감시중 S2 {flow.get('s2_trigger_watch_rows',0)}",
        f"- 위반: Trigger 전 S1 {flow.get('s1_before_trigger_violation',0)} / Trigger 전 OPEN가능 {flow.get('open_before_trigger_violation',0)} / Target≤Trigger {flow.get('target_not_above_trigger',0)} / 새 상태 {flow.get('unexpected_flow_state',0)}",
        f"- 흐름 상태: {flow.get('states') or {}}",
        f"- Paper: exact S1 {paper.get('exact_s1')} / Strategy S1 전용 {paper.get('strategy_exact_s1_only')} / 실제 진입가 최종검증 owner Paper",
        f"- 원문 연결: stable {src.get('stable_read')} / rows {src.get('same_rows')} / stage {src.get('same_stage')} / cycle {src.get('same_cycle')} / writer exact {src.get('writer_exact_v1229')}",
        "- 고정 흐름: 후보계약 생성 → Trigger 감시 → 도달 시 S1 → Paper 실제 진입가 최종검증 → 통과 즉시 OPEN",
        "- 읽기 전용 · 새 대기상태/조기진입 없음 · 청산/기존 OPEN/원장 변경 없음 · 자동매수 OFF",
    ])


def _v1222_shadow_line_price(shadow: dict, key: str) -> Optional[float]:
    return _v1219_line_price(shadow.get(key) if isinstance(shadow, dict) else None)


def collect_structure_pairing_compare_audit_v1222() -> dict:
    """Compare v1211 selection and current dynamic selection on one exact committed candidate snapshot.

    v1223 fixes the v1222 reader bug: the live writer publishes
    ``candidate_snapshot_scope`` (not ``current_scope``), and the Gate status is
    not commit-scoped.  Therefore this audit now binds the atomic candidate
    JSONL directly to the writer's committed scope and derives stage counts
    from those same rows.  It retries brief writer/candidate handoff races and
    never mixes a later Gate status into the comparison.

    Read-only: no trading line, threshold, stage, rank, OPEN or exit is changed.
    """
    candidate_path = BOT_DIR / S1_ZERO_AUDIT_CANDIDATES_V1214
    writer_path = BOT_DIR / S1_ZERO_AUDIT_WRITER_STATUS_V1214

    rows = []
    read_errors = []
    stable_read = False
    candidate_stat = None
    writer_status = {}
    scope = {}
    row_cycle = ''
    cycle_ids = Counter()
    writer_cycle = ''
    writer_commit = ''
    writer_rows = 0
    writer_bytes = 0
    same_rows = False
    same_cycle = False
    writer_exact = False

    # Candidate replace and writer-status commit are two consecutive atomic
    # writes. Retry a short bounded window so a command landing between them
    # does not report a false source mismatch.
    for _ in range(8):
        before = candidate_path.stat() if candidate_path.exists() else None
        trial_rows, trial_errors = _v1214_candidate_rows(candidate_path)
        after = candidate_path.stat() if candidate_path.exists() else None
        trial_stable = bool(before and after and before.st_ino == after.st_ino and before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns)
        trial_writer = read_json(writer_path) or {}
        trial_scope = trial_writer.get('candidate_snapshot_scope') if isinstance(trial_writer.get('candidate_snapshot_scope'), dict) else {}
        trial_cycles = Counter()
        for trial_row in trial_rows:
            cid = str(trial_row.get('candidate_pipeline_cycle_id_v1150') or '').strip()
            if cid:
                trial_cycles[cid] += 1
        trial_row_cycle = trial_cycles.most_common(1)[0][0] if trial_cycles else ''
        trial_writer_cycle = str(trial_scope.get('pipeline_cycle_id_v1150') or '').strip()
        trial_writer_rows = int(trial_scope.get('rows_written') or 0)
        trial_writer_bytes = int(trial_scope.get('output_bytes') or 0)
        trial_same_rows = bool(trial_rows and len(trial_rows) == trial_writer_rows)
        trial_same_cycle = bool(trial_row_cycle and trial_writer_cycle and trial_row_cycle == trial_writer_cycle and len(trial_cycles) == 1)
        trial_size_exact = bool(after and trial_writer_bytes > 0 and int(after.st_size) == trial_writer_bytes)
        trial_writer_exact = bool(
            trial_writer.get('result') == 'OK'
            and trial_scope.get('complete_snapshot') is True
            and trial_scope.get('atomic_replace') is True
            and trial_scope.get('pipeline_cycle_id_consistent_v1150') is True
            and trial_same_rows
            and trial_same_cycle
            and trial_size_exact
        )
        rows, read_errors, stable_read, candidate_stat = trial_rows, trial_errors, trial_stable, after
        writer_status, scope = trial_writer, trial_scope
        cycle_ids, row_cycle = trial_cycles, trial_row_cycle
        writer_cycle = trial_writer_cycle
        writer_commit = str(trial_scope.get('commit_id') or trial_writer.get('candidate_last_commit_id_v1026') or '').strip()
        writer_rows, writer_bytes = trial_writer_rows, trial_writer_bytes
        same_rows, same_cycle, writer_exact = trial_same_rows, trial_same_cycle, trial_writer_exact
        if trial_stable and not trial_errors and trial_writer_exact:
            break
        time.sleep(0.06)

    stage_counts = Counter()
    invalid_stage_rows = 0
    shadow_rows = shadow_exact = shadow_complete = 0
    current_complete = both_complete = 0
    old_rr = []; old_room = []; old_risk = []
    cur_rr = []; cur_room = []; cur_risk = []
    target_gap_delta = []; risk_delta = []; rr_delta = []
    target_source_old = Counter(); target_source_new = Counter()
    trigger_tf_old = Counter(); trigger_tf_new = Counter()
    invalid_tf_old = Counter(); invalid_tf_new = Counter()
    target_tf_old = Counter(); target_tf_new = Counter()
    collapse = Counter(); cost_spread = []; cost_slip = []; cost_fee = []; cost_total = []
    samples = []

    for row in rows:
        stage = _v1214_stage(row)
        stage_counts[stage] += 1
        if stage not in ('S1', 'S2', 'S3'):
            invalid_stage_rows += 1
        shadow = row.get('v1211_structure_shadow_v1222') if isinstance(row.get('v1211_structure_shadow_v1222'), dict) else {}
        if shadow:
            shadow_rows += 1
        if shadow.get('source_exact') is True:
            shadow_exact += 1
        if shadow.get('complete') is True:
            shadow_complete += 1
        plan = _v1216_plan(row)
        ot = _v1222_shadow_line_price(shadow, 'trigger')
        oi = _v1222_shadow_line_price(shadow, 'invalid')
        og = _v1222_shadow_line_price(shadow, 'target')
        nt = _v1219_line_price(plan.get('trigger'))
        ni = _v1219_line_price(plan.get('invalid'))
        ng = _v1219_line_price(plan.get('target'))
        old_ok = all(x is not None and x > 0 for x in (ot, oi, og)) and oi < ot < og
        new_ok = all(x is not None and x > 0 for x in (nt, ni, ng)) and ni < nt < ng
        if new_ok:
            current_complete += 1
        if not (old_ok and new_ok):
            continue
        both_complete += 1
        orisk = (ot - oi) / ot * 100.0
        oroom = (og - ot) / ot * 100.0
        orr = oroom / orisk if orisk > 0 else 0.0
        nrisk = (nt - ni) / nt * 100.0
        nroom = (ng - nt) / nt * 100.0
        nrr = nroom / nrisk if nrisk > 0 else 0.0
        old_risk.append(orisk); old_room.append(oroom); old_rr.append(orr)
        cur_risk.append(nrisk); cur_room.append(nroom); cur_rr.append(nrr)
        target_gap_delta.append(nroom - oroom); risk_delta.append(nrisk - orisk); rr_delta.append(nrr - orr)
        if nroom < oroom * 0.5:
            collapse['current_target_room_under_half_v1211'] += 1
        if nrisk > orisk * 1.5:
            collapse['current_risk_over_150pct_v1211'] += 1
        if nroom < oroom * 0.5 and nrisk > orisk * 1.5:
            collapse['both_target_shrunk_and_risk_expanded'] += 1
        if orr >= 1.5 and nrr < 1.5:
            collapse['v1211_pass_current_fail_rr'] += 1
        if oroom >= 1.2 and nroom < 1.2:
            collapse['v1211_pass_current_fail_room'] += 1
        old_target = shadow.get('target') if isinstance(shadow.get('target'), dict) else {}
        new_target = plan.get('target') if isinstance(plan.get('target'), dict) else {}
        target_source_old[str(old_target.get('role') or old_target.get('source_key') or 'UNKNOWN')] += 1
        target_source_new[str(plan.get('target_mode_v1212') or new_target.get('source_key') or 'UNKNOWN')] += 1
        for obj, counter in (
            (shadow.get('trigger'), trigger_tf_old), (plan.get('trigger'), trigger_tf_new),
            (shadow.get('invalid'), invalid_tf_old), (plan.get('invalid'), invalid_tf_new),
            (shadow.get('target'), target_tf_old), (plan.get('target'), target_tf_new),
        ):
            if isinstance(obj, dict):
                counter[str(obj.get('tf') or 'UNKNOWN')] += 1
        costs = plan.get('cost_inputs') if isinstance(plan.get('cost_inputs'), dict) else {}
        for value, bucket in (
            (costs.get('spread_pct'), cost_spread),
            (costs.get('slippage_pct'), cost_slip),
            (costs.get('fee_pct'), cost_fee),
            (costs.get('estimated_roundtrip_cost_pct'), cost_total),
        ):
            num = _v1216_float(value)
            if num is not None:
                bucket.append(num)
        if len(samples) < 8:
            samples.append({
                'ticker': row.get('ticker') or row.get('market'), 'stage': stage,
                'v1211': {'trigger': ot, 'invalid': oi, 'target': og, 'risk_pct': round(orisk, 4), 'room_pct': round(oroom, 4), 'rr': round(orr, 4), 'target_tf': old_target.get('tf')},
                'current': {'trigger': nt, 'invalid': ni, 'target': ng, 'risk_pct': round(nrisk, 4), 'room_pct': round(nroom, 4), 'rr': round(nrr, 4), 'target_tf': new_target.get('tf'), 'target_mode': plan.get('target_mode_v1212')},
            })

    total = len(rows)
    stage_accounted = sum(int(stage_counts.get(x, 0)) for x in ('S1', 'S2', 'S3'))
    same_stage = bool(total > 0 and invalid_stage_rows == 0 and stage_accounted == total)
    if read_errors or not stable_read or not writer_exact or not same_stage:
        verdict = 'CHECK_SOURCE_MISMATCH'
        easy = '현재 완료 candidate commit 원문 연결부터 다시 확인 필요'
    elif shadow_rows != total or shadow_exact != total:
        verdict = 'CHECK_WAIT_V1222_SHADOW_EVIDENCE'
        easy = 'v1211 비교용 exact 구조선 증거가 아직 모든 후보에 기록되지 않음'
    elif both_complete < 20:
        verdict = 'CHECK_INSUFFICIENT_COMPARABLE_ROWS'
        easy = '두 방식 모두 완전한 같은 후보 표본이 부족함'
    else:
        med_old_rr = _v1216_median(old_rr) or 0.0
        med_new_rr = _v1216_median(cur_rr) or 0.0
        med_old_room = _v1216_median(old_room) or 0.0
        med_new_room = _v1216_median(cur_room) or 0.0
        med_old_risk = _v1216_median(old_risk) or 0.0
        med_new_risk = _v1216_median(cur_risk) or 0.0
        if med_new_room < med_old_room * 0.5 and med_new_risk > med_old_risk * 1.2:
            verdict = 'PROVEN_PAIRING_TARGET_SHRINK_RISK_EXPAND'
            easy = '현재 조합은 v1211보다 목표는 크게 가까워지고 손절은 더 멀어져 RR이 무너짐'
        elif med_new_room < med_old_room * 0.5:
            verdict = 'PROVEN_TARGET_SELECTION_SHRINK'
            easy = '현재 Target 선택이 v1211보다 지나치게 가까워 RR을 줄임'
        elif med_new_risk > med_old_risk * 1.5:
            verdict = 'PROVEN_INVALID_DISTANCE_EXPANSION'
            easy = '현재 Invalid 선택이 v1211보다 지나치게 멀어 RR을 줄임'
        else:
            verdict = 'PROVEN_MIXED_PAIRING_DIFFERENCE'
            easy = '두 방식의 선 선택 차이는 확인됐고 단일 원인보다 혼합 영향'

    report = {
        'schema': 'v1211_dynamic_structure_pairing_compare_v1223_exact_scope',
        'version': 'v1223',
        'guard_version': VERSION,
        'created_ts': time.time(), 'created_text': now(),
        'verdict': verdict, 'easy_verdict': easy,
        'read_only': True, 'threshold_changed': False, 'entry_exit_changed': False, 'auto_buy': False,
        'source': {
            'candidate_file': candidate_path.name, 'candidate_rows': total,
            'candidate_file_bytes': int(candidate_stat.st_size) if candidate_stat else 0,
            'stable_read': stable_read, 'read_errors': read_errors,
            'row_cycle_id': row_cycle or None, 'writer_cycle_id': writer_cycle or None,
            'writer_commit_id': writer_commit or None,
            'writer_scope_schema': scope.get('schema'),
            'writer_rows': writer_rows, 'writer_output_bytes': writer_bytes,
            'same_rows': same_rows, 'same_stage': same_stage, 'same_cycle': same_cycle,
            'writer_exact_v1223': writer_exact, 'invalid_stage_rows': invalid_stage_rows,
            'shadow_rows': shadow_rows, 'shadow_exact_rows': shadow_exact,
            'gate_status_not_used_for_commit_binding_v1223': True,
            'source_fix_v1223': 'candidate_snapshot_scope + atomic file bytes + row stage self-accounting',
        },
        'stage': {'total': total, 's1': int(stage_counts.get('S1', 0)), 's2': int(stage_counts.get('S2', 0)), 's3': int(stage_counts.get('S3', 0))},
        'scope': {'v1211_complete': shadow_complete, 'current_complete': current_complete, 'both_complete': both_complete},
        'v1211': {'risk_pct': _v1219_distribution(old_risk), 'target_room_pct': _v1219_distribution(old_room), 'risk_reward': _v1219_distribution(old_rr), 'trigger_tf': dict(trigger_tf_old), 'invalid_tf': dict(invalid_tf_old), 'target_tf': dict(target_tf_old), 'target_source': dict(target_source_old)},
        'current': {'risk_pct': _v1219_distribution(cur_risk), 'target_room_pct': _v1219_distribution(cur_room), 'risk_reward': _v1219_distribution(cur_rr), 'trigger_tf': dict(trigger_tf_new), 'invalid_tf': dict(invalid_tf_new), 'target_tf': dict(target_tf_new), 'target_source': dict(target_source_new)},
        'difference': {'risk_pct_delta': _v1219_distribution(risk_delta), 'target_room_pct_delta': _v1219_distribution(target_gap_delta), 'risk_reward_delta': _v1219_distribution(rr_delta), 'collapse_counts': dict(collapse)},
        'cost': {'spread_pct': _v1219_distribution(cost_spread), 'one_way_slippage_pct': _v1219_distribution(cost_slip), 'roundtrip_fee_pct': _v1219_distribution(cost_fee), 'estimated_roundtrip_cost_pct': _v1219_distribution(cost_total)},
        'samples': samples,
        'contract': {
            'v1211': 'execution resistance trigger / nearest valid setup-or-major support / major resistance first, setup fallback',
            'current': 'dynamic repeated reaction zones / all usable stop-profit pairs / major target tier first / no synthetic line',
            'entry_flow_unchanged': True, 'ranking_unchanged': True,
            'strategy_threshold_changed': False, 'auto_buy': False,
        },
    }
    write_json(BOT_DIR / STRUCTURE_PAIRING_AUDIT_STATUS_V1222, report)
    return report

def gstructure_pairing_audit_text_v1222() -> str:
    try: report=collect_structure_pairing_compare_audit_v1222()
    except Exception as exc:
        return '\n'.join(['🧭 ❌ 구조선 조합 비교감사 실패 /gstructure_pairing_audit',f'- {type(exc).__name__}: {exc}','- 읽기 전용 · 구조선·RR·순위·진입·청산·원장 변경 없음 / 자동매수 OFF'])
    src=report.get('source') or {}; st=report.get('stage') or {}; scope=report.get('scope') or {}; old=report.get('v1211') or {}; cur=report.get('current') or {}; diff=report.get('difference') or {}; cost=report.get('cost') or {}
    def med(block,key):
        obj=block.get(key) if isinstance(block.get(key),dict) else {}; val=obj.get('median'); return '정보없음' if val is None else f'{float(val):.3f}'
    return '\n'.join([
        f'🧭 v1211↔현재 구조선 조합 비교 /gstructure_pairing_audit · {VERSION}',
        f"- 판정: {report.get('verdict')} · {report.get('easy_verdict')}",
        f"- cycle: {src.get('row_cycle_id') or '-'} / commit {src.get('writer_commit_id') or '-'}",
        f"- 전체 {st.get('total',0)} → S1 {st.get('s1',0)} / S2 {st.get('s2',0)} / S3 {st.get('s3',0)}",
        f"- 비교 가능: v1211 완전 {scope.get('v1211_complete',0)} / 현재 완전 {scope.get('current_complete',0)} / 같은 후보 양쪽 완전 {scope.get('both_complete',0)}",
        f"- v1211 중앙: 손절 {med(old,'risk_pct')}% / 목표 {med(old,'target_room_pct')}% / RR {med(old,'risk_reward')}",
        f"- 현재 중앙: 손절 {med(cur,'risk_pct')}% / 목표 {med(cur,'target_room_pct')}% / RR {med(cur,'risk_reward')}",
        f"- 영향 건수: {((diff.get('collapse_counts') or {}))}",
        f"- Target 방식: v1211 {old.get('target_source') or {}} / 현재 {cur.get('target_source') or {}}",
        f"- 비용 중앙: spread {med(cost,'spread_pct')}% / slippage(편도) {med(cost,'one_way_slippage_pct')}% / fee(왕복) {med(cost,'roundtrip_fee_pct')}% / 합계 {med(cost,'estimated_roundtrip_cost_pct')}%",
        f"- 원문 연결: stable {src.get('stable_read')} / rows {src.get('same_rows')} / stage {src.get('same_stage')} / cycle {src.get('same_cycle')} / writer exact {src.get('writer_exact_v1223')} / v1211 exact {src.get('shadow_exact_rows',0)}/{src.get('candidate_rows',0)}",
        '- 읽기 전용 · 진입 흐름·전체점수순·Runner 예약 제거 유지 · 기준/ATR/RR/청산/OPEN 변경 0 · 자동매수 OFF',
    ])

def help_text() -> str:
    return (
        "🛡 백가 가드봇 메뉴\n"
        "기본\n"
        "/guard - 가드 핵심 상태\n"
        "/gdeploy - 배포·버전 상태\n"
        "/gupgrade_menu - 업그레이드 메뉴\n"
        "/gmenu_sync - 텔레그램 하단 메뉴 강제 갱신\n"
        "/glog - 메인봇 최근 오류 로그\n"
        "/gpaperlog - 페이퍼봇 최근 로그\n\n"
        "업그레이드\n"
        "1) /gupgrade - 전체 최신화: 가드 → 메인 → 페이퍼 → WS → micro\n"
        "2) /gupgrade_main - 메인봇만 최신 적용\n"
        "3) /gupgrade_paper - 페이퍼봇만 최신 적용\n"
        "4) /gupgrade_ws - WS 직원만 최신 적용\n"
        "5) /gupgrade_micro - micro 직원만 최신 적용\n"
        "6) /gupgrade_guard - 가드봇만 최신 적용\n"
        "- 원칙: 같은 적용 본선 사용, hash 동일이면 재시작 생략\n\n"
        "복구/재시작\n"
        "/grestart - 메인봇 재시작\n"
        "/gpaper_restart - 페이퍼봇 재시작\n"
        "/gpaper_reset - 페이퍼 실행연결 재설치\n"
        "/gpaper_service - 페이퍼봇 서비스화 안내\n"
        "/gexternal_state - 외부직원 통합상태\n"
        "/gcore_v2_verify - 새 CORE 전체 흐름·명령·중복정의 검증\n"
        "/gcore_v2_cutover - 최신 PASS 후 새 CORE 일괄전환\n"
        "/gcore_v2_closeout - 전환 후 runtime·hash·exact·장부 최종 마감\n"
        "/gexport_profitability - 수익성 감사 원장 단일 ZIP 텔레그램 전송(읽기전용)\n"
        "/gledger_v1262 - v1261/v1262 pending 사건 live append·tail 검증(읽기전용)\n"
        "/gs1_zero_audit - S1 0 원인·강한 차단 전수감사(읽기전용)\n"
        "/gstructure_missing_audit - 동적 구조선 빈 계약 원인 정밀감사(읽기전용)\n"
        "/gentry_geometry_audit - RR·목표공간·가격순서·Trigger 정밀감사(읽기전용)\n"
        "/gentry_flow_audit - v1211 Trigger 감시→S1→Paper 진입 흐름 계약감사(읽기전용)\n"
        "/gstructure_pairing_audit - v1211 구조선과 현재 동적 구조선 같은 후보 비교(읽기전용)\n"
        "/gpair_exclusion_audit - 새 조합에서 제외된 후보 원인 분리(읽기전용)\n"
        "/gdeep_audit - 작업자 지연·디스크 증가 원인 통합감사(읽기전용)\n"
        "/gstorage_fix - 승인된 로그상한·archive·trace 정리\n"
        "/gopen_policy_v1264 - OPEN 50·generation 5 계약 검수\n"
        "/gcontract_v1265 - 통합계약 S1 전달·OPEN 봉인 검수\n"
        "/gledger_v1265 - v1265 live 장부 tail 검증\n"
        "/gstructure_case_audit - 손실·S1·빈계약 구조선 케이스 감사(읽기전용)\n"
        "/gledger_v1266 - v1266 live 장부 tail 검증(읽기전용)\n"
        "/gledger_v1267 - v1267 live 장부 tail 검증(읽기전용)\n"
        "/gledger_v1268 - v1269 live 장부 tail 검증(읽기전용)\n"
        "/gcleanup - 디스크 순환정리\n"
        "/gws_state - 웹소켓 직원 상태\n"
        "/gws_start - 웹소켓 직원 시작\n"
        "/gws_stop - 웹소켓 직원 중지\n"
        "/gws_restart - 웹소켓 직원 재시작\n"
        "/gmicro_state - 빗썸 호가·체결 직원 상태\n"
        "/gmicro_restart - 빗썸 호가·체결 직원 재시작\n"
        "/gbackups - 메인봇 백업 목록\n"
        "/grollback - 메인봇 최신 백업 롤백\n"
        "/gunlock - 배포 lock 삭제\n\n"
        "가드봇 자체\n"
        "/gguard_restart - 가드봇 재시작\n\n"
        "운영법: 전체가 필요하면 /gupgrade, 파일 하나만 바뀌었으면 위 개별 업그레이드 사용.\n"
        "주의: 전략/조건/청산은 건드리지 않고 파일 교체와 재시작만 관리"
    )

def guard_command_menu_items() -> list[dict]:
    """Telegram 하단 메뉴에 등록할 명령 목록.

    v2.5.37: 사용자가 실제로 자주 누르는 업그레이드 명령을 맨 위에 둔다.
    alias 명령(gws_upgrade/gmicro_upgrade 등)은 handler에는 남기되 메뉴에는 중복 노출하지 않는다.
    """
    return [
        {"command": "gupgrade", "description": "1 전체 최신화"},
        {"command": "gupgrade_main", "description": "2 메인봇만 최신 적용"},
        {"command": "gupgrade_paper", "description": "3 페이퍼봇만 최신 적용"},
        {"command": "gupgrade_ws", "description": "4 WS 직원만 최신 적용"},
        {"command": "gupgrade_micro", "description": "5 micro 직원만 최신 적용"},
        {"command": "gupgrade_guard", "description": "6 가드봇만 최신 적용"},
        {"command": "gupgrade_bundle", "description": "한 번으로 전체 적용·재시작·검수"},
        {"command": "gops_refresh", "description": "통합 운영 지도 완성판 갱신"},
        {"command": "gexport_profitability", "description": "수익성 감사 원장 단일 ZIP 받기"},
        {"command": "gs1_zero_audit", "description": "S1 0 원인·탈락사유 전수감사"},
        {"command": "gstructure_missing_audit", "description": "동적 구조선 빈 계약 원인 정밀감사"},
        {"command": "gentry_geometry_audit", "description": "RR·목표공간·가격순서 정밀감사"},
        {"command": "gentry_flow_audit", "description": "Trigger 감시→S1→Paper 흐름감사"},
        {"command": "gstructure_pairing_audit", "description": "v1211↔현재 구조선 조합 비교"},
        {"command": "gpair_exclusion_audit", "description": "제외 후보 원인 정확히 분리"},
        {"command": "gpaper_performance_fix_v1092", "description": "Paper 증분 성과 writer·메모리 검수"},
        {"command": "gquality_open_audit_v1093", "description": "승률 코드원인·후보품질·OPEN 통합감사"},
        {"command": "gquality_spine_verify", "description": "Feature→Strategy 품질 전달·runtime 검수"},
        {"command": "gcore_shadow", "description": "CORE V2 전체 생명주기 Shadow"},
        {"command": "grelease_verify", "description": "현재 릴리스 통합검수"},
        {"command": "gledger_v1262", "description": "v1262 live 장부 tail 확인"},
        {"command": "grelease_last", "description": "최근 자동 배포 최종결과"},
        {"command": "gworker_upgrade", "description": "10 worker 최신 적용"},
        {"command": "gworker_state", "description": "worker 통합상태"},
        {"command": "gexact_replay", "description": "Paper exact 재생기"},
        {"command": "gpolicy_matchup", "description": "7개 정책 경쟁 worker"},
        {"command": "gdeep_audit", "description": "작업자·디스크 원인 통합감사"},
        {"command": "gresource_owner", "description": "핵심 worker 자원 owner 정밀감사"},
        {"command": "gstrategy_writer_v1077", "description": "Strategy writer 경량화 검수"},
        {"command": "gstrategy_overlay_v1078", "description": "Strategy Candle overlay 검수"},
        {"command": "ghotpath_v1079", "description": "Strategy·Paper·Review 통합병목 검수"},
        {"command": "gdisk_bound_v1080", "description": "비핵심 trace 고정상한 검수"},
        {"command": "gfinal_owner_v1081", "description": "Paper 메모리·Risk·주변 owner 최종검수"},
        {"command": "gsystem_closeout_v1082", "description": "Paper compact 메타·Risk 분리 cache·시스템 최종마감"},
        {"command": "gpaper_memory_owner_v1083", "description": "Paper v1083 구 측정결과"},
        {"command": "gpaper_allocator_v1084", "description": "Paper allocator·exact exit 메모리 특정"},
        {"command": "gsystem_closeout_v1086", "description": "전체 runtime·writer·reader·메모리 최종마감"},
        {"command": "gcore_v2_closeout", "description": "CORE V2 전환 최종 마감"},
        {"command": "gstorage_fix", "description": "저장공간·지연 원인수술"},
        {"command": "gopen_policy_v1264", "description": "OPEN 50·cycle 5 검수"},
        {"command": "gcontract_v1265", "description": "통합계약 전달·봉인 검수"},
        {"command": "gledger_v1265", "description": "v1265 live 장부 확인"},
        {"command": "gstructure_case_audit", "description": "구조선 케이스 감사"},
        {"command": "gledger_v1266", "description": "v1266 live 장부 확인"},
        {"command": "gledger_v1267", "description": "v1267 live 장부 확인"},
        {"command": "gledger_v1268", "description": "v1269 live 장부 확인"},
        {"command": "gupgrade_menu", "description": "업그레이드 메뉴"},
        {"command": "guard", "description": "가드 핵심 상태"},
        {"command": "gdeploy", "description": "배포·버전 상태"},
        {"command": "gpaper_state", "description": "페이퍼봇 상태"},
        {"command": "gexternal_state", "description": "외부직원 통합상태"},
        {"command": "gworker_restart", "description": "worker 재시작"},
        {"command": "glog", "description": "메인봇 로그"},
        {"command": "gpaperlog", "description": "페이퍼봇 로그"},
        {"command": "grestart", "description": "메인봇 재시작"},
        {"command": "gpaper_restart", "description": "페이퍼봇 재시작"},
        {"command": "gpaper_reset", "description": "페이퍼 실행연결 재설치"},
        {"command": "gws_state", "description": "웹소켓 직원 상태"},
        {"command": "gws_restart", "description": "웹소켓 직원 재시작"},
        {"command": "gmicro_state", "description": "호가·체결 직원 상태"},
        {"command": "gmicro_restart", "description": "호가·체결 직원 재시작"},
        {"command": "gcleanup", "description": "디스크 순환정리"},
        {"command": "gbackups", "description": "백업 목록"},
        {"command": "gmenu_sync", "description": "텔레그램 메뉴 갱신"},
        {"command": "gmenu", "description": "가드 메뉴"},
    ]

def set_commands() -> dict:
    commands = guard_command_menu_items()
    # Telegram Bot API는 commands를 JSON 배열 문자열로 받는다.
    # 반환값을 남겨 /gmenu_sync에서 실제 성공/실패를 확인할 수 있게 한다.
    return api("setMyCommands", {"commands": json.dumps(commands, ensure_ascii=False)}, timeout=15)

def sync_guard_menu_text() -> str:
    try:
        res = set_commands()
        ok = bool(res.get("ok")) if isinstance(res, dict) else False
        if ok:
            return (
                "✅ 텔레그램 메뉴 갱신 완료 /gmenu_sync\n"
                f"- guard: {VERSION}\n"
                "- 메뉴 순서: 전체 → 메인 → 페이퍼 → WS → micro → 가드\n"
                "- aliases는 계속 사용 가능하지만 메뉴에는 중복 노출하지 않음\n"
                "- 앱 하단 메뉴가 바로 안 바뀌면 채팅방을 나갔다가 다시 열거나 텔레그램을 재시작해줘."
            )
        return f"❌ 텔레그램 메뉴 갱신 실패 /gmenu_sync\n- 응답: {res}"
    except Exception as e:
        return f"❌ 텔레그램 메뉴 갱신 실패 /gmenu_sync\n- {type(e).__name__}: {e}"

def _extract_guard_command_lines(text: str) -> list[str]:
    return [ln.strip() for ln in str(text or "").splitlines() if ln.strip().startswith("/")]

def _guard_command_name(line: str) -> str:
    first = line.strip().split()[0].lower() if line.strip().split() else ""
    if "@" in first:
        first = first.split("@", 1)[0]
    return first

_BUNDLE_UPGRADE_COMMANDS_V1030 = {
    "/gupgrade_bundle", "/gbundle", "/gapply_bundle",
    "/gupgrade", "/gupgrade_all", "/apply_latest", "/upgradebot",
}

def _normalize_post_upgrade_commands_v1030(commands) -> list[str]:
    out: list[str] = []
    for raw in commands or []:
        line = str(raw or "").strip()
        if not line or not line.startswith("/"):
            continue
        name = _guard_command_name(line)
        if name in _BUNDLE_UPGRADE_COMMANDS_V1030 or name in {"/gguard_restart", "/guard_restart"}:
            continue
        if len(line) > 500:
            line = line[:500]
        out.append(line)
        if len(out) >= 12:
            break
    return out

def _execute_guard_commands_once_v1030(commands, title: str = "업그레이드 후 이어실행") -> tuple[bool, str]:
    lines = _normalize_post_upgrade_commands_v1030(commands)
    if not lines:
        return True, f"📦 {title} 없음"
    rendered = [f"📦 {title}", f"- 명령 {len(lines)}개 / 원래 순서 / 각 1회", "- 재시도·반복·중첩 업그레이드 없음"]
    all_ok = True
    for idx, line in enumerate(lines, start=1):
        name = _guard_command_name(line)
        try:
            body = handle_single_command(line)
            ok = "❌" not in str(body) and not str(body).startswith("오류:") and not str(body).startswith("알 수 없는")
        except Exception as exc:
            ok = False
            body = f"오류: {exc.__class__.__name__}: {exc}"
        all_ok = all_ok and ok
        rendered.append(f"\n[{idx}/{len(lines)}] {name}\n{body}")
    return all_ok, "\n".join(rendered)

def parse_upgrade_force_explicit(args: list[str]) -> tuple[bool, Optional[str]]:
    """개별 업그레이드 명령 공통 인자 파서.

    v2.5.62: /gupgrade_bundle nofetch coinbot_update_v###.zip 처럼
    nofetch/local 뒤에 zip 파일명을 적어도 explicit으로 인식한다.
    """
    args = [str(a).strip() for a in (args or []) if str(a).strip()]
    lowered = [a.lower() for a in args]
    force = bool(lowered and lowered[0] == "force")
    explicit = None
    scan = args[1:] if force else args
    for a in scan:
        low = a.lower()
        if low in {"force", "nofetch", "local", "skipgit", "skip_git", "fallback", "localfallback", "local_fallback"}:
            continue
        if low.endswith((".py", ".zip")):
            explicit = a
            break
    return force, explicit

def gupgrade_menu_text() -> str:
    """v2.5.36: 전체/개별 업그레이드 메뉴."""
    return "\n".join([
        "🛠 업그레이드 메뉴 /gupgrade_menu",
        "- 기본은 전체, 급할 때는 바뀐 코드만 개별 적용",
        "- 모든 개별 명령도 기존 단일 적용 함수 사용: hash 동일이면 재시작 생략",
        "",
        "[1] 전체",
        "/gupgrade - 가드 → worker → 메인 → 페이퍼 → WS → micro 전체 확인/적용",
        "",
        "[2] 메인봇",
        "/gupgrade_main - 수익형_v*.py만 적용",
        "",
        "[3] 페이퍼봇",
        "/gupgrade_paper - paper_bot_v*.py만 적용",
        "",
        "[4] WS 직원",
        "/gupgrade_ws - ws_sidecar_v*.py만 적용",
        "",
        "[5] micro 직원",
        "/gupgrade_micro - bithumb_micro_sidecar_v*.py만 적용",
        "",
        "[6] 가드봇",
        "/gupgrade_guard - backga_guard_bot_v*.py만 적용",
        "",
        "예시",
        "- /gupgrade_paper",
        "- /gupgrade_main force 수익형_v2.13.253.py",
        "- /gworker_upgrade",
    ])

def _bundle_version_key(path: Path) -> tuple:
    m = re.search(r"coinbot_update_v(\d+)", path.name)
    return (int(m.group(1)) if m else -1, path.name)

def find_latest_bundle_file(explicit: Optional[str] = None) -> Optional[Path]:
    if explicit:
        p = BOT_DIR / explicit
        return p if p.exists() else None
    files = sorted(BOT_DIR.glob("coinbot_update_v*.zip"), key=_bundle_version_key)
    return files[-1] if files else None

def _bundle_manifest_defaults(bundle_dir: Path) -> dict:
    # DEPLOY_BUNDLE.json이 없을 때도 파일명으로 최대한 복구. 단 정식 bundle은 manifest를 포함한다.
    def latest(pat: str) -> str:
        xs = sorted(bundle_dir.glob(pat), key=lambda p: p.name)
        return xs[-1].name if xs else ""
    def latest_main() -> str:
        xs = []
        for pat in ("수익형_v*.py", "coinbot_main_v*.py"):
            for p in bundle_dir.glob(pat):
                ver = BotVersion.parse(p.name)
                if ver:
                    xs.append((ver, p.name))
        return sorted(xs, key=lambda x: x[0])[-1][1] if xs else ""
    return {
        "main": latest_main(),
        "guard": latest("backga_guard_bot_v*.py"),
        "paper": latest("paper_bot_v*.py"),
        "workers": {
            "scanner": latest("scanner_worker_v*.py"),
            "candle": latest("candle_worker_v*.py"),
            "market": latest("market_regime_worker_v*.py"),
            "feature": latest("feature_worker_v*.py"),
            "orderflow": latest("orderflow_worker_v*.py"),
            "target_router": latest("target_router_worker_v*.py"),
            "risk": latest("risk_worker_v*.py"),
            "strategy": latest("strategy_worker_v*.py"),
            "review": latest("review_worker_v*.py"),
        },
    }

def _normalize_bundle_manifest(manifest: dict, bundle_dir: Path) -> dict:
    """Normalize every supported bundle schema to the single deploy contract.

    v1238 closes a fail-open gap found in the v1237 package: the package used a
    nested ``runtime_files`` map while the active deploy path only consumed the
    top-level ``main/paper/guard/workers`` fields.  That mismatch could copy no
    runtime target and still verify the old runtime.  The normalized result is
    now the only object consumed by copy/apply/verify.
    """
    if not isinstance(manifest, dict):
        return manifest
    m = dict(manifest)

    runtime_files = m.get("runtime_files") if isinstance(m.get("runtime_files"), dict) else {}
    for key in ("main", "paper", "guard", "ws", "micro", "ws_sidecar", "micro_sidecar"):
        value = runtime_files.get(key)
        if not m.get(key) and isinstance(value, str) and value.strip() and (bundle_dir / value.strip()).exists():
            m[key] = value.strip()
    workers = dict(m.get("workers")) if isinstance(m.get("workers"), dict) else {}
    for key in WORKER_SPECS:
        value = runtime_files.get(key)
        if not workers.get(key) and isinstance(value, str) and value.strip() and (bundle_dir / value.strip()).exists():
            workers[key] = value.strip()
    if workers:
        m["workers"] = workers

    def is_main_py(name: str) -> bool:
        value = str(name or "").strip()
        return value.endswith(".py") and (value.startswith("coinbot_main_v") or value.startswith("수익형_v"))
    if not m.get("main"):
        target = m.get("target") or m.get("deploy_target") or m.get("main_file")
        if isinstance(target, str) and is_main_py(target) and (bundle_dir / target).exists():
            m["main"] = target
        else:
            files = m.get("files")
            if isinstance(files, list):
                cands = [str(x).strip() for x in files if isinstance(x, str) and is_main_py(str(x)) and (bundle_dir / str(x)).exists()]
                if cands:
                    def key(name: str):
                        bv = BotVersion.parse(name)
                        return (bv.major, bv.minor, bv.patch, name) if bv else (-1, -1, -1, name)
                    m["main"] = sorted(cands, key=key)[-1]
    return m

def _copy_bundle_files_to_repo(bundle_dir: Path, manifest: dict) -> list[str]:
    """Copy declared runtime components and support files.

    v1067 adds an explicit support_files contract so a clean package can be
    deployed without pretending every module is a worker. Paths are relative,
    must stay inside the extracted bundle, and are copied recursively with their
    directory structure preserved.
    """
    notes=[]
    names=[]
    for key in ["main", "guard", "paper", "ws", "micro", "ws_sidecar", "micro_sidecar"]:
        v = manifest.get(key)
        if isinstance(v, str) and v:
            names.append(v)
    workers = manifest.get("workers") if isinstance(manifest.get("workers"), dict) else {}
    for v in workers.values():
        if isinstance(v, str) and v:
            names.append(v)
    support = manifest.get("support_files") if isinstance(manifest.get("support_files"), list) else []
    for value in support:
        if not isinstance(value,str) or not value.strip():
            continue
        rel=Path(value.strip())
        if rel.is_absolute() or '..' in rel.parts:
            notes.append(f"invalid support path: {value}")
            continue
        src=bundle_dir/rel
        if not src.exists() or not src.is_file():
            notes.append(f"missing support file: {value}")
            continue
        dst=BOT_DIR/rel
        dst.parent.mkdir(parents=True,exist_ok=True)
        if dst.exists() and short_hash(dst)==short_hash(src):
            notes.append(f"same support {value}")
        else:
            shutil.copy2(src,dst)
            notes.append(f"copy support {value}")
    for name in sorted(set(names)):
        src = bundle_dir / name
        if not src.exists():
            notes.append(f"missing in bundle: {name}")
            continue
        dst = BOT_DIR / name
        if dst.exists() and short_hash(dst) == short_hash(src):
            notes.append(f"same {name}")
        else:
            shutil.copy2(src, dst)
            notes.append(f"copy {name}")
    main = manifest.get("main")
    if main:
        (BOT_DIR / "DEPLOY_TARGET.txt").write_text(str(main).strip()+"\n", encoding="utf-8")
        notes.append(f"DEPLOY_TARGET.txt -> {main}")
    return notes

def _bundle_num_from_name(name: str) -> int:
    m = re.search(r"coinbot_update_v(\d+)", str(name or ""))
    return int(m.group(1)) if m else -1

def _last_success_bundle_name() -> str:
    st = read_json(BOT_DIR / UPGRADE_STATUS_FILE)
    if isinstance(st, dict):
        b = st.get("bundle") or st.get("target_bundle") or ""
        if isinstance(b, str):
            return b.strip()
    return ""

def _github_repo_from_origin() -> tuple[str, str]:
    """Return (owner/repo, note) for the configured origin."""
    rc, out = run(["git", "config", "--get", "remote.origin.url"], cwd=BOT_DIR, timeout=8)
    raw = (out or "").strip().splitlines()[0].strip() if out else ""
    if not raw:
        raw = "https://github.com/dangdang971216-code/coin-bot.git"
    s = raw
    if s.startswith("git@github.com:"):
        s = "https://github.com/" + s.split(":", 1)[1]
    s = s.replace("git://github.com/", "https://github.com/")
    m = re.search(r"github\.com[:/]+([^/]+)/([^/]+?)(?:\.git)?/?$", s)
    if not m:
        return "dangdang971216-code/coin-bot", f"origin parse failed: {raw or '-'} → default"
    return f"{m.group(1)}/{m.group(2)}", f"origin={raw}"

def _http_json(url: str, timeout: int = 20):
    req = urllib.request.Request(url, headers={"User-Agent": "backga-guard-bot"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
    return json.loads(raw.decode("utf-8", errors="replace"))

def _download_url_to_path(url: str, dest: Path, timeout: int = 90) -> tuple[bool, str]:
    tmp = dest.with_name(f".{dest.name}.download.{os.getpid()}.{time.time_ns()}")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "backga-guard-bot"})
        with urllib.request.urlopen(req, timeout=timeout) as resp, tmp.open("wb") as f:
            shutil.copyfileobj(resp, f)
            f.flush()
            os.fsync(f.fileno())
        if tmp.stat().st_size <= 0:
            return False, "downloaded file is empty"
        new_digest = sha256_file(tmp)
        if dest.exists():
            try:
                if sha256_file(dest) == new_digest:
                    return True, f"same digest reuse {dest.name} / {dest.stat().st_size} bytes"
            except Exception:
                pass
        os.replace(tmp, dest)
        return True, f"downloaded {dest.name} / {dest.stat().st_size} bytes / sha256 {new_digest[:12]}"
    except Exception as exc:
        return False, f"{exc.__class__.__name__}: {exc}"
    finally:
        try:
            tmp.unlink(missing_ok=True)
        except Exception:
            pass

def _prune_update_bundle_cache_v1030(protect_name: str = "", keep: int = 3) -> dict:
    """Keep only the newest local release ZIPs after a successful apply.

    Git history and live ledgers are untouched. The bundle currently being applied
    is always protected until the post-restart continuation has completed.
    """
    protect = Path(str(protect_name or "")).name
    rows = []
    for path in BOT_DIR.glob("coinbot_update_v*.zip"):
        try:
            rows.append((_bundle_num_from_name(path.name), path.stat().st_mtime, path))
        except Exception:
            continue
    rows.sort(key=lambda x: (x[0], x[1], x[2].name), reverse=True)
    keep_names = {p.name for _, _, p in rows[:max(1, int(keep or 3))]}
    if protect:
        keep_names.add(protect)
    deleted = 0
    freed = 0
    errors = []
    for _, _, path in rows:
        if path.name in keep_names:
            continue
        try:
            size = path.stat().st_size
            path.unlink()
            deleted += 1
            freed += size
        except Exception as exc:
            errors.append(f"{path.name}:{exc.__class__.__name__}")
    return {
        "schema": "guard_bundle_cache_retention_v1030",
        "keep": sorted(keep_names),
        "deleted": deleted,
        "freed_bytes": freed,
        "errors": errors[:10],
    }

def _github_direct_download_latest_bundle(explicit: Optional[str] = None) -> tuple[bool, list[str]]:
    """v2.5.64: /gupgrade_bundle must not depend on full git fetch.

    Old desired flow is kept from the user's side: upload coinbot_update_v###.zip to GitHub,
    then run /gupgrade_bundle. Internally we read the single zip file from GitHub contents API
    instead of fetching/resetting the whole repository.
    """
    notes: list[str] = []
    repo, repo_note = _github_repo_from_origin()
    notes.append(repo_note)
    api = f"https://api.github.com/repos/{repo}/contents?ref={urllib.parse.quote(GIT_BRANCH)}"
    try:
        items = _http_json(api, timeout=25)
    except Exception as exc:
        notes.append(f"github contents api failed: {exc.__class__.__name__}: {exc}")
        return False, notes
    if not isinstance(items, list):
        notes.append("github contents api returned non-list")
        return False, notes
    candidates = []
    for it in items:
        if not isinstance(it, dict):
            continue
        name = str(it.get("name") or "")
        if not re.fullmatch(r"coinbot_update_v\d+\.zip", name):
            continue
        if explicit and name != explicit:
            continue
        num = _bundle_num_from_name(name)
        candidates.append((num, name, it.get("download_url") or ""))
    if not candidates:
        notes.append(f"github bundle not found: {explicit or 'coinbot_update_v*.zip'}")
        return False, notes
    candidates.sort(reverse=True)
    num, name, download_url = candidates[0]
    if not download_url:
        notes.append(f"download_url missing: {name}")
        return False, notes
    dest = BOT_DIR / name
    ok, msg = _download_url_to_path(download_url, dest, timeout=120)
    notes.append(msg)
    if not ok:
        return False, notes
    return True, [f"github direct bundle={name}"] + notes

def _core_v2_stage_release_verify_v1071(manifest: dict) -> str:
    support = manifest.get('support_files') if isinstance(manifest.get('support_files'), list) else []
    missing=[]; compile_fail=[]
    for rel in support:
        if not isinstance(rel,str) or not rel.strip():
            continue
        path=BOT_DIR/rel
        if not path.exists():
            missing.append(rel); continue
        if rel.endswith('.py'):
            okc,out=py_compile(path)
            if not okc: compile_fail.append(f'{rel}: {tail(out,300)}')
    guard_expected=str(manifest.get('guard') or '')
    guard_target=BOT_DIR/guard_expected if guard_expected else None
    guard_ok=bool(guard_target and guard_target.exists() and extract_assignment(guard_target,'VERSION')==VERSION)
    required=['core_v2_verify_v1071.py','risk_worker_v0.11.py','strategy_worker_v0.992.py','paper_bot_v0.999.py','review_worker_v0.995.py','coinbot_main_v2_13_1071.py']
    required_missing=[x for x in required if not (BOT_DIR/x).exists()]
    ok=bool(not missing and not required_missing and not compile_fail and guard_ok)
    lines=[
      f"{'✅' if ok else '⚠️'} CORE V2 v1072 배포대상 동기화 정정 스테이징 {'PASS' if ok else 'CHECK'}",
      f"- guard: expected={extract_assignment(guard_target,'VERSION') if guard_target and guard_target.exists() else '-'} / actual={VERSION}",
      f"- support files: {len(support)-len(missing)}/{len(support)}",
      f"- required exact-spine files: {len(required)-len(required_missing)}/{len(required)}",
      f"- py_compile 실패: {len(compile_fail)}",
      '- 라이브 Strategy·Risk·Paper·Review·Main 미전환',
      '- v1067 간이 구조/S1 재계산은 active 경로에서 폐기',
      '- 원장·전략수치·자동매수 변경 0',
      '- 다음: /gcore_v2_verify',
    ]
    if missing: lines.append('- support 누락: '+', '.join(missing[:20]))
    if required_missing: lines.append('- 필수 누락: '+', '.join(required_missing[:20]))
    if compile_fail: lines.extend('- '+x for x in compile_fail[:10])
    return '\n'.join(lines)


def _retire_services_v1257(service_names: Any) -> tuple[bool, list[str]]:
    names=[str(x).strip() for x in (service_names or []) if str(x).strip()]
    notes=[]; ok=True
    allowed={'tradingbot-policy-competition-worker','tradingbot-structure-rebuild-worker'}
    for name in names:
        if name not in allowed:
            ok=False; notes.append(f'{name}: REJECT_NOT_APPROVED')
            continue
        rc_stop,out_stop=run(['systemctl','stop',name],timeout=30)
        rc_disable,out_disable=run(['systemctl','disable',name],timeout=30)
        active=is_service_active(name)
        item_ok=str(active) not in {'active','activating'}
        ok=ok and item_ok
        notes.append(f'{name}: stop_rc={rc_stop} disable_rc={rc_disable} state={active} preserved_files=True')
    return ok,notes


def _verify_retired_services_v1257(service_names: Any) -> tuple[bool,list[str]]:
    names=[str(x).strip() for x in (service_names or []) if str(x).strip()]
    rows=[]; ok=True
    for name in names:
        active=is_service_active(name)
        item_ok=str(active) not in {'active','activating'}
        ok=ok and item_ok
        rows.append(f'{name}: {active} / inactive_required={item_ok}')
    return ok,rows


def _v1260_last_release_manifest() -> tuple[dict, str]:
    """Read the exact manifest from the last applied local bundle.

    A manual /grelease_verify previously received no manifest and therefore
    printed every changed component as SKIP.  The release result already owns
    the exact bundle name and digest, so reuse that evidence instead of guessing
    from the latest filename.
    """
    result=read_json(_release_result_path()) or {}
    bundle_name=Path(str(result.get('bundle') or '')).name
    if not bundle_name:
        return {}, 'none'
    bundle_path=BOT_DIR/bundle_name
    if not bundle_path.exists():
        return {}, f'last_bundle_missing:{bundle_name}'
    try:
        with zipfile.ZipFile(bundle_path,'r') as zf:
            raw=json.loads(zf.read('DEPLOY_BUNDLE.json').decode('utf-8'))
        if isinstance(raw,dict):
            return raw, f'last_release_bundle:{bundle_name}'
    except Exception as exc:
        return {}, f'last_bundle_manifest_error:{type(exc).__name__}'
    return {}, f'last_bundle_manifest_invalid:{bundle_name}'


def _v1260_strategy_release_health(expected_version: str='', expected_build: str='', wait_sec: float=0.0) -> dict:
    """Prove a new Strategy generation, not merely a running process.

    Required evidence: service/PID/hash/status health, writer result OK, exact
    writer version/build, a non-empty candidate commit, and the same NORMAL
    cycle/commit in the canonical pipeline file.  This is read-only and never
    changes candidates, contracts or ledgers.
    """
    deadline=time.monotonic()+max(0.0,float(wait_sec or 0.0))
    last={}
    while True:
        worker=worker_state_dict('strategy')
        status=worker.get('raw') if isinstance(worker.get('raw'),dict) else {}
        writer=read_json(BOT_DIR/'clean_strategy_paper_latest_writer_status.json') or {}
        pipeline=read_json(BOT_DIR/'strategy_candidate_pipeline_commit_v1150.json') or {}
        scope=writer.get('candidate_snapshot_scope') if isinstance(writer.get('candidate_snapshot_scope'),dict) else {}
        status_error=str(status.get('error') or status.get('last_error') or '').strip()
        writer_error=str(writer.get('error') or '').strip()
        nowv=time.time()
        writer_ts=float(writer.get('updated_ts') or 0.0)
        pipeline_ts=float(pipeline.get('updated_ts') or 0.0)
        writer_age=(nowv-writer_ts) if writer_ts>0 else 999999.0
        pipeline_age=(nowv-pipeline_ts) if pipeline_ts>0 else 999999.0
        writer_cycle=str(scope.get('pipeline_cycle_id_v1150') or '')
        writer_commit=str(scope.get('commit_id') or writer.get('candidate_commit_id_v1026') or '')
        pipeline_cycle=str(pipeline.get('cycle_id') or '')
        pipeline_commit=str(pipeline.get('candidate_commit_id') or '')
        actual_version=str(status.get('version') or worker.get('active_version') or '')
        actual_build=str(status.get('build') or '')
        try:
            service_pid=int(worker.get('pid') or 0)
            status_pid=int(status.get('pid') or 0)
        except Exception:
            service_pid=0; status_pid=0
        version_ok=bool(actual_version and (not expected_version or actual_version==expected_version))
        build_ok=bool(not expected_build or actual_build==expected_build)
        pid_ok=bool(service_pid and status_pid and service_pid==status_pid)
        writer_ok=bool(
            writer.get('result')=='OK'
            and int(writer.get('rows_written') or 0)>0
            and writer_commit
            and writer_cycle
            and writer_age<=180.0
            and not writer_error
            and (not expected_version or str(writer.get('version') or '')==expected_version)
            and (not expected_build or str(writer.get('build') or '')==expected_build)
        )
        pipeline_ok=bool(
            str(pipeline.get('state') or '').upper()=='NORMAL'
            and pipeline.get('complete') is True
            and pipeline.get('all_required_commits_v1150') is True
            and pipeline_cycle and pipeline_commit
            and pipeline_cycle==writer_cycle and pipeline_commit==writer_commit
            and pipeline_age<=180.0
            and (not expected_version or str(pipeline.get('version') or '')==expected_version)
            and (not expected_build or str(pipeline.get('build') or '')==expected_build)
        )
        ok=bool(worker.get('ok') and version_ok and build_ok and pid_ok and not status_error and writer_ok and pipeline_ok)
        last={
            'ok':ok,'worker_ok':bool(worker.get('ok')),'service':worker.get('service_active'),
            'service_pid':service_pid,'status_pid':status_pid,'actual_version':actual_version,'actual_build':actual_build,
            'status_state':status.get('state'),'status_error':status_error,'writer_result':writer.get('result'),
            'writer_error':writer_error,'writer_rows':writer.get('rows_written'),'writer_cycle':writer_cycle,
            'writer_commit':writer_commit,'writer_age':writer_age,'pipeline_state':pipeline.get('state'),
            'pipeline_complete':pipeline.get('complete'),'pipeline_cycle':pipeline_cycle,'pipeline_commit':pipeline_commit,
            'pipeline_age':pipeline_age,'same_cycle_commit':bool(writer_cycle and writer_cycle==pipeline_cycle and writer_commit and writer_commit==pipeline_commit),
            'expected_version':expected_version,'expected_build':expected_build,
        }
        if ok or time.monotonic()>=deadline:
            return last
        time.sleep(1.0)


def grelease_verify_text(manifest: Optional[dict] = None) -> str:
    """Release truth verification from the exact bundle plus live writers.

    Components omitted from the bundle do not create a version mismatch, but
    active Strategy health is always mandatory.  A process/version/hash match
    without a new candidate writer commit can never be PASS.
    """
    manifest_source='argument'
    manifest = manifest if isinstance(manifest, dict) else {}
    if not manifest:
        manifest, manifest_source = _v1260_last_release_manifest()
    if str(manifest.get('release') or '') == 'core_v2_full_code_staged_cutover':
        return _core_v2_stage_release_verify_v1071(manifest)
    workers = manifest.get('workers') if isinstance(manifest.get('workers'), dict) else {}

    paper_in_scope = bool(manifest.get('paper'))
    paper_target = BOT_DIR / str(manifest.get('paper')) if paper_in_scope else (BOT_DIR / PAPER_ACTIVE_FILE)
    expected_version = _v399_expected_paper_version(paper_target) if paper_target and paper_target.exists() else ''
    expected_build = extract_assignment(paper_target, 'BUILD_LABEL') if paper_target and paper_target.exists() else ''
    expected_build = '' if expected_build == '?' else expected_build
    expected_hash = short_hash(paper_target) if paper_target and paper_target.exists() else ''
    ps = paper_runtime_snapshot(expected_version, expected_build, expected_hash, max_age_sec=120.0)

    # v1059: wait once, boundedly, for the first real Paper consumer cycle.
    # Heartbeats must preserve the evaluated block and are never interpreted as
    # a new ready=False result merely because pick_stats is absent.
    contract_in_scope = bool(
        str(manifest.get('version') or '') == 'v1059'
        or expected_version == 'paper_bot_v0.996'
        or str(manifest.get('guard') or '').endswith('backga_guard_bot_v2_5_116.py')
    )
    risk_paper_status = {}
    deadline = time.monotonic() + (45.0 if contract_in_scope else 0.0)
    while True:
        paper_status_obj = read_json(BOT_DIR / 'paper_bot_status.json') or {}
        obj = paper_status_obj.get('risk_paper_contract_v1059') if isinstance(paper_status_obj.get('risk_paper_contract_v1059'), dict) else {}
        if obj:
            risk_paper_status = obj
            if obj.get('consumer_evidence_present') is True:
                break
        if not contract_in_scope or time.monotonic() >= deadline:
            break
        time.sleep(1.0)
    old_reason = str(risk_paper_status.get('reason') or '')
    risk_paper_ok = True if not contract_in_scope else bool(
        risk_paper_status.get('schema') == 'paper_risk_contract_status_v1059'
        and risk_paper_status.get('status_owner') == 'paper_bot.write_status'
        and risk_paper_status.get('consumer_owner') == 'paper_bot.select_candidates'
        and risk_paper_status.get('canonical_top_level') is True
        and risk_paper_status.get('consumer_evidence_present') is True
        and risk_paper_status.get('heartbeat_preserve_mode') is True
        and risk_paper_status.get('ready') is True
        and risk_paper_status.get('closed_signature_match') is True
        and risk_paper_status.get('latest_loss_selection') == 'max_numeric_closed_ts_per_ticker'
        and risk_paper_status.get('old_version_string_gate_active') is False
        and 'risk_worker_v0.5' not in old_reason
        and 'risk_filter_v1037_loss_reentry_occurrence_source' not in old_reason
    )

    review_status = read_json(BOT_DIR / 'clean_review_worker_status.json') or {}
    review_active = is_service_active(WORKER_SPECS['review']['service']) if 'review' in WORKER_SPECS else 'unknown'
    review_expected = str(workers.get('review') or '')
    review_in_scope = bool(review_expected)
    review_target = BOT_DIR / review_expected if review_in_scope else None
    review_version_expected = extract_assignment(review_target, 'VERSION') if review_target and review_target.exists() else ''
    review_version_actual = str(review_status.get('version') or '') if isinstance(review_status, dict) else ''
    review_ok = True if not review_in_scope else (str(review_active) in {'active','activating'} and bool(review_version_expected) and review_version_actual == review_version_expected)

    strategy_status = read_json(BOT_DIR / 'clean_strategy_worker_status.json') or {}
    strategy_active = is_service_active(WORKER_SPECS['strategy']['service'])
    strategy_expected = str(workers.get('strategy') or '')
    strategy_in_scope = bool(strategy_expected)
    strategy_file = BOT_DIR / strategy_expected if strategy_in_scope else None
    strategy_version_expected = extract_assignment(strategy_file, 'VERSION') if strategy_file and strategy_file.exists() else ''
    strategy_build_expected = extract_assignment(strategy_file, 'BUILD_LABEL') if strategy_file and strategy_file.exists() else ''
    strategy_build_expected = '' if strategy_build_expected == '?' else strategy_build_expected
    strategy_health = _v1260_strategy_release_health(
        strategy_version_expected if strategy_in_scope else '',
        strategy_build_expected if strategy_in_scope else '',
        wait_sec=45.0 if strategy_in_scope else 0.0,
    )
    strategy_version_actual = str(strategy_health.get('actual_version') or strategy_status.get('version') or '')
    # v1260 truth rule: Strategy is a critical active producer even when the
    # manual verify call did not receive a manifest.  No writer commit = no PASS.
    strategy_ok = bool(strategy_health.get('ok'))

    target_status = read_json(BOT_DIR / 'clean_target_router_status.json') or {}
    target_active = is_service_active(WORKER_SPECS['target_router']['service'])
    target_expected = str(workers.get('target_router') or '')
    target_in_scope = bool(target_expected)
    target_file = BOT_DIR / target_expected if target_in_scope else None
    target_version_expected = extract_assignment(target_file, 'VERSION') if target_file and target_file.exists() else ''
    target_version_actual = str(target_status.get('version') or '') if isinstance(target_status,dict) else ''
    target_owner = str(target_status.get('active_owner') or '') if isinstance(target_status,dict) else ''
    target_ok = True if not target_in_scope else (str(target_active) in {'active','activating'} and bool(target_version_expected) and target_version_actual == target_version_expected and target_owner == 'target_router_single_run_once')

    main_expected = str(manifest.get('main') or '')
    main_in_scope = bool(main_expected)
    main_target = BOT_DIR / main_expected if main_in_scope else None
    main_expected_version = extract_assignment(main_target, 'BOT_VERSION') if main_target and main_target.exists() else ''
    main_actual_version = extract_assignment(BOT_DIR / MAIN_ACTIVE_FILE, 'BOT_VERSION') if (BOT_DIR / MAIN_ACTIVE_FILE).exists() else ''
    main_ok = True if not main_in_scope else (bool(main_expected_version) and main_actual_version == main_expected_version)

    # v1012: every worker listed in the manifest is verified exactly, not only
    # review/strategy/target_router.  This closes the gap where candle could be
    # copied and restarted but omitted from the final integrated PASS scope.
    manifest_worker_checks: List[Dict[str, Any]] = []
    for worker_name, worker_file_name in workers.items():
        # v1200: empty/default worker entries are not release targets.
        # A bundle that changes only Main/Guard must not exact-verify every
        # unchanged worker against an empty path (BOT_DIR / "").
        worker_file_name = str(worker_file_name or "").strip()
        if not worker_file_name:
            continue
        spec = WORKER_SPECS.get(str(worker_name))
        target_path = BOT_DIR / worker_file_name
        if not spec:
            manifest_worker_checks.append({'name':str(worker_name),'ok':False,'reason':'unknown worker manifest key'})
            continue
        status_obj = read_json(BOT_DIR / str(spec.get('status'))) or {}
        active_state = is_service_active(str(spec.get('service')))
        expected = extract_assignment(target_path, 'VERSION') if target_path.exists() else ''
        actual = str(status_obj.get('version') or '') if isinstance(status_obj,dict) else ''
        active_path = BOT_DIR / str(spec.get('active'))
        target_hash = short_hash(target_path) if target_path.exists() else ''
        active_hash = short_hash(active_path) if active_path.exists() else ''
        item_ok = bool(str(active_state) in {'active','activating'} and expected and actual == expected and target_hash and active_hash == target_hash)
        manifest_worker_checks.append({'name':str(worker_name),'ok':item_ok,'active':active_state,'expected':expected or '-',
                                       'actual':actual or '-','target_hash':target_hash or '-','active_hash':active_hash or '-'})
    manifest_workers_ok = all(bool(item.get('ok')) for item in manifest_worker_checks)
    retired_ok,retired_rows=_verify_retired_services_v1257(manifest.get('retire_services') or RETIRED_SERVICES_V1257)

    ok = bool(ps.get('ok')) and review_ok and strategy_ok and target_ok and main_ok and manifest_workers_ok and risk_paper_ok and retired_ok
    reasons = list(ps.get('reasons') or [])
    if not review_ok:
        reasons.append(f'review mismatch active={review_active} expected={review_version_expected or "-"} actual={review_version_actual or "-"}')
    if not strategy_ok:
        reasons.append(
            'strategy runtime/writer mismatch '
            f'active={strategy_active} expected={strategy_version_expected or "CURRENT"} actual={strategy_version_actual or "-"} '
            f'state={strategy_health.get("status_state") or "-"} error={strategy_health.get("status_error") or strategy_health.get("writer_error") or "-"} '
            f'writer={strategy_health.get("writer_result") or "-"} pipeline={strategy_health.get("pipeline_state") or "-"} '
            f'same_commit={strategy_health.get("same_cycle_commit")}'
        )
    if not target_ok:
        reasons.append(f'target_router mismatch active={target_active} expected={target_version_expected or "-"} actual={target_version_actual or "-"} owner={target_owner or "-"}')
    if not main_ok:
        reasons.append(f'main mismatch expected={main_expected_version or "-"} actual={main_actual_version or "-"}')
    if not retired_ok:
        reasons.append('retired service still active: ' + '; '.join(retired_rows))
    if not risk_paper_ok:
        reasons.append(
            'risk-paper canonical status mismatch '
            f'schema={risk_paper_status.get("schema") or "-"} ready={risk_paper_status.get("ready")} '
            f'signature={risk_paper_status.get("closed_signature_match")} owner={risk_paper_status.get("status_owner") or "-"} '
            f'reason={old_reason or "-"}'
        )
    for item in manifest_worker_checks:
        if not item.get('ok'):
            reasons.append(f"{item.get('name')} mismatch active={item.get('active','-')} expected={item.get('expected','-')} actual={item.get('actual','-')} hash={item.get('active_hash','-')}/{item.get('target_hash','-')}")

    def scoped(flag: bool, value: str) -> str:
        return value if flag else 'SKIP(미변경)'

    lines = [
        '✅ 릴리스 통합검수 PASS' if ok else '⚠️ 릴리스 통합검수 CHECK',
        f'- manifest: {manifest_source} / release={manifest.get("release") or manifest.get("version") or "-"}',
        f'- main: expected={scoped(main_in_scope, main_expected_version or "-")} / actual={main_actual_version or "-"}',
        f'- paper: pid={ps.get("main_pid")} / status={ps.get("status_pid")} / writer={ps.get("writer_pid")} / owner={ps.get("writer_owner")} / count={ps.get("writer_count")} / age={float(ps.get("status_age") or 0):.1f}s',
        f'- risk-paper: {scoped(contract_in_scope, "PASS" if risk_paper_ok else "CHECK")} / schema={risk_paper_status.get("schema") or "-"} / ready={risk_paper_status.get("ready")} / signature={risk_paper_status.get("closed_signature_match")} / latest={risk_paper_status.get("latest_loss_selection") or "-"}',
        f'- review: active={review_active} / expected={scoped(review_in_scope, review_version_expected or "-")} / actual={review_version_actual or "-"} / last_sec={review_status.get("last_sec") if isinstance(review_status,dict) else "-"} / rss={review_status.get("rss_mb") if isinstance(review_status,dict) else "-"}MB',
        f'- strategy: active={strategy_active} / expected={scoped(strategy_in_scope, strategy_version_expected or "-")} / actual={strategy_version_actual or "-"} / health={"PASS" if strategy_health.get("ok") else "CHECK"} / state={strategy_health.get("status_state") or "-"} / err={strategy_health.get("status_error") or strategy_health.get("writer_error") or "-"}',
        f'- strategy writer: result={strategy_health.get("writer_result") or "-"} / rows={strategy_health.get("writer_rows") or 0} / cycle={strategy_health.get("writer_cycle") or "-"} / commit={strategy_health.get("writer_commit") or "-"} / pipeline={strategy_health.get("pipeline_state") or "-"} / same={strategy_health.get("same_cycle_commit")}',
        f'- target_router: active={target_active} / expected={scoped(target_in_scope, target_version_expected or "-")} / actual={target_version_actual or "-"} / owner={target_owner or "-"} / last_sec={target_status.get("last_sec") if isinstance(target_status,dict) else "-"}',
        '- worker exact: ' + (' / '.join([f"{item.get('name')}={'PASS' if item.get('ok') else 'CHECK'}:{item.get('actual','-')}:{item.get('active_hash','-')}" for item in manifest_worker_checks]) if manifest_worker_checks else 'SKIP(미변경)'),
        '- retired services: ' + (' / '.join(retired_rows) if retired_rows else 'SKIP(미변경)'),
        f'- errors: {"없음" if not reasons else " / ".join(reasons[:8])}',
        '- 판정범위: exact bundle manifest + 변경 대상 hash/version + Strategy live writer NORMAL cycle/commit + Paper canonical runtime identity',
        '- 원장·전략수치·자동매수 상태는 변경하지 않는 읽기전용 검수',
    ]
    return '\n'.join(lines)

def gupgrade_bundle_text(force: bool = False, explicit: Optional[str] = None, skip_git: bool = False, post_commands=None) -> str:
    active_job = _load_release_job()
    if active_job:
        return "\n".join([
            "📦 ⚠️ 자동 이어가기 1건 처리 중",
            f"- request: {active_job.get('request_id') or '-'}",
            f"- bundle: {active_job.get('explicit') or '-'}",
            f"- 이어실행 예약: {len(_normalize_post_upgrade_commands_v1030(active_job.get('post_commands') or []))}개",
            "- 중복 실행하지 않음",
            "- 확인: /grelease_last",
        ])
    t0=perf_now()
    status_path = BOT_DIR / UPGRADE_STATUS_FILE
    notes=[]
    progress_notify("📦 /gupgrade_bundle 접수\n- bundle zip 1개 기준으로 적용합니다\n- 단계별 진행을 표시합니다")
    if skip_git:
        progress_notify("[1/5] GitHub 확인 생략\n- 서버 로컬 zip 기준")
    if not skip_git:
        progress_notify("[1/5] GitHub 최신 zip 1개 확인 중\n- repo 전체 fetch/reset 없이 bundle zip만 직접 확인")
        ok_dl, dl_steps = _github_direct_download_latest_bundle(explicit=explicit)
        notes += ["[github bundle]"] + dl_steps[-6:]
        if not ok_dl:
            return "📦 ❌ bundle 업그레이드 실패 /gupgrade_bundle\n- GitHub 최신 zip 직접 확인 실패\n- repo 전체 fetch/stale fallback은 사용하지 않음\n" + "\n".join(notes[-10:])
    bundle = find_latest_bundle_file(explicit)
    if bundle:
        progress_notify(f"[2/5] bundle 발견\n- {bundle.name}\n- 압축 검수/해제 중")
    if not bundle:
        return "📦 ❌ bundle 업그레이드 실패 /gupgrade_bundle\n- coinbot_update_v*.zip 파일을 못 찾음"
    work = BOT_DIR / f".bundle_unpack_{int(time.time())}"
    if work.exists():
        shutil.rmtree(work, ignore_errors=True)
    work.mkdir(parents=True, exist_ok=True)
    try:
        with zipfile.ZipFile(bundle, 'r') as z:
            bad = z.testzip()
            if bad:
                return f"📦 ❌ bundle 검수 실패\n- zip 손상 의심: {bad}"
            z.extractall(work)
        manifest_path = work / "DEPLOY_BUNDLE.json"
        manifest = read_json(manifest_path) if manifest_path.exists() else _bundle_manifest_defaults(work)
        if not isinstance(manifest, dict):
            return "📦 ❌ bundle 검수 실패\n- DEPLOY_BUNDLE.json 형식 오류"
        manifest = _normalize_bundle_manifest(manifest, work)
        ledger_ok, ledger_notes = _append_packaged_ledger_events_v1238(work, manifest)
        notes += ledger_notes
        if not ledger_ok:
            return "📦 ❌ bundle 장부 append 실패\n- 기존 원장은 유지하고 runtime 적용을 중단함\n" + "\n".join(ledger_notes[-10:])
        notes.append(f"bundle={bundle.name}")
        if manifest.get("main"):
            notes.append(f"manifest main={manifest.get('main')}")
        notes += _copy_bundle_files_to_repo(work, manifest)
        progress_notify("[3/5] bundle 파일 복사 완료\n- 변경 파일 중심 빠른 검수 중")
        # v2.5.48: component apply 단계에서 main/paper/worker/guard를 다시 검수하므로
        # bundle 단계의 전체 중복 py_compile은 줄인다. manifest 밖의 보조 .py만 여기서 검수한다.
        manifest_py = set()
        for key in ("main", "paper", "guard", "ws", "micro", "ws_sidecar", "micro_sidecar"):
            if manifest.get(key):
                manifest_py.add(str(manifest.get(key)))
        workers_manifest = manifest.get('workers') if isinstance(manifest.get('workers'), dict) else {}
        for fname in workers_manifest.values():
            if fname:
                manifest_py.add(str(fname))
        support_files = manifest.get('support_files') if isinstance(manifest.get('support_files'), list) else []
        for rel in support_files:
            if isinstance(rel,str) and rel.endswith('.py'):
                manifest_py.add(rel)
                okc,out=py_compile(BOT_DIR/rel)
                if not okc:
                    return f"📦 ❌ support py_compile 실패\n- file: {rel}\n{tail(out,1200)}"
        # v2.5.176/v1131: manifest 밖 archive-only Python은 아직 BOT_DIR에 복사되지 않았다.
        # unpack 경로에서 직접 compile하여 존재하지 않는 BOT_DIR 경로 오판을 막는다.
        for n in [x for x in os.listdir(work) if x.endswith('.py') and x not in manifest_py]:
            okc,out=py_compile(work/n)
            if not okc:
                return f"📦 ❌ bundle py_compile 실패\n- file: {n}\n{tail(out,1200)}"
        # v2.5.66: 가드봇 파일이 바뀌는 bundle은 가드봇만 먼저 교체하고 여기서 끝낸다.
        # 같은 명령에서 가드봇 재시작 뒤 worker/main/paper까지 이어가지 않는다.
        if manifest.get('guard'):
            guard_target = BOT_DIR / str(manifest.get('guard'))
            active_guard = BOT_DIR / GUARD_ACTIVE_FILE
            try:
                guard_changed = guard_target.exists() and (not active_guard.exists() or short_hash(guard_target) != short_hash(active_guard))
            except Exception:
                guard_changed = True
            if guard_changed:
                progress_notify("[4/5] 가드봇 우선 적용 중\n- 새 가드 정상기동 뒤 나머지 1회 적용")
                guard_res = format_guard_apply_result(apply_guard_first_for_smart_upgrade(force=force, continuation_bundle=bundle.name, post_commands=post_commands))
                write_json(status_path, {"time": now(), "ok": True, "stage": "guard_only", "bundle": bundle.name, "guard_version": VERSION, "guard_only": True})
                return "\n".join([
                    "📦 ✅ 가드봇 우선 적용 완료 /gupgrade_bundle",
                    f"- guard: {VERSION}",
                    f"- bundle: {bundle.name}",
                    "- 처리: 가드봇 교체/재시작 후 새 가드가 안정화된 다음 같은 bundle 나머지를 1회 적용",
                    "- 새 가드봇은 MainPID 안정화 후 나머지 적용 1회·검수 1회·결과 전송 1회만 수행함",
                    "",
                    "[guard]",
                    guard_res,
                    "",
                    "다음 확인: 별도 명령 없음",
                    "새 가드봇이 자동으로 최종 적용 결과를 전송",
                ])

        progress_notify("[4/5] 컴포넌트 적용 중\n- 변경된 worker/main/paper만 재시작")
        results=[]
        component_failures=[]
        # workers first except guard/main/paper. A failed component stops the
        # release; later components are not applied over an untrusted partial state.
        workers=manifest.get('workers') if isinstance(manifest.get('workers'), dict) else {}
        for name, fname in workers.items():
            if name in WORKER_SPECS and fname:
                raw = apply_worker_latest(name, force=force, explicit=fname, restart=True)
                rendered = format_worker_apply_result(raw)
                results.append(rendered)
                if isinstance(raw,dict) and not bool(raw.get('ok', True)):
                    component_failures.append(f"worker:{name}")
                    break

        main_res = ""
        paper_res = ""
        ws_res = ""
        micro_res = ""
        guard_res = ""
        if not component_failures and manifest.get('main'):
            main_res = apply_main_latest_auto(force=force, explicit=str(manifest.get('main')), skip_git=True)
            if _v1165_apply_text_failed(main_res):
                component_failures.append('main')
        # v1197: shared support modules such as canonical_spine are imported in
        # memory. If the Main source hash is unchanged, normal apply skips the
        # restart, so explicitly reload only the declared dependent service.
        support_restart_dependents = {str(x).strip().lower() for x in (manifest.get('restart_support_dependents') or []) if str(x).strip()}
        if not component_failures and 'main' in support_restart_dependents and (not manifest.get('main') or '변경 없음' in str(main_res)):
            support_restart_text = restart_service(short=True)
            main_res = (str(main_res).rstrip() + "\n" if main_res else "") + "[support module reload]\n" + support_restart_text
            if 'active: active' not in support_restart_text:
                component_failures.append('main_support_reload')
        if not component_failures and manifest.get('paper'):
            paper_raw = apply_paper_latest(force=force, explicit=str(manifest.get('paper')))
            paper_res = format_paper_apply_result(paper_raw)
            if isinstance(paper_raw,dict) and not bool(paper_raw.get('ok',True)):
                component_failures.append('paper')
        ws_manifest = manifest.get('ws') or manifest.get('ws_sidecar')
        if not component_failures and ws_manifest:
            ws_raw = apply_ws_sidecar_latest(force=force, explicit=str(ws_manifest), restart=True)
            ws_res = format_ws_apply_result(ws_raw)
            if isinstance(ws_raw,dict) and not bool(ws_raw.get('ok',True)):
                component_failures.append('ws')
        micro_manifest = manifest.get('micro') or manifest.get('micro_sidecar')
        if not component_failures and micro_manifest:
            micro_raw = apply_micro_sidecar_latest(force=force, explicit=str(micro_manifest), restart=True)
            micro_res = format_micro_apply_result(micro_raw)
            if isinstance(micro_raw,dict) and not bool(micro_raw.get('ok',True)):
                component_failures.append('micro')
        if not component_failures and manifest.get('guard'):
            # guard is copied last in the legacy direct path. A guard-changing bundle
            # normally exits earlier through the guarded continuation contract.
            guard_res = format_guard_apply_result(apply_guard_first_for_smart_upgrade(force=force, continuation_bundle=bundle.name, post_commands=post_commands))
            if _v1165_apply_text_failed(guard_res):
                component_failures.append('guard')
        retire_notes=[]
        if not component_failures and manifest.get('retire_services'):
            retire_ok,retire_notes=_retire_services_v1257(manifest.get('retire_services'))
            notes += ['[retire services]'] + retire_notes
            if not retire_ok:
                component_failures.append('retire_services')

        verify_text = grelease_verify_text(manifest)
        verify_ok = str(verify_text).startswith('✅')
        overall_ok = bool(not component_failures and verify_ok)
        write_json(status_path, {
            "time": now(), "ok": overall_ok, "stage": "bundle",
            "bundle": bundle.name, "manifest": manifest, "guard_version": VERSION,
            "component_failures_v1165": component_failures,
            "verify_ok_v1165": verify_ok,
        })
        progress_notify(
            "[5/5] bundle 적용·검수 완료\n- 최종 PASS" if overall_ok
            else "[5/5] bundle 적용 또는 검수 실패\n- 성공으로 표시하지 않음"
        )
        lines=[
            "📦 ✅ bundle 업그레이드 완료 /gupgrade_bundle" if overall_ok else "📦 ❌ bundle 적용 실패·통합검수 CHECK /gupgrade_bundle",
            f"- guard: {VERSION}", f"- bundle: {bundle.name}",
            f"- total: {fmt_sec(perf_now()-t0)}",
            f"- 컴포넌트 실패: {', '.join(component_failures) if component_failures else '없음'}",
            f"- 통합검수: {'PASS' if verify_ok else 'CHECK'}",
            "", "[bundle 복사]",
        ]
        lines += [f"- {x}" for x in notes[:20]]
        if results:
            lines += ["", "[worker]"] + [r[:900] for r in results]
        if main_res:
            lines += ["", "[main]", tail(main_res, 1200)]
        if paper_res:
            lines += ["", "[paper]", paper_res]
        if ws_res:
            lines += ["", "[ws]", ws_res]
        if micro_res:
            lines += ["", "[micro]", micro_res]
        if guard_res:
            lines += ["", "[guard]", guard_res]
        zip_retention = _prune_update_bundle_cache_v1030(bundle.name, keep=3)
        lines += [
            "", "[로컬 bundle 보관]",
            f"- 최신 3개 유지 / 삭제 {zip_retention.get('deleted',0)}개 / 확보 {_fmt_bytes(zip_retention.get('freed_bytes',0))}",
            f"- 오류 {len(zip_retention.get('errors') or [])}개",
            "", "[자동 최종검수]", verify_text,
            "", "추가 명령: 문제 있을 때만 /grelease_verify 또는 /gpaperlog 120",
        ]
        return "\n".join(lines)

    except Exception as exc:
        return f"📦 ❌ bundle 업그레이드 예외\n- {exc.__class__.__name__}: {exc}\n{tail(traceback.format_exc(), 1200)}"
    finally:
        shutil.rmtree(work, ignore_errors=True)

def gupgrade_component_text(component: str, force: bool = False, explicit: Optional[str] = None) -> str:
    """v2.5.36: 개별 업그레이드 단일 입구.

    기존 적용 본선을 그대로 사용하고, 대상만 분리한다.
    """
    component = str(component or "").strip().lower()
    labels = {
        "main": ("🚀", "메인봇", "/gupgrade_main"),
        "paper": ("🧪", "페이퍼봇", "/gupgrade_paper"),
        "ws": ("🛰", "WS 직원", "/gupgrade_ws"),
        "micro": ("🔎", "micro 직원", "/gupgrade_micro"),
        "guard": ("🛡", "가드봇", "/gupgrade_guard"),
    }
    if component not in labels:
        return gupgrade_menu_text()
    icon, label, command = labels[component]
    t0 = perf_now()
    status_path = BOT_DIR / UPGRADE_STATUS_FILE

    disk_ok, disk_text = preupgrade_disk_guard(force=force)
    if not disk_ok:
        write_json(status_path, {"time": now(), "ok": False, "stage": f"{component}_disk_precheck", "guard_version": VERSION})
        return f"{icon} ❌ {label} 개별 업그레이드 중단 {command}\n" + disk_text

    progress_notify(f"{icon} {label} 개별 업그레이드 시작\n- 전체가 아니라 {label}만 확인/적용\n- hash 동일이면 재시작 생략")
    progress_notify(f"{icon} [1/2] GitHub 최신 파일 확인 중")
    ok_git, steps = git_update()
    if not ok_git:
        write_json(status_path, {"time": now(), "ok": False, "stage": f"{component}_git", "steps": steps, "guard_version": VERSION})
        return f"{icon} ❌ {label} 개별 업그레이드 실패 {command}\n- 단계: GitHub 갱신 실패\n\n" + "\n\n".join(steps)

    progress_notify(f"{icon} [2/2] {label} 적용 확인 중")
    status = read_json(status_path)
    ok = False
    result_text = ""

    if component == "main":
        result_text = apply_main_latest_auto(force=force, explicit=explicit, skip_git=True)
        ok = "❌" not in result_text and "업그레이드 예외" not in result_text and "중단" not in result_text
        status["main_component_upgrade"] = {"time": now(), "ok": ok, "explicit": explicit or "", "force": force}
    elif component == "paper":
        res = apply_paper_latest(force=force, explicit=explicit)
        ok = bool(res.get("ok"))
        status["paper"] = res
        result_text = format_paper_apply_result(res)
    elif component == "ws":
        res = apply_ws_sidecar_latest(force=force, explicit=explicit, restart=True)
        ok = bool(res.get("ok"))
        status["ws_sidecar"] = res
        result_text = format_ws_apply_result(res)
    elif component == "micro":
        set_micro_desired(True, "gupgrade_micro_component")
        res = apply_micro_sidecar_latest(force=force, explicit=explicit, restart=True)
        ok = bool(res.get("ok"))
        status["micro_sidecar"] = res
        result_text = format_micro_apply_result(res)
    elif component == "guard":
        result_text = guard_self_upgrade(force=force, explicit=explicit)
        ok = "실패" not in result_text and "❌" not in result_text
        status["guard_component_upgrade"] = {"time": now(), "ok": ok, "explicit": explicit or "", "force": force}
    elif component == "workers":
        res = apply_workers_latest(force=force, restart=True)
        ok = bool(res.get("ok"))
        status["workers_component_upgrade"] = {"time": now(), "ok": ok, "force": force}
        result_text = gworker_upgrade_text(force=force)

    status["guard_version"] = VERSION
    status[f"{component}_component_upgrade_time"] = now()
    status[f"{component}_component_upgrade_total_sec"] = perf_now() - t0
    write_json(status_path, status)

    title_icon = "✅" if ok else "❌"
    return (
        f"{icon} {title_icon} {label} 개별 업그레이드 {command}\n"
        f"- guard: {VERSION}\n"
        f"- 대상: {label}만 적용 / 다른 컴포넌트는 건드리지 않음\n"
        f"- 방식: 기존 단일 적용 함수 사용, hash 동일이면 재시작 생략\n"
        f"- total: {fmt_sec(perf_now() - t0)}\n\n"
        f"[적용 결과]\n{result_text}\n\n"
        f"다음 확인:\n"
        f"- 가드봇: /gdeploy\n"
        f"- 메인봇: /health /errorlog\n"
        f"- 페이퍼봇: /pstatus /perror\n"
        f"- 외부직원: /gexternal_state"
    )

CORE_V2_VERIFY_STATUS_V1071 = BOT_DIR / 'core_v2_verify_status_v1071.json'

CORE_V2_CUTOVER_STATUS_V1071 = BOT_DIR / 'core_v2_cutover_status_v1071.json'

CORE_V2_FILES_V1071 = {
    'risk':'risk_worker_v0.11.py',
    'strategy':'strategy_worker_v0.992.py',
    'review':'review_worker_v0.995.py',
    'paper':'paper_bot_v0.999.py',
    'main':'coinbot_main_v2_13_1071.py',
}

def gcore_v2_verify_text() -> str:
    _core_v2_append_ledger_v1071('CHECK','CHECK','v1071 static exact-pair server semantic parity verification started','PASS required before cutover')
    script=BOT_DIR/'core_v2_verify_v1071.py'
    if not script.exists():
        return '🧬 ❌ v1071 검증 파일 없음\n- bundle support file 적용 확인 필요'
    py=WORKER_PYTHON_BIN or '/usr/bin/python3'
    rc,out=run([py,str(script),str(BOT_DIR),str(CORE_V2_VERIFY_STATUS_V1071)],cwd=BOT_DIR,timeout=240)
    if out:
        return out
    return f'🧬 v1071 검증 종료\n- rc {rc}\n- status {CORE_V2_VERIFY_STATUS_V1071}'

def _core_v2_exact_counts_v1073(snapshot):
    """Read the canonical sparse Counter contract without fuzzy key search.

    canonical_alt_swing_performance_snapshot_v987 stores ``counts`` from a
    Counter.  A valid schema may omit zero-valued keys, so absence of a known
    counter key means zero only after schema/owner/counts validation.  Missing
    snapshot/schema/counts remains CHECK and is never normalised to zero.
    """
    if not isinstance(snapshot, dict):
        return False, None, None, None, 'snapshot_missing'
    if str(snapshot.get('schema') or '') != 'canonical_alt_swing_performance_snapshot_v987':
        return False, None, None, None, 'schema_mismatch'
    if str(snapshot.get('source_owner') or '') != 'paper_bot_single_canonical_performance_writer':
        return False, None, None, None, 'owner_mismatch'
    counts = snapshot.get('counts')
    if not isinstance(counts, dict):
        return False, None, None, None, 'counts_missing'
    values=[]
    for key in ('duplicate_closed_rows','missing_decision_key','decision_not_closed_or_missing'):
        raw=counts.get(key,0)
        try:
            value=int(float(raw))
        except Exception:
            return False, None, None, None, f'invalid_count:{key}'
        if value < 0:
            return False, None, None, None, f'negative_count:{key}'
        values.append(value)
    dup,keymiss,unlinked=values
    return bool(dup==0 and keymiss==0 and unlinked==0),dup,keymiss,unlinked,'canonical_sparse_counter'

def _core_v2_runtime_proof_v1071() -> tuple[bool,list[str]]:
    checks=[]; ok=True; nowv=time.time()
    expected={
      'risk':('clean_risk_status.json','risk_worker_v0.11'),
      'strategy':('clean_strategy_worker_status.json','strategy_worker_v0.992'),
      'review':('clean_review_worker_status.json','review_worker_v0.995'),
      'paper':('paper_bot_status.json','paper_bot_v0.999'),
      'main':('clean_brain_status.json','수익형 v2.13.1071'),
    }
    objects={}
    for name,(fname,version) in expected.items():
        path=BOT_DIR/fname; obj=read_json(path); objects[name]=obj
        age=max(0.0,nowv-path.stat().st_mtime) if path.exists() else 999999.0
        actual=str(obj.get('version') or obj.get('worker_version') or obj.get('bot_version') or '') if isinstance(obj,dict) else ''
        if name=='main' and version not in actual:
            actual=str(obj.get('main_version') or obj.get('version') or obj.get('bot_version') or '') if isinstance(obj,dict) else ''
        error=str((obj or {}).get('error') or (obj or {}).get('last_error') or '').strip() if isinstance(obj,dict) else 'missing'
        row_ok=bool(version in actual and age<180 and not error)
        ok=ok and row_ok; checks.append(f"{'✅' if row_ok else '⚠️'} {name}: expected={version} actual={actual or '-'} age={age:.1f}s error={error or '-'}")
    paper=objects.get('paper') if isinstance(objects.get('paper'),dict) else {}
    contract=paper.get('risk_paper_contract_v1059') if isinstance(paper.get('risk_paper_contract_v1059'),dict) else {}
    contract_ok=bool(contract.get('schema')=='paper_risk_contract_status_v1059' and contract.get('ready') is True and contract.get('closed_signature_match') is True)
    ok=ok and contract_ok; checks.append(f"{'✅' if contract_ok else '⚠️'} risk-paper: schema={contract.get('schema') or '-'} ready={contract.get('ready')} signature={contract.get('closed_signature_match')}")
    writer=read_json(BOT_DIR/'clean_strategy_paper_latest_writer_status.json')
    try: writer_age=max(0.0,nowv-(BOT_DIR/'clean_strategy_paper_latest_writer_status.json').stat().st_mtime)
    except Exception: writer_age=999999.0
    writer_ok=bool(isinstance(writer,dict) and str(writer.get('result') or '').upper()=='OK' and writer_age<180)
    ok=ok and writer_ok; checks.append(f"{'✅' if writer_ok else '⚠️'} strategy candidate writer: result={(writer or {}).get('result') if isinstance(writer,dict) else '-'} age={writer_age:.1f}s")
    perf=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json')
    exact_ok,dup,keymiss,unlinked,exact_reason=_core_v2_exact_counts_v1073(perf)
    ok=ok and exact_ok; checks.append(f"{'✅' if exact_ok else '⚠️'} exact ledger: duplicate={dup} key_missing={keymiss} unlinked={unlinked} source={exact_reason}")
    auto_off=bool((paper.get('auto_buy') in (False,0,None)) and (objects.get('strategy') or {}).get('auto_buy') in (False,0,None))
    ok=ok and auto_off; checks.append(f"{'✅' if auto_off else '⚠️'} auto-buy OFF")
    return ok,checks

def _core_v2_cutover_backup_v1071() -> tuple[Path,dict]:
    stamp=time.strftime('%Y%m%d_%H%M%S'); root=BOT_DIR/f'core_v2_cutover_backup_v1071_{stamp}'; root.mkdir(parents=True,exist_ok=False)
    aliases={'risk':BOT_DIR/WORKER_SPECS['risk']['active'],'strategy':BOT_DIR/WORKER_SPECS['strategy']['active'],'review':BOT_DIR/WORKER_SPECS['review']['active'],'paper':BOT_DIR/PAPER_ACTIVE_FILE,'main':BOT_DIR/MAIN_ACTIVE_FILE}
    meta={'aliases':{},'markers':{}}
    for name,path in aliases.items():
        if path.exists():
            dst=root/path.name; shutil.copy2(path,dst); meta['aliases'][name]={'active':str(path),'backup':str(dst),'hash':short_hash(path)}
    for marker in ('.deployed_target',DEPLOYED_PAPER_FILE,'.deployed_risk_worker_target','.deployed_strategy_worker_target','.deployed_review_worker_target','DEPLOY_TARGET.txt'):
        path=BOT_DIR/marker; meta['markers'][marker]=read_file(path) if path.exists() else None
    write_json(root/'backup_manifest.json',meta); return root,meta

def _core_v2_restore_v1071(root:Path,meta:dict) -> list[str]:
    notes=[]
    for service in (MAIN_SERVICE,PAPER_SERVICE,WORKER_SPECS['review']['service'],WORKER_SPECS['strategy']['service'],WORKER_SPECS['risk']['service']):run(['systemctl','stop',service],timeout=25)
    for name,obj in (meta.get('aliases') or {}).items():
        src=Path(str(obj.get('backup') or '')); dst=Path(str(obj.get('active') or ''))
        if src.exists() and dst:
            tmp=dst.with_name(f'.{dst.name}.restore.{os.getpid()}.{time.time_ns()}'); shutil.copy2(src,tmp); os.replace(tmp,dst); notes.append(f'restore {name} {short_hash(dst)}')
    for marker,value in (meta.get('markers') or {}).items():
        path=BOT_DIR/marker
        if value is None:
            try:path.unlink(missing_ok=True)
            except Exception:pass
        else:path.write_text(str(value).rstrip()+'\n',encoding='utf-8')
    for service in (WORKER_SPECS['risk']['service'],WORKER_SPECS['strategy']['service'],PAPER_SERVICE,WORKER_SPECS['review']['service'],MAIN_SERVICE):
        rc,out=run(['systemctl','restart',service],timeout=35); notes.append(f'{service} restart rc={rc}')
    return notes

def _core_v2_append_ledger_v1071(issue_status:str,change_status:str,summary:str,remaining:str='') -> None:
    ts=time.time(); common={'version':'v1073','ts':ts,'time':now(),'strategy_impact':'none_exact_semantic_parity','auto_buy':False,'source':'guard_static_exact_pair_verify_cutover'}
    rows=[
      (BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1073',event_type='ISSUE',issue_id='CORE-V2-CUTOVER-CONTROL-1073',status=issue_status,title='CORE V2 cutover deployed-target runtime verification',summary=summary,remaining=remaining)),
      (BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1073',event_type='CHANGE_VERIFY',change_id='v1073-canonical-exact-counts-001',issue_id='CORE-V2-CUTOVER-CONTROL-1073',status=change_status,summary=summary,remaining=remaining)),
    ]
    for path,row in rows:
        path.parent.mkdir(parents=True,exist_ok=True)
        with path.open('a',encoding='utf-8') as fh:fh.write(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=str)+'\n');fh.flush();os.fsync(fh.fileno())

def gcore_v2_cutover_text() -> str:
    report=read_json(CORE_V2_VERIFY_STATUS_V1071)
    try:age=max(0.0,time.time()-CORE_V2_VERIFY_STATUS_V1071.stat().st_mtime)
    except Exception:age=999999.0
    required=('proof_file_exact','active_source_hashes_exact','staged_source_hashes_exact','local_exact_pair_proof_valid','static_compile_pass','duplicate_active_definitions_zero','command_contract_preserved','staged_versions_exact','source_execution_zero','live_ledger_access_zero','auto_buy_off','simplified_recalculation_retired')
    checks=report.get('checks') if isinstance(report,dict) and isinstance(report.get('checks'),dict) else {}; missing_checks=[k for k in required if checks.get(k) is not True]
    if not isinstance(report,dict) or report.get('pass') is not True or age>900 or missing_checks:
        return '\n'.join(['🧬 ❌ v1071 전환 중단','- 최신 정확 본선 검증 PASS 필요','- 먼저 /gcore_v2_verify 실행',f'- verify age {age:.1f}s',f"- 미통과: {', '.join(missing_checks) or '-'}"])
    missing=[name for name in CORE_V2_FILES_V1071.values() if not (BOT_DIR/name).exists()]
    if missing:return '🧬 ❌ v1071 전환 파일 누락\n- '+', '.join(missing)
    compile_errors=[]
    for name in list(CORE_V2_FILES_V1071.values())+['core_v2_verify_v1071.py']:
        okc,out=py_compile(BOT_DIR/name)
        if not okc:compile_errors.append(f'{name}: {tail(out,300)}')
    if compile_errors:return '🧬 ❌ v1071 전환 전 compile 실패\n- '+'\n- '.join(compile_errors)
    _core_v2_append_ledger_v1071('CHECK','CHECK','v1071 static exact-pair full cutover started','runtime proof and persistence required')
    started=time.time();results=[];proof=[];backup_root=None;backup_meta={};success=False;rollback=[]
    try:
        backup_root,backup_meta=_core_v2_cutover_backup_v1071()
        for worker in ('risk','strategy'):
            raw=apply_worker_latest(worker,force=True,explicit=CORE_V2_FILES_V1071[worker],restart=True);results.append(format_worker_apply_result(raw))
            if not bool(raw.get('ok')):raise RuntimeError(f'{worker} apply failed')
        raw=apply_paper_latest(force=True,explicit=CORE_V2_FILES_V1071['paper']);results.append(format_paper_apply_result(raw))
        if not bool(raw.get('ok')):raise RuntimeError('paper apply failed')
        raw=apply_worker_latest('review',force=True,explicit=CORE_V2_FILES_V1071['review'],restart=True);results.append(format_worker_apply_result(raw))
        if not bool(raw.get('ok')):raise RuntimeError('review apply failed')
        rendered=apply_main_latest_auto(force=True,explicit=CORE_V2_FILES_V1071['main'],skip_git=True);results.append(rendered)
        if str(rendered).startswith(('❌','🚀 ❌')) or '업그레이드 예외' in str(rendered):raise RuntimeError('main apply failed')
        deadline=time.time()+100
        while time.time()<deadline:
            proof_ok,proof=_core_v2_runtime_proof_v1071()
            if proof_ok:break
            time.sleep(5)
        if not proof_ok:raise RuntimeError('runtime proof failed')
        success=True
    except Exception as exc:
        results.append(f'FAIL: {type(exc).__name__}: {exc}')
        if backup_root is not None:rollback=_core_v2_restore_v1071(backup_root,backup_meta)
        _core_v2_append_ledger_v1071('FAIL','FAIL',f'v1071 cutover failed and full rollback completed: {type(exc).__name__}: {exc}','Do not retry until cause is corrected')
    status={'schema':'core_v2_cutover_status_v1071','time':now(),'ok':bool(success),'apply_ok':bool(success),'runtime_proof_ok':bool(success),'verify_digest':sha256_file(CORE_V2_VERIFY_STATUS_V1071),'auto_buy':False,'backup_dir':str(backup_root or ''),'results':results,'proof':proof,'rollback':rollback}
    write_json(CORE_V2_CUTOVER_STATUS_V1071,status)
    if success:_core_v2_append_ledger_v1071('DONE','DONE','v1071 static exact-pair server cutover and runtime proof complete','observe next cycle and restart persistence')
    return '\n'.join([f"🧬 {'✅' if success else '❌'} v1071 정적 exact-pair 본선 일괄전환 {'DONE' if success else 'ROLLBACK'}",'- 대상: Risk → Strategy → Paper → Review → Main','- 간이 구조/S1 재계산 제거 · 기존 동작 exact 이식','- 전략 수치 변경 0 / 원장 삭제 0 / 자동매수 OFF',f"- backup: {backup_root or '-'}",f"- total {time.time()-started:.1f}s",'','[runtime 증명]',*(proof or ['- 미완료']),'','[rollback]',*(rollback or ['- 없음']),'','[적용]',*results])

CORE_V2_CLOSEOUT_STATUS_V1074 = BOT_DIR / 'core_v2_closeout_status_v1074.json'

CORE_V2_CLOSEOUT_MARKER_V1074 = BOT_DIR / '.core_v2_closeout_done_v1074.json'

def _append_jsonl_fsync_v1074(path: Path, row: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as fh:
        fh.write(json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str) + '\n')
        fh.flush()
        os.fsync(fh.fileno())

def _core_v2_closeout_append_v1074(status: str, summary: str, remaining: str) -> None:
    ts=time.time()
    common={
        'version':'v1074','ts':ts,'time':now(),'status':status,
        'strategy_impact':'none_runtime_closeout_only','auto_buy':False,
        'source':'guard_core_v2_closeout_v1074',
    }
    rows=[
        (BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1074',event_type='ISSUE',issue_id='CORE-V2-CUTOVER-CONTROL-1073',title='CORE V2 exact active-spine cutover',summary=summary,remaining=remaining)),
        (BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1074',event_type='ISSUE',issue_id='CORE-V2-SYSTEM-CLOSEOUT-1074',title='CORE V2 runtime persistence and ledger closeout',summary=summary,remaining=remaining)),
        (BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1074',event_type='ISSUE',issue_id='PAPER-RISK-STATUS-1059',title='Risk-Paper canonical status single reader',summary='v1074 closeout re-proved READY/signature true and exact 0/0/0 after CORE V2 cutover.',remaining='Continue normal monitoring; no strategy or contract change.')),
        (BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1074',event_type='CHANGE_VERIFY',change_id='v1074-core-v2-closeout-001',issue_id='CORE-V2-SYSTEM-CLOSEOUT-1074',summary=summary,remaining=remaining)),
    ]
    for path,row in rows:
        _append_jsonl_fsync_v1074(path,row)

def _core_v2_active_hash_checks_v1074() -> tuple[bool,list[str]]:
    rows=[]; ok=True
    pairs={
        'risk':(BOT_DIR/WORKER_SPECS['risk']['active'],BOT_DIR/'risk_worker_v0.11.py'),
        'strategy':(BOT_DIR/WORKER_SPECS['strategy']['active'],BOT_DIR/'strategy_worker_v0.992.py'),
        'review':(BOT_DIR/WORKER_SPECS['review']['active'],BOT_DIR/'review_worker_v0.995.py'),
        'paper':(BOT_DIR/PAPER_ACTIVE_FILE,BOT_DIR/'paper_bot_v1.000.py'),
        'main':(BOT_DIR/MAIN_ACTIVE_FILE,BOT_DIR/'coinbot_main_v2_13_1074.py'),
    }
    for name,(active,target) in pairs.items():
        active_hash=sha256_file(active) if active.exists() else ''
        target_hash=sha256_file(target) if target.exists() else ''
        row_ok=bool(active_hash and target_hash and active_hash==target_hash)
        ok=ok and row_ok
        rows.append(f"{'✅' if row_ok else '⚠️'} {name} hash: active={active_hash[:12] or '-'} target={target_hash[:12] or '-'}")
    return ok,rows

def _core_v2_runtime_proof_v1074() -> tuple[bool,list[str]]:
    checks=[]; ok=True; nowv=time.time()
    expected={
      'risk':('clean_risk_status.json','risk_worker_v0.11'),
      'strategy':('clean_strategy_worker_status.json','strategy_worker_v0.992'),
      'review':('clean_review_worker_status.json','review_worker_v0.995'),
      'paper':('paper_bot_status.json','paper_bot_v1.000'),
      'main':('clean_brain_status.json','수익형 v2.13.1074'),
    }
    objects={}
    for name,(fname,version) in expected.items():
        path=BOT_DIR/fname; obj=read_json(path); objects[name]=obj
        age=max(0.0,nowv-path.stat().st_mtime) if path.exists() else 999999.0
        actual=str(obj.get('version') or obj.get('worker_version') or obj.get('bot_version') or '') if isinstance(obj,dict) else ''
        if name=='main' and version not in actual:
            actual=str(obj.get('main_version') or obj.get('version') or obj.get('bot_version') or '') if isinstance(obj,dict) else ''
        error=str((obj or {}).get('error') or (obj or {}).get('last_error') or '').strip() if isinstance(obj,dict) else 'missing'
        row_ok=bool(version in actual and age<180 and not error)
        ok=ok and row_ok; checks.append(f"{'✅' if row_ok else '⚠️'} {name}: expected={version} actual={actual or '-'} age={age:.1f}s error={error or '-'}")
    paper=objects.get('paper') if isinstance(objects.get('paper'),dict) else {}
    contract=paper.get('risk_paper_contract_v1059') if isinstance(paper.get('risk_paper_contract_v1059'),dict) else {}
    contract_ok=bool(contract.get('schema')=='paper_risk_contract_status_v1059' and contract.get('ready') is True and contract.get('closed_signature_match') is True)
    ok=ok and contract_ok; checks.append(f"{'✅' if contract_ok else '⚠️'} risk-paper: schema={contract.get('schema') or '-'} ready={contract.get('ready')} signature={contract.get('closed_signature_match')}")
    writer=read_json(BOT_DIR/'clean_strategy_paper_latest_writer_status.json')
    try: writer_age=max(0.0,nowv-(BOT_DIR/'clean_strategy_paper_latest_writer_status.json').stat().st_mtime)
    except Exception: writer_age=999999.0
    writer_ok=bool(isinstance(writer,dict) and str(writer.get('result') or '').upper()=='OK' and writer_age<180)
    ok=ok and writer_ok; checks.append(f"{'✅' if writer_ok else '⚠️'} strategy candidate writer: result={(writer or {}).get('result') if isinstance(writer,dict) else '-'} age={writer_age:.1f}s")
    perf=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json')
    exact_ok,dup,keymiss,unlinked,exact_reason=_core_v2_exact_counts_v1073(perf)
    ok=ok and exact_ok; checks.append(f"{'✅' if exact_ok else '⚠️'} exact ledger: duplicate={dup} key_missing={keymiss} unlinked={unlinked} source={exact_reason}")
    auto_off=bool((paper.get('auto_buy') in (False,0,None)) and (objects.get('strategy') or {}).get('auto_buy') in (False,0,None))
    ok=ok and auto_off; checks.append(f"{'✅' if auto_off else '⚠️'} auto-buy OFF")
    return ok,checks

def gcore_v2_closeout_text() -> str:
    previous=read_json(CORE_V2_CLOSEOUT_MARKER_V1074)
    if isinstance(previous,dict) and previous.get('ok') is True:
        return '\n'.join([
            '🧬 ✅ CORE V2 마감 이미 완료 · v1074',
            f"- 완료: {previous.get('time') or '-'}",
            f"- proof digest: {previous.get('proof_digest') or '-'}",
            '- 중복 장부 append 0',
            '- 자동매수 OFF',
        ])
    cut=read_json(CORE_V2_CUTOVER_STATUS_V1071)
    cut_ok=bool(isinstance(cut,dict) and cut.get('ok') is True and cut.get('runtime_proof_ok') is True and not (cut.get('rollback') or []))
    try: cut_age=max(0.0,time.time()-CORE_V2_CUTOVER_STATUS_V1071.stat().st_mtime)
    except Exception: cut_age=999999.0
    runtime_ok,runtime_rows=_core_v2_runtime_proof_v1074()
    hash_ok,hash_rows=_core_v2_active_hash_checks_v1074()
    persistence_ok=bool(cut_ok and cut_age>=60.0)
    guard_snap=read_json(BOT_DIR/GUARD_RUNTIME_STATUS_FILE)
    resource=(guard_snap.get('resource_contract_v1074') if isinstance(guard_snap,dict) else {}) or {}
    resource_ok=bool(resource.get('canonical_owner')=='guard_single_runtime_status_writer' and resource.get('same_source_for_main_guard_boards') is True)
    overall=bool(cut_ok and persistence_ok and runtime_ok and hash_ok and resource_ok)
    checks=[
        f"{'✅' if cut_ok else '⚠️'} cutover status: ok={cut.get('ok') if isinstance(cut,dict) else None} rollback={len(cut.get('rollback') or []) if isinstance(cut,dict) else '-'}",
        f"{'✅' if persistence_ok else '⚠️'} post-cutover persistence: age={cut_age:.1f}s / required≥60s",
        *runtime_rows,
        *hash_rows,
        f"{'✅' if resource_ok else '⚠️'} resource owner: {resource.get('canonical_owner') or '-'} / main·guard same source={resource.get('same_source_for_main_guard_boards')}",
    ]
    proof_digest=hashlib.sha256(json.dumps({'cut':cut_ok,'age':round(cut_age,1),'runtime':runtime_rows,'hash':hash_rows,'resource':resource_ok},ensure_ascii=False,sort_keys=True).encode()).hexdigest()
    status_obj={'schema':'core_v2_closeout_status_v1074','time':now(),'ts':time.time(),'ok':overall,'cutover_ok':cut_ok,'persistence_ok':persistence_ok,'runtime_ok':runtime_ok,'hash_ok':hash_ok,'resource_owner_ok':resource_ok,'proof_digest':proof_digest,'auto_buy':False,'checks':checks}
    write_json(CORE_V2_CLOSEOUT_STATUS_V1074,status_obj)
    if overall:
        _core_v2_closeout_append_v1074('DONE','CORE V2 v1071 cutover remained exact after subsequent cycles; all five runtimes, hashes, Risk-Paper contract, candidate writer, exact 0/0/0, resource owner, and auto-buy OFF were re-proved.','System/runtime closeout complete. Next work must be a separate resource/disk optimization version; strategy thresholds remain locked.')
        write_json(CORE_V2_CLOSEOUT_MARKER_V1074,status_obj)
    else:
        _core_v2_closeout_append_v1074('CHECK','CORE V2 closeout verification did not fully pass.','Correct only the displayed runtime/hash/resource proof item; do not change strategy or ledgers.')
    return '\n'.join([
        f"🧬 {'✅' if overall else '⚠️'} CORE V2 시스템 마감 · v1074",
        f"- 판정: {'DONE' if overall else 'CHECK'}",
        '- 범위: runtime·hash·Risk–Paper·exact·resource owner·장부 봉인',
        '- 전략 수치 변경 0 / 원장 삭제 0 / 자동매수 OFF','',
        '[증명]',*checks,'',
        '[장부]',
        f"- issue/change append: {'DONE' if overall else 'CHECK'}",
        '- 과거 실패·미적용 기록은 삭제하지 않음',
        f"- proof digest: {proof_digest[:16]}",
    ])


# -----------------------------------------------------------------------------
# v1262 - live ledger append/fsync/tail proof command
# -----------------------------------------------------------------------------
V1262_EXPECTED_ISSUE_EVENTS = (
    ('ISSUE-V1261-V1211-BASELINE-IDENTITY', 'OPEN'),
    ('ISSUE-V1261-MISSED-CANDIDATE-KEY-CHURN', 'OPEN'),
    ('ISSUE-V1261-PROFIT-WIDTH-REGRESSION-AUDIT', 'OPEN'),
    ('ISSUE-V1261-CURRENT-UNIFIED-NO-SAMPLE', 'OBSERVED'),
    ('ISSUE-FLOW-09-GATE-EVIDENCE', 'OBSERVED_SERVER'),
    ('ISSUE-FLOW-18-REVIEW-EVIDENCE', 'OBSERVED_SERVER'),
    ('ISSUE-STRATEGY-HANDOFF-OVER-15S', 'OBSERVED_SERVER'),
    ('ISSUE-STRUCTURE-SOURCE-MISSING-NONS1', 'OBSERVED_SERVER'),
    ('ISSUE-V1261-V1211-BASELINE-IDENTITY', 'FIX_LOCAL_DONE_V1262'),
    ('ISSUE-V1261-MISSED-CANDIDATE-KEY-CHURN', 'FIX_LOCAL_DONE_V1262'),
)
V1262_EXPECTED_CHANGE_EVENTS = (
    ('CHANGE-V1261-SERVER-HANDOFF-AND-ISSUE-SYNC', 'START'),
    ('CHANGE-V1261-SERVER-HANDOFF-AND-ISSUE-SYNC', 'PACKAGE_VERIFY'),
    ('CHANGE-V1262-SCORE-TRUTH-MISSED-SEMANTIC', 'START'),
    ('CHANGE-V1262-SCORE-TRUTH-MISSED-SEMANTIC', 'LOCAL_VERIFY'),
)

def _v1262_tail_json_objects(path: Path, max_bytes: int = 4 * 1024 * 1024) -> tuple[list[dict], dict]:
    meta = {'exists': path.exists(), 'size': 0, 'mtime': None, 'bad_json_tail': 0}
    if not path.exists() or not path.is_file():
        return [], meta
    stat = path.stat()
    meta['size'] = int(stat.st_size)
    meta['mtime'] = float(stat.st_mtime)
    with path.open('rb') as fh:
        if stat.st_size > max_bytes:
            fh.seek(stat.st_size - max_bytes)
            fh.readline()
        raw = fh.read()
    rows=[]
    for line in raw.decode('utf-8', errors='replace').splitlines():
        if not line.strip():
            continue
        try:
            obj=json.loads(line)
        except Exception:
            meta['bad_json_tail'] += 1
            continue
        if isinstance(obj,dict):
            rows.append(obj)
    return rows, meta


def gledger_v1262_text() -> str:
    issue_path = BOT_DIR / 'issue_ledger.jsonl'
    change_path = BOT_DIR / 'change_verify_ledger.jsonl'
    issue_rows, issue_meta = _v1262_tail_json_objects(issue_path)
    change_rows, change_meta = _v1262_tail_json_objects(change_path)
    issue_events = {(str(row.get('issue_id') or '').strip(), str(row.get('event') or '').strip()) for row in issue_rows}
    change_events = {(str(row.get('change_id') or row.get('issue_id') or '').strip(), str(row.get('event') or '').strip()) for row in change_rows}
    missing_issue = [value for value in V1262_EXPECTED_ISSUE_EVENTS if value not in issue_events]
    missing_change = [value for value in V1262_EXPECTED_CHANGE_EVENTS if value not in change_events]
    state = 'DONE' if not missing_issue and not missing_change and issue_meta['bad_json_tail'] == 0 and change_meta['bad_json_tail'] == 0 else 'CHECK'
    lines = [
        f'📚 v1262 live 장부 append·fsync·tail 증거 · {VERSION}',
        f'- 상태: {state}',
        f"- issue tail: {len(issue_rows)}행 / 파일 {issue_meta['size']}B / bad JSON {issue_meta['bad_json_tail']}",
        f"- change tail: {len(change_rows)}행 / 파일 {change_meta['size']}B / bad JSON {change_meta['bad_json_tail']}",
        f'- issue 사건 확인: {len(V1262_EXPECTED_ISSUE_EVENTS)-len(missing_issue)}/{len(V1262_EXPECTED_ISSUE_EVENTS)}',
        f'- change 사건 확인: {len(V1262_EXPECTED_CHANGE_EVENTS)-len(missing_change)}/{len(V1262_EXPECTED_CHANGE_EVENTS)}',
        '- append writer 계약: flock → append → flush → os.fsync → unlock',
        '- 이 명령은 live 원장을 읽기만 하며 수정·재작성하지 않음',
    ]
    if missing_issue:
        lines.append('- issue tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_issue))
    if missing_change:
        lines.append('- change tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_change))
    lines.append('- DONE은 실제 live tail에서 모든 사건을 찾았을 때만 표시')
    return '\n'.join(lines)


V1265_EXPECTED_ISSUE_EVENTS = (
    ('V1265-UNIFIED-CONTRACT-HANDOFF', 'OPEN'),
    ('V1265-UNIFIED-CONTRACT-HANDOFF', 'DONE_LOCAL'),
)
V1265_EXPECTED_CHANGE_EVENTS = (
    ('V1265-UNIFIED-CONTRACT-HANDOFF', 'START'),
    ('V1265-UNIFIED-CONTRACT-HANDOFF', 'LOCAL_VERIFY'),
)


def gledger_v1265_text() -> str:
    issue_path = BOT_DIR / 'issue_ledger.jsonl'
    change_path = BOT_DIR / 'change_verify_ledger.jsonl'
    issue_rows, issue_meta = _v1262_tail_json_objects(issue_path)
    change_rows, change_meta = _v1262_tail_json_objects(change_path)
    issue_events = {(str(row.get('issue_id') or '').strip(), str(row.get('event') or '').strip()) for row in issue_rows}
    change_events = {(str(row.get('change_id') or row.get('issue_id') or '').strip(), str(row.get('event') or '').strip()) for row in change_rows}
    missing_issue = [value for value in V1265_EXPECTED_ISSUE_EVENTS if value not in issue_events]
    missing_change = [value for value in V1265_EXPECTED_CHANGE_EVENTS if value not in change_events]
    state = 'DONE' if not missing_issue and not missing_change and issue_meta['bad_json_tail'] == 0 and change_meta['bad_json_tail'] == 0 else 'CHECK'
    lines = [
        f'📚 v1265 live 장부 append·fsync·tail 증거 · {VERSION}',
        f'- 상태: {state}',
        f"- issue tail: {len(issue_rows)}행 / 파일 {issue_meta['size']}B / bad JSON {issue_meta['bad_json_tail']}",
        f"- change tail: {len(change_rows)}행 / 파일 {change_meta['size']}B / bad JSON {change_meta['bad_json_tail']}",
        f'- issue 사건 확인: {len(V1265_EXPECTED_ISSUE_EVENTS)-len(missing_issue)}/{len(V1265_EXPECTED_ISSUE_EVENTS)}',
        f'- change 사건 확인: {len(V1265_EXPECTED_CHANGE_EVENTS)-len(missing_change)}/{len(V1265_EXPECTED_CHANGE_EVENTS)}',
        '- append writer 계약: flock → append → flush → os.fsync → unlock',
        '- 이 명령은 live 원장을 읽기만 하며 수정·재작성하지 않음',
    ]
    if missing_issue:
        lines.append('- issue tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_issue))
    if missing_change:
        lines.append('- change tail 누락: ' + ', '.join(f'{a}/{b}' for a,b in missing_change))
    lines.append('- DONE은 실제 live tail에서 모든 v1265 사건을 찾았을 때만 표시')
    return '\n'.join(lines)


def handle_single_command(text: str, post_commands=None) -> str:
    parts = text.strip().split()
    cmd = parts[0].lower() if parts else ""
    if "@" in cmd:
        cmd = cmd.split("@", 1)[0]
    args = parts[1:]

    if cmd in ("/gmenu_sync", "/gsync_menu", "/gcommands", "/gcommand_menu"):
        return sync_guard_menu_text()
    if cmd in ("/start", "/help", "/gmenu", "/menu"):
        return help_text()
    if cmd in ("/guard", "/status", "/check"):
        return service_status()
    if cmd in ("/gdeploy", "/version", "/upgradestatus"):
        return deploy_status()
    if cmd in ("/glog", "/lastlog"):
        n = 80
        if args and args[0].isdigit():
            n = max(20, min(300, int(args[0])))
        return glog(n)
    if cmd in ("/grestart", "/restart"):
        return restart_service()
    if cmd in ("/gpaper_reset", "/gpaperreset", "/gpaper_relink", "/gpaper_reconnect"):
        return gpaper_reset_text()
    if cmd in ("/gpaper_restart", "/gpaperrestart"):
        return gpaper_restart_text()
    if cmd in ("/gpaperlog", "/paperlog"):
        n = 80
        if args and args[0].isdigit():
            n = max(20, min(300, int(args[0])))
        return gpaper_log(n)
    if cmd in ("/gpaper_state", "/gpaperstate"):
        return gpaper_state_text()
    if cmd in ("/gpaper_service", "/gpaperservice"):
        return gpaper_service_text()
    if cmd in ("/gexternal_state", "/gexternal", "/gext_state"):
        return gexternal_state_text()
    if cmd in ("/gws_state", "/gwsstate"):
        return gws_state_text()
    if cmd in ("/gws_start", "/gwsstart"):
        return gws_start_text()
    if cmd in ("/gws_stop", "/gwsstop"):
        return gws_stop_text()
    if cmd in ("/gws_restart", "/gwsrestart"):
        return gws_restart_text()
    if cmd in ("/gupgrade_menu", "/gup_menu", "/upgrade_menu"):
        return gupgrade_menu_text()
    if cmd in ("/gupgrade_main", "/gmain_upgrade", "/gmain_apply"):
        force, explicit = parse_upgrade_force_explicit(args)
        return gupgrade_component_text("main", force=force, explicit=explicit)
    if cmd in ("/gupgrade_paper", "/gpaper_upgrade", "/gpaper_apply"):
        force, explicit = parse_upgrade_force_explicit(args)
        return gupgrade_component_text("paper", force=force, explicit=explicit)
    if cmd in ("/gupgrade_ws", "/gws_upgrade", "/gwsupgrade", "/gws_apply"):
        force, explicit = parse_upgrade_force_explicit(args)
        return gupgrade_component_text("ws", force=force, explicit=explicit)
    if cmd in ("/gwslog", "/gws_log"):
        n = 80
        if args and args[0].isdigit():
            n = max(20, min(300, int(args[0])))
        return gws_log(n)
    if cmd in ("/gws_import", "/gwsimport"):
        ok, notes = ws_import_check()
        icon = "✅" if ok else "❌"
        return "\n".join([f"{icon} 웹소켓 import 검사 /gws_import"] + [f"- {x}" for x in notes])
    if cmd in ("/gmicro_state", "/gmicrostate"):
        return gmicro_state_text()
    if cmd in ("/gmicro_start", "/gmicrostart"):
        return gmicro_start_text()
    if cmd in ("/gmicro_stop", "/gmicrostop"):
        return gmicro_stop_text()
    if cmd in ("/gmicro_restart", "/gmicrorestart"):
        return gmicro_restart_text()
    if cmd in ("/gupgrade_micro", "/gmicro_upgrade", "/gmicroupgrade", "/gmicro_apply"):
        force, explicit = parse_upgrade_force_explicit(args)
        return gupgrade_component_text("micro", force=force, explicit=explicit)
    if cmd in ("/gmicrolog", "/gmicro_log"):
        n = 80
        if args and args[0].isdigit():
            n = max(20, min(300, int(args[0])))
        return gmicro_log(n)
    if cmd in ("/gupgrade_guard", "/gguard_upgrade", "/guard_upgrade"):
        force, explicit = parse_upgrade_force_explicit(args)
        return gupgrade_component_text("guard", force=force, explicit=explicit)
    if cmd in ("/gcore_v2_verify", "/gcore_verify"):
        return gcore_v2_verify_text()
    if cmd in ("/gcore_v2_cutover", "/gcore_cutover"):
        return gcore_v2_cutover_text()
    if cmd in ("/gcore_v2_closeout", "/gcore_closeout"):
        return gcore_v2_closeout_text()
    if cmd in ("/gcore_shadow", "/gcore_v2_shadow", "/gshadow_core"):
        return gcore_shadow_text(args)
    if cmd in ("/gdeep_audit", "/gdisk_audit", "/gworker_audit", "/gruntime_audit", "/gaudit"):
        sec = 20
        if args and str(args[0]).isdigit():
            sec = max(5, min(30, int(args[0])))
        return gdeep_audit_text(sample_sec=sec)
    if cmd in ("/gresource_owner", "/gresource_audit", "/gprofile_owner", "/g1076"):
        sec = 20
        if args and str(args[0]).isdigit():
            sec = max(5, min(30, int(args[0])))
        return gresource_owner_text_v1076(sample_sec=sec)
    if cmd in ("/gstrategy_writer_v1077", "/gwriter_verify", "/g1077"):
        sec = 35
        if args and str(args[0]).isdigit():
            sec = max(20, min(60, int(args[0])))
        return gstrategy_writer_verify_text_v1077(sample_sec=sec)
    if cmd in ("/gstrategy_overlay_v1078", "/goverlay_verify", "/g1078"):
        sec = 95
        if args and str(args[0]).isdigit():
            sec = max(60, min(150, int(args[0])))
        return gstrategy_overlay_verify_text_v1078(sample_sec=sec)
    if cmd in ("/ghotpath_v1079", "/gintegrated_perf_v1079", "/g1079"):
        sec = 360
        if args and str(args[0]).isdigit():
            sec = max(120, min(720, int(args[0])))
        return ghotpath_verify_text_v1079(sample_sec=sec)
    if cmd in ('/gdisk_bound_v1080','/gtrace_bound_v1080','/gdisk1080','/g1080'):
        sec = 120
        if args and str(args[0]).isdigit():
            sec = max(30,min(300,int(args[0])))
        return gdisk_bound_verify_text_v1080(sample_sec=sec)
    if cmd in ('/gfinal_owner_v1081','/gowner_closeout_v1081','/g1081'):
        sec = 180
        if args and str(args[0]).isdigit():
            sec = max(60,min(480,int(args[0])))
        return gfinal_owner_verify_text_v1081(sample_sec=sec)
    if cmd in ('/gsystem_closeout_v1082','/gfinal_system_v1082','/g1082'):
        sec = 240
        if args and str(args[0]).isdigit():
            sec = max(120,min(600,int(args[0])))
        return gsystem_closeout_verify_text_v1082(sample_sec=sec)
    if cmd in ('/gpaper_memory_owner_v1083','/gpaper_mem_v1083','/g1083'):
        sec = 180
        if args and str(args[0]).isdigit():
            sec = max(60,min(360,int(args[0])))
        return gpaper_memory_owner_probe_text_v1083(sample_sec=sec)
    if cmd in ('/gpaper_allocator_v1084','/gpaper_mem_v1084','/g1084'):
        sec = 240
        if args and str(args[0]).isdigit():
            sec = max(120,min(600,int(args[0])))
        return gpaper_allocator_probe_text_v1084(sample_sec=sec)
    if cmd in ('/gpaper_memory_fix_v1085','/gpaper_reader_v1085','/g1085'):
        sec = 180
        if args and str(args[0]).isdigit():
            sec = max(90,min(480,int(args[0])))
        return gpaper_memory_fix_verify_text_v1085(sample_sec=sec)
    if cmd == '/gsystem_closeout_v1086':
        sec = 240
        if args and str(args[0]).isdigit():
            sec = max(120,min(600,int(args[0])))
        return gsystem_final_closeout_text_v1086(sample_sec=sec)
    if cmd in ('/gpaper_performance_fix_v1092','/gpaper_perf_v1092','/g1092'):
        sec = 180
        if args and str(args[0]).isdigit():
            sec = max(90,min(480,int(args[0])))
        return gpaper_performance_fix_verify_text_v1092(sample_sec=sec)
    if cmd == '/gquality_spine_verify':
        return gquality_spine_verify_text(args)
    if cmd in ('/gquality_open_audit_v1093','/gwinrate_audit_v1093','/gquality_open_v1093','/g1093'):
        return gquality_open_audit_v1093_text()
    if cmd in ("/gs1_zero_audit", "/gs1_audit", "/g1214"):
        return gs1_zero_audit_text_v1214()
    if cmd in ("/gstructure_missing_audit", "/gstructure_audit", "/g1216"):
        return gstructure_missing_audit_text_v1216()
    if cmd in ("/gentry_geometry_audit", "/grr_target_audit", "/ggeometry_audit", "/g1219"):
        return gentry_geometry_audit_text_v1219()
    if cmd in ("/gentry_flow_audit", "/gflow_contract", "/g1221"):
        return gentry_flow_audit_text_v1221()
    if cmd in ("/gstructure_pairing_audit", "/gpairing_audit", "/g1222"):
        return gstructure_pairing_audit_text_v1222()
    if cmd in ("/gpair_exclusion_audit", "/gpair_exclusion", "/gincomplete_pair_audit", "/g1232"):
        return gpair_exclusion_audit_text_v1232()
    if cmd in ("/gexport_profitability", "/gprofitability_export", "/gexport_profit"):
        return gexport_profitability_text_v1129()
    if cmd in ('/gops_refresh','/gops_map','/gmap_refresh','/g1087'):
        return gops_refresh_text()
    if cmd in ("/gstorage_fix", "/gstorage_cleanup", "/gops_cleanup"):
        dry = bool(args and str(args[0]).lower() in {"dry","preview","check"})
        return gstorage_fix_text(dry_run=dry)
    if cmd in ("/gopen_policy_v1264", "/gopen50", "/gcapacity"):
        return gopen_policy_v1264_text()
    if cmd in ("/gcontract_v1265", "/gcontract", "/gseal"):
        return gcontract_v1265_text()
    if cmd in ("/gledger_v1265", "/gledger1265"):
        return gledger_v1265_text()
    if cmd in ("/gstructure_case_audit", "/gstructure_case", "/gcase1266"):
        return gstructure_case_audit_text_v1266()
    if cmd in ("/gledger_v1266", "/gledger1266"):
        return gledger_v1266_text()
    if cmd in ("/gledger_v1267", "/gledger1267"):
        return gledger_v1267_text()
    if cmd in ("/gledger_v1269", "/gledger1269"):
        return gledger_v1269_text()
    if cmd in ("/gworker_state", "/gworkers", "/gworkerstate"):
        return gworker_state_text()
    if cmd in ("/gscanner_state", "/gscanner"):
        return gworker_state_text("scanner")
    if cmd in ("/gcandle_state", "/gcandle"):
        return gworker_state_text("candle")
    if cmd in ("/gmarket_state", "/gmarket", "/gregime_state"):
        return gworker_state_text("market")
    if cmd in ("/gfeature_state", "/gfeature"):
        return gworker_state_text("feature")
    if cmd in ("/gorderflow_state", "/gorderflow"):
        return gworker_state_text("orderflow")
    if cmd in ("/grisk_state", "/grisk"):
        return gworker_state_text("risk")
    if cmd in ("/gstrategy_state", "/gstrategy"):
        return gworker_state_text("strategy")
    if cmd in ("/gtarget_state", "/gtarget", "/gtarget_router_state"):
        return gworker_state_text("target_router")
    if cmd in ("/greview_state", "/greview"):
        return gworker_state_text("review")
    if cmd in ("/gexact_replay", "/gexactreplay", "/gexact_replay_worker"):
        return gworker_state_text("exact_replay")
    if cmd in ("/gstrategy_upgrade", "/gupgrade_strategy"):
        force, explicit = parse_upgrade_force_explicit(args)
        return format_worker_apply_result(apply_worker_latest("strategy", force=force, explicit=explicit, restart=True))
    if cmd in ("/gorderflow_upgrade", "/gupgrade_orderflow"):
        force, explicit = parse_upgrade_force_explicit(args)
        return format_worker_apply_result(apply_worker_latest("orderflow", force=force, explicit=explicit, restart=True))
    if cmd in ("/gtarget_upgrade", "/gupgrade_target", "/gtarget_router_upgrade"):
        force, explicit = parse_upgrade_force_explicit(args)
        return format_worker_apply_result(apply_worker_latest("target_router", force=force, explicit=explicit, restart=True))
    if cmd in ("/gworker_upgrade", "/gupgrade_worker", "/gupgrade_workers"):
        force, explicit = parse_upgrade_force_explicit(args)
        return gworker_upgrade_text(force=force)
    if cmd in ("/gworker_restart", "/gworkers_restart"):
        return gworker_restart_text()
    if cmd in ("/gscanner_restart",):
        return gworker_restart_text("scanner")
    if cmd in ("/gcandle_restart",):
        return gworker_restart_text("candle")
    if cmd in ("/gmarket_restart",):
        return gworker_restart_text("market")
    if cmd in ("/gfeature_restart",):
        return gworker_restart_text("feature")
    if cmd in ("/gorderflow_restart",):
        return gworker_restart_text("orderflow")
    if cmd in ("/grisk_restart",):
        return gworker_restart_text("risk")
    if cmd in ("/gstrategy_restart",):
        return gworker_restart_text("strategy")
    if cmd in ("/greview_restart",):
        return gworker_restart_text("review")
    if cmd in ("/gworkerlog", "/gworker_log"):
        name = args[0].lower() if args else "strategy"
        n = int(args[1]) if len(args) > 1 and args[1].isdigit() else 80
        return gworker_log_text(name, n)
    if cmd in ("/gguard_restart", "/guard_restart"):
        rc, out = run(["systemctl", "restart", GUARD_SERVICE], timeout=30)
        return f"🔁 가드봇 재시작 요청\n- rc: {rc}\n- service: {GUARD_SERVICE}\n- 다음 확인: /guard"
    if cmd in ("/gunlock", "/unlock"):
        return unlock_deploy()
    if cmd in ("/gbackups", "/backups"):
        return list_backups_text()
    if cmd in ("/grollback", "/rollback"):
        return rollback_latest()
    if cmd in ("/gcleanup", "/cleanup", "/gdisk_cleanup"):
        return cleanup_text(dry_run=False)
    if cmd in ("/gledger_v1262", "/gledger1262"):
        return gledger_v1262_text()
    if cmd in ("/grelease_verify", "/gverify_release", "/gverify"):
        return grelease_verify_text()
    if cmd in ("/grelease_last", "/glast_release"):
        return grelease_last_text()
    if cmd in ("/gupgrade_bundle", "/gbundle", "/gapply_bundle"):
        force, explicit = parse_upgrade_force_explicit(args)
        lowered_args = {str(a).lower() for a in args}
        skip_git = bool(lowered_args & {"nofetch", "local", "skipgit", "skip_git"})
        return gupgrade_bundle_text(force=force, explicit=explicit, skip_git=skip_git, post_commands=post_commands)
    if cmd in ("/gupgrade", "/gupgrade_all", "/apply_latest", "/upgradebot"):
        force, explicit = parse_upgrade_force_explicit(args)
        lowered_args = {str(a).lower() for a in args}
        skip_git = bool(lowered_args & {"nofetch", "local", "skipgit", "skip_git"})
        # v2.5.65: /gupgrade도 /gupgrade_bundle와 같은 단일 bundle 본선만 탄다.
        # repo 전체 git fetch/reset 경로와 stale/local fallback 검문은 기본 적용 경로에서 제거한다.
        return gupgrade_bundle_text(force=force, explicit=explicit, skip_git=skip_git, post_commands=post_commands)
    return "알 수 없는 명령어야.\n\n" + help_text()

def handle_command(text: str) -> str:
    lines = _extract_guard_command_lines(text)
    if len(lines) <= 1:
        return handle_single_command(text)

    upgrade_rows = [(idx, line) for idx, line in enumerate(lines) if _guard_command_name(line) in _BUNDLE_UPGRADE_COMMANDS_V1030]
    if upgrade_rows:
        if len(upgrade_rows) != 1:
            return "📦 ❌ 자동 묶음 중단\n- bundle 업그레이드 명령은 한 메시지에 1개만 허용"
        upgrade_idx, upgrade_line = upgrade_rows[0]
        remaining = [line for idx, line in enumerate(lines) if idx != upgrade_idx]
        remaining = _normalize_post_upgrade_commands_v1030(remaining)
        out = [
            "📦 bundle 우선 자동 묶음 접수",
            f"- bundle 업그레이드 1개를 먼저 실행",
            f"- 완료 후 나머지 {len(remaining)}개를 원래 순서대로 각 1회 실행",
            "- 업그레이드 실패 시 나머지 실행 안 함",
        ]
        try:
            body = handle_single_command(upgrade_line, post_commands=remaining)
        except Exception as exc:
            body = f"오류: {exc.__class__.__name__}: {exc}"
        out.append(f"\n[업그레이드] {_guard_command_name(upgrade_line)}\n{body}")
        active_job = _load_release_job()
        if active_job:
            queued = _normalize_post_upgrade_commands_v1030(active_job.get('post_commands') or [])
            out.append(f"\n[이어실행 예약] {len(queued)}개\n- 새 가드 MainPID 안정화 후 bundle 나머지 적용·검수 성공 시 딱 1번 실행")
            return "\n".join(out)
        upgrade_ok = "❌" not in str(body) and "예외" not in str(body) and "중단" not in str(body)
        if not upgrade_ok:
            out.append("\n[이어실행] 실행 안 함\n- 업그레이드 실패 또는 중단")
            return "\n".join(out)
        refresh_note = refresh_guard_runtime_before_followup_v1033('same_process_bundle')
        out.append(f"\n[runtime snapshot]\n- {refresh_note}")
        follow_ok, follow_text = _execute_guard_commands_once_v1030(remaining)
        out.append("\n" + follow_text)
        if not follow_ok:
            out.append("\n⚠️ 일부 이어실행 명령 확인 필요")
        return "\n".join(out)

    out = ["📦 자동 묶음 명령 접수", "- /g배치 없이 여러 줄 명령을 감지", f"- 실행 {len(lines)}개"]
    total = len(lines)
    for idx, line in enumerate(lines, start=1):
        name = _guard_command_name(line)
        try:
            body = handle_single_command(line)
        except Exception as exc:
            body = f"오류: {exc.__class__.__name__}: {exc}"
        out.append(f"\n[{idx}/{total}] {name}\n{body}")
    return "\n".join(out)

def _v1228_disk_pressure_level(free_bytes: int) -> str:
    free = int(free_bytes or 0)
    if free < DISK_CRITICAL_FREE_BYTES_V1228:
        return 'CRITICAL'
    if free < DISK_DANGER_FREE_BYTES_V1228:
        return 'DANGER'
    if free < DISK_WARNING_FREE_BYTES_V1228:
        return 'WARNING'
    return 'NORMAL'

def maybe_run_auto_retention_v1196(force: bool = False) -> dict:
    """Periodic disk hygiene owner. Never deletes core trading ledgers.

    v1228 adds one-time policy migration, aged orphan-temp cleanup, automatic
    system-log rotation under low free space, and staged disk pressure output.
    """
    nowv = time.time()
    before = server_resource_snapshot()
    state = read_json(BOT_DIR / AUTO_RETENTION_STATE_V1196)
    state = state if isinstance(state, dict) else {}
    last_run = float(state.get('last_run_ts') or 0.0)
    last_system_run = float(state.get('last_system_log_run_ts_v1228') or 0.0)
    migration_due = state.get('auto_storage_policy_v1228') is not True
    low_free = float(before.get('disk_free') or 0.0) < AUTO_RETENTION_LOW_FREE_BYTES_V1196
    low_free_due = bool(low_free and nowv - last_run >= AUTO_RETENTION_LOW_FREE_RUN_INTERVAL_SEC_V1196)
    due = nowv - last_run >= AUTO_RETENTION_RUN_INTERVAL_SEC_V1196
    should_run = bool(force or migration_due or low_free_due or due)
    if not should_run:
        return {
            'ran': False, 'reason': 'not_due', 'before': before, 'after': before, 'state': state,
            'pressure_level_v1228': _v1228_disk_pressure_level(int(before.get('disk_free') or 0)),
        }
    result = run_retention_cleanup(dry_run=False)
    mid = server_resource_snapshot()
    system_due = bool(force or migration_due or low_free or nowv - last_system_run >= AUTO_RETENTION_SYSTEM_LOG_INTERVAL_SEC_V1228)
    system_result = _v928_system_log_fix(dry_run=False) if system_due else {'skipped':True,'errors':0}
    after = server_resource_snapshot()
    payload = {
        'schema': 'guard_auto_retention_v1228',
        'version': VERSION,
        'last_run_ts': nowv,
        'last_run_at': now(),
        'last_system_log_run_ts_v1228': nowv if system_due else last_system_run,
        'trigger': 'force' if force else ('policy_migration_v1228' if migration_due else ('low_free' if low_free else 'interval')),
        'before_free': int(before.get('disk_free') or 0),
        'mid_free': int(mid.get('disk_free') or 0),
        'after_free': int(after.get('disk_free') or 0),
        'reported_freed': int(result.get('freed') or 0),
        'system_reported_freed_v1228': int(system_result.get('journal_freed') or 0) + int(system_result.get('var_log_freed') or 0),
        'deleted': int(result.get('deleted') or 0),
        'truncated': int(result.get('truncated') or 0),
        'compressed': int(result.get('compressed') or 0),
        'errors': int(result.get('errors') or 0) + int(system_result.get('errors') or 0),
        'system_log_maintenance_v1228': system_result,
        'pressure_level_v1228': _v1228_disk_pressure_level(int(after.get('disk_free') or 0)),
        'auto_storage_policy_v1228': True,
        'protected_core_ledgers': ['OPEN','CLOSED','trade_log','decision','exact','change_verify','issue','good-S2'],
        'core_ledger_deleted': False,
        'auto_buy': False,
    }
    write_json(BOT_DIR / AUTO_RETENTION_STATE_V1196, payload)
    return {'ran': True, 'before': before, 'mid': mid, 'after': after, 'result': result, 'system_result': system_result, 'state': payload, 'pressure_level_v1228': payload['pressure_level_v1228']}

def _v1228_maybe_send_disk_alert(retention: dict) -> None:
    after = retention.get('after') if isinstance(retention.get('after'), dict) else retention.get('before') or {}
    free_bytes = int(after.get('disk_free') or 0)
    level = _v1228_disk_pressure_level(free_bytes)
    state_path = BOT_DIR / DISK_ALERT_STATE_V1228
    previous = read_json(state_path)
    previous = previous if isinstance(previous, dict) else {}
    previous_level = str(previous.get('level') or 'NORMAL')
    last_notice = float(previous.get('last_notice_ts') or 0.0)
    nowv = time.time()
    rr = retention.get('result') if isinstance(retention.get('result'), dict) else {}
    system = retention.get('system_result') if isinstance(retention.get('system_result'), dict) else {}
    freed = int(rr.get('freed') or 0) + int(system.get('journal_freed') or 0) + int(system.get('var_log_freed') or 0)
    should_notice = False
    if level != 'NORMAL':
        cooldown = int(DISK_ALERT_COOLDOWN_SEC_V1228.get(level) or 6 * 3600)
        should_notice = bool(level != previous_level or nowv - last_notice >= cooldown)
    elif previous_level != 'NORMAL':
        should_notice = True
    elif retention.get('ran') and freed >= AUTO_RETENTION_NOTIFY_FREED_BYTES_V1196:
        should_notice = bool(nowv - last_notice >= AUTO_RETENTION_RUN_INTERVAL_SEC_V1196)
    if should_notice:
        icon = {'WARNING':'⚠️','DANGER':'🟠','CRITICAL':'❌','NORMAL':'✅'}.get(level,'⚠️')
        title = '디스크 여유 회복' if level == 'NORMAL' else f'디스크 용량 {level}'
        send(ALLOWED_CHAT_ID, '\n'.join([
            f'{icon} {title}',
            f'- 남음 {_fmt_bytes(free_bytes)} / 단계 기준 4GB 주의 · 2GB 위험 · 1GB 긴급',
            f"- 자동정리: {'실행' if retention.get('ran') else '대기'} / 확보 추정 {_fmt_bytes(freed)}",
            f"- 오류 {int((retention.get('state') or {}).get('errors') or 0)}",
            '- OPEN/CLOSED/trade_log/decision/exact/change/issue/good-S2 원장 삭제 0',
        ]))
        previous = {'schema':'guard_disk_alert_v1228','version':VERSION,'level':level,'free_bytes':free_bytes,'last_notice_ts':nowv,'last_notice_at':now(),'auto_buy':False}
        write_json(state_path, previous)
    elif previous_level != level:
        previous.update({'level':level,'free_bytes':free_bytes,'updated_ts':nowv,'updated_at':now()})
        write_json(state_path, previous)


def main():
    print(f"[{now()}] guard bot started. service={MAIN_SERVICE} dir={BOT_DIR} version={VERSION}", flush=True)
    offset = load_guard_offset()
    offset = init_guard_offset_if_empty(offset)
    last_active = None
    last_notify = 0
    main_active_timeout_count = 0
    last_timeout_notify = 0
    set_commands()
    try:
        reconcile_main_markers_v1196()
    except Exception as marker_exc:
        print(f"[{now()}] main marker reconcile error: {marker_exc.__class__.__name__}: {marker_exc}", flush=True)
    # v1005: never apply a bundle remainder in the startup section. Start the
    # Telegram loop and confirm this process is the stable systemd MainPID first.
    send_guard_start_notice()
    guard_boot_mono = time.monotonic()
    last_release_resume_try = 0.0
    last_release_delivery_try = 0.0
    last_runtime_snapshot_write = 0.0
    last_core_v2_shadow_write_v1064 = 0.0
    last_ops_map_refresh = 0.0
    last_auto_retention_check_v1196 = 0.0
    last_auto_retention_notify_v1196 = 0.0

    while True:
        try:
            if time.time() - last_runtime_snapshot_write >= GUARD_RUNTIME_WRITE_INTERVAL_SEC:
                try:
                    write_guard_runtime_snapshot_v1010('periodic_loop'); last_runtime_snapshot_write=time.time()
                except Exception as runtime_exc:
                    print(f"[{now()}] runtime snapshot error: {runtime_exc.__class__.__name__}: {runtime_exc}",flush=True)
            if time.time() - last_ops_map_refresh >= OPS_MAP_REFRESH_INTERVAL_SEC:
                try:
                    refresh_ops_map_snapshot('periodic_guard'); last_ops_map_refresh=time.time()
                except Exception as ops_map_exc:
                    last_ops_map_refresh=time.time()
                    print(f"[{now()}] ops map error: {ops_map_exc.__class__.__name__}: {ops_map_exc}", flush=True)
            if time.time() - last_core_v2_shadow_write_v1064 >= CORE_V2_FULL_SHADOW_INTERVAL_SEC_V1064:
                try:
                    _v1064_run_full_shadow_cycle(); last_core_v2_shadow_write_v1064 = time.time()
                except Exception as core_shadow_exc:
                    last_core_v2_shadow_write_v1064 = time.time()
                    print(f"[{now()}] core v2 full shadow error: {core_shadow_exc.__class__.__name__}: {core_shadow_exc}", flush=True)
            if time.time() - last_auto_retention_check_v1196 >= AUTO_RETENTION_CHECK_INTERVAL_SEC_V1196 and not _load_release_job():
                last_auto_retention_check_v1196 = time.time()
                try:
                    retention = maybe_run_auto_retention_v1196(force=False)
                    _v1228_maybe_send_disk_alert(retention)
                except Exception as retention_exc:
                    print(f"[{now()}] auto retention error: {retention_exc.__class__.__name__}: {retention_exc}", flush=True)
            # The new guard applies the remainder only after it has stayed alive
            # for 6 seconds in the normal loop. No pending→inflight rename.
            if time.monotonic() - guard_boot_mono >= 6.0 and time.time() - last_release_resume_try >= 3.0:
                last_release_resume_try = time.time()
                if _load_release_job():
                    resume_guard_release_job()
            if _release_final_pending_path().exists() and time.time() - last_release_delivery_try >= 15.0:
                last_release_delivery_try = time.time()
                _deliver_pending_release_result_once()
            params = {"timeout": 25}
            if offset is not None:
                params["offset"] = offset
            data = api("getUpdates", params, timeout=35)

            for upd in data.get("result", []):
                offset = upd.get("update_id", 0) + 1
                save_guard_offset(offset, "before_handle_update")
                msg = upd.get("message") or upd.get("edited_message") or {}
                chat = msg.get("chat", {})
                chat_id = str(chat.get("id", ""))
                text = (msg.get("text") or "").strip()
                if chat_id != ALLOWED_CHAT_ID:
                    if text:
                        send(chat_id, "허용되지 않은 사용자입니다.")
                    continue
                if text.startswith("/"):
                    first = text.strip().split()[0].lower() if text.strip().split() else ""
                    if first in ("/gupgrade", "/gupgrade_all", "/apply_latest", "/upgradebot"):
                        send(chat_id, "🚀 /gupgrade 접수\n- 순서: 가드봇 → 메인봇 → 페이퍼봇 → WS → micro\n- 최신 hash 동일 항목은 교체/재시작 생략\n- 진행 단계는 중간 메시지로 계속 알림")
                    elif first in ("/gguard_upgrade", "/guard_upgrade"):
                        send(chat_id, "🛡 /gguard_upgrade 접수\n- 가드봇 자체 최신화 확인 중\n- hash 동일이면 재시작 생략")
                    elif first in ("/gupgrade_ws", "/gws_upgrade", "/gwsupgrade", "/gws_apply"):
                        send(chat_id, "🛰 /gws_upgrade 접수\n- WS sidecar 최신화 확인 중\n- hash 동일 + 실행중이면 재시작 생략")
                    elif first in ("/gupgrade_micro", "/gmicro_upgrade", "/gmicroupgrade", "/gmicro_apply"):
                        send(chat_id, "🔎 /gmicro_upgrade 접수\n- 호가·체결 sidecar 최신화 확인 중\n- hash 동일 + 실행중이면 재시작 생략")
                    elif first in ("/gs1_zero_audit", "/gs1_audit", "/g1214"):
                        send(chat_id, "🔎 S1 0 원인감사 접수\n- 현재 완료 후보 원문과 Strategy Gate 상태를 같은 cycle로 대조\n- 옛 S3 표시·구조선 누락·강한 차단·일반 S2 사유를 전수 집계\n- 읽기 전용, 전략·진입·청산·원장 변경 없음")
                    elif first in ("/gstructure_missing_audit", "/gstructure_audit", "/g1216"):
                        send(chat_id, "🧩 동적 구조선 빈 계약 정밀감사 접수\n- 현재 완료 후보의 Trigger·Invalid·Target 누락을 원인별 집계\n- 완료봉·구조구역·정상흔들림·최대위험 필터를 분리 확인\n- 읽기 전용, ATR·RR·구조선식·진입·청산·원장 변경 없음")
                    elif first in ("/gentry_geometry_audit", "/grr_target_audit", "/ggeometry_audit", "/g1219"):
                        send(chat_id, "🧮 진입 구조값 정밀감사 접수\n- 같은 완료 cycle의 RR·목표공간·손절거리·Trigger 상태를 분리 집계\n- 불완전 계약과 가격순서 오류를 정상계약 통계에서 분리\n- 읽기 전용, 기준·ATR·RR·순위·진입·청산·원장 변경 없음")
                    elif first in ("/gentry_flow_audit", "/gflow_contract", "/g1221"):
                        send(chat_id, "🚦 진입 흐름 계약감사 접수\n- v1211 후보계약→Trigger 감시→S1→Paper 실제진입 검증 흐름을 현재 cycle과 대조\n- Trigger 전 S1·OPEN, Target≤Trigger, 새 대기상태 여부를 전수 확인\n- 읽기 전용, 구조선 수치·진입·청산·원장 변경 없음")
                    elif first in ("/gstructure_pairing_audit", "/gpairing_audit", "/g1222"):
                        send(chat_id, "🧭 구조선 조합 비교감사 접수\n- 같은 완료 cycle에서 v1211 구조선 선택과 현재 동적 구조선을 같은 후보로 비교\n- Trigger·Invalid·Target 시간축, RR, 목표공간, 손절거리, 비용 분해 확인\n- 읽기 전용, 기준·순위·진입·청산·원장 변경 없음")
                    elif first in ("/gpair_exclusion_audit", "/gpair_exclusion", "/gincomplete_pair_audit", "/g1232"):
                        send(chat_id, "🧩 제외 후보 원인감사 접수\n- 새 손절선×목표선 조합에서 제외된 후보를 이유별로 분리\n- 예전 선 누락 감사와 현재 조합 실패를 같은 완료 후보에서 연결\n- 읽기 전용, 기준완화·강제진입·청산·원장 변경 없음")
                    elif first in ("/gexport_profitability", "/gprofitability_export", "/gexport_profit"):
                        send(chat_id, "📦 수익성 감사파일 export 접수\n- 승인 원장만 읽기 전용 snapshot\n- manifest·SHA256 포함 단일 ZIP 전송\n- 원본 수정·삭제 없음")
                    elif first in ("/gdeep_audit", "/gdisk_audit", "/gworker_audit", "/gruntime_audit", "/gaudit"):
                        send(chat_id, "🔬 통합감사 접수\n- 작업자 cycle/CPU/메모리/중복 프로세스 확인\n- 디스크 큰 파일/journal/삭제 후 열린 파일 확인\n- 20초 증가량 표본 측정\n- 읽기 전용, 장부·매매코드 변경 없음")
                    elif first in ("/gresource_owner", "/gresource_audit", "/gprofile_owner", "/g1076"):
                        send(chat_id, "🧪 v1076 자원 owner 감사 접수\n- Paper heap·mmap·page cache·child/cgroup 차이 분해\n- Strategy·Review 단계별 시간/CPU/RSS/I/O 확인\n- Candle·대형 trace 20초 증가량 확인\n- 읽기 전용, 전략·진입·청산·원장 변경 없음")
                    elif first in ("/gstrategy_writer_v1077", "/gwriter_verify", "/g1077"):
                        send(chat_id, "🧪 v1077 Strategy writer 검수 접수\n- 신규 Strategy runtime/hash와 다음 candidate commit 확인\n- full-row audit 시간·계약·exact 0/0/0 확인\n- 읽기 전용, 전략·진입·청산·원장 변경 없음")
                    elif first in ("/gstrategy_overlay_v1078", "/goverlay_verify", "/g1078"):
                        send(chat_id, "🧪 v1078 Strategy Candle overlay 검수 접수\n- Candle full-checkpoint 객체 재생성 캐시 재사용 확인\n- overlay 시간·후보계약·exact 0/0/0 확인\n- 읽기 전용, 전략·진입·청산·원장 변경 없음")
                    elif first in ("/ghotpath_v1079", "/gintegrated_perf_v1079", "/g1079"):
                        send(chat_id, "🧪 v1079 통합 병목 검수 접수\n- Strategy 후보압축·Paper 가격 owner·Review 파생 인덱스 재사용 확인\n- 후보계약·exact 0/0/0·runtime/hash 확인\n- 읽기 전용, 전략 수치·진입·청산·원장 변경 없음")
                    elif first in ('/gdisk_bound_v1080','/gtrace_bound_v1080','/gdisk1080','/g1080'):
                        send(chat_id, '🧪 v1080 디스크 고정상한 검수 접수\n- structure·hot-watch·good-S2·quality trace 활성파일과 압축본 상한 확인\n- 기존 대형 trace 회전·압축, pending 파일, 20초 증가량 확인\n- 핵심 원장·전략·진입·청산 변경 없음')
                    elif first in ('/gfinal_owner_v1081','/gowner_closeout_v1081','/g1081'):
                        send(chat_id, '🧪 v1081 최종 owner 검수 접수\n- Paper streaming 성과 writer와 heap 회수 증명\n- Risk 단발 재계산·주변 worker alias/hash/process owner 확인\n- 디스크 상한·exact 0/0/0·자동매수 OFF 확인')
                    elif first in ('/gsystem_closeout_v1082','/gfinal_system_v1082','/g1082'):
                        send(chat_id, '🧪 v1082 시스템 자원 최종마감 접수\n- Paper 무변경 canonical snapshot 전체파싱 제거·RSS 안정성 확인\n- Risk CLOSED scan과 OPEN ticker refresh 분리 확인\n- 전체 worker runtime/hash·디스크 상한·exact 0/0/0·자동매수 OFF 확인')
                    elif first in ('/gpaper_memory_owner_v1083','/gpaper_mem_v1083','/g1083'):
                        send(chat_id, '🔬 v1083 Paper 메모리 owner 정밀측정 접수\n- startup·candidate select·decision state·status writer 단계별 RSS/할당 peak 확인\n- 3개 cycle 자동 계측 후 주원인과 보조원인 분리\n- 측정 전용, 전략·진입·청산·원장 변경 없음')
                    elif first in ('/gpaper_allocator_v1084','/gpaper_mem_v1084','/g1084'):
                        send(chat_id, '🔬 v1084 Paper allocator·exact exit 정밀측정 접수\n- tracemalloc 없이 RSS·smaps·mallinfo2·전역객체 측정\n- 3개 cycle과 exact exit 6회 포함\n- 측정 전용, 전략·진입·청산·원장 변경 없음')
                    elif first in ('/gpaper_memory_fix_v1085','/gpaper_reader_v1085','/g1085'):
                        send(chat_id, '🧪 v1085 Paper 메모리 뿌리수술 검수 접수\n- CLOSED 최근 2,000건 전량 dict 파싱 제거와 append-only ID index 확인\n- 상태판 후보 full-row 보유 제거·Paper RSS·candidate_select·exact 0/0/0 확인\n- 읽기 전용 검수, 전략·진입·청산·핵심 원장 변경 없음')
                    elif first == '/gsystem_closeout_v1086':
                        send(chat_id, '🧪 v1086 전체 시스템 최종마감 접수\n- v1085 이후 cycle 지속·runtime/source/hash·writer/reader 단일성 확인\n- Paper RSS 장시간 범위·exact·디스크 상한·신규 runtime 오류 확인\n- 읽기 전용 검수, 재시작·전략·진입·청산·핵심 원장 변경 없음')
                    elif first in ('/gpaper_performance_fix_v1092','/gpaper_perf_v1092','/g1092'):
                        send(chat_id, '🧪 v1092 Paper 증분 성과 writer 검수 접수\n- CLOSED 전체 재독 제거·append cursor·OPEN membership compact refresh 확인\n- performance_write·RSS·exact 0/0/0·runtime/hash 확인\n- 읽기 전용 검수, 성과식·전략·진입·청산·핵심 원장 변경 없음')
                    elif first in ("/gcore_v2_verify", "/gcore_verify"):
                        send(chat_id, "🧬 v1071 정적 exact-pair 본선 검증 접수\n- active·staged exact hash와 고정 pair proof 확인\n- worker 코드 실행 0 · 라이브 원장 접근 0\n- 완료까지 약 10~30초")
                    elif first in ("/gcore_v2_cutover", "/gcore_cutover"):
                        send(chat_id, "🧬 v1071 일괄전환 접수\n- PASS 검증 확인 후 Risk→Strategy→Paper→Review→Main 순서\n- runtime 증명 실패 시 전체 rollback\n- 완료까지 약 1~3분")
                    elif first in ("/gcore_v2_closeout", "/gcore_closeout"):
                        send(chat_id, "🧬 v1074 시스템 마감 접수\n- 전환 후 runtime·hash·Risk–Paper·exact·resource owner 재검증\n- PASS면 issue/change 장부를 DONE으로 append\n- 완료까지 약 10~30초")
                    reply = handle_command(text)
                    # For a no-guard bundle, there is no post-restart request.
                    # Persist the final reply before sending so a transient Telegram
                    # failure cannot silently drop the final result/summary.
                    if first in ("/gupgrade_bundle", "/gbundle", "/gapply_bundle", "/gupgrade", "/gupgrade_all", "/apply_latest", "/upgradebot") and not _load_release_job():
                        pseudo = {
                            'request_id': f"direct-{int(time.time()*1000)}",
                            'explicit': _last_success_bundle_name(),
                            'bundle_digest': '',
                        }
                        _queue_release_final(pseudo, ('❌' not in str(reply) and '예외' not in str(reply)), str(reply))
                        _deliver_pending_release_result_once()
                    else:
                        send(chat_id, reply)

            active = is_main_service_active()
            if is_status_timeout_value(active):
                main_active_timeout_count += 1
                # v2.5.67: systemctl timeout은 실제 active 상태가 아니다.
                # TIMEOUT을 last_active로 저장하면 active ↔ TIMEOUT 알림이 반복된다.
                # 마지막 정상 active 값은 유지하고, 연속 timeout 때만 별도 경고를 보낸다.
                if main_active_timeout_count >= 3 and time.time() - last_timeout_notify > 180:
                    last_timeout_notify = time.time()
                    send(ALLOWED_CHAT_ID,
                         "⚠️ 메인봇 상태확인 지연\n"
                         f"- 마지막 정상상태: {last_active or '?'}\n"
                         f"- systemctl timeout: {main_active_timeout_count}회 연속\n"
                         "- 상태변경 알림이 아니라 가드봇 확인 지연입니다.\n"
                         "- 확인: 메인봇 /health 또는 가드봇 /gdeploy")
            else:
                main_active_timeout_count = 0
                if last_active is None:
                    last_active = active
                elif active != last_active:
                    last_active = active
                    if time.time() - last_notify > 20:
                        last_notify = time.time()
                        # v2.5.7: 상태변경 알림에서 /glog를 자동 호출하지 않는다.
                        # journalctl 지연이 가드봇 polling을 막고 재시작처럼 보이는 문제를 차단한다.
                        # v2.5.67: TIMEOUT은 위에서 별도 처리하므로 여기서는 실제 active 값만 알린다.
                        send(ALLOWED_CHAT_ID, f"❔ 메인봇 상태 변경\n- active: {active}\n- 시각: {now()}\n- 로그 확인: /glog 80")

        except KeyboardInterrupt:
            raise
        except Exception as e:
            print(f"[{now()}] loop error: {type(e).__name__}: {e}", file=sys.stderr, flush=True)
            time.sleep(3)
        time.sleep(POLL_SEC)

def _v398_guard_file_age(path: Path) -> float:
    try:
        return max(0.0, time.time() - path.stat().st_mtime) if path.exists() else 999999.0
    except Exception:
        return 999999.0

def _v399_expected_paper_version(target: Path) -> str:
    try:
        v = extract_paper_version(target)
        return v if v and v != '?' else str(paper_version_from_filename(target) or '?')
    except Exception:
        return '?'

def paper_runtime_snapshot(expected_version: str = '', expected_build: str = '', expected_hash: str = '', max_age_sec: float = 45.0) -> dict:
    """One read-only runtime truth: systemd MainPID -> cmdline -> status identity -> alias hash."""
    active_path = BOT_DIR / PAPER_ACTIVE_FILE
    status_path = BOT_DIR / 'paper_bot_status.json'
    phase_path = BOT_DIR / 'paper_bot_runtime_phase_v994.json'
    status = read_json(status_path)
    phase = read_json(phase_path)
    phase = phase if isinstance(phase, dict) else {}
    status = status if isinstance(status, dict) else {}
    pid_file = read_pid(BOT_DIR / PAPER_PID_FILE)
    service_main_pid = _service_main_pid(PAPER_SERVICE) if service_exists(PAPER_SERVICE) else None
    proc_pids = find_paperbot_pids()
    try:
        status_pid = int(float(status.get('writer_pid') or status.get('status_writer_pid') or status.get('self_pid') or status.get('pid') or status.get('process_pid') or 0))
    except Exception:
        status_pid = 0
    try:
        writer_count = int(float(status.get('status_writer_count') or 0))
    except Exception:
        writer_count = 0
    active_version = extract_paper_version(active_path)
    active_build = extract_assignment(active_path, 'BUILD_LABEL')
    source_owner = extract_assignment(active_path, '_STATUS_WRITER_OWNER')
    active_hash = short_hash(active_path) if active_path.exists() else '?'
    expected_version = expected_version or (active_version if active_version != '?' else '')
    expected_build = expected_build or (active_build if active_build != '?' else '')
    expected_hash = expected_hash or (active_hash if active_hash != '?' else '')
    expected_owner = source_owner if source_owner != '?' else ''
    age = _v398_guard_file_age(status_path)
    stop_reason = str(status.get('stop_reason') or '').strip()
    running = status.get('running') is True
    service_active = is_service_active(PAPER_SERVICE) if service_exists(PAPER_SERVICE) else 'no_service'
    main_alive = bool(service_main_pid and pid_alive(service_main_pid))
    cmdline = proc_cmdline(service_main_pid) if main_alive else ''
    extras = [pid for pid in proc_pids if pid != service_main_pid and pid_alive(pid)]
    reasons: list[str] = []
    if not service_exists(PAPER_SERVICE): reasons.append('systemd service 없음')
    elif service_active not in {'active','activating'}: reasons.append(f'service={service_active}')
    if not main_alive: reasons.append('systemd MainPID 없음/죽음')
    if main_alive and 'paper_bot.py' not in cmdline: reasons.append('MainPID cmdline이 paper_bot.py 아님')
    if extras: reasons.append('중복 paper process=' + ','.join(map(str, extras)))
    if service_main_pid and pid_file != service_main_pid: reasons.append(f'pid_file 불일치 {pid_file}->{service_main_pid}')
    if service_main_pid and status_pid != service_main_pid: reasons.append(f'status_pid 불일치 {status_pid}->{service_main_pid}')
    if age > float(max_age_sec): reasons.append(f'status age {age:.1f}s>{float(max_age_sec):.0f}s')
    if expected_version and str(status.get('version') or status.get('paper_version') or '') != expected_version:
        reasons.append(f"status VERSION 불일치 {status.get('version') or status.get('paper_version') or '-'}->{expected_version}")
    if expected_build and str(status.get('build') or status.get('paper_runtime_build') or '') != expected_build:
        reasons.append(f"status BUILD 불일치 {status.get('build') or status.get('paper_runtime_build') or '-'}->{expected_build}")
    if expected_hash and active_hash != expected_hash: reasons.append(f'active hash 불일치 {active_hash}->{expected_hash}')
    if expected_owner and str(status.get('status_writer_owner') or '') != expected_owner:
        reasons.append(f"writer owner 불일치 {status.get('status_writer_owner') or '-'}->{expected_owner}")
    if writer_count != 1: reasons.append(f'writer_count={writer_count}, expected=1')
    try:
        writer_pid_num = int(float(status.get('writer_pid') or 0))
    except Exception:
        writer_pid_num = 0
    if service_main_pid and writer_pid_num != service_main_pid:
        reasons.append(f"writer_pid 불일치 {writer_pid_num}->{service_main_pid}")
    if not running: reasons.append('status running!=True')
    if stop_reason not in {'','running'}: reasons.append(f'stale stop_reason={stop_reason}')
    if not status.get('process_started_at'): reasons.append('process_started_at 누락')
    return {
        'ok': not reasons,
        'reasons': reasons,
        'service': PAPER_SERVICE,
        'service_active': service_active,
        'main_pid': service_main_pid,
        'main_alive': main_alive,
        'cmdline': cmdline,
        'proc_pids': proc_pids,
        'extra_pids': extras,
        'pid_file': pid_file,
        'status_pid': status_pid,
        'writer_pid': status.get('writer_pid'),
        'writer_owner': status.get('status_writer_owner'),
        'writer_count': writer_count,
        'status_age': age,
        'status_version': status.get('version') or status.get('paper_version'),
        'status_build': status.get('build') or status.get('paper_runtime_build'),
        'running': status.get('running'),
        'stop_reason': stop_reason,
        'process_started_at': status.get('process_started_at'),
        'runtime_instance_id': status.get('runtime_instance_id'),
        'write_seq': status.get('status_write_seq'),
        'active_file': active_path.name,
        'active_version': active_version,
        'active_build': active_build,
        'active_hash': active_hash,
        'expected_owner': expected_owner,
        'runtime_phase': phase.get('phase') or status.get('runtime_phase'),
        'runtime_phase_detail': phase.get('detail') or status.get('runtime_phase_detail'),
        'runtime_phase_age': _v398_guard_file_age(phase_path),
        'exact_commit_active': phase.get('exact_commit_active') if phase else status.get('exact_commit_active'),
        'paper_io_v1018': status.get('paper_io_v1018') if isinstance(status.get('paper_io_v1018'), dict) else {},
        'paper_io_v1017': status.get('paper_io_v1017') if isinstance(status.get('paper_io_v1017'), dict) else {},
    }

def _v399_paper_stale_reasons(target: Path, active_path: Path) -> list[str]:
    expected_version = _v399_expected_paper_version(target)
    expected_build = extract_assignment(target, 'BUILD_LABEL')
    expected_hash = short_hash(target) if target.exists() else ''
    snap = paper_runtime_snapshot(expected_version, expected_build if expected_build != '?' else '', expected_hash)
    reasons = list(snap.get('reasons') or [])
    trace = read_json(BOT_DIR / 'paper_bot_candidate_handoff_trace.json')
    trace_ver = str(trace.get('version') or trace.get('trace_version') or '') if isinstance(trace, dict) else ''
    trace_age = _v398_guard_file_age(BOT_DIR / 'paper_bot_candidate_handoff_trace.json')
    if expected_version != '?' and trace_ver and trace_ver != expected_version:
        reasons.append(f'trace VERSION 불일치 {trace_ver}->{expected_version}')
    if trace_age > 150:
        reasons.append(f'trace age {trace_age:.0f}s')
    return reasons

def _v399_paper_unit_content() -> str:
    home = _guess_bot_owner_home() or str(BOT_DIR.parent)
    user = _guess_bot_user()
    user_line = f"User={user}\n" if user and user != 'root' else ''
    py = PAPER_PYTHON_BIN or '/usr/bin/python3'
    return f"""[Unit]
Description=Coinbot Paper Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
{user_line}WorkingDirectory={BOT_DIR}
EnvironmentFile=-{ENV_PATH}
Environment=TRADING_BOT_DIR={BOT_DIR}
Environment=HOME={home}
ExecStart={py} {BOT_DIR / PAPER_ACTIVE_FILE} --bot
Restart=always
RestartSec=3
KillMode=control-group
KillSignal=SIGTERM
TimeoutStopSec=8

[Install]
WantedBy=multi-user.target
"""

def _v399_install_paper_service(force: bool = True) -> tuple[bool, list[str]]:
    notes=[]
    unit_path = Path(f"/etc/systemd/system/{PAPER_SERVICE}.service")
    content = _v399_paper_unit_content()
    existing = ''
    try:
        existing = unit_path.read_text(encoding='utf-8', errors='ignore') if unit_path.exists() else ''
    except Exception:
        existing = ''
    if service_exists(PAPER_SERVICE) and existing.strip() == content.strip() and not force:
        return True, [f'service already installed: {PAPER_SERVICE}']
    tmp = BOT_DIR / f'.{PAPER_SERVICE}.service.tmp'
    try:
        tmp.write_text(content, encoding='utf-8')
    except Exception as exc:
        return False, [f'unit tmp write failed: {exc.__class__.__name__}: {str(exc)[:140]}']
    try:
        if os.geteuid() == 0:
            unit_path.write_text(content, encoding='utf-8')
            rc_cp, out_cp = 0, ''
        else:
            rc_cp, out_cp = _run_privileged(['cp', str(tmp), str(unit_path)], timeout=10)
        if rc_cp != 0:
            return False, ['unit install failed: ' + tail(out_cp, 600)]
        _run_privileged(['chmod', '0644', str(unit_path)], timeout=8)
        rc_daemon, out_daemon = _run_privileged(['systemctl', 'daemon-reload'], timeout=15)
        rc_enable, out_enable = _run_privileged(['systemctl', 'enable', PAPER_SERVICE], timeout=15)
        notes.append(f'service reinstalled: {PAPER_SERVICE}')
        if rc_daemon != 0:
            notes.append('daemon-reload: ' + tail(out_daemon, 300))
        if rc_enable != 0:
            notes.append('enable: ' + tail(out_enable, 300))
        return rc_cp == 0, notes
    finally:
        try: tmp.unlink(missing_ok=True)
        except Exception: pass

def _v399_stop_paper_runtime() -> list[str]:
    notes=[]
    if service_exists(PAPER_SERVICE):
        rc, out = run(['systemctl', 'stop', PAPER_SERVICE], timeout=12)
        notes.append(f'systemctl stop {PAPER_SERVICE}: rc={rc} {tail(out,300)}')
        if rc == 124 or is_service_active(PAPER_SERVICE) in {'active','activating','deactivating'}:
            rc2, out2 = run(['systemctl', 'kill', '-s', 'SIGKILL', PAPER_SERVICE], timeout=8)
            notes.append(f'systemctl kill {PAPER_SERVICE}: rc={rc2} {tail(out2,300)}')
    for pid in list(find_paperbot_pids()):
        if pid_alive(pid):
            stop_pid(pid)
            notes.append(f'paper 잔류 pid 종료: {pid}')
    return notes

def _v399_backup_and_remove_paper_runtime_files() -> tuple[str, list[str]]:
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_dir = BOT_DIR / f'.paper_runtime_reset_{stamp}'
    backup_dir.mkdir(exist_ok=True)
    names = [
        PAPER_PID_FILE,
        'paper_bot_status.json',
        'paper_bot_candidate_handoff_trace.json',
        'paper_bot_candidate_handoff_status.json',
        'paper_bot_current_score_anchor.json',
        'paper_bot_score_cache.json',
    ]
    notes=[]
    for name in names:
        p = BOT_DIR / name
        if not p.exists():
            continue
        try:
            shutil.copy2(p, backup_dir / name)
            p.unlink()
            notes.append(f'runtime 캐시 백업 후 제거: {name}')
        except Exception as exc:
            notes.append(f'runtime 캐시 제거 실패: {name} / {exc.__class__.__name__}: {str(exc)[:120]}')
    notes.append('보존: paper_bot_open.json / paper_bot_closed.jsonl / trade_log 계열은 삭제하지 않음')
    return backup_dir.name, notes

def _v399_copy_paper_target_to_active(target: Path, force: bool = True) -> tuple[bool, list[str]]:
    notes=[]
    active_path = BOT_DIR / PAPER_ACTIVE_FILE
    valid, checks, warnings = validate_paper_target(target)
    notes += checks[:4] + [f'warning: {w}' for w in warnings[:4]]
    if not valid:
        return False, notes
    if active_path.exists():
        backup_path = BOT_DIR / f"{active_path.name}.backup_v399_reset_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(active_path, backup_path)
        notes.append(f'active backup: {backup_path.name}')
    tmp = BOT_DIR / f"{active_path.name}.v399_tmp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(target, tmp)
    if sha256_file(tmp) != sha256_file(target):
        tmp.unlink(missing_ok=True)
        return False, notes + ['paper active copy hash mismatch']
    os.replace(tmp, active_path)
    try:
        (BOT_DIR / DEPLOYED_PAPER_FILE).write_text(target.name + '\n', encoding='utf-8')
    except Exception:
        pass
    notes.append(f'active paper relinked: {active_path.name} <= {target.name}')
    return True, notes

def _v399_wait_paper_fresh(expected: str, timeout_sec: float = 60.0, expected_build: str = '', expected_hash: str = '', expected_pid: Optional[int] = None) -> tuple[bool, list[str]]:
    notes=[]
    deadline=time.time()+max(1.0, timeout_sec)
    last={}
    while time.time() < deadline:
        last = paper_runtime_snapshot(expected, expected_build, expected_hash)
        if last.get('ok') and (not expected_pid or int(last.get('main_pid') or 0) == int(expected_pid)):
            notes.append(
                f"fresh exact: pid {last.get('main_pid')} / status {last.get('status_version')} / "
                f"owner {last.get('writer_owner')} / count {last.get('writer_count')} / age {float(last.get('status_age') or 0):.1f}s"
            )
            return True, notes
        time.sleep(1)
    notes.append('fresh exact timeout: ' + ' / '.join((last.get('reasons') or ['status 없음'])[:10]))
    return False, notes

def gpaper_reset_text() -> str:
    """paper 실행 연결부만 끊고 다시 잇는다. 장부는 보존한다."""
    t0=perf_now()
    target = choose_latest_paper_target()
    if not target or not target.exists():
        return '🧯 ❌ 페이퍼 재연결 실패 /gpaper_reset\n- paper_bot_v*.py 대상 파일을 못 찾음'
    expected = _v399_expected_paper_version(target)
    notes=[]
    notes.append(f'target: {target.name} / expected {expected}')
    ok_unit, unit_notes = _v399_install_paper_service(force=True)
    notes += unit_notes
    if not ok_unit:
        return '🧯 ❌ 페이퍼 재연결 실패 /gpaper_reset\n- service unit 설치 실패\n' + '\n'.join(f'- {x}' for x in notes[-12:])
    notes += _v399_stop_paper_runtime()
    backup_dir, backup_notes = _v399_backup_and_remove_paper_runtime_files()
    notes += backup_notes
    ok_copy, copy_notes = _v399_copy_paper_target_to_active(target, force=True)
    notes += copy_notes
    if not ok_copy:
        return '🧯 ❌ 페이퍼 재연결 실패 /gpaper_reset\n- active paper 복사 실패\n' + '\n'.join(f'- {x}' for x in notes[-16:])
    rc, out = run(['systemctl', 'start', PAPER_SERVICE], timeout=15)
    notes.append(f'systemctl start {PAPER_SERVICE}: rc={rc} {tail(out,300)}')
    time.sleep(1)
    pid = _service_main_pid(PAPER_SERVICE)
    if pid:
        repair_paper_pid_file(pid)
        notes.append(f'service pid={pid}')
    active = is_service_active(PAPER_SERVICE) if service_exists(PAPER_SERVICE) else 'no_service'
    fresh_ok, fresh_notes = _v399_wait_paper_fresh(expected, timeout_sec=60.0, expected_build=extract_assignment(target, 'BUILD_LABEL'), expected_hash=short_hash(target), expected_pid=_service_main_pid(PAPER_SERVICE))
    notes += fresh_notes
    ok = (rc == 0 and active in {'active','activating'} and fresh_ok)
    title = '🧯 ✅ 페이퍼 재연결 완료 /gpaper_reset' if ok else '🧯 ⚠️ 페이퍼 재연결 확인필요 /gpaper_reset'
    lines=[title, f'- target: {target.name}', f'- expected: {expected}', f'- service: {PAPER_SERVICE} / active={active}', f'- backup_runtime: {backup_dir}', f'- total: {fmt_sec(perf_now()-t0)}', '', '[조치]']
    lines += [f'- {x}' for x in notes[:24]]
    lines += ['', '[보존]', '- paper_bot_open.json / paper_bot_closed.jsonl / trade_log 계열은 건드리지 않음', '', '다음 확인:', '- /gpaper_state', '- /gpaperlog 120', '- 메인봇 /health /pstatus /errorlog']
    return '\n'.join(lines)

def restart_paper_bot(expected_version: str = '', expected_build: str = '', expected_hash: str = '') -> tuple[str, list[str]]:
    """One systemd restart path followed by exact source/status identity verification."""
    notes=[]
    if not service_exists(PAPER_SERVICE):
        ok_unit, unit_notes = _v399_install_paper_service(force=True)
        notes += unit_notes
        if not ok_unit:
            notes.append(f'systemd service 없음({PAPER_SERVICE}); direct fallback 금지')
            return 'no_service', notes
    active_path = BOT_DIR / PAPER_ACTIVE_FILE
    expected_version = expected_version or extract_paper_version(active_path)
    build = expected_build or extract_assignment(active_path, 'BUILD_LABEL')
    expected_build = '' if build == '?' else build
    expected_hash = expected_hash or (short_hash(active_path) if active_path.exists() else '')
    rc, out = run(['systemctl', 'restart', PAPER_SERVICE], timeout=25)
    notes.append(f'systemctl restart {PAPER_SERVICE}: rc={rc} {tail(out,500)}')
    if rc != 0:
        return 'restart_failed', notes
    deadline=time.time()+8
    pid=None
    while time.time()<deadline:
        pid=_service_main_pid(PAPER_SERVICE)
        if pid and pid_alive(pid): break
        time.sleep(0.5)
    if pid:
        repair_paper_pid_file(pid)
        notes.append(f'MainPID={pid} / pid_file synchronized')
    extras=[p for p in find_paperbot_pids() if p != pid and pid_alive(p)]
    for extra in extras:
        stop_pid(extra)
        notes.append(f'stale paper pid stopped={extra}')
    permission_ok, permission_notes = repair_paper_canonical_writer_ownership()
    notes += permission_notes
    if not permission_ok:
        run(['systemctl','stop',PAPER_SERVICE], timeout=12)
        notes.append('canonical writer ownership failed -> paper stopped; alternate ledger forbidden')
        return 'permission_failed', notes
    fresh_ok, fresh_notes = _v399_wait_paper_fresh(expected_version, timeout_sec=60.0, expected_build=expected_build, expected_hash=expected_hash, expected_pid=pid)
    notes += fresh_notes
    active=is_service_active(PAPER_SERVICE)
    if not fresh_ok:
        notes.append('service active만으로 성공 처리하지 않음')
        return 'verification_failed', notes
    return active, notes

def _paper_identity_from_pid(pid: int) -> Optional[dict]:
    """Return the actual OS identity of a live paper process."""
    try:
        status = Path(f'/proc/{int(pid)}/status').read_text(encoding='utf-8', errors='ignore')
        uid_line = next((line for line in status.splitlines() if line.startswith('Uid:')), '')
        gid_line = next((line for line in status.splitlines() if line.startswith('Gid:')), '')
        uid = int(uid_line.split()[1]); gid = int(gid_line.split()[1])
        try: user = pwd.getpwuid(uid).pw_name
        except Exception: user = str(uid)
        return {'uid':uid,'gid':gid,'user':user,'pid':int(pid),'source':'paper_main_pid'}
    except Exception:
        return None

def resolve_paper_runtime_identity() -> tuple[Optional[dict], list[str]]:
    """Resolve the exact user that executes paper_bot.py; never infer it from BOT_DIR owner."""
    notes: list[str] = []
    main_pid = _service_main_pid(PAPER_SERVICE) if service_exists(PAPER_SERVICE) else None
    if main_pid and pid_alive(main_pid):
        ident = _paper_identity_from_pid(main_pid)
        if ident:
            notes.append(f"identity pid={main_pid} user={ident['user']} uid={ident['uid']} gid={ident['gid']}")
            return ident, notes
    for pid in reversed(find_paperbot_pids()):
        if pid_alive(pid):
            ident = _paper_identity_from_pid(pid)
            if ident:
                ident['source'] = 'paper_process_scan'
                notes.append(f"identity scan pid={pid} user={ident['user']} uid={ident['uid']} gid={ident['gid']}")
                return ident, notes
    service_user = ''
    if service_exists(PAPER_SERVICE):
        rc, out = run(['systemctl','show',PAPER_SERVICE,'-p','User','--value'], timeout=8)
        if rc == 0:
            service_user = str(out or '').strip()
    user = service_user or _guess_bot_user()
    if user:
        try:
            rec = pwd.getpwnam(user)
            ident = {'uid':int(rec.pw_uid),'gid':int(rec.pw_gid),'user':rec.pw_name,'pid':None,
                     'source':'systemd_user' if service_user else 'bot_path_user'}
            notes.append(f"identity {ident['source']} user={ident['user']} uid={ident['uid']} gid={ident['gid']}")
            return ident, notes
        except Exception as exc:
            notes.append(f"identity user lookup failed {user}: {type(exc).__name__}: {exc}")
    notes.append('paper runtime identity unresolved')
    return None, notes

def repair_paper_canonical_writer_ownership() -> tuple[bool, list[str]]:
    """Make canonical transaction files owned by the actual paper runtime identity."""
    identity, notes = resolve_paper_runtime_identity()
    if not identity:
        return False, notes
    uid = int(identity['uid']); gid = int(identity['gid']); owner = f'{uid}:{gid}'
    names = [
        'paper_bot_closed.jsonl', 'paper_bot_open.json',
        'paper_closed_append_status_v925.json', 'paper_closed_append_events_v925.jsonl',
        'paper_closed_commit_status.json', 'paper_closed_commit_events.jsonl',
        'paper_decision_state_v926.json', 'paper_decision_status_v926.json', 'paper_decision_events_v926.jsonl',
        'paper_decision_reconcile_status.json',
        'paper_exit_monitor_status.json', 'paper_exit_monitor_events.jsonl',
        'paper_writer_permission_status.json',
    ]
    ok = True
    changed = 0
    for name in names:
        path = BOT_DIR / name
        if not path.exists():
            notes.append(f'not_exists {name}')
            continue
        try:
            st = path.stat()
            if int(st.st_uid) != uid or int(st.st_gid) != gid:
                rc, out = _run_privileged(['chown', owner, str(path)], timeout=8)
                notes.append(f'chown {name} -> {identity["user"]}({owner}): rc={rc} {tail(out,160)}')
                ok = ok and rc == 0
                changed += 1 if rc == 0 else 0
            st = path.stat()
            if not bool(st.st_mode & 0o200):
                rc, out = _run_privileged(['chmod','0664',str(path)], timeout=8)
                notes.append(f'chmod {name} 0664: rc={rc} {tail(out,160)}')
                ok = ok and rc == 0
                changed += 1 if rc == 0 else 0
            final = path.stat()
            final_ok = int(final.st_uid) == uid and int(final.st_gid) == gid and bool(final.st_mode & 0o200)
            if not final_ok:
                ok = False
                notes.append(f'verify_fail {name}: uid={final.st_uid} gid={final.st_gid} mode={oct(final.st_mode & 0o777)} expected={owner}')
            else:
                notes.append(f'owner_ok {name}: user={identity["user"]} uid={final.st_uid} gid={final.st_gid} mode={oct(final.st_mode & 0o777)}')
        except Exception as exc:
            ok = False
            notes.append(f'permission_error {name}: {type(exc).__name__}: {exc}')
    notes.insert(1, f"contract actual paper identity only; BOT_DIR owner ignored; changed={changed}")
    return ok, notes

def apply_paper_latest(force: bool = False, explicit: Optional[str] = None) -> dict:
    target = choose_latest_paper_target(explicit=explicit)
    if not target or not target.exists():
        return {'ok': True, 'changed': False, 'target': explicit or '?', 'active': '유지', 'warning': 'paper_bot_v*.py 대상 없음 → 기존 실행 유지'}
    active_path = BOT_DIR / PAPER_ACTIVE_FILE
    valid, checks, warnings = validate_paper_target(target)
    if not valid:
        return {'ok': False, 'changed': False, 'target': target.name, 'checks': checks, 'warnings': warnings, 'error': 'paper 검수 실패'}
    permission_ok, permission_notes = repair_paper_canonical_writer_ownership()
    if not permission_ok:
        return {'ok': False, 'changed': False, 'target': target.name, 'checks': checks, 'warnings': warnings, 'error': 'paper canonical ledger 권한 복구 실패', 'notes': permission_notes}
    expected_version = _v399_expected_paper_version(target)
    expected_build = extract_assignment(target, 'BUILD_LABEL')
    expected_build = '' if expected_build == '?' else expected_build
    expected_hash = short_hash(target)
    same_hash = active_path.exists() and short_hash(active_path) == expected_hash
    stale_reasons = _v399_paper_stale_reasons(target, active_path) if same_hash else ['active source hash 변경 필요']
    backup='없음'
    changed=False
    if not same_hash or force:
        if active_path.exists():
            backup_path = BOT_DIR / f"{active_path.name}.backup_guard_apply_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
            shutil.copy2(active_path, backup_path)
            backup=backup_path.name
        tmp = BOT_DIR / f"{active_path.name}.guard_tmp_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(target, tmp)
        if sha256_file(tmp) != sha256_file(target):
            tmp.unlink(missing_ok=True)
            return {'ok': False, 'changed': False, 'target': target.name, 'error': 'paper 임시복사 hash 불일치'}
        os.replace(tmp, active_path)
        changed=True
        try: (BOT_DIR / DEPLOYED_PAPER_FILE).write_text(target.name + '\n', encoding='utf-8')
        except Exception: pass
    if changed or stale_reasons or force:
        active, notes = restart_paper_bot(expected_version, expected_build, expected_hash)
        ok = active in {'active','activating'}
        return {'ok': ok, 'changed': changed, 'target': target.name, 'version': extract_paper_version(active_path), 'active': active,
                'backup': backup, 'hash': short_hash(active_path), 'notes': permission_notes + notes,
                'warnings': warnings + stale_reasons, 'error': None if ok else 'paper runtime exact verification failed'}
    snap=paper_runtime_snapshot(expected_version, expected_build, expected_hash)
    try: (BOT_DIR / DEPLOYED_PAPER_FILE).write_text(target.name + '\n', encoding='utf-8')
    except Exception: pass
    return {'ok': bool(snap.get('ok')), 'changed': False, 'target': target.name, 'version': extract_paper_version(active_path),
            'active': snap.get('service_active'), 'hash': short_hash(active_path), 'skipped_restart': True,
            'warning': '변경 없음 + exact runtime identity 정상 → 재시작 생략',
            'notes': permission_notes + [f"pid={snap.get('main_pid')} owner={snap.get('writer_owner')} count={snap.get('writer_count')}"],
            'warnings': warnings + list(snap.get('reasons') or [])}

RESOURCE_OWNER_STATUS_V1076 = BOT_DIR / 'resource_owner_audit_v1076.json'

RESOURCE_OWNER_LEDGER_MARKER_V1076 = BOT_DIR / '.resource_owner_ledger_events_v1076.json'

_RESOURCE_OWNER_SPECS_V1076 = {
    'paper': {'service': PAPER_SERVICE, 'status': 'paper_bot_status.json'},
    'strategy': {'service': WORKER_SPECS['strategy']['service'], 'status': WORKER_SPECS['strategy']['status']},
    'review': {'service': WORKER_SPECS['review']['service'], 'status': WORKER_SPECS['review']['status']},
    'candle': {'service': WORKER_SPECS['candle']['service'], 'status': WORKER_SPECS['candle']['status']},
}

_RESOURCE_TRACE_SPECS_V1076 = {
    'structure_lab_horizon_result_ledger_v956.jsonl': 'review_worker.update_structure_laboratory',
    'structure_lab_event_detail_ledger_v956.jsonl': 'review_worker.update_structure_laboratory',
    'clean_hot_watch_strategy_events.jsonl': 'strategy_worker hot-watch event writer',
    'good_s2_result_ledger.jsonl': 'review_worker good-S2 result writer',
}

def _v1076_read_numeric_map(path: Path, *, kb: bool=False) -> dict:
    out={}
    try:
        for line in path.read_text(encoding='utf-8',errors='ignore').splitlines():
            if ':' in line:
                key,raw=line.split(':',1)
            else:
                parts=line.split(None,1)
                if len(parts)!=2: continue
                key,raw=parts
            values=raw.strip().split()
            if not values: continue
            try: value=int(float(values[0]))
            except Exception: continue
            if kb and len(values)>=2 and values[1].lower()=='kb': value*=1024
            out[key.strip()]=value
    except Exception:
        pass
    return out

def _v1076_service_props(service: str) -> dict:
    rc,out=run(['systemctl','show',service,'-p','ActiveState','-p','SubState','-p','MainPID','-p','MemoryCurrent','-p','TasksCurrent','-p','ControlGroup'],timeout=8)
    props={}
    if rc==0:
        for line in (out or '').splitlines():
            if '=' in line:
                key,value=line.split('=',1); props[key.strip()]=value.strip()
    return props

def _v1076_cgroup_snapshot(control_group: str) -> dict:
    rel=str(control_group or '').strip()
    root=Path('/sys/fs/cgroup') / rel.lstrip('/') if rel else Path('/sys/fs/cgroup/__missing__')
    stat=_v1076_read_numeric_map(root/'memory.stat') if root.exists() else {}
    try: current=int((root/'memory.current').read_text().strip())
    except Exception: current=0
    try: pids=[int(x) for x in (root/'cgroup.procs').read_text().split() if x.isdigit()]
    except Exception: pids=[]
    rss_sum=0; proc_rows=[]
    for pid in pids[:128]:
        status=_v1076_read_numeric_map(Path(f'/proc/{pid}/status'),kb=True)
        rss=int(status.get('VmRSS') or 0); rss_sum+=rss
        proc_rows.append({'pid':pid,'rss_bytes':rss,'rss_anon_bytes':int(status.get('RssAnon') or 0),'rss_file_bytes':int(status.get('RssFile') or 0),'threads':int(status.get('Threads') or 0)})
    return {
        'path':str(root),'memory_current_bytes':current,'memory_stat':stat,
        'pids':pids,'process_rss_sum_bytes':rss_sum,'processes':proc_rows,
    }

def _v1076_fd_snapshot(pid: int) -> dict:
    counts={'regular':0,'socket':0,'pipe':0,'anon_inode':0,'deleted':0,'other':0}; deleted_bytes=0
    fdroot=Path(f'/proc/{pid}/fd')
    try: fds=list(fdroot.iterdir())
    except Exception: return counts
    for fd in fds:
        try: target=os.readlink(str(fd))
        except Exception: continue
        if target.endswith(' (deleted)'):
            counts['deleted']+=1
            try: deleted_bytes+=int(os.stat(str(fd)).st_size)
            except Exception: pass
        elif target.startswith('socket:'): counts['socket']+=1
        elif target.startswith('pipe:'): counts['pipe']+=1
        elif target.startswith('anon_inode:'): counts['anon_inode']+=1
        elif target.startswith('/'): counts['regular']+=1
        else: counts['other']+=1
    counts['deleted_bytes']=deleted_bytes
    counts['total']=sum(v for k,v in counts.items() if k not in {'deleted_bytes','total'})
    return counts

def _v1076_proc_snapshot(pid: int, props: dict) -> dict:
    if pid<=0: return {'pid':pid,'state':'NO_PID'}
    status=_v1076_read_numeric_map(Path(f'/proc/{pid}/status'),kb=True)
    smaps=_v1076_read_numeric_map(Path(f'/proc/{pid}/smaps_rollup'),kb=True)
    io=_v1076_read_numeric_map(Path(f'/proc/{pid}/io'))
    cgroup=_v1076_cgroup_snapshot(str(props.get('ControlGroup') or ''))
    try: cmd=Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\x00',b' ').decode('utf-8',errors='ignore').strip()
    except Exception: cmd=''
    return {
        'pid':pid,'state':'OK' if status else 'CHECK','cmdline':cmd[:500],
        'status':status,'smaps_rollup':smaps,'io':io,'fds':_v1076_fd_snapshot(pid),'cgroup':cgroup,
        'service_memory_current_bytes':_audit_int(props.get('MemoryCurrent')),
        'service_tasks':_audit_int(props.get('TasksCurrent')),
    }

def _v1076_component_snapshot(name: str) -> dict:
    spec=_RESOURCE_OWNER_SPECS_V1076[name]
    props=_v1076_service_props(str(spec['service']))
    pid=_audit_int(props.get('MainPID'))
    status_obj=read_json(BOT_DIR/str(spec['status'])) or {}
    return {'name':name,'service':spec['service'],'props':props,'proc':_v1076_proc_snapshot(pid,props),'status_obj':status_obj if isinstance(status_obj,dict) else {}}

def _v1076_trace_sizes() -> dict:
    out={}
    for name,owner in _RESOURCE_TRACE_SPECS_V1076.items():
        path=BOT_DIR/name
        try: size=int(path.stat().st_size)
        except Exception: size=0
        out[name]={'bytes':size,'owner':owner,'exists':path.exists()}
    return out

def _v1076_delta(before: dict, after: dict) -> dict:
    keys=set(before)|set(after); return {k:int(after.get(k) or 0)-int(before.get(k) or 0) for k in keys}

def _v1076_profile_extract(name: str, status_obj: dict) -> dict:
    if name=='paper':
        deep=status_obj.get('paper_resource_profile_v1076') if isinstance(status_obj.get('paper_resource_profile_v1076'),dict) else {}
        legacy=status_obj.get('paper_cycle_profile_v1053') if isinstance(status_obj.get('paper_cycle_profile_v1053'),dict) else {}
        return {'deep_v1076':deep,'legacy_v1053':legacy}
    if name=='strategy':
        profile=read_json(BOT_DIR/'clean_strategy_cpu_profile_v1027.json') or {}
        return profile if isinstance(profile,dict) else {}
    if name=='review':
        return {
            'last_cycle_sec':status_obj.get('last_cycle_sec',status_obj.get('last_sec')),
            'phase_top':status_obj.get('phase_top') or [],
            'phase_memory_top':status_obj.get('phase_memory_top') or [],
            'phase_io_top_v1011':status_obj.get('phase_io_top_v1011') or [],
            'memory_reclaim_v1008':status_obj.get('memory_reclaim_v1008') or {},
        }
    return {
        'last_sec':status_obj.get('last_sec'),'phase':status_obj.get('phase'),
        'delta_appended_bytes_v1016':status_obj.get('delta_appended_bytes_v1016'),
        'delta_size_after_v1016':status_obj.get('delta_size_after_v1016'),
        'checkpoint_due_v1016':status_obj.get('checkpoint_due_v1016'),
    }

def _v1076_owner_reason(row: dict) -> dict:
    proc=row.get('after',{}).get('proc') if isinstance(row.get('after'),dict) else {}
    status=proc.get('status') if isinstance(proc,dict) and isinstance(proc.get('status'),dict) else {}
    cgroup=proc.get('cgroup') if isinstance(proc,dict) and isinstance(proc.get('cgroup'),dict) else {}
    mstat=cgroup.get('memory_stat') if isinstance(cgroup.get('memory_stat'),dict) else {}
    rss=int(status.get('VmRSS') or 0); anon=int(status.get('RssAnon') or 0); rssfile=int(status.get('RssFile') or 0)
    current=int(cgroup.get('memory_current_bytes') or proc.get('service_memory_current_bytes') or 0)
    proc_sum=int(cgroup.get('process_rss_sum_bytes') or rss); extra_proc=max(0,proc_sum-rss); file_cache=int(mstat.get('file') or 0)
    gap=max(0,current-rss)
    if current<=0 or rss<=0: reason='CHECK_SOURCE_MISSING'
    elif gap<=64*1024*1024: reason='PROCESS_RSS_AND_CGROUP_CLOSE'
    elif extra_proc>=max(64*1024*1024,int(gap*0.35)): reason='EXTRA_CGROUP_PROCESS_OR_CHILD'
    elif file_cache>=max(64*1024*1024,int(gap*0.50)): reason='CGROUP_FILE_PAGE_CACHE'
    elif anon>=int(rss*0.70): reason='PYTHON_ANON_HEAP_OR_ALLOCATOR_RETENTION'
    elif rssfile>=int(rss*0.35): reason='FILE_MMAP_OR_SHARED_LIBRARY_RSS'
    else: reason='MIXED_MEMORY_OWNER'
    return {'reason':reason,'main_rss_bytes':rss,'rss_anon_bytes':anon,'rss_file_bytes':rssfile,'cgroup_current_bytes':current,'cgroup_gap_bytes':gap,'cgroup_file_bytes':file_cache,'extra_cgroup_process_rss_bytes':extra_proc}

def _v1076_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(RESOURCE_OWNER_LEDGER_MARKER_V1076) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key): return False
    _append_jsonl_fsync_v1074(path,row)
    done[event_key]={'ts':time.time(),'time':now()}
    write_json(RESOURCE_OWNER_LEDGER_MARKER_V1076,{'schema':'resource_owner_ledger_marker_v1076','events':done})
    return True

def _v1076_issue_open() -> None:
    common={'version':'v1076','ts':time.time(),'time':now(),'status':'OPEN','strategy_impact':'none_measurement_only','auto_buy':False,'source':'guard_resource_owner_audit_v1076'}
    _v1076_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1076',event_type='ISSUE',issue_id='RESOURCE-OWNER-PROFILE-1076',title='Paper Strategy Review Candle resource owner and cycle bottleneck audit',summary='Read-only owner/profile audit started before optimization.',remaining='Collect canonical process/cgroup/profile/trace evidence; do not optimize before owner is proven.'))

def _v1076_result_ledger(report: dict) -> None:
    stable={'findings':report.get('findings'),'trace_delta':report.get('trace_delta'),'sample_sec':report.get('sample_sec')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str).encode('utf-8')).hexdigest()
    common={'version':'v1076','ts':time.time(),'time':now(),'status':'CHECK','strategy_impact':'none_measurement_only','auto_buy':False,'source':'guard_resource_owner_audit_v1076','proof_digest':digest}
    _v1076_append_once('result:'+digest,BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1076',event_type='CHANGE_VERIFY',change_id='v1076-resource-owner-profile-001',issue_id='RESOURCE-OWNER-PROFILE-1076',summary='Resource owner/profile sample collected without strategy or ledger mutation.',remaining='Use measured top owner only for v1077 optimization; server repeat sample required after restart and next cycle.'))

def _v1076_top_phase_text(name: str, profile: dict) -> str:
    rows=[]
    if name=='paper':
        deep=profile.get('deep_v1076') if isinstance(profile.get('deep_v1076'),dict) else {}
        cycle=deep.get('cycle') if isinstance(deep.get('cycle'),dict) else {}
        rows=cycle.get('top_phases') if isinstance(cycle.get('top_phases'),list) else []
    elif name=='strategy':
        rows=profile.get('top_phases') if isinstance(profile.get('top_phases'),list) else []
    elif name=='review':
        rows=profile.get('phase_top') if isinstance(profile.get('phase_top'),list) else []
        return ', '.join(f'{x[0]} {float(x[1]):.2f}s' for x in rows[:3] if isinstance(x,(list,tuple)) and len(x)>=2) or '-'
    if rows:
        return ', '.join(f"{x.get('phase')} {float(x.get('wall_sec') or 0.0):.2f}s" for x in rows[:3] if isinstance(x,dict)) or '-'
    if name=='candle':
        phase=str(profile.get('phase') or '-'); sec=profile.get('last_sec')
        return f"{phase} / {float(sec):.2f}s" if isinstance(sec,(int,float)) else phase
    return '-'

def gresource_owner_text_v1076(sample_sec: int=20) -> str:
    sample_sec=max(5,min(30,int(sample_sec or 20)))
    _v1076_issue_open()
    before={name:_v1076_component_snapshot(name) for name in _RESOURCE_OWNER_SPECS_V1076}
    trace_before=_v1076_trace_sizes()
    time.sleep(sample_sec)
    after={name:_v1076_component_snapshot(name) for name in _RESOURCE_OWNER_SPECS_V1076}
    trace_after=_v1076_trace_sizes()
    components={}; findings={}
    for name in _RESOURCE_OWNER_SPECS_V1076:
        b=before[name]; a=after[name]
        bio=((b.get('proc') or {}).get('io') or {}); aio=((a.get('proc') or {}).get('io') or {})
        profile=_v1076_profile_extract(name,a.get('status_obj') if isinstance(a.get('status_obj'),dict) else {})
        b_compact={k:v for k,v in b.items() if k!='status_obj'}
        a_compact={k:v for k,v in a.items() if k!='status_obj'}
        row={'before':b_compact,'after':a_compact,'io_delta':_v1076_delta(bio,aio),'profile':profile}
        components[name]=row; findings[name]=_v1076_owner_reason(row)
    trace_delta={}
    for name in _RESOURCE_TRACE_SPECS_V1076:
        b=trace_before.get(name) or {}; a=trace_after.get(name) or {}
        trace_delta[name]={'before_bytes':int(b.get('bytes') or 0),'after_bytes':int(a.get('bytes') or 0),'delta_bytes':int(a.get('bytes') or 0)-int(b.get('bytes') or 0),'owner':a.get('owner') or b.get('owner')}
    report={'schema':'resource_owner_audit_v1076','version':'v1076','guard_version':VERSION,'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'read_only':True,'auto_buy':False,'strategy_changed':False,'ledger_deleted':False,'components':components,'findings':findings,'trace_delta':trace_delta,'next_action':'v1077 may remove only the largest measured duplicate I/O/copy/serialize owner while preserving candidate and ledger digests'}
    write_json(RESOURCE_OWNER_STATUS_V1076,report); _v1076_result_ledger(report)
    lines=[f'🧪 v1076 자원 owner 정밀감사 · {VERSION}',f'- 읽기 전용 {sample_sec}초 / 정리·삭제·재시작 0','- 전략·진입·청산·원장 변경 0 / 자동매수 OFF','']
    labels={'paper':'Paper','strategy':'Strategy','review':'Review','candle':'Candle'}
    for name in ('paper','strategy','review','candle'):
        f=findings[name]; row=components[name]; proc=((row.get('after') or {}).get('proc') or {}); cgroup=proc.get('cgroup') if isinstance(proc.get('cgroup'),dict) else {}; io=row.get('io_delta') or {}
        lines += [f"[{labels[name]}]",f"- 판정: {f.get('reason')}",f"- main RSS {_fmt_bytes(f.get('main_rss_bytes',0))} = anon {_fmt_bytes(f.get('rss_anon_bytes',0))} + file {_fmt_bytes(f.get('rss_file_bytes',0))}",f"- cgroup {_fmt_bytes(f.get('cgroup_current_bytes',0))} / 차이 {_fmt_bytes(f.get('cgroup_gap_bytes',0))} / file cache {_fmt_bytes(f.get('cgroup_file_bytes',0))} / extra proc RSS {_fmt_bytes(f.get('extra_cgroup_process_rss_bytes',0))}",f"- {sample_sec}초 I/O: read {_fmt_bytes(max(0,int(io.get('read_bytes') or 0)))} / write {_fmt_bytes(max(0,int(io.get('write_bytes') or 0)))} / cgroup PID {len(cgroup.get('pids') or [])}",f"- 단계 TOP: {_v1076_top_phase_text(name,row.get('profile') or {})}",'']
    lines += ['[대형 trace 증가]']
    for name,row in trace_delta.items(): lines.append(f"- {name}: {_audit_fmt_delta(row.get('delta_bytes',0))} / owner {row.get('owner')}")
    lines += ['', '[다음 행동]', '- 이 결과에서 가장 큰 실제 owner 1개만 v1077에서 수술', '- candidate·S1/S2/S3·trigger/invalid/target·OPEN/CLOSED digest 동일 검수 후 적용',f'- 원본 보고서: {RESOURCE_OWNER_STATUS_V1076.name}','- issue OPEN / change CHECK append 완료']
    return '\n'.join(lines)

STRATEGY_WRITER_VERIFY_STATUS_V1077 = BOT_DIR / 'strategy_writer_verify_v1077.json'

STRATEGY_WRITER_VERIFY_MARKER_V1077 = BOT_DIR / '.strategy_writer_verify_ledger_v1077.json'

STRATEGY_WRITER_BASELINE_AUDIT_SEC_V1077 = 5.18

def _v1077_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(STRATEGY_WRITER_VERIFY_MARKER_V1077) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key):
        return False
    _append_jsonl_fsync_v1074(path,row)
    done[event_key]={'ts':time.time(),'time':now()}
    write_json(STRATEGY_WRITER_VERIFY_MARKER_V1077,{'schema':'strategy_writer_verify_marker_v1077','events':done})
    return True

def _v1077_issue_open() -> None:
    row={
        'schema':'issue_event_v1077','event_type':'ISSUE','issue_id':'STRATEGY-WRITER-AUDIT-1077',
        'version':'v1077','ts':time.time(),'time':now(),'status':'OPEN',
        'title':'Strategy candidate writer full-row audit cost removal',
        'summary':'Retire the unused full-row str(row) sentinel scan and stop copying the growing status payload between eleven audit collectors.',
        'owner':'strategy_worker._v1021_collect_candidate_publish_status and collect_freshness_missing_status',
        'not_changed':['candidate compactor','S1/S2/S3','trigger','invalid','target','Paper OPEN/CLOSED','exact ledger','auto-buy'],
        'strategy_impact':'none_runtime_writer_optimization','auto_buy':False,
        'remaining':'Apply Strategy v0.993 and verify next candidate commit, phase time, contract counters, exact 0/0/0 and runtime hash.',
        'source':'guard_strategy_writer_verify_v1077',
    }
    _v1077_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',row)

def _v1077_profile_phase(profile: dict, phase_name: str) -> dict:
    phases=profile.get('phases') if isinstance(profile,dict) and isinstance(profile.get('phases'),dict) else {}
    row=phases.get(phase_name) if isinstance(phases.get(phase_name),dict) else {}
    return row if isinstance(row,dict) else {}

def _v1077_candidate_contract_snapshot(path: Path) -> dict:
    out={'rows':0,'parse_errors':0,'stage_counts':{},'s1_rows':0,'s1_missing_decision_key':0,'s1_missing_trigger':0,'s1_missing_invalid':0,'s1_missing_target':0}
    stages={}
    try:
        with path.open('r',encoding='utf-8',errors='ignore') as handle:
            for raw in handle:
                raw=raw.strip()
                if not raw: continue
                try: row=json.loads(raw)
                except Exception:
                    out['parse_errors']+=1; continue
                if not isinstance(row,dict): continue
                out['rows']+=1
                stage=str(row.get('s_stage') or row.get('candidate_stage') or row.get('candidate_grade') or row.get('grade') or '-')
                stages[stage]=int(stages.get(stage) or 0)+1
                if stage!='S1': continue
                out['s1_rows']+=1
                gate=row.get('swing_entry_gate_v977') if isinstance(row.get('swing_entry_gate_v977'),dict) else {}
                if not str(row.get('swing_gate_decision_key_v977') or gate.get('decision_key') or '').strip(): out['s1_missing_decision_key']+=1
                if not (row.get('swing_trigger_price_v977') or row.get('trigger_price') or gate.get('trigger_price')): out['s1_missing_trigger']+=1
                if not (row.get('swing_invalid_price_v977') or row.get('invalid_price') or gate.get('invalid_price')): out['s1_missing_invalid']+=1
                if not (row.get('swing_target_price_v977') or row.get('target_price') or gate.get('target_price')): out['s1_missing_target']+=1
    except Exception as exc:
        out['read_error']=f'{exc.__class__.__name__}: {exc}'
    out['stage_counts']=stages
    return out

def _v1077_writer_snapshot() -> dict:
    profile=read_json(BOT_DIR/'clean_strategy_cpu_profile_v1027.json') or {}
    writer=read_json(BOT_DIR/'clean_strategy_paper_latest_writer_status.json') or {}
    strategy=read_json(BOT_DIR/'clean_strategy_worker_status.json') or {}
    return {
        'ts':time.time(),
        'profile':profile if isinstance(profile,dict) else {},
        'writer':writer if isinstance(writer,dict) else {},
        'strategy':strategy if isinstance(strategy,dict) else {},
    }

def _v1077_commit_count(writer: dict) -> int:
    for key in ('candidate_total_commit_count_v1026','candidate_write_count_v1021','candidate_process_commit_count_v1026'):
        try:
            value=int(float(writer.get(key)))
            if value>=0: return value
        except Exception:
            continue
    return 0

def _v1077_result_ledger(report: dict) -> None:
    overall=bool(report.get('ok'))
    stable={k:report.get(k) for k in ('ok','checks','before_audit_sec','after_audit_sec','reduction_pct','exact','candidate_contract')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str).encode('utf-8')).hexdigest()
    common={
        'version':'v1077','ts':time.time(),'time':now(),'status':'DONE' if overall else 'CHECK',
        'strategy_impact':'none_runtime_writer_optimization','auto_buy':False,
        'source':'guard_strategy_writer_verify_v1077','proof_digest':digest,
    }
    change=dict(common,schema='change_verify_event_v1077',event_type='CHANGE_VERIFY',change_id='v1077-strategy-writer-audit-001',issue_id='STRATEGY-WRITER-AUDIT-1077',summary='Strategy candidate writer audit-cost change verified.' if overall else 'Strategy candidate writer audit-cost change requires another check.',remaining='Proceed to the next measured owner only.' if overall else 'Review failed check(s); do not change strategy thresholds or start another optimization.')
    issue=dict(common,schema='issue_event_v1077',event_type='ISSUE',issue_id='STRATEGY-WRITER-AUDIT-1077',title='Strategy candidate writer full-row audit cost removal',summary=change['summary'],remaining=change['remaining'])
    _v1077_append_once('change:'+digest,BOT_DIR/'change_verify_ledger.jsonl',change)
    _v1077_append_once(('issue_done:' if overall else 'issue_check:')+digest,BOT_DIR/'issue_ledger.jsonl',issue)

def gstrategy_writer_verify_text_v1077(sample_sec: int=35) -> str:
    sample_sec=max(20,min(60,int(sample_sec or 35)))
    _v1077_issue_open()
    before=_v1077_writer_snapshot()
    time.sleep(sample_sec)
    after=_v1077_writer_snapshot()
    writer=after.get('writer') if isinstance(after.get('writer'),dict) else {}
    strategy=after.get('strategy') if isinstance(after.get('strategy'),dict) else {}
    profile=after.get('profile') if isinstance(after.get('profile'),dict) else {}
    before_phase=_v1077_profile_phase(before.get('profile') if isinstance(before.get('profile'),dict) else {},'candidate_writer_full_row_audit')
    after_phase=_v1077_profile_phase(profile,'candidate_writer_full_row_audit')
    before_sec=float(before_phase.get('wall_sec') or 0.0)
    after_sec=float(after_phase.get('wall_sec') or 0.0)
    reduction=((STRATEGY_WRITER_BASELINE_AUDIT_SEC_V1077-after_sec)/STRATEGY_WRITER_BASELINE_AUDIT_SEC_V1077*100.0) if after_sec>=0 else 0.0
    target=BOT_DIR/'strategy_worker_v0.993.py'; active=BOT_DIR/'strategy_worker.py'
    active_state=is_service_active(WORKER_SPECS['strategy']['service'])
    exact_snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(exact_snapshot)
    contract=_v1077_candidate_contract_snapshot(BOT_DIR/'paper_candidates_latest.jsonl')
    before_count=_v1077_commit_count(before.get('writer') if isinstance(before.get('writer'),dict) else {})
    after_count=_v1077_commit_count(writer)
    commit_advanced=bool(after_count>before_count or float(writer.get('candidate_counter_status_updated_ts_v1026') or 0)>float((before.get('writer') or {}).get('candidate_counter_status_updated_ts_v1026') or 0))
    expected_version='strategy_worker_v0.993'
    checks={
        'runtime_active':str(active_state) in {'active','activating'},
        'runtime_version_exact':str(strategy.get('version') or '')==expected_version,
        'active_target_hash_exact':bool(active.exists() and target.exists() and short_hash(active)==short_hash(target)),
        'candidate_commit_advanced':commit_advanced,
        'writer_result_ok':str(writer.get('result') or '')=='OK',
        'collector_delta_merge_active':writer.get('candidate_audit_collector_merge_v1077')=='delta_update_no_accumulating_payload_copy',
        'full_row_text_scan_retired':writer.get('candidate_audit_full_row_text_scan_retired_v1077') is True,
        'candidate_validation_failures_zero':int(writer.get('candidate_validation_failures_v1021') or 0)==0,
        'candidate_hard_ceiling_zero':int(writer.get('candidate_over_hard_ceiling_v1021') or 0)==0,
        'role_source_consistency':writer.get('role_source_audit_consistency_v1007') is True,
        'candidate_parse_errors_zero':int(contract.get('parse_errors') or 0)==0 and not contract.get('read_error'),
        's1_contract_complete':all(int(contract.get(k) or 0)==0 for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target')),
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':strategy.get('auto_buy') in (False,0,None),
        'audit_phase_improved':bool(after_sec>0 and after_sec<STRATEGY_WRITER_BASELINE_AUDIT_SEC_V1077),
    }
    overall=all(checks.values())
    report={
        'schema':'strategy_writer_verify_v1077','version':'v1077','guard_version':VERSION,
        'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'ok':overall,
        'baseline_audit_sec':STRATEGY_WRITER_BASELINE_AUDIT_SEC_V1077,
        'before_audit_sec':round(before_sec,6),'after_audit_sec':round(after_sec,6),'reduction_pct':round(reduction,2),
        'before_commit_count':before_count,'after_commit_count':after_count,
        'checks':checks,'candidate_contract':contract,
        'writer_subphases':writer.get('candidate_audit_collector_elapsed_sec_v1077') or {},
        'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},
        'strategy_changed':False,'entry_exit_changed':False,'ledger_deleted':False,'auto_buy':False,
    }
    write_json(STRATEGY_WRITER_VERIFY_STATUS_V1077,report)
    _v1077_result_ledger(report)
    failed=[k for k,v in checks.items() if not v]
    lines=[
        f"🧪 v1077 Strategy writer 검수 · {VERSION}",
        f"- 판정: {'DONE' if overall else 'CHECK'} / 읽기 전용 {sample_sec}초",
        f"- runtime: {strategy.get('version') or '-'} / active-target hash {'일치' if checks['active_target_hash_exact'] else '불일치'} / commit {before_count}→{after_count}",
        f"- full-row audit: 기준 {STRATEGY_WRITER_BASELINE_AUDIT_SEC_V1077:.2f}s → 현재 {after_sec:.2f}s / 감소 {reduction:+.1f}%",
        f"- candidate: {contract.get('rows',0)}개 / S1 {contract.get('s1_rows',0)} / parse 오류 {contract.get('parse_errors',0)} / S1 계약누락 {sum(int(contract.get(k) or 0) for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target'))}",
        f"- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF",
        f"- 전략·진입·청산 변경 0 / OPEN·CLOSED·decision·exact 삭제 0",
    ]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    sub=report.get('writer_subphases') if isinstance(report.get('writer_subphases'),dict) else {}
    if sub:
        top=sorted(sub.items(),key=lambda kv:float(kv[1] or 0),reverse=True)[:5]
        lines.append('- 남은 audit TOP: '+', '.join(f'{k} {float(v):.3f}s' for k,v in top))
    lines += [f'- 원본 보고서: {STRATEGY_WRITER_VERIFY_STATUS_V1077.name}',f"- issue/change append: {'DONE' if overall else 'CHECK'}"]
    return '\n'.join(lines)

STRATEGY_OVERLAY_VERIFY_STATUS_V1078 = BOT_DIR / 'strategy_overlay_verify_v1078.json'

STRATEGY_OVERLAY_VERIFY_MARKER_V1078 = BOT_DIR / '.strategy_overlay_verify_ledger_v1078.json'

STRATEGY_OVERLAY_BASELINE_SEC_V1078 = 4.92

def _v1078_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(STRATEGY_OVERLAY_VERIFY_MARKER_V1078) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key):
        return False
    _append_jsonl_fsync_v1074(path,row)
    done[event_key]={'ts':time.time(),'time':now()}
    write_json(STRATEGY_OVERLAY_VERIFY_MARKER_V1078,{'schema':'strategy_overlay_verify_marker_v1078','events':done})
    return True

def _v1078_issue_open() -> None:
    row={
        'schema':'issue_event_v1078','event_type':'ISSUE','issue_id':'STRATEGY-CANDLE-OVERLAY-1078',
        'version':'v1078','ts':time.time(),'time':now(),'status':'OPEN',
        'title':'Strategy Candle overlay cache invalidated by checkpoint object identity',
        'summary':'Candle full checkpoint rebuilds Python row objects. v1032 used id(c), invalidating unchanged ticker cache entries and rerunning four legacy material wrappers.',
        'owner':'strategy_worker._v1032_candle_source_signature and _v597_candle_official_fields',
        'not_changed':['Candle values','candidate rows','S1/S2/S3','trigger','invalid','target','Paper OPEN/CLOSED','exact ledger','auto-buy'],
        'strategy_impact':'none_runtime_cache_identity_fix','auto_buy':False,
        'remaining':'Apply Strategy v0.994 and prove stable checkpoint reuse, overlay reduction, candidate contract and exact 0/0/0.',
        'source':'guard_strategy_overlay_verify_v1078',
    }
    _v1078_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',row)

def _v1078_overlay_snapshot() -> dict:
    return {
        'ts':time.time(),
        'profile':read_json(BOT_DIR/'clean_strategy_cpu_profile_v1027.json') or {},
        'writer':read_json(BOT_DIR/'clean_strategy_paper_latest_writer_status.json') or {},
        'strategy':read_json(BOT_DIR/'clean_strategy_worker_status.json') or {},
    }

def _v1078_profile_identity(profile: dict) -> str:
    if not isinstance(profile,dict): return ''
    for key in ('cycle_started_ts','started_ts','created_ts','updated_ts'):
        value=profile.get(key)
        if value not in (None,''): return f'{key}:{value}'
    phases=profile.get('phases') if isinstance(profile.get('phases'),dict) else {}
    return hashlib.sha256(json.dumps(phases,ensure_ascii=False,sort_keys=True,default=str).encode('utf-8')).hexdigest()[:16] if phases else ''

def _v1078_cache_status(strategy: dict) -> dict:
    value=strategy.get('candle_overlay_cache_v1032') if isinstance(strategy,dict) else {}
    return value if isinstance(value,dict) else {}

def _v1078_result_ledger(report: dict) -> None:
    overall=bool(report.get('ok'))
    stable={k:report.get(k) for k in ('ok','checks','overlay_samples_sec','cache_status','exact','candidate_contract')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str).encode('utf-8')).hexdigest()
    common={
        'version':'v1078','ts':time.time(),'time':now(),'status':'DONE' if overall else 'CHECK',
        'strategy_impact':'none_runtime_cache_identity_fix','auto_buy':False,
        'source':'guard_strategy_overlay_verify_v1078','proof_digest':digest,
    }
    change=dict(common,schema='change_verify_event_v1078',event_type='CHANGE_VERIFY',change_id='v1078-strategy-candle-overlay-001',issue_id='STRATEGY-CANDLE-OVERLAY-1078',summary='Strategy Candle overlay stable-identity cache verified.' if overall else 'Strategy Candle overlay stable-identity cache requires another check.',remaining='Proceed to the next measured owner only.' if overall else 'Review failed check(s); do not change strategy thresholds or optimize another owner.')
    issue=dict(common,schema='issue_event_v1078',event_type='ISSUE',issue_id='STRATEGY-CANDLE-OVERLAY-1078',title='Strategy Candle overlay cache invalidated by checkpoint object identity',summary=change['summary'],remaining=change['remaining'])
    _v1078_append_once('change:'+digest,BOT_DIR/'change_verify_ledger.jsonl',change)
    _v1078_append_once(('issue_done:' if overall else 'issue_check:')+digest,BOT_DIR/'issue_ledger.jsonl',issue)

def gstrategy_overlay_verify_text_v1078(sample_sec: int=95) -> str:
    sample_sec=max(60,min(150,int(sample_sec or 95)))
    _v1078_issue_open()
    before=_v1078_overlay_snapshot()
    before_writer=before.get('writer') if isinstance(before.get('writer'),dict) else {}
    before_count=_v1077_commit_count(before_writer)
    seen=set(); samples=[]; cache_samples=[]
    deadline=time.time()+sample_sec
    while time.time()<deadline:
        snap=_v1078_overlay_snapshot()
        profile=snap.get('profile') if isinstance(snap.get('profile'),dict) else {}
        identity=_v1078_profile_identity(profile)
        if identity and identity not in seen:
            seen.add(identity)
            phase=_v1077_profile_phase(profile,'candle_cache_row_overlay')
            sec=float(phase.get('wall_sec') or 0.0)
            if sec>0:
                samples.append(round(sec,6))
            cache=_v1078_cache_status(snap.get('strategy') if isinstance(snap.get('strategy'),dict) else {})
            if cache:
                cache_samples.append(dict(cache))
        time.sleep(min(2.0,max(0.1,deadline-time.time())))
    after=_v1078_overlay_snapshot()
    writer=after.get('writer') if isinstance(after.get('writer'),dict) else {}
    strategy=after.get('strategy') if isinstance(after.get('strategy'),dict) else {}
    profile=after.get('profile') if isinstance(after.get('profile'),dict) else {}
    identity=_v1078_profile_identity(profile)
    if identity and identity not in seen:
        phase=_v1077_profile_phase(profile,'candle_cache_row_overlay')
        sec=float(phase.get('wall_sec') or 0.0)
        if sec>0: samples.append(round(sec,6))
    cache=_v1078_cache_status(strategy)
    if cache: cache_samples.append(dict(cache))
    target=BOT_DIR/'strategy_worker_v0.994.py'; active=BOT_DIR/'strategy_worker.py'
    active_state=is_service_active(WORKER_SPECS['strategy']['service'])
    exact_snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(exact_snapshot)
    contract=_v1077_candidate_contract_snapshot(BOT_DIR/'paper_candidates_latest.jsonl')
    after_count=_v1077_commit_count(writer)
    commit_advanced=bool(after_count>before_count or float(writer.get('candidate_counter_status_updated_ts_v1026') or 0)>float(before_writer.get('candidate_counter_status_updated_ts_v1026') or 0))
    max_sec=max(samples) if samples else 0.0
    avg_sec=(sum(samples)/len(samples)) if samples else 0.0
    object_reuse=max([int(float(x.get('checkpoint_object_rebuild_reuse_v1078') or 0)) for x in cache_samples] or [0])
    hits=max([int(float(x.get('hits') or 0)) for x in cache_samples] or [0])
    misses=max([int(float(x.get('misses') or 0)) for x in cache_samples] or [0])
    checks={
        'runtime_active':str(active_state) in {'active','activating'},
        'runtime_version_exact':str(strategy.get('version') or '')=='strategy_worker_v0.994',
        'active_target_hash_exact':bool(active.exists() and target.exists() and short_hash(active)==short_hash(target)),
        'candidate_commit_advanced':commit_advanced,
        'writer_result_ok':str(writer.get('result') or '')=='OK',
        'stable_signature_active':cache.get('schema')=='strategy_candle_overlay_cache_v1078_stable_identity',
        'python_object_id_retired':cache.get('python_object_id_in_signature_v1078') is False,
        'exact_overlay_output_preserved':cache.get('exact_overlay_output_preserved_v1078') is True,
        'checkpoint_object_reuse_proven':object_reuse>0,
        'overlay_samples_present':len(samples)>=1,
        'overlay_phase_improved':bool(max_sec>0 and max_sec<STRATEGY_OVERLAY_BASELINE_SEC_V1078),
        'candidate_parse_errors_zero':int(contract.get('parse_errors') or 0)==0 and not contract.get('read_error'),
        's1_contract_complete':all(int(contract.get(k) or 0)==0 for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target')),
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':strategy.get('auto_buy') in (False,0,None),
    }
    overall=all(checks.values())
    report={
        'schema':'strategy_overlay_verify_v1078','version':'v1078','guard_version':VERSION,
        'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'ok':overall,
        'baseline_overlay_sec':STRATEGY_OVERLAY_BASELINE_SEC_V1078,
        'overlay_samples_sec':samples,'overlay_avg_sec':round(avg_sec,6),'overlay_max_sec':round(max_sec,6),
        'before_commit_count':before_count,'after_commit_count':after_count,
        'cache_status':cache,'cache_samples':cache_samples[-6:],
        'cache_summary':{'hits':hits,'misses':misses,'checkpoint_object_rebuild_reuse_v1078':object_reuse},
        'checks':checks,'candidate_contract':contract,
        'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},
        'strategy_changed':False,'entry_exit_changed':False,'ledger_deleted':False,'auto_buy':False,
    }
    write_json(STRATEGY_OVERLAY_VERIFY_STATUS_V1078,report)
    _v1078_result_ledger(report)
    failed=[k for k,v in checks.items() if not v]
    reduction=((STRATEGY_OVERLAY_BASELINE_SEC_V1078-avg_sec)/STRATEGY_OVERLAY_BASELINE_SEC_V1078*100.0) if avg_sec>0 else 0.0
    lines=[
        f"🧪 v1078 Strategy Candle overlay 검수 · {VERSION}",
        f"- 판정: {'DONE' if overall else 'CHECK'} / 읽기 전용 {sample_sec}초",
        f"- runtime: {strategy.get('version') or '-'} / active-target hash {'일치' if checks['active_target_hash_exact'] else '불일치'} / commit {before_count}→{after_count}",
        f"- overlay: 기준 {STRATEGY_OVERLAY_BASELINE_SEC_V1078:.2f}s → 표본 {', '.join(f'{x:.2f}s' for x in samples) if samples else '-'} / 평균 {avg_sec:.2f}s / 감소 {reduction:+.1f}%",
        f"- cache: hit {hits} / miss {misses} / full-checkpoint 객체 재생성 재사용 {object_reuse}",
        f"- candidate: {contract.get('rows',0)}개 / S1 {contract.get('s1_rows',0)} / parse 오류 {contract.get('parse_errors',0)} / S1 계약누락 {sum(int(contract.get(k) or 0) for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target'))}",
        f"- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF",
        f"- 전략·진입·청산 변경 0 / OPEN·CLOSED·decision·exact 삭제 0",
    ]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    lines += [f'- 원본 보고서: {STRATEGY_OVERLAY_VERIFY_STATUS_V1078.name}',f"- issue/change append: {'DONE' if overall else 'CHECK'}"]
    return '\n'.join(lines)

HOTPATH_VERIFY_STATUS_V1079 = BOT_DIR / 'hotpath_verify_v1079.json'

HOTPATH_VERIFY_MARKER_V1079 = BOT_DIR / '.hotpath_verify_ledger_v1079.json'

V1079_STRATEGY_BASELINE_SEC = 3.91

V1079_PAPER_BASELINE_SEC = 7.31

V1079_REVIEW_BASELINE_SEC = 10.76

def _v1079_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(HOTPATH_VERIFY_MARKER_V1079) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key):
        return False
    _append_jsonl_fsync_v1074(path,row)
    done[event_key]={'ts':time.time(),'time':now()}
    write_json(HOTPATH_VERIFY_MARKER_V1079,{'schema':'hotpath_verify_marker_v1079','events':done})
    return True

def _v1079_issue_open() -> None:
    row={
        'schema':'issue_event_v1079','event_type':'ISSUE','issue_id':'INTEGRATED-HOTPATH-1079',
        'version':'v1079','ts':time.time(),'time':now(),'status':'OPEN',
        'title':'Strategy/Paper/Review repeated serialization, duplicate price fetch and derived-index reload',
        'summary':'Three measured owners shared unnecessary runtime work: scalar JSON sizing per candidate field, Paper-owned duplicate ALL_KRW entry confirmation fetch, and Review full derived-index JSON reload.',
        'owners':['strategy_worker candidate compactor','paper_bot entry trigger confirmation price','review_worker performance derived indexes'],
        'not_changed':['S1/S2/S3','trigger','invalid','target','spread','slippage','entry/exit thresholds','OPEN/CLOSED/decision/exact ledgers','auto-buy'],
        'strategy_impact':'none_runtime_owner_and_serialization_cleanup','auto_buy':False,
        'remaining':'Apply Strategy v0.995, Paper v1.002, Review v0.996 and prove runtime/hash, reduced phases, exact contract and ledger invariants.',
        'source':'guard_hotpath_verify_v1079',
    }
    _v1079_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',row)

def _v1079_median(values: list[float]) -> float:
    vals=sorted(float(x) for x in values if float(x)>=0)
    if not vals: return 0.0
    n=len(vals); mid=n//2
    return vals[mid] if n%2 else (vals[mid-1]+vals[mid])/2.0

def _v1079_paper_phase(status: dict, name: str) -> float:
    deep=status.get('paper_resource_profile_v1076') if isinstance(status,dict) and isinstance(status.get('paper_resource_profile_v1076'),dict) else {}
    cycle=deep.get('cycle') if isinstance(deep.get('cycle'),dict) else {}
    phases=cycle.get('phases') if isinstance(cycle.get('phases'),dict) else {}
    row=phases.get(name) if isinstance(phases.get(name),dict) else {}
    return float(row.get('wall_sec') or 0.0)

def _v1079_paper_cycle_id(status: dict) -> str:
    deep=status.get('paper_resource_profile_v1076') if isinstance(status,dict) and isinstance(status.get('paper_resource_profile_v1076'),dict) else {}
    cycle=deep.get('cycle') if isinstance(deep.get('cycle'),dict) else {}
    value=cycle.get('finished_ts') or cycle.get('started_ts')
    return str(value or '')

def _v1079_review_memory_hits(perf: dict) -> dict:
    stats=perf.get('performance_index_memory_cache_v1079') if isinstance(perf,dict) and isinstance(perf.get('performance_index_memory_cache_v1079'),dict) else {}
    return {
        'structure':int(float(stats.get('structure_memory_hits') or 0)),
        'cost':int(float(stats.get('cost_memory_hits') or 0)),
        'c_shadow':int(float(stats.get('c_shadow_memory_hits') or 0)),
        'structure_disk':int(float(stats.get('structure_disk_loads') or 0)),
        'cost_disk':int(float(stats.get('cost_disk_loads') or 0)),
        'c_shadow_disk':int(float(stats.get('c_shadow_disk_loads') or 0)),
    }

def _v1079_result_ledger(report: dict) -> None:
    overall=bool(report.get('ok'))
    stable={k:report.get(k) for k in ('ok','checks','strategy_samples_sec','paper_samples_sec','review','exact','candidate_contract')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str).encode('utf-8')).hexdigest()
    common={
        'version':'v1079','ts':time.time(),'time':now(),'status':'DONE' if overall else 'CHECK',
        'strategy_impact':'none_runtime_owner_and_serialization_cleanup','auto_buy':False,
        'source':'guard_hotpath_verify_v1079','proof_digest':digest,
    }
    summary='Integrated Strategy/Paper/Review hotpath cleanup verified.' if overall else 'Integrated hotpath cleanup requires another server check.'
    remaining='Proceed to disk/trace integrated cleanup.' if overall else 'Review only the failed proof item; do not alter strategy thresholds or ledgers.'
    change=dict(common,schema='change_verify_event_v1079',event_type='CHANGE_VERIFY',change_id='v1079-integrated-hotpath-001',issue_id='INTEGRATED-HOTPATH-1079',summary=summary,remaining=remaining)
    issue=dict(common,schema='issue_event_v1079',event_type='ISSUE',issue_id='INTEGRATED-HOTPATH-1079',title='Strategy/Paper/Review integrated hotpath cleanup',summary=summary,remaining=remaining)
    _v1079_append_once('change:'+digest,BOT_DIR/'change_verify_ledger.jsonl',change)
    _v1079_append_once(('issue_done:' if overall else 'issue_check:')+digest,BOT_DIR/'issue_ledger.jsonl',issue)

def ghotpath_verify_text_v1079(sample_sec: int=360) -> str:
    sample_sec=max(120,min(720,int(sample_sec or 360)))
    _v1079_issue_open()
    before_writer=read_json(BOT_DIR/'clean_strategy_paper_latest_writer_status.json') or {}
    before_count=_v1077_commit_count(before_writer)
    review_before=_v1076_component_snapshot('review')
    seen_strategy=set(); seen_paper=set(); strategy_samples=[]; paper_samples=[]
    last_progress=time.time(); deadline=time.time()+sample_sec
    review_hits={'structure':0,'cost':0,'c_shadow':0,'structure_disk':0,'cost_disk':0,'c_shadow_disk':0}
    review_perf={}
    while time.time()<deadline:
        profile=read_json(BOT_DIR/'clean_strategy_cpu_profile_v1027.json') or {}
        sid=_v1078_profile_identity(profile)
        if sid and sid not in seen_strategy:
            seen_strategy.add(sid)
            sec=float((_v1077_profile_phase(profile,'candidate_writer_compact_single_pass') or {}).get('wall_sec') or 0.0)
            if sec>0: strategy_samples.append(round(sec,6))
        paper=read_json(BOT_DIR/'paper_bot_status.json') or {}
        pid=_v1079_paper_cycle_id(paper)
        if pid and pid not in seen_paper:
            seen_paper.add(pid)
            sec=_v1079_paper_phase(paper,'candidate_select')
            if sec>0: paper_samples.append(round(sec,6))
        review_perf=read_json(BOT_DIR/'clean_performance_lab_status_v959.json') or {}
        review_hits=_v1079_review_memory_hits(review_perf)
        ready_samples=len(strategy_samples)>=2 and len(paper_samples)>=2
        ready_review=all(review_hits.get(k,0)>0 for k in ('structure','cost','c_shadow'))
        if ready_samples and ready_review:
            break
        if time.time()-last_progress>=60:
            last_progress=time.time()
            progress_notify(f"🧪 v1079 검수 진행\n- Strategy 표본 {len(strategy_samples)} / Paper 표본 {len(paper_samples)}\n- Review memory hit {review_hits.get('structure',0)}/{review_hits.get('cost',0)}/{review_hits.get('c_shadow',0)}\n- 전략·원장 변경 없이 계속 확인 중")
        time.sleep(min(2.0,max(0.1,deadline-time.time())))
    strategy=read_json(BOT_DIR/'clean_strategy_worker_status.json') or {}
    writer=read_json(BOT_DIR/'clean_strategy_paper_latest_writer_status.json') or {}
    paper=read_json(BOT_DIR/'paper_bot_status.json') or {}
    review=read_json(BOT_DIR/'clean_review_worker_status.json') or {}
    review_perf=read_json(BOT_DIR/'clean_performance_lab_status_v959.json') or review_perf
    review_hits=_v1079_review_memory_hits(review_perf)
    review_after=_v1076_component_snapshot('review')
    contract=_v1077_candidate_contract_snapshot(BOT_DIR/'paper_candidates_latest.jsonl')
    exact_snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(exact_snapshot)
    after_count=_v1077_commit_count(writer)
    price_owner=paper.get('paper_entry_price_owner_v1079') if isinstance(paper.get('paper_entry_price_owner_v1079'),dict) else {}
    strategy_median=_v1079_median(strategy_samples); paper_median=_v1079_median(paper_samples)
    review_sec=float(review_perf.get('cycle_sec') or 0.0)
    strategy_active=BOT_DIR/WORKER_SPECS['strategy']['active']; strategy_target=BOT_DIR/'strategy_worker_v0.995.py'
    paper_active=BOT_DIR/PAPER_ACTIVE_FILE; paper_target=BOT_DIR/'paper_bot_v1.002.py'
    review_active=BOT_DIR/WORKER_SPECS['review']['active']; review_target=BOT_DIR/'review_worker_v0.996.py'
    strategy_marker=bool(writer.get('candidate_compactor_scalar_field_fastpath_v1079') is True and writer.get('candidate_compactor_context_identity_reuse_v1079') is True)
    review_cache_proven=all(review_hits.get(k,0)>0 for k in ('structure','cost','c_shadow'))
    checks={
        'strategy_runtime_version':str(strategy.get('version') or '')=='strategy_worker_v0.995',
        'paper_runtime_version':str(paper.get('version') or '')=='paper_bot_v1.002',
        'review_runtime_version':str(review.get('version') or '')=='review_worker_v0.996',
        'strategy_hash_exact':bool(strategy_active.exists() and strategy_target.exists() and short_hash(strategy_active)==short_hash(strategy_target)),
        'paper_hash_exact':bool(paper_active.exists() and paper_target.exists() and short_hash(paper_active)==short_hash(paper_target)),
        'review_hash_exact':bool(review_active.exists() and review_target.exists() and short_hash(review_active)==short_hash(review_target)),
        'strategy_commit_advanced':after_count>before_count,
        'strategy_fastpath_marker':strategy_marker,
        'strategy_samples_present':len(strategy_samples)>=1,
        'strategy_compactor_improved':bool(strategy_median>0 and strategy_median<V1079_STRATEGY_BASELINE_SEC),
        'paper_owner_marker':price_owner.get('owner')=='orderflow.scanner_rest_price_with_paper_rest_fallback',
        'paper_owner_cache_errors_zero':int(price_owner.get('cache_error_count') or 0)==0,
        'paper_exit_owner_unchanged':price_owner.get('exit_price_owner_changed') is False,
        'paper_trigger_threshold_unchanged':price_owner.get('trigger_threshold_changed') is False,
        'paper_samples_present':len(paper_samples)>=1,
        'paper_candidate_select_improved':bool(paper_median>0 and paper_median<V1079_PAPER_BASELINE_SEC),
        'review_memory_reuse_proven':review_cache_proven,
        'review_performance_improved':bool(review_cache_proven and review_sec>0 and review_sec<V1079_REVIEW_BASELINE_SEC),
        'candidate_parse_errors_zero':int(contract.get('parse_errors') or 0)==0 and not contract.get('read_error'),
        's1_contract_complete':all(int(contract.get(k) or 0)==0 for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target')),
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':all(x.get('auto_buy') in (False,0,None) for x in (strategy,paper,review)),
    }
    overall=all(checks.values())
    before_mem=int((((review_before.get('proc') or {}).get('cgroup') or {}).get('memory_current_bytes') or 0))
    after_mem=int((((review_after.get('proc') or {}).get('cgroup') or {}).get('memory_current_bytes') or 0))
    report={
        'schema':'integrated_hotpath_verify_v1079','version':'v1079','guard_version':VERSION,
        'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'ok':overall,'checks':checks,
        'strategy_samples_sec':strategy_samples,'strategy_median_sec':round(strategy_median,6),'strategy_baseline_sec':V1079_STRATEGY_BASELINE_SEC,
        'paper_samples_sec':paper_samples,'paper_median_sec':round(paper_median,6),'paper_baseline_sec':V1079_PAPER_BASELINE_SEC,'paper_price_owner':price_owner,
        'review':{'cycle_sec':review_sec,'baseline_sec':V1079_REVIEW_BASELINE_SEC,'memory_hits':review_hits,'cgroup_before_bytes':before_mem,'cgroup_after_bytes':after_mem,'cgroup_delta_bytes':after_mem-before_mem},
        'before_commit_count':before_count,'after_commit_count':after_count,'candidate_contract':contract,
        'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},
        'strategy_changed':False,'entry_exit_threshold_changed':False,'ledger_deleted':False,'auto_buy':False,
    }
    write_json(HOTPATH_VERIFY_STATUS_V1079,report)
    _v1079_result_ledger(report)
    failed=[k for k,v in checks.items() if not v]
    sreduce=((V1079_STRATEGY_BASELINE_SEC-strategy_median)/V1079_STRATEGY_BASELINE_SEC*100.0) if strategy_median>0 else 0.0
    preduce=((V1079_PAPER_BASELINE_SEC-paper_median)/V1079_PAPER_BASELINE_SEC*100.0) if paper_median>0 else 0.0
    rreduce=((V1079_REVIEW_BASELINE_SEC-review_sec)/V1079_REVIEW_BASELINE_SEC*100.0) if review_sec>0 else 0.0
    lines=[
        f"🧪 v1079 통합 병목 검수 · {VERSION}",
        f"- 판정: {'DONE' if overall else 'CHECK'} / 읽기 전용 {sample_sec}초",
        f"- runtime: Strategy {strategy.get('version') or '-'} / Paper {paper.get('version') or '-'} / Review {review.get('version') or '-'}",
        f"- Strategy 압축: 기준 {V1079_STRATEGY_BASELINE_SEC:.2f}s → 중앙값 {strategy_median:.2f}s / 감소 {sreduce:+.1f}% / 표본 {len(strategy_samples)}",
        f"- Paper 후보선별: 기준 {V1079_PAPER_BASELINE_SEC:.2f}s → 중앙값 {paper_median:.2f}s / 감소 {preduce:+.1f}% / local {int(price_owner.get('local_hit_count') or 0)} fallback {int(price_owner.get('rest_fallback_count') or 0)}",
        f"- Review 성과분석: 기준 {V1079_REVIEW_BASELINE_SEC:.2f}s → 현재 {review_sec:.2f}s / 감소 {rreduce:+.1f}% / memory hit {review_hits.get('structure',0)}/{review_hits.get('cost',0)}/{review_hits.get('c_shadow',0)}",
        f"- candidate: {contract.get('rows',0)}개 / S1 {contract.get('s1_rows',0)} / parse 오류 {contract.get('parse_errors',0)} / 계약누락 {sum(int(contract.get(k) or 0) for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target'))}",
        f"- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF",
        f"- Review cgroup 변화: {(after_mem-before_mem)/1048576.0:+.1f}MB (판정 참고값)",
        '- 전략수치·진입·청산·OPEN/CLOSED/decision/exact 변경 0',
    ]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    lines += [f'- 원본 보고서: {HOTPATH_VERIFY_STATUS_V1079.name}',f"- issue/change append: {'DONE' if overall else 'CHECK'}"]
    return '\n'.join(lines)

DISK_BOUND_VERIFY_STATUS_V1080 = BOT_DIR / 'disk_bound_verify_v1080.json'

DISK_BOUND_VERIFY_MARKER_V1080 = BOT_DIR / '.disk_bound_verify_ledger_v1080.json'

def _v1080_file_bytes(path: Path) -> int:
    try: return int(path.stat().st_size)
    except OSError: return 0

def _v1080_archive_snapshot(directory: Path, pattern: str) -> dict:
    try:
        files=sorted((x for x in directory.glob(pattern) if x.is_file()),key=lambda x:(x.stat().st_mtime_ns,x.name),reverse=True) if directory.exists() else []
    except OSError:
        files=[]
    return {'files':len(files),'bytes':sum(_v1080_file_bytes(x) for x in files),'sample':[x.name for x in files[:5]]}

def _v1080_watch_snapshot() -> dict:
    active_specs={
        'structure_detail':('structure_lab_event_detail_ledger_v956.jsonl',32*1024*1024),
        'structure_horizon':('structure_lab_horizon_result_ledger_v956.jsonl',32*1024*1024),
        'structure_final':('structure_lab_event_final_ledger_v956.jsonl',16*1024*1024),
        'good_s2_result':('good_s2_result_ledger.jsonl',16*1024*1024),
        'quality_shadow':('quality_shadow_result_ledger_v946.jsonl',50*1024*1024),
        'hot_watch':('clean_hot_watch_strategy_events.jsonl',16*1024*1024),
        'good_s2_observation':('good_s2_observation_ledger.jsonl',50*1024*1024),
        'candle_delta':('clean_candle_delta_v1014.jsonl',8*1024*1024),
    }
    active={}
    for key,(name,cap) in active_specs.items():
        path=BOT_DIR/name; active[key]={'path':name,'bytes':_v1080_file_bytes(path),'cap_bytes':cap,'within_cap':_v1080_file_bytes(path)<=cap}
    archive_specs={
        'structure_detail':(BOT_DIR/'trace_archive_v1080'/'structure_detail','structure_detail_*.jsonl.gz',2,160*1024*1024),
        'structure_horizon':(BOT_DIR/'trace_archive_v1080'/'structure_horizon','structure_horizon_*.jsonl.gz',2,160*1024*1024),
        'structure_final':(BOT_DIR/'trace_archive_v1080'/'structure_final','structure_final_*.jsonl.gz',2,160*1024*1024),
        'good_s2_result':(BOT_DIR/'trace_archive_v1080'/'good_s2_result','good_s2_result_*.jsonl.gz',2,64*1024*1024),
        'quality_shadow':(BOT_DIR/'quality_shadow_archive','quality_shadow_result_*.jsonl.gz',2,64*1024*1024),
        'hot_watch':(BOT_DIR/'trace_archive_v1080'/'hot_watch','hot_watch_*.jsonl.gz',2,48*1024*1024),
        'good_s2_observation':(BOT_DIR/'archive','good_s2_observation_*.jsonl.gz',2,64*1024*1024),
    }
    archives={}
    for key,(directory,pattern,max_files,max_bytes) in archive_specs.items():
        row=_v1080_archive_snapshot(directory,pattern); row.update({'max_files':max_files,'max_bytes':max_bytes,'within_cap':row['files']<=max_files and row['bytes']<=max_bytes})
        archives[key]=row
    pending=[]
    try:
        for path in BOT_DIR.rglob('*.rotate_pending_v1080.*'):
            if path.is_file(): pending.append({'path':str(path.relative_to(BOT_DIR)),'bytes':_v1080_file_bytes(path)})
    except OSError:
        pass
    stale_quality_tmp=[]
    try:
        for path in BOT_DIR.glob('clean_quality_shadow_state_v946.json.tmp.*'):
            if path.is_file(): stale_quality_tmp.append({'path':path.name,'bytes':_v1080_file_bytes(path)})
    except OSError:
        pass
    total=sum(x['bytes'] for x in active.values())+sum(x['bytes'] for x in archives.values())+sum(x['bytes'] for x in pending)+sum(x['bytes'] for x in stale_quality_tmp)
    usage=shutil.disk_usage(BOT_DIR)
    return {'ts':time.time(),'active':active,'archives':archives,'pending':pending,'stale_quality_tmp':stale_quality_tmp,'bounded_total_bytes':total,'disk':{'total':usage.total,'used':usage.used,'free':usage.free}}

def _v1080_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(DISK_BOUND_VERIFY_MARKER_V1080) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key): return False
    _append_jsonl_fsync_v1074(path,row); done[event_key]={'ts':time.time(),'time':now()}
    write_json(DISK_BOUND_VERIFY_MARKER_V1080,{'schema':'disk_bound_verify_marker_v1080','events':done})
    return True

def _v1080_issue_open() -> None:
    row={'schema':'issue_event_v1080','event_type':'ISSUE','issue_id':'BOUNDED-NONCORE-TRACE-1080','version':'v1080','ts':time.time(),'time':now(),'status':'OPEN','title':'Non-core JSONL rotation retained unbounded active files or unlimited gzip archives','summary':'Trace producers are being converted to active-size and archive-count/bytes bounded rotation.','remaining':'Verify runtime versions, active caps, archive caps, pending files, exact 0/0/0 and auto-buy OFF.','strategy_impact':'none','auto_buy':False}
    _v1080_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',row)

def _v1080_result_ledger(report: dict) -> None:
    overall=bool(report.get('ok')); stable={k:report.get(k) for k in ('ok','checks','before','after','growth','exact')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    common={'version':'v1080','ts':time.time(),'time':now(),'status':'DONE' if overall else 'CHECK','strategy_impact':'none_noncore_trace_rotation','auto_buy':False,'source':'guard_disk_bound_verify_v1080','proof_digest':digest}
    summary='Non-core active traces and gzip archives are bounded and runtime verification passed.' if overall else 'One or more v1080 trace bounds or runtime checks require review.'
    remaining='Proceed to final owner/system closeout.' if overall else 'Do not delete core ledgers; inspect failed checks and rotation status.'
    change=dict(common,schema='change_verify_event_v1080',event_type='CHANGE_VERIFY',change_id='v1080-bounded-trace-001',issue_id='BOUNDED-NONCORE-TRACE-1080',summary=summary,remaining=remaining)
    issue=dict(common,schema='issue_event_v1080',event_type='ISSUE',issue_id='BOUNDED-NONCORE-TRACE-1080',title='Bounded non-core trace rotation',summary=summary,remaining=remaining)
    _v1080_append_once('change:'+digest,BOT_DIR/'change_verify_ledger.jsonl',change)
    _v1080_append_once(('issue_done:' if overall else 'issue_check:')+digest,BOT_DIR/'issue_ledger.jsonl',issue)

def gdisk_bound_verify_text_v1080(sample_sec: int=120) -> str:
    sample_sec=max(30,min(300,int(sample_sec or 120))); _v1080_issue_open()
    deadline=time.time()+sample_sec; last_progress=time.time(); review_status={}; strategy_status={}
    while time.time()<deadline:
        review_status=read_json(BOT_DIR/'clean_review_trace_rotation_status_v1080.json') or {}
        strategy_status=read_json(BOT_DIR/'clean_strategy_trace_rotation_status_v1080.json') or {}
        review_runtime=read_json(BOT_DIR/'clean_review_worker_status.json') or {}
        strategy_runtime=read_json(BOT_DIR/'clean_strategy_worker_status.json') or {}
        ready=(str(review_runtime.get('version') or '')=='review_worker_v0.997' and str(strategy_runtime.get('version') or '')=='strategy_worker_v0.996' and review_status.get('schema')=='review_trace_rotation_status_v1080' and strategy_status.get('schema')=='strategy_trace_rotation_status_v1080')
        pending=list(BOT_DIR.rglob('*.rotate_pending_v1080.*'))
        if ready and not pending: break
        if time.time()-last_progress>=30:
            last_progress=time.time(); progress_notify('🧪 v1080 디스크 검수 진행\n- Review/Strategy rotation status와 기존 대형 trace 압축 완료를 기다리는 중\n- 핵심 원장과 전략 수치는 건드리지 않음')
        time.sleep(min(2.0,max(0.1,deadline-time.time())))
    before=_v1080_watch_snapshot(); growth_wait=min(20,max(5,int(sample_sec/4))); time.sleep(growth_wait); after=_v1080_watch_snapshot()
    strategy=read_json(BOT_DIR/'clean_strategy_worker_status.json') or {}; review=read_json(BOT_DIR/'clean_review_worker_status.json') or {}; paper=read_json(BOT_DIR/'paper_bot_status.json') or {}
    review_status=read_json(BOT_DIR/'clean_review_trace_rotation_status_v1080.json') or review_status
    strategy_status=read_json(BOT_DIR/'clean_strategy_trace_rotation_status_v1080.json') or strategy_status
    exact_snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}; exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(exact_snapshot)
    contract=_v1077_candidate_contract_snapshot(BOT_DIR/'paper_candidates_latest.jsonl')
    strategy_active=BOT_DIR/WORKER_SPECS['strategy']['active']; strategy_target=BOT_DIR/'strategy_worker_v0.996.py'
    review_active=BOT_DIR/WORKER_SPECS['review']['active']; review_target=BOT_DIR/'review_worker_v0.997.py'
    active_caps=all(bool(x.get('within_cap')) for x in after.get('active',{}).values())
    archive_caps=all(bool(x.get('within_cap')) for x in after.get('archives',{}).values())
    pending_zero=len(after.get('pending') or [])==0
    stale_quality_tmp_zero=len(after.get('stale_quality_tmp') or [])==0
    review_errors=[]
    for row in ((review_status.get('results') or {}).values() if isinstance(review_status.get('results'),dict) else []):
        if isinstance(row,dict) and row.get('error'): review_errors.append(str(row.get('error')))
    strategy_errors=[]
    for key in ('last_hot_watch_rotation','last_good_s2_rotation'):
        row=strategy_status.get(key) if isinstance(strategy_status.get(key),dict) else {}
        if row.get('error'): strategy_errors.append(str(row.get('error')))
    checks={
        'strategy_runtime_version':str(strategy.get('version') or '')=='strategy_worker_v0.996',
        'review_runtime_version':str(review.get('version') or '')=='review_worker_v0.997',
        'strategy_hash_exact':bool(strategy_active.exists() and strategy_target.exists() and short_hash(strategy_active)==short_hash(strategy_target)),
        'review_hash_exact':bool(review_active.exists() and review_target.exists() and short_hash(review_active)==short_hash(review_target)),
        'review_rotation_status_ready':review_status.get('schema')=='review_trace_rotation_status_v1080',
        'strategy_rotation_status_ready':strategy_status.get('schema')=='strategy_trace_rotation_status_v1080',
        'active_files_within_caps':active_caps,
        'archive_sets_within_caps':archive_caps,
        'rotation_pending_zero':pending_zero,
        'stale_quality_tmp_zero':stale_quality_tmp_zero,
        'rotation_errors_zero':not review_errors and not strategy_errors,
        'candidate_parse_errors_zero':int(contract.get('parse_errors') or 0)==0 and not contract.get('read_error'),
        's1_contract_complete':all(int(contract.get(k) or 0)==0 for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target')),
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':all(x.get('auto_buy') in (False,0,None) for x in (strategy,review,paper)),
        'core_ledger_change_flag_false':review_status.get('core_ledgers_changed') is False,
        'strategy_rule_change_flag_false':review_status.get('strategy_rules_changed') is False and strategy_status.get('strategy_rules_changed') is False,
    }
    overall=all(checks.values())
    growth={'sample_sec':growth_wait,'bounded_total_delta_bytes':int(after.get('bounded_total_bytes') or 0)-int(before.get('bounded_total_bytes') or 0),'disk_used_delta_bytes':int((after.get('disk') or {}).get('used') or 0)-int((before.get('disk') or {}).get('used') or 0),'disk_free_bytes':int((after.get('disk') or {}).get('free') or 0)}
    report={'schema':'disk_bound_verify_v1080','version':'v1080','guard_version':VERSION,'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'ok':overall,'checks':checks,'before':before,'after':after,'growth':growth,'review_status':review_status,'strategy_status':strategy_status,'rotation_errors':review_errors+strategy_errors,'candidate_contract':contract,'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},'strategy_changed':False,'entry_exit_changed':False,'core_ledger_deleted':False,'auto_buy':False}
    write_json(DISK_BOUND_VERIFY_STATUS_V1080,report); _v1080_result_ledger(report)
    failed=[k for k,v in checks.items() if not v]
    def mb(v): return float(v or 0)/1048576.0
    lines=[
        f'🧪 v1080 디스크 고정상한 검수 · {VERSION}',
        f"- 판정: {'DONE' if overall else 'CHECK'} / 표본 {growth_wait}초",
        f"- runtime: Strategy {strategy.get('version') or '-'} / Review {review.get('version') or '-'} / hash {'일치' if checks['strategy_hash_exact'] and checks['review_hash_exact'] else '불일치'}",
        f"- 활성 trace 합계: {mb(sum(x.get('bytes',0) for x in after.get('active',{}).values())):.1f}MB / 전부 상한 {'내' if active_caps else '초과'}",
        f"- 압축 archive 합계: {mb(sum(x.get('bytes',0) for x in after.get('archives',{}).values())):.1f}MB / 세트 상한 {'정상' if archive_caps else '초과'}",
        f"- pending: {len(after.get('pending') or [])}개 / stale quality tmp {len(after.get('stale_quality_tmp') or [])}개 / 회전 오류 {len(review_errors)+len(strategy_errors)}개",
        f"- {growth_wait}초 bounded 합계 변화: {growth['bounded_total_delta_bytes']/1024.0:+.0f}KB / 디스크 남음 {mb(growth['disk_free_bytes'])/1024.0:.2f}GB",
        f"- candidate {contract.get('rows',0)}개 / S1 {contract.get('s1_rows',0)} / exact {dup}/{keymiss}/{unlinked} / 자동매수 OFF",
        '- 핵심 OPEN/CLOSED/decision/exact 원장 삭제·축소 0 / 전략·진입·청산 변경 0',
    ]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    if review_errors or strategy_errors: lines.append('- 회전 오류: '+', '.join((review_errors+strategy_errors)[:4]))
    lines += [f'- 원본 보고서: {DISK_BOUND_VERIFY_STATUS_V1080.name}',f"- issue/change append: {'DONE' if overall else 'CHECK'}"]
    return '\n'.join(lines)

FINAL_OWNER_STATUS_V1081 = BOT_DIR / 'final_owner_verify_v1081.json'

FINAL_OWNER_MARKER_V1081 = BOT_DIR / '.final_owner_verify_ledger_v1081.json'

def _v1081_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(FINAL_OWNER_MARKER_V1081) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key): return False
    _append_jsonl_fsync_v1074(path,row); done[event_key]={'ts':time.time(),'time':now()}
    write_json(FINAL_OWNER_MARKER_V1081,{'schema':'final_owner_verify_marker_v1081','events':done})
    return True

def _v1081_issue_open() -> None:
    row={'schema':'issue_event_v1081','event_type':'ISSUE','issue_id':'FINAL-OWNER-PAPER-MEMORY-1081','version':'v1081','ts':time.time(),'time':now(),'status':'OPEN','title':'Paper canonical performance heap and surrounding worker owner closeout','summary':'Verify streaming CLOSED reader, temporary heap release, Risk bounded recompute and surrounding worker single runtime ownership.','remaining':'Apply v1081 and prove runtime/hash/digest/exact/disk/process invariants.','strategy_impact':'none','auto_buy':False}
    _v1081_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',row)

def _v1081_result_ledger(report: dict) -> None:
    overall=bool(report.get('ok')); stable={k:report.get(k) for k in ('ok','checks','paper','risk','workers','disk','exact')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    common={'version':'v1081','ts':time.time(),'time':now(),'status':'DONE' if overall else 'CHECK','strategy_impact':'none_runtime_memory_owner','auto_buy':False,'source':'guard_final_owner_verify_v1081','proof_digest':digest}
    summary='Paper canonical performance memory owner and surrounding worker ownership verified.' if overall else 'One or more final owner checks require review.'
    remaining='Proceed to system final closeout.' if overall else 'Inspect failed checks; do not change strategy or core ledgers.'
    _v1081_append_once('change:'+digest,BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1081',event_type='CHANGE_VERIFY',change_id='v1081-final-owner-001',issue_id='FINAL-OWNER-PAPER-MEMORY-1081',summary=summary,remaining=remaining))
    _v1081_append_once(('issue_done:' if overall else 'issue_check:')+digest,BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1081',event_type='ISSUE',issue_id='FINAL-OWNER-PAPER-MEMORY-1081',title='Paper memory and surrounding owner closeout',summary=summary,remaining=remaining))

def gfinal_owner_verify_text_v1081(sample_sec: int=180) -> str:
    sample_sec=max(60,min(480,int(sample_sec or 180))); _v1081_issue_open()
    deadline=time.time()+sample_sec; risk_samples=[]; last_progress=time.time()
    paper_status={}; memory={}; snapshot={}
    while time.time()<deadline:
        paper_status=read_json(BOT_DIR/'paper_bot_status.json') or {}
        memory=paper_status.get('paper_performance_memory_v1081') if isinstance(paper_status.get('paper_performance_memory_v1081'),dict) else {}
        snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
        risk=read_json(BOT_DIR/'clean_risk_status.json') or {}
        if isinstance(risk,dict):
            risk_samples.append({'ts':time.time(),'last_sec':float(risk.get('last_sec') or 0.0),'cached':risk.get('cached'),'error':risk.get('error'),'source_ready':risk.get('loss_reentry_contract_ready_v1057')})
            risk_samples=risk_samples[-30:]
        paper_ready=(str(paper_status.get('version') or '')=='paper_bot_v1.003' and memory.get('streaming_closed_reader') is True and memory.get('last_build_at'))
        digest_ready=bool(memory.get('membership_digest') and memory.get('membership_digest')==snapshot.get('membership_digest') and memory.get('source_digest')==snapshot.get('source_digest'))
        if paper_ready and digest_ready and len(risk_samples)>=3: break
        if time.time()-last_progress>=30:
            last_progress=time.time(); progress_notify('🧪 v1081 최종 owner 검수 진행\n- Paper 첫 canonical streaming rebuild와 status 증명을 기다리는 중\n- Risk·주변 worker·디스크·exact는 읽기 전용으로 확인')
        time.sleep(min(3.0,max(0.2,deadline-time.time())))

    paper_active=BOT_DIR/PAPER_ACTIVE_FILE; paper_target=BOT_DIR/'paper_bot_v1.003.py'
    paper_proc=_v1076_component_snapshot('paper'); proc=((paper_proc.get('proc') or {})); pstatus=proc.get('status') if isinstance(proc.get('status'),dict) else {}
    paper_rss=int(pstatus.get('VmRSS') or 0); paper_anon=int(pstatus.get('RssAnon') or 0)
    reclaim=memory.get('last_reclaim') if isinstance(memory.get('last_reclaim'),dict) else {}
    workers={name:worker_state_dict(name) for name in ('scanner','candle','market','feature','orderflow','target_router','risk','strategy','review')}
    surrounding=('scanner','candle','market','feature','orderflow','target_router')
    surrounding_ok=all(bool(workers.get(n,{}).get('ok')) and bool(workers.get(n,{}).get('sync_ok')) for n in surrounding)
    process_ok=all(len(find_worker_pids(n))==1 for n in workers)
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(snapshot)
    disk=_v1080_watch_snapshot(); active_caps=all(bool(x.get('within_cap')) for x in disk.get('active',{}).values()); archive_caps=all(bool(x.get('within_cap')) for x in disk.get('archives',{}).values())
    risk_status=read_json(BOT_DIR/'clean_risk_status.json') or {}
    risk_errors=[x for x in risk_samples if x.get('error')]
    risk_last=[float(x.get('last_sec') or 0.0) for x in risk_samples]
    checks={
        'paper_runtime_version':str(paper_status.get('version') or '')=='paper_bot_v1.003',
        'paper_hash_exact':bool(paper_active.exists() and paper_target.exists() and short_hash(paper_active)==short_hash(paper_target)),
        'paper_streaming_closed_reader':memory.get('streaming_closed_reader') is True and memory.get('closed_reader')=='stream_jsonl_one_row',
        'paper_previous_snapshot_overlap_removed':memory.get('previous_snapshot_overlap') is False,
        'paper_digest_matches_canonical':bool(memory.get('membership_digest')==snapshot.get('membership_digest') and memory.get('source_digest')==snapshot.get('source_digest')),
        'paper_reclaim_executed':bool(reclaim and reclaim.get('ts')),
        'paper_rss_below_previous_1_1gb':bool(paper_rss and paper_rss < 1024*1024*1024),
        'risk_runtime_ok':bool(workers.get('risk',{}).get('ok')),
        'risk_errors_zero':not risk_errors and not risk_status.get('error'),
        'risk_source_contract_ready':risk_status.get('loss_reentry_contract_ready_v1057') is True,
        'surrounding_workers_runtime_hash_ok':surrounding_ok,
        'managed_worker_process_single':process_ok,
        'disk_active_caps_ok':active_caps,
        'disk_archive_caps_ok':archive_caps,
        'disk_pending_zero':len(disk.get('pending') or [])==0,
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':all((workers.get(n,{}).get('raw') or {}).get('auto_buy') in (False,0,None) for n in workers) and paper_status.get('auto_buy') in (False,0,None),
    }
    overall=all(checks.values())
    report={'schema':'final_owner_verify_v1081','version':'v1081','guard_version':VERSION,'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'ok':overall,'checks':checks,'paper':{'version':paper_status.get('version'),'rss_bytes':paper_rss,'anon_bytes':paper_anon,'memory':memory,'active_hash':short_hash(paper_active),'target_hash':short_hash(paper_target)},'risk':{'status':risk_status,'samples':risk_samples,'max_last_sec':max(risk_last) if risk_last else 0.0,'latest_last_sec':risk_last[-1] if risk_last else 0.0},'workers':{k:{x:v.get(x) for x in ('ok','sync_ok','service_active','pid','active_version','latest_version','last_error')} for k,v in workers.items()},'disk':disk,'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},'strategy_changed':False,'entry_exit_changed':False,'core_ledger_deleted':False,'auto_buy':False}
    write_json(FINAL_OWNER_STATUS_V1081,report); _v1081_result_ledger(report)
    failed=[k for k,v in checks.items() if not v]
    before=int(reclaim.get('before_rss_bytes') or 0); after=int(reclaim.get('after_rss_bytes') or 0)
    lines=[
        f'🧪 v1081 최종 owner 검수 · {VERSION}',
        f"- 판정: {'DONE' if overall else 'CHECK'} / 읽기 전용 {sample_sec}초",
        f"- Paper: {paper_status.get('version') or '-'} / RSS {_fmt_bytes(paper_rss)} / anon {_fmt_bytes(paper_anon)} / hash {'일치' if checks['paper_hash_exact'] else '불일치'}",
        f"- 성과 writer: CLOSED streaming={checks['paper_streaming_closed_reader']} / 이전·현재 snapshot 동시보유 제거={checks['paper_previous_snapshot_overlap_removed']} / digest 일치={checks['paper_digest_matches_canonical']}",
        f"- heap 회수: {_fmt_bytes(before)} → {_fmt_bytes(after)} / 회수 {_fmt_bytes(max(0,before-after))} / rebuild {float(memory.get('last_build_sec') or 0.0):.2f}s",
        f"- Risk: 최근 {len(risk_last)}표본 / 최대 {max(risk_last) if risk_last else 0.0:.2f}s / 최신 {risk_last[-1] if risk_last else 0.0:.2f}s / 오류 {len(risk_errors)}",
        f"- 주변 worker: {sum(1 for n in surrounding if workers.get(n,{}).get('ok'))}/{len(surrounding)} 정상 / 관리 worker 단일 process={process_ok}",
        f"- 디스크: 남음 {float((disk.get('disk') or {}).get('free') or 0)/1073741824.0:.2f}GB / 활성·archive 상한 {'정상' if active_caps and archive_caps else 'CHECK'} / pending {len(disk.get('pending') or [])}",
        f'- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF',
        '- 전략·진입·청산·OPEN/CLOSED/decision/exact 변경 0',
    ]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    lines += [f'- 원본 보고서: {FINAL_OWNER_STATUS_V1081.name}',f"- issue/change append: {'DONE' if overall else 'CHECK'}"]
    return '\n'.join(lines)

SYSTEM_CLOSEOUT_STATUS_V1082 = BOT_DIR / 'system_closeout_verify_v1082.json'

SYSTEM_CLOSEOUT_MARKER_V1082 = BOT_DIR / '.system_closeout_verify_ledger_v1082.json'

def _v1082_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(SYSTEM_CLOSEOUT_MARKER_V1082) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key): return False
    _append_jsonl_fsync_v1074(path,row); done[event_key]={'ts':time.time(),'time':now()}
    write_json(SYSTEM_CLOSEOUT_MARKER_V1082,{'schema':'system_closeout_verify_marker_v1082','events':done})
    return True

def _v1082_issue_open() -> None:
    row={'schema':'issue_event_v1082','event_type':'ISSUE','issue_id':'SYSTEM-RESOURCE-CLOSEOUT-1082','version':'v1082','ts':time.time(),'time':now(),'status':'OPEN','title':'Paper compact performance reference and Risk CLOSED/OPEN split cache closeout','summary':'Remove unchanged full canonical snapshot parsing, split Risk CLOSED and OPEN fingerprints, and prove the remaining system runtime/resource invariants.','remaining':'Apply v1082 and prove Paper RSS stability, Risk fast OPEN-only refresh, exact/disk/runtime/hash invariants.','strategy_impact':'none','auto_buy':False}
    _v1082_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',row)

def _v1082_result_ledger(report: dict) -> None:
    overall=bool(report.get('ok')); stable={k:report.get(k) for k in ('ok','checks','paper','risk','workers','disk','exact')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    common={'version':'v1082','ts':time.time(),'time':now(),'status':'DONE' if overall else 'CHECK','strategy_impact':'none_runtime_reader_cache','auto_buy':False,'source':'guard_system_closeout_verify_v1082','proof_digest':digest}
    summary='Paper compact performance reference, Risk split cache, and final system resource invariants verified.' if overall else 'One or more v1082 system resource closeout checks require review.'
    remaining='Begin profitability shadow work; system/runtime/resource closeout is complete.' if overall else 'Inspect failed checks; do not change strategy or core ledgers.'
    _v1082_append_once('change:'+digest,BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1082',event_type='CHANGE_VERIFY',change_id='v1082-system-resource-closeout-001',issue_id='SYSTEM-RESOURCE-CLOSEOUT-1082',summary=summary,remaining=remaining))
    _v1082_append_once(('issue_done:' if overall else 'issue_check:')+digest,BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1082',event_type='ISSUE',issue_id='SYSTEM-RESOURCE-CLOSEOUT-1082',title='System resource closeout v1082',summary=summary,remaining=remaining))

def gsystem_closeout_verify_text_v1082(sample_sec: int=240) -> str:
    sample_sec=max(120,min(600,int(sample_sec or 240))); _v1082_issue_open()
    deadline=time.time()+sample_sec; paper_samples=[]; risk_samples=[]; last_progress=time.time()
    while time.time()<deadline:
        paper_status=read_json(BOT_DIR/'paper_bot_status.json') or {}
        cache=paper_status.get('paper_performance_read_cache_v1082') if isinstance(paper_status.get('paper_performance_read_cache_v1082'),dict) else {}
        paper_proc=_v1076_component_snapshot('paper'); proc=((paper_proc.get('proc') or {})); pst=proc.get('status') if isinstance(proc.get('status'),dict) else {}
        paper_samples.append({'ts':time.time(),'rss':int(pst.get('VmRSS') or 0),'anon':int(pst.get('RssAnon') or 0),'avoided':int(cache.get('unchanged_snapshot_full_parse_avoided') or 0),'full_noop':int(cache.get('full_snapshot_noop_reads') or 0),'snapshot_id':cache.get('snapshot_id')})
        paper_samples=paper_samples[-120:]
        risk=read_json(BOT_DIR/'clean_risk_status.json') or {}
        split=risk.get('risk_closed_open_split_v1082') if isinstance(risk.get('risk_closed_open_split_v1082'),dict) else {}
        risk_samples.append({'ts':time.time(),'version':risk.get('version'),'last_sec':float(risk.get('last_sec') or 0.0),'phase':risk.get('phase'),'closed_scan':bool(risk.get('closed_scan_performed_v1082')),'open_refresh':bool(risk.get('open_refresh_performed_v1082')),'closed_scan_count':int(risk.get('closed_scan_count_v1082') or split.get('closed_scan_count') or 0),'closed_cache_hits':int(risk.get('closed_cache_hit_count_v1082') or split.get('closed_cache_hit_count') or 0),'open_refresh_count':int(risk.get('open_refresh_count_v1082') or split.get('open_refresh_count') or 0),'ready':risk.get('loss_reentry_contract_ready_v1057'),'error':risk.get('error')})
        risk_samples=risk_samples[-120:]
        paper_ready=(str(paper_status.get('version') or '')=='paper_bot_v1.004' and cache.get('compact_meta_ready') is True and int(cache.get('unchanged_snapshot_full_parse_avoided') or 0)>=3)
        risk_ready=(str(risk.get('version') or '')=='risk_worker_v0.12' and len(risk_samples)>=5 and any((not x.get('closed_scan') and x.get('last_sec',99)<1.5) for x in risk_samples[-10:]))
        if paper_ready and risk_ready and time.time() >= deadline-3: break
        if time.time()-last_progress>=45:
            last_progress=time.time(); progress_notify('🧪 v1082 시스템 마감 검수 진행\n- Paper compact 성과메타 재사용과 RSS 안정성 표본 수집\n- Risk CLOSED scan/Open ticker refresh 분리 표본 수집\n- runtime/hash/disk/exact는 읽기 전용 확인')
        time.sleep(min(3.0,max(0.2,deadline-time.time())))

    paper_status=read_json(BOT_DIR/'paper_bot_status.json') or {}
    cache=paper_status.get('paper_performance_read_cache_v1082') if isinstance(paper_status.get('paper_performance_read_cache_v1082'),dict) else {}
    memory=paper_status.get('paper_performance_memory_v1081') if isinstance(paper_status.get('paper_performance_memory_v1081'),dict) else {}
    snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    risk_status=read_json(BOT_DIR/'clean_risk_status.json') or {}
    paper_active=BOT_DIR/PAPER_ACTIVE_FILE; paper_target=BOT_DIR/'paper_bot_v1.004.py'
    risk_active=BOT_DIR/WORKER_SPECS['risk']['active']; risk_target=BOT_DIR/'risk_worker_v0.12.py'
    rss_values=[int(x.get('rss') or 0) for x in paper_samples if int(x.get('rss') or 0)>0]
    late_rss=rss_values[len(rss_values)//2:] if rss_values else []
    latest_rss=rss_values[-1] if rss_values else 0; late_peak=max(late_rss) if late_rss else latest_rss; late_floor=min(late_rss) if late_rss else latest_rss
    avoided_values=[int(x.get('avoided') or 0) for x in paper_samples]
    risk_fast=[x for x in risk_samples if not x.get('closed_scan') and float(x.get('last_sec') or 0.0)<1.5]
    scan_counts=[int(x.get('closed_scan_count') or 0) for x in risk_samples]
    scan_delta=(max(scan_counts)-min(scan_counts)) if scan_counts else 0
    workers={name:worker_state_dict(name) for name in WORKER_SPECS}
    workers_ok=all(bool(v.get('ok')) and bool(v.get('sync_ok')) for v in workers.values())
    process_ok=all(len(find_worker_pids(n))==1 for n in WORKER_SPECS)
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(snapshot)
    disk=_v1080_watch_snapshot(); active_caps=all(bool(x.get('within_cap')) for x in disk.get('active',{}).values()); archive_caps=all(bool(x.get('within_cap')) for x in disk.get('archives',{}).values())
    checks={
        'paper_runtime_version':str(paper_status.get('version') or '')=='paper_bot_v1.004',
        'paper_hash_exact':bool(paper_active.exists() and paper_target.exists() and short_hash(paper_active)==short_hash(paper_target)),
        'paper_compact_meta_ready':cache.get('compact_meta_ready') is True and bool(cache.get('snapshot_id')),
        'paper_unchanged_full_parse_avoided':int(cache.get('unchanged_snapshot_full_parse_avoided') or 0)>=3 and (max(avoided_values)-min(avoided_values) if avoided_values else 0)>=2,
        'paper_full_snapshot_noop_reads_zero':int(cache.get('full_snapshot_noop_reads', -1))==0,
        'paper_digest_matches_canonical':bool(memory.get('membership_digest')==snapshot.get('membership_digest') and memory.get('source_digest')==snapshot.get('source_digest')),
        'paper_rss_below_previous_1_1gb':bool(latest_rss and latest_rss < 1024*1024*1024),
        'paper_rss_late_growth_bounded':bool(late_peak-late_floor < 192*1024*1024),
        'risk_runtime_version':str(risk_status.get('version') or '')=='risk_worker_v0.12',
        'risk_hash_exact':bool(risk_active.exists() and risk_target.exists() and short_hash(risk_active)==short_hash(risk_target)),
        'risk_source_contract_ready':risk_status.get('loss_reentry_contract_ready_v1057') is True,
        'risk_closed_open_split_active':bool(risk_status.get('risk_closed_open_split_v1082')),
        'risk_fast_cached_or_open_only_samples':len(risk_fast)>=3,
        'risk_closed_scan_not_repeated_on_open_updates':scan_delta<=1,
        'risk_errors_zero':not risk_status.get('error') and not any(x.get('error') for x in risk_samples),
        'all_worker_runtime_hash_ok':workers_ok,
        'managed_worker_process_single':process_ok,
        'disk_active_caps_ok':active_caps,
        'disk_archive_caps_ok':archive_caps,
        'disk_pending_zero':len(disk.get('pending') or [])==0,
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':paper_status.get('auto_buy') in (False,0,None) and all((v.get('raw') or {}).get('auto_buy') in (False,0,None) for v in workers.values()),
    }
    overall=all(checks.values())
    report={'schema':'system_closeout_verify_v1082','version':'v1082','guard_version':VERSION,'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'ok':overall,'checks':checks,'paper':{'status_version':paper_status.get('version'),'cache':cache,'memory':memory,'rss_latest':latest_rss,'rss_late_peak':late_peak,'rss_late_floor':late_floor,'samples':paper_samples[-30:],'active_hash':short_hash(paper_active),'target_hash':short_hash(paper_target)},'risk':{'status':risk_status,'samples':risk_samples[-40:],'fast_sample_count':len(risk_fast),'closed_scan_count_delta':scan_delta,'active_hash':short_hash(risk_active),'target_hash':short_hash(risk_target)},'workers':{k:{x:v.get(x) for x in ('ok','sync_ok','service_active','pid','active_version','latest_version','last_error')} for k,v in workers.items()},'disk':disk,'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},'strategy_changed':False,'entry_exit_changed':False,'core_ledger_deleted':False,'auto_buy':False}
    write_json(SYSTEM_CLOSEOUT_STATUS_V1082,report); _v1082_result_ledger(report)
    failed=[k for k,v in checks.items() if not v]
    risk_latest=float(risk_samples[-1].get('last_sec') or 0.0) if risk_samples else 0.0
    lines=[
        f'🧪 v1082 시스템 자원 최종마감 · {VERSION}',
        f"- 판정: {'DONE' if overall else 'CHECK'} / 읽기 전용 {sample_sec}초",
        f"- Paper: {paper_status.get('version') or '-'} / RSS {_fmt_bytes(latest_rss)} / 후반 변동 {_fmt_bytes(max(0,late_peak-late_floor))} / hash {'일치' if checks['paper_hash_exact'] else '불일치'}",
        f"- 성과 snapshot: 무변경 전체파싱 회피 {int(cache.get('unchanged_snapshot_full_parse_avoided') or 0)}회 / no-op 전체파싱 {int(cache.get('full_snapshot_noop_reads') or 0)}회 / digest 일치={checks['paper_digest_matches_canonical']}",
        f"- Risk: {risk_status.get('version') or '-'} / 최신 {risk_latest:.3f}s / fast 표본 {len(risk_fast)} / CLOSED scan count 변화 {scan_delta} / hash {'일치' if checks['risk_hash_exact'] else '불일치'}",
        f"- worker runtime/hash: {sum(1 for v in workers.values() if v.get('ok') and v.get('sync_ok'))}/{len(workers)} / 단일 process={process_ok}",
        f"- 디스크: 남음 {float((disk.get('disk') or {}).get('free') or 0)/1073741824.0:.2f}GB / 활성·archive 상한 {'정상' if active_caps and archive_caps else 'CHECK'} / pending {len(disk.get('pending') or [])}",
        f'- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF',
        '- 전략·진입·청산·OPEN/CLOSED/decision/exact 변경 0',
    ]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    lines += [f'- 원본 보고서: {SYSTEM_CLOSEOUT_STATUS_V1082.name}',f"- issue/change append: {'DONE' if overall else 'CHECK'}",'- CORE V2 closeout은 재실행하지 않음']
    return '\n'.join(lines)

PAPER_MEMORY_PROBE_V1083 = BOT_DIR / 'paper_memory_owner_probe_v1083.json'

PAPER_MEMORY_PROBE_VERIFY_V1083 = BOT_DIR / 'paper_memory_owner_verify_v1083.json'

PAPER_MEMORY_PROBE_MARKER_V1083 = BOT_DIR / '.paper_memory_owner_verify_ledger_v1083.json'

def _v1083_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(PAPER_MEMORY_PROBE_MARKER_V1083) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key): return False
    _append_jsonl_fsync_v1074(path,row); done[event_key]={'ts':time.time(),'time':now()}
    write_json(PAPER_MEMORY_PROBE_MARKER_V1083,{'schema':'paper_memory_owner_verify_marker_v1083','events':done})
    return True

def _v1083_issue_open() -> None:
    row={'schema':'issue_event_v1083','event_type':'ISSUE','issue_id':'PAPER-MEMORY-OWNER-1083','version':'v1083','ts':time.time(),'time':now(),'status':'OPEN','title':'Paper 1.1GB live memory owner identification','summary':'Measure startup and three normal cycles by phase to identify the real RSS/allocation owner before any further fix.','remaining':'Apply v1083, collect complete probe and name the primary and secondary owner paths.','strategy_impact':'none_measurement_only','auto_buy':False}
    _v1083_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',row)

def _v1083_result_ledger(report: dict) -> None:
    complete=bool(report.get('complete')); stable={k:report.get(k) for k in ('complete','primary_owner','secondary_owner','checks','phase_rows','file_sizes','exact')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    status='DONE' if complete else 'CHECK'
    summary='Paper live memory owner was identified by phase-level RSS and allocation evidence.' if complete else 'Paper memory probe did not complete or runtime invariants require review.'
    remaining='Use the proven owner path for one targeted v1084 fix; do not change strategy.' if complete else 'Repeat or inspect the incomplete probe; do not guess a fix.'
    common={'version':'v1083','ts':time.time(),'time':now(),'status':status,'strategy_impact':'none_measurement_only','auto_buy':False,'source':'guard_paper_memory_owner_probe_v1083','proof_digest':digest}
    _v1083_append_once('change:'+digest,BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1083',event_type='CHANGE_VERIFY',change_id='v1083-paper-memory-owner-001',issue_id='PAPER-MEMORY-OWNER-1083',summary=summary,remaining=remaining))
    _v1083_append_once(('issue_done:' if complete else 'issue_check:')+digest,BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1083',event_type='ISSUE',issue_id='PAPER-MEMORY-OWNER-1083',title='Paper memory owner identification',summary=summary,remaining=remaining))

def _v1083_phase_score(row: dict) -> int:
    return max(0,int(row.get('max_rss_delta_bytes') or 0)) + max(0,int(row.get('max_traced_call_peak_over_before_bytes') or row.get('max_traced_current_delta_bytes') or 0))

def _v1083_owner_label(phase: str) -> str:
    labels={
        'status_candidate_rows_reload':'Status writer의 후보 461개 재로딩',
        'decision_state_full_load_and_record_copy':'Decision state 전체 JSON parse + record dict 복사',
        'decision_state_full_json_digest':'Decision state 전체 JSON 직렬화 digest',
        'candidate_select_total':'Paper 후보선별 전체',
        'preopen_review_total':'Pre-open 복기 전체',
        'performance_writer_total':'Canonical 성과 writer',
        'status_writer_total':'Status/handoff/trace writer 전체',
        'run_cycle_total':'Paper 전체 cycle',
    }
    return labels.get(str(phase),str(phase))

def gpaper_memory_owner_probe_text_v1083(sample_sec: int=180) -> str:
    sample_sec=max(60,min(360,int(sample_sec or 180))); _v1083_issue_open()
    deadline=time.time()+sample_sec; report={}; last_progress=time.time()
    while time.time()<deadline:
        report=read_json(PAPER_MEMORY_PROBE_V1083) or {}
        if str(report.get('version') or '')=='paper_bot_v1.005' and report.get('complete') is True and int(report.get('cycles_completed') or 0)>=3:
            break
        if time.time()-last_progress>=30:
            last_progress=time.time(); progress_notify('🔬 v1083 Paper 메모리 정밀측정 진행\n- startup 및 3개 cycle 단계별 RSS·allocation peak 수집\n- 원인 확정 전 수정 없음')
        time.sleep(min(2.0,max(0.2,deadline-time.time())))
    report=read_json(PAPER_MEMORY_PROBE_V1083) or {}
    paper_status=read_json(BOT_DIR/'paper_bot_status.json') or {}
    paper_active=BOT_DIR/PAPER_ACTIVE_FILE; paper_target=BOT_DIR/'paper_bot_v1.005.py'
    phase_rows=[dict(x) for x in (report.get('phase_summary') or []) if isinstance(x,dict)]
    leaf_names={'status_candidate_rows_reload','decision_state_full_load_and_record_copy','decision_state_full_json_digest','preopen_review_total','performance_writer_total'}
    leaf=[x for x in phase_rows if str(x.get('phase')) in leaf_names]
    leaf.sort(key=_v1083_phase_score,reverse=True)
    primary=leaf[0] if leaf else (phase_rows[0] if phase_rows else {})
    secondary=leaf[1] if len(leaf)>1 else {}
    files=report.get('file_sizes') if isinstance(report.get('file_sizes'),dict) else {}
    globals_size=report.get('global_deep_sizes') if isinstance(report.get('global_deep_sizes'),dict) else {}
    snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(snapshot)
    checks={
        'probe_complete':report.get('complete') is True and int(report.get('cycles_completed') or 0)>=3,
        'paper_runtime_version':str(paper_status.get('version') or '')=='paper_bot_v1.005',
        'paper_hash_exact':bool(paper_active.exists() and paper_target.exists() and short_hash(paper_active)==short_hash(paper_target)),
        'phase_evidence_present':bool(phase_rows and primary),
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':paper_status.get('auto_buy') in (False,0,None),
    }
    complete=all(checks.values())
    out={
        'schema':'paper_memory_owner_verify_v1083','version':'v1083','guard_version':VERSION,'created_ts':time.time(),'created_text':now(),'complete':complete,'checks':checks,
        'primary_owner':primary,'secondary_owner':secondary,'phase_rows':phase_rows,'file_sizes':files,'global_deep_sizes':globals_size,'top_live_allocations':report.get('top_live_allocations') or [],
        'paper':{'status_version':paper_status.get('version'),'active_hash':short_hash(paper_active),'target_hash':short_hash(paper_target),'current_memory':report.get('current_memory') or {},'cycles':report.get('cycles_completed')},
        'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},'strategy_changed':False,'entry_exit_changed':False,'core_ledger_changed':False,'auto_buy':False,
    }
    write_json(PAPER_MEMORY_PROBE_VERIFY_V1083,out); _v1083_result_ledger(out)
    def mb(v): return float(int(v or 0))/1024/1024
    primary_name=_v1083_owner_label(primary.get('phase') or '-')
    secondary_name=_v1083_owner_label(secondary.get('phase') or '-')
    rows_sorted=sorted(leaf,key=_v1083_phase_score,reverse=True)[:5]
    lines=[
        f'🔬 v1083 Paper 메모리 owner 정밀측정 · {VERSION}',
        f"- 판정: {'DONE' if complete else 'CHECK'} / cycle {int(report.get('cycles_completed') or 0)}/3",
        f"- 1순위 owner: {primary_name} / RSS 최대증가 {mb(primary.get('max_rss_delta_bytes')):.1f}MB / 호출중 peak +{mb(primary.get('max_traced_call_peak_over_before_bytes')):.1f}MB / 최대 {float(primary.get('max_wall_sec') or 0.0):.2f}s",
        f"- 2순위 owner: {secondary_name} / RSS 최대증가 {mb(secondary.get('max_rss_delta_bytes')):.1f}MB / 호출중 peak +{mb(secondary.get('max_traced_call_peak_over_before_bytes')):.1f}MB / 최대 {float(secondary.get('max_wall_sec') or 0.0):.2f}s",
        f"- 입력 크기: candidates {mb(files.get('paper_latest')):.1f}MB / decision state {mb(files.get('decision_state')):.1f}MB / performance {mb(files.get('performance_snapshot')):.1f}MB / CLOSED {mb(files.get('closed')):.1f}MB",
        f"- 현재 Paper RSS {mb(((report.get('current_memory') or {}).get('rss_bytes'))):.1f}MB / anon {mb(((report.get('current_memory') or {}).get('anon_bytes'))):.1f}MB",
        f'- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF / 전략·진입·청산·원장 변경 0',
        '- 단계별 TOP:',
    ]
    for row in rows_sorted:
        lines.append(f"  · {_v1083_owner_label(row.get('phase'))}: RSS +{mb(row.get('max_rss_delta_bytes')):.1f}MB / peak +{mb(row.get('max_traced_call_peak_over_before_bytes')):.1f}MB / {float(row.get('max_wall_sec') or 0.0):.2f}s")
    failed=[k for k,v in checks.items() if not v]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    lines += [f'- 원본: {PAPER_MEMORY_PROBE_V1083.name}',f'- 검수본: {PAPER_MEMORY_PROBE_VERIFY_V1083.name}',f"- issue/change append: {'DONE' if complete else 'CHECK'}"]
    return '\n'.join(lines)

PAPER_ALLOCATOR_PROBE_V1084 = BOT_DIR / 'paper_memory_allocator_probe_v1084.json'

PAPER_ALLOCATOR_VERIFY_V1084 = BOT_DIR / 'paper_memory_allocator_verify_v1084.json'

PAPER_ALLOCATOR_MARKER_V1084 = BOT_DIR / '.paper_allocator_verify_ledger_v1084.json'

def _v1084_guard_proc_status(pid: int) -> dict:
    out={'VmRSS':0,'RssAnon':0,'RssFile':0,'VmHWM':0,'VmData':0,'VmSwap':0,'Threads':0}
    if pid<=0: return out
    try:
        for line in Path(f'/proc/{pid}/status').read_text(encoding='utf-8',errors='ignore').splitlines():
            if ':' not in line: continue
            key,raw=line.split(':',1)
            if key not in out: continue
            parts=raw.strip().split()
            if not parts: continue
            value=int(float(parts[0])); out[key]=value if key=='Threads' else value*1024
    except Exception:
        pass
    return out

def _v1084_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(PAPER_ALLOCATOR_MARKER_V1084) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key): return False
    _append_jsonl_fsync_v1074(path,row); done[event_key]={'ts':time.time(),'time':now()}
    write_json(PAPER_ALLOCATOR_MARKER_V1084,{'schema':'paper_allocator_verify_marker_v1084','events':done})
    return True

def _v1084_ledger(report: dict) -> None:
    stable={k:report.get(k) for k in ('complete','checks','classification','paper','exact')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    status='DONE' if report.get('complete') else 'CHECK'
    common={'version':'v1084','ts':time.time(),'time':now(),'status':status,'strategy_impact':'none_measurement_only','auto_buy':False,'source':'guard_paper_allocator_probe_v1084','proof_digest':digest}
    _v1084_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1084',event_type='ISSUE',issue_id='PAPER-MEMORY-OWNER-1084',title='Paper allocator and exact-exit memory owner proof',summary='Replace failed v1083 tracemalloc probe with low-overhead allocator/exact-exit evidence.',remaining='Collect three cycles and six exact-exit sweeps; name root class before any fix.'))
    _v1084_append_once('result:'+digest,BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1084',event_type='CHANGE_VERIFY',change_id='v1084-paper-memory-owner-001',issue_id='PAPER-MEMORY-OWNER-1084',summary='Allocator/exact-exit owner measurement completed.' if status=='DONE' else 'Allocator/exact-exit probe incomplete.',remaining='Use proven root class for one targeted fix.' if status=='DONE' else 'Repeat or inspect runtime; do not guess a fix.'))
    _v1084_append_once(('done:' if status=='DONE' else 'check:')+digest,BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1084',event_type='ISSUE',issue_id='PAPER-MEMORY-OWNER-1084',title='Paper allocator/exact-exit memory owner proof',summary='Root class proven.' if status=='DONE' else 'Probe incomplete.',remaining='Targeted fix only.' if status=='DONE' else 'No optimization until complete.'))

def gpaper_allocator_probe_text_v1084(sample_sec: int=240) -> str:
    sample_sec=max(120,min(600,int(sample_sec or 240))); deadline=time.time()+sample_sec; report={}; last_progress=0.0
    while time.time()<deadline:
        report=read_json(PAPER_ALLOCATOR_PROBE_V1084) or {}
        if str(report.get('version') or '')=='paper_bot_v1.006' and report.get('complete') is True and int(report.get('cycles_completed') or 0)>=3 and int(report.get('exit_sweeps_completed') or 0)>=6:
            break
        if time.time()-last_progress>=30:
            last_progress=time.time(); progress_notify('🔬 v1084 Paper allocator·exact exit 측정 진행\n- 3개 cycle·exact exit 6회·mallinfo2·smaps 수집\n- 원인 확정 전 수정 없음')
        time.sleep(min(2.0,max(0.2,deadline-time.time())))
    report=read_json(PAPER_ALLOCATOR_PROBE_V1084) or {}
    paper_status=read_json(BOT_DIR/'paper_bot_status.json') or {}
    active=BOT_DIR/PAPER_ACTIVE_FILE; target=BOT_DIR/'paper_bot_v1.006.py'
    pid=_service_main_pid(PAPER_SERVICE)
    proc=_v1084_guard_proc_status(pid)
    snapshot=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(snapshot)
    mem=report.get('current_memory') if isinstance(report.get('current_memory'),dict) else {}
    mall=mem.get('mallinfo2') if isinstance(mem.get('mallinfo2'),dict) else {}
    phases=[dict(x) for x in (report.get('phase_summary') or []) if isinstance(x,dict)]
    classification=report.get('classification') if isinstance(report.get('classification'),dict) else {}
    checks={
        'probe_complete':report.get('complete') is True and int(report.get('cycles_completed') or 0)>=3 and int(report.get('exit_sweeps_completed') or 0)>=6,
        'paper_runtime_version':str(paper_status.get('version') or '')=='paper_bot_v1.006',
        'paper_hash_exact':bool(active.exists() and target.exists() and short_hash(active)==short_hash(target)),
        'same_live_pid':bool(pid>0 and int(report.get('pid') or 0)==pid),
        'paper_rss_nonzero':int(proc.get('VmRSS') or 0)>0 and int(mem.get('rss_bytes') or 0)>0,
        'mallinfo_present':int(mall.get('uordblks') or 0)>0 or int(mall.get('arena') or 0)>0,
        'exact_exit_measured':any(str(x.get('phase') or '')=='exact_exit_monitor_total' and int(x.get('calls') or 0)>=6 for x in phases),
        'tracemalloc_disabled':report.get('tracemalloc_enabled') is False,
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':paper_status.get('auto_buy') in (False,0,None),
    }
    complete=all(checks.values())
    out={'schema':'paper_memory_allocator_verify_v1084','version':'v1084','guard_version':VERSION,'created_ts':time.time(),'created_text':now(),'complete':complete,'checks':checks,
         'classification':classification,'paper':{'status_version':paper_status.get('version'),'pid':pid,'process_rss_bytes':int(proc.get('VmRSS') or 0),'process_anon_bytes':int(proc.get('RssAnon') or 0),'probe':report},
         'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},'strategy_changed':False,'entry_exit_changed':False,'core_ledger_changed':False,'auto_buy':False}
    write_json(PAPER_ALLOCATOR_VERIFY_V1084,out); _v1084_ledger(out)
    def mb(v): return float(int(v or 0))/1024/1024
    top=sorted(phases,key=lambda r:max(0,int(r.get('max_rss_delta_bytes') or 0))+max(0,int(r.get('max_allocator_live_delta_bytes') or 0)),reverse=True)[:6]
    globals_size=report.get('global_deep_sizes') if isinstance(report.get('global_deep_sizes'),dict) else {}
    global_top=sorted([(n,int((r or {}).get('bytes') or 0)) for n,r in globals_size.items() if isinstance(r,dict)],key=lambda x:x[1],reverse=True)[:4]
    lines=[
        f'🔬 v1084 Paper allocator·exact exit 메모리 특정 · {VERSION}',
        f"- 판정: {'DONE' if complete else 'CHECK'} / cycle {int(report.get('cycles_completed') or 0)}/3 / exit sweep {int(report.get('exit_sweeps_completed') or 0)}/6",
        f"- root class: {classification.get('root_class') or '-'}",
        f"- Paper RSS: guard {mb(proc.get('VmRSS')):.1f}MB / self {mb(mem.get('rss_bytes')):.1f}MB / anon {mb(mem.get('anon_bytes')):.1f}MB",
        f"- allocator: live {mb(mem.get('allocator_live_bytes')):.1f}MB / free-retained {mb(mem.get('allocator_free_retained_bytes')):.1f}MB / arena {mb(mall.get('arena')):.1f}MB / mmap {mb(mall.get('hblkhd')):.1f}MB",
        f"- largest global: {classification.get('largest_global_name') or '-'} {mb(classification.get('largest_global_bytes')):.1f}MB",
        '- 단계별 TOP:',
    ]
    for row in top:
        lines.append(f"  · {row.get('phase')}: calls {int(row.get('calls') or 0)} / RSSΔ +{mb(row.get('max_rss_delta_bytes')):.1f}MB / alloc-liveΔ +{mb(row.get('max_allocator_live_delta_bytes')):.1f}MB / freeΔ +{mb(row.get('max_allocator_free_delta_bytes')):.1f}MB / peak RSS {mb(row.get('peak_rss_bytes')):.1f}MB / {float(row.get('max_wall_sec') or 0.0):.2f}s")
    if global_top:
        lines.append('- 전역 객체 TOP: '+', '.join(f'{n} {mb(v):.1f}MB' for n,v in global_top))
    lines.append(f'- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF / 전략·진입·청산·원장 변경 0')
    failed=[k for k,v in checks.items() if not v]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    lines += [f'- 원본: {PAPER_ALLOCATOR_PROBE_V1084.name}',f'- 검수본: {PAPER_ALLOCATOR_VERIFY_V1084.name}',f"- issue/change append: {'DONE' if complete else 'CHECK'}"]
    return '\n'.join(lines)

PAPER_MEMORY_FIX_VERIFY_V1085 = BOT_DIR / 'paper_memory_fix_verify_v1085.json'

PAPER_MEMORY_FIX_MARKER_V1085 = BOT_DIR / '.paper_memory_fix_verify_ledger_v1085.json'

def _v1085_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=read_json(PAPER_MEMORY_FIX_MARKER_V1085) or {}
    done=marker.get('events') if isinstance(marker,dict) and isinstance(marker.get('events'),dict) else {}
    if done.get(event_key): return False
    _append_jsonl_fsync_v1074(path,row)
    done[event_key]={'ts':time.time(),'time':now()}
    write_json(PAPER_MEMORY_FIX_MARKER_V1085,{'schema':'paper_memory_fix_verify_marker_v1085','events':done})
    return True

def _v1085_ledger(report: dict) -> None:
    stable={k:report.get(k) for k in ('ok','checks','paper','candidate_contract','exact')}
    digest=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    status='DONE' if report.get('ok') else 'CHECK'
    common={'version':'v1085','ts':time.time(),'time':now(),'status':status,'strategy_impact':'none_reader_memory_only','auto_buy':False,'source':'guard_paper_stream_reader_verify_v1085','proof_digest':digest}
    _v1085_append_once('issue_open',BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1085',event_type='ISSUE',issue_id='PAPER-MEMORY-ROOT-1085',title='Paper CLOSED recent-id memory burst removal',summary='Remove full CLOSED tail dictionaries and full status candidate retention without changing execution contracts.',remaining='Verify three live cycles, exact 0/0/0 and bounded RSS.'))
    _v1085_append_once('result:'+digest,BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1085',event_type='CHANGE_VERIFY',change_id='v1085-paper-stream-reader-001',issue_id='PAPER-MEMORY-ROOT-1085',summary='CLOSED ID index and compact status reader verified.' if status=='DONE' else 'Paper reader verification incomplete.',remaining='System closeout may proceed.' if status=='DONE' else 'Inspect failed checks; do not change strategy.'))
    _v1085_append_once(('done:' if status=='DONE' else 'check:')+digest,BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1085',event_type='ISSUE',issue_id='PAPER-MEMORY-ROOT-1085',title='Paper CLOSED recent-id memory burst removal',summary='Reader memory root cause fixed.' if status=='DONE' else 'Verification remains CHECK.',remaining='Proceed to system closeout.' if status=='DONE' else 'Resolve only the failed reader/runtime proof.'))

def _v1085_candidate_phase_sec(status: dict) -> float:
    profile=status.get('paper_resource_profile_v1076') if isinstance(status.get('paper_resource_profile_v1076'),dict) else {}
    cycle=profile.get('cycle') if isinstance(profile.get('cycle'),dict) else {}
    for row in cycle.get('top_phases') or []:
        if isinstance(row,dict) and str(row.get('phase') or '')=='candidate_select':
            return float(row.get('wall_sec') or 0.0)
    return 0.0

def gpaper_memory_fix_verify_text_v1085(sample_sec: int=180) -> str:
    sample_sec=max(90,min(480,int(sample_sec or 180)))
    deadline=time.time()+sample_sec
    seen_cycles=set(); cycle_samples=[]; rss_samples=[]; last_progress=0.0; status={}
    while time.time()<deadline:
        status=read_json(BOT_DIR/'paper_bot_status.json') or {}
        if str(status.get('version') or status.get('paper_version') or '')=='paper_bot_v1.007':
            pid=_service_main_pid(PAPER_SERVICE)
            proc=_v1084_guard_proc_status(pid)
            rss=int(proc.get('VmRSS') or 0)
            if rss>0: rss_samples.append(rss)
            cycle_id=str(status.get('cycle_started_at') or ((status.get('paper_resource_profile_v1076') or {}).get('cycle') or {}).get('started_ts') or '')
            if cycle_id and cycle_id not in seen_cycles:
                seen_cycles.add(cycle_id)
                sec=_v1085_candidate_phase_sec(status)
                if sec>0: cycle_samples.append(sec)
            diag=status.get('paper_memory_reader_v1085') if isinstance(status.get('paper_memory_reader_v1085'),dict) else {}
            closed=diag.get('closed_recent_index') if isinstance(diag.get('closed_recent_index'),dict) else {}
            sread=diag.get('status_candidate_reader') if isinstance(diag.get('status_candidate_reader'),dict) else {}
            ready=bool(len(seen_cycles)>=3 and int(closed.get('initial_tail_scans') or 0)>=1 and int(sread.get('calls') or 0)>=2 and (int(closed.get('cache_hits') or 0)+int(closed.get('incremental_scans') or 0))>=1)
            if ready: break
        if time.time()-last_progress>=30:
            last_progress=time.time(); progress_notify(f'🧪 v1085 Paper 메모리 검수 진행\n- live cycle {len(seen_cycles)}/3 / candidate 표본 {len(cycle_samples)}\n- CLOSED bounded index·상태판 compact reader·RSS 확인 중')
        time.sleep(min(2.0,max(0.2,deadline-time.time())))
    status=read_json(BOT_DIR/'paper_bot_status.json') or {}
    diag=status.get('paper_memory_reader_v1085') if isinstance(status.get('paper_memory_reader_v1085'),dict) else {}
    closed=diag.get('closed_recent_index') if isinstance(diag.get('closed_recent_index'),dict) else {}
    sread=diag.get('status_candidate_reader') if isinstance(diag.get('status_candidate_reader'),dict) else {}
    pid=_service_main_pid(PAPER_SERVICE); proc=_v1084_guard_proc_status(pid)
    current_rss=int(proc.get('VmRSS') or 0); rss_samples.append(current_rss) if current_rss>0 else None
    active=BOT_DIR/PAPER_ACTIVE_FILE; target=BOT_DIR/'paper_bot_v1.007.py'
    try: source_text=active.read_text(encoding='utf-8',errors='ignore')
    except Exception: source_text=''
    contract=_v1077_candidate_contract_snapshot(BOT_DIR/'paper_candidates_latest.jsonl')
    snap=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    exact_ok,dup,keymiss,unlinked,exact_source=_core_v2_exact_counts_v1073(snap)
    median=_v1079_median(cycle_samples); max_rss=max(rss_samples) if rss_samples else 0
    checks={
        'paper_runtime_version':str(status.get('version') or status.get('paper_version') or '')=='paper_bot_v1.007',
        'paper_hash_exact':bool(active.exists() and target.exists() and short_hash(active)==short_hash(target)),
        'v1084_runtime_probe_retired':'paper_bot v1.006 / v1084: allocator + exact-exit live memory owner probe' not in source_text,
        'three_live_cycles':len(seen_cycles)>=3,
        'closed_bounded_tail_initialized':int(closed.get('initial_tail_scans') or 0)>=1,
        'closed_full_dict_materialization_off':closed.get('full_row_list_materialized') is False and diag.get('closed_full_dict_tail_materialization') is False,
        'closed_cache_bounded':int(diag.get('closed_recent_cached_rows') or 0)<=2000,
        'closed_append_or_cache_reuse':(int(closed.get('cache_hits') or 0)+int(closed.get('incremental_scans') or 0))>=1,
        'status_compact_reader_active':int(sread.get('calls') or 0)>=2 and int(sread.get('rows_compacted') or 0)>0,
        'status_full_rows_not_retained':sread.get('full_candidate_rows_retained') is False and diag.get('status_full_candidate_row_retention') is False,
        'status_parse_errors_zero':int(sread.get('parse_errors') or 0)==0,
        'paper_current_rss_below_800mb':0<current_rss<800*1024*1024,
        'paper_sample_peak_below_950mb':0<max_rss<950*1024*1024,
        'candidate_select_below_4s':bool(median>0 and median<4.0),
        'candidate_parse_errors_zero':int(contract.get('parse_errors') or 0)==0 and not contract.get('read_error'),
        's1_contract_complete':all(int(contract.get(k) or 0)==0 for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target')),
        'exact_zero_zero_zero':bool(exact_ok),
        'auto_buy_off':status.get('auto_buy') in (False,0,None),
    }
    overall=all(checks.values())
    report={'schema':'paper_memory_fix_verify_v1085','version':'v1085','guard_version':VERSION,'created_ts':time.time(),'created_text':now(),'sample_sec':sample_sec,'ok':overall,'checks':checks,
            'paper':{'version':status.get('version') or status.get('paper_version'),'pid':pid,'current_rss_bytes':current_rss,'sample_peak_rss_bytes':max_rss,'rss_samples':rss_samples[-60:],'cycle_ids':list(seen_cycles),'candidate_select_samples_sec':cycle_samples,'candidate_select_median_sec':median,'reader':diag},
            'candidate_contract':contract,'exact':{'ok':exact_ok,'duplicate':dup,'key_missing':keymiss,'unlinked':unlinked,'source':exact_source},'strategy_changed':False,'entry_exit_changed':False,'core_ledger_changed':False,'auto_buy':False}
    write_json(PAPER_MEMORY_FIX_VERIFY_V1085,report); _v1085_ledger(report)
    def mb(v): return float(int(v or 0))/1024/1024
    failed=[k for k,v in checks.items() if not v]
    lines=[
        f'🧪 v1085 Paper 메모리 뿌리수술 검수 · {VERSION}',
        f"- 판정: {'DONE' if overall else 'CHECK'} / live cycle {len(seen_cycles)}/3",
        f"- Paper RSS: 현재 {mb(current_rss):.1f}MB / 표본 최고 {mb(max_rss):.1f}MB / 이전 1.1GB",
        f"- CLOSED 최근 ID: 초기 tail {int(closed.get('initial_tail_scans') or 0)}회 / incremental {int(closed.get('incremental_scans') or 0)}회 / cache hit {int(closed.get('cache_hits') or 0)}회 / 보유 row {int(diag.get('closed_recent_cached_rows') or 0)}",
        f"- CLOSED 마지막 읽기: {int(closed.get('last_rows_examined') or 0)}행 / {mb(closed.get('last_bytes_read')):.1f}MB / mode {closed.get('last_mode') or '-'}",
        f"- 상태판 후보: compact {int(sread.get('last_rows_compacted') or 0)}행 / {float(sread.get('last_duration_sec') or 0.0):.3f}s / full-row 보유 0",
        f"- candidate_select: 중앙값 {median:.2f}s / 표본 {len(cycle_samples)}",
        f"- candidate: {contract.get('rows',0)}개 / S1 {contract.get('s1_rows',0)} / parse 오류 {contract.get('parse_errors',0)} / 계약누락 {sum(int(contract.get(k) or 0) for k in ('s1_missing_decision_key','s1_missing_trigger','s1_missing_invalid','s1_missing_target'))}",
        f'- exact: {dup}/{keymiss}/{unlinked} / 자동매수 OFF',
        '- 전략·진입·청산·OPEN/CLOSED/decision/exact 변경 0',
    ]
    if failed: lines.append('- CHECK 항목: '+', '.join(failed))
    lines += [f'- 원본 보고서: {PAPER_MEMORY_FIX_VERIFY_V1085.name}',f"- issue/change append: {'DONE' if overall else 'CHECK'}"]
    return '\n'.join(lines)

SYSTEM_FINAL_CLOSEOUT_V1086 = BOT_DIR / 'system_final_closeout_verify_v1086.json'

SYSTEM_FINAL_CLOSEOUT_MARKER_V1086 = BOT_DIR / '.system_final_closeout_verify_ledger_v1086.json'

def _v1086_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker = read_json(SYSTEM_FINAL_CLOSEOUT_MARKER_V1086) or {}
    events = marker.get('events') if isinstance(marker, dict) and isinstance(marker.get('events'), dict) else {}
    if events.get(event_key):
        return False
    _append_jsonl_fsync_v1074(path, row)
    events[event_key] = {'ts': time.time(), 'time': now()}
    write_json(SYSTEM_FINAL_CLOSEOUT_MARKER_V1086, {'schema': 'system_final_closeout_marker_v1086', 'events': events})
    return True

def _v1086_issue_open() -> None:
    _v1086_append_once('issue_open', BOT_DIR / 'issue_ledger.jsonl', {
        'schema': 'issue_event_v1086', 'event_type': 'ISSUE',
        'issue_id': 'SYSTEM-FINAL-CLOSEOUT-1086', 'version': 'v1086',
        'ts': time.time(), 'time': now(), 'status': 'OPEN',
        'title': 'System runtime writer reader and resource final closeout',
        'summary': 'Prove v1085 persistence, runtime/source/hash ownership, canonical writer-reader links, bounded Paper RSS, exact and disk invariants without changing execution.',
        'remaining': 'Run /gsystem_closeout_v1086 and correct only failed proof items.',
        'strategy_impact': 'none_read_only_closeout', 'auto_buy': False,
    })

def _v1086_result_ledger(report: dict) -> None:
    stable = {k: report.get(k) for k in ('ok', 'checks', 'runtime', 'paper', 'writers_readers', 'disk', 'exact', 'errors')}
    digest = hashlib.sha256(json.dumps(stable, ensure_ascii=False, sort_keys=True, default=str, separators=(',', ':')).encode()).hexdigest()
    status = 'DONE' if report.get('ok') else 'CHECK'
    common = {
        'version': 'v1086', 'ts': time.time(), 'time': now(), 'status': status,
        'strategy_impact': 'none_read_only_closeout', 'auto_buy': False,
        'source': 'guard_system_final_closeout_v1086', 'proof_digest': digest,
    }
    summary = 'System runtime, source/hash, writer-reader, v1085 persistence, Paper memory, exact and disk invariants verified.' if status == 'DONE' else 'One or more final system closeout proofs require review.'
    remaining = 'Begin read-only code/system/resource/ledger map work in a separate version.' if status == 'DONE' else 'Correct only displayed proof failures; do not change strategy, contracts or core ledgers.'
    _v1086_append_once('change:' + digest, BOT_DIR / 'change_verify_ledger.jsonl', dict(common,
        schema='change_verify_event_v1086', event_type='CHANGE_VERIFY',
        change_id='v1086-system-final-closeout-001', issue_id='SYSTEM-FINAL-CLOSEOUT-1086',
        summary=summary, remaining=remaining))
    _v1086_append_once(('done:' if status == 'DONE' else 'check:') + digest, BOT_DIR / 'issue_ledger.jsonl', dict(common,
        schema='issue_event_v1086', event_type='ISSUE', issue_id='SYSTEM-FINAL-CLOSEOUT-1086',
        title='System final closeout v1086', summary=summary, remaining=remaining))

def _v1086_file_mtime_ns(path: Path) -> int:
    try:
        return int(path.stat().st_mtime_ns)
    except Exception:
        return 0

def _v1086_latest_target(prefix: str, active_name: str) -> Path | None:
    rows = []
    for path in BOT_DIR.glob(prefix + '*.py'):
        if path.name == active_name:
            continue
        rows.append(path)
    if not rows:
        return None
    def key(path: Path):
        nums = tuple(int(x) for x in re.findall(r'\d+', path.stem))
        return nums, path.name
    return max(rows, key=key)

def _v1086_severe_journal_errors(service: str, since_text: str, lines: int = 500) -> dict:
    start = str(since_text or '').strip()
    cmd = ['journalctl', '-u', service, '--no-pager', '-n', str(lines)]
    if start:
        cmd[3:3] = ['--since', start]
    rc, out = run(cmd, timeout=18)
    text = out or ''
    patterns = ('Traceback (most recent call last)', 'NameError:', 'PermissionError:', 'SyntaxError:', 'ModuleNotFoundError:', 'MemoryError:', 'Fatal Python error')
    hits = [line.strip()[:500] for line in text.splitlines() if any(p in line for p in patterns)]
    return {'service': service, 'since': start, 'rc': rc, 'count': len(hits), 'tail': hits[-8:]}

def _v1086_main_reader_static() -> dict:
    active = BOT_DIR / MAIN_ACTIVE_FILE
    try:
        text = active.read_text(encoding='utf-8', errors='ignore')
    except Exception:
        text = ''
    return {
        'guard_runtime_path': 'clean_guard_runtime_status_v1010.json' in text,
        'guard_runtime_schema': 'guard_runtime_status_v1011_io_owner' in text,
        'performance_path': 'canonical_performance_snapshot_v987.json' in text,
        'paper_status_path': 'paper_bot_status.json' in text,
    }

def gsystem_final_closeout_text_v1086(sample_sec: int = 240) -> str:
    sample_sec = max(120, min(600, int(sample_sec or 240)))
    _v1086_issue_open()
    start_ts = time.time()
    deadline = start_ts + sample_sec
    status_paths = {
        'paper': BOT_DIR / 'paper_bot_status.json',
        'strategy': BOT_DIR / str(WORKER_SPECS['strategy']['status']),
        'review': BOT_DIR / str(WORKER_SPECS['review']['status']),
    }
    seen_mtimes = {k: set() for k in status_paths}
    paper_seq = set()
    rss_samples = []
    candidate_samples = []
    last_progress = 0.0
    while time.time() < deadline:
        for name, path in status_paths.items():
            mt = _v1086_file_mtime_ns(path)
            if mt:
                seen_mtimes[name].add(mt)
        pst = read_json(status_paths['paper']) or {}
        seq = int(pst.get('status_write_seq') or pst.get('status_writer_seq') or pst.get('writer_seq') or ((pst.get('writer') or {}).get('seq') if isinstance(pst.get('writer'), dict) else 0) or 0)
        if seq:
            paper_seq.add(seq)
        pid = _service_main_pid(PAPER_SERVICE)
        proc = _v1084_guard_proc_status(pid)
        rss = int(proc.get('VmRSS') or 0)
        if rss:
            rss_samples.append(rss)
        sec = _v1085_candidate_phase_sec(pst)
        if sec > 0:
            candidate_samples.append(sec)
        if time.time() - last_progress >= 45:
            last_progress = time.time()
            progress_notify(
                '🧪 v1086 전체 시스템 최종마감 진행\n'
                f'- Paper/Strategy/Review 갱신 {len(seen_mtimes["paper"])}/{len(seen_mtimes["strategy"])}/{len(seen_mtimes["review"])}\n'
                f'- Paper RSS 표본 {len(rss_samples)} · runtime/source/hash·writer/reader·exact 확인 중'
            )
        time.sleep(min(3.0, max(0.2, deadline - time.time())))

    runtime = write_guard_runtime_snapshot_v1010(write_reason='v1086_final_closeout')
    components = runtime.get('components') if isinstance(runtime.get('components'), dict) else {}
    paper_status = read_json(BOT_DIR / 'paper_bot_status.json') or {}
    perf = read_json(BOT_DIR / 'canonical_performance_snapshot_v987.json') or {}
    v1085_report = read_json(BOT_DIR / 'paper_memory_fix_verify_v1085.json') or {}
    reader = _v1086_main_reader_static()

    main_active = BOT_DIR / MAIN_ACTIVE_FILE
    main_target = BOT_DIR / 'coinbot_main_v2_13_1074.py'
    paper_active = BOT_DIR / PAPER_ACTIVE_FILE
    paper_target = BOT_DIR / 'paper_bot_v1.007.py'
    guard_active = BOT_DIR / GUARD_ACTIVE_FILE
    guard_target = BOT_DIR / 'backga_guard_bot_v2_5_141.py'

    worker_states = {name: worker_state_dict(name) for name in WORKER_SPECS}
    worker_targets = {name: _v1086_latest_target(str(spec.get('prefix') or ''), str(spec.get('active') or '')) for name, spec in WORKER_SPECS.items()}
    worker_hash_ok = all(
        target is not None and (BOT_DIR / str(WORKER_SPECS[name]['active'])).exists() and short_hash(BOT_DIR / str(WORKER_SPECS[name]['active'])) == short_hash(target)
        for name, target in worker_targets.items()
    )
    worker_runtime_ok = all(bool(row.get('ok')) and bool(row.get('sync_ok')) and len(find_worker_pids(name)) == 1 for name, row in worker_states.items())

    exact_ok, dup, keymiss, unlinked, exact_source = _core_v2_exact_counts_v1073(perf)
    disk = _v1080_watch_snapshot()
    disk_active_ok = all(bool(x.get('within_cap')) for x in (disk.get('active') or {}).values())
    disk_archive_ok = all(bool(x.get('within_cap')) for x in (disk.get('archives') or {}).values())

    rss_values = [int(x) for x in rss_samples if int(x) > 0]
    late = rss_values[len(rss_values)//2:] if rss_values else []
    current_rss = rss_values[-1] if rss_values else 0
    peak_rss = max(rss_values) if rss_values else 0
    late_peak = max(late) if late else current_rss
    late_floor = min(late) if late else current_rss
    candidate_median = _v1079_median(candidate_samples)

    writer = paper_status.get('writer') if isinstance(paper_status.get('writer'), dict) else {}
    writer_pid = int(paper_status.get('writer_pid') or writer.get('pid') or paper_status.get('pid') or 0)
    writer_count = int(paper_status.get('status_writer_count') or paper_status.get('writer_count') or writer.get('count') or 0)
    paper_pid = _service_main_pid(PAPER_SERVICE)
    v1085_pid = int(((v1085_report.get('paper') or {}).get('pid')) or 0)
    guard_comp = components.get('guard') if isinstance(components.get('guard'), dict) else {}
    main_comp = components.get('main') if isinstance(components.get('main'), dict) else {}
    paper_comp = components.get('paper') if isinstance(components.get('paper'), dict) else {}
    ws_comp = components.get('ws') if isinstance(components.get('ws'), dict) else {}
    micro_comp = components.get('micro') if isinstance(components.get('micro'), dict) else {}
    journal_since = datetime.fromtimestamp(start_ts).strftime('%Y-%m-%d %H:%M:%S')

    journal = {name: _v1086_severe_journal_errors(service, journal_since) for name, service in {
        'main': MAIN_SERVICE, 'paper': PAPER_SERVICE, 'guard': GUARD_SERVICE,
        'strategy': WORKER_SPECS['strategy']['service'], 'review': WORKER_SPECS['review']['service'],
    }.items()}
    severe_errors = sum(int(x.get('count') or 0) for x in journal.values())
    journal_reads_ok = all(int(x.get('rc') or 0) == 0 for x in journal.values())
    ws_active = BOT_DIR / WS_ACTIVE_FILE; ws_target = BOT_DIR / 'ws_sidecar_v0.7.py'
    micro_active = BOT_DIR / MICRO_ACTIVE_FILE; micro_target = BOT_DIR / 'bithumb_micro_sidecar_v0.14.py'
    perf_owner_ok = perf.get('source_owner') == 'paper_bot_single_canonical_performance_writer' and (perf.get('invariants') or {}).get('single_writer') is True and (perf.get('invariants') or {}).get('public_readers_recompute') is False

    checks = {
        'guard_runtime_v1086': VERSION == 'guard_v2.5.141_system_final_closeout_v1086_2026-06-27',
        'guard_active_target_hash': bool(guard_active.exists() and guard_target.exists() and short_hash(guard_active) == short_hash(guard_target)),
        'guard_canonical_snapshot_owner': runtime.get('owner') == 'guard_single_runtime_status_writer' and int(runtime.get('guard_pid') or 0) == _service_main_pid(GUARD_SERVICE),
        'main_runtime_active_single': main_comp.get('runtime_state') == 'OK' and int(main_comp.get('process_count') or 0) == 1,
        'main_active_target_hash': bool(main_active.exists() and main_target.exists() and short_hash(main_active) == short_hash(main_target)),
        'main_version_exact': extract_assignment(main_active, 'BOT_VERSION') == extract_assignment(main_target, 'BOT_VERSION'),
        'paper_runtime_active_single': paper_comp.get('runtime_state') == 'OK' and int(paper_comp.get('process_count') or 0) == 1,
        'paper_active_target_hash': bool(paper_active.exists() and paper_target.exists() and short_hash(paper_active) == short_hash(paper_target)),
        'paper_version_build_exact': str(paper_status.get('version') or paper_status.get('paper_version') or '') == 'paper_bot_v1.007' and str(paper_status.get('build') or paper_status.get('paper_runtime_build') or '') == extract_assignment(paper_target, 'BUILD_LABEL'),
        'paper_single_writer_pid': writer_count == 1 and paper_pid > 0 and writer_pid == paper_pid and str(paper_status.get('status_writer_owner') or '') == 'paper_bot_single_status_writer_v994',
        'paper_performance_single_writer': perf_owner_ok,
        'v1085_server_proof_done': v1085_report.get('ok') is True,
        'paper_pid_persisted_after_v1085': v1085_pid > 0 and paper_pid == v1085_pid,
        'paper_cycles_advanced': len(seen_mtimes['paper']) >= 3 and len(paper_seq) >= 2,
        'strategy_cycles_advanced': len(seen_mtimes['strategy']) >= 3,
        'review_cycles_advanced': len(seen_mtimes['review']) >= 2,
        'paper_rss_current_below_1gb': 0 < current_rss < 1024 * 1024 * 1024,
        'paper_rss_peak_below_previous_1_1gb': 0 < peak_rss < 1100 * 1024 * 1024,
        'paper_rss_late_growth_bounded': bool(late and late_peak - late_floor < 256 * 1024 * 1024),
        'candidate_select_median_below_4s': bool(candidate_median > 0 and candidate_median < 4.0),
        'all_worker_runtime_hash_single': worker_runtime_ok and worker_hash_ok,
        'ws_micro_runtime_hash_single': all(row.get('runtime_state') == 'OK' and int(row.get('process_count') or 0) == 1 and row.get('source_alias_hash_match') is True for row in (ws_comp, micro_comp)) and bool(ws_active.exists() and ws_target.exists() and short_hash(ws_active) == short_hash(ws_target)) and bool(micro_active.exists() and micro_target.exists() and short_hash(micro_active) == short_hash(micro_target)),
        'main_reader_guard_runtime_canonical': reader.get('guard_runtime_path') and reader.get('guard_runtime_schema'),
        'main_reader_performance_canonical': reader.get('performance_path') and reader.get('paper_status_path'),
        'guard_main_paper_alias_source_match': all(row.get('source_alias_hash_match') is True for row in (guard_comp, main_comp, paper_comp)),
        'disk_active_caps_ok': disk_active_ok,
        'disk_archive_caps_ok': disk_archive_ok,
        'disk_pending_zero': len(disk.get('pending') or []) == 0,
        'exact_zero_zero_zero': bool(exact_ok),
        'runtime_journal_reads_ok': journal_reads_ok,
        'runtime_severe_errors_zero': severe_errors == 0,
        'auto_buy_off': paper_status.get('auto_buy') in (False, 0, None) and all((row.get('raw') or {}).get('auto_buy') in (False, 0, None) for row in worker_states.values()),
    }
    overall = all(checks.values())
    report = {
        'schema': 'system_final_closeout_verify_v1086', 'version': 'v1086', 'guard_version': VERSION,
        'created_ts': time.time(), 'created_text': now(), 'sample_sec': sample_sec, 'ok': overall,
        'checks': checks,
        'runtime': {'snapshot': runtime, 'workers': {k: {x: v.get(x) for x in ('ok','sync_ok','service_active','pid','active_version','latest_version','last_error')} for k, v in worker_states.items()}, 'worker_targets': {k: str(v) if v else '' for k, v in worker_targets.items()}},
        'paper': {'pid': paper_pid, 'v1085_pid': v1085_pid, 'status_version': paper_status.get('version') or paper_status.get('paper_version'), 'writer_pid': writer_pid, 'writer_count': writer_count, 'rss_samples': rss_values[-240:], 'current_rss_bytes': current_rss, 'peak_rss_bytes': peak_rss, 'late_peak_bytes': late_peak, 'late_floor_bytes': late_floor, 'candidate_samples_sec': candidate_samples[-120:], 'candidate_median_sec': candidate_median, 'status_mtime_count': len(seen_mtimes['paper']), 'status_seq_count': len(paper_seq)},
        'writers_readers': {'paper_writer': writer, 'main_reader_static': reader, 'guard_snapshot_owner': runtime.get('owner')},
        'disk': disk,
        'exact': {'ok': exact_ok, 'duplicate': dup, 'key_missing': keymiss, 'unlinked': unlinked, 'source': exact_source},
        'errors': {'severe_count': severe_errors, 'services': journal},
        'strategy_changed': False, 'entry_exit_changed': False, 'core_ledger_changed': False, 'services_restarted_by_command': False, 'auto_buy': False,
    }
    write_json(SYSTEM_FINAL_CLOSEOUT_V1086, report)
    _v1086_result_ledger(report)

    def mb(value):
        return float(int(value or 0)) / 1024 / 1024
    failed = [k for k, value in checks.items() if not value]
    lines = [
        f'🧪 v1086 전체 시스템 최종마감 · {VERSION}',
        f"- 판정: {'DONE' if overall else 'CHECK'} / 읽기 전용 {sample_sec}초",
        f"- runtime: main {main_comp.get('main_pid') or '-'} / paper {paper_pid or '-'} / guard {guard_comp.get('main_pid') or '-'} / worker {sum(1 for x in worker_states.values() if x.get('ok'))}/{len(worker_states)}",
        f"- Paper writer: count {writer_count} / writerPID {writer_pid or '-'} / MainPID {paper_pid or '-'} / v1085 PID 유지 {'YES' if v1085_pid and v1085_pid == paper_pid else 'NO'}",
        f"- cycle 지속: Paper {len(seen_mtimes['paper'])} / Strategy {len(seen_mtimes['strategy'])} / Review {len(seen_mtimes['review'])}",
        f"- Paper RSS: 현재 {mb(current_rss):.1f}MB / 최고 {mb(peak_rss):.1f}MB / 후반 범위 {mb(late_floor):.1f}~{mb(late_peak):.1f}MB",
        f"- candidate_select: 중앙값 {candidate_median:.2f}s / 표본 {len(candidate_samples)}",
        f"- writer/reader: Guard canonical {'PASS' if checks['guard_canonical_snapshot_owner'] else 'CHECK'} / Main runtime reader {'PASS' if checks['main_reader_guard_runtime_canonical'] else 'CHECK'} / 성과 reader {'PASS' if checks['main_reader_performance_canonical'] else 'CHECK'}",
        f"- exact: {dup}/{keymiss}/{unlinked} / 신규 심각오류 {severe_errors} / 자동매수 OFF",
        f"- 디스크 상한: active {'PASS' if disk_active_ok else 'CHECK'} / archive {'PASS' if disk_archive_ok else 'CHECK'} / pending {len(disk.get('pending') or [])}",
        '- 서비스 재시작 0 / 전략·진입·청산·OPEN/CLOSED/decision/exact 변경 0',
    ]
    if failed:
        lines.append('- CHECK 항목: ' + ', '.join(failed))
    lines += [f'- 원본 보고서: {SYSTEM_FINAL_CLOSEOUT_V1086.name}', f"- issue/change append: {'DONE' if overall else 'CHECK'}", '- DONE 다음 작업: 별도 버전에서 읽기 전용 /code_map → /system_map → /resource_map → /ledger_map']
    return '\n'.join(lines)

OPS_MAP_MARKER_FILE = BOT_DIR / '.ops_map_event_marker.json'

OPS_MAP_REFRESH_INTERVAL_SEC = 60.0

def _ops_read_json(path: Path) -> dict:
    obj = read_json(path)
    return obj if isinstance(obj, dict) else {}

def _ops_atomic_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + f'.tmp.{os.getpid()}.{time.time_ns()}')
    with tmp.open('w', encoding='utf-8') as handle:
        json.dump(obj, handle, ensure_ascii=False, separators=(',', ':'), default=str)
        handle.flush(); os.fsync(handle.fileno())
    os.replace(tmp, path)

def _ops_issue_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker=_ops_read_json(OPS_MAP_MARKER_FILE); events=marker.get('events') if isinstance(marker.get('events'),dict) else {}
    if event_key in events: return False
    _append_jsonl_fsync_v1074(path,row); events[event_key]={'ts':time.time(),'time':now()}
    _ops_atomic_json(OPS_MAP_MARKER_FILE,{'schema':'ops_map_event_marker','events':events}); return True

PAPER_PERFORMANCE_FIX_VERIFY_V1092 = BOT_DIR / 'paper_performance_fix_verify_v1092.json'

PAPER_PERFORMANCE_FIX_MARKER_V1092 = BOT_DIR / '.paper_performance_fix_verify_ledger_v1092.json'

def _v1092_append_once(event_key: str, path: Path, row: dict) -> bool:
    marker = read_json(PAPER_PERFORMANCE_FIX_MARKER_V1092) or {}
    events = marker.get('events') if isinstance(marker, dict) and isinstance(marker.get('events'), dict) else {}
    if events.get(event_key):
        return False
    _append_jsonl_fsync_v1074(path, row)
    events[event_key] = {'ts': time.time(), 'time': now()}
    write_json(PAPER_PERFORMANCE_FIX_MARKER_V1092, {'schema': 'paper_performance_fix_marker_v1092', 'events': events})
    return True

def _v1092_result_ledger(report: dict) -> None:
    stable = {k: report.get(k) for k in ('ok', 'checks', 'paper', 'writer', 'performance', 'exact', 'errors')}
    digest = hashlib.sha256(json.dumps(stable, ensure_ascii=False, sort_keys=True, default=str, separators=(',', ':')).encode()).hexdigest()
    status = 'DONE' if report.get('ok') else 'CHECK'
    common = {
        'version': 'v1092', 'ts': time.time(), 'time': now(), 'status': status,
        'strategy_impact': 'none_performance_writer_io_memory_only', 'auto_buy': False,
        'source': 'guard_paper_incremental_performance_verify_v1092', 'proof_digest': digest,
    }
    _v1092_append_once('issue_open', BOT_DIR / 'issue_ledger.jsonl', dict(common,
        schema='issue_event_v1092', event_type='ISSUE', issue_id='PAPER-PERFORMANCE-WRITER-1092',
        title='Paper canonical performance full CLOSED reread removal',
        summary='Replace normal 267MB CLOSED full reread with one canonical append cursor writer while preserving exact performance formulas and OPEN membership sealing.',
        remaining='Apply v1092 and verify live cycles, cursor, runtime/hash, performance time, RSS and exact 0/0/0.'))
    summary = 'Incremental canonical performance writer verified without strategy, entry, exit, formula or core-ledger changes.' if status == 'DONE' else 'Paper incremental performance writer verification has failed proof items.'
    remaining = 'Proceed to the next map-proven owner bundle.' if status == 'DONE' else 'Correct only displayed writer/runtime proof failures; do not change formulas or trading contracts.'
    _v1092_append_once('change:' + digest, BOT_DIR / 'change_verify_ledger.jsonl', dict(common,
        schema='change_verify_event_v1092', event_type='CHANGE_VERIFY', change_id='v1092-paper-performance-writer-001',
        issue_id='PAPER-PERFORMANCE-WRITER-1092', summary=summary, remaining=remaining))
    _v1092_append_once(('done:' if status == 'DONE' else 'check:') + digest, BOT_DIR / 'issue_ledger.jsonl', dict(common,
        schema='issue_event_v1092', event_type='ISSUE', issue_id='PAPER-PERFORMANCE-WRITER-1092',
        title='Paper incremental performance writer v1092', summary=summary, remaining=remaining))

def _v1092_performance_phase_sec(status: dict) -> float:
    profile = status.get('paper_resource_profile_v1076') if isinstance(status.get('paper_resource_profile_v1076'), dict) else {}
    cycle = profile.get('cycle') if isinstance(profile.get('cycle'), dict) else {}
    found = []
    for key in ('phases', 'top_phases'):
        rows = cycle.get(key) if isinstance(cycle.get(key), list) else []
        for row in rows:
            if isinstance(row, dict) and str(row.get('phase') or '') == 'performance_write':
                try: found.append(float(row.get('wall_sec') or 0.0))
                except Exception: pass
    return max(found) if found else 0.0

def gpaper_performance_fix_verify_text_v1092(sample_sec: int = 180) -> str:
    sample_sec = max(90, min(480, int(sample_sec or 180)))
    started_ts = time.time()
    since_text = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    deadline = started_ts + sample_sec
    seen_status_mtimes = set()
    performance_samples = []
    rss_samples = []
    modes_seen = set()
    incremental_seen = False
    status = read_json(BOT_DIR / 'paper_bot_status.json') or {}
    initial_stats = status.get('paper_performance_writer_v1092') if isinstance(status.get('paper_performance_writer_v1092'), dict) else {}
    initial_full_rebuild = int(initial_stats.get('full_rebuild_count') or 0)
    initial_incremental = int(initial_stats.get('incremental_write_count') or 0)
    initial_open_refresh = int(initial_stats.get('open_membership_refresh_count') or 0)
    last_progress = 0.0
    while time.time() < deadline:
        status_path = BOT_DIR / 'paper_bot_status.json'
        status = read_json(status_path) or {}
        try: mtime_ns = int(status_path.stat().st_mtime_ns)
        except Exception: mtime_ns = 0
        version = str(status.get('version') or status.get('paper_version') or '')
        if version == 'paper_bot_v1.008':
            pid = _service_main_pid(PAPER_SERVICE)
            proc = _v1084_guard_proc_status(pid)
            rss = int(proc.get('VmRSS') or 0)
            if rss > 0: rss_samples.append(rss)
            stats = status.get('paper_performance_writer_v1092') if isinstance(status.get('paper_performance_writer_v1092'), dict) else {}
            mode = str(stats.get('last_mode') or '')
            if mode: modes_seen.add(mode)
            if mode == 'incremental_append' or int(stats.get('incremental_write_count') or 0) > initial_incremental:
                incremental_seen = True
            if mtime_ns and mtime_ns not in seen_status_mtimes:
                seen_status_mtimes.add(mtime_ns)
                sec = _v1092_performance_phase_sec(status)
                if sec > 0: performance_samples.append(sec)
            ready = bool(len(seen_status_mtimes) >= 3 and len(performance_samples) >= 2 and isinstance(stats, dict) and stats.get('schema') == 'paper_performance_append_cursor_v1092')
            if ready and time.time() - started_ts >= min(45, sample_sec * 0.35):
                break
        if time.time() - last_progress >= 30:
            last_progress = time.time()
            progress_notify(f'🧪 v1092 Paper 성과 writer 검수 진행\n- status 갱신 {len(seen_status_mtimes)}/3 · performance 표본 {len(performance_samples)}\n- append cursor·RSS·runtime/hash·exact 확인 중')
        time.sleep(min(2.0, max(0.2, deadline - time.time())))

    status = read_json(BOT_DIR / 'paper_bot_status.json') or {}
    stats = status.get('paper_performance_writer_v1092') if isinstance(status.get('paper_performance_writer_v1092'), dict) else {}
    snapshot = read_json(BOT_DIR / 'canonical_performance_snapshot_v987.json') or {}
    source = snapshot.get('source_meta') if isinstance(snapshot.get('source_meta'), dict) else {}
    writer_meta = snapshot.get('incremental_writer_v1092') if isinstance(snapshot.get('incremental_writer_v1092'), dict) else {}
    closed_path = BOT_DIR / 'paper_bot_closed.jsonl'
    try: closed_size = int(closed_path.stat().st_size)
    except Exception: closed_size = 0
    processed_offset = int(source.get('closed_processed_offset_v1092') or 0)
    cursor_lag = max(0, closed_size - processed_offset)
    pid = _service_main_pid(PAPER_SERVICE)
    proc = _v1084_guard_proc_status(pid)
    current_rss = int(proc.get('VmRSS') or 0)
    if current_rss > 0: rss_samples.append(current_rss)
    max_rss = max(rss_samples) if rss_samples else 0
    late = rss_samples[len(rss_samples)//2:] if rss_samples else []
    late_range = (max(late) - min(late)) if late else 0
    active = BOT_DIR / PAPER_ACTIVE_FILE
    target = BOT_DIR / 'paper_bot_v1.008.py'
    exact_ok, dup, keymiss, unlinked, exact_source = _core_v2_exact_counts_v1073(snapshot)
    median = _v1079_median(performance_samples)
    final_full_rebuild = int(stats.get('full_rebuild_count') or 0)
    final_incremental = int(stats.get('incremental_write_count') or 0)
    final_open_refresh = int(stats.get('open_membership_refresh_count') or 0)
    mode = str(stats.get('last_mode') or writer_meta.get('mode') or '')
    journal = _v1086_severe_journal_errors(PAPER_SERVICE, since_text, 600)
    status_pid = _audit_int(status.get('pid') or status.get('writer_pid') or status.get('owner_pid'), 0)
    build = str(status.get('build') or status.get('build_label') or ((status.get('paper_resource_profile_v1076') or {}).get('build') if isinstance(status.get('paper_resource_profile_v1076'), dict) else '') or '')
    checks = {
        'paper_runtime_version': str(status.get('version') or status.get('paper_version') or '') == 'paper_bot_v1.008',
        'paper_runtime_build': 'v1092_incremental_canonical_performance_writer' in build,
        'paper_hash_exact': bool(active.exists() and target.exists() and short_hash(active) == short_hash(target)),
        'paper_single_mainpid': bool(pid > 0 and (status_pid in (0, pid))),
        'three_status_updates': len(seen_status_mtimes) >= 3,
        'writer_status_schema': stats.get('schema') == 'paper_performance_append_cursor_v1092',
        'writer_owner_single': stats.get('owner') == 'paper_bot_single_canonical_performance_writer' and stats.get('canonical_snapshot_single_writer') is True,
        'normal_append_full_scan_off': stats.get('closed_full_scan_on_normal_append') is False,
        'snapshot_owner_single': snapshot.get('source_owner') == 'paper_bot_single_canonical_performance_writer' and writer_meta.get('single_writer') is True,
        'snapshot_formula_unchanged': writer_meta.get('formula_changed') is False and stats.get('performance_formula_changed') is False,
        'strategy_entry_exit_unchanged': all(stats.get(k) is False for k in ('strategy_changed', 'entry_exit_changed', 'core_ledger_changed')),
        'cursor_metadata_present': bool(int(source.get('closed_inode_v1092') or 0) > 0 and source.get('closed_records_digest_v1092') and source.get('open_membership_digest_v1092')),
        'cursor_caught_up': bool(processed_offset <= closed_size and cursor_lag <= 8 * 1024 * 1024),
        'no_new_full_rebuild': final_full_rebuild == initial_full_rebuild == 0 and not any(x.startswith('full_rebuild') for x in modes_seen),
        'performance_write_median_below_3s': bool(median > 0 and median < 3.0),
        'performance_write_max_below_6s': bool(performance_samples and max(performance_samples) < 6.0),
        'paper_current_rss_below_1100mb': bool(0 < current_rss < 1100 * 1024 * 1024),
        'paper_sample_peak_below_1250mb': bool(0 < max_rss < 1250 * 1024 * 1024),
        'paper_late_growth_bounded': bool(not late or late_range < 500 * 1024 * 1024),
        'exact_zero_zero_zero': bool(exact_ok),
        'no_new_severe_error': int(journal.get('count') or 0) == 0,
        'auto_buy_off': status.get('auto_buy') in (False, 0, None),
    }
    overall = all(checks.values())
    report = {
        'schema': 'paper_performance_fix_verify_v1092', 'version': 'v1092', 'guard_version': VERSION,
        'created_ts': time.time(), 'created_text': now(), 'sample_sec': sample_sec, 'ok': overall, 'checks': checks,
        'paper': {'version': status.get('version') or status.get('paper_version'), 'build': build, 'pid': pid, 'status_pid': status_pid,
                  'current_rss_bytes': current_rss, 'sample_peak_rss_bytes': max_rss, 'late_range_bytes': late_range,
                  'rss_samples': rss_samples[-120:], 'status_updates': len(seen_status_mtimes)},
        'writer': {'stats': stats, 'modes_seen': sorted(modes_seen), 'incremental_event_seen': incremental_seen,
                   'incremental_count_delta': final_incremental - initial_incremental,
                   'open_refresh_count_delta': final_open_refresh - initial_open_refresh,
                   'full_rebuild_count_delta': final_full_rebuild - initial_full_rebuild},
        'performance': {'samples_sec': performance_samples, 'median_sec': median, 'max_sec': max(performance_samples) if performance_samples else 0.0,
                        'snapshot_id': snapshot.get('snapshot_id'), 'snapshot_version': snapshot.get('version'), 'snapshot_build': snapshot.get('build'),
                        'writer_meta': writer_meta, 'source_meta': source, 'closed_size': closed_size, 'processed_offset': processed_offset, 'cursor_lag_bytes': cursor_lag},
        'exact': {'ok': exact_ok, 'duplicate': dup, 'key_missing': keymiss, 'unlinked': unlinked, 'source': exact_source},
        'errors': journal, 'strategy_changed': False, 'entry_exit_changed': False, 'performance_formula_changed': False,
        'core_ledger_changed': False, 'auto_buy': False,
    }
    write_json(PAPER_PERFORMANCE_FIX_VERIFY_V1092, report)
    _v1092_result_ledger(report)
    def mb(value): return float(int(value or 0)) / 1024 / 1024
    failed = [k for k, value in checks.items() if not value]
    lines = [
        f'🧪 v1092 Paper 증분 성과 writer 검수 · {VERSION}',
        f"- 판정: {'DONE' if overall else 'CHECK'} / status 갱신 {len(seen_status_mtimes)} / {sample_sec}초 창",
        f"- performance_write: 중앙값 {median:.3f}s / 최고 {(max(performance_samples) if performance_samples else 0.0):.3f}s / 표본 {len(performance_samples)}",
        f"- writer mode: {mode or '-'} / 관찰 {', '.join(sorted(modes_seen)) or '-'} / incremental event {'YES' if incremental_seen else 'NO-CLOSED-EVENT'}",
        f"- cursor: {processed_offset}/{closed_size} bytes / lag {mb(cursor_lag):.3f}MB / full rebuild 현재 {final_full_rebuild}·변화 {final_full_rebuild-initial_full_rebuild}",
        f"- writer count 변화: incremental +{final_incremental-initial_incremental} / OPEN refresh +{final_open_refresh-initial_open_refresh}",
        f"- Paper RSS: 현재 {mb(current_rss):.1f}MB / 표본 최고 {mb(max_rss):.1f}MB / 후반 범위 {mb(late_range):.1f}MB",
        f"- runtime: {status.get('version') or status.get('paper_version') or '-'} / MainPID {pid or '-'} / hash {'일치' if checks['paper_hash_exact'] else '불일치'}",
        f'- exact: {dup}/{keymiss}/{unlinked} / 신규 심각오류 {int(journal.get("count") or 0)} / 자동매수 OFF',
        '- 성과식·전략·진입·청산·OPEN/CLOSED/decision/exact 변경 0',
    ]
    if failed: lines.append('- CHECK 항목: ' + ', '.join(failed))
    lines += [f'- 원본 보고서: {PAPER_PERFORMANCE_FIX_VERIFY_V1092.name}', f"- issue/change append: {'DONE' if overall else 'CHECK'}"]
    return '\n'.join(lines)

QUALITY_OPEN_AUDIT_V1093 = BOT_DIR / 'quality_open_audit_snapshot_v1093.json'

QUALITY_OPEN_AUDIT_MARKER_V1093 = BOT_DIR / '.quality_open_audit_ledger_v1093.json'

def _v1093_num(*values, default=None):
    import math
    for value in values:
        if value in (None, '', [], {}):
            continue
        try:
            out=float(str(value).replace(',','').replace('%','').strip())
            if math.isfinite(out): return out
        except Exception:
            continue
    return default

def _v1093_rows(obj):
    if isinstance(obj,list): return [dict(x) for x in obj if isinstance(x,dict)]
    if not isinstance(obj,dict): return []
    for key in ('rows','items','positions','open_positions','active','candidates','hold','data'):
        value=obj.get(key)
        if isinstance(value,list): return [dict(x) for x in value if isinstance(x,dict)]
        if isinstance(value,dict):
            out=[]
            for k,v in value.items():
                if isinstance(v,dict):
                    row=dict(v); row.setdefault('pos_id',k); out.append(row)
            if out: return out
    if obj and all(isinstance(v,dict) for v in obj.values()):
        out=[]
        for k,v in obj.items():
            row=dict(v); row.setdefault('pos_id',k); out.append(row)
        return out
    return []

def _v1093_first_deep(obj, keys, depth=0):
    if depth>5: return None
    if isinstance(obj,dict):
        for key in keys:
            value=obj.get(key)
            if value not in (None,'',[],{}): return value
        for value in obj.values():
            if isinstance(value,(dict,list)):
                found=_v1093_first_deep(value,keys,depth+1)
                if found not in (None,'',[],{}): return found
    elif isinstance(obj,list):
        for value in obj[:40]:
            found=_v1093_first_deep(value,keys,depth+1)
            if found not in (None,'',[],{}): return found
    return None

def _v1093_ticker(row):
    text=str(_v1093_first_deep(row,('ticker','market','symbol')) or '').upper().replace('_','-').replace('/','-')
    parts=[x for x in text.split('-') if x]
    if len(parts)>1:
        non=[x for x in parts if x!='KRW']; text=non[-1] if non else parts[-1]
    if text.endswith('KRW') and len(text)>3: text=text[:-3]
    return text or '-'

def _v1093_metric(rows):
    vals=[]; mfe=[]; mae=[]; give=[]; hold=[]
    for row in rows:
        pnl=_v1093_num(row.get('net_pnl_pct'),row.get('pnl_pct'),default=None)
        if pnl is not None: vals.append(pnl)
        for key,target in (('mfe_pct',mfe),('mae_pct',mae),('giveback_pct',give),('hold_sec',hold)):
            v=_v1093_num(row.get(key),default=None)
            if v is not None: target.append(v)
    n=len(vals); wins=sum(1 for x in vals if x>0)
    return {'rows':len(rows),'pnl_rows':n,'wins':wins,'losses':sum(1 for x in vals if x<=0),'win_rate_pct':round(wins/n*100,2) if n else None,
            'sum_pnl_pct':round(sum(vals),4) if vals else None,'avg_pnl_pct':round(sum(vals)/n,4) if n else None,
            'avg_mfe_pct':round(sum(mfe)/len(mfe),4) if mfe else None,'avg_mae_pct':round(sum(mae)/len(mae),4) if mae else None,
            'avg_giveback_pct':round(sum(give)/len(give),4) if give else None,'avg_hold_sec':round(sum(hold)/len(hold),1) if hold else None}

def _v1093_group(rows, classifier):
    from collections import defaultdict
    groups=defaultdict(list)
    for row in rows:
        try: key=classifier(row)
        except Exception: key='ERROR'
        groups[str(key or 'MISSING')].append(row)
    return {k:_v1093_metric(v) for k,v in sorted(groups.items(), key=lambda kv:(-len(kv[1]),kv[0]))}

def _v1093_last_function(source, name):
    try:
        tree=ast.parse(source)
        nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name==name]
        if not nodes: return {'found':False,'name':name,'segment':'','line':None}
        node=nodes[-1]; lines=source.splitlines(); end=getattr(node,'end_lineno',node.lineno)
        return {'found':True,'name':name,'segment':'\n'.join(lines[node.lineno-1:end]),'line':node.lineno,'end_line':end}
    except Exception as exc:
        return {'found':False,'name':name,'segment':'','line':None,'error':f'{type(exc).__name__}:{exc}'}

def _v1093_line_evidence(source, patterns, limit=8):
    out=[]
    for idx,line in enumerate(source.splitlines(),1):
        if any(re.search(p,line,re.I) for p in patterns):
            out.append({'line':idx,'text':line.strip()[:240]})
            if len(out)>=limit: break
    return out

def _v1093_static_contract_audit():
    paper_path=BOT_DIR/'paper_bot.py'; strategy_path=BOT_DIR/'strategy_worker.py'
    paper=paper_path.read_text(encoding='utf-8',errors='ignore') if paper_path.exists() else ''
    strategy=strategy_path.read_text(encoding='utf-8',errors='ignore') if strategy_path.exists() else ''
    final_safety=_v1093_last_function(paper,'paper_final_safety'); select_fn=_v1093_last_function(paper,'select_candidates'); swing_gate=_v1093_last_function(strategy,'apply_swing_entry_gate')
    ps=final_safety.get('segment') or ''; ss=select_fn.get('segment') or ''; sg=swing_gate.get('segment') or ''
    actual_rr_present=bool(re.search(r'actual[_ ]?entry[_ ]?rr|actual_rr',ps,re.I) and re.search(r'(minimum|min).*rr|<\s*1\.5|V925_MIN_RR',ps,re.I))
    reaction_called='_paper_v144_reaction_proof_block' in ps
    quality_nonblocking_flag=bool(re.search(r"quality_conditions_blocking_v925['\"]?\s*[:=]\s*False",ps,re.I) or re.search(r"quality_final_hard_block_v1039['\"]?\s*[:=]\s*False",ps,re.I))
    quality_block=bool(('swing_quality_gate_v1097' in sg and 'hard_pass' in sg and 'quality_confirmation_absent' in sg) or (not quality_nonblocking_flag and re.search(r"(price_reaction|relative_strength|money_flow|buy_ratio).*?(hard|block|append)",ps,re.I|re.S)))
    slip_missing_block=bool(re.search(r'(slip|slippage)\s+is\s+None',ps) and re.search(r'(hard|block|reason)',ps,re.I))
    rank_present=bool(('quality_rank_owner' in sg and re.search(r'eligible_rows\.sort|swing_quality_rank',sg,re.I)) or re.search(r'(sorted\(|\.sort\().*(relative_strength|money_flow|quality|execution|priority_rank)',ss,re.I|re.S))
    max_open=re.search(r"['\"]max_open_strict['\"]\s*:\s*([0-9]+)",paper)
    max_new=re.search(r"['\"]max_new_per_cycle['\"]\s*:\s*([0-9]+)",paper)
    quality_observation=bool('quality_metric_role_v1039' in sg and 'score_priority_record_only' in sg and re.search(r'quality_final_hard_block_v1039[^\n]*False',sg))
    findings=[
        {'id':'ACTUAL_ENTRY_RR_RECHECK_MISSING','severity':'CHECK' if not actual_rr_present else 'NORMAL','owner':'paper.final_safety','proven_gap':not actual_rr_present,'detail':'confirmation entry price is checked for chase but actual-entry RR/target room is not hard-revalidated' if not actual_rr_present else 'actual-entry RR hard recheck detected','line':final_safety.get('line')},
        {'id':'QUALITY_METRICS_NON_BLOCKING','severity':'CHECK' if quality_observation and not quality_block else 'NORMAL','owner':'strategy→paper selector','proven_gap':bool(quality_observation and not quality_block),'detail':'reaction/relative strength/money flow are score·record only and final Paper safety has no quality hard block' if quality_observation and not quality_block else 'quality blocking path detected','line':swing_gate.get('line')},
        {'id':'REACTION_PROOF_CONFIG_BYPASSED','severity':'CHECK' if not reaction_called else 'NORMAL','owner':'paper.final_safety','proven_gap':not reaction_called,'detail':'active final safety does not call configured reaction-proof block' if not reaction_called else 'reaction proof called','line':final_safety.get('line')},
        {'id':'SLIPPAGE_MISSING_ALLOWED','severity':'CHECK' if not slip_missing_block else 'NORMAL','owner':'paper.final_safety','proven_gap':not slip_missing_block,'detail':'confirmed slippage above limit blocks, but missing/unconfirmed slippage does not' if not slip_missing_block else 'missing slippage block detected','line':final_safety.get('line')},
        {'id':'OPEN_LIMIT_MODE','severity':'NORMAL','owner':'paper.control','proven_gap':False,'detail':f"policy={OPEN_LIMIT_POLICY_V1199}, max_open_strict={max_open.group(1) if max_open else 'UNKNOWN'}, max_new_per_cycle={max_new.group(1) if max_new else 'UNKNOWN'}; 후보·OPEN 개수 제한은 품질검수 전 변경 금지",'line':None},
        {'id':'FINAL_QUALITY_RANK_OWNER_MISSING','severity':'CHECK' if not rank_present else 'NORMAL','owner':'strategy.apply_swing_entry_gate→paper.select_candidates','proven_gap':not rank_present,'detail':'no explicit final sort by relative strength/structure/money-flow/execution before future OPEN cap' if not rank_present else 'explicit final quality ranking detected','line':select_fn.get('line')},
    ]
    return {'paper_source':paper_path.name,'strategy_source':strategy_path.name,'paper_sha256':short_hash(paper_path) if paper_path.exists() else None,'strategy_sha256':short_hash(strategy_path) if strategy_path.exists() else None,
            'findings':findings,'evidence':{
              'paper_final_safety':_v1093_line_evidence(ps,[r'trigger_rr|risk_reward',r'chase',r'spread',r'slipp',r'quality',r'reaction'],12),
              'strategy_quality_gate':_v1093_line_evidence(sg,[r'quality_final_hard_block',r'score_priority_record_only',r'confirmed_slip',r'risk_reward',r'target_room'],12),
              'paper_select':_v1093_line_evidence(ss,[r'max_open',r'max_new',r'for .*filtered|for .*candidate',r'sort'],12)},
            'strategy_or_entry_changed':False,'auto_buy':False}

def _v1093_bucket_rr(row):
    rr=_v1093_num(row.get('actual_entry_rr'),default=None)
    if rr is None: return 'MISSING'
    if rr<1.5: return '<1.5'
    if rr<2.0: return '1.5-1.99'
    return '>=2.0'

def _v1093_bucket_open(row):
    value=_v1093_num(row.get('open_count_before'),default=None)
    if value is None: return 'MISSING'
    if value<20: return '0-19'
    if value<40: return '20-39'
    if value<80: return '40-79'
    return '80+'

def _v1093_bucket_cycle(row):
    value=_v1093_num(row.get('new_index_in_cycle'),default=None)
    if value is None: return 'MISSING'
    if value<=1: return '1'
    if value<=3: return '2-3'
    if value<=10: return '4-10'
    return '11+'

def _v1093_closed_analysis(snapshot):
    rows=[dict(x) for x in snapshot.get('rows',[]) if isinstance(x,dict)] if isinstance(snapshot,dict) else []
    rows.sort(key=lambda r:_v1093_num(r.get('closed_at'),default=0.0) or 0.0)
    nowv=time.time(); recent24=[r for r in rows if (_v1093_num(r.get('closed_at'),default=0.0) or 0)>=nowv-86400]
    windows={'all':_v1093_metric(rows),'recent_24h':_v1093_metric(recent24),'latest_20':_v1093_metric(rows[-20:]),'latest_50':_v1093_metric(rows[-50:]),'latest_100':_v1093_metric(rows[-100:])}
    quality_keys=('price_reaction_pct','buy_ratio','buy_sustain_1m','relative_strength','money_flow','spread_pct','paper_reference_slippage_pct')
    complete=[r for r in rows if all(_v1093_num(r.get(k),default=None) is not None for k in quality_keys)]
    missing=[r for r in rows if r not in complete]
    builds=_v1093_group(rows,lambda r:str(r.get('entry_build_key') or r.get('paper_build_label') or r.get('opened_paper_version') or 'MISSING'))
    builds=dict(list(builds.items())[:20])
    named={}
    for token in ('v1058','v1059','v1073'):
        matched=[r for r in rows if token in ' '.join(str(r.get(k) or '') for k in ('entry_build_key','paper_build_label','opened_paper_version','candidate_entry_build_key_v923')).lower()]
        named[token]=_v1093_metric(matched)
    counterfactual={
      'recorded_open_lt20':_v1093_metric([r for r in rows if (_v1093_num(r.get('open_count_before'),default=999999) or 999999)<20]),
      'recorded_open_lt30':_v1093_metric([r for r in rows if (_v1093_num(r.get('open_count_before'),default=999999) or 999999)<30]),
      'recorded_open_lt50':_v1093_metric([r for r in rows if (_v1093_num(r.get('open_count_before'),default=999999) or 999999)<50]),
      'cycle_index_le2':_v1093_metric([r for r in rows if 0<(_v1093_num(r.get('new_index_in_cycle'),default=999999) or 999999)<=2]),
      'cycle_index_le3':_v1093_metric([r for r in rows if 0<(_v1093_num(r.get('new_index_in_cycle'),default=999999) or 999999)<=3]),
      'open_lt20_and_cycle_le3':_v1093_metric([r for r in rows if (_v1093_num(r.get('open_count_before'),default=999999) or 999999)<20 and 0<(_v1093_num(r.get('new_index_in_cycle'),default=999999) or 999999)<=3]),
    }
    return {'snapshot_id':snapshot.get('snapshot_id') if isinstance(snapshot,dict) else None,'source_digest':snapshot.get('source_digest') if isinstance(snapshot,dict) else None,'exact_counts':snapshot.get('counts') if isinstance(snapshot,dict) else {},'windows':windows,
            'groups':{'actual_entry_rr':_v1093_group(rows,_v1093_bucket_rr),'open_count_before':_v1093_group(rows,_v1093_bucket_open),'new_index_in_cycle':_v1093_group(rows,_v1093_bucket_cycle),
                      'source_lane':_v1093_group(rows,lambda r:r.get('source_lane') or 'MISSING'),'hot_rank_lane':_v1093_group(rows,lambda r:'HOT' if r.get('hot_rank_lane') else 'NORMAL'),
                      'slippage_state':_v1093_group(rows,lambda r:r.get('paper_reference_measurement_state') or 'MISSING'),
                      'quality_coverage':{'COMPLETE':_v1093_metric(complete),'MISSING_ANY':_v1093_metric(missing)},'build_cohorts':builds,'named_release_matches':named},
            'counterfactual_recorded_filter_only':counterfactual,'interpretation':'descriptive recorded-row filters only; not replay and not proof that a new cap would reproduce these results'}

def _v1093_actual_rr(row):
    direct=_v1093_num(_v1093_first_deep(row,('actual_entry_rr','actual_rr')),default=None)
    if direct is not None: return direct
    entry=_v1093_num(_v1093_first_deep(row,('entry_price','open_price','confirmation_price','current_confirmation_price','price')),default=None)
    target=_v1093_num(_v1093_first_deep(row,('target_price','swing_target_price_v977')),default=None)
    invalid=_v1093_num(_v1093_first_deep(row,('invalid_price','swing_invalid_price_v977','stop_price')),default=None)
    if entry and target and invalid is not None and target>entry>invalid:
        return (target-entry)/(entry-invalid)
    return None

def _v1093_open_analysis(obj):
    from collections import Counter
    rows=_v1093_rows(obj); tickers=[_v1093_ticker(r) for r in rows]; ticker_counts=Counter(tickers)
    dup={k:v for k,v in ticker_counts.items() if k!='-' and v>1}
    decision=Counter(str(_v1093_first_deep(r,('paper_decision_key_v926','decision_key','swing_gate_decision_key_v977')) or '') for r in rows)
    candidate=Counter(str(_v1093_first_deep(r,('trigger_occurrence_candidate_key_v1037','candidate_key','candidate_entry_build_key','entry_build_key')) or '') for r in rows)
    rr=[_v1093_actual_rr(r) for r in rows]; spread=[_v1093_num(_v1093_first_deep(r,('spread_pct','micro_spread_pct')),default=None) for r in rows]; slip=[_v1093_num(_v1093_first_deep(r,('slippage_pct_confirmed','paper_reference_slippage_pct','slippage_pct')),default=None) for r in rows]
    quality_keys=(('reaction',('price_reaction_pct','reaction_pct')),('relative_strength',('relative_strength_pct','relative_strength')),('money_flow',('money_flow_score','money_expand_score','turnover_change_pct')),('buy_ratio',('buy_ratio','micro_buy_ratio')))
    missing={name:sum(1 for r in rows if _v1093_num(_v1093_first_deep(r,keys),default=None) is None) for name,keys in quality_keys}
    return {'count':len(rows),'duplicate_tickers':dup,'duplicate_decision_keys':sum(1 for k,v in decision.items() if k and v>1),'duplicate_candidate_keys':sum(1 for k,v in candidate.items() if k and v>1),
            'actual_rr_below_1_5':sum(1 for x in rr if x is not None and x<1.5),'actual_rr_missing':sum(1 for x in rr if x is None),'spread_missing':sum(1 for x in spread if x is None),'slippage_missing':sum(1 for x in slip if x is None),'quality_missing':missing,
            'rows_sample':[{'ticker':_v1093_ticker(r),'actual_rr':round(_v1093_actual_rr(r),3) if _v1093_actual_rr(r) is not None else None,'entry_build':str(_v1093_first_deep(r,('entry_build_key','paper_build_label','build')) or '-')[:80]} for r in rows[:12]]}

def _v1093_percentile(values, value, reverse=False):
    clean=sorted(x for x in values if x is not None)
    if value is None or not clean: return None
    if len(clean)==1: return 1.0
    below=sum(1 for x in clean if x<value); equal=sum(1 for x in clean if x==value); rank=(below+0.5*equal)/len(clean)
    return 1.0-rank if reverse else rank

def _v1093_candidate_analysis(obj):
    rows=_v1093_rows(obj)
    eligible=[r for r in rows if bool(_v1093_first_deep(r,('open_eligible','paper_bot_open','trade_ready'))) or str(_v1093_first_deep(r,('s_stage','candidate_stage','stage')) or '').upper()=='S1']
    metrics=[]
    for r in eligible:
        rr=_v1093_actual_rr(r); rel=_v1093_num(_v1093_first_deep(r,('relative_strength_pct','relative_strength')),default=None); reaction=_v1093_num(_v1093_first_deep(r,('price_reaction_pct','reaction_pct')),default=None); flow=_v1093_num(_v1093_first_deep(r,('money_flow_score','money_expand_score','turnover_change_pct')),default=None); buy=_v1093_num(_v1093_first_deep(r,('buy_ratio','micro_buy_ratio')),default=None); spread=_v1093_num(_v1093_first_deep(r,('spread_pct','micro_spread_pct')),default=None); slip=_v1093_num(_v1093_first_deep(r,('slippage_pct_confirmed','slippage_pct')),default=None); chase=_v1093_num(_v1093_first_deep(r,('trigger_chase_pct','trigger_gap_pct')),default=None); room=_v1093_num(_v1093_first_deep(r,('target_room_pct',)),default=None)
        metrics.append({'row':r,'ticker':_v1093_ticker(r),'rr':rr,'relative':rel,'reaction':reaction,'flow':flow,'buy':buy,'spread':spread,'slip':slip,'chase':chase,'room':room})
    pools={k:[x[k] for x in metrics] for k in ('rr','relative','reaction','flow','buy','spread','slip','chase','room')}
    ranked=[]
    for x in metrics:
        structure_vals=[_v1093_percentile(pools['rr'],x['rr']),_v1093_percentile(pools['room'],x['room']),_v1093_percentile(pools['reaction'],x['reaction'])]
        flow_vals=[_v1093_percentile(pools['flow'],x['flow']),_v1093_percentile(pools['buy'],x['buy'])]
        exec_vals=[_v1093_percentile(pools['spread'],x['spread'],True),_v1093_percentile(pools['slip'],x['slip'],True),_v1093_percentile(pools['chase'],x['chase'],True)]
        relp=_v1093_percentile(pools['relative'],x['relative'])
        owner_rank=_v1093_num(_v1093_first_deep(x['row'],('swing_quality_rank',)),default=None)
        owner_score=_v1093_num(_v1093_first_deep(x['row'],('swing_quality_rank_score',)),default=None)
        complete=owner_rank is not None
        score=owner_score
        ranked.append({'ticker':x['ticker'],'strategy_rank':int(owner_rank) if owner_rank is not None else None,'shadow_score':round(score,2) if score is not None else None,'rank_complete':complete,'actual_rr':round(x['rr'],3) if x['rr'] is not None else None,'relative_strength':x['relative'],'reaction':x['reaction'],'money_flow':x['flow'],'buy_ratio':x['buy'],'spread':x['spread'],'slippage':x['slip'],'chase':x['chase']})
    ranked.sort(key=lambda r:(r.get('strategy_rank') is None,int(r.get('strategy_rank') or 10**9),r['ticker']))
    rr=[x['rr'] for x in metrics]
    return {'source_rows':len(rows),'eligible_rows':len(eligible),'actual_rr_below_1_5':sum(1 for x in rr if x is not None and x<1.5),'actual_rr_missing':sum(1 for x in rr if x is None),
            'rank_complete':sum(1 for r in ranked if r['rank_complete']),'rank_incomplete':sum(1 for r in ranked if not r['rank_complete']),
            'top_shadow':ranked[:50],'top_coverage':{str(n):{'available_complete':min(n,sum(1 for r in ranked if r['rank_complete'])),'eligible_total':len(eligible)} for n in (10,20,30,50)},
            'ranking_contract':'read-only Strategy-owned swing_quality_rank/swing_quality_rank_score from canonical S1 hold; no independent rerank; missing stays incomplete'}

def collect_quality_open_audit_v1093():
    started=time.monotonic(); static=_v1093_static_contract_audit()
    perf=read_json(BOT_DIR/'canonical_performance_snapshot_v987.json') or {}
    opened=read_json(BOT_DIR/'paper_bot_open.json') or {}
    candidates=read_json(BOT_DIR/'paper_s1_hold_cache.json') or {}
    closed=_v1093_closed_analysis(perf); open_audit=_v1093_open_analysis(opened); candidate_audit=_v1093_candidate_analysis(candidates)
    proven=[x for x in static.get('findings',[]) if x.get('proven_gap')]
    exact=closed.get('exact_counts') if isinstance(closed.get('exact_counts'),dict) else {}
    payload={'schema':'quality_open_root_audit_snapshot_v1097','version':'v1097','created_ts':time.time(),'created_text':now(),'owner':'guard_single_quality_open_audit_writer',
             'status':'CHECK' if proven else 'NORMAL','static_code_contract':static,'closed_exact_analysis':closed,'current_open':open_audit,'current_candidates':candidate_audit,
             'summary':{'proven_code_gaps':len(proven),'proven_gap_ids':[x.get('id') for x in proven],'exact_duplicate':int(exact.get('duplicate_closed_rows') or exact.get('duplicate') or 0),'exact_key_missing':int(exact.get('missing_decision_key') or exact.get('key_missing') or 0),'exact_unlinked':int(exact.get('unlinked') or exact.get('decision_not_closed') or 0),'open_count':open_audit.get('count'),'candidate_eligible':candidate_audit.get('eligible_rows'),'auto_buy':False},
             'policy':{'read_only':True,'strategy_changed':True,'entry_exit_changed':True,'open_limit_changed':True,'quality_threshold_changed':True,'ledgers_mutated':False,'auto_buy':False,'attribution':'v1097 audit reads current post-recovery contract; reset CLOSED rows remain a separate transition cohort'},
             'duration_sec':round(time.monotonic()-started,3)}
    stable=dict(payload); stable.pop('created_ts',None); stable.pop('created_text',None); stable.pop('duration_sec',None)
    payload['digest']=hashlib.sha256(json.dumps(stable,ensure_ascii=False,sort_keys=True,default=str,separators=(',',':')).encode()).hexdigest()
    write_json(QUALITY_OPEN_AUDIT_V1093,payload)
    return payload

def _v1093_append_result(report):
    marker=read_json(QUALITY_OPEN_AUDIT_MARKER_V1093) or {}; digest=str(report.get('digest') or '')
    if marker.get('digest')==digest: return
    status='DONE' if report.get('schema')=='quality_open_root_audit_snapshot_v1097' else 'CHECK'
    common={'version':'v1097','ts':time.time(),'time':now(),'status':status,'strategy_impact':'v1097_current_contract_read_only_audit','auto_buy':False,'proof_digest':digest}
    _append_jsonl_fsync_v1074(BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1093',event_type='ISSUE',issue_id='WINRATE-CANDIDATE-OPEN-AUDIT-1093',title='Win-rate code contract and candidate/open root audit',summary='Read-only audit seals code contract gaps, exact CLOSED cohorts, current OPEN exposure and candidate quality shadow.',remaining='User approval required before any OPEN cap or quality gate change.'))
    _append_jsonl_fsync_v1074(BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1093',event_type='CHANGE_VERIFY',change_id='v1093-winrate-candidate-open-root-audit-001',issue_id='WINRATE-CANDIDATE-OPEN-AUDIT-1093',summary='Single canonical audit snapshot generated; no strategy/entry/exit/ledger mutation.',remaining='Use exact evidence to choose grouped v1094 surgery.'))
    write_json(QUALITY_OPEN_AUDIT_MARKER_V1093,{'schema':'quality_open_audit_marker_v1093','digest':digest,'ts':time.time(),'time':now()})

def gquality_open_audit_v1093_text() -> str:
    try:
        report=collect_quality_open_audit_v1093(); _v1093_append_result(report)
        summary=report.get('summary') or {}; windows=((report.get('closed_exact_analysis') or {}).get('windows') or {}); recent=windows.get('recent_24h') or {}; latest=(windows.get('latest_50') or {})
        open_a=report.get('current_open') or {}; cand=report.get('current_candidates') or {}
        return '\n'.join([
          '🔬 v1093 승률 코드원인·후보품질·OPEN 통합감사',
          f"- 판정: DONE(읽기전용 감사) / 코드 계약 gap {summary.get('proven_code_gaps')}건",
          f"- 최근24h: {recent.get('rows')}건 · 승률 {recent.get('win_rate_pct')}% · 합산 {recent.get('sum_pnl_pct')}%",
          f"- 최근50: {latest.get('rows')}건 · 승률 {latest.get('win_rate_pct')}% · 합산 {latest.get('sum_pnl_pct')}%",
          f"- 현재 OPEN {open_a.get('count')} · actual RR<1.5 {open_a.get('actual_rr_below_1_5')} · RR누락 {open_a.get('actual_rr_missing')} · 중복ticker {len(open_a.get('duplicate_tickers') or {})}",
          f"- 현재 후보 S1/eligible {cand.get('eligible_rows')} · rank완성 {cand.get('rank_complete')} · actual RR<1.5 {cand.get('actual_rr_below_1_5')}",
          f"- exact 진단 duplicate/key_missing/unlinked {summary.get('exact_duplicate')}/{summary.get('exact_key_missing')}/{summary.get('exact_unlinked')}",
          f"- snapshot: {QUALITY_OPEN_AUDIT_V1093.name} / digest {str(report.get('digest') or '')[:16]} / {report.get('duration_sec')}초",
          '- v1097 현재 계약 기준 재감사 / 원장 변경 0 / 자동매수 OFF',
          '- 메인봇: /quality_open_audit',
        ])
    except Exception as exc:
        return f'🔬 v1093 통합감사 실패\n- {type(exc).__name__}: {exc}\n- 전략·매매·원장 변경 0 / 자동매수 OFF'

QUALITY_SPINE_VERIFY = BOT_DIR / 'quality_spine_verify.json'

QUALITY_SPINE_MARKER = BOT_DIR / '.quality_spine_verify_marker.json'

def _quality_spine_file_rows(path: Path):
    obj=read_json(path) or {}
    if isinstance(obj,list): return [x for x in obj if isinstance(x,dict)]
    if isinstance(obj,dict):
        for key in ('rows','positions','open_positions'):
            value=obj.get(key)
            if isinstance(value,list): return [x for x in value if isinstance(x,dict)]
            if isinstance(value,dict): return [x for x in value.values() if isinstance(x,dict)]
        if obj and all(isinstance(v,dict) for v in obj.values()): return list(obj.values())
    return []

def collect_quality_spine_verify(window_sec: int=0):
    window_sec=max(0,min(420,int(window_sec or 0)))
    samples=[]; deadline=time.time()+window_sec
    while True:
        paper=read_json(BOT_DIR/'paper_bot_status.json') or {}
        phase=read_json(BOT_DIR/'paper_runtime_phase_v994.json') or {}
        strategy_worker=read_json(BOT_DIR/'clean_strategy_worker_status.json') or {}
        strategy=read_json(BOT_DIR/'clean_strategy_swing_gate_status_v977.json') or {}
        feature=read_json(BOT_DIR/'clean_feature_status.json') or {}
        orderflow_rows=_quality_spine_file_rows(BOT_DIR/'clean_orderflow_summary_cache.json')
        slip_rows=[r for r in orderflow_rows if r.get('entry_slippage_confirmed') is True and str(r.get('entry_slippage_owner') or '')=='orderflow_worker' and r.get('entry_slippage_est_pct') is not None]
        open_rows=_quality_spine_file_rows(BOT_DIR/'paper_bot_open.json')
        pick=paper.get('pick_stats') if isinstance(paper.get('pick_stats'),dict) else {}
        paper_stamp=paper.get('updated_ts') or paper.get('updated_at') or paper.get('ts')
        samples.append({
            'ts':time.time(),'paper_version':paper.get('version'),'paper_build':paper.get('build'),
            'paper_status_age':max(0.0,time.time()-float(paper_stamp or 0.0)) if paper_stamp else None,
            'paper_cycle':paper.get('elapsed_sec'),'paper_phase':phase.get('phase'),'open_count':len(open_rows),
            'strategy_worker_version':strategy_worker.get('version'),'strategy_worker_build':strategy_worker.get('build'),
            'strategy_gate_version':strategy.get('version'),'strategy_gate_build':strategy.get('build'),
            'quality_rows':strategy.get('rows'),'quality_pass':strategy.get('quality_gate_pass_count_v1098'),
            'quality_block':strategy.get('quality_gate_block_count_v1098'),'quality_rank':strategy.get('quality_rank_complete'),
            'transport_matched':strategy.get('quality_transport_source_matched_rows_v1098'),
            'transport_relative_known':strategy.get('quality_transport_relative_known_rows_v1098'),
            'transport_money_known':strategy.get('quality_transport_money_known_rows_v1098'),
            'transport_owner_rows':strategy.get('quality_transport_feature_owner_rows_v1098'),
            'transport_both_missing_block':strategy.get('quality_transport_both_missing_block_rows_v1098'),
            'transport_missing_axes':strategy.get('quality_transport_missing_axes_v1098'),
            'quality_tiers':strategy.get('quality_gate_tier_counts_v1098'),
            'quality_block_reasons':strategy.get('quality_gate_block_reason_counts_v1098'),
            'feature_relative_known':feature.get('relative_strength_known_v1095'),
            'feature_money_known':feature.get('money_flow_known_v1095'),'feature_rows':feature.get('row_count'),
            'orderflow_slippage_known':len(slip_rows),'orderflow_rows':len(orderflow_rows),
            'orderflow_slippage_sources':dict(Counter(str(r.get('entry_slippage_source') or 'missing') for r in slip_rows)),
            'paper_s1_seen':pick.get('s1_seen'),'paper_ttl_pass':pick.get('s1_ttl_fresh_v1039'),
            'paper_strategy_execution_fresh':pick.get('s1_execution_fresh_v1039'),
            'paper_execution_pass':pick.get('paper_execution_pass_v1099'),
            'paper_final_checked':pick.get('paper_final_safety_checked_v1099'),
            'paper_final_pass':pick.get('paper_final_safety_pass_v1099'),
            'paper_selected':pick.get('selected_s1'),'paper_hold':pick.get('paper_entry_hold',pick.get('paper_final_block')),
            'paper_hold_reason_counts':pick.get('paper_entry_hold_reason_counts_v1099') if isinstance(pick.get('paper_entry_hold_reason_counts_v1099'),dict) else {},
            'paper_hold_rows':len(pick.get('paper_entry_hold_rows_v1099') or []) if isinstance(pick.get('paper_entry_hold_rows_v1099'),list) else 0,
            'paper_funnel_accounted':pick.get('paper_funnel_accounted_v1102'),'paper_funnel_unclassified':pick.get('paper_funnel_unclassified_v1102'),
            'paper_funnel_balance_ok':pick.get('paper_funnel_balance_ok_v1102'),'paper_terminal_counts':pick.get('paper_funnel_terminal_counts_v1102') if isinstance(pick.get('paper_funnel_terminal_counts_v1102'),dict) else {},
        })
        if time.time()>=deadline: break
        time.sleep(min(10,max(1,deadline-time.time())))
    last=samples[-1]
    main_src=(BOT_DIR/'bot.py').read_text(encoding='utf-8',errors='ignore') if (BOT_DIR/'bot.py').exists() else ''
    strategy_src=(BOT_DIR/'strategy_worker.py').read_text(encoding='utf-8',errors='ignore') if (BOT_DIR/'strategy_worker.py').exists() else ''
    quality_rows=int(last.get('quality_rows') or 0)
    matched=int(last.get('transport_matched') or 0); rel=int(last.get('transport_relative_known') or 0); money=int(last.get('transport_money_known') or 0)
    both_missing=int(last.get('transport_both_missing_block') or 0)
    paper_src=(BOT_DIR/'paper_bot.py').read_text(encoding='utf-8',errors='ignore') if (BOT_DIR/'paper_bot.py').exists() else ''
    s1_seen=int(last.get('paper_s1_seen') or 0); selected=int(last.get('paper_selected') or 0); hold_rows=int(last.get('paper_hold_rows') or 0); accounted=int(last.get('paper_funnel_accounted') or 0)
    checks={
      'main_v2_13_1087_source': '수익형 v2.13.1087' in main_src and 'v1102_full_flow_map_and_paper_funnel_accounting_2026-06-28' in main_src,
      'strategy_v1_001_runtime': str(last.get('strategy_gate_version') or '')=='strategy_worker_v1.001' and str(last.get('strategy_gate_build') or '')=='v1100_orderflow_slippage_canonical_spine_2026-06-28',
      'strategy_transport_code_active': '_v1098_copy_feature_quality_fields' in strategy_src and 'feature_cache_pre_gate_overlay_v1098' in strategy_src,
      'strategy_hold_execution_proof_active': 'execution_fresh_ok_v1039' in strategy_src and 'swing_quality_rank' in strategy_src,
      'paper_v1_013': str(last.get('paper_version') or '')=='paper_bot_v1.013',
      'orderflow_v0_11_runtime': str((read_json(BOT_DIR/'clean_orderflow_status.json') or {}).get('version') or '')=='orderflow_worker_v0.11',
      'orderflow_slippage_owner_present': int(last.get('orderflow_slippage_known') or 0)>0,
      'paper_funnel_code_active': '_v1102_record_funnel_terminal' in paper_src and 'paper_funnel_balance_ok_v1102' in paper_src and 'canonical Paper 입력' in paper_src,
      'paper_cycle_fresh': last.get('paper_status_age') is not None and float(last.get('paper_status_age'))<90 and last.get('paper_phase') not in ('startup_permissions','startup_decision_reconcile'),
      'paper_funnel_accounted_when_s1': (s1_seen==0 or (last.get('paper_funnel_balance_ok') is True and accounted==s1_seen and int(last.get('paper_funnel_unclassified') or 0)==0)),
      'feature_quality_present': int(last.get('feature_relative_known') or 0)>0 and int(last.get('feature_money_known') or 0)>0,
      'strategy_quality_rows_present': quality_rows>0,
      'feature_to_strategy_rows_matched': matched>0,
      'relative_strength_transport_present': rel>0,
      'money_flow_transport_present': money>0,
      'all_rows_not_both_source_missing': quality_rows>0 and both_missing<quality_rows,
      'open_cap_30': len(_quality_spine_file_rows(BOT_DIR/'paper_bot_open.json'))<=30,
      'auto_buy_off': True,
    }
    failed=[k for k,v in checks.items() if not v]
    report={'schema':'quality_full_flow_verify_v1102','version':'v1102','created_ts':time.time(),'created_text':now(),'status':'DONE' if not failed else 'CHECK','checks':checks,'failed':failed,'samples':samples[-50:],'last':last,'policy':{'quality_value_owner':'feature_worker','slippage_value_owner':'orderflow_worker','transport_owner':'strategy_worker canonical candidate spine','paper_consumer_owner':'paper_bot final safety','quality_threshold_changed':False,'slippage_limit_changed':False,'open_limit_changed':False,'exit_contract_changed':False,'auto_buy':False}}
    write_json(QUALITY_SPINE_VERIFY,report)
    return report

def _append_quality_spine_verify(report):
    digest=hashlib.sha256(json.dumps(report.get('checks') or {},sort_keys=True,separators=(',',':')).encode()).hexdigest()
    marker=read_json(QUALITY_SPINE_MARKER) or {}
    if marker.get('digest')==digest and marker.get('status')==report.get('status'): return
    if not marker:
        opened={'version':'v1102','ts':time.time(),'time':now(),'status':'OPEN','auto_buy':False,'proof_digest':'pending'}
        _append_jsonl_fsync_v1074(BOT_DIR/'issue_ledger.jsonl',dict(opened,schema='issue_event_v1102',event_type='ISSUE_OPEN',issue_id='FLOW-MAP-1102',title='Full lifecycle map and Paper funnel accounting',summary='Open server verification for canonical full-flow snapshot and complete S1 terminal accounting.',remaining='runtime apply and flow/accounting proof'))
        _append_jsonl_fsync_v1074(BOT_DIR/'change_verify_ledger.jsonl',dict(opened,schema='change_verify_event_v1102',event_type='CHANGE_START',change_id='v1102-flow-map-accounting-001',issue_id='FLOW-MAP-1102',summary='Start verification for one canonical flow map and Paper S1 input=terminal outcome accounting.',remaining='runtime apply and flow/accounting proof'))
    common={'version':'v1102','ts':time.time(),'time':now(),'status':report.get('status'),'auto_buy':False,'proof_digest':digest}
    _append_jsonl_fsync_v1074(BOT_DIR/'issue_ledger.jsonl',dict(common,schema='issue_event_v1102',event_type='ISSUE_VERIFY',issue_id='FLOW-MAP-1102',title='Full lifecycle map and Paper funnel accounting',summary='v1102 maps workers, joins, resources, ledgers, blocks and Paper terminal outcomes in one canonical snapshot.',remaining='None' if report.get('status')=='DONE' else ','.join(report.get('failed') or [])))
    _append_jsonl_fsync_v1074(BOT_DIR/'change_verify_ledger.jsonl',dict(common,schema='change_verify_event_v1102',event_type='CHANGE_VERIFY',change_id='v1102-flow-map-accounting-001',issue_id='FLOW-MAP-1102',summary='Server proof for canonical /flow_map and complete Paper funnel accounting.',remaining='None' if report.get('status')=='DONE' else ','.join(report.get('failed') or [])))
    write_json(QUALITY_SPINE_MARKER,{'digest':digest,'status':report.get('status'),'ts':time.time(),'time':now()})

def gquality_spine_verify_text(args=None):
    try:
        sec=0
        if isinstance(args,(list,tuple)) and args:
            try: sec=int(args[0])
            except Exception: sec=0
        report=collect_quality_spine_verify(sec); _append_quality_spine_verify(report)
        last=report.get('last') or {}
        return "\n".join([
          '🧬 v1102 전체흐름·Paper 퍼널 accounting 검수',
          f"- 판정: {report.get('status')} / 관찰 {sec}초 / 표본 {len(report.get('samples') or [])}",
          f"- Strategy {last.get('strategy_gate_version')} / {last.get('strategy_gate_build')}",
          f"- Paper {last.get('paper_version')} / phase {last.get('paper_phase')} / status age {last.get('paper_status_age')}s / cycle {last.get('paper_cycle')}",
          f"- Feature RS known {last.get('feature_relative_known')}/{last.get('feature_rows')} · money known {last.get('feature_money_known')}/{last.get('feature_rows')}",
          f"- Orderflow canonical slippage {last.get('orderflow_slippage_known')}/{last.get('orderflow_rows')} · source {last.get('orderflow_slippage_sources')}",
          f"- 전달 matched {last.get('transport_matched')} · RS known {last.get('transport_relative_known')} · money known {last.get('transport_money_known')} · owner rows {last.get('transport_owner_rows')}",
          f"- 품질 rows {last.get('quality_rows')} · pass {last.get('quality_pass')} · block {last.get('quality_block')} · rank {last.get('quality_rank')}",
          f"- Paper 퍼널 S1 {last.get('paper_s1_seen')} → TTL {last.get('paper_ttl_pass')} → Strategy 실행증명 {last.get('paper_strategy_execution_fresh')} → Paper 실행 {last.get('paper_execution_pass')} → 최종검사 {last.get('paper_final_checked')} → 최종통과 {last.get('paper_final_pass')} → 선택 {last.get('paper_selected')} · hold rows {last.get('paper_hold_rows')}",
          f"- Paper accounting {last.get('paper_funnel_accounted')}/{last.get('paper_s1_seen')} · 미분류 {last.get('paper_funnel_unclassified')} · balance {last.get('paper_funnel_balance_ok')} · terminal {last.get('paper_terminal_counts')}",
          f"- Paper 보류 사유 TOP {last.get('paper_hold_reason_counts')}",
          f"- 둘다 source_missing 차단 {last.get('transport_both_missing_block')} · missing 축 {last.get('transport_missing_axes')}",
          f"- block TOP {last.get('quality_block_reasons')}",
          f"- CHECK 항목: {', '.join(report.get('failed') or []) or '-'}",
          '- 품질값 owner Feature / slippage값 owner Orderflow / 전달·gate·rank owner Strategy',
          '- 후보수·OPEN수 인위적 제한 변경 없음 · 사용자 승인 무제한 유지',
          '- 자동매수 OFF',
        ])
    except Exception as exc:
        return f"🧬 v1102 전체흐름 검수 실패\n- {type(exc).__name__}: {exc}\n- 핵심원장 변경 금지 / 자동매수 OFF"

V1181_OPS_SNAPSHOT = BOT_DIR / 'ops_spine_snapshot_v1181.json'

V1181_OPS_STATUS = BOT_DIR / 'guard_ops_spine_status_v1181.json'

_V1181_OPS_LOCK = threading.RLock()

def refresh_ops_map_snapshot(write_reason: str = 'manual') -> dict:  # type: ignore[override]
    """Write the one active operations snapshot.

    The old collector functions remain only as historical source reference; no
    old cache fallback is used when this writer fails.
    """
    started = time.monotonic()
    with _V1181_OPS_LOCK:
        try:
            from canonical_spine_v1190 import atomic_write_json, build_ops_snapshot
            snapshot = build_ops_snapshot(BOT_DIR)
            snapshot['write_reason'] = write_reason
            snapshot['guard_version'] = VERSION
            snapshot['legacy_ops_map_collector_active'] = False
            snapshot['auto_buy'] = False
            atomic_write_json(V1181_OPS_SNAPSHOT, snapshot)
            atomic_write_json(V1181_OPS_STATUS, {
                'schema': 'guard_ops_spine_status_v1190',
                'state': 'NORMAL',
                'version': VERSION,
                'updated_ts': time.time(),
                'updated_text': now(),
                'write_reason': write_reason,
                'snapshot_id': snapshot.get('snapshot_id'),
                'overall_state': snapshot.get('overall_state'),
                'elapsed_sec': round(max(0.0, time.monotonic() - started), 6),
                'legacy_ops_map_collector_active': False,
                'auto_buy': False,
            })
            return snapshot
        except Exception as exc:
            # Fail visible. Do not return a previous ops map as current truth.
            try:
                V1181_OPS_STATUS.write_text(json.dumps({
                    'schema': 'guard_ops_spine_status_v1190',
                    'state': 'FAIL',
                    'version': VERSION,
                    'updated_ts': time.time(),
                    'updated_text': now(),
                    'write_reason': write_reason,
                    'last_error': f'{type(exc).__name__}: {exc}',
                    'legacy_fallback_used': False,
                    'auto_buy': False,
                }, ensure_ascii=False, indent=2), encoding='utf-8')
            except Exception:
                pass
            log_error('v1181_canonical_ops_spine', exc)
            return {
                'schema': 'ops_spine_snapshot_v1181',
                'overall_state': 'FAIL',
                'problems': [{
                    'code': 'OPS-SPINE-WRITE-FAIL',
                    'state': 'FAIL',
                    'owner': 'guard',
                    'reason': f'{type(exc).__name__}: {exc}',
                    'impact': 'Main 통합지도 현재값 사용 금지',
                }],
                'legacy_fallback_used': False,
                'auto_buy': False,
            }

def gops_refresh_text() -> str:  # type: ignore[override]
    snap = refresh_ops_map_snapshot('guard_command_v1190')
    current = snap.get('current_cycle') if isinstance(snap.get('current_cycle'), dict) else {}
    timing = snap.get('timing') if isinstance(snap.get('timing'), dict) else {}
    timing_path = snap.get('timing_path') if isinstance(snap.get('timing_path'), dict) else {}
    errors = snap.get('errors') if isinstance(snap.get('errors'), dict) else {}
    groups = snap.get('evidence_groups') if isinstance(snap.get('evidence_groups'), dict) else {}
    resources = snap.get('resources') if isinstance(snap.get('resources'), dict) else {}
    phase_profiles = snap.get('phase_profiles') if isinstance(snap.get('phase_profiles'), dict) else {}
    problems = snap.get('problems') if isinstance(snap.get('problems'), list) else []
    slow = [x for x in (timing_path.get('top_slowest') or []) if isinstance(x, dict)]
    lines = [
        f'🗺️ canonical 전수 운영지도 갱신 · {VERSION}',
        f"- 전체: {snap.get('overall_state') or 'CHECK'}",
        f"- 현재 cycle: {current.get('state') or 'CHECK'} / 후보 {current.get('candidate_rows')} / S1 {current.get('s1_count')} / Paper 확인 {current.get('paper_received')}",
        f"- Strategy 전달: {fmt_sec(timing.get('strategy_execution_handoff_sec')) if isinstance(timing.get('strategy_execution_handoff_sec'), (int, float)) else '수집 중'} / 전체: {fmt_sec(timing.get('strategy_full_cycle_sec')) if isinstance(timing.get('strategy_full_cycle_sec'), (int, float)) else '수집 중'} / Paper core: {fmt_sec(timing.get('paper_fast_cycle_sec')) if isinstance(timing.get('paper_fast_cycle_sec'), (int, float)) else '수집 중'}",
    ]
    if slow:
        top=slow[0]
        lines.append(f"- 가장 느린 구간: {top.get('key') or '-'} / 중앙 {fmt_sec(top.get('median_sec'))} / 최대 {fmt_sec(top.get('max_sec'))}")
    lines += [
        f"- 현재 오류 원인: {int(errors.get('current_cause_count') or 0)} / 반복 {int(errors.get('current_count') or 0)} / 과거 {int(errors.get('historical_count') or 0)}",
        f"- 증거판: 입력 {groups.get('data_intake')} / 후보배관 {groups.get('candidate_pipeline')} / Paper {groups.get('paper_execution')} / 원장 {groups.get('ledger_performance')} / runtime {groups.get('runtime_deploy')} / 명령 {groups.get('commands_delivery')}",
        f"- 파일연결: {groups.get('artifact_chain')} / 임시·backup·cache: {groups.get('storage_hygiene')}",
        f"- 자원: {groups.get('resources')} / 디스크 남음 {resources.get('disk_free_gb') if resources.get('disk_free_gb') is not None else '정보없음'}GB",
        f"- 내부 단계시간: {groups.get('phase_timing')} / 미수집 {phase_profiles.get('missing_components') or []}",
        f"- 확인할 문제: {len(problems)}개",
        f"- snapshot: {snap.get('snapshot_id') or '-'}",
        '- 지도는 진단·수리 위치 확인용 · 신규 차단 0',
        '- 구 통합지도 재계산·구 cache fallback 없음',
        '- 후보식·trigger·invalid·target·RR 유지 · 실제 개수·청산 계약은 Paper canonical snapshot · 자동매수 OFF',
    ]
    for row in problems[:8]:
        if isinstance(row, dict):
            lines.append(f"  · {row.get('code')}: {row.get('reason') or '-'}")
    return '\n'.join(lines)

# Flattened final runtime bindings


# v1190 read-only Guard map-refresh phase timing
from runtime_phase_probe_v1190 import wrap_function as _v1190_wrap_function
_v1190_wrap_function(globals(), "refresh_ops_map_snapshot", "guard", "ops_map_refresh", VERSION, 300.0)

V1260_RELEASE_TRUTH_CONTRACT = {
    'schema':'guard_release_truth_v1260',
    'manual_verify_manifest_source':'last exact release bundle',
    'strategy_required_even_when_manifest_omits_it':True,
    'strategy_pass_requires':['service_pid_hash_status','writer_result_OK','new_candidate_commit','NORMAL_pipeline_same_cycle_commit'],
    'version_only_pass_forbidden':True,
    'strategy_values_changed':False,
    'live_ledgers_changed':False,
    'auto_buy':False,
}


V1261_PUBLIC_SCORE_CONTRACT = {
    'schema':'guard_public_score_contract_v1261',
    'paper':'current unified actual vs v1211 actual only',
    'review':'fresh current missed-candidate state from zero; exact candidate key only',
    'retired_public_panels':['transition cohort','virtual structure shadow','policy competition','old missed accumulation'],
    'historical_files_deleted':False,
    'live_ledgers_rewritten':False,
    'strategy_values_changed':False,
    'auto_buy':False,
}




V1262_SCORE_TRUTH_GUARD_CONTRACT = {
    'schema':'guard_score_truth_and_semantic_missed_v1262',
    'paper':'explicit v1211 only; missing/unknown UNCLASSIFIED/CHECK',
    'review':'exact key required as evidence; semantic structure occurrence owns event',
    'ledger_verify_command':'/gledger_v1262',
    'historical_ledgers_rewritten':False,
    'candidate_formula_changed':False,
    'trigger_invalid_target_rr_changed':False,
    'entry_exit_changed':False,
    'strategy_worker_sha_unchanged':True,
    'auto_buy':False,
}

if __name__ == "__main__":
    main()
