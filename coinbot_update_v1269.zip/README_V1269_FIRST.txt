v1269 repairs only Strategy invalid support prefilter: distance is judged after the same stop buffer that will be sealed. No trigger/target/RR/exit/OPEN cap/autobuy changes.
