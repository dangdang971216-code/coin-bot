v1282 exact_replay index/WAL 경량화판. 전략·Paper 매매 로직 변경 없음. 적용 후 /gexact_replay_compact_rebuild_v1282 실행.
