# v1156 원인과 다음 단계

## 원인
- 요약 reader: Guard 후반의 두 번째 Paper status read
- 상세 reader: Guard component 수집 당시 첫 번째 Paper status read
- 결과: 서로 다른 Paper cycle 혼합

## v1156에서 확인 가능
- 이번 Paper 회차 확인 후보 수
- STALE trigger/slippage 수
- 첫 도착부터 늦은 사건 수
- 같은 trigger event 반복 노출 수
- 종목별 trigger→품질→S1→Paper 시간
- trigger event key / direct decision key

## 적용 후 다음 판단
- 반복 STALE이 많으면 동일 event 재게시 생명주기를 다음 단일 버전에서 수정
- 첫 도착 STALE이 많으면 trigger 전 Feature/Orderflow 준비 또는 Strategy 지연을 수정
- 이번 버전에서는 실제 후보 생성·진입 조건을 바꾸지 않음
