# v1156 범위와 검수

## 변경 파일
- backga_guard_bot_v2_5_191.py
- paper_bot_v1.030.py
- coinbot_main_v2_13_1117.py

## 서버 DONE 조건
1. Main/Guard/Paper alias와 versioned source hash 일치
2. `/flow_map_full` 상단 확인 수와 20단계 FLOW-11 입력·STALE 수가 같은 Paper snapshot ID에서 일치
3. stale 후보에 trigger key, decision key, 첫 도착/반복 횟수 표시
4. append-only path JSONL에서 같은 stage/event는 최초 1행만 유지
5. 새 runtime 오류 0
6. 자동매수 OFF

## 전략 영향
없음. 진입·청산·한도·안전수치 변경 없음.
