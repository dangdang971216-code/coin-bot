# v1156 작업 잠금

- 상태: 로컬 PASS / 서버 적용 전 CHECK
- 자동매수: OFF
- 전략모드: ALT_SWING

## 확정 원인
v1155 Guard는 한 운영지도 생성 중 `paper_bot_status.json`을 두 번 읽었다.
20단계 FLOW-11은 첫 번째 Paper cycle을 읽었고, 상단 시간요약은 뒤의 Paper cycle을 다시 읽었다.
그 사이 Paper cycle이 바뀌어 상세에는 STALE 2건, 상단에는 0건이 동시에 표시됐다.

## 이번 수정
1. Guard가 처음 읽은 Paper 후보 cycle 객체를 snapshot ID/digest와 함께 봉인한다.
2. 20단계 상세와 상단 시간요약이 그 객체 하나만 읽는다.
3. Paper append-once 사건 원장은 그대로 두고 mutable dedup state에 동일 event 반복 노출 횟수만 누적한다.
4. TXT에 trigger event key, direct decision key, 첫 Paper 수신, 반복 횟수, 지연구간을 표시한다.

## 변경 금지
Gate, TTL, RR, room, spread, slippage, trigger, invalid, target, 재진입, 청산, OPEN 30, cycle 3은 변경하지 않는다.
