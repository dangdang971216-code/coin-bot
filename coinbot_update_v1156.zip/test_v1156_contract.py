#!/usr/bin/env python3
from pathlib import Path
import ast, hashlib, json, tempfile, threading, os, time
from typing import Any, Dict, Optional
ROOT=Path(__file__).resolve().parent
MAIN=ROOT/'coinbot_main_v2_13_1117.py'; GUARD=ROOT/'backga_guard_bot_v2_5_191.py'; PAPER=ROOT/'paper_bot_v1.030.py'
for p in (MAIN,GUARD,PAPER): compile(p.read_text(encoding='utf-8'),str(p),'exec')

def funcs(path):
    m=ast.parse(path.read_text(encoding='utf-8'))
    return {n.name:n for n in m.body if isinstance(n,ast.FunctionDef)}

# Trading functions must be byte-semantically unchanged at AST level.
expected=json.loads((ROOT/'tests/fixtures/V1156_TRADING_FUNCTION_AST_SHA256.json').read_text())
pf=funcs(PAPER)
for name,digest in expected.items():
    got=hashlib.sha256(ast.dump(pf[name],include_attributes=False).encode()).hexdigest()
    assert got==digest,(name,got,digest)

# Guard same-snapshot contract synthetic proof.
gf=funcs(GUARD); ns={}
exec(compile(ast.Module(body=[gf['_v1154_reason_count'],gf['_v1154_candidate_time_quality_contract']],type_ignores=[]),str(GUARD),'exec'),ns)
fixture=json.loads((ROOT/'tests/fixtures/V1156_SAME_SNAPSHOT_FIXTURE.json').read_text())
out=ns['_v1154_candidate_time_quality_contract'](fixture['paper_cycle'])
for k,v in fixture['expected'].items(): assert out[k]==v,(k,out[k],v)
assert out['paper_cycle_snapshot_id_v1156']=='paper-cycle-test'
assert out['same_snapshot_proof_v1156'] is True

# Guard candidate-time path cannot reread paper status after component capture.
gtxt=GUARD.read_text(encoding='utf-8')
segment=gtxt[gtxt.index("paper_component_v1156=components.get('paper')"):gtxt.index("strategy_writer_scope_status",gtxt.index("paper_component_v1156=components.get('paper')"))]
assert "_ops_read_json(BOT_DIR/'paper_bot_status.json')" not in segment
assert "candidate_cycle_snapshot_v1156" in gtxt and "paper_cycle_snapshot_id_v1156" in gtxt

# Paper repeat exposure: one append row, repeated state count.
want=[pf['_v1153_paper_path_identity'],pf['_v1153_paper_event_once']]
with tempfile.TemporaryDirectory() as td:
    td=Path(td); ledger=td/'events.jsonl'; statef=td/'state.json'
    def load_json(path,default):
        try:return json.loads(Path(path).read_text())
        except:return default
    def save_json(path,obj):Path(path).write_text(json.dumps(obj))
    def fnum(*vals,default=0.0):
        for v in vals:
            try:
                if v not in (None,'',[],{}):return float(v)
            except:pass
        return default
    ns2=dict(Path=Path,Any=Any,Dict=Dict,Optional=Optional,threading=threading,hashlib=hashlib,json=json,os=os,
      V1153_PAPER_PATH_LEDGER=ledger,V1153_PAPER_PATH_STATE=statef,_V1153_PAPER_PATH_LOCK=threading.RLock(),
      now_ts=lambda:time.time(),iso_ts=lambda ts:'x',VERSION='paper_bot_v1.030',BUILD_LABEL='v1156',load_json=load_json,save_json=save_json,
      fnum=fnum,log_error=lambda *a:None,normalize_ticker=lambda x:str(x),read_strategy_entry_gate=lambda ev:ev.get('gate',{}),read_strategy_decision_key=lambda ev,g:g.get('decision_key'))
    exec(compile(ast.Module(body=want,type_ignores=[]),str(PAPER),'exec'),ns2)
    ev={'ticker':'AAA','gate':{'decision_key':'D1','trigger_occurrence_v1037':{'candidate_key':'T1'}}}
    first=ns2['_v1153_paper_event_once']('PAPER_RECEIVED',ev)
    assert ns2['_v1153_paper_event_once']('PAPER_RECEIVED',ev)==first
    assert ns2['_v1153_paper_event_once']('PAPER_RECEIVED',ev)==first
    exp=ev['paper_path_exposure_v1156']['PAPER_RECEIVED']
    assert exp['exposure_count']==3 and exp['repeat_exposure_count']==2
    assert len(ledger.read_text().splitlines())==1

mtxt=MAIN.read_text(encoding='utf-8')
for token in ('같은 Paper 회차','첫 도착부터 늦음','같은 사건 반복','paper_cycle_snapshot_id_v1156','trigger key'):
    assert token in mtxt,token
for token in ("BOT_VERSION = '수익형 v2.13.1117'",'paper_bot_v1.030','guard_v2.5.191_same_snapshot_candidate_trace_v1156_2026-06-30'):
    assert token in mtxt,token
print('PASS v1156 contract')
