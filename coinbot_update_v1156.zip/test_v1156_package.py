#!/usr/bin/env python3
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
manifest=ROOT/'FILES_SHA256_v1156.tsv'
rows=[]
for line in manifest.read_text().splitlines():
    if not line.strip():continue
    digest,rel=line.split('\t',1); rows.append((digest,rel))
for digest,rel in rows:
    p=ROOT/rel; assert p.is_file(),rel
    got=hashlib.sha256(p.read_bytes()).hexdigest(); assert got==digest,(rel,got,digest)
for p in ROOT.rglob('*'):
    if not p.is_file():continue
    low=str(p.relative_to(ROOT)).lower()
    assert not any(x in low for x in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','decision_state','issue_ledger_events.jsonl','runtime/','.log')),(p,low)
bundle=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text())
assert bundle['auto_buy'] is False and bundle['live_ledger_included'] is False
assert bundle['quality_formula_change'] is False and bundle['candidate_ttl_change'] is False
print('PASS v1156 package')
