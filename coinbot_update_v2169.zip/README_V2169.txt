코인봇 v2169

목적
- Strategy 462개 후보와 Review·시장상승 분류 후보를 같은 canonical snapshot으로 통일
- 구조가 덜 완성된 후보도 Review에서 사라지지 않게 보존
- 보존된 과거 S1의 옛 Trigger 시각을 신규 전달지연에서 제외
- 원천 Trigger→전략감지와 전략감지→S1 저장을 분리
- 준비된 WAIT_TRIGGER 계약을 전체 cycle 전에 재확인하고, 현재 전체계약이 ENTRY_READY인 경우에만 기존 S1 hold로 즉시 전달

변경하지 않음
- 구조·상승예측·Trigger·Invalid·T1 수치
- Paper 비용·RR·청산계약
- 기존 OPEN/CLOSED/decision/exact 원장
- 자동매수 OFF

상태
- 로컬 검수 PASS
- 서버 적용·실측 CHECK
