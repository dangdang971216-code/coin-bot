# v1090 운영 지도 정확도 최종마감

## 변경
- Main v2.13.1078
- Guard v2.5.144
- 지도 명령 등록 오탐 제거
- active hash·marker·내부 VERSION/BUILD runtime source 증명
- deleted-open FD·inode·실제 점유 byte 표시
- 장부 writer 증거 단계 분리
- phase 중복 표시 제거
- 현재 history event 표시
- AST cache cold/partial/warm 및 next-cycle readiness 표시

## 변경하지 않음
- Strategy, Risk, Paper, Review 및 주변 worker
- trigger, invalid, target, RR, spread, slippage
- OPEN/CLOSED/decision/exact 원장 계약
- 자동매수 OFF

## 적용 후 검수
1. 가드봇: `/gops_refresh` `/gworker_state`
2. 메인봇: `/ops_map` `/code_map` `/system_map` `/resource_map` `/ledger_map` `/ops_diff` `/ops_anomaly` `/ops_history` `/ops_focus` `/commands` `/errorlog`
3. Paper봇: `/pstatus` `/perror`

## DONE 기준
- snapshot writer 1개, 동일 snapshot/digest
- 지도 명령 canonical 등록 9/9
- registry false positive 0
- runtime source·marker drift 분리
- phase 중복 0
- deleted-open 실제 점유 표시
- writer evidence tier 표시
- current history 1건 이상
- next-cache readiness PASS
- 신규 실행 오류 0
- 전략·매매·핵심원장 변경 0
