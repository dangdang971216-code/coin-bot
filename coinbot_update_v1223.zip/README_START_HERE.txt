코인봇 v1223 · v1211↔현재 구조선 비교감사 source exact reader 수리

- 실제 매매전략 변경 없음.
- Guard만 2.5.220으로 변경.
- Strategy 1.051 / Main 1143 / Paper 1.064 유지.
- 자동매수 OFF.
- 먼저 /gupgrade_bundle 단독 실행 후 새 완료 cycle에서 /gstructure_pairing_audit 실행.
