#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import pathlib
import sys
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def main() -> None:
    g = load('guard_v1223_test', ROOT / 'backga_guard_bot_v2_5_220.py')
    shadow = {
        'source_exact': True, 'complete': True,
        'trigger': {'rounded_price': 103.0, 'tf': '15m'},
        'invalid': {'rounded_price': 98.0, 'tf': '30m'},
        'target': {'rounded_price': 112.0, 'tf': '4h', 'role': 'major'},
    }
    plan = {
        'trigger': {'rounded_price': 100.5, 'tf': '15m'},
        'invalid': {'rounded_price': 97.0, 'tf': '1h'},
        'target': {'rounded_price': 101.0, 'tf': '30m'},
        'target_mode_v1212': 'nearest_actual_resistance',
        'cost_inputs': {'spread_pct': 0.1, 'slippage_pct': 0.1, 'fee_pct': 0.2, 'estimated_roundtrip_cost_pct': 0.5},
    }
    with tempfile.TemporaryDirectory() as td:
        d = pathlib.Path(td)
        g.BOT_DIR = d
        rows = []
        for i in range(30):
            rows.append({
                'ticker': f'T{i}', 's_stage': 'S2',
                'candidate_pipeline_cycle_id_v1150': 'cycle-exact',
                'v1211_structure_shadow_v1222': shadow,
                'dynamic_structure_plan_v1212': plan,
            })
        candidate = d / g.S1_ZERO_AUDIT_CANDIDATES_V1214
        candidate.write_text('\n'.join(json.dumps(x, separators=(',', ':')) for x in rows) + '\n', encoding='utf-8')
        writer = {
            'result': 'OK',
            'candidate_last_commit_id_v1026': 'candidate-exact',
            'candidate_snapshot_scope': {
                'schema': 'strategy_candidate_snapshot_scope_v1143',
                'pipeline_cycle_id_v1150': 'cycle-exact',
                'pipeline_cycle_id_consistent_v1150': True,
                'complete_snapshot': True,
                'atomic_replace': True,
                'rows_written': 30,
                'output_bytes': candidate.stat().st_size,
                'commit_id': 'candidate-exact',
            },
            # A stale/advisory legacy-looking scope must not override canonical scope.
            'current_scope': {'rows_written': 29, 'pipeline_cycle_id_v1150': 'wrong-cycle'},
        }
        (d / g.S1_ZERO_AUDIT_WRITER_STATUS_V1214).write_text(json.dumps(writer), encoding='utf-8')
        # Deliberately mismatched latest Gate status: v1223 must not bind the
        # committed candidate snapshot to this non-commit-scoped file.
        (d / g.S1_ZERO_AUDIT_GATE_STATUS_V1214).write_text(json.dumps({'rows': 31, 'pass_s1': 1, 'recheck_s2': 30, 'observe_s3': 0}), encoding='utf-8')
        report = g.collect_structure_pairing_compare_audit_v1222()
        src = report['source']
        assert report['verdict'] == 'PROVEN_TARGET_SELECTION_SHRINK', report
        assert src['same_rows'] is True
        assert src['same_stage'] is True
        assert src['same_cycle'] is True
        assert src['writer_exact_v1223'] is True
        assert src['writer_scope_schema'] == 'strategy_candidate_snapshot_scope_v1143'
        assert src['gate_status_not_used_for_commit_binding_v1223'] is True
        assert src['shadow_exact_rows'] == 30
        assert report['stage'] == {'total': 30, 's1': 0, 's2': 30, 's3': 0}
        assert report['v1211']['risk_reward']['median'] > 1.5
        assert report['current']['risk_reward']['median'] < 0.2

        # Wrong canonical writer scope must fail closed.
        writer['candidate_snapshot_scope']['pipeline_cycle_id_v1150'] = 'wrong-cycle'
        (d / g.S1_ZERO_AUDIT_WRITER_STATUS_V1214).write_text(json.dumps(writer), encoding='utf-8')
        report_bad = g.collect_structure_pairing_compare_audit_v1222()
        assert report_bad['verdict'] == 'CHECK_SOURCE_MISMATCH'
        assert report_bad['source']['writer_exact_v1223'] is False

    text = (ROOT / 'backga_guard_bot_v2_5_220.py').read_text(encoding='utf-8')
    assert "trial_writer.get('candidate_snapshot_scope')" in text
    assert "gate_status_not_used_for_commit_binding_v1223" in text
    print('PASS v1223 canonical candidate_snapshot_scope binding, gate race exclusion, fail-closed mismatch')

if __name__ == '__main__':
    main()
