v1313: 7-day active/cold archive disk reclaim. Apply with /gupgrade_bundle. Then /grelease_verify, /gdisk_full, /gdisk_status, /gdeep_audit.
