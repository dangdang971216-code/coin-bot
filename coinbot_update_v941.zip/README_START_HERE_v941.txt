v941 디스크 반복증가 차단판. 먼저 docs 인수인계와 APPLY_AFTER_v941.txt를 확인. guard 변경이라 2단계 적용.
