#!/usr/bin/env python3
from __future__ import annotations

import ast
import importlib.util
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path
from typing import Any, Dict, List

HERE = Path(__file__).resolve().parent
OLD_SOURCE = Path('/mnt/data/v1190_full/coinbot_v1190_full/source/strategy_worker_v1.038.py')
NEW_SOURCE = HERE / 'strategy_worker_v1.039.py'
PROBE_SOURCE = HERE / 'runtime_phase_probe_v1190.py'


def load_module(path: Path, name: str, base_dir: Path):
    old = os.environ.get('TRADING_BOT_DIR')
    os.environ['TRADING_BOT_DIR'] = str(base_dir)
    sys.path.insert(0, str(path.parent))
    try:
        spec = importlib.util.spec_from_file_location(name, path)
        assert spec and spec.loader
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        try:
            sys.path.remove(str(path.parent))
        except ValueError:
            pass
        if old is None:
            os.environ.pop('TRADING_BOT_DIR', None)
        else:
            os.environ['TRADING_BOT_DIR'] = old


def synthetic_rows(count: int = 30) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for i in range(count):
        stage = ('S1', 'S2', 'S3')[i % 3]
        rows.append({
            'ticker': f'T{i:03d}',
            'market': f'KRW-T{i:03d}',
            's_stage': stage,
            'candidate_stage': stage,
            'candidate_grade': stage,
            'stage': stage,
            'grade': stage,
            'canonical_lane': 'base' if i % 2 else 'spike',
            'strategy_key': 'unit_strategy',
            'current_price': 1000.0 + i,
            'price': 1000.0 + i,
            'change_1m_pct': (-0.1, 0.2, 0.5)[i % 3],
            'buy_ratio': 0.60 + (i % 5) * 0.03,
            'buy_sustain_1m': 0.58 + (i % 5) * 0.02,
            'spread_pct': 0.12,
            'entry_slippage_est_pct': 0.05,
            'block_reasons': [f'reason-{i % 4}'],
            's_stage_reasons': [f'stage-reason-{i % 5}'],
            'risk_tags': [f'risk-{i % 3}'],
            'warning_tags': [f'warn-{i % 2}'],
            'structure_board_v812': {
                'stage': stage, 'setup_type': 'breakout_hold', 'role': 'structure_recheck',
                'stage_reasons': [f'structure-{i % 3}'], 'rr_ratio': 2.1,
            },
            'structure_board': {
                'stage': stage, 'setup_type': 'breakout_hold', 'role': 'structure_recheck',
                'stage_reasons': [f'structure-{i % 3}'], 'rr_ratio': 2.1,
            },
            'entry_context': {
                'ticker': f'T{i:03d}',
                'structure_levels': {'trigger_price': 1001 + i, 'invalid_price': 970 + i, 'target_price': 1080 + i},
                'debug': {'values': list(range(30)), 'text': 'x' * 1000},
            },
            'entry_diagnostics': {'nested': {'payload': 'y' * 1200, 'items': list(range(40))}},
            'source_snapshot': {'scanner': 0.1, 'feature': 0.2, 'orderflow': 0.3},
            'updated_ts': 1782981600.0 + i,
            'candidate_pipeline_cycle_id_v1150': 'cycle-unit',
        })
    return rows


def function_source(path: Path, name: str) -> str:
    tree = ast.parse(path.read_text(encoding='utf-8'))
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            return ast.dump(node, include_attributes=False)
    raise AssertionError(f'function not found: {name}')


class V1194StrategySpeedTests(unittest.TestCase):
    def test_wall_only_probe_preserves_return_and_never_constructs_cprofile(self):
        with tempfile.TemporaryDirectory() as td:
            probe = load_module(PROBE_SOURCE, 'probe_v1194_return', Path(td))
            original_profile = probe.cProfile.Profile
            probe._base_dir = lambda: Path(td)

            class ForbiddenProfile:
                def __init__(self, *args, **kwargs):
                    raise AssertionError('cProfile must be disabled for strategy normal cycles')

            probe.cProfile.Profile = ForbiddenProfile
            try:
                value = probe.profiled_call(
                    'strategy', 'cycle', 'strategy_worker_v1.039', lambda: {'ok': 7},
                    sample_interval_sec=300.0, publish_interval_sec=0.0, profile_enabled=False,
                )
                self.assertEqual(value, {'ok': 7})
                path = Path(td) / 'runtime' / 'runtime_phase_profile_strategy_v1190.json'
                obj = json.loads(path.read_text(encoding='utf-8'))
                scope = obj['scopes']['cycle']
                self.assertEqual(scope['profile_mode'], 'lightweight_wall_only')
                self.assertFalse(scope['cprofile_enabled'])
                self.assertEqual(scope['top_functions'], [])
            finally:
                probe.cProfile.Profile = original_profile

    def test_probe_no_publish_path_does_not_swallow_function_result(self):
        with tempfile.TemporaryDirectory() as td:
            probe = load_module(PROBE_SOURCE, 'probe_v1194_nopublish', Path(td))
            probe._base_dir = lambda: Path(td)
            first = probe.profiled_call('unit', 'scope', 'v1', lambda: 11, publish_interval_sec=9999, profile_enabled=False)
            second = probe.profiled_call('unit', 'scope', 'v1', lambda: 22, publish_interval_sec=9999, profile_enabled=False)
            self.assertEqual(first, 11)
            self.assertEqual(second, 22)

    def test_single_source_builder_matches_previous_separate_outputs(self):
        with tempfile.TemporaryDirectory() as td:
            module = load_module(NEW_SOURCE, 'strategy_v1194_views', Path(td))
            rows = synthetic_rows(36)
            captured: Dict[str, Any] = {}
            original_save = module.save_json
            try:
                module.save_json = lambda path, obj: captured.setdefault('lite', obj)
                module._v821_publish_candidate_lite_snapshot(rows, 1782981600.0)
            finally:
                module.save_json = original_save
            expected_compact = [module._v861_compact_row_for_latest(row) for row in rows]
            expected_encoded = [json.dumps(row, ensure_ascii=False, separators=(',', ':'), default=str).encode('utf-8') for row in expected_compact]
            compact, encoded, sizes, lite = module._v1194_build_candidate_publish_views(rows, 1782981600.0)
            self.assertEqual(compact, expected_compact)
            self.assertEqual(encoded, expected_encoded)
            self.assertEqual(sizes, [len(x) for x in expected_encoded])
            expected_lite = dict(captured['lite'])
            # Only schema policy/build metadata intentionally changes; all rows and counts must match.
            for key in ('policy', 'single_source_traversal_v1194'):
                expected_lite.pop(key, None)
                lite.pop(key, None)
            self.assertEqual(lite, expected_lite)

    def test_lite_view_failure_cannot_block_canonical_candidate_build(self):
        with tempfile.TemporaryDirectory() as td:
            module = load_module(NEW_SOURCE, 'strategy_v1194_nonblock', Path(td))
            rows = synthetic_rows(8)
            original = module._v821_compact_candidate_row
            module._v821_compact_candidate_row = lambda row: (_ for _ in ()).throw(RuntimeError('display-only failure'))
            try:
                compact, encoded, sizes, lite = module._v1194_build_candidate_publish_views(rows, 1782981600.0)
            finally:
                module._v821_compact_candidate_row = original
            self.assertEqual(len(compact), len(rows))
            self.assertEqual(len(encoded), len(rows))
            self.assertEqual(len(sizes), len(rows))
            self.assertEqual(lite, {})

    def test_summary_no_longer_duplicates_large_candidate_payload(self):
        with tempfile.TemporaryDirectory() as td:
            module = load_module(NEW_SOURCE, 'strategy_v1194_summary', Path(td))
            row = synthetic_rows(1)[0]
            row['entry_context']['huge'] = 'z' * 500_000
            sample = module._v1194_summary_sample_row(row)
            top = module._v1194_summary_top_candidate_row(row)
            self.assertNotEqual(sample, top)
            self.assertNotIn('entry_context', sample)
            self.assertNotIn('entry_context', top)
            self.assertLess(len(json.dumps(sample, ensure_ascii=False).encode('utf-8')), 4096)
            self.assertLess(len(json.dumps(top, ensure_ascii=False).encode('utf-8')), 8192)

    def test_strategy_and_exit_contract_functions_are_unchanged(self):
        protected = (
            'apply_swing_entry_gate__v1177_current_cycle',
            '_v1177_current_cycle_occurrence',
            '_v1180_apply_execution_entry_plan_core',
            'seal_canonical_candidate_keys',
            'write_s1_hold_cache',
            '_v732_reseal_common_uprising_promotions__v1115',
        )
        for name in protected:
            self.assertEqual(function_source(OLD_SOURCE, name), function_source(NEW_SOURCE, name), name)

    def test_final_version_and_profile_opt_in(self):
        with tempfile.TemporaryDirectory() as td:
            old = os.environ.pop('COINBOT_STRATEGY_DEEP_CPROFILE', None)
            try:
                module = load_module(NEW_SOURCE, 'strategy_v1194_version', Path(td))
                self.assertEqual(module.VERSION, 'strategy_worker_v1.039')
                self.assertEqual(module.BUILD_LABEL, 'v1194_strategy_light_profile_single_pass_publish_2026-07-02')
                self.assertTrue(getattr(module.run_once, '_v1190_profile_wrapped', False))
            finally:
                if old is not None:
                    os.environ['COINBOT_STRATEGY_DEEP_CPROFILE'] = old


if __name__ == '__main__':
    unittest.main(verbosity=2)
