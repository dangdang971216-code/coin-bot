#!/usr/bin/env python3
from __future__ import annotations
import cProfile, importlib.util, json, os, statistics, sys, tempfile, time
from pathlib import Path

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
os.environ['TRADING_BOT_DIR']=tempfile.mkdtemp(prefix='v1194_bench_')
spec=importlib.util.spec_from_file_location('st1194',HERE/'strategy_worker_v1.039.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)

def rows(n=461):
 out=[]
 for i in range(n):
  st=('S1','S2','S3')[i%3]
  out.append({
   'ticker':f'T{i:04d}','market':f'KRW-T{i:04d}','s_stage':st,'candidate_stage':st,'candidate_grade':st,'stage':st,'grade':st,
   'canonical_lane':'spike' if i%2==0 else 'base','strategy_key':'bench','current_price':1000+i,'price':1000+i,
   'change_1m_pct':(-.1,.2,.5)[i%3],'buy_ratio':.65,'buy_sustain_1m':.63,'spread_pct':.13,'entry_slippage_est_pct':.04,
   'block_reasons':['reason'], 's_stage_reasons':['reason'], 'risk_tags':['risk'], 'warning_tags':['warn'],
   'structure_board_v812':{'stage':st,'setup_type':'breakout_hold','role':'structure_recheck','stage_reasons':['r'],'rr_ratio':2.0},
   'structure_board':{'stage':st,'setup_type':'breakout_hold','role':'structure_recheck','stage_reasons':['r'],'rr_ratio':2.0},
   'entry_context':{'structure_levels':{'trigger_price':1001+i,'invalid_price':970+i,'target_price':1080+i},'payload':'x'*3500,'items':list(range(80))},
   'entry_diagnostics':{'payload':'y'*2200,'items':list(range(50))},
   'source_snapshot':{'scanner':.1,'feature':.2,'orderflow':.3},'updated_ts':1782981600+i,
   'candidate_pipeline_cycle_id_v1150':'cycle-bench',
  })
 return out

R=rows()
orig_save=m.save_json
m.save_json=lambda *a,**k: None

def old_path():
 m._v821_publish_candidate_lite_snapshot(R,1782981600.0)
 compact=[m._v861_compact_row_for_latest(r) for r in R]
 encoded=[json.dumps(r,ensure_ascii=False,separators=(',',':'),default=str).encode() for r in compact]
 return sum(map(len,encoded))

def new_path():
 c,e,s,l=m._v1194_build_candidate_publish_views(R,1782981600.0)
 return sum(s)

def timing(fn, reps=3):
 vals=[]
 for _ in range(reps):
  t=time.perf_counter(); v=fn(); vals.append(time.perf_counter()-t)
 return {'median_sec':statistics.median(vals),'min_sec':min(vals),'max_sec':max(vals),'result':v}

old=timing(old_path,3)
new=timing(new_path,3)
plain=timing(new_path,2)
prof=[]
for _ in range(2):
 p=cProfile.Profile(); t=time.perf_counter(); v=p.runcall(new_path); prof.append(time.perf_counter()-t)
profiled={'median_sec':statistics.median(prof),'min_sec':min(prof),'max_sec':max(prof),'result':v}
old_summary=[m._v928_compact_runtime_row(x) for x in R[:8]]
old_summary_bytes=len(json.dumps({'sample':old_summary,'top_candidates':old_summary},ensure_ascii=False,default=str).encode())
new_sample=[m._v1194_summary_sample_row(x) for x in R[:8]]
new_top=[m._v1194_summary_top_candidate_row(x) for x in R[:8]]
new_summary_bytes=len(json.dumps({'sample':new_sample,'top_candidates':new_top},ensure_ascii=False,default=str).encode())
result={
 'rows':len(R),'old_separate_publish':old,'new_single_source_publish':new,
 'publish_speedup_x':round(old['median_sec']/new['median_sec'],3),
 'new_plain':plain,'new_under_cprofile':profiled,
 'cprofile_overhead_x':round(profiled['median_sec']/plain['median_sec'],3),
 'old_summary_bytes':old_summary_bytes,'new_summary_bytes':new_summary_bytes,
 'summary_reduction_pct':round((1-new_summary_bytes/old_summary_bytes)*100,2),
}
(HERE/'V1194_LOCAL_BENCHMARK.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2))
m.save_json=orig_save
