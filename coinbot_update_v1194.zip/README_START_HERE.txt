코인봇 업데이트 v1194
생성: 2026-07-02 18:07:35 KST

목적
- v1193에서 Paper가 9초대로 내려간 뒤 가장 느린 Strategy의 저장·계측 낭비를 수리한다.
- 전략 계산이나 후보 기준을 바꾸지 않고 정상 cycle에 붙은 무거운 cProfile 부하와 후보 출력 중복 직렬화만 제거한다.

변경
- Strategy strategy_worker_v1.038 -> strategy_worker_v1.039.
- Strategy 정상 cycle은 가벼운 wall-time만 기록하고 무거운 cProfile은 COINBOT_STRATEGY_DEEP_CPROFILE=1 명시 진단에서만 실행한다.
- Paper용 canonical 후보와 Main용 lite 후보를 원본 461개 한 번 순회로 만든다.
- hard-ceiling 검증에서 이미 만든 exact JSON bytes를 실제 파일 저장에 재사용한다.
- summary의 sample/top_candidates가 같은 큰 후보 원본을 중복 보관하지 않고 작은 표시값과 canonical 포인터만 보관한다.

변경하지 않음
- 구조판 3단계 계산은 입력 합류 전·후·최종 봉인 역할이 달라 이번 버전에서 삭제하지 않았다.
- 후보식·S1·rank·selector·중복차단·trigger·invalid·target·RR·청산계약.
- Paper v1.052, OPEN/CLOSED/decision 원장, 라이브 원장.
- 신규 차단 0 / 자동매수 OFF.

상태
- 로컬 PASS.
- 서버 미적용 CHECK_PENDING_DEPLOY.
- 서버 exact PID/hash와 다음 cycle 속도 전에는 DONE 금지.
