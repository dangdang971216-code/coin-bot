#!/usr/bin/env python3
from __future__ import annotations
import importlib.util, json, os, pathlib, sys, tempfile, time

ROOT=pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT=ROOT.parent
if str(PACKAGE_ROOT) not in sys.path: sys.path.insert(0,str(PACKAGE_ROOT))

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path); mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod; assert spec and spec.loader; spec.loader.exec_module(mod); return mod

def line(price,tf): return {'price':price,'rounded_price':price,'tf':tf,'source':f'test.{tf}'}

def candidate(ticker,strong=True,route='hot-rank 급등 재확인'):
    return {
        'ticker':ticker,'current_price':100.0,'s_stage':'S1','open_eligible':True,
        'strategy_label':route,'global_entry_score_v1212':70.0 if strong else 30.0,
        'price_reaction_pct':0.20 if strong else -0.20,
        'relative_strength_rank_pct_v1095':82.0 if strong else 25.0,
        'money_flow_score':76.0 if strong else 28.0,
        'buy_ratio':0.68 if strong else 0.25,'buy_sustain_1m':0.62 if strong else 0.20,
        'risk_reward_ratio':2.2,'target_room_pct':5.0,'spread_pct':0.10,
        'swing_entry_gate_v977':{'risk_reward':2.2,'target_room_pct':5.0,'spread_pct':0.10,'confirmed_slippage_pct':0.0,
            'structure_plan':{'trigger':line(100,'m5'),'invalid':line(97,'m30'),'target':line(105,'h2')}},
        'dynamic_structure_plan_v1212':{'trigger':line(100,'m5'),'invalid':line(97,'m30'),'target':line(105,'h2')},
        'hybrid_entry_shadow_pass_v1234':strong,'hybrid_entry_shadow_score_v1234':80 if strong else 25,
        'hybrid_entry_shadow_reason_v1234':'PASS' if strong else 'quality_confirmation_absent',
    }

def perf(i,strong=True,pnl=None):
    now=time.time()-max(0,40-i)*600
    if pnl is None: pnl=(1.2+0.03*i) if strong else (-1.6-0.02*i)
    target_ts=now+1800 if strong else None
    invalid_ts=None if strong else now+1200
    return {
        'ticker':f'H{i}','structure_contract_version':'structure_contract_v1231_zero_trigger_fail_closed',
        'entry_method':'hot-rank 급등 재확인' if strong else '코인품질 전체커버',
        'market_mode_at_open':'bull' if strong else 'sideways',
        'opened_at':now,'closed_at':now+2400,'hold_sec':2400,
        'net_pnl_pct':pnl,'pnl_pct':pnl,'mfe_pct':max(0.2,pnl+0.5 if pnl>0 else 0.1),'mae_pct':min(-0.2,pnl),
        'giveback_pct':0.3 if strong else 1.0,'exit_reason':'structure_target' if strong else 'structure_invalid',
        'target_first_touch_ts':target_ts,'invalid_first_touch_ts':invalid_ts,
        'trigger':line(100,'m5'),'invalid':line(97,'m30'),'target':line(105,'h2'),
        'actual_entry_rr':2.2,'target_distance_pct':5.0,'invalid_distance_pct':3.0,
        'price_reaction_pct':0.20 if strong else -0.20,'relative_strength_rank_pct':82.0 if strong else 25.0,
        'relative_strength':1.0 if strong else -1.0,'money_flow':76.0 if strong else 28.0,
        'buy_ratio':0.68 if strong else 0.25,'buy_sustain_1m':0.62 if strong else 0.20,
        'spread_pct':0.10,'paper_reference_cost_pct':0.0,'configured_fee_pct':0.10,
        'global_entry_score_v1212':75.0 if strong else 35.0,
    }

def main():
    review=load('review_v1235',PACKAGE_ROOT/'review_worker_v1.024.py')
    history=[perf(i,strong=(i%3!=0)) for i in range(45)]
    strong=candidate('STRONG',True); weak=candidate('WEAK',False,route='코인품질 전체커버')
    model_strong=review._v1235_estimate(strong,history,history,time.time())
    model_weak=review._v1235_estimate(weak,history,history,time.time())
    assert model_strong['neighbors']>0 and model_weak['neighbors']>0
    assert model_strong['conservative_ev_pct']>model_weak['conservative_ev_pct'],(model_strong,model_weak)
    assert model_strong['profile'] in {'fast_breakout','slow_trend','giveback_guard','volatile_structure','balanced'}
    assert {'3h','6h','12h'}<=set(model_strong['horizons'])
    assert 0<=model_strong['p_win']<=1 and 0<=model_strong['p_giveback']<=1
    with tempfile.TemporaryDirectory() as td:
        base=pathlib.Path(td)
        (base/'canonical_performance_snapshot_v987.json').write_text(json.dumps({'snapshot_id':'p1235','rows':history}),encoding='utf-8')
        out=review.update_version_score_review(base,[strong,weak])
        root=out['probability_policy_v1235']
        assert root['history_rows']==45 and root['candidate_rows']==2
        assert root['walk_forward']['prediction_rows']>=30
        assert root['invariants']['actual_rank_changed'] is False
        assert (base/'canonical_version_score_review_v1235.json').exists()
        assert (base/'version_score_review_state_v1235.json').exists()
        # Minimal canonical files for Main rendering.
        (base/'canonical_candidate_standard_v1181.json').write_text(json.dumps({'state':'NORMAL','easy_state':'test','delivery':{},'candidate':{},'structure':{},'structure_s1':{},'reason_accounting':{},'selection_contract_v1215':{},'contract_changes_since_v1211':{},'v1215_change_scope':{},'quality':{},'time':{},'performance':{},'contract':{},'scope':{},'missing':[]}),encoding='utf-8')
        (base/'ops_spine_snapshot_v1181.json').write_text(json.dumps({'overall_state':'NORMAL','current_cycle':{},'last_completed_cycle':{},'timing':{},'timing_path':{},'paper_funnel':{},'open_exit_monitor':{},'ledger_performance':{},'errors':{},'runtime_deploy':{},'resources':{},'commands_delivery':{},'artifact_chain':{},'storage_hygiene':{},'phase_profiles':{},'hotpath_optimization_v1211':{},'invariants':{},'strategy_gate_health_v1215':{},'evidence_groups':{},'problems':[]}),encoding='utf-8')
        os.environ['COINBOT_BASE_DIR']=td
        mainmod=load('main_v1235',PACKAGE_ROOT/'coinbot_main_v2_13_1146.py')
        text=mainmod.render_policy_score()
        assert '확률형 기대값 정책 검증' in text and '실제 후보순위·S1·Paper 진입·청산·기존 OPEN 변경 0' in text
        assert mainmod.BOT_VERSION=='수익형 v2.13.1146'
        assert 'policy_score' in mainmod.COMMANDS
    paper=load('paper_v1235',PACKAGE_ROOT/'paper_bot_v1.068.py')
    pos={'ticker':'STRONG','entry_price':100.0,'spread_pct':0.10,'strategy_label':'hot-rank 급등 재확인',
         'swing_entry_gate_v977':{'structure_plan':{'trigger':line(100,'m5'),'invalid':line(97,'m30'),'target':line(105,'h2')}}}
    shadow=paper.evaluate_policy_exit_shadow_v1235(pos,2.0,0.1,-0.1,{'fee_pct_roundtrip':0.10},{'profile':'fast_breakout','exit_policy':{'observation_grace_min':5,'no_progress_review_min':10,'profit_protect_arm_pct':0.4,'profit_floor_pct':0.03},'confidence':70})
    assert shadow['action']=='HOLD_PROFILE_GRACE' and shadow['actual_exit_changed'] is False
    protect=paper.evaluate_policy_exit_shadow_v1235(pos,20.0,0.8,0.0,{'fee_pct_roundtrip':0.10},{'profile':'giveback_guard','exit_policy':{'observation_grace_min':5,'no_progress_review_min':10,'profit_protect_arm_pct':0.35,'profit_floor_pct':0.03},'confidence':70})
    assert protect['action']=='CLOSE_PROFILE_PROTECT'
    assert paper.VERSION=='paper_bot_v1.068'
    print('PASS v1235 similarity probability EV, walk-forward policy competition, candidate exit profile shadow, Main view')

if __name__=='__main__': main()
