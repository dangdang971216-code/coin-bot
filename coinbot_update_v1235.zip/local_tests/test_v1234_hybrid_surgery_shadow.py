#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import json
import os
import pathlib
import sys
import tempfile
import time

ROOT = pathlib.Path(__file__).resolve().parent
PACKAGE_ROOT = ROOT.parent
if str(PACKAGE_ROOT) not in sys.path:
    sys.path.insert(0, str(PACKAGE_ROOT))

def load(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec and spec.loader
    spec.loader.exec_module(mod)
    return mod

def line(price: float, tf: str):
    return {'rounded_price': price, 'raw_price': price, 'price': price, 'tf': tf, 'source': f'test.{tf}'}

def candidate(ticker: str, price: float, *, strong: bool, cycle: str = 'cycle-a'):
    return {
        'ticker': ticker,
        'current_price': price,
        'candidate_key': f'{ticker}-{cycle}',
        'candidate_pipeline_cycle_id_v1150': cycle,
        'structure_contract_hash': f'{ticker}-same-structure',
        's_stage': 'S1', 'open_eligible': True,
        'hybrid_entry_shadow_pass_v1234': bool(strong),
        'hybrid_entry_shadow_score_v1234': 78.0 if strong else 22.0,
        'hybrid_entry_shadow_reason_v1234': 'PASS' if strong else 'quality_confirmation_absent',
        'risk_reward_ratio': 2.0, 'target_room_pct': 4.0, 'spread_pct': 0.10,
        'price_reaction_pct': 0.10 if strong else -0.10,
        'relative_strength_rank_pct_v1095': 80.0 if strong else 20.0,
        'money_flow_score': 70.0 if strong else 20.0,
        'buy_ratio': 0.60 if strong else 0.20,
        'buy_sustain_1m': 0.55 if strong else 0.10,
        'swing_entry_gate_v977': {
            'risk_reward': 2.0, 'target_room_pct': 4.0, 'spread_pct': 0.10,
            'confirmed_slippage_pct': 0.0,
        },
        'dynamic_structure_plan_v1212': {
            'structure_contract_hash': f'{ticker}-same-structure',
            'trigger': line(100.0, 'm15'),
            'invalid': line(96.0, 'm30'),
            'target': line(108.0, 'h2'),
            'pairing_contract_v1229': {
                'invalid_candidates': 2, 'target_candidates': 2, 'passing': 0,
                'cost_complete': True,
            },
        },
        'v1211_structure_shadow_v1222': {
            'source_exact': True, 'complete': True,
            'trigger': line(100.0, 'm15'), 'invalid': line(95.0, 'h1'), 'target': line(110.0, 'h4'),
        },
    }

def perf_row(ticker: str, pnl: float, *, strong: bool, hold_sec: float, mfe: float, reason: str = 'swing_dynamic_momentum_decay'):
    now = time.time()
    return {
        'ticker': ticker,
        'structure_contract_version': 'structure_contract_v1231_zero_trigger_fail_closed',
        'net_pnl_pct': pnl, 'pnl_pct': pnl, 'mfe_pct': mfe, 'mae_pct': min(pnl, -0.2),
        'giveback_pct': max(0.0, mfe-pnl), 'hold_sec': hold_sec,
        'exit_reason': reason, 'closed_at': now, 'opened_at': now-hold_sec,
        'trigger': {'tf':'m15'},
        'price_reaction_pct': 0.10 if strong else -0.10,
        'relative_strength_rank_pct': 80.0 if strong else 20.0,
        'relative_strength': 1.0 if strong else -1.0,
        'money_flow': 70.0 if strong else 20.0,
        'buy_ratio': 0.60 if strong else 0.20,
        'buy_sustain_1m': 0.55 if strong else 0.10,
        'actual_entry_rr': 2.0, 'target_distance_pct': 4.0,
        'spread_pct': 0.10, 'paper_reference_cost_pct': 0.0,
        'configured_fee_pct': 0.10,
    }

def main() -> None:
    strategy = load('strategy_v1234', PACKAGE_ROOT/'strategy_worker_v1.059.py')
    strong = candidate('STRONG', 99.0, strong=True)
    weak = candidate('WEAK', 99.0, strong=False)
    s1 = strategy._v1234_hybrid_quality_shadow(strong)
    s2 = strategy._v1234_hybrid_quality_shadow(weak)
    assert s1['would_pass'] is True and s1['confirmation_passes'] >= 1
    assert s2['would_pass'] is False and 'quality_confirmation_absent' in s2['block_reasons']
    assert strong['s_stage']=='S1' and strong['open_eligible'] is True
    assert strategy.VERSION=='strategy_worker_v1.059'
    # Shadow scalars must survive the canonical compact writer without reopening
    # the v1229/v1230 row-size failure.
    transport = load('transport_helpers_v1234', ROOT/'test_v1230_pairing_transport_runtime_margin.py')
    transport.install_material(strategy)
    plan=strategy._v925_current_actual_plan({'ticker':'TEST','current_price':100.0})
    src=transport.source(plan,15500,'selection_contract_v1234_shadow_only')
    src.update({
        'hybrid_entry_shadow_pass_v1234':False,'hybrid_entry_shadow_score_v1234':22.0,
        'hybrid_entry_shadow_known_axes_v1234':4,'hybrid_entry_shadow_confirmations_v1234':0,
        'hybrid_entry_shadow_reason_v1234':'quality_confirmation_absent',
    })
    compact=strategy._v861_compact_row_for_latest(src)
    encoded=json.dumps(compact,ensure_ascii=False,separators=(',',':'),default=str).encode()
    assert len(encoded)<=strategy.V1020_ROW_HARD_CEILING_BYTES-600, len(encoded)
    assert compact['hybrid_entry_shadow_pass_v1234'] is False

    paper = load('paper_v1234', PACKAGE_ROOT/'paper_bot_v1.067.py')
    pos={'ticker':'CAP','entry_price':100.0,'spread_pct':0.10,
         'swing_entry_gate_v977':{'structure_plan':{'trigger':{'tf':'m15'}}}}
    cap=paper.evaluate_hybrid_exit_shadow_v1234(pos,2.1,0.38,-0.04,{'fee_pct_roundtrip':0.10})
    assert cap['variants']['combined']=='HOLD_GRACE'
    wiken=paper.evaluate_hybrid_exit_shadow_v1234(pos,547.2,0.78,-0.28,{'fee_pct_roundtrip':0.10})
    assert wiken['variants']['combined']=='CLOSE_PROTECT_FLOOR'
    assert cap['actual_exit_changed'] is False and wiken['actual_exit_changed'] is False
    assert paper.VERSION=='paper_bot_v1.067'

    review = load('review_v1234', PACKAGE_ROOT/'review_worker_v1.023.py')
    with tempfile.TemporaryDirectory() as td:
        base=pathlib.Path(td)
        perf={
            'snapshot_id':'perf-v1234-test',
            'rows':[
                perf_row('PASS_WIN',1.0,strong=True,hold_sec=1200,mfe=1.2),
                perf_row('BLOCK_LOSS',-2.0,strong=False,hold_sec=120,mfe=0.38),
                perf_row('PASS_GIVEBACK',-0.2,strong=True,hold_sec=3600,mfe=0.8),
                {'ticker':'OLD','structure_contract_version':'structure_contract_v1211_legacy','net_pnl_pct':0.5,'mfe_pct':1.0,'mae_pct':-0.2,'hold_sec':1000},
            ],
        }
        (base/'canonical_performance_snapshot_v987.json').write_text(json.dumps(perf),encoding='utf-8')
        rows=[candidate('AAA',99.0,strong=True,cycle='cycle-1'), candidate('BBB',99.0,strong=False,cycle='cycle-1')]
        out1=review.update_version_score_review(base,rows)
        hybrid=out1['hybrid_surgery_v1234']
        assert hybrid['entry_replay']['hybrid_would_pass']==2
        assert hybrid['entry_replay']['hybrid_would_block']==1
        assert hybrid['entry_replay']['actual_outcomes_if_hybrid_block']['total_pct']==-2.0
        assert hybrid['exit_replay']['early_timeframe_conflict']>=1
        assert hybrid['exit_replay']['profit_to_loss_gap']>=1
        assert hybrid['current_generation']['current_s1_hybrid_block']==1
        assert out1['semantic_occurrence_dedupe_v1234'] is True
        # Same structure in a new Strategy cycle must not create duplicate missed events.
        rows2=[candidate('AAA',99.1,strong=True,cycle='cycle-2'), candidate('BBB',99.2,strong=False,cycle='cycle-2')]
        out2=review.update_version_score_review(base,rows2)
        assert out2['missed_current_structure']['tracked_total']==out1['missed_current_structure']['tracked_total']
        assert (base/'version_score_review_state_v1234.json').exists()
        assert (base/'canonical_version_score_review_v1234.json').exists()

        (base/'canonical_candidate_standard_v1181.json').write_text(json.dumps({
            'state':'NORMAL','easy_state':'test','delivery':{},'candidate':{},'structure':{},'structure_s1':{},
            'reason_accounting':{},'selection_contract_v1215':{},'contract_changes_since_v1211':{},
            'v1215_change_scope':{},'quality':{},'time':{},'performance':{},'contract':{},'scope':{},'missing':[],
        }),encoding='utf-8')
        (base/'ops_spine_snapshot_v1181.json').write_text(json.dumps({
            'overall_state':'NORMAL','current_cycle':{},'last_completed_cycle':{},'timing':{},'timing_path':{},
            'paper_funnel':{},'open_exit_monitor':{},'ledger_performance':{},'errors':{},'runtime_deploy':{},
            'resources':{},'commands_delivery':{},'artifact_chain':{},'storage_hygiene':{},'phase_profiles':{},
            'hotpath_optimization_v1211':{},'invariants':{},'strategy_gate_health_v1215':{},'evidence_groups':{},'problems':[],
        }),encoding='utf-8')
        os.environ['COINBOT_BASE_DIR']=td
        mainmod=load('main_v1234', PACKAGE_ROOT/'coinbot_main_v2_13_1145.py')
        text=mainmod.render_hybrid_score()
        assert '혼합형 수술 검증' in text
        assert '후보선발·청산·기존 OPEN·자동매수 변경 0' in text
        assert '혼합형이면 차단 1개' in text
        candidate_text=mainmod.render_candidate_standard()
        assert '[v1234 혼합형 수술 · 쉐도우 전용]' in candidate_text
        # flow map may be source-empty in the isolated test, but the full renderer
        # must still carry the v1234 section when a snapshot exists on server.
        assert '[17. v1234 혼합형 수술 · 쉐도우 전용]' in mainmod.render_flow_map_full() or '운영지도 canonical snapshot 대기' in mainmod.render_flow_map_full()
        assert mainmod.BOT_VERSION=='수익형 v2.13.1145'

    assert review.VERSION=='review_worker_v1.023'
    print('PASS v1234 hybrid entry/exit shadow, historical exact split, semantic dedupe, main presentation')

if __name__=='__main__':
    main()
