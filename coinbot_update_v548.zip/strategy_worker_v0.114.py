#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations
import json, os, time, math, traceback, urllib.request
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
import re
from collections import Counter
BASE_DIR = Path(os.getenv("TRADING_BOT_DIR", "/home/dangdang971216/trading_bot"))
def now_ts() -> float: return time.time()
def now_text(ts: Optional[float]=None) -> str: return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(ts or now_ts()))
def fnum(*vals: Any, default: float=0.0) -> float:
    for v in vals:
        try:
            if v is None or v == "": continue
            return float(str(v).replace(",", "").replace("%", ""))
        except Exception: continue
    return default
def load_json(path: Path, default: Any=None) -> Any:
    try:
        if not path.exists(): return default
        return json.loads(path.read_text(encoding="utf-8", errors="ignore"))
    except Exception: return default
def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str), encoding="utf-8")
    os.replace(tmp, path)
def append_jsonl(path: Path, obj: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
def write_jsonl_atomic(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False, separators=(",", ":"), default=str)+"\n")
    os.replace(tmp, path)
def read_jsonl(path: Path, max_lines: int=1000) -> List[Dict[str, Any]]:
    if not path.exists(): return []
    try:
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        if max_lines and len(lines) > max_lines: lines = lines[-max_lines:]
        out=[]
        for ln in lines:
            try:
                if ln.strip():
                    o=json.loads(ln)
                    if isinstance(o,dict): out.append(o)
            except Exception: pass
        return out
    except Exception: return []
def read_fresh_jsonl_by_ttl(path: Path, ttl_sec: float) -> List[Dict[str, Any]]:
    """TTL 기준으로 fresh 후보만 읽는다. 개수 제한으로 후보를 자르지 않는다.

    기존 latest/후보 복구 경로의 max_lines=120/500 및 [:40] 고정 상한을
    제거하기 위한 단일 읽기 경로다. 서버 보호는 후보 수 제한이 아니라 TTL로 처리한다.
    """
    if not path.exists():
        return []
    try:
        nowv = now_ts()
        lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
        out: List[Dict[str, Any]] = []
        for ln in reversed(lines):
            try:
                if not ln.strip():
                    continue
                o = json.loads(ln)
                if not isinstance(o, dict):
                    continue
                exp = fnum(o.get("expires_at"), default=0.0)
                ts = _event_created_ts(o)
                fresh = (exp >= nowv) if exp > 0 else (ts > 0 and (nowv - ts) <= ttl_sec)
                if fresh:
                    out.append(o)
                    continue
                # 파일은 시간순 append라, TTL의 여유구간보다 오래된 항목을 만나면 더 과거는 볼 필요 없다.
                if ts > 0 and (nowv - ts) > max(ttl_sec * 3.0, ttl_sec + 60.0):
                    break
            except Exception:
                continue
        out.reverse()
        return out
    except Exception:
        return []

def append_error(path: Path, where: str, exc: BaseException) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(f"[{now_text()}] {where}: {exc.__class__.__name__}: {exc}\n")
            f.write(traceback.format_exc()[-1500:]+"\n")
    except Exception: pass
def ticker_norm(x: Any) -> str:
    t = str(x or "").strip().upper().replace("/", "-").replace("_", "-")
    parts=[p for p in t.split("-") if p]
    if len(parts)>=2:
        non=[p for p in parts if p != "KRW"]
        t = non[-1] if non else parts[-1]
    if t.endswith("KRW") and len(t)>3: t=t[:-3]
    return t.strip().upper()
def pct(a: float, b: float) -> float: return ((a-b)/b*100.0) if b else 0.0
def age_sec(path: Path) -> float:
    try: return max(0.0, now_ts()-path.stat().st_mtime)
    except Exception: return 999999.0
def map_rows(obj: Any) -> Dict[str, Dict[str, Any]]:
    if isinstance(obj, dict) and isinstance(obj.get("rows"), list): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("rows"), dict): obj = obj.get("rows")
    elif isinstance(obj, dict) and isinstance(obj.get("cache"), dict): obj = obj.get("cache")
    out: Dict[str, Dict[str, Any]] = {}
    if isinstance(obj, list):
        for r in obj:
            if isinstance(r, dict):
                t=ticker_norm(r.get("ticker") or r.get("symbol") or r.get("market"))
                if t: out[t]=r
    elif isinstance(obj, dict):
        for k,v in obj.items():
            t=ticker_norm(k)
            if t and isinstance(v, dict):
                vv=dict(v); vv.setdefault("ticker", t); out[t]=vv
    return out

def feature_rows(obj: Any) -> List[Dict[str, Any]]:
    """feature_worker cache를 한 본선으로 읽는다.
    rows/list/cache/dict 형태를 모두 map_rows로 표준화한다.
    전략 조건 수치는 변경하지 않는다.
    """
    return list(map_rows(obj).values())

INTERVAL_SEC=float(os.getenv("STRATEGY_WORKER_INTERVAL_SEC","2.0"))
STATUS=BASE_DIR/"clean_strategy_worker_status.json"; ERROR=BASE_DIR/"clean_strategy_worker_error.log"
FEATURE=BASE_DIR/"clean_feature_cache.json"; ORDERFLOW=BASE_DIR/"clean_orderflow_summary_cache.json"; REGIME=BASE_DIR/"clean_market_regime_cache.json"; RISK=BASE_DIR/"clean_risk_filter_cache.json"
PAPER=BASE_DIR/"paper_candidates.jsonl"; PAPER_LATEST=BASE_DIR/"paper_candidates_latest.jsonl"; SUMMARY=BASE_DIR/"clean_strategy_s_summary.json"; REJECT=BASE_DIR/"clean_strategy_s_reject_summary.json"; HANDOFF=BASE_DIR/"clean_strategy_paper_handoff_status.json"; WS_TARGETS=BASE_DIR/"clean_ws_targets.json"; MICRO_TARGETS=BASE_DIR/"clean_micro_targets.json"; MICRO_URGENT=BASE_DIR/"clean_micro_urgent_targets.json"; PRIORITY_REQ=BASE_DIR/"clean_strategy_priority_requests.json"; TARGET_ROUTER_QUEUE=BASE_DIR/"clean_target_router_queue.json"; MISSED_REVIEW_QUEUE=BASE_DIR/"clean_missed_review_queue.json"; SCANNER_HOT=BASE_DIR/"clean_scanner_hot_rank_cache.json"
CANDIDATE_TTL_SEC=float(os.getenv("STRATEGY_PAPER_CANDIDATE_TTL_SEC","120"))
STRATEGIES={"money_reaccel_s":"돈흐름 재가속 S","leader_momentum_s":"주도추세 지속 S","breakout_early_s":"돌파 초입 S","sweep_vwap_recovery_s":"저점 VWAP 회복 S","surge_rebreak_s":"급등 후 재돌파 S","leader_flow_adaptive_hold_s":"주도흐름 유동보유 S"}
MAIN_DEPLOY_VERSION = "v2.13.452"
MAIN_BOT_VERSION = "수익형 v2.13.452"
def write_status(state:str, **extra:Any)->None:
    # v434: cycle 시작부의 evaluated=0/target=0 상태가 마지막 정상값을 지우지 않게
    # 중앙 status 저장부에서 구 0 초기화 경로를 제거한다.
    prev: Dict[str, Any] = {}
    phase = str(extra.get("phase") or "")
    is_cycle_start_zero = (
        state == "running"
        and phase.startswith("evaluating")
        and int(float(extra.get("evaluated") or 0)) <= 0
        and int(float(extra.get("target_count") or 0)) <= 0
    )
    if is_cycle_start_zero:
        try:
            prev = load_json(STATUS, {}) or {}
        except Exception:
            prev = {}
    obj={"version":VERSION,"state":state,"pid":os.getpid(),"updated_ts":now_ts(),"updated_text":now_text(),"last_error":""}
    obj.update(extra)
    if is_cycle_start_zero and prev:
        for key in ("evaluated", "target_count", "s_count", "paper_latest_count", "s1_count", "s2_count", "s3_count", "router_target_count", "router_queue_count", "router_backlog_count", "last_sec"):
            if key in prev and (obj.get(key) in (None, "", 0, "0", "-")):
                obj[key] = prev.get(key)
        obj["status_route_schema"] = "strategy_status_v435_no_zero_cycle_start_no_40_cap"
        obj["status_route_note"] = "v436: S1/S2/S3 단순화 + cycle 시작 0 초기화 방지 + 후보 latest 고정 40개 제한 제거"
    if state == "error" and "error" in extra:
        obj["last_error"] = str(extra.get("error") or "")[:240]
    save_json(STATUS,obj)

def _event_created_ts(ev: Dict[str, Any]) -> float:
    return fnum(ev.get("created_at"), ev.get("candidate_created_at"), ev.get("source_created_at"), ev.get("detected_ts"), ev.get("event_ts"), ev.get("ts"), ev.get("timestamp"), default=0.0)

# v533 removed legacy unused function: _normalize_paper_event

def _paper_event_fresh(ev: Dict[str, Any], nowv: Optional[float] = None) -> bool:
    nowv = nowv or now_ts()
    exp = fnum(ev.get("expires_at"), default=0.0)
    ts = _event_created_ts(ev)
    if exp > 0:
        return exp >= nowv
    return ts > 0 and (nowv - ts) <= CANDIDATE_TTL_SEC

def _paper_dedupe_key(ev: Dict[str, Any]) -> str:
    t = ticker_norm(ev.get("ticker") or ev.get("market") or ev.get("symbol"))
    sk = str(ev.get("strategy_key") or ev.get("strategy_bucket_primary") or "strategy_s")
    return f"{t}:{sk}"

# v510: legacy persist_paper_handoff removed from runtime. paper_candidates_latest is written once by _v510_publish.

def risk_bad(t:str)->List[str]:
    r=load_json(RISK,{}) or {}; cd=(r.get("cooldown") or {}) if isinstance(r,dict) else {}
    out=[]
    if t in cd: out.append("최근반복손실/하드손실")
    if t in set(r.get("open_tickers",[]) if isinstance(r,dict) else []): out.append("이미OPEN중")
    return out
def common_hard(row:Dict[str,Any], of:Dict[str,Any])->List[str]:
    """cheap/기본 차단만 본다.
    WS/micro 부족은 여기서 붙이지 않는다.
    v0.8: 붙일 필요도 없는 후보까지 정보부족으로 보이는 문제를 막기 위해
    정보부족은 cheap gate 통과 후보에게만 별도 부여한다.
    """
    hard=[]; t=ticker_norm(row.get("ticker")); hard+=risk_bad(t)
    if row.get("major_watch"): hard.append("대형주는시장참고")
    if bool(of.get("micro_fresh")):
        spread=fnum(of.get("spread_pct"),default=0)
        buy=fnum(of.get("buy_ratio"),default=0)
        if spread>0.28: hard.append(f"스프레드넓음 {spread:.2f}%")
        if buy and buy<0.58: hard.append(f"매수체결약함 {buy:.2f}")
        if of.get("sell_pressure"): hard.append("매도벽/매도체결압력")
    if fnum(row.get("turnover_24h"))<250_000_000: hard.append("거래대금부족")
    if row.get("long_upper_wick"): hard.append("윗꼬리위험")
    if fnum(row.get("day_pos_pct"),default=50)>94 and fnum(row.get("change_5m"))<0.2: hard.append("고점끝물위험")
    return hard[:8]

def orderflow_info_bad(of:Dict[str,Any])->List[str]:
    """v0.9: strategy는 WS 단독 fresh가 아니라 표준 시세(quote_fresh)를 본다.
    quote_fresh는 orderflow_worker가 WS 또는 scanner/feature REST 현재가로 만든 canonical 시세다.
    micro는 호가·체결 판단 재료라 별도로 필요하다.
    """
    info=[]
    if not bool(of.get("quote_fresh") or of.get("ws_fresh")):
        info.append("시세정보보강대기")
    if not bool(of.get("micro_fresh")):
        info.append("micro정보보강대기")
    return info[:4]
def eval_money(r,o):
    no=[]
    if fnum(r.get("change_3m"))<0.25 or fnum(r.get("change_5m"))<0.35: no.append("3/5분재가속부족")
    if fnum(r.get("vwap_gap_pct"))<-0.05 or fnum(r.get("ema5_gap_pct"))<-0.08: no.append("VWAP/EMA유지부족")
    if not r.get("volume_expanding"): no.append("캔들거래량확장부족")
    # micro가 fresh일 때만 매수체결비를 전략 실패로 본다. fresh가 없으면 정보보강대기로 분리한다.
    if o.get("micro_fresh") and fnum(o.get("buy_ratio"))<0.65: no.append("매수체결우세부족")
    return (not no, ["돈흐름재가속","3/5분재가속","VWAP/EMA유지","체결우세"], no)
def eval_leader(r,o):
    no=[]
    if fnum(r.get("change_15m"))<0.65 or fnum(r.get("change_30m"))<0.65: no.append("15/30분주도부족")
    if fnum(r.get("relative_strength_pct"))<0.3: no.append("시장대비강도부족")
    if fnum(r.get("vwap_gap_pct"))<0 or fnum(r.get("ema5_gap_pct"))<0: no.append("VWAP/EMA위치부족")
    if r.get("market_mode") == "약함": no.append("장세약함")
    return (not no, ["15/30분주도","시장대비강함","VWAP/EMA위"], no)
def eval_breakout(r,o):
    no=[]
    if not r.get("breakout_hint"): no.append("돌파캔들미확인")
    if fnum(r.get("recent_high_gap_pct"))<-0.15: no.append("돌파후유지부족")
    if fnum(r.get("change_15m"))>5.0 and not r.get("volume_expanding"): no.append("끝물추격위험")
    return (not no, ["돌파초입","거래량확장","고점돌파유지"], no)
def eval_sweep(r,o):
    no=[]
    if not r.get("sweep_reclaim_hint"): no.append("저점쓸림회복미확인")
    if fnum(r.get("vwap_gap_pct"))<-0.05: no.append("VWAP회복부족")
    if fnum(r.get("recent_low_rebound_pct"))<0.4: no.append("저점방어반등부족")
    return (not no, ["저점이탈실패","VWAP회복","매수회복"], no)
def eval_surge(r,o):
    no=[]
    if fnum(r.get("change_15m"))<1.2: no.append("1차상승부족")
    if fnum(r.get("change_3m"))<0.15: no.append("재돌파시도부족")
    if fnum(r.get("recent_high_gap_pct"))<-0.25: no.append("고점재접근부족")
    if r.get("long_upper_wick"): no.append("윗꼬리반락위험")
    return (not no, ["급등후재돌파","얕은눌림","체결재상승"], no)


def eval_adaptive_hold(r,o):
    """v0.19/v367 주도흐름 유동보유 전략.
    시간 고정이 아니라 0~5분 검증, 5~30분 확인, 30~120분 확장으로 나눠 본다.
    """
    no=[]
    ch1=fnum(r.get("change_1m"), r.get("price_change_1m"), default=0.0)
    ch3=fnum(r.get("change_3m"), r.get("price_change_3m"), default=0.0)
    ch5=fnum(r.get("change_5m"), r.get("price_change_5m"), default=0.0)
    ch15=fnum(r.get("change_15m"), r.get("price_change_15m"), default=0.0)
    ch30=fnum(r.get("change_30m"), r.get("price_change_30m"), default=0.0)
    vwap=fnum(r.get("vwap_gap_pct"), default=-9.0)
    ema=fnum(r.get("ema5_gap_pct"), r.get("ma5_gap_pct"), default=-9.0)
    rel=fnum(r.get("relative_strength_pct"), r.get("relative_strength"), default=0.0)
    day=fnum(r.get("day_pos_pct"), r.get("current_close_pos_ratio"), default=50.0)
    high_gap=fnum(r.get("recent_high_gap_pct"), r.get("below_high_pct"), default=-9.0)
    money=fnum(r.get("turnover_24h"), default=0.0)
    buy=fnum(o.get("buy_ratio"), o.get("micro_trade_buy_ratio_30"), default=0.0)
    spread=fnum(o.get("spread_pct"), default=99.0)
    if not ((ch3 >= 0.20 and ch5 >= 0.25) or (ch15 >= 0.70 and ch30 >= 0.40) or (ch5 >= 0.80 and ch15 >= 0.40)):
        no.append("흐름유지부족")
    if vwap < -0.10 or ema < -0.15:
        no.append("VWAP/EMA유지부족")
    if rel < -1.0 and ch5 < 1.0:
        no.append("시장대비약함")
    if money < 300_000_000:
        no.append("거래대금부족")
    if o.get("micro_fresh") and buy < 0.58:
        no.append("매수체결최소부족")
    if o.get("micro_fresh") and spread > 0.30:
        no.append("스프레드과다")
    if day >= 97.0 and high_gap >= -0.05 and ch1 <= 0.05:
        no.append("고점끝물재확인필요")
    if ch5 >= 12.0 and ema >= 6.0:
        no.append("급등과열재확인필요")
    return (not no, ["주도흐름유지","유동보유","VWAP/EMA방어","시간확장후보"], no)

def _pickv(src: Dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if isinstance(src, dict) and src.get(k) not in (None, "", "-"):
            return src.get(k)
    return default

def _boolv(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}

# v533 removed legacy unused function: _entry_snapshot

def _v361_adaptive_hold_profile(row: Dict[str, Any], of: Dict[str, Any], skey: str) -> Dict[str, Any]:
    """유동 보유형 후보별 청산/복기 프로필."""
    ch5=fnum(row.get('change_5m'), row.get('price_change_5m'), default=0.0)
    ch15=fnum(row.get('change_15m'), row.get('price_change_15m'), default=0.0)
    ch30=fnum(row.get('change_30m'), row.get('price_change_30m'), default=0.0)
    rel=fnum(row.get('relative_strength_pct'), row.get('relative_strength'), default=0.0)
    vwap=fnum(row.get('vwap_gap_pct'), default=0.0)
    ema=fnum(row.get('ema5_gap_pct'), row.get('ma5_gap_pct'), default=0.0)
    strong = (ch15 >= 1.2 and ch30 >= 0.8 and rel >= 0.3) or (ch5 >= 1.2 and ch15 >= 0.8 and vwap >= 0 and ema >= 0)
    ext_tp = 2.20 if strong else 1.80
    max_min = 120 if strong else 75
    return {
        'strategy_family': 'adaptive_hold',
        'strategy_family_label': '주도흐름 유동보유',
        'hold_model': 'adaptive_0_5_30_120',
        'phase_1': '0~5분 진입검증: 가격반응/체결지속/VWAP 방어 없으면 빠른정리',
        'phase_2': '5~30분 수익확인: +0.5~1.2% 도달·VWAP/EMA 유지 시 보유',
        'phase_3': '30~120분 확장: +1.2% 이상 도달 후 추세 유지 시 보호익절로 연장',
        'take_profit_pct': 1.20,
        'extended_target_pct': ext_tp,
        'extended_take_profit_pct': ext_tp,
        'protect_trigger_pct': 0.70,
        'protect_floor_pct': 0.35,
        'stop_loss_pct': -0.60,
        'hard_loss_guard_pct': -0.90,
        'time_exit_minutes': max_min,
        'time_exit_min': max_min,
        'early_validation_minutes': 5,
        'mid_validation_minutes': 30,
        'adaptive_hold_note': '나쁜 후보는 0~5분 검증 실패로 빨리 정리하고, +1.2% 이상 간 후보만 30~120분 확장 관찰',
    }

# v533 removed legacy unused function: build_event

def _priority_score(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], info_bad: List[str], hard_bad: List[str]) -> float:
    score = 0.0
    score += fnum(row.get("scanner_priority_score"), default=0.0)
    score += min(30.0, max(0.0, fnum(row.get("change_3m"), default=0.0) * 8))
    score += min(30.0, max(0.0, fnum(row.get("change_5m"), default=0.0) * 6))
    score += min(25.0, max(0.0, fnum(row.get("change_15m"), default=0.0) * 3))
    score += min(20.0, max(0.0, fnum(row.get("turnover_24h"), default=0.0) / 400_000_000))
    score += 25.0 * len(core_hits)
    if info_bad:
        score += 15.0
    if hard_bad:
        score -= 35.0
    return round(score, 3)


def _make_priority_request(t: str, row: Dict[str, Any], bucket: str, priority: float, need: List[str], core_hits: List[Tuple[str, List[str]]], reasons: List[str]) -> Dict[str, Any]:
    return {
        "ticker": t,
        "bucket": bucket,
        "priority": round(priority, 3),
        "need": need,
        "core_strategies": [k for k, _ in core_hits],
        "core_strategy_labels": [STRATEGIES.get(k, k) for k, _ in core_hits],
        "reasons": reasons[:8],
        "score": fnum(row.get("scanner_priority_score"), default=0.0),
        "change_3m": fnum(row.get("change_3m"), default=0.0),
        "change_5m": fnum(row.get("change_5m"), default=0.0),
        "change_15m": fnum(row.get("change_15m"), default=0.0),
        "turnover_24h": fnum(row.get("turnover_24h"), default=0.0),
        "updated_ts": now_ts(),
        "source": "strategy_worker",
    }


def _cheap_gate(row: Dict[str, Any], core_hits: List[Tuple[str, List[str]]], hard_bad: List[str]) -> Tuple[bool, str]:
    """정보를 붙일 가치가 있는 후보인지 cheap 재료만으로 먼저 가른다.
    개수 제한이 아니라 우선순위 gate다.
    - S 코어가 맞는 후보는 정보필요 후보
    - 코어가 아직 안 맞아도 돈/흐름/캔들/VWAP가 좋은 후보는 high 후보
    - 나머지는 WS/micro를 붙일 필요 없는 cheap 탈락 후보
    """
    if hard_bad:
        return False, "hard_block"
    if core_hits:
        return True, "core_hit"
    ch3=fnum(row.get("change_3m"), default=0.0)
    ch5=fnum(row.get("change_5m"), default=0.0)
    ch15=fnum(row.get("change_15m"), default=0.0)
    money=fnum(row.get("turnover_24h"), default=0.0)
    score=fnum(row.get("scanner_priority_score"), default=0.0)
    good_flow = (ch3 >= 0.35 and ch5 >= 0.45) or (ch5 >= 0.70) or (ch15 >= 1.20)
    good_position = fnum(row.get("vwap_gap_pct"), default=-9.0) >= -0.10 and fnum(row.get("ema5_gap_pct"), default=-9.0) >= -0.12
    good_signal = bool(row.get("volume_expanding") or row.get("breakout_hint") or row.get("sweep_reclaim_hint"))
    good_money = money >= 500_000_000
    if (good_flow and good_position and (good_signal or good_money)) or (score >= 88 and good_flow):
        return True, "high_cheap"
    return False, "cheap_drop"



# =============================================================================
# strategy_worker v0.87 / v510: clean single-pass canonical spine
# - Does not call legacy run_once / tail overrides.
# - Reads feature/orderflow once, builds base/spike lanes independently, merges once.
# - Writes paper_candidates_latest once. No old_latest re-mix, no archive runtime append.
# - Publishes candidate_reason / recheck / lifecycle / summary from the same final rows.
# =============================================================================
VERSION = "strategy_worker_v0.114"
MAIN_VERSION = "v2.13.452"
MAIN_DEPLOY_VERSION = "v2.13.452"
MAIN_BOT_VERSION = "수익형 v2.13.452"
V510_SCHEMA = "strategy_canonical_spine_v525_latest_only_publish"
CANDIDATE_REASON_COMPACT_CACHE = BASE_DIR / "clean_candidate_reason_compact_cache.json"
S1_LIFECYCLE_TRACE = BASE_DIR / "clean_s1_lifecycle_trace.json"
S1_LIFECYCLE_STATE = BASE_DIR / "clean_s1_lifecycle_state.json"
# v512: main command readers have used different historical names. We write the same object
# to explicit alias files, but all aliases are produced from one final_rows payload.
# v525: legacy candidate_reason/lifecycle alias cache files are no longer published.
# Main commands read paper_candidates_latest.jsonl directly. Keeping these lists empty prevents
# old cache readers from being revived by stale files.
CANDIDATE_REASON_ALIAS_FILES: List[Path] = []
S1_LIFECYCLE_ALIAS_FILES: List[Path] = []
RECHECK_CACHE = BASE_DIR / "clean_recheck_candidates_cache.json"
RECHECK_STATE = BASE_DIR / "clean_recheck_candidates_state.json"
CANONICAL_STRATEGY_SUMMARY = BASE_DIR / "clean_strategy_canonical_summary.json"
V510_TRACE = BASE_DIR / "clean_strategy_v510_single_pass_trace.json"

_STAGE_ORDER = {"S1": 3, "S2": 2, "S3": 1}


def _v510_num(*vals: Any, default: float = 0.0) -> float:
    return fnum(*vals, default=default)


def _v510_stage(row: Dict[str, Any]) -> str:
    st = str(row.get("s_stage") or row.get("candidate_grade") or row.get("stage") or row.get("grade") or "S3").upper()
    return st if st in ("S1", "S2", "S3") else "S3"


def _v510_uniq(xs: List[Any], maxn: int = 12) -> List[str]:
    out: List[str] = []
    seen = set()
    for x in xs or []:
        s = str(x or "").strip()
        if not s or s in seen:
            continue
        seen.add(s); out.append(s)
        if len(out) >= maxn:
            break
    return out


def _v510_bool(v: Any) -> bool:
    if isinstance(v, bool): return v
    return str(v).lower() in {"1", "true", "yes", "ok", "fresh", "신선"}


def _v510_age_from_of(of: Dict[str, Any], *keys: str, default: float = 999999.0) -> float:
    return _v510_num(*[of.get(k) for k in keys], default=default)



def _v521_file_age(path: Path) -> float:
    try:
        return max(0.0, now_ts() - path.stat().st_mtime)
    except Exception:
        return 999999.0


def _v521_row_age(row: Dict[str, Any], cache_age: float, *ts_keys: str) -> float:
    # 999999 means "age field missing", not "really stale".
    for k in ("age_sec", "cache_age_sec", "row_age_sec", "updated_age_sec"):
        a = _v510_num(row.get(k), default=-1.0)
        if 0 <= a < 999998:
            return a
    for k in ts_keys or ("updated_ts", "ts", "timestamp", "created_at", "event_ts"):
        ts = _v510_num(row.get(k), default=0.0)
        if ts > 1_000_000_000:
            return max(0.0, now_ts() - ts)
    return cache_age


def _v521_load_map_with_cache_age(path: Path, cache_name: str) -> Dict[str, Dict[str, Any]]:
    obj = load_json(path, {}) or {}
    c_age = _v521_file_age(path)
    out = map_rows(obj)
    top_ts = _v510_num(obj.get("updated_ts") if isinstance(obj, dict) else 0.0, default=0.0)
    top_age = max(0.0, now_ts() - top_ts) if top_ts > 1_000_000_000 else c_age
    for t, r in list(out.items()):
        rr = dict(r)
        rr.setdefault("_cache_name", cache_name)
        rr.setdefault("_cache_age_sec", min(c_age, top_age))
        rr.setdefault("_cache_updated_ts", top_ts or now_ts() - c_age)
        out[t] = rr
    return out


def _v521_hot_map() -> Dict[str, Dict[str, Any]]:
    out = _v521_load_map_with_cache_age(SCANNER_HOT, "scanner_hot")
    c_age = _v521_file_age(SCANNER_HOT)
    for t, r in list(out.items()):
        rr = dict(r)
        if "scanner_change_1m_pct" in rr and "change_1m" not in rr:
            rr["change_1m"] = rr.get("scanner_change_1m_pct")
        if "scanner_change_3m_pct" in rr and "change_3m" not in rr:
            rr["change_3m"] = rr.get("scanner_change_3m_pct")
        rr.setdefault("hot_signal_age_sec", _v521_row_age(rr, c_age, "updated_ts", "ts", "timestamp"))
        rr.setdefault("hot_fresh", c_age <= 10)
        rr.setdefault("scanner_hot_fresh", c_age <= 10)
        out[t] = rr
    return out


def _v521_overlay_feature(src: Dict[str, Any], hot: Dict[str, Any]) -> Dict[str, Any]:
    if not hot:
        return dict(src)
    merged = dict(src)
    for k in ("scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m", "hot_signal_age_sec", "hot_fresh", "scanner_hot_fresh"):
        if merged.get(k) in (None, "", 0, 0.0, 999999, 999999.0):
            merged[k] = hot.get(k)
    if merged.get("change_1m") in (None, "", 0, 0.0) and hot.get("change_1m") is not None:
        merged["change_1m"] = hot.get("change_1m")
    if merged.get("change_3m") in (None, "", 0, 0.0) and hot.get("change_3m") is not None:
        merged["change_3m"] = hot.get("change_3m")
    merged["_scanner_hot_cache_age_sec"] = hot.get("_cache_age_sec", _v521_file_age(SCANNER_HOT))
    return merged


def _v521_age_from_sources(primary: Dict[str, Any], secondary: Dict[str, Any], cache_key: str, keys: Tuple[str, ...], default_cache_age: float = 999999.0) -> float:
    for row in (primary, secondary):
        for k in keys:
            a = _v510_num(row.get(k), default=-1.0)
            if 0 <= a < 999998:
                return a
    for row in (primary, secondary):
        c = _v510_num(row.get(cache_key), row.get("_cache_age_sec"), default=-1.0)
        if 0 <= c < 999998:
            return c
    return default_cache_age


def _v521_value_present(row: Dict[str, Any], *keys: str) -> bool:
    for k in keys:
        v = row.get(k)
        if v in (None, "", [], {}):
            continue
        try:
            if float(str(v).replace(",", "").replace("%", "")) != 0:
                return True
        except Exception:
            return True
    return False



def _v522_parse_age_item(item: Any) -> Tuple[str, float]:
    s = str(item or "").strip()
    m = re.search(r'(hot|micro|orderflow|price|quote|paper)\s+([0-9]+(?:\.[0-9]+)?)s', s)
    if not m:
        return s, 999999.0
    return m.group(1), _v510_num(m.group(2), default=999999.0)


def _v522_filter_stale_items(items: List[Any], strict: bool = True) -> List[str]:
    # A stale reason is valid only when the component is actually over TTL.
    ttl = {
        "hot": 35.0 if strict else 60.0,
        "micro": 20.0,
        "orderflow": 20.0,
        "price": 30.0,
        "quote": 20.0,
        "paper": 45.0,
    }
    out: List[str] = []
    for raw in items or []:
        comp, a = _v522_parse_age_item(raw)
        if comp in ttl:
            if a >= ttl[comp]:
                out.append(f"{comp} {a:.1f}s")
            continue
        s = str(raw or "").strip()
        if s:
            out.append(s)
    return _v510_uniq(out, 8)


def _v522_strip_freshness_text(raw: List[Any]) -> List[str]:
    # Old route may still pass "신선도재확인:hot 0.8s" as an existing reason.
    # Remove all freshness strings here; the single gate will re-add only real stale items.
    out: List[str] = []
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if "신선" in s or "final_entry_gate" in s:
            continue
        out.append(s)
    return out


def _v520_age_ok(age_val: float, limit: float) -> bool:
    return age_val < 999998 and age_val <= limit


def _v520_bool_any(*vals: Any) -> bool:
    for v in vals:
        try:
            if _v510_bool(v):
                return True
        except Exception:
            continue
    return False


def _v520_fresh_stale_items(src: Dict[str, Any], of: Dict[str, Any], hot_age: float, micro_age: float, order_age: float, price_age: float, quote_age: float, sealed_price: float, strict: bool = True) -> List[str]:
    """v522 single freshness gate.
    Age under TTL is fresh. Value/cache presence is a bonus, not a second stale route.
    """
    hot_cache_age = _v510_num(src.get("_scanner_hot_cache_age_sec"), src.get("_cache_age_sec"), default=999999.0)
    of_cache_age = _v510_num(of.get("_cache_age_sec"), default=999999.0)

    ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), src.get("scanner_change_1m_pct"), default=0.0)
    ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), src.get("scanner_change_3m_pct"), default=0.0)
    hot_present = max(abs(ch1), abs(ch3)) > 0 or _v521_value_present(src, "scanner_hot_score", "scanner_hot_rank_1m", "scanner_hot_rank_3m")
    micro_present = _v521_value_present(of, "buy_ratio", "micro_trade_buy_ratio_30", "trade_buy_ratio", "spread_pct", "best_bid", "best_ask")
    order_present = micro_present or _v521_value_present(of, "orderflow_score", "sell_wall_ratio", "trade_count", "buy_count", "sell_count")
    quote_present = sealed_price > 0 or _v521_value_present(of, "quote_price", "current_price", "mid_price", "best_bid", "best_ask")
    price_present = sealed_price > 0 or _v521_value_present(src, "current_price", "price", "trade_price", "close", "last_price")

    # Missing embedded age uses cache age. If either age is fresh or value exists with fresh cache, it is fresh.
    hot_ok = bool(src.get("hot_fresh") or src.get("scanner_hot_fresh")) or _v520_age_ok(hot_age, 35) or (hot_cache_age <= 12 and hot_present)
    micro_ok = bool(of.get("micro_fresh")) or _v520_age_ok(micro_age, 20) or (of_cache_age <= 12 and micro_present)
    order_ok = bool(of.get("orderflow_fresh") or of.get("trade_fresh")) or _v520_age_ok(order_age, 20) or (of_cache_age <= 12 and order_present)
    quote_ok = bool(of.get("quote_fresh") or of.get("ws_fresh") or src.get("quote_fresh") or src.get("ws_fresh")) or _v520_age_ok(quote_age, 20) or (of_cache_age <= 12 and quote_present)
    price_ok = bool(src.get("price_reaction_fresh") or src.get("feature_fresh")) or _v520_age_ok(price_age, 30) or price_present

    stale: List[str] = []
    if strict and not hot_ok:
        stale.append(f"hot {hot_age:.1f}s")
    if not quote_ok:
        stale.append(f"quote {quote_age:.1f}s")
    if not micro_ok:
        stale.append(f"micro {micro_age:.1f}s")
    if strict and not order_ok:
        stale.append(f"orderflow {order_age:.1f}s")
    if not price_ok:
        stale.append(f"price {price_age:.1f}s")
    return _v522_filter_stale_items(stale, strict=strict)[:5]




def _v520_split_reasons(raw: List[Any], stale: List[str]) -> Tuple[List[str], List[str]]:
    decision: List[str] = []
    structure: List[str] = []
    raw = _v522_strip_freshness_text(raw)
    for x in raw or []:
        s = str(x or "").strip()
        if not s:
            continue
        if s.startswith("구조:"):
            structure.append(s.replace("구조:", "", 1).strip())
            continue
        if "fresh urgent" in s or "급등 확인" in s:
            decision.append("급등확인")
            continue
        decision.append(s)
    stale = _v522_filter_stale_items(stale, strict=True)
    if stale:
        decision.append("신선도재확인:" + "/".join(stale[:3]))
    return _v510_uniq(decision, 12), _v510_uniq(structure, 8)


def _v520_normalize_reason_row(r: Dict[str, Any]) -> Dict[str, Any]:
    stale = _v522_filter_stale_items([str(x).strip() for x in (r.get("stale_reasons") or []) if str(x).strip()], strict=True)
    reasons, structures = _v520_split_reasons(list(r.get("s_stage_reasons") or []) + list(r.get("block_reasons") or []), stale)
    base_structures = r.get("structure_tags") if isinstance(r.get("structure_tags"), list) else []
    r["structure_tags"] = _v510_uniq(list(base_structures) + structures, 10)
    r["s_stage_reasons"] = reasons
    r["reason"] = " / ".join(reasons)
    r["freshness_status"] = "recheck" if stale else "fresh"
    if stale:
        r["stale_reasons"] = stale
    else:
        r["stale_reasons"] = []
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    ctx["structure_tags"] = r["structure_tags"]
    ctx["reasons"] = reasons
    ctx["freshness_status"] = r["freshness_status"]
    ctx["stale_reasons"] = r["stale_reasons"]
    r["entry_context"] = ctx
    return r


def _v510_price_reaction(row: Dict[str, Any], of: Dict[str, Any]) -> float:
    return _v510_num(of.get("price_reaction_pct"), of.get("reaction_pct"), row.get("price_reaction_pct"), row.get("change_1m"), row.get("price_change_1m"), default=0.0)


def _v510_spread(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("spread_pct"), row.get("spread_pct"), default=99.0)


def _v510_buy(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=0.0)


def _v524_sustain_detail(of: Dict[str, Any], row: Dict[str, Any]) -> Tuple[float, str, bool]:
    real_keys = (
        "buy_sustain_1m", "buy_sustain_60s", "buy_persist_1m",
        "buy_flow_1m", "buy_pressure_1m", "micro_buy_sustain_1m",
    )
    for k in real_keys:
        v = _v510_num(of.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    for k in real_keys:
        v = _v510_num(row.get(k), default=-1.0)
        if v >= 0:
            return v, k, True
    fb = _v510_num(of.get("buy_ratio"), of.get("micro_trade_buy_ratio_30"), row.get("buy_ratio"), default=_v510_buy(of, row))
    return fb, "buy_ratio_fallback", False


def _v510_sustain(of: Dict[str, Any], row: Dict[str, Any]) -> float:
    return _v524_sustain_detail(of, row)[0]


def _v510_structure_tags(row: Dict[str, Any]) -> List[str]:
    tags: List[str] = []
    if row.get("sweep_reclaim_hint"): tags += ["저점유동성쓸림", "쓸림후빠른회복"]
    if row.get("breakout_hint"): tags += ["저항돌파후재테스트"]
    if _v510_num(row.get("vwap_gap_pct"), default=-9.0) >= -0.05: tags.append("VWAP방어")
    if _v510_num(row.get("ema5_gap_pct"), row.get("ma5_gap_pct"), default=-9.0) >= -0.10: tags.append("EMA방어")
    if row.get("volume_expanding"): tags.append("거래량확장")
    if _v510_num(row.get("change_3m"), default=0.0) >= 0.35: tags.append("돈흐름재유입")
    return _v510_uniq(tags, 8)


def _v510_risk_tags(row: Dict[str, Any], of: Dict[str, Any], hard: List[str]) -> List[str]:
    tags: List[str] = []
    spread = _v510_spread(of, row)
    buy = _v510_buy(of, row)
    if spread >= 0.35: tags.append("스프레드부담")
    if spread >= 0.35: tags.append("미끄러짐부담")
    if buy and buy < 0.58: tags.append("매수체결약함")
    if row.get("long_upper_wick"): tags.append("윗꼬리위험")
    if _v510_num(row.get("day_pos_pct"), default=50.0) > 94 and _v510_num(row.get("change_1m"), default=0.0) <= 0.05:
        tags.append("되돌림위험")
    for h in hard or []:
        if "매도" in h: tags.append("매도압력부담")
        if "스프레드" in h: tags.append("스프레드부담")
    return _v510_uniq(tags, 8)


def _v510_event_id(ticker: str, skey: str, lane: str, nowv: float) -> str:
    return f"{ticker}:{lane}:{skey}:{int(nowv // 10)}"



# =============================================================================
# v529: S1 체크리스트 inline helper
# - 함수 덮어쓰기/override 없음.
# - _v510_make_row/_v510_final_gate/_v510_publish 본체에서 직접 호출한다.
# - 조건값 변경 없음. 진단값만 row에 봉인한다.
# =============================================================================
def _v529_core_ok_from_row(row: Dict[str, Any]) -> bool:
    keys = row.get("matched_strategy_keys") if isinstance(row.get("matched_strategy_keys"), list) else []
    sk = str(row.get("strategy_key") or "")
    if keys:
        return any(str(k) and not str(k).startswith("hot_rank") for k in keys)
    return bool(sk and not sk.startswith("hot_rank"))


def _v544_is_hot_rank_row(row: Dict[str, Any], labels: List[Any], keys: List[Any]) -> bool:
    hay = " ".join(str(x) for x in ([row.get("strategy_label"), row.get("strategy"), row.get("strategy_key")] + list(labels or []) + list(keys or []))).lower()
    return ("hot-rank" in hay) or ("hot_rank" in hay) or ("hot rank" in hay)


def _v545_guard_text(row: Dict[str, Any], labels: List[Any], keys: List[Any], risks: List[Any], structures: List[Any]) -> str:
    return " ".join(str(x) for x in ([
        row.get("strategy_label"), row.get("strategy"), row.get("strategy_key"), row.get("paper_strategy_key")
    ] + list(labels or []) + list(keys or []) + list(risks or []) + list(structures or []))).lower()


def _v545_has_any(hay: str, words: Tuple[str, ...]) -> bool:
    return any(str(w).lower() in hay for w in words)


def _v545_strategy_recheck_reasons(row: Dict[str, Any], react: float, buy: float, sustain: float, sustain20: float, spread: float, slippage: float, chg30: float, chg60: float, risks: List[Any], structures: List[Any], labels: List[Any], keys: List[Any]) -> Tuple[List[str], List[str]]:
    """v545 multi-strategy S1 quality guard.

    This reflects v543 win/loss analysis, but never blocks by itself.
    Compound loss-like S1 rows are moved to S2 recheck; very weak low-confidence rows
    may be marked as S3 observe. Global S1/S2/S3 thresholds and exit rules are unchanged.
    """
    hay = _v545_guard_text(row, labels, keys, risks, structures)
    risk_txt = " ".join(str(x) for x in (risks or []))
    struct_txt = " ".join(str(x) for x in (structures or []))
    spread_bad = spread >= 0.45 or slippage >= 0.45 or "스프레드부담" in risk_txt or "미끄러짐부담" in risk_txt
    spread_severe = spread >= 0.65 or slippage >= 0.65
    sustain_weak = sustain < 0.70 or sustain20 < 0.55
    buy_weak = buy < 0.70
    chase_like = react >= 0.30 or chg30 >= 0.45 or chg60 >= 1.20
    vwap_ema = ("VWAP" in struct_txt or "EMA" in struct_txt)
    money_structure = ("돈흐름" in struct_txt or "거래량" in struct_txt)

    recheck: List[str] = []
    observe: List[str] = []

    # 1) hot-rank 급등 재확인: v543에서 손실군은 추격성 가격반응 + 약한 지속 + 나쁜 스프레드/미끄러짐이 반복됨.
    if _v545_has_any(hay, ("hot-rank", "hot_rank", "hot rank", "급등 재확인")):
        if spread_bad and sustain_weak and chase_like:
            recheck.append("재확인: hot-rank 추격+스프레드/지속약함")
        if spread_severe and (buy_weak or sustain_weak):
            recheck.append("재확인: hot-rank 높은 미끄러짐+체결확인 부족")

    # 2) 주도흐름 유동보유: 단순 체결/스프레드 차이는 작았고, 손실군은 고점권/되돌림/채널상단 위험이 반복됨.
    if _v545_has_any(hay, ("leader_flow_adaptive_hold", "주도흐름 유동보유")):
        overheat_hits = sum(1 for w in ("고점권가격반응약함", "되돌림위험", "채널상단과열", "윗꼬리위험") if w in risk_txt or w in struct_txt)
        if overheat_hits >= 2:
            recheck.append("재확인: 주도흐름 고점권/되돌림 위험")
        elif overheat_hits >= 1 and chase_like and sustain_weak:
            recheck.append("재확인: 주도흐름 추격+지속 약화")

    # 3) 돈흐름 재가속: 성과는 손실우세이나 단순 평균값 차이는 애매함.
    #    그래서 최근반복손실/하드손실/윗꼬리 같은 명시 위험이 있고 확인값이 충분치 않을 때만 재확인.
    if _v545_has_any(hay, ("money_reaccel", "pullback_reaccel", "돈흐름 재가속")):
        loss_like = _v545_has_any(risk_txt, ("최근반복손실", "하드손실", "윗꼬리위험", "매도압력"))
        structure_ok = bool(vwap_ema and money_structure and buy >= 0.85 and sustain >= 0.75)
        if loss_like and not structure_ok:
            recheck.append("재확인: 돈흐름 손실유사 위험+확인부족")
        elif ("윗꼬리위험" in risk_txt or "매도압력" in risk_txt) and (buy < 0.80 or sustain < 0.75):
            recheck.append("재확인: 돈흐름 윗꼬리/매도압력")

    # 4) 돌파 초입: 표본은 작지만 손실군에 거래량없는돌파가 보임. 스프레드/미끄러짐과 같이 있을 때만 재확인.
    if _v545_has_any(hay, ("breakout_early", "돌파 초입")):
        no_volume_break = "거래량없는돌파" in risk_txt or "거래량없는돌파" in struct_txt
        if no_volume_break and (spread_bad or sustain_weak):
            recheck.append("재확인: 돌파 초입 거래량없는돌파+위험부담")

    # 5) 저점 VWAP 회복: 표본은 작지만 손익비가 나빴고, 손실군은 스프레드/미끄러짐+체결 약함이 반복됨.
    #    아주 약한 조합은 paper 즉시진입보다 S3 관찰로 내린다.
    if _v545_has_any(hay, ("sweep_vwap", "저점 vwap", "저점 VWAP")):
        if spread_bad and (buy < 0.75 or sustain < 0.70):
            observe.append("관찰: 저점 VWAP 스프레드/체결약함")

    return _v510_uniq(recheck, 5), _v510_uniq(observe, 3)


def _v532_build_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:
    """v535 canonical S1 판단 원천.
    normal_common은 기존 안정형 기준을 유지하고, 급등형은 별도 entry_profile로 paper-test한다.
    """
    react = _v510_num(row.get("price_reaction_pct"), default=0.0)
    buy = _v510_num(row.get("buy_ratio"), default=0.0)
    sustain = _v510_num(row.get("buy_sustain_1m"), default=0.0)
    sustain20 = _v510_num(row.get("buy_sustain_20s"), row.get("buy_ratio_20s"), default=sustain)
    buy10 = _v510_num(row.get("buy_ratio_10s"), default=buy)
    spread = _v510_num(row.get("spread_pct"), default=99.0)
    slippage = _v510_num(row.get("slippage_pct"), default=spread)
    chg10 = _v510_num(row.get("price_chg_10s"), default=0.0)
    chg20 = _v510_num(row.get("price_chg_20s"), default=0.0)
    chg30 = _v510_num(row.get("price_chg_30s"), default=0.0)
    chg60 = _v510_num(row.get("price_chg_60s"), row.get("change_1m_pct"), default=0.0)
    accel10 = _v510_num(row.get("price_accel_10s"), default=0.0)
    accel20 = _v510_num(row.get("price_accel_20s"), default=0.0)
    spread_widen = _v510_num(row.get("spread_widening_10s"), default=0.0)
    sustain_real = bool(row.get("buy_sustain_1m_real"))
    stale = row.get("stale_reasons") if isinstance(row.get("stale_reasons"), list) else []
    risks = row.get("risk_tags") if isinstance(row.get("risk_tags"), list) else []
    structures = row.get("structure_tags") if isinstance(row.get("structure_tags"), list) else []
    hard_like = [str(x) for x in risks if any(w in str(x) for w in ("매도압력", "스프레드부담", "미끄러짐부담"))]
    upper_wick = any("윗꼬리" in str(x) for x in risks)
    sell_pressure = any("매도압력" in str(x) for x in risks)
    vwap_ema_ok = any(("VWAP" in str(x) or "EMA" in str(x)) for x in structures)
    money_ok = any(("돈흐름" in str(x) or "거래량" in str(x)) for x in structures)
    matched_labels = row.get("matched_strategy_labels") if isinstance(row.get("matched_strategy_labels"), list) else []
    matched_keys = row.get("matched_strategy_keys") if isinstance(row.get("matched_strategy_keys"), list) else []
    strategy_label = row.get("strategy_label") or row.get("strategy") or row.get("strategy_key") or "-"

    def ok_missing(checks: List[Dict[str, Any]]) -> Tuple[bool, List[Dict[str, Any]], List[str]]:
        missing = [c for c in checks if not c.get("ok")]
        return (len(missing) == 0), missing, [str(c.get("reason")) for c in missing if str(c.get("reason") or "").strip()]

    normal_checks = [
        {"name": "전략태그", "ok": True, "value": matched_labels or strategy_label, "need": "tag only", "reason": "태그", "weight": 0},
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "가격반응", "ok": react >= 0.35, "value": round(react,4), "need": ">=0.35", "reason": f"가격반응 {react:+.2f}% < +0.35%", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.70, "value": round(buy,4), "need": ">=0.70", "reason": f"매수체결 {buy:.2f} < 0.70", "weight": 1},
        {"name": "1분지속", "ok": bool(sustain_real and sustain >= 0.70), "value": round(sustain,4), "need": "real >=0.70", "reason": ("1분지속 실측없음" if not sustain_real else f"1분지속 {sustain:.2f} < 0.70"), "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.18, "value": round(spread,4), "need": "<=0.18", "reason": f"스프레드 {spread:.2f}% > 0.18%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.20, "value": round(slippage,4), "need": "<=0.20", "reason": f"미끄러짐 {slippage:.2f}% > 0.20%", "weight": 1},
        {"name": "강한위험", "ok": not bool(hard_like), "value": hard_like[:3], "need": "none", "reason": "위험부담:" + "/".join(hard_like[:3]) if hard_like else "통과", "weight": 1},
    ]
    normal_ok, normal_missing, normal_reasons = ok_missing(normal_checks)

    spike_signal = bool(chg20 >= 0.30 or chg30 >= 0.45 or react >= 0.70 or accel10 >= 0.18 or accel20 >= 0.22)
    late_chase = bool((chg60 >= 2.50 and (buy10 < 0.55 or spread > 0.85 or spread_widen > 0.35)) or upper_wick or (spread > 1.10) or (slippage > 1.20))
    spike_fast_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "급등초입", "ok": spike_signal, "value": {"chg20": round(chg20,3), "chg30": round(chg30,3), "react": round(react,3), "accel10": round(accel10,3)}, "need": "20s>=0.30 or 30s>=0.45 or react>=0.70", "reason": "급등초입 신호 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.55, "value": round(buy,4), "need": ">=0.55", "reason": f"급등형 매수체결 {buy:.2f} < 0.55", "weight": 1},
        {"name": "짧은매수", "ok": (sustain20 >= 0.55 or buy10 >= 0.65), "value": {"buy10": round(buy10,3), "sustain20": round(sustain20,3)}, "need": "20s>=0.55 or 10s>=0.65", "reason": f"짧은 매수세 부족 10s {buy10:.2f} / 20s {sustain20:.2f}", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.85, "value": round(spread,4), "need": "<=0.85", "reason": f"급등형 스프레드 {spread:.2f}% > 0.85%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.85, "value": round(slippage,4), "need": "<=0.85", "reason": f"급등형 미끄러짐 {slippage:.2f}% > 0.85%", "weight": 1},
        {"name": "최소체결", "ok": buy >= 0.40 and sustain20 >= 0.35, "value": {"buy": round(buy,3), "sustain20": round(sustain20,3)}, "need": "buy>=0.40 & 20s>=0.35", "reason": "급등형 최소 체결/지속 미달", "weight": 2},
        {"name": "늦은추격", "ok": not late_chase, "value": {"chg60": round(chg60,3), "spread_widen": round(spread_widen,3)}, "need": "not late chase", "reason": "늦은추격 위험", "weight": 2},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "급등형 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_fast_ok, spike_fast_missing, spike_fast_reasons = ok_missing(spike_fast_checks)

    runner_signal = bool(react >= 0.80 or chg60 >= 1.20 or chg30 >= 0.90)
    spike_runner_checks = [
        {"name": "신선도", "ok": not bool(stale), "value": stale[:3] if stale else "-", "need": "fresh", "reason": "신선도 재확인:" + "/".join(str(x) for x in stale[:3]) if stale else "통과", "weight": 2},
        {"name": "runner신호", "ok": runner_signal, "value": {"react": round(react,3), "chg60": round(chg60,3)}, "need": "react>=0.80 or 60s>=1.20", "reason": "runner 가격힘 부족", "weight": 1},
        {"name": "매수체결", "ok": buy >= 0.68, "value": round(buy,4), "need": ">=0.68", "reason": f"runner 매수체결 {buy:.2f} < 0.68", "weight": 1},
        {"name": "지속", "ok": sustain20 >= 0.65 and sustain >= 0.60, "value": {"20s": round(sustain20,3), "1m": round(sustain,3)}, "need": "20s>=0.65 and 1m>=0.60", "reason": "runner 매수지속 부족", "weight": 1},
        {"name": "스프레드", "ok": spread <= 0.55, "value": round(spread,4), "need": "<=0.55", "reason": f"runner 스프레드 {spread:.2f}% > 0.55%", "weight": 1},
        {"name": "미끄러짐", "ok": slippage <= 0.65, "value": round(slippage,4), "need": "<=0.65", "reason": f"runner 미끄러짐 {slippage:.2f}% > 0.65%", "weight": 1},
        {"name": "구조", "ok": bool(vwap_ema_ok and money_ok), "value": structures[:4], "need": "VWAP/EMA + money", "reason": "runner 구조 부족", "weight": 1},
        {"name": "강한위험", "ok": not bool(sell_pressure or upper_wick), "value": risks[:3], "need": "none", "reason": "runner 매도압력/윗꼬리 위험", "weight": 2},
    ]
    spike_runner_ok, spike_runner_missing, spike_runner_reasons = ok_missing(spike_runner_checks)

    spike_ok = bool(spike_fast_ok or spike_runner_ok)
    spike_watch = bool(spike_signal or runner_signal)
    spike_missing = spike_runner_missing if spike_runner_ok else spike_fast_missing
    spike_reasons = spike_runner_reasons if spike_runner_ok else spike_fast_reasons
    spike_checks = spike_runner_checks if spike_runner_ok else spike_fast_checks

    if normal_ok:
        entry_profile = "normal_common"
        exit_profile = "normal_exit"
        active_checks = normal_checks
        active_missing = normal_missing
        active_reasons = normal_reasons
    elif spike_ok:
        # v536: 급등형 진입은 spike 하나로만 기록한다. fast/runner 세부분류는 exit_reason/성과에서 본다.
        entry_profile = "spike"
        exit_profile = "spike_trailing"
        active_checks = spike_checks
        active_missing = spike_missing
        active_reasons = spike_reasons
    else:
        entry_profile = "watch"
        exit_profile = "watch_exit"
        active_checks = spike_fast_checks if spike_watch else normal_checks
        active_missing = spike_fast_missing if spike_watch else normal_missing
        active_reasons = spike_fast_reasons if spike_watch else normal_reasons

    raw_s1_allowed = bool(normal_ok or spike_ok)
    if raw_s1_allowed:
        recheck_guard_reasons, observe_guard_reasons = _v545_strategy_recheck_reasons(row, react, buy, sustain, sustain20, spread, slippage, chg30, chg60, risks, structures, matched_labels, matched_keys)
    else:
        recheck_guard_reasons, observe_guard_reasons = [], []
    # v547 surgery: S2 재확인은 출력부에서 꾸미지 않고, canonical decision에서 stage로 봉인한다.
    # - raw S1 손실유사 조합은 S2 재확인/S3 관찰로 분리한다.
    # - raw S3라도 구조/확인값이 살아 있고 부족값이 회복 가능한 경우는 S2 재확인으로 남긴다.
    block_score_pre = sum(int(c.get("weight", 1)) for c in active_missing)
    structure_present = bool(matched_labels or matched_keys or structures)
    strong_confirm = bool(buy >= 0.70 and sustain >= 0.70)
    partial_confirm = bool(buy >= 0.55 and sustain >= 0.55)
    severe_risk = bool(spread >= 1.20 or slippage >= 1.20 or (buy < 0.40 and sustain < 0.40))
    recoverable_recheck_reasons: List[str] = []
    if (not observe_guard_reasons) and (not severe_risk) and structure_present:
        if stale and (partial_confirm or react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 신선도 갱신 대기")
        if (spread > 0.18 or slippage > 0.20) and (strong_confirm or (react >= 0.30 and partial_confirm)):
            recoverable_recheck_reasons.append("재확인: 스프레드/미끄러짐 회복 대기")
        if (buy < 0.70 or sustain < 0.70) and (buy >= 0.55 or sustain >= 0.55) and (react >= 0.05 or spike_signal or runner_signal):
            recoverable_recheck_reasons.append("재확인: 체결/1분지속 회복 대기")
        if react < 0.35 and strong_confirm and (spread <= 0.85 and slippage <= 0.85):
            recoverable_recheck_reasons.append("재확인: 가격반응 확인 대기")
    recoverable_recheck_reasons = _v510_uniq(recoverable_recheck_reasons, 4)
    recheck_all_reasons = _v510_uniq(list(recheck_guard_reasons) + list(recoverable_recheck_reasons), 6)
    guard_reasons = list(recheck_all_reasons) + list(observe_guard_reasons)
    s1_allowed = bool(raw_s1_allowed and not guard_reasons)
    if guard_reasons:
        active_missing = list(active_missing) + [
            {"name": "S2재확인" if str(reason).startswith("재확인") else "S3관찰", "ok": False, "value": reason, "need": "recheck/observe", "reason": reason, "weight": 1}
            for reason in guard_reasons
        ]
        active_reasons = list(active_reasons) + guard_reasons
    block_score = sum(int(c.get("weight", 1)) for c in active_missing)
    s2_recheck = bool((recheck_all_reasons and not observe_guard_reasons) or ((not guard_reasons) and (not severe_risk) and structure_present and block_score <= 6 and ((react >= 0.15 and buy >= 0.55) or spike_signal or runner_signal or strong_confirm)))
    near = bool(block_score <= 3 or bool(recoverable_recheck_reasons))
    passed = [str(c.get("name")) for c in active_checks if c.get("ok")]
    raw_entry_profile = entry_profile
    if guard_reasons:
        entry_profile = "watch"
        exit_profile = "watch_exit"
    return {
        "schema": "canonical_entry_decision_v547_recheck_spine",
        "version": VERSION,
        "strategy_role": "tag",
        "entry_profile": entry_profile,
        "exit_profile": exit_profile,
        "profile_family": "spike" if entry_profile == "spike" else ("normal" if entry_profile == "normal_common" else "watch"),
        "matched_strategy_keys": matched_keys,
        "matched_strategy_labels": matched_labels or [str(strategy_label)],
        "gate_pass": s1_allowed,
        "raw_s1_allowed": raw_s1_allowed,
        "s1_allowed": s1_allowed,
        "s1_recheck_guard": bool(guard_reasons),
        "s1_recheck_guard_reasons": guard_reasons,
        "s1_recheck_reasons": recheck_all_reasons,
        "s2_recheck_reasons": recheck_all_reasons,
        "s1_observe_reasons": observe_guard_reasons,
        "s1_recheck_basis": "v547 surgery: recheck reasons are sealed as visible S2 in canonical stage spine, not patched in output",
        "s2_recheck": bool(s2_recheck and not s1_allowed),
        "recoverable_recheck_reasons": recoverable_recheck_reasons,
        "action": "paper_open_candidate" if s1_allowed else ("recheck" if s2_recheck else "observe"),
        "freshness_ok": not bool(stale),
        "stale_reasons": list(stale),
        "checks": active_checks,
        "passed_conditions": passed,
        "missing_conditions": active_reasons,
        "missing_names": [str(c.get("name")) for c in active_missing],
        "block_count": len(active_missing),
        "block_score": block_score,
        "s1_distance": block_score,
        "s1_near_miss": near,
        "s1_near_miss_level": "near" if near else ("mid" if block_score <= 5 else "far"),
        "display_reasons": active_reasons,
        "profile_decisions": {
            "normal_common": {"pass": normal_ok, "missing": normal_reasons[:6]},
            "spike": {"pass": spike_ok, "missing": spike_reasons[:6], "fast_pass": spike_fast_ok, "runner_pass": spike_runner_ok},
            "watch": {"pass": False, "missing": active_reasons[:6]},
            "raw_entry_profile": raw_entry_profile,
        },
        "metrics": {
            "price_reaction_pct": react,
            "price_chg_10s": chg10,
            "price_chg_20s": chg20,
            "price_chg_30s": chg30,
            "price_chg_60s": chg60,
            "price_accel_10s": accel10,
            "price_accel_20s": accel20,
            "buy_ratio": buy,
            "buy_ratio_10s": buy10,
            "buy_sustain_20s": sustain20,
            "buy_sustain_1m": sustain,
            "buy_sustain_1m_real": sustain_real,
            "spread_pct": spread,
            "slippage_pct": slippage,
            "spread_widening_10s": spread_widen,
        },
        "policy": "v548: canonical S2 recheck spine fixed; main reads hub cache only; recoverable near-miss rows become visible S2 recheck, not S3 display patch; conditions/exits unchanged.",
    }


def _v532_apply_canonical_entry_decision(row: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(row, dict):
        return row
    dec = _v532_build_canonical_entry_decision(row)
    row["canonical_entry_decision"] = dec
    row["common_entry_decision"] = dec
    row["common_entry_pass"] = bool(dec.get("s1_allowed"))
    row["common_entry_schema"] = dec.get("schema")
    row["strategy_role"] = "tag"
    row["entry_profile"] = dec.get("entry_profile")
    row["exit_profile"] = dec.get("exit_profile")
    row["profile_family"] = dec.get("profile_family")
    row["profile_decisions"] = dec.get("profile_decisions", {})
    row["s1_checklist"] = dec.get("checks", [])
    row["s1_passed_conditions"] = dec.get("passed_conditions", [])
    row["s1_missing_conditions"] = dec.get("missing_conditions", [])
    row["s1_missing_names"] = dec.get("missing_names", [])
    row["s1_block_count"] = dec.get("block_count", 0)
    row["s1_block_score"] = dec.get("block_score", 0)
    row["s1_distance"] = dec.get("s1_distance", 0)
    row["s1_near_miss"] = bool(dec.get("s1_near_miss"))
    row["s1_near_miss_level"] = dec.get("s1_near_miss_level")
    row["s1_short_reason"] = " / ".join(str(x) for x in (dec.get("display_reasons") or [])[:4]) if dec.get("display_reasons") else "S1 조건 통과"
    if bool(dec.get("s1_allowed")):
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S1"
        row["open_eligible"] = True
        row["paper_bot_open"] = True
        row["trade_ready"] = True
    elif bool(dec.get("s2_recheck") or dec.get("action") == "recheck"):
        # v547: 재확인 사유가 있으면 출력 보정이 아니라 canonical stage를 S2로 봉인한다.
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S2"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
        row["recheck_state"] = "S2 재확인"
        row["s2_recheck_reasons"] = dec.get("s2_recheck_reasons") or dec.get("s1_recheck_reasons") or []
    elif _v510_stage(row) == "S1":
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = "S3"
        row["open_eligible"] = False
        row["paper_bot_open"] = False
        row["trade_ready"] = False
    else:
        st = _v510_stage(row)
        row["s_stage"] = row["candidate_stage"] = row["candidate_grade"] = row["stage"] = row["grade"] = st
        if st != "S1":
            row["open_eligible"] = False
            row["paper_bot_open"] = False
            row["trade_ready"] = False
    ctx = row.get("entry_context") if isinstance(row.get("entry_context"), dict) else {}
    ctx = dict(ctx)
    for k in (
        "canonical_entry_decision", "common_entry_decision", "common_entry_pass", "common_entry_schema", "strategy_role",
        "entry_profile", "exit_profile", "profile_family", "profile_decisions",
        "s1_checklist", "s1_passed_conditions", "s1_missing_conditions", "s1_missing_names",
        "s1_block_count", "s1_block_score", "s1_distance", "s1_near_miss", "s1_near_miss_level", "s1_short_reason", "s2_recheck_reasons", "recheck_state",
    ):
        ctx[k] = row.get(k)
    row["entry_context"] = ctx
    return row

def _v510_make_row(src: Dict[str, Any], of: Dict[str, Any], stage: str, skey: str, label: str, lane: str, score: float, reasons: List[str], nowv: float, hard: Optional[List[str]] = None) -> Dict[str, Any]:
    t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
    react = _v510_price_reaction(src, of)
    spread = _v510_spread(of, src)
    buy = _v510_buy(of, src)
    sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
    # v519: paper_bot OPEN 필수 가격값을 strategy canonical row에서 봉인한다.
    sealed_price = _v510_num(
        src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
        of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
        of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
        default=0.0,
    )
    hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
    micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
    price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
    quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
    stale_items = _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price, strict=True)
    decision_reasons, reason_structure_tags = _v520_split_reasons(reasons, stale_items)
    row = {
        "schema": "paper_candidate_v520_reason_spine_row",
        "version": VERSION,
        "ticker": t,
        "market": f"KRW-{t}" if t else src.get("market"),
        "symbol": f"{t}_KRW" if t else src.get("symbol"),
        "event_id": _v510_event_id(t, skey, lane, nowv),
        "event_key": _v510_event_id(t, skey, lane, nowv),
        "created_at": nowv,
        "candidate_created_at": nowv,
        "source_created_at": nowv,
        "detected_ts": nowv,
        "event_ts": nowv,
        "created_at_text": now_text(nowv),
        "updated_ts": nowv,
        "expires_at": nowv + (70 if stage == "S1" else 180),
        "strategy_key": skey,
        "paper_strategy_key": skey,
        "strategy_label": label,
        "strategy": label,
        "matched_strategy_keys": list(src.get("_matched_strategy_keys") or [skey]),
        "matched_strategy_labels": list(src.get("_matched_strategy_labels") or [label]),
        "canonical_lane": lane,
        "s_stage": stage,
        "candidate_stage": stage,
        "candidate_grade": stage,
        "stage": stage,
        "grade": stage,
        "score": round(score, 3),
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "trade_price": sealed_price,
        "price_source": "strategy_v522_sealed",
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_reaction_pct": round(react, 4),
        "spread_pct": round(spread, 4),
        "slippage_pct": round(spread, 4),
        "buy_ratio": round(buy, 4),
        "buy_sustain_1m": round(sustain, 4),
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "sustain_source": sustain_source,
        "change_1m_pct": _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0),
        "change_3m_pct": _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0),
        "change_5m_pct": _v510_num(src.get("change_5m"), src.get("price_change_5m"), default=0.0),
        "price_chg_5s": _v510_num(of.get("price_chg_5s"), src.get("price_chg_5s"), default=0.0),
        "price_chg_10s": _v510_num(of.get("price_chg_10s"), src.get("price_chg_10s"), default=0.0),
        "price_chg_20s": _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0),
        "price_chg_30s": _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0),
        "price_chg_60s": _v510_num(of.get("price_chg_60s"), src.get("price_chg_60s"), default=0.0),
        "price_accel_10s": _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0),
        "price_accel_20s": _v510_num(of.get("price_accel_20s"), src.get("price_accel_20s"), default=0.0),
        "buy_ratio_5s": _v510_num(of.get("buy_ratio_5s"), src.get("buy_ratio_5s"), default=buy),
        "buy_ratio_10s": _v510_num(of.get("buy_ratio_10s"), src.get("buy_ratio_10s"), default=buy),
        "buy_sustain_20s": _v510_num(of.get("buy_sustain_20s"), src.get("buy_sustain_20s"), default=sustain),
        "trade_burst_10s": _v510_num(of.get("trade_burst_10s"), src.get("trade_burst_10s"), default=0.0),
        "spread_widening_10s": _v510_num(of.get("spread_widening_10s"), src.get("spread_widening_10s"), default=0.0),
        "spike_fast_ready": bool(of.get("spike_fast_ready") or src.get("spike_fast_ready")),
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "structure_tags": _v510_uniq(_v510_structure_tags(src) + reason_structure_tags, 10),
        "risk_tags": _v510_risk_tags(src, of, hard or []),
        "stale_reasons": stale_items,
        "freshness_status": "recheck" if stale_items else "fresh",
        "reason": " / ".join(decision_reasons),
        "s_stage_reasons": decision_reasons,
    }
    row["entry_context"] = {
        "strategy_key": skey,
        "strategy_label": label,
        "canonical_lane": lane,
        "structure_tags": row["structure_tags"],
        "risk_tags": row["risk_tags"],
        "hot_signal_age_sec": hot_age,
        "micro_age_sec": micro_age,
        "orderflow_age_sec": order_age,
        "price_reaction_age_sec": price_age,
        "quote_age_sec": quote_age,
        "freshness_status": "recheck" if stale_items else "fresh",
        "stale_reasons": stale_items,
        "current_price": sealed_price,
        "entry_price": sealed_price,
        "detected_price": sealed_price,
        "live_price": sealed_price,
        "price": sealed_price,
        "price_ready": bool(sealed_price and sealed_price > 0),
        "price_source": "strategy_v522_sealed",
        "price_reaction_pct": react,
        "buy_ratio": buy,
        "buy_sustain_1m": sustain,
        "buy_sustain_1m_source": sustain_source,
        "buy_sustain_1m_real": bool(sustain_real),
        "buy_sustain_1m_is_fallback": not bool(sustain_real),
        "spread_pct": spread,
        "price_chg_20s": row.get("price_chg_20s"),
        "price_chg_30s": row.get("price_chg_30s"),
        "price_chg_60s": row.get("price_chg_60s"),
        "price_accel_10s": row.get("price_accel_10s"),
        "buy_ratio_10s": row.get("buy_ratio_10s"),
        "buy_sustain_20s": row.get("buy_sustain_20s"),
        "spread_widening_10s": row.get("spread_widening_10s"),
        "reasons": row["s_stage_reasons"],
    }
    return _v532_apply_canonical_entry_decision(row)


def _v510_final_gate(row: Dict[str, Any], nowv: float) -> Dict[str, Any]:
    r = dict(row)
    stage = _v510_stage(r)
    skey = str(r.get("strategy_key") or "")
    is_spike = skey in {"spike_momentum_ride", "spike_pullback_reaccel"}
    hot = _v510_num(r.get("hot_signal_age_sec"), default=999999.0)
    micro = _v510_num(r.get("micro_age_sec"), default=999999.0)
    order = _v510_num(r.get("orderflow_age_sec"), default=micro)
    price = _v510_num(r.get("price_reaction_age_sec"), default=999999.0)
    quote = _v510_num(r.get("quote_age_sec"), default=999999.0)
    paper_delay = max(0.0, nowv - _event_created_ts(r))
    sealed_price = _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0)
    stale: List[str] = _v520_fresh_stale_items(r, r, hot, micro, order, price, quote, sealed_price, strict=is_spike)
    if is_spike and paper_delay > 20:
        stale.append(f"paper {paper_delay:.1f}s")
    elif (not is_spike) and paper_delay > 45:
        stale.append(f"paper {paper_delay:.1f}s")
    stale = _v522_filter_stale_items(_v510_uniq(stale, 6), strict=is_spike)
    allowed = not stale
    if stage == "S1" and not allowed:
        r["v510_downgraded_from_s1"] = True
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = "S2"
        rr = list(r.get("s_stage_reasons") or []) + ["final_entry_gate 신선도 재확인: " + " / ".join(stale[:5])]
        r["s_stage_reasons"] = _v510_uniq(rr, 12)
    r["stale_reasons"] = stale
    r = _v520_normalize_reason_row(r)
    r["fresh_gate_ok"] = bool(allowed)
    r = _v532_apply_canonical_entry_decision(r)
    decision = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    final_allowed = bool(decision.get("s1_allowed") and allowed)
    if not final_allowed and _v510_stage(r) == "S1":
        r["v510_downgraded_from_s1"] = True
        target_stage = "S2" if (stale or decision.get("s2_recheck") or decision.get("action") == "recheck") else "S3"
        r["s_stage"] = r["candidate_stage"] = r["candidate_grade"] = r["stage"] = r["grade"] = target_stage
    r["open_eligible"] = bool(final_allowed)
    r["paper_bot_open"] = bool(final_allowed)
    r["trade_ready"] = bool(final_allowed)
    r["v510_final_entry_gate"] = {
        "schema": "final_entry_gate_v536_profile_simplified",
        "version": VERSION,
        "checked_ts": nowv,
        "age_values": {"hot": hot, "micro": micro, "orderflow": order, "price": price, "quote": quote, "paper": paper_delay},
        "stale_reasons": stale,
        "s1_allowed": bool(final_allowed),
        "policy": "v536: canonical_entry_decision with simplified entry_profile; paper_candidates_latest.jsonl is canonical",
    }
    ctx = r.get("entry_context") if isinstance(r.get("entry_context"), dict) else {}
    ctx = dict(ctx); ctx["v510_final_entry_gate"] = r["v510_final_entry_gate"]
    r["entry_context"] = ctx
    dec = r.get("canonical_entry_decision") if isinstance(r.get("canonical_entry_decision"), dict) else {}
    if isinstance(dec, dict):
        dec = dict(dec)
        dec["v510_final_entry_gate"] = r["v510_final_entry_gate"]
        dec["s1_allowed"] = bool(final_allowed)
        dec["gate_pass"] = bool(final_allowed)
        dec["action"] = "paper_open_candidate" if final_allowed else ("recheck" if dec.get("s2_recheck") else "observe")
        r["canonical_entry_decision"] = dec
        r["common_entry_decision"] = dec
        r["entry_context"]["canonical_entry_decision"] = dec
        r["entry_context"]["common_entry_decision"] = dec
    return r


def _v510_base_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
    rows: List[Dict[str, Any]] = []
    rejects: List[Dict[str, Any]] = []
    requests: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        hard = common_hard(src, of)
        core_hits: List[Tuple[str, List[str]]] = []
        core_fail: List[str] = []
        for skey, fn in evals:
            ok, why, no = fn(src, of)
            if ok: core_hits.append((skey, why))
            else: core_fail += [f"{STRATEGIES.get(skey, skey)}:{x}" for x in no[:2]]
        need_info, cheap_bucket = _cheap_gate(src, core_hits, hard)
        info_bad = orderflow_info_bad(of) if need_info else []
        react = _v510_price_reaction(src, of)
        buy = _v510_buy(of, src)
        sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        spread = _v510_spread(of, src)
        score = _priority_score(src, core_hits, info_bad, hard)
        reasons: List[str] = []
        skey = core_hits[0][0] if core_hits else "leader_flow_adaptive_hold_s"
        label = STRATEGIES.get(skey, skey).replace(" S", "")
        if core_hits:
            reasons += [f"구조:{STRATEGIES.get(k,k)}" for k,_ in core_hits[:2]]
        reasons += hard[:4] + info_bad[:3]
        if react < 0.05: reasons.append("가격반응 기준근접(+0.00%→+0.05%)")
        if react < 0.35: reasons.append("가격반응 약함(+0.05%→+0.35%)")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        elif spread > 0.18: reasons.append(f"스프레드 경계값({spread:.2f}%)→재확인")
        stage = ""
        common_s2 = (not hard and react >= 0.15 and buy >= 0.55 and spread <= 0.35)
        if core_hits or common_s2 or (need_info and cheap_bucket in {"core_hit", "high_cheap"}) or score >= 88:
            # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
            stage = "S2" if (core_hits or react >= 0.25 or score >= 105 or common_s2) else "S3"
        elif cheap_bucket == "high_cheap":
            stage = "S3"
        if not stage:
            rejects.append({"ticker": t, "score": score, "reasons": _v510_uniq(reasons + core_fail, 8), "updated_ts": nowv})
            continue
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "base", score, reasons or ["구조관찰"], nowv, hard)
        rows.append(row)
        need = []
        if not _v510_bool(of.get("quote_fresh") or of.get("ws_fresh")): need.append("quote")
        if not _v510_bool(of.get("micro_fresh")): need.append("micro")
        requests.append(_make_priority_request(t, src, "s_candidate" if stage == "S1" else "recheck_candidate", 100 + score + _STAGE_ORDER.get(stage,1)*20, need or ["micro"], core_hits, row.get("s_stage_reasons") or []))
    return rows, rejects, requests


def _v510_spike_lane(nowv: float, feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    for src in feature_list:
        t = ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol"))
        if not t: continue
        of = ofmap.get(t, {}) or {}
        ch1 = _v510_num(src.get("change_1m"), src.get("price_change_1m"), default=0.0)
        ch3 = _v510_num(src.get("change_3m"), src.get("price_change_3m"), default=0.0)
        react = _v510_price_reaction(src, of)
        short20 = _v510_num(of.get("price_chg_20s"), src.get("price_chg_20s"), default=0.0)
        short30 = _v510_num(of.get("price_chg_30s"), src.get("price_chg_30s"), default=0.0)
        accel10 = _v510_num(of.get("price_accel_10s"), src.get("price_accel_10s"), default=0.0)
        # Wide prefilter only. It does not cap candidates.
        if max(ch1, ch3, react, short20, short30, accel10) < 0.30:
            continue
        spread = _v510_spread(of, src); buy = _v510_buy(of, src); sustain, sustain_source, sustain_real = _v524_sustain_detail(of, src)
        hot_age = _v521_age_from_sources(src, of, "_scanner_hot_cache_age_sec", ("hot_signal_age_sec", "hot_age_sec"), default_cache_age=_v521_file_age(SCANNER_HOT))
        micro_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("micro_age_sec", "trade_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        order_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("orderflow_age_sec", "trade_age_sec", "micro_age_sec"), default_cache_age=micro_age)
        price_age = _v521_age_from_sources(src, of, "_cache_age_sec", ("price_reaction_age_sec", "price_age_sec", "feature_age_sec"), default_cache_age=0.0)
        quote_age = _v521_age_from_sources(of, src, "_cache_age_sec", ("quote_age_sec", "ws_age_sec"), default_cache_age=_v510_num(of.get("_cache_age_sec"), default=999999.0))
        sealed_price_probe = _v510_num(
            src.get("current_price"), src.get("price"), src.get("trade_price"), src.get("close"), src.get("last_price"),
            of.get("quote_price"), of.get("current_price"), of.get("price"), of.get("trade_price"), of.get("last_price"),
            of.get("mid_price"), of.get("best_bid"), of.get("bid_price"),
            default=0.0,
        )
        fresh = not _v520_fresh_stale_items(src, of, hot_age, micro_age, order_age, price_age, quote_age, sealed_price_probe, strict=True)
        evals=[("leader_flow_adaptive_hold_s",eval_adaptive_hold),("money_reaccel_s",eval_money),("leader_momentum_s",eval_leader),("breakout_early_s",eval_breakout),("sweep_vwap_recovery_s",eval_sweep),("surge_rebreak_s",eval_surge)]
        core_hits: List[Tuple[str, List[str]]] = []
        for _skey, _fn in evals:
            _ok, _why, _no = _fn(src, of)
            if _ok:
                core_hits.append((_skey, _why))
        # S1 is not decided here. _v532_apply_canonical_entry_decision is the only S1 source.
        strong = (react >= 0.80 or ch1 >= 0.70 or ch3 >= 1.20) and buy >= 0.78 and sustain >= 0.78 and spread <= 0.18
        late_risk = (buy < 0.70 or sustain < 0.70 or spread > 0.35 or row_bool(src, "long_upper_wick"))
        stage = "S2" if (fresh and (react >= 0.35 or strong) and spread <= 0.50) else "S3"
        if core_hits:
            skey = core_hits[0][0]
            label = STRATEGIES.get(skey, skey).replace(" S", "")
        else:
            skey = "hot_rank_recheck"
            label = "hot-rank 급등 재확인"
        reasons: List[str] = []
        if stage == "S1":
            reasons.append("fresh urgent 급등 확인")
        elif core_hits:
            reasons.append("급등확인 재확인")
        else:
            reasons.append("hot-rank 급등 재확인")
        if buy < 0.70: reasons.append(f"매수체결 0.70 미만({buy:.2f})")
        if sustain < 0.70 and sustain_real:
            reasons.append("1분 매수지속 부족")
        elif sustain < 0.70 and not sustain_real:
            reasons.append("1분지속 실측없음(buy_ratio대체)")
        if spread > 0.35: reasons.append(f"스프레드 과다({spread:.2f}%)")
        score = 100 + max(0.0, react)*10 + max(0.0, ch1)*4 + max(0.0, ch3)*3 + max(0.0, buy)*2 + max(0.0, short20)*5 + max(0.0, accel10)*4
        src_for_row = dict(src)
        src_for_row["_matched_strategy_keys"] = [k for k, _ in core_hits] or [skey, "common_rise_entry"]
        src_for_row["_matched_strategy_labels"] = [STRATEGIES.get(k, k) for k, _ in core_hits] or [label, "공통상승조건"]
        row = _v510_make_row(src_for_row, of, stage, skey, label, "spike", score, reasons, nowv, [])
        rows.append(_v520_normalize_reason_row(row))
    return rows


def row_bool(row: Dict[str, Any], key: str) -> bool:
    try:
        return _v510_bool(row.get(key))
    except Exception:
        return False


def _v510_merge_rows(rows: List[Dict[str, Any]], nowv: float) -> List[Dict[str, Any]]:
    merged: Dict[str, Dict[str, Any]] = {}
    for r in rows:
        if not isinstance(r, dict): continue
        r = _v510_final_gate(r, nowv)
        t = ticker_norm(r.get("ticker") or r.get("market") or r.get("symbol"))
        if not t: continue
        key = t
        prev = merged.get(key)
        if prev is None:
            merged[key] = r; continue
        merged_keys = _v510_uniq(list(prev.get("matched_strategy_keys") or []) + list(r.get("matched_strategy_keys") or []), 8)
        merged_labels = _v510_uniq(list(prev.get("matched_strategy_labels") or []) + list(r.get("matched_strategy_labels") or []), 8)
        a = (_STAGE_ORDER.get(_v510_stage(r), 0), 1 if str(r.get("canonical_lane")) == "base" else 0, _v510_num(r.get("score"), default=0.0), _event_created_ts(r))
        b = (_STAGE_ORDER.get(_v510_stage(prev), 0), 1 if str(prev.get("canonical_lane")) == "base" else 0, _v510_num(prev.get("score"), default=0.0), _event_created_ts(prev))
        chosen = r if a >= b else prev
        chosen["matched_strategy_keys"] = merged_keys
        chosen["matched_strategy_labels"] = merged_labels
        merged[key] = chosen
    out = sorted(merged.values(), key=lambda x: (_STAGE_ORDER.get(_v510_stage(x),0), _v510_num(x.get("score"), default=0.0), _event_created_ts(x)), reverse=True)
    return out


def _v510_counts(rows: List[Dict[str, Any]]) -> Dict[str, int]:
    c = {"S1": 0, "S2": 0, "S3": 0}
    for r in rows:
        st = _v510_stage(r)
        c[st] = c.get(st, 0) + 1
    return c


def _v510_reason_top(rows: List[Dict[str, Any]], maxn: int = 20) -> List[Dict[str, Any]]:
    ctr: Dict[str, int] = {}
    for r in rows:
        if _v510_stage(r) == "S1": continue
        for reason in (r.get("s_stage_reasons") or r.get("block_reasons") or [])[:6]:
            s = str(reason or "").strip()
            if not s: continue
            # Collapse numeric variants lightly for panel readability.
            if "스프레드" in s: s = "스프레드"
            elif "미끄러짐" in s: s = "미끄러짐"
            elif "매수체결" in s: s = "매수체결"
            elif "1분" in s: s = "1분지속"
            elif "가격반응" in s: s = "가격반응"
            elif "신선" in s: s = "신선도재확인"
            ctr[s] = ctr.get(s, 0) + 1
    return [{"reason": k, "count": v} for k, v in sorted(ctr.items(), key=lambda kv: kv[1], reverse=True)[:maxn]]



def _v512_info_quality(feature_list: List[Dict[str, Any]], ofmap: Dict[str, Dict[str, Any]]) -> Dict[str, int]:
    """상태판이 읽는 정보품질 숫자를 single-pass canonical 기준으로 채운다.

    v510은 final_rows는 정상 생산했지만 /health 상단 정보요약이 0/전체로 표시됐다.
    이유는 예전 status/summary reader가 기대하던 quote_ready_count/micro_ready_count/full_info_ready_count
    계열 필드를 publish하지 않았기 때문이다. 여기서는 후보 조건을 바꾸지 않고, 같은 입력 feature/orderflow에서
    정보품질 숫자만 확정한다.
    """
    evaluated = len(feature_list)
    quote_ready = 0
    micro_ready = 0
    both_ready = 0
    orderflow_attached = 0
    price_ready = 0
    for row in feature_list:
        t = ticker_norm(row.get("ticker"))
        of = ofmap.get(t, {}) if t else {}
        has_price = _v510_num(row.get("current_price"), row.get("price"), of.get("quote_price"), of.get("current_price"), default=0.0) > 0
        quote = bool(of.get("quote_fresh") or of.get("ws_fresh") or has_price)
        micro = bool(of.get("micro_fresh") or of.get("orderflow_fresh") or of.get("buy_ratio") is not None or of.get("spread_pct") is not None)
        attached = bool(of)
        if has_price:
            price_ready += 1
        if attached:
            orderflow_attached += 1
        if quote:
            quote_ready += 1
        if micro:
            micro_ready += 1
        if quote and micro:
            both_ready += 1
    return {
        "price_ready_count": price_ready,
        "quote_ready_count": quote_ready,
        "market_price_ready_count": price_ready,
        "micro_ready_count": micro_ready,
        "full_info_ready_count": both_ready,
        "both_ready_count": both_ready,
        "orderflow_attached_count": orderflow_attached,
    }


def _v512_display_rows(rows: List[Dict[str, Any]], maxn: int = 80) -> List[Dict[str, Any]]:
    """candidate_reason/s1_lifecycle이 모두 볼 수 있는 표시 row aliases를 만든다.

    명령어 handler마다 top_candidates/items/rows/display_rows 중 서로 다른 key를 보던 구버전 흔적이 남아 있으므로,
    v512에서는 같은 canonical row를 여러 alias로만 publish한다. 새 계산 경로는 만들지 않는다.
    """
    out: List[Dict[str, Any]] = []
    for r in rows[:maxn]:
        rr = dict(r)
        rr.setdefault("display_name", rr.get("ticker") or rr.get("symbol"))
        rr.setdefault("stage", _v510_stage(rr))
        rr.setdefault("s_stage", _v510_stage(rr))
        rr.setdefault("strategy_label", rr.get("strategy") or rr.get("strategy_name") or rr.get("paper_strategy_label"))
        rr.setdefault("strategy_name", rr.get("strategy_label"))
        rr.setdefault("block_reasons", rr.get("s_stage_reasons") or rr.get("reasons") or [])
        rr.setdefault("missing_info", rr.get("missing_info") or [])
        rr.setdefault("structure_tags", rr.get("structure_tags") or rr.get("quality_structure_tags") or [])
        rr.setdefault("risk_tags", rr.get("risk_tags") or rr.get("quality_risk_tags") or [])
        out.append(rr)
    return out

# v533 removed legacy unused function: _v512_save_aliases

def _v512_enrich_summary_pointers(summary: Dict[str, Any], compact: Dict[str, Any], life: Dict[str, Any], recheck: Dict[str, Any]) -> None:
    """Expose cache pointers expected by older main-bot status readers."""
    ts = compact.get("updated_ts")
    summary.update({
        "candidate_reason_compact_cache_schema": compact.get("schema"),
        "candidate_reason_compact_cache_ts": ts,
        "candidate_reason_compact_cache_updated_ts": ts,
        "candidate_reason_compact_cache_status": compact.get("status", "fresh"),
        "candidate_reason_compact_cache_count": compact.get("candidate_count", 0),
        "candidate_reason_compact_cache_display_count": compact.get("display_count", 0),
        "candidate_reason_cache_file": str(CANDIDATE_REASON_COMPACT_CACHE),
        "s1_lifecycle_schema": life.get("schema"),
        "s1_lifecycle_ts": life.get("updated_ts"),
        "s1_lifecycle_worker": life.get("worker"),
        "s1_lifecycle_fresh_count": life.get("fresh_count", 0),
        "s1_lifecycle_raw_count": life.get("raw_count", 0),
        "s1_lifecycle_cache_file": str(S1_LIFECYCLE_TRACE),
        "recheck_cache_schema": recheck.get("schema"),
        "recheck_cache_ts": recheck.get("updated_ts"),
        "recheck_candidate_count": recheck.get("candidate_count", 0),
    })


def _v513_legacy_candidate_reason_top(display_rows: List[Dict[str, Any]], limit: int = 10) -> List[Dict[str, Any]]:
    """Build the old /candidate_reason top_candidates shape from the same canonical display rows.

    Main-bot v468 is strict about the compact-cache schema/key shape.  We keep one
    canonical row source, but publish the compact payload in the legacy-compatible
    shape so the command does not report "cache 없음" while health/lifecycle can
    still read the same final rows.
    """
    top: List[Dict[str, Any]] = []
    for rr in display_rows[:limit]:
        st = _v510_stage(rr)
        fail = rr.get("block_reasons") or rr.get("s_stage_reasons") or rr.get("reasons") or []
        miss = rr.get("missing_info") or rr.get("entry_missing_info") or []
        risk = rr.get("risk_tags") or rr.get("structure_risk_tags") or []
        metrics = {
            "price_reaction_pct": _v510_num(rr.get("price_reaction_pct"), default=0.0),
            "spread_pct": _v510_num(rr.get("spread_pct"), default=0.0),
            "slippage_pct": _v510_num(rr.get("slippage_pct"), rr.get("spread_pct"), default=0.0),
            "buy_ratio": _v510_num(rr.get("buy_ratio"), default=0.0),
            "buy_sustain_1m": _v510_num(rr.get("buy_sustain_1m"), rr.get("buy_ratio"), default=0.0),
        }
        top.append({
            "ticker": ticker_norm(rr.get("ticker") or rr.get("market") or rr.get("symbol")),
            "stage": st,
            "s_stage": st,
            "strategy": str(rr.get("strategy_label") or rr.get("strategy") or rr.get("strategy_key") or "-"),
            "strategy_key": str(rr.get("strategy_key") or rr.get("paper_strategy_key") or "-"),
            "score": round(_v510_num(rr.get("score"), default=0.0), 2),
            "decision": str(rr.get("recheck_state") or rr.get("review_decision") or "-"),
            "block_reasons": _v510_uniq([str(x) for x in fail], 4),
            "missing_info": _v510_uniq([str(x) for x in miss], 3),
            "metrics": metrics,
            "metric_spine_source": "v513_canonical_final_rows",
            "needed_recovery": rr.get("needed_recovery") or rr.get("need_recovery") or [],
            "relative_context": rr.get("relative_context") or {},
            "structure_tags": rr.get("structure_tags") or [],
            "structure_good_tags": rr.get("structure_good_tags") or rr.get("structure_tags") or [],
            "structure_risk_tags": risk,
            "risk_tags": risk,
            "structure_fit": rr.get("structure_fit") or rr.get("structure_summary") or ("구조위험" if risk else "구조관찰"),
            "structure_summary": rr.get("structure_summary") or "",
            "market_regime_tags": rr.get("market_regime_tags") or [],
            "market_risk_tags": rr.get("market_risk_tags") or [],
            "market_regime_summary": rr.get("market_regime_summary") or "",
            "snapshot_ts": rr.get("updated_ts") or rr.get("created_at") or now_ts(),
            "snapshot_text": rr.get("updated_text") or now_text(),
            "fresh_for_paper": True,
        })
    return top

def _v510_publish(rows: List[Dict[str, Any]], rejects: List[Dict[str, Any]], priority_requests: List[Dict[str, Any]], evaluated: int, cycle_ts: float, info_quality: Optional[Dict[str, int]] = None) -> Dict[str, Any]:
    nowv = now_ts()
    counts = _v510_counts(rows)
    info_quality = info_quality or {}
    display_rows = _v512_display_rows(rows, 120)
    lane_counts: Dict[str, int] = {}
    for r in rows:
        lane = str(r.get("canonical_lane") or "base")
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    s1_missing_counter = Counter()
    for r in rows:
        for x in (r.get("s1_missing_names") or []):
            s1_missing_counter[str(x)] += 1
    s1_near_count = sum(1 for r in rows if bool(r.get("s1_near_miss")))
    write_jsonl_atomic(PAPER_LATEST, rows)
    # Runtime OPEN does not append to archive. Archive/trade log stays paper-owned/history-only.
    priority_requests = sorted(priority_requests, key=lambda x: _v510_num(x.get("priority"), default=0.0), reverse=True)
    targets = list(dict.fromkeys([ticker_norm(r.get("ticker")) for r in priority_requests if ticker_norm(r.get("ticker"))]))
    pr_obj = {"schema": "strategy_priority_requests_v512", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "request_count": len(priority_requests), "targets": targets, "requests": priority_requests, "buckets": {}}
    for pr in priority_requests:
        b = str(pr.get("bucket") or "-"); pr_obj["buckets"][b] = pr_obj["buckets"].get(b, 0) + 1
    save_json(PRIORITY_REQ, pr_obj)
    reason_top = _v510_reason_top(rows)
    summary = {"schema": V510_SCHEMA, "version": VERSION, "main_version": MAIN_VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "evaluated": evaluated, "paper_latest_count": len(rows), "s_count": len(rows), "s_stage_counts": counts, "stage_counts": counts, "s1_count": counts.get("S1",0), "s2_count": counts.get("S2",0), "s3_count": counts.get("S3",0), "lane_counts": lane_counts, "reason_top": reason_top, "s1_diagnostic": {"schema":"v532_canonical_entry_decision", "near_miss_count": s1_near_count, "missing_top": dict(s1_missing_counter.most_common(8))}, "target_count": len(targets), "priority_request_count": len(priority_requests), "events": display_rows[:20], "sample": display_rows[:20], "top_candidates": display_rows[:20], "last_sec": round(nowv - cycle_ts, 3), "policy": "v548: canonical S2 recheck spine fixed; main reads hub cache only. 조건값/청산/자동매수 변경 없음."}
    summary.update(info_quality)
    summary["freshness_overlay"] = {"schema": "v536_profile_simplified", "scanner_hot_cache_age_sec": round(_v521_file_age(SCANNER_HOT), 3), "orderflow_cache_age_sec": round(_v521_file_age(ORDERFLOW), 3)}
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    legacy_top = _v513_legacy_candidate_reason_top(display_rows, limit=10)
    compact = {"schema": "candidate_reason_compact_cache_v473_metric_spine", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "status": "fresh", "evaluated": evaluated, "paper_latest_count": len(rows), "candidate_count": len(rows), "raw_candidate_count": len(rows), "stale_candidate_count": 0, "stale_s1_ignored_count": 0, "display_count": len(display_rows), "s_stage_counts": counts, "stage_counts": counts, "reason_top": reason_top, "missing_info_top": [x for x in reason_top if "정보" in x.get("reason", "")], "metric_spine_source_top": [{"reason": "v513_canonical_final_rows", "count": len(rows)}], "top_candidates": legacy_top, "display_rows": display_rows, "display_candidates": display_rows, "candidates": display_rows, "items": display_rows, "rows": display_rows, "top": legacy_top, "policy": summary["policy"]}
    compact.update(info_quality)
    compact["top_rows"] = legacy_top
    compact["display_candidates"] = compact.get("display_rows", [])
    compact["source_file"] = str(PAPER_LATEST)
    compact["source_policy"] = summary["policy"]
    summary["legacy_candidate_reason_alias_publish"] = False  # v525: disabled
    re_rows = [r for r in rows if _v510_stage(r) in ("S2", "S3")]
    re_state_counts: Dict[str, int] = {}
    for r in re_rows:
        st = "위험우선" if r.get("risk_tags") else ("유연재확인" if _v510_stage(r) == "S2" else "추적중")
        r["recheck_state"] = st
        re_state_counts[st] = re_state_counts.get(st, 0) + 1
    recheck_display = _v512_display_rows(re_rows, 160)
    recheck = {"schema": "recheck_candidates_cache_v513", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "candidate_count": len(re_rows), "state_counts": re_state_counts, "top": recheck_display[:80], "top_candidates": recheck_display[:80], "display_rows": recheck_display, "rows": recheck_display, "promotion_summary": {"s1_promotion_count": counts.get("S1",0), "policy": "S2/S3 재확인은 paper OPEN이 아니다."}}
    summary["legacy_recheck_cache_publish"] = False  # v525: disabled; target_router reads paper_latest
    summary["legacy_recheck_state_publish"] = False  # v525 disabled
    s1_rows = [r for r in display_rows if _v510_stage(r)=="S1"]
    life = {"schema": "s1_lifecycle_trace_v513_canonical", "version": VERSION, "worker": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "current_s1_count": counts.get("S1",0), "current_s2_count": counts.get("S2",0), "current_s3_count": counts.get("S3",0), "recent_s1_count": counts.get("S1",0), "paper_waiting_count": 0, "paper_pre_downgrade_count": 0, "paper_block_count": 0, "paper_final_block_count": 0, "expired_s1_ignored_count": 0, "fresh_count": len(rows), "raw_count": len(rows), "current_fresh_count": len(rows), "current_raw_count": len(rows), "fresh_candidate_count": len(rows), "raw_candidate_count": len(rows), "counts": counts, "stage_counts": counts, "current_s1": s1_rows, "current_s1_rows": s1_rows, "paper_waiting": [], "paper_pre_downgrade": [], "paper_blocked": [], "paper_final_blocked": [], "expired_s1_ignored": [], "flow_rows": display_rows[:80], "recent_flow": display_rows[:80], "recent_rows": display_rows[:80], "top": display_rows[:80], "rows": display_rows, "policy": "candidate_reason/s1_lifecycle/summary all read the same final_rows."}
    summary["legacy_s1_lifecycle_alias_publish"] = False  # v525: disabled
    summary["legacy_s1_lifecycle_state_publish"] = False  # v525 disabled
    # v512: summary/health readers also need direct pointers to compact/lifecycle caches.
    _v512_enrich_summary_pointers(summary, compact, life, recheck)
    save_json(SUMMARY, summary)
    save_json(REJECT, {**summary, "reject_count": len(rejects), "reject_sample": rejects[:30]})
    can = {"schema": "strategy_canonical_summary_v513", "version": VERSION, "updated_ts": nowv, "cycle_started_ts": cycle_ts, "cycle_elapsed_sec": round(nowv-cycle_ts,3), "s_stage_counts": counts, "paper_latest_count": len(rows), "candidate_reason": {"schema": compact["schema"], "updated_ts": nowv, "candidate_count": len(rows)}, "recheck": {"schema": recheck["schema"], "updated_ts": nowv, "candidate_count": len(re_rows)}, "s1_lifecycle": {"schema": life["schema"], "updated_ts": nowv, "current_s1_count": counts.get("S1",0)}, "source_policy": summary["policy"]}
    save_json(CANONICAL_STRATEGY_SUMMARY, can)
    price_ready_count = sum(1 for r in rows if _v510_num(r.get("current_price"), r.get("entry_price"), r.get("price"), default=0.0) > 0)
    save_json(HANDOFF, {"schema": "paper_handoff_status_v525", "version": VERSION, "updated_ts": nowv, "updated_text": now_text(nowv), "latest_count": len(rows), "stage_counts": counts, "lane_counts": lane_counts, "price_ready_count": price_ready_count, "source": "paper_candidates_latest", "archive_runtime_open": False, "old_latest_remix": False, "price_policy": "strategy seals current_price/entry_price/detected_price for paper_bot"})
    save_json(V510_TRACE, {"schema": V510_SCHEMA, "version": VERSION, "updated_ts": nowv, "elapsed_sec": round(nowv-cycle_ts,3), "evaluated": evaluated, "stage_counts": counts, "lane_counts": lane_counts, "reason_top": reason_top, "sample": rows[:12]})
    write_status("running", phase="cycle_done_v525", phase_note="v548 S2 재확인 spine + hub cache-only", phase_started_ts=cycle_ts, strategy_worker_version=VERSION, main_version=MAIN_VERSION, deploy_version=MAIN_DEPLOY_VERSION, evaluated=evaluated, row_count=evaluated, s_count=len(rows), paper_latest_count=len(rows), s1_count=counts.get("S1",0), s2_count=counts.get("S2",0), s3_count=counts.get("S3",0), target_count=len(targets), priority_request_count=len(priority_requests), last_sec=round(nowv-cycle_ts,3), status_route_schema="strategy_status_v548_recheck_spine_hub", **info_quality)
    return summary


def run_once() -> Dict[str, Any]:  # type: ignore[override]
    cycle_ts = now_ts()
    try:
        write_status("running", phase="evaluating_v544", phase_note="v529 S1 checklist inline publish 시작", strategy_worker_version=VERSION)
        fobj = load_json(FEATURE, {}) or {}
        raw_feature_list = feature_rows(fobj)
        hotmap = _v521_hot_map()
        feature_list = [_v521_overlay_feature(src, hotmap.get(ticker_norm(src.get("ticker") or src.get("market") or src.get("symbol")), {})) for src in raw_feature_list]
        ofmap = _v521_load_map_with_cache_age(ORDERFLOW, "orderflow")
        base_rows, rejects, reqs = _v510_base_lane(cycle_ts, feature_list, ofmap)
        spike_rows = _v510_spike_lane(cycle_ts, feature_list, ofmap)
        final_rows = _v510_merge_rows(base_rows + spike_rows, cycle_ts)
        info_quality = _v512_info_quality(feature_list, ofmap)
        # Requests from spike rows are added after merge so stale/blocked rows still get recheck/urgent targets if useful.
        for r in final_rows:
            t = ticker_norm(r.get("ticker"))
            if not t: continue
            bucket = "s1_candidate" if _v510_stage(r)=="S1" else ("spike_recheck" if str(r.get("canonical_lane"))=="spike" else "recheck_candidate")
            pri = 180 if _v510_stage(r)=="S1" else (130 if _v510_stage(r)=="S2" else 90)
            reqs.append({"ticker": t, "bucket": bucket, "priority": pri + _v510_num(r.get("score"), default=0.0), "need": ["quote", "micro"], "source": "strategy_worker_v529", "strategy_key": r.get("strategy_key"), "stage": _v510_stage(r), "reasons": r.get("s_stage_reasons", [])[:6], "updated_ts": cycle_ts})
        return _v510_publish(final_rows, rejects, reqs, len(feature_list), cycle_ts, info_quality)
    except Exception as exc:
        append_error(ERROR, "v513_run_once", exc)
        write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        raise


def main() -> None:  # type: ignore[override]
    write_status("running", phase="boot_v513", evaluated=0, s_count=0, target_count=0, last_sec=0, strategy_worker_version=VERSION)
    while True:
        try:
            run_once()
        except KeyboardInterrupt:
            write_status("stopping", strategy_worker_version=VERSION)
            raise
        except Exception as exc:
            append_error(ERROR, "loop_v512", exc)
            write_status("error", error=f"{exc.__class__.__name__}: {exc}", strategy_worker_version=VERSION)
        time.sleep(max(0.5, INTERVAL_SEC))


if __name__ == "__main__":
    main()
