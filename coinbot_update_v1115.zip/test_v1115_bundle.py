import ast
import collections
import copy
import hashlib
import importlib.util
import inspect
import json
import math
import os
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'strategy_worker_v1.007.py'
PREV_SRC = Path('/tmp/v1114/strategy_worker_v1.006.py')


def load_module(path: Path, name: str, base_dir: str):
    os.environ['TRADING_BOT_DIR'] = base_dir
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader
    spec.loader.exec_module(module)
    return module


def source_hash(func) -> str:
    return hashlib.sha256(inspect.getsource(func).encode('utf-8')).hexdigest()




def normalize_runtime_meta(obj):
    if isinstance(obj, dict):
        return {k: normalize_runtime_meta(v) for k, v in obj.items() if k not in ('version', 'build')}
    if isinstance(obj, list):
        return [normalize_runtime_meta(v) for v in obj]
    return obj

def top_level_duplicates(path: Path):
    tree = ast.parse(path.read_text())
    rows = collections.defaultdict(list)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            rows[node.name].append(node.lineno)
    return {k: v for k, v in rows.items() if len(v) > 1}


assert top_level_duplicates(SRC) == {}
text = SRC.read_text()
assert text.count('\ndef load_json(') == 1
assert text.count('\ndef save_json(') == 1
assert text.count('_v1115_structure_cache_save(') == 5  # helper definition + four call sites
assert text.count('_v1115_structure_cache_load({})') == 3

with tempfile.TemporaryDirectory() as td_new, tempfile.TemporaryDirectory() as td_old:
    current = load_module(SRC, 'strategy_v1115', td_new)
    previous = load_module(PREV_SRC, 'strategy_v1114_compare', td_old)
    assert current.VERSION == 'strategy_worker_v1.007'
    assert current.BUILD_LABEL == 'v1115_strategy_snapshot_single_writer_cleanup_2026-06-28'

    # Trading decision owners remain byte-identical to v1114.
    for name in (
        'apply_swing_entry_gate', '_v812_build_structure_board',
        'seal_canonical_candidate_keys', 'build_structure_lab', '_v925_row_price'
    ):
        assert source_hash(getattr(current, name)) == source_hash(getattr(previous, name)), name

    nowv = 1782656000.0
    base = {
        'ticker': 'AAA', 'market': 'KRW-AAA', 'symbol': 'AAA',
        'price': 100.0, 'current_price': 100.0, 'last_price': 100.0,
        's_stage': 'S2', 'stage': 'S2', 'candidate_stage': 'S2',
        'grade': 'S2', 'candidate_grade': 'S2', 'updated_ts': nowv,
        'candidate_input_fresh_ok_v908': True, 'open_eligible': False,
        'trigger': 101.0, 'invalid': 97.0, 'target': 110.0, 'target1': 110.0,
        'entry_context': {}, 'canonical_metric_row': {},
        'structure_levels': {}, 'block_reasons': [],
        'relative_strength': 1.2, 'money_flow_score': 1.1,
        'buy_ratio': 0.55, 'price_reaction_score': 0.2,
    }
    rows = []
    for idx in range(16):
        row = copy.deepcopy(base)
        row['ticker'] = f'T{idx:03d}'
        row['market'] = 'KRW-' + row['ticker']
        row['symbol'] = row['ticker']
        rows.append(row)

    old_planned = previous._v554_apply_entry_plan_state(copy.deepcopy(rows), nowv)
    old_resealed, old_summary = previous._v732_reseal_common_uprising_promotions(old_planned, nowv)
    new_planned = current._v554_apply_entry_plan_state(copy.deepcopy(rows), nowv)
    new_resealed, new_summary = current._v732_reseal_common_uprising_promotions(new_planned, nowv)
    assert normalize_runtime_meta(new_resealed) == normalize_runtime_meta(old_resealed)
    assert normalize_runtime_meta(new_summary) == normalize_runtime_meta(old_summary)

    tx = current._V1115_STRUCTURE_TX_LAST
    assert tx['buffered_writes'] == 4
    assert tx['physical_writes'] == 1
    assert tx['writes_avoided'] == 3
    assert tx['flush_reason'] == 'promotion_reseal_complete'
    assert (Path(td_new) / 'clean_structure_snapshot_cache.json').exists()

    # All non-structure files still use the original single canonical helpers.
    probe = Path(td_new) / 'ordinary.json'
    current.save_json(probe, {'ok': 1})
    assert current.load_json(probe, {}) == {'ok': 1}

print('PASS v1115 bundle')
