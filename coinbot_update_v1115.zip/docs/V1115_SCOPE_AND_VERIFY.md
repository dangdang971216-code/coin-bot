# v1115 scope and verification

## Symptom
v1114 achieved a latest measured Strategy profile near 19.49 seconds, but `/flow_map` detected `DUPLICATE_TOP_LEVEL_DEF` for `load_json` and `save_json`.

## Actual cause
v1114 implemented the structure snapshot transaction by redefining the process-wide JSON helpers near the end of the Strategy module. Functional behavior worked, but the active source then had two top-level definitions for each helper.

## Fix
- Remove the process-wide overrides.
- Keep one canonical `load_json` and one canonical `save_json`.
- Route only the four `STRUCTURE_SNAPSHOT_CACHE` writers and three matching readers through dedicated transaction helpers.
- Preserve one final atomic commit per cycle.

## Not changed
- quality gate and rank
- trigger, invalid, target
- actual-entry RR, spread, slippage, costs
- OPEN 30 and cycle 3
- Paper/exit contract
- auto-buy OFF

## Server proof
- Strategy version `strategy_worker_v1.007`
- no `DUPLICATE_TOP_LEVEL_DEF`
- runtime mismatch 0
- new runtime errors 0
- compare 3 to 5 fresh Strategy cycles before closing the speed issue
