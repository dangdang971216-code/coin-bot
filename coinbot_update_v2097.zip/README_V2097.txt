코인봇 v2097 · 대수익 공통점·허용범위 감사판

목적
- 대수익을 너무 빨리 자르지 않도록, 실제 +5%·+10% CLOSED의 공통점과 허용 흔들림을 먼저 찾는다.
- 대수익과 MFE +1.5~5% 후 손실로 끝난 실패 유사형을 비교한다.
- MFE +5%까지 갔지만 최종 +2% 미만으로 끝난 missed runner를 별도 표시한다.
- 새 Shadow·새 원장 없이 Paper canonical exact CLOSED snapshot만 읽는다.

/runner_audit
- 전체 exact와 최근 200건을 따로 비교
- 최종 +5/+10%, MFE +5/+10%, 실패 유사형, missed runner cohort
- 실제 RR·목표공간·invalid 거리·추격·spread/slippage·가격반응·상대강도·돈흐름·매수비율/지속·시장상태 비교
- 전체와 최근에서 방향이 같은 공통점 후보만 별도 표시
- 대수익의 MAE·최종 반납·MFE 확보율·보유시간·목표공간 분포
- 손실상한 -1/-1.5/-2/-2.5/-3/-4%가 대수익 표본을 몇 건 자를 위험이 있는지 계산
- 대수익 TOP 12 exact 상세

중요
- MAE는 전체 보유 중 최저값이라 상승 전 눌림과 고점 뒤 반납을 분리하지 못한다.
- runner 자격·약세청산·재진입 조건은 이 결과만으로 바로 본선 적용하지 않는다.
- 서버 결과를 본 뒤 기존 Shadow에 검증식만 연결한다.

변경하지 않음
- Strategy 후보·구조선·trigger·invalid·target
- Paper 진입·청산·수익보호·재진입
- 기존 OPEN 계약과 v2086/v2089
- OPEN/CLOSED/decision/exact 원장
- 새 Shadow·generation·원장
- 자동매수 OFF

판정
- 로컬 py_compile·AST·synthetic import/fixture PASS
- 서버 적용·실제 runner 표본 판독 전 CHECK
