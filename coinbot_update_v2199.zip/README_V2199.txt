코인봇 v2199

목적
- Shadow 없이 기존 /trade_review 하나로 상승예측 식 변경 전 결과를 확인

수정
- Review worker 상태판이 없어도 strategy_v2_outcome_state_v2133.json과 strategy_v2_outcomes_v2133.jsonl을 직접 읽음
- exact event_key로 중복 제거
- 같은 봉인 입력과 같은 30m/1h/3h/6h MFE·MAE 정답에 v2193·v2198을 재계산
- 정확도, 통과 수, 통과 승률, 상승회수, 하락오판감소, 상승훼손, MFE·MAE, 낮은 정확도 입력 표시
- 원본 또는 계산식 연결 실패 시 FAIL. 정상 0표본으로 표시하지 않음

변경 없음
- v2198 상승예측 본선식
- 후보·S1·Paper 접수
- 구조선·Trigger·Invalid·Target·RR
- Paper 비용·청산·성과 초기화
- 모든 과거 원장
- 자동매수 OFF

LOCAL PASS / SERVER CHECK
