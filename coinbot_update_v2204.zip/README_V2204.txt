v2204 review-only hotfix.
Root cause: Review boot state ACTIVE did not satisfy Guard ready contract running/ready.
Scope: health boot-state contract only. Prediction/structure/Paper/exit/reset/ledger unchanged. Auto-buy OFF.
