코인봇 v2207
- v2206 Review 분석 계약은 그대로 재사용
- 실제 원인: Guard worker 적용만 별도 subprocess py_compile 경로를 사용했고, compile 상세를 최종 결과에서 숨김
- 수정: worker도 Guard 공통 in-process source compile(no pyc) 사용
- 복사 전 target SHA256, 복사 후 active SHA256, 서비스/PID/버전/sync를 모두 확인한 뒤 PASS
- Review v2.087 / Main v2.13.2172 / Guard v2.6.45
- 상승예측식·후보·구조·Paper·청산·원장 변경 없음
- 자동매수 OFF
