v1337 hybrid shadow filter read-only. Apply with /gupgrade_bundle. No live trading rule changes. Auto-buy OFF.
