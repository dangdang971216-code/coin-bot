v2170은 현재 실행서명·현재 candidate cycle만 본선 현재값으로 읽는다.
S1이 0개인 정상 cycle도 같은 candidate commit을 Paper가 ACK_ZERO_S1로 접수한다.
Scanner 현재 거래시장 변화는 제외 이유와 일시 자료대기를 분리하며, 과거 후보를 삭제하지 않는다.
후보품질은 v2169 1시간 first-touch 분석에서 가장 분리가 좋았던 큰흐름·구조 축 +0.341 하나만 반영했다.
Invalid·T1·Paper 비용·청산계약·과거 원장은 변경하지 않았다. 자동매수 OFF.
