# v1096 packaging closeout

## Root cause
`feature_worker_v0.6.py` and `strategy_worker_v0.997.py` existed in the v1095 ZIP, but the manifest declared them as unsupported top-level keys. The canonical bundle copier only copies main/guard/paper and entries under `workers`, so Feature was not copied to the server before the undeclared-file py_compile pass.

## Fix
The runtime source set is unchanged. Feature and Strategy are declared under the canonical `workers` map. v1095 remains an undeployed packaging failure; v1096 is the corrected application bundle.

## Server verification
1. `/gupgrade_bundle`
2. `/gquality_rebuild_v1095 240`
3. `/gworker_state`
4. `/gops_refresh`
5. Main: `/quality_rebuild_status`, `/quality_open_audit`, `/ops_focus`, `/errorlog`
6. Paper: `/pstatus`, `/perror`

Auto-buy remains OFF. No live ledgers are included.
