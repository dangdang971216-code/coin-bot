이 ZIP의 ledger 파일은 append/seed용입니다. 서버의 OPEN/CLOSED/trade_log/decision/change_verify 원장을 덮어쓰거나 삭제하지 않습니다.
