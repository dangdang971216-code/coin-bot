v1434 GQUICK_STRATEGY_SERVICE_NAME_FIX

목적
- /gquick 실행 시 NameError: STRATEGY_SERVICE 미정의 오류 수리.
- v1433의 명령 우선 접수/빠른 ACK 구조는 유지.

수정
- WORKER_SPECS["strategy"]["service"] 기준으로 STRATEGY_SERVICE 단일 상수 추가.
- /gquick 표시를 v1434로 갱신.

변경하지 않음
- 후보 흐름, S1/S2/S3, Paper 진입, OPEN limit, 실제 청산계약, 자동매수 OFF.
