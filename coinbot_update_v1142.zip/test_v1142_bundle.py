from __future__ import annotations
import json, zipfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'DEPLOY_BUNDLE.json').read_text())
assert manifest['version']=='v1142'
assert manifest['main']=='coinbot_main_v2_13_1109.py'
assert manifest['paper']=='paper_bot_v1.025.py'
assert manifest['guard']=='backga_guard_bot_v2_5_183.py'
assert manifest['workers']=={'review':'review_worker_v1.009.py'}
assert manifest['strategy_source_change'] is False and manifest['auto_buy'] is False
required=[manifest['main'],manifest['paper'],manifest['guard'],*manifest['workers'].values(),*manifest['support_files'],'DEPLOY_BUNDLE.json']
for name in required: assert (ROOT/name).exists(),name
for forbidden in ('paper_bot_open.json','paper_bot_closed.jsonl','paper_trade_log.json','paper_decision_state_v926.json','change_verify_ledger.jsonl','issue_ledger.jsonl'):
    assert not (ROOT/forbidden).exists(),forbidden
print(json.dumps({'ok':True,'required':len(required),'workers':manifest['workers']},ensure_ascii=False))
