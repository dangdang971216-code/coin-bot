from __future__ import annotations
import ast, hashlib, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def fh(path):
    tree=ast.parse(path.read_text())
    return {n.name:hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest() for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}

base=json.loads((ROOT/'BASELINE_FUNCTION_HASHES_V1141.json').read_text())
paper=fh(ROOT/'paper_bot_v1.025.py')
old=base['paper']['functions']
changed=sorted(k for k in set(old)|set(paper) if old.get(k)!=paper.get(k))
assert changed==['write_status__v1135'],changed
for name in ('load_control','update_position','select_candidates','process_open_positions_for_exit','commit_closed_position_exact'):
    assert paper.get(name)==old.get(name),(name,paper.get(name),old.get(name))
ps=(ROOT/'paper_bot_v1.025.py').read_text()
for token in (
    '"max_open_strict": 30','"max_new_per_cycle": 3','"candidate_ttl_sec": 120',
    '"swing_emergency_stop_pct": -2.50','"swing_no_progress_minutes": 360',
    '"swing_trailing_trigger_pct": 2.00','"swing_trailing_giveback_pct": 0.80',
    'effective_control_contract_v1142','strategy_formula_changed\':False','exit_formula_changed\':False'
): assert token in ps,token
assert not (ROOT/'strategy_worker_v1.014.py').exists()
rs=(ROOT/'review_worker_v1.009.py').read_text()
for token in (
    'candidate_standard_reference_state_v1142.json','candidate_standard_reference_ledger_v1142.jsonl',
    'first 30 unique fresh qualified occurrences are immutable reference','candidate_reference_ready','PRELIM_TRIGGER_TO_OPEN_DELAY',
    "verdict='CHECK_SAMPLE'","critical_source_missing","source_gap_count",
    "'legacy_single_snapshot_reference':'REFERENCE_ONLY'"
): assert token in rs,token
ms=(ROOT/'coinbot_main_v2_13_1109.py').read_text()
for token in ('수익형 v2.13.1109','guard_v2.5.183_candidate_standard_truth_v1142_2026-06-29','[판정 준비도]','[예비 신호 · 확정판정 아님]','[원천 누락 상세]'):
    assert token in ms,token
gs=(ROOT/'backga_guard_bot_v2_5_183.py').read_text()
for token in ('guard_v2.5.183_candidate_standard_truth_v1142_2026-06-29','ops_candidate_standard_contract_v1142','CHECK_SAMPLE is expected collection','elif cs_confirmed'):
    assert token in gs,token
inv=json.loads((ROOT/'TRADING_RULES_INVARIANT_V1142.json').read_text())
assert inv['auto_buy'] is False and inv['strategy_source_in_bundle'] is False
assert all(inv[k] is False for k in ('strategy_formula_change','quality_formula_change','rank_formula_change','candidate_ttl_change','trigger_contract_change','invalid_formula_change','target_formula_change','rr_formula_change','slippage_formula_change','exit_formula_change','open_limit_change','cycle_limit_change','baseline_rewrite','protected_ledger_change'))
print(json.dumps({'ok':True,'paper_changed_functions':changed,'strategy_in_bundle':False,'auto_buy':False},ensure_ascii=False))
