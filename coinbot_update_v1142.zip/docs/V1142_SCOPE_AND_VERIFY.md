# v1142 scope

## Root cause
v1141 used one mutable candidate snapshot as a quality baseline. `occurrence_age` was recalculated from wall clock and `chase` used a moving current price. With only 11 gate-pass rows and 2 fresh CLOSED, the board could confirm `EXECUTION_DEGRADED`. It also read raw Paper control values and hid nested source gaps.

## New mainline
- Existing v1141 contract baseline remains append-only.
- Candidate quality reference collects unique fresh qualified occurrences.
- First 30 events are the immutable reference; latest 30 are the rolling comparison.
- Before readiness, final cause is `CHECK_SAMPLE`; warnings are preliminary only.
- Paper owns and publishes the effective control contract.
- Review owns read-only aggregation and reference/decision state.
- Guard maps confirmed faults only; expected collection does not become an error.
- Main renders readiness, preliminary signals, source gaps and effective Paper contract.

## Not changed
Strategy source, candidate generation, Gate/rank, TTL value, trigger/invalid/target/RR, spread/slippage rules, selector, OPEN/cycle limits, exit formulas, protected ledgers and auto-buy OFF.

## Server proof
1. Paper status exposes effective contract with max OPEN 30 and cycle 3.
2. `/candidate_standard` shows `CHECK_SAMPLE`, candidate reference `COLLECTING n/30`, and no confirmed `EXECUTION_DEGRADED`.
3. Same occurrence rows do not increase reference age after time passes.
4. Nested source gaps are nonzero when timestamp/market/shadow evidence is absent.
5. Guard has no `CANDIDATE_STANDARD_EXECUTION_DEGRADED` unless confirmed flags exist.
6. No new runtime error.
