from __future__ import annotations
import importlib.util, json, os, shutil, tempfile, time
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def write_json(path,obj):
    path.write_text(json.dumps(obj,ensure_ascii=False),encoding='utf-8')

def candidate(i, now, scale=1.0, with_path=True):
    price=100.0+i*0.01; trigger=99.8+i*0.01; invalid=98.4+i*0.01; target=104.0+i*0.01
    event=now-5-(i%3)
    row={
      'ticker':f'T{i:03d}','price':price,'entry_price':price,'open_eligible':True,'swing_quality_rank_score':70*scale,
      'price_reaction_pct':0.8*scale,'relative_strength_pct':1.2*scale,'money_flow_score':70*scale,'buy_ratio':0.65*scale,'buy_sustain_1m':0.7*scale,
      'swing_quality_gate':{'hard_pass':True,'rank_score':70*scale,'confirmation_count':3},
      'swing_entry_gate_v977':{'hard_pass':True,'risk_reward':2.5*scale,'target_room_pct':4.0*scale,'spread_pct':0.25/scale,'confirmed_slippage_pct':0.05/scale,'decision_key':f'dec-{i}',
        'invalid_price':invalid,'target_price':target,'updated_ts':now,
        'structure_plan':{'frozen_ts':now-100,'trigger':{'source':'execution_resistance','source_key':'m15_high','tf':'15m','rounded_price':trigger},'invalid':{'source':'setup_support','source_key':'h1_low','tf':'1h','rounded_price':invalid},'target':{'source':'major_resistance','source_key':'h4_high','tf':'4h','rounded_price':target}}},
      'trigger_occurrence_v1037':{'event_ts':event,'candidate_key':f'cand-{i}','decision_key':f'dec-{i}','trigger_price':trigger,'contract_ready_at_cross':True},
      'strategy':'leader_flow' if i%2 else 'breakout','updated_ts':now,
    }
    if with_path:
        row.update({'quality_pass_ts':event+0.2,'s1_seen_ts':event+0.4,'paper_received_ts':event+0.5})
    return row

def closed(i,epoch,now):
    r=candidate(i,now)
    event=r['trigger_occurrence_v1037']['event_ts']
    r.update({'performance_epoch_id':epoch,'actual_entry_price':r['entry_price'],'opened_at':event+0.6,'closed_at':event+90,
              'mfe_pct':2.2,'mae_pct':-1.0,'net_pnl_pct':0.7,'giveback_pct':1.5,'hold_sec':89.4})
    return r

def bind_review(r,td):
    mapping={
       'CANDIDATE_STANDARD_CONTRACT_V1141':'clean_candidate_standard_contract_v1141.json','CANDIDATE_STANDARD_STATUS_V1141':'candidate_standard_status_v1141.json','CANDIDATE_STANDARD_BASELINE_STATE_V1141':'candidate_standard_baseline_state_v1141.json','CANDIDATE_STANDARD_BASELINE_LEDGER_V1141':'candidate_standard_baseline_ledger_v1141.jsonl','CANDIDATE_STANDARD_DECISION_LEDGER_V1141':'candidate_standard_decision_ledger_v1141.jsonl','CANDIDATE_STANDARD_REFERENCE_STATE_V1142':'candidate_standard_reference_state_v1142.json','CANDIDATE_STANDARD_REFERENCE_LEDGER_V1142':'candidate_standard_reference_ledger_v1142.jsonl','PAPER_STATUS_V1141':'paper_bot_status.json','STRATEGY_STATUS_V1141':'clean_strategy_worker_status.json','PERFORMANCE_EPOCH_V1141':'paper_quality_rebuild_epoch_v1095.json','QUALITY_POLICY_V1141':'clean_quality_policy_comparison_status_v1125.json','STRUCTURE_REVIEW_V1141':'clean_structure_lab_review_status_v956.json','PAPER_LATEST':'paper_candidates_latest.jsonl','OPEN':'paper_bot_open.json','REGIME':'clean_market_regime_cache.json','CANONICAL_PERFORMANCE_V987':'canonical_performance_snapshot_v987.json','STATUS':'clean_review_worker_status.json','ERROR':'clean_review_worker_error.log'}
    for name,fn in mapping.items(): setattr(r,name,td/fn)

def main():
    td=Path(tempfile.mkdtemp(prefix='v1142_'))
    try:
      for src,dst in [
        ('review_worker_v1.009.py','review_worker_v1.009.py'),('coinbot_main_v2_13_1109.py','coinbot_main_v2_13_1109.py'),
        ('backga_guard_bot_v2_5_183.py','backga_guard_bot_v2_5_183.py'),('paper_bot_v1.025.py','paper_bot_v1.025.py')]:
        shutil.copy2(ROOT/src,td/dst)
      os.environ['TRADING_BOT_DIR']=str(td); os.environ['BOT_DIR']=str(td); os.environ['GUARD_BOT_TOKEN']='dummy'; os.environ['GUARD_CHAT_ID']='1'
      now=time.time(); epoch='post-reset:test'
      contract={'schema':'candidate_standard_contract_v1141','version':'strategy_worker_v1.013','strategy_source_sha256':'sha-a','contract_digest':'digest-a','timeframe_contract':{'major':{'timeframes':['4h','2h']},'setup':{'timeframes':['1h','30m']},'entry':{'timeframes':['15m','5m']},'execution':{'timeframes':['1m','quote']}},'active_structure_method':{'id':'ALT_SWING_V977_FROZEN_PLAN','used_for_entry_gate':True},'observation_only_structure_methods':[]}
      write_json(td/'clean_candidate_standard_contract_v1141.json',contract)
      baseline={'schema':'candidate_standard_baseline_state_v1141','active_baseline':{'baseline_id':'ALT_SWING_BASELINE_TEST','strategy_contract_digest':'digest-a','strategy_version':'strategy_worker_v1.013','strategy_source_sha256':'sha-a','approval_state':'USER_REQUESTED_LOCK_V1141','performance_state':'COLLECTING','candidate_reference':{'gate_pass_rows':11}},'last_decision_state':None,'last_contract_digest':'digest-a'}
      write_json(td/'candidate_standard_baseline_state_v1141.json',baseline)
      effective={'schema':'paper_effective_control_contract_v1142','state':'NORMAL','owner':'paper_bot.load_control','candidate_ttl_sec':120,'max_open_strict':30,'max_new_per_cycle':3,'new_open_paused':False,'exit_contract':{'swing_emergency_stop_pct':-2.5,'swing_no_progress_minutes':360,'swing_trailing_trigger_pct':2.0,'swing_trailing_giveback_pct':0.8,'time_exit_minutes':15}}
      write_json(td/'paper_bot_status.json',{'version':'paper_bot_v1.025','effective_control_contract_v1142':effective,'updated_ts':now})
      write_json(td/'paper_quality_rebuild_epoch_v1095.json',{'epoch_id':epoch,'state':'ACTIVE'})
      write_json(td/'clean_market_regime_cache.json',{'mode':'강함','breadth_pct':55,'market_strength':1.1})
      write_json(td/'clean_quality_policy_comparison_status_v1125.json',{'state':'EVIDENCE_READY','tracked_records':100,'false_pass_60m_count':8,'false_block_60m_count':2,'verdict':'CURRENT_STABLE','current':{'n':50},'improved':{'n':50}})
      write_json(td/'clean_structure_lab_review_status_v956.json',{'state':'ACTIVE'})
      write_json(td/'clean_strategy_worker_status.json',{'last_sec':12.3,'version':'strategy_worker_v1.013'})
      write_json(td/'paper_bot_open.json',[])
      write_json(td/'canonical_performance_snapshot_v987.json',{'rows':[]})
      r=load('rmod',td/'review_worker_v1.009.py'); r.BASE_DIR=td; bind_review(r,td)
      # Small sample must never become EXECUTION_DEGRADED, even when current price/clock moves.
      small=[candidate(i,now) for i in range(11)]
      board=r.update_candidate_standard_v1141(now,small,[closed(i,epoch,now) for i in range(2)])
      assert board['final_judgement']['state']=='CHECK_SAMPLE',board['final_judgement']
      assert board['final_judgement']['confirmed_flags']==[],board['final_judgement']
      assert board['baseline_identity']['candidate_reference_unique_n']==11
      first_age=((board['candidate_quality']['reference_state']))
      board_later=r.update_candidate_standard_v1141(now+600,small,[closed(i,epoch,now) for i in range(2)])
      assert board_later['baseline_identity']['candidate_reference_unique_n']==11
      ref=json.loads((td/'candidate_standard_reference_state_v1142.json').read_text())
      stored=list(ref.get('baseline_samples') or [])+list(ref.get('recent_samples') or [])
      assert stored and max(x['occurrence_age'] for x in stored)<120,stored[0]
      assert board_later['paper_contract']['max_open_strict']==30 and board_later['paper_contract']['max_new_per_cycle']==3
      assert board_later['paper_contract']['exit_contract']['time_exit_minutes']==15
      # Nested missing evidence must be counted, not hidden.
      write_json(td/'clean_market_regime_cache.json',{'mode':'강함'})
      write_json(td/'clean_quality_policy_comparison_status_v1125.json',{'state':'EVIDENCE_READY','tracked_records':100})
      gap_rows=[candidate(500+i,now+605,with_path=False) for i in range(5)]
      board_gap=r.update_candidate_standard_v1141(now+605,gap_rows,[])
      assert board_gap['section_completeness']['source_gap_count']>0,board_gap['source_gaps']
      assert board_gap['market_context']['state']=='PARTIAL_SOURCE'
      write_json(td/'clean_market_regime_cache.json',{'mode':'강함','breadth_pct':55,'market_strength':1.1})
      write_json(td/'clean_quality_policy_comparison_status_v1125.json',{'state':'EVIDENCE_READY','tracked_records':100,'false_pass_60m_count':8,'false_block_60m_count':2,'verdict':'CURRENT_STABLE','current':{'n':50},'improved':{'n':50}})
      # Add 40 new fresh unique occurrences and 60 exact closed rows with complete paths.
      rows=[candidate(100+i,now+610) for i in range(40)]
      closed_rows=[closed(1000+i,epoch,now+610) for i in range(60)]
      write_json(td/'canonical_performance_snapshot_v987.json',{'rows':closed_rows})
      board2=r.update_candidate_standard_v1141(now+610,rows,closed_rows)
      assert board2['candidate_quality']['reference_state']['state']=='READY',board2['candidate_quality']['reference_state']
      assert board2['candidate_quality']['baseline_comparison']['state']=='READY'
      assert board2['final_judgement']['state']=='NORMAL',board2['final_judgement']
      assert board2['structure_outcomes']['state']=='NORMAL' and board2['structure_outcomes']['combination_count']>=1
      assert board2['market_context']['state']=='NORMAL'
      assert board2['same_market_shadow']['comparison_ready'] is True
      assert board2['source_gaps']==[],board2['source_gaps']
      # First 30 reference samples remain immutable after more than 240 total events.
      ref_before=json.loads((td/'candidate_standard_reference_state_v1142.json').read_text())
      baseline_before=json.dumps(ref_before['baseline_samples'],sort_keys=True,ensure_ascii=False)
      many=[candidate(2000+i,now+615) for i in range(260)]
      r.update_candidate_standard_v1141(now+615,many,closed_rows)
      ref_after=json.loads((td/'candidate_standard_reference_state_v1142.json').read_text())
      assert json.dumps(ref_after['baseline_samples'],sort_keys=True,ensure_ascii=False)==baseline_before
      assert len(ref_after['baseline_samples'])==30 and len(ref_after['recent_samples'])==30
      assert ref_after['total_unique_count']>240
      # Contract change still dominates.
      contract['strategy_source_sha256']='sha-b'; write_json(td/'clean_candidate_standard_contract_v1141.json',contract); r._JSON_CYCLE_CACHE.clear()
      board3=r.update_candidate_standard_v1141(now+620,rows,closed_rows)
      assert board3['final_judgement']['state']=='SYSTEM_REGRESSION',board3['final_judgement']
      # Main render and Guard reader.
      m=load('mmod',td/'coinbot_main_v2_13_1109.py'); m.BASE_DIR=td; m.CANDIDATE_STANDARD_STATUS_V1141=td/'candidate_standard_status_v1141.json'
      rendered=m.render_candidate_standard_text()
      for token in ('[판정 준비도]','[예비 신호 · 확정판정 아님]','[원천 누락 상세]','[Paper 실행·청산 계약]','[최종 원인판정]'):
        assert token in rendered,token
      (td/'guard.env').write_text(f'BOT_DIR={td}\n',encoding='utf-8')
      g=load('gmod',td/'backga_guard_bot_v2_5_183.py'); g.BOT_DIR=td
      gc=g._ops_candidate_standard_contract_v1141(now+620)
      assert gc['schema']=='ops_candidate_standard_contract_v1142' and gc['candidate_reference_n']>=30,gc
      # Paper source must expose actual effective contract without changing formulas.
      paper=(td/'paper_bot_v1.025.py').read_text()
      for token in ('effective_control_contract_v1142',"'max_open_strict':int(fnum(effective_ctrl.get('max_open_strict'),default=30))","'time_exit_minutes':fnum(effective_ctrl.get('time_exit_minutes'),default=0.0)"):
        assert token in paper,token
      print(json.dumps({'ok':True,'small':board['final_judgement']['state'],'ready':board2['final_judgement']['state'],'system':board3['final_judgement']['state'],'reference_n':board2['baseline_identity']['candidate_reference_unique_n'],'source_gap_partial':board_gap['section_completeness']['source_gap_count'],'render_chars':len(rendered)},ensure_ascii=False))
    finally:
      shutil.rmtree(td,ignore_errors=True)

if __name__=='__main__': main()
