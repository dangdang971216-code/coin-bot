코인봇 v2149
1) 오래 지난 기존 OPEN을 삭제 없이 활성관리에서 퇴역하고 새 평가구간 시작
2) /version_score의 generic compact가 핵심 헤더·CLOSED·OPEN을 제거하여 Telegram 전송 전 무결성 실패하던 오류 수리
3) 단일/여러줄 명령 모두 버전스코어 핵심판 직접 1회 + 같은 snapshot 상세 TXT
4) 구조+상승예측 결합 큰틀, Paper 실행전용, 봉인 청산 유지
5) 자동매수 OFF
