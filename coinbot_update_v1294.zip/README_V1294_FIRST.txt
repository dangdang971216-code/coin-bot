Apply with /gupgrade_bundle. Then run /pstrategy_reset_v1294 in Paper bot to start a clean v1294 swing epoch.
