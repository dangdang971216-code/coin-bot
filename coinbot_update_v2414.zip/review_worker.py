#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from __future__ import annotations

import atexit
import copy
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import statistics
import time
import traceback
from collections import Counter, defaultdict
from itertools import combinations
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

BASE_DIR = Path(os.getenv('TRADING_BOT_DIR', '/home/dangdang971216/trading_bot'))
VERSION = 'review_worker_v2.179'
BUILD_LABEL = 'exact_sealed_formula_transport_current_eventset_recovery_2026-08-02'
MAIN_DEPLOY_VERSION = BUILD_LABEL
INTERVAL_SEC = max(5.0, float(os.getenv('REVIEW_WORKER_INTERVAL_SEC', '30')))
STATUS = BASE_DIR / 'clean_review_worker_status.json'
ERROR = BASE_DIR / 'clean_review_worker_error.log'
LOCK_PATH = BASE_DIR / 'runtime' / 'review_worker_singleton_v1121.lock'
SNAPSHOT = BASE_DIR / 'runtime' / 'current_candidate_snapshot_v2176.json'
CANDLE_CACHE = BASE_DIR / 'clean_candle_cache.json'
CANDLE_DELTA = BASE_DIR / 'clean_candle_delta_v1014.jsonl'
PAPER_EXACT_OPEN = BASE_DIR / 'paper_v2_exact_open_v2135.json'
PAPER_EXACT_CLOSED = BASE_DIR / 'paper_v2_exact_closed_v2135.jsonl'
LEDGER_DIR = BASE_DIR / 'rise_prediction_ledger'
ROLLUP_LEDGER = LEDGER_DIR / 'rollups.jsonl'
CHANGE_LEDGER = BASE_DIR / 'runtime' / 'change_verify_ledger.jsonl'
ISSUE_LEDGER = BASE_DIR / 'ledger' / 'issue_ledger_events.jsonl'
RAW_RETENTION_SEC = 5 * 24 * 3600.0
ROLLUP_RETENTION_SEC = 90 * 24 * 3600.0
HORIZONS = (('30m', 1800.0), ('1h', 3600.0), ('3h', 10800.0), ('6h', 21600.0), ('12h', 43200.0), ('24h', 86400.0))
def _load_canonical_strategy_core():
    path = BASE_DIR / 'strategy_v2_core.py'
    spec = importlib.util.spec_from_file_location('coinbot_canonical_strategy_core', path)
    if spec is None or spec.loader is None:
        raise RuntimeError('STRATEGY_CORE_IMPORT_SPEC_MISSING')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


_ACTIVE_STRATEGY_CORE = _load_canonical_strategy_core()
MATERIAL_NAMES = tuple(getattr(_ACTIVE_STRATEGY_CORE, 'RISE_MATERIAL_NAMES', ()))
CURRENT_PREDICTION_CONTRACT_ID = str(getattr(_ACTIVE_STRATEGY_CORE, 'TIMEFRAME_ROLE_CONTRACT_ID', '') or '')
BASELINE_PREDICTION_CONTRACT_ID = 'PRE_STRUCTURE_12'
CURRENT_TIMEFRAME_ROLE_FORMULA_ID = str(getattr(_ACTIVE_STRATEGY_CORE, 'TIMEFRAME_ROLE_FORMULA_ID', '') or '')
_STRATEGY_CORE_SIGNATURE = None
if not MATERIAL_NAMES or not CURRENT_PREDICTION_CONTRACT_ID or not CURRENT_TIMEFRAME_ROLE_FORMULA_ID:
    raise RuntimeError('CANONICAL_STRATEGY_CORE_CONTRACT_MISSING')

def _refresh_canonical_strategy_contract() -> bool:
    """Reload only Strategy contract metadata when the canonical alias changes.

    Review never calls the Strategy decision formula. This prevents a long-running
    Review process from keeping an old formula id after Strategy Core deployment.
    """
    global _ACTIVE_STRATEGY_CORE, MATERIAL_NAMES, CURRENT_PREDICTION_CONTRACT_ID
    global CURRENT_TIMEFRAME_ROLE_FORMULA_ID, _STRATEGY_CORE_SIGNATURE
    path = BASE_DIR / 'strategy_v2_core.py'
    stat = path.stat()
    signature = (int(stat.st_mtime_ns), int(stat.st_size))
    if _STRATEGY_CORE_SIGNATURE == signature:
        return False
    module = _load_canonical_strategy_core()
    names = tuple(getattr(module, 'RISE_MATERIAL_NAMES', ()))
    contract = str(getattr(module, 'TIMEFRAME_ROLE_CONTRACT_ID', '') or '')
    formula = str(getattr(module, 'TIMEFRAME_ROLE_FORMULA_ID', '') or '')
    if not names or not contract or not formula:
        raise RuntimeError('CANONICAL_STRATEGY_CORE_CONTRACT_MISSING')
    _ACTIVE_STRATEGY_CORE = module
    MATERIAL_NAMES = names
    CURRENT_PREDICTION_CONTRACT_ID = contract
    CURRENT_TIMEFRAME_ROLE_FORMULA_ID = formula
    _STRATEGY_CORE_SIGNATURE = signature
    return True

_refresh_canonical_strategy_contract()
PREVIOUS_PREDICTION_CONTRACT_ID = 'PREVIOUS_CONTRACT'
OLD_RISE_DERIVED_PATHS = (
    BASE_DIR / 'strategy_v2_outcome_state_v2133.json',
    BASE_DIR / 'strategy_v2_outcome_status_v2133.json',
    BASE_DIR / 'strategy_v2_outcomes_v2133.jsonl',
    BASE_DIR / 'strategy_v2_actual_exact_status_v2168.json',
    BASE_DIR / 'prediction_material_recovery_status_v2339.json',
    BASE_DIR / 'runtime' / 'review_incremental_state.json',
    BASE_DIR / 'runtime' / 'review_incremental_snapshot.json',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-wal',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-shm',
    BASE_DIR / 'runtime' / 'review_exact_day_cache_v2220.sqlite3-journal',
)

_LOCK_FH = None
_STATE_LOADED = False
_EVENTS: Dict[str, Dict[str, Any]] = {}
_LEGACY_EVENT_KEYS: set[str] = set()
_OUTCOMES: set[Tuple[str, str]] = set()
_OUTCOME_ROWS: Dict[Tuple[str, str], Dict[str, Any]] = {}
_ROLLED_DATES: set[str] = set()
_FINALIZED_DATES: set[str] = set()
_LAST_MAINTENANCE_DAY: Optional[str] = None
_CANDLE_SIGNATURE: Optional[Tuple[int, int]] = None
_CANDLE_INDEX: Dict[str, Dict[str, List[Dict[str, float]]]] = {}
_CANDLE_COUNT = 0
_COLLECTION_START_TS: Optional[float] = None


def now_ts() -> float:
    return time.time()


def now_text(ts: Optional[float] = None) -> str:
    return time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(ts or now_ts()))

def kst_text(ts: Optional[float]) -> Optional[str]:
    if ts is None:
        return None
    return time.strftime('%Y-%m-%d %H:%M:%S KST', time.gmtime(float(ts) + 9 * 3600.0))


def num(value: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if value is None or value == '' or isinstance(value, bool):
            return default
        result = float(value)
        return result if math.isfinite(result) else default
    except Exception:
        return default


def ticker(value: Any) -> str:
    return str(value or '').upper().strip().replace('KRW-', '').replace('_KRW', '').replace('/KRW', '')


def load_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return default


def atomic_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f'.{path.name}.{os.getpid()}.{time.time_ns()}.tmp')
    with tmp.open('w', encoding='utf-8') as handle:
        json.dump(obj, handle, ensure_ascii=False, separators=(',', ':'))
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(tmp, path)


def append_jsonl(path: Path, row: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
        handle.flush()
        os.fsync(handle.fileno())


def read_jsonl(path: Path) -> Iterable[Dict[str, Any]]:
    if not path.exists():
        return []
    rows = []
    try:
        with path.open('r', encoding='utf-8', errors='ignore') as handle:
            for line in handle:
                try:
                    item = json.loads(line)
                except Exception:
                    continue
                if isinstance(item, dict):
                    rows.append(item)
    except Exception:
        return []
    return rows


def append_error(where: str, exc: BaseException) -> None:
    ERROR.parent.mkdir(parents=True, exist_ok=True)
    with ERROR.open('a', encoding='utf-8') as handle:
        handle.write(f'[{now_text()}] {where}: {type(exc).__name__}: {exc}\n')
        handle.write(traceback.format_exc() + '\n')


def day_key(ts: float) -> str:
    return time.strftime('%Y-%m-%d', time.localtime(ts))


def raw_path(date_text: str) -> Path:
    return LEDGER_DIR / f'{date_text}.jsonl'


def file_signature(path: Path) -> int:
    try:
        stat = path.stat()
        return stat.st_mtime_ns ^ stat.st_size
    except OSError:
        return 0


def acquire_lock() -> None:
    global _LOCK_FH
    LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    handle = LOCK_PATH.open('a+', encoding='utf-8')
    try:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except BlockingIOError:
        raise SystemExit(0)
    handle.seek(0)
    handle.truncate()
    handle.write(json.dumps({'pid': os.getpid(), 'version': VERSION, 'build': BUILD_LABEL, 'ts': now_ts()}))
    handle.flush()
    _LOCK_FH = handle
    atexit.register(lambda: handle.close() if not handle.closed else None)


def _candidate_rows(snapshot: Any) -> List[Dict[str, Any]]:
    if not isinstance(snapshot, dict):
        return []
    rows = snapshot.get('rows')
    return [dict(row) for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []


def _rise_input(row: Dict[str, Any]) -> Dict[str, Any]:
    value = row.get('rise_prediction_input')
    if isinstance(value, dict):
        return value
    contract = row.get('trade_path_contract_v2149') if isinstance(row.get('trade_path_contract_v2149'), dict) else {}
    prediction = contract.get('prediction') if isinstance(contract.get('prediction'), dict) else {}
    value = prediction.get('rise_prediction_input')
    return value if isinstance(value, dict) else {}



def _clip_probability(value: float) -> float:
    return max(1.0, min(99.0, float(value)))


def _quantile(values: List[float], fraction: float) -> Optional[float]:
    clean=sorted(float(value) for value in values if num(value) is not None)
    if not clean:
        return None
    if len(clean)==1:
        return clean[0]
    pos=(len(clean)-1)*max(0.0,min(1.0,float(fraction)))
    lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi:
        return clean[lo]
    return clean[lo]+(clean[hi]-clean[lo])*(pos-lo)


def _model_material_value(value: Any) -> Tuple[str, Any]:
    numeric=num(value)
    if numeric is not None:
        return 'numeric', float(numeric)
    if isinstance(value,dict):
        risk=str(value.get('risk_state') or 'UNKNOWN')
        context=str(value.get('context_state') or 'UNKNOWN')
        concentration=num(value.get('turnover_concentration_top10_pct'))
        concentration_band='UNKNOWN' if concentration is None else ('HIGH' if concentration>=65 else 'MID' if concentration>=40 else 'LOW')
        return 'categorical', f'RISK_{risk}|CONTEXT_{context}|CONCENTRATION_{concentration_band}'
    if value is None:
        return 'missing', None
    return 'categorical', str(value)


def _numeric_bucket(value: float, edges: List[float]) -> str:
    if len(edges)<3:
        return 'ALL'
    if value<=edges[0]: return 'Q1'
    if value<=edges[1]: return 'Q2'
    if value<=edges[2]: return 'Q3'
    return 'Q4'


def _posterior_probability(positive: float, total: float, base_probability: float, prior_strength: float=8.0) -> float:
    if total<=0:
        return _clip_probability(base_probability*100.0)
    return _clip_probability((positive+base_probability*prior_strength)/(total+prior_strength)*100.0)


def _sealed_estimated_cost_pct(event: Dict[str,Any]) -> Tuple[float,str]:
    obs=event.get('execution_cost_observation') if isinstance(event.get('execution_cost_observation'),dict) else {}
    roundtrip=num(obs.get('roundtrip_cost_pct'))
    if roundtrip is not None and roundtrip>=0:
        return float(roundtrip),'SEALED_ROUNDTRIP_COST'
    values=[num(obs.get('spread_pct')),num(obs.get('slippage_pct')),num(obs.get('fee_pct'))]
    ready=[max(0.0,float(value)) for value in values if value is not None]
    if ready:
        return sum(ready),'SEALED_AVAILABLE_COST_PARTS'
    return 0.0,'COST_NOT_AVAILABLE_RAW_RETURN'


def _scoring_net_return(event: Dict[str,Any], outcome: Dict[str,Any]) -> Tuple[Optional[float],str]:
    raw=num(outcome.get('final_return_pct'))
    if raw is None:
        return None,'RETURN_MISSING'
    cost,basis=_sealed_estimated_cost_pct(event)
    return float(raw)-float(cost),basis

def _target_observations(target_name: str, nowv: float) -> List[Tuple[Dict[str,Any], Dict[str,Any], bool]]:
    horizon='3h' if target_name in {'probability_3h','late_capture_risk'} else '6h'
    rows=[]
    for (event_key,row_horizon),outcome in _OUTCOME_ROWS.items():
        if row_horizon!=horizon or str(outcome.get('outcome_state') or '')!='READY':
            continue
        event=_EVENTS.get(str(event_key))
        # Current live probabilities learn only from the prediction-first
        # 12-material contract. Older contracts stay append-only evidence.
        if not isinstance(event,dict) or _prediction_contract_id(event)!=CURRENT_PREDICTION_CONTRACT_ID:
            continue
        event_ts=num(event.get('event_ts'))
        if event_ts is None or event_ts<nowv-RAW_RETENTION_SEC:
            continue
        if target_name in {'probability_3h','probability_6h'}:
            # Rise prediction is the upstream price-direction owner. Trading cost
            # belongs to the later Paper execution stage and must not turn a
            # genuinely rising coin into a DOWN training label.
            raw_return=num(outcome.get('final_return_pct'))
            if raw_return is None or raw_return==0:
                continue
            actual=raw_return>0
        elif target_name=='giveback_risk':
            mfe=num(outcome.get('mfe_pct')); giveback=num(outcome.get('giveback_pct'))
            if mfe is None or giveback is None or mfe<=0:
                continue
            actual=(giveback/max(mfe,1e-9))>=0.50
        else:
            early=num(outcome.get('early_capture_ratio'))
            if early is not None:
                actual=early<0.50
            else:
                pre=num(outcome.get('pre_signal_rise_pct')); mfe=num(outcome.get('mfe_pct'))
                if pre is None or mfe is None:
                    continue
                actual=pre>max(0.0,mfe)
        rows.append((event,outcome,bool(actual)))
    return rows


def _build_target_model(target_name: str, nowv: float) -> Dict[str,Any]:
    observations=_target_observations(target_name,nowv)
    episode_counts=Counter(str(event.get('episode_id') or event.get('event_key')) for event,_,_ in observations)
    weighted=[]
    for event,outcome,actual in observations:
        episode=str(event.get('episode_id') or event.get('event_key'))
        weight=1.0/max(1,int(episode_counts.get(episode) or 1))
        weighted.append((event,outcome,actual,weight))
    total=sum(weight for *_,weight in weighted)
    positive=sum(weight for _,_,actual,weight in weighted if actual)
    base=(positive/total) if total>0 else 0.5
    features={}
    for name in MATERIAL_NAMES:
        numeric_rows=[]; categorical_rows=[]
        for event,_,actual,weight in weighted:
            materials=event.get('materials') if isinstance(event.get('materials'),dict) else {}
            item=materials.get(name) if isinstance(materials.get(name),dict) else {}
            if str(item.get('state') or '').upper()!='READY' or str(item.get('source_state') or '').upper()!='READY':
                continue
            kind,value=_model_material_value(item.get('value'))
            if kind=='numeric': numeric_rows.append((float(value),actual,weight))
            elif kind=='categorical': categorical_rows.append((str(value),actual,weight))
        if numeric_rows:
            edges=[_quantile([value for value,_,_ in numeric_rows],fraction) for fraction in (0.25,0.50,0.75)]
            clean_edges=[float(value) for value in edges if value is not None]
            buckets=defaultdict(lambda:{'total':0.0,'positive':0.0})
            for value,actual,weight in numeric_rows:
                bucket=_numeric_bucket(value,clean_edges); buckets[bucket]['total']+=weight; buckets[bucket]['positive']+=weight*int(actual)
            public={bucket:{'effective_sample':round(counts['total'],6),'positive_effective':round(counts['positive'],6),'probability_pct':round(_posterior_probability(counts['positive'],counts['total'],base),4)} for bucket,counts in buckets.items()}
            features[name]={'kind':'numeric','edges':[round(value,10) for value in clean_edges],'buckets':public,'raw_sample_count':len(numeric_rows),'source_state_required':'READY'}
        elif categorical_rows:
            buckets=defaultdict(lambda:{'total':0.0,'positive':0.0})
            for value,actual,weight in categorical_rows:
                buckets[value]['total']+=weight; buckets[value]['positive']+=weight*int(actual)
            public={key:{'effective_sample':round(counts['total'],6),'positive_effective':round(counts['positive'],6),'probability_pct':round(_posterior_probability(counts['positive'],counts['total'],base),4)} for key,counts in buckets.items()}
            features[name]={'kind':'categorical','buckets':public,'raw_sample_count':len(categorical_rows),'source_state_required':'READY'}
    def categorical_model(values_fn):
        buckets=defaultdict(lambda:{'total':0.0,'positive':0.0})
        for event,_,actual,weight in weighted:
            values=values_fn(event)
            for value in values:
                if not value: continue
                buckets[str(value)]['total']+=weight; buckets[str(value)]['positive']+=weight*int(actual)
        return {key:{'effective_sample':round(counts['total'],6),'positive_effective':round(counts['positive'],6),'probability_pct':round(_posterior_probability(counts['positive'],counts['total'],base),4)} for key,counts in buckets.items()}
    tag_model=categorical_model(lambda event:list(event.get('explanation_tags') or []))
    tag_combo_model=categorical_model(lambda event:['+'.join(sorted(str(tag) for tag in (event.get('explanation_tags') or []))) or 'NONE'])
    sequence_model=categorical_model(lambda event:[str((event.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN')])
    return {
        'schema':'rise_probability_target_model','target':target_name,
        'horizon':'3h' if target_name in {'probability_3h','late_capture_risk'} else '6h',
        'state':'LIVE' if total>0 else 'NO_SAMPLE','raw_sample_count':len(observations),'effective_sample':round(total,6),
        'positive_effective':round(positive,6),'base_probability_pct':round(base*100.0,4),
        'feature_models':features,'tag_models':tag_model,'tag_combination_models':tag_combo_model,'sequence_models':sequence_model,
        'episode_weighting':'1 / event_count_in_same_episode','candidate_gate_active':True,
        'target_basis':'RAW_PRICE_FINAL_RETURN' if target_name in {'probability_3h','probability_6h'} else 'OBSERVED_PATH_RISK',
        'material_source_state_required':'READY'
    }



def _weighted_numeric_stats(rows: List[Tuple[float, float]]) -> Dict[str, Any]:
    clean=[(float(value),float(weight)) for value,weight in rows if math.isfinite(float(value)) and float(weight)>0]
    total=sum(weight for _,weight in clean)
    if not clean or total<=0:
        return {'raw_count':0,'effective_sample':0.0,'mean':None,'median':None,'stddev':None}
    mean=sum(value*weight for value,weight in clean)/total
    ordered=sorted(clean,key=lambda row:row[0])
    halfway=total/2.0
    cumulative=0.0
    median=ordered[-1][0]
    for value,weight in ordered:
        cumulative+=weight
        if cumulative>=halfway:
            median=value
            break
    variance=sum(weight*((value-mean)**2) for value,weight in clean)/total
    return {
        'raw_count':len(clean),
        'effective_sample':round(total,6),
        'mean':round(mean,8),
        'median':round(median,8),
        'stddev':round(math.sqrt(max(0.0,variance)),8),
    }


def _standardized_group_difference(left: Dict[str,Any], right: Dict[str,Any]) -> Optional[float]:
    left_mean=num(left.get('mean')); right_mean=num(right.get('mean'))
    left_std=num(left.get('stddev')); right_std=num(right.get('stddev'))
    if left_mean is None or right_mean is None:
        return None
    pooled=math.sqrt(max(0.0,((left_std or 0.0)**2+(right_std or 0.0)**2)/2.0))
    if pooled<=1e-12:
        return 0.0 if abs(left_mean-right_mean)<=1e-12 else (8.0 if left_mean>right_mean else -8.0)
    return round(max(-8.0,min(8.0,(left_mean-right_mean)/pooled)),6)


def _weighted_category_rates(rows: List[Tuple[str,float]]) -> Dict[str,Any]:
    counts=defaultdict(float)
    for value,weight in rows:
        if value and float(weight)>0:
            counts[str(value)]+=float(weight)
    total=sum(counts.values())
    return {
        'effective_sample':round(total,6),
        'rates_pct':{key:round(value/total*100.0,4) for key,value in sorted(counts.items())} if total>0 else {},
    }


def _top_category_gap(left: Dict[str,Any], right: Dict[str,Any]) -> Optional[Dict[str,Any]]:
    left_rates=left.get('rates_pct') if isinstance(left.get('rates_pct'),dict) else {}
    right_rates=right.get('rates_pct') if isinstance(right.get('rates_pct'),dict) else {}
    keys=set(left_rates)|set(right_rates)
    if not keys:
        return None
    key=max(keys,key=lambda item:abs(float(left_rates.get(item) or 0.0)-float(right_rates.get(item) or 0.0)))
    left_rate=float(left_rates.get(key) or 0.0); right_rate=float(right_rates.get(key) or 0.0)
    left_p=left_rate/100.0; right_p=right_rate/100.0; pooled=(left_p+right_p)/2.0
    denom=math.sqrt(max(0.0,pooled*(1.0-pooled)))
    effect=0.0 if abs(left_p-right_p)<=1e-12 else (8.0 if denom<=1e-12 and left_p>right_p else -8.0 if denom<=1e-12 else (left_p-right_p)/denom)
    return {'category':key,'left_rate_pct':round(left_rate,4),'right_rate_pct':round(right_rate,4),'gap_pct':round(left_rate-right_rate,4),'effect_size':round(max(-8.0,min(8.0,effect)),6)}


def _sealed_formula_identity(value: Any) -> Tuple[Optional[str], str, Dict[str,str]]:
    if not isinstance(value, dict):
        return None, 'MISSING', {}
    role_input=value.get('timeframe_role_input') if isinstance(value.get('timeframe_role_input'),dict) else {}
    role_eval=value.get('timeframe_role_evaluation') if isinstance(value.get('timeframe_role_evaluation'),dict) else {}
    sources={
        'timeframe_role_formula_id':str(value.get('timeframe_role_formula_id') or '').strip(),
        'role_input_formula_id':str(role_input.get('formula_id') or '').strip(),
        'role_evaluation_formula_id':str(role_eval.get('formula_id') or '').strip(),
        'prediction_model_id':str(value.get('prediction_model_id') or '').strip(),
    }
    present={name:item for name,item in sources.items() if item}
    unique=sorted(set(present.values()))
    if not unique:
        return None, 'MISSING', present
    if len(unique)>1:
        return None, 'CONFLICT', present
    return unique[0], 'PASS', present


def _event_formula_id(event: Dict[str,Any]) -> str:
    formula,state,_=_sealed_formula_identity(event)
    return str(formula or f'FORMULA_{state}')

def _event_prediction_path(event: Dict[str,Any]) -> str:
    role_eval=event.get('timeframe_role_evaluation') if isinstance(event.get('timeframe_role_evaluation'),dict) else {}
    raw=str(role_eval.get('prediction_path') or event.get('prediction_path') or event.get('prediction_selection_reason') or '').strip().upper()
    if raw in {'','UNKNOWN','PREDICTION_OUTPUT_MISSING','ROLE_OUTPUT_MISSING'}:
        return 'LEGACY_PATH_METADATA_MISSING'
    return raw

def _common_numeric_pattern(false_positive_effect: Optional[float], missed_effect: Optional[float]) -> str:
    if false_positive_effect is None or missed_effect is None:
        return 'ONE_SIDED_ONLY'
    product=float(false_positive_effect)*float(missed_effect)
    if product < 0.0:
        return 'ROLE_SIGN_INVERSION'
    if product > 0.0:
        return 'SAME_DIRECTION_AMBIGUITY'
    return 'FLAT_OR_UNRESOLVED'


def build_directional_material_comparison(event_filter=None, include_formula_cohorts: bool=True) -> Dict[str,Any]:
    """Compare every sealed prediction result without dropping HOLD misses.

    This is the existing directional comparison, corrected to use all six groups:
    UP/HOLD/DOWN x actual UP/DOWN. It reads Strategy-sealed materials and outcomes
    only; it never recalculates or reclassifies historical rows.
    """
    groups=('UP_UP','UP_DOWN','HOLD_UP','HOLD_DOWN','DOWN_UP','DOWN_DOWN')
    eligible=[]
    nowv=now_ts()
    formula_counts=Counter()
    for (event_key,horizon),outcome in _OUTCOME_ROWS.items():
        if str(outcome.get('outcome_state') or '')!='READY':
            continue
        event=_EVENTS.get(str(event_key))
        if not isinstance(event,dict):
            continue
        event_ts=num(event.get('event_ts'))
        if event_ts is None or event_ts<nowv-RAW_RETENTION_SEC:
            continue
        selection=event.get('prediction_selection')
        decision=_normalize_decision(selection.get('decision') if isinstance(selection,dict) else selection)
        if decision not in {'UP','HOLD','DOWN'}:
            continue
        actual=str(outcome.get('actual_direction') or outcome.get('raw_actual_direction') or '').upper()
        if actual not in {'UP','DOWN'}:
            continue
        materials=event.get('materials') if isinstance(event.get('materials'),dict) else {}
        if not materials or not any(name in materials for name in MATERIAL_NAMES):
            continue
        role_input=event.get('timeframe_role_input') if isinstance(event.get('timeframe_role_input'),dict) else {}
        formula=_event_formula_id(event)
        if event_filter is not None and not event_filter(event):
            continue
        formula_counts[formula]+=1
        eligible.append((str(horizon),event,outcome,f'{decision}_{actual}'))
    episode_counts=Counter((horizon,str(event.get('episode_id') or event.get('event_key'))) for horizon,event,_,_ in eligible)
    numeric_rows=defaultdict(lambda:defaultdict(lambda:defaultdict(list)))
    category_rows=defaultdict(lambda:defaultdict(lambda:defaultdict(list)))
    tag_rows=defaultdict(lambda:defaultdict(lambda:defaultdict(float)))
    tag_totals=defaultdict(lambda:defaultdict(float))
    sequence_rows=defaultdict(lambda:defaultdict(lambda:defaultdict(float)))
    sequence_totals=defaultdict(lambda:defaultdict(float))
    raw_counts=defaultdict(Counter); effective_counts=defaultdict(lambda:defaultdict(float))
    path_rows=defaultdict(lambda:defaultdict(Counter))
    path_metadata_missing=defaultdict(Counter)
    for horizon,event,_,group in eligible:
        episode=str(event.get('episode_id') or event.get('event_key'))
        weight=1.0/max(1,int(episode_counts.get((horizon,episode)) or 1))
        raw_counts[horizon][group]+=1; effective_counts[horizon][group]+=weight
        prediction_path=_event_prediction_path(event)
        if prediction_path=='LEGACY_PATH_METADATA_MISSING':
            path_metadata_missing[horizon][group]+=weight
        else:
            path_rows[horizon][group][prediction_path] += weight
        materials=event.get('materials') if isinstance(event.get('materials'),dict) else {}
        for name in MATERIAL_NAMES:
            item=materials.get(name) if isinstance(materials.get(name),dict) else {}
            if str(item.get('state') or '').upper()!='READY' or str(item.get('source_state') or '').upper()!='READY':
                continue
            kind,value=_model_material_value(item.get('value'))
            if kind=='numeric': numeric_rows[horizon][group][name].append((float(value),weight))
            elif kind=='categorical': category_rows[horizon][group][name].append((str(value),weight))
        tags=[str(tag) for tag in (event.get('explanation_tags') or []) if str(tag)]
        tag_totals[horizon][group]+=weight
        for tag in tags: tag_rows[horizon][group][tag]+=weight
        sequence=str((event.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN')
        sequence_totals[horizon][group]+=weight; sequence_rows[horizon][group][sequence]+=weight
    horizons={}
    for horizon in ('30m','1h','3h','6h'):
        counts={group:int(raw_counts[horizon].get(group) or 0) for group in groups}
        up_total=counts['UP_UP']+counts['UP_DOWN']
        nonup_total=sum(counts[g] for g in ('HOLD_UP','HOLD_DOWN','DOWN_UP','DOWN_DOWN'))
        actual_up=counts['UP_UP']+counts['HOLD_UP']+counts['DOWN_UP']
        resolved=up_total+nonup_total
        numeric_public={}; categorical_public={}; false_positive=[]; missed_rise=[]; common=[]
        for name in MATERIAL_NAMES:
            group_stats={group:_weighted_numeric_stats(numeric_rows[horizon][group].get(name,[])) for group in groups}
            missed_rows=(numeric_rows[horizon]['HOLD_UP'].get(name,[])+numeric_rows[horizon]['DOWN_UP'].get(name,[]))
            correct_nonup_rows=(numeric_rows[horizon]['HOLD_DOWN'].get(name,[])+numeric_rows[horizon]['DOWN_DOWN'].get(name,[]))
            missed_stat=_weighted_numeric_stats(missed_rows); correct_nonup_stat=_weighted_numeric_stats(correct_nonup_rows)
            if any(int(stat.get('raw_count') or 0)>0 for stat in group_stats.values()):
                fp_effect=_standardized_group_difference(group_stats['UP_DOWN'],group_stats['UP_UP'])
                miss_effect=_standardized_group_difference(missed_stat,correct_nonup_stat)
                numeric_public[name]={'groups':group_stats,'missed_rise_combined':missed_stat,'correct_nonup_combined':correct_nonup_stat,'false_positive_effect_size':fp_effect,'missed_rise_effect_size':miss_effect}
                fp_row=None; miss_row=None
                if fp_effect is not None and min(group_stats['UP_DOWN']['raw_count'],group_stats['UP_UP']['raw_count'])>=5:
                    fp_row={'material':name,'kind':'numeric','effect_size':fp_effect,'failure_median':group_stats['UP_DOWN']['median'],'success_median':group_stats['UP_UP']['median'],'failure_count':group_stats['UP_DOWN']['raw_count'],'success_count':group_stats['UP_UP']['raw_count']}; false_positive.append(fp_row)
                if miss_effect is not None and min(missed_stat['raw_count'],correct_nonup_stat['raw_count'])>=5:
                    miss_row={'material':name,'kind':'numeric','effect_size':miss_effect,'missed_median':missed_stat['median'],'correct_nonup_median':correct_nonup_stat['median'],'missed_count':missed_stat['raw_count'],'correct_nonup_count':correct_nonup_stat['raw_count'],'hold_missed_count':counts['HOLD_UP'],'down_missed_count':counts['DOWN_UP']}; missed_rise.append(miss_row)
                if fp_row and miss_row:
                    common.append({'material':name,'kind':'numeric','pattern':_common_numeric_pattern(fp_effect,miss_effect),'false_positive_effect_size':fp_effect,'missed_rise_effect_size':miss_effect,'wrong_up_median':fp_row['failure_median'],'right_up_median':fp_row['success_median'],'missed_median':miss_row['missed_median'],'correct_nonup_median':miss_row['correct_nonup_median'],'minimum_group_count':min(fp_row['failure_count'],fp_row['success_count'],miss_row['missed_count'],miss_row['correct_nonup_count'])})
            cat_stats={group:_weighted_category_rates(category_rows[horizon][group].get(name,[])) for group in groups}
            if any(float(stat.get('effective_sample') or 0)>0 for stat in cat_stats.values()):
                missed_cat=_weighted_category_rates(category_rows[horizon]['HOLD_UP'].get(name,[])+category_rows[horizon]['DOWN_UP'].get(name,[]))
                correct_cat=_weighted_category_rates(category_rows[horizon]['HOLD_DOWN'].get(name,[])+category_rows[horizon]['DOWN_DOWN'].get(name,[]))
                fp_gap=_top_category_gap(cat_stats['UP_DOWN'],cat_stats['UP_UP']); miss_gap=_top_category_gap(missed_cat,correct_cat)
                categorical_public[name]={'groups':cat_stats,'missed_rise_combined':missed_cat,'correct_nonup_combined':correct_cat,'false_positive_top_gap':fp_gap,'missed_rise_top_gap':miss_gap}
                if fp_gap and min(cat_stats['UP_DOWN']['effective_sample'],cat_stats['UP_UP']['effective_sample'])>=5:
                    false_positive.append({'material':name,'kind':'categorical','effect_size':fp_gap.get('effect_size'),'category':fp_gap['category'],'failure_rate_pct':fp_gap['left_rate_pct'],'success_rate_pct':fp_gap['right_rate_pct']})
                if miss_gap and min(missed_cat['effective_sample'],correct_cat['effective_sample'])>=5:
                    missed_rise.append({'material':name,'kind':'categorical','effect_size':miss_gap.get('effect_size'),'category':miss_gap['category'],'missed_rate_pct':miss_gap['left_rate_pct'],'correct_nonup_rate_pct':miss_gap['right_rate_pct']})
                if fp_gap and miss_gap and min(cat_stats['UP_DOWN']['effective_sample'],cat_stats['UP_UP']['effective_sample'],missed_cat['effective_sample'],correct_cat['effective_sample'])>=5:
                    common.append({'material':name,'kind':'categorical','pattern':'CATEGORY_RATE_CONFLICT','category':miss_gap['category'],'false_positive_effect_size':fp_gap.get('effect_size'),'missed_rise_effect_size':miss_gap.get('effect_size'),'wrong_up_rate_pct':fp_gap['left_rate_pct'],'right_up_rate_pct':fp_gap['right_rate_pct'],'missed_rate_pct':miss_gap['left_rate_pct'],'correct_nonup_rate_pct':miss_gap['right_rate_pct']})
        false_positive.sort(key=lambda row:(-abs(float(row.get('effect_size') or 0.0)),str(row.get('material') or '')))
        missed_rise.sort(key=lambda row:(-abs(float(row.get('effect_size') or 0.0)),str(row.get('material') or '')))
        common.sort(key=lambda row:(-(abs(float(row.get('false_positive_effect_size') or 0.0))+abs(float(row.get('missed_rise_effect_size') or 0.0))),str(row.get('material') or '')))
        horizons[horizon]={
            'group_counts':counts,'resolved_count':resolved,
            'up_prediction_precision_pct':round(counts['UP_UP']/up_total*100.0,3) if up_total else None,
            'hold_missed_rise_count':counts['HOLD_UP'],'down_missed_rise_count':counts['DOWN_UP'],
            'missed_rise_rate_pct':round((counts['HOLD_UP']+counts['DOWN_UP'])/actual_up*100.0,3) if actual_up else None,
            'numeric_materials':numeric_public,'categorical_materials':categorical_public,
            'top_false_positive_materials':false_positive[:8],
            'top_missed_rise_materials':missed_rise[:8],
            'top_common_error_materials':common[:8],
            'prediction_path_counts':{group:{path:round(weight,6) for path,weight in path_rows[horizon][group].most_common()} for group in groups},
            'prediction_path_metadata_missing_counts':{group:round(float(path_metadata_missing[horizon].get(group) or 0.0),6) for group in groups},
            'path_metadata_missing_is_prediction_error':False,
        }
    formula_cohorts={}
    stable_cross_formula=defaultdict(list)
    if include_formula_cohorts:
        for formula in sorted(formula_counts):
            if not formula or formula=='UNKNOWN':
                continue
            def _formula_filter(event, formula_id=formula):
                return (event_filter(event) if event_filter is not None else True) and _event_formula_id(event)==formula_id
            cohort=build_directional_material_comparison(_formula_filter, include_formula_cohorts=False)
            formula_cohorts[formula]={'formula_counts':cohort.get('formula_counts') or {},'horizons':cohort.get('horizons') or {}}
        for formula,cohort in formula_cohorts.items():
            for horizon,block in (cohort.get('horizons') or {}).items():
                for item in (block.get('top_common_error_materials') or []):
                    if item.get('kind')!='numeric' or item.get('pattern')!='ROLE_SIGN_INVERSION':
                        continue
                    fp=float(item.get('false_positive_effect_size') or 0.0); miss=float(item.get('missed_rise_effect_size') or 0.0)
                    sign_pair=('HIGH' if fp>0 else 'LOW','HIGH' if miss>0 else 'LOW')
                    stable_cross_formula[(horizon,str(item.get('material') or ''),sign_pair)].append(formula)
    stable_rows=[]
    for (horizon,material,sign_pair),formulas in stable_cross_formula.items():
        if len(formulas)<2:
            continue
        stable_rows.append({'horizon':horizon,'material':material,'pattern':'ROLE_SIGN_INVERSION','wrong_up_side':sign_pair[0],'missed_rise_side':sign_pair[1],'formula_count':len(formulas),'formula_ids':sorted(formulas)})
    stable_rows.sort(key=lambda row:(-int(row.get('formula_count') or 0),str(row.get('horizon') or ''),str(row.get('material') or '')))
    return {
        'schema':'directional_material_comparison','contract_id':'SEALED_RECENT_FORMULA_COHORTS',
        'formula_counts':dict(formula_counts),
        'group_meaning':{'UP_UP':'UP→상승','UP_DOWN':'UP→하락','HOLD_UP':'HOLD→상승','HOLD_DOWN':'HOLD→하락','DOWN_UP':'DOWN→상승','DOWN_DOWN':'DOWN→하락'},
        'horizons':horizons,'hold_missed_included':True,'down_missed_included':True,
        'active_formula_id':CURRENT_TIMEFRAME_ROLE_FORMULA_ID,
        'formula_cohorts':formula_cohorts,
        'cross_formula_stable_errors':stable_rows,
        'formula_mixing_used_for_condition':False,
        'historical_rows_recomputed':False,'historical_rows_reclassified':False,
        'analysis_only':True,'prediction_formula_changed':False,'weights_changed':False,'thresholds_changed':False,'candidate_gate_changed':False,'auto_buy':False,
    }

def _load_active_strategy_core():
    return _ACTIVE_STRATEGY_CORE


def _slice_completed(rows: List[Dict[str,float]], event_ts: float, interval_sec: float) -> List[Dict[str,float]]:
    return [dict(row) for row in rows if num(row.get('ts')) is not None and float(row['ts'])+interval_sec<=float(event_ts)+1.0]


def _historical_market_context(event: Dict[str,Any]) -> Dict[str,Any]:
    materials=event.get('materials') if isinstance(event.get('materials'),dict) else {}
    liq=(materials.get('market_liquidity_state') or {}).get('value') if isinstance(materials.get('market_liquidity_state'),dict) else {}
    breadth=(materials.get('market_breadth_change') or {}).get('value') if isinstance(materials.get('market_breadth_change'),dict) else None
    out=dict(liq) if isinstance(liq,dict) else {}
    out['breadth_change']=num(breadth)
    flow=event.get('existing_flow_inputs') if isinstance(event.get('existing_flow_inputs'),dict) else {}
    if not flow:
        flow={
            'buy_ratio':num(event.get('buy_ratio')),
            'buy_sustain_1m':num(event.get('buy_sustain_1m')),
            'buy_ratio_delta':num(event.get('buy_ratio_delta_v2130')),
            'buy_sustain_delta':num(event.get('buy_sustain_delta_v2130')),
            'sell_pressure':event.get('sell_pressure') if isinstance(event.get('sell_pressure'),bool) else None,
            'pullback_volume_contract':event.get('pullback_volume_contract') if isinstance(event.get('pullback_volume_contract'),bool) else None,
            'reclaim_volume_expand':event.get('reclaim_volume_expand') if isinstance(event.get('reclaim_volume_expand'),bool) else None,
        }
    out['_sealed_prediction_payload']={'explanation_tags':list(event.get('explanation_tags') or []),'price_volume_sequence':event.get('price_volume_sequence') if isinstance(event.get('price_volume_sequence'),dict) else {},'existing_flow_inputs':flow}
    return out


def _normalize_decision(value: Any) -> str:
    decision=str(value or '').strip().upper()
    return decision if decision in {'UP','HOLD','DOWN'} else 'UNKNOWN'


def _mean_or_none(values: Iterable[Any]) -> Optional[float]:
    nums=[float(value) for value in values if num(value) is not None]
    return round(sum(nums)/len(nums),6) if nums else None


def _shadow_answer_from_outcome(outcome: Dict[str,Any]) -> Optional[Dict[str,Any]]:
    """Interpret one completed actual path without using Strategy.

    Three answer layers are deliberately kept separate:
    1) sealed target/invalid order (strict execution contract),
    2) horizon finish after sealed cost,
    3) intrahorizon MFE after sealed cost.
    No layer substitutes for another and no threshold is invented here.
    """
    if str(outcome.get('outcome_state') or '')!='READY':
        return None
    mfe=num(outcome.get('mfe_pct')); mae=num(outcome.get('mae_pct'))
    giveback=num(outcome.get('giveback_pct')); final_return=num(outcome.get('final_return_pct'))
    scored_net=num(outcome.get('scored_net_return_pct')); cost=num(outcome.get('scoring_cost_pct'),0.0)
    if mfe is None or scored_net is None:
        return None
    cost=float(cost or 0.0); net_mfe=float(mfe)-cost
    touch_order=str(outcome.get('touch_order') or 'NO_TOUCH').upper()
    if touch_order not in {'TARGET_FIRST','INVALID_FIRST','AMBIGUOUS_SAME_BAR','NO_TOUCH'}:
        touch_order='NO_TOUCH'
    contract_success=True if touch_order=='TARGET_FIRST' else False if touch_order=='INVALID_FIRST' else None
    finish_success=float(scored_net)>0.0
    opportunity_success=net_mfe>0.0
    if touch_order=='TARGET_FIRST': answer_class='TARGET_FIRST'
    elif touch_order=='INVALID_FIRST': answer_class='INVALID_FIRST'
    elif touch_order=='AMBIGUOUS_SAME_BAR': answer_class='AMBIGUOUS_SAME_BAR'
    elif finish_success: answer_class='PROFITABLE_FINISH_NO_TOUCH'
    elif opportunity_success: answer_class='INTRAPATH_OPPORTUNITY_ONLY'
    else: answer_class='NO_RISE'
    return {
        'schema':'fixed_shadow_answer','answer_contract':'ACTUAL_PATH_THREE_LAYER_V2',
        'event_key':outcome.get('event_key'),'horizon':outcome.get('horizon'),
        'answer_class':answer_class,'touch_order':touch_order,
        'contract_resolved':contract_success is not None,'contract_success':contract_success,
        'profitable_finish':finish_success,'cost_clearing_opportunity':opportunity_success,
        'net_mfe_after_cost_pct':round(net_mfe,8),'mfe_pct':mfe,'mae_pct':mae,
        'giveback_pct':giveback,'final_return_pct':final_return,'scored_net_return_pct':scored_net,
        'scoring_cost_pct':cost,
        'actual_path_only':True,'strategy_formula_used':False,'future_candle_used':False,
        'historical_row_rewritten':False,'auto_buy':False,
    }


def _binary_decision_metrics(rows: List[Tuple[str,str,bool]]) -> Dict[str,Any]:
    # rows: (old_decision, new_decision, positive_answer)
    def one(which: int) -> Dict[str,Any]:
        decisions=Counter(); positive_by_decision=Counter(); negative_by_decision=Counter()
        for old,new,positive in rows:
            decision=(old,new)[which]
            decisions[decision]+=1
            (positive_by_decision if positive else negative_by_decision)[decision]+=1
        up=int(decisions.get('UP') or 0); positive=sum(int(v) for v in positive_by_decision.values())
        return {
            'resolved_count':len(rows),'positive_count':positive,'decision_counts':dict(decisions),
            'up_count':up,'up_positive_count':int(positive_by_decision.get('UP') or 0),
            'up_precision_pct':round(positive_by_decision.get('UP',0)/up*100.0,3) if up else None,
            'positive_recall_pct':round(positive_by_decision.get('UP',0)/positive*100.0,3) if positive else None,
            'hold_positive_count':int(positive_by_decision.get('HOLD') or 0),
            'down_positive_count':int(positive_by_decision.get('DOWN') or 0),
            'unknown_positive_count':int(positive_by_decision.get('UNKNOWN') or 0),
            'false_up_count':int(negative_by_decision.get('UP') or 0),
            'hold_positive_rate_pct':round(positive_by_decision.get('HOLD',0)/max(int(decisions.get('HOLD') or 0),1)*100.0,3) if decisions.get('HOLD') else None,
            'down_positive_rate_pct':round(positive_by_decision.get('DOWN',0)/max(int(decisions.get('DOWN') or 0),1)*100.0,3) if decisions.get('DOWN') else None,
        }
    transitions=Counter(); positive_transitions=Counter(); negative_transitions=Counter()
    for old,new,positive in rows:
        key=f'{old}->{new}'; transitions[key]+=1
        (positive_transitions if positive else negative_transitions)[key]+=1
    old_correct=[row for row in rows if row[0]=='UP' and row[2]]
    old_missed=[row for row in rows if row[0]!='UP' and row[2]]
    old_false=[row for row in rows if row[0]=='UP' and not row[2]]
    new_false=[row for row in rows if row[0]!='UP' and not row[2] and row[1]=='UP']
    def movement(subset: List[Tuple[str,str,bool]]) -> Dict[str,Any]:
        counts=Counter(row[1] for row in subset); total=len(subset)
        return {
            'total':total,'new_up':int(counts.get('UP') or 0),'new_hold':int(counts.get('HOLD') or 0),'new_down':int(counts.get('DOWN') or 0),'new_unknown':int(counts.get('UNKNOWN') or 0),
            'new_up_pct':round(counts.get('UP',0)/total*100.0,3) if total else None,
            'new_hold_pct':round(counts.get('HOLD',0)/total*100.0,3) if total else None,
            'new_down_pct':round(counts.get('DOWN',0)/total*100.0,3) if total else None,
        }
    return {
        'baseline':one(0),'new':one(1),
        'transition_counts':dict(transitions),'positive_transition_counts':dict(positive_transitions),'negative_transition_counts':dict(negative_transitions),
        'prior_correct_up_movement':movement(old_correct),
        'prior_missed_positive_movement':movement(old_missed),
        'prior_false_up_movement':movement(old_false),
        'new_false_up_from_prior_non_up_count':len(new_false),
        'hold_counted_as_damage':False,
    }


def build_shadow_answer_sheet() -> Dict[str,Any]:
    horizons={}; contract_counts=Counter(); total=0
    for horizon,_sec in HORIZONS:
        answers=[]
        for (event_key,row_horizon),outcome in _OUTCOME_ROWS.items():
            if row_horizon!=horizon: continue
            answer=_shadow_answer_from_outcome(outcome)
            if not isinstance(answer,dict): continue
            answers.append(answer); total+=1
            event=_EVENTS.get(str(event_key))
            if isinstance(event,dict): contract_counts[_prediction_contract_id(event)]+=1
        classes=Counter(str(x.get('answer_class') or 'UNKNOWN') for x in answers)
        resolved=[x for x in answers if x.get('contract_success') in {True,False}]
        target=sum(int(x.get('contract_success') is True) for x in resolved)
        invalid=sum(int(x.get('contract_success') is False) for x in resolved)
        finish=sum(int(bool(x.get('profitable_finish'))) for x in answers)
        opportunity=sum(int(bool(x.get('cost_clearing_opportunity'))) for x in answers)
        horizons[horizon]={
            'answer_count':len(answers),'answer_class_counts':dict(classes),
            'contract_resolved_count':len(resolved),'target_first_count':target,'invalid_first_count':invalid,
            'target_first_rate_pct':round(target/len(resolved)*100.0,3) if resolved else None,
            'profitable_finish_count':finish,'profitable_finish_rate_pct':round(finish/len(answers)*100.0,3) if answers else None,
            'cost_clearing_opportunity_count':opportunity,'cost_clearing_opportunity_rate_pct':round(opportunity/len(answers)*100.0,3) if answers else None,
            'avg_net_mfe_after_cost_pct':_mean_or_none(x.get('net_mfe_after_cost_pct') for x in answers),
            'avg_mfe_pct':_mean_or_none(x.get('mfe_pct') for x in answers),'avg_mae_pct':_mean_or_none(x.get('mae_pct') for x in answers),
            'avg_giveback_pct':_mean_or_none(x.get('giveback_pct') for x in answers),'avg_scored_net_return_pct':_mean_or_none(x.get('scored_net_return_pct') for x in answers),
        }
    return {
        'schema':'fixed_shadow_answer_sheet','state':'READY' if total else 'WAITING','answer_contract':'ACTUAL_PATH_THREE_LAYER_V2','answer_count':total,
        'definition':{
            'contract_success':'sealed target touched before sealed invalid; ambiguous/no-touch excluded from this strict layer',
            'profitable_finish':'horizon final return after sealed estimated cost is positive',
            'cost_clearing_opportunity':'actual MFE after sealed estimated cost is positive; this is broad opportunity only, not a tradeable-success substitute',
        },
        'horizons':horizons,'source_contract_counts':dict(contract_counts),
        'strategy_formula_used':False,'mainline_prediction_used':False,'actual_elapsed_outcomes_only':True,
        'historical_event_rows_rewritten':False,'historical_outcome_rows_rewritten':False,'future_candle_used':False,'auto_buy':False,
    }


def build_canonical_prediction_seal_audit() -> Dict[str,Any]:
    """Audit Strategy-sealed prediction rows without recalculating any decision.

    Strategy is the sole calculation Owner. Review only validates the sealed
    canonical input/evaluation contract and links the sealed decision to actual
    elapsed outcomes. Legacy/current-formula replay paths are intentionally
    absent; invalid rows are CHECK/source_missing, never silently HOLD.
    """
    events=[event for event in _EVENTS.values() if isinstance(event,dict) and _prediction_contract_id(event)==CURRENT_PREDICTION_CONTRACT_ID]
    invalid=Counter(); decisions=Counter(); paths=Counter(); source_missing=Counter(); mismatch_samples=[]
    valid=0; decision_match=0; current_formula_count=0
    for event in events:
        role_input=event.get('timeframe_role_input') if isinstance(event.get('timeframe_role_input'),dict) else {}
        role_eval=event.get('timeframe_role_evaluation') if isinstance(event.get('timeframe_role_evaluation'),dict) else {}
        selection=_normalize_decision(event.get('prediction_selection'))
        sealed_decision=_normalize_decision(role_eval.get('decision'))
        row_errors=[]
        if str(role_input.get('schema') or '')!='official_timeframe_role_input': row_errors.append('INPUT_SCHEMA')
        if str(role_input.get('contract_id') or '')!=CURRENT_PREDICTION_CONTRACT_ID: row_errors.append('INPUT_CONTRACT')
        if str(role_input.get('formula_id') or '')!=CURRENT_TIMEFRAME_ROLE_FORMULA_ID: row_errors.append('INPUT_FORMULA')
        axes=role_input.get('axes') if isinstance(role_input.get('axes'),dict) else {}
        for axis in ('1h_timing','4h_structure','24h_context'):
            if not isinstance(axes.get(axis),dict): row_errors.append(f'INPUT_AXIS_{axis}')
        states=role_input.get('axis_source_state') if isinstance(role_input.get('axis_source_state'),dict) else {}
        for axis in ('h1','h4','d1'):
            if not str(states.get(axis) or ''): row_errors.append(f'INPUT_STATE_{axis}')
        if str(role_eval.get('schema') or '')!='official_timeframe_role_evaluation': row_errors.append('EVAL_SCHEMA')
        if str(role_eval.get('contract_id') or '')!=CURRENT_PREDICTION_CONTRACT_ID: row_errors.append('EVAL_CONTRACT')
        if str(role_eval.get('formula_id') or '')!=CURRENT_TIMEFRAME_ROLE_FORMULA_ID: row_errors.append('EVAL_FORMULA')
        if sealed_decision not in {'UP','HOLD','DOWN'}: row_errors.append('EVAL_DECISION')
        if selection not in {'UP','HOLD','DOWN'}: row_errors.append('SELECTION_DECISION')
        if row_errors:
            invalid.update(row_errors)
            continue
        valid+=1; current_formula_count+=1; decisions[sealed_decision]+=1
        paths[str(role_eval.get('prediction_path') or 'UNKNOWN')]+=1
        for axis in role_eval.get('source_missing_axes') or []: source_missing[str(axis)]+=1
        if selection==sealed_decision:
            decision_match+=1
        else:
            invalid['SEALED_SELECTION_MISMATCH']+=1
            if len(mismatch_samples)<10:
                mismatch_samples.append({'event_key':event.get('event_key'),'ticker':event.get('ticker'),'selection':selection,'sealed_decision':sealed_decision})
    invalid_count=sum(1 for event in events if not (
        isinstance(event.get('timeframe_role_input'),dict)
        and isinstance(event.get('timeframe_role_evaluation'),dict)
        and _normalize_decision(event.get('prediction_selection')) in {'UP','HOLD','DOWN'}
        and _normalize_decision((event.get('timeframe_role_evaluation') or {}).get('decision')) in {'UP','HOLD','DOWN'}
        and str((event.get('timeframe_role_input') or {}).get('formula_id') or '')==CURRENT_TIMEFRAME_ROLE_FORMULA_ID
        and str((event.get('timeframe_role_evaluation') or {}).get('formula_id') or '')==CURRENT_TIMEFRAME_ROLE_FORMULA_ID
    ))
    mismatch_count=max(0,valid-decision_match)
    state='PASS' if events and invalid_count==0 and mismatch_count==0 else ('WAITING' if not events else 'CHECK')
    return {
        'schema':'canonical_prediction_seal_audit','state':state,'owner':'strategy_v2_core -> strategy_worker seal; review read-only',
        'formula_id':CURRENT_TIMEFRAME_ROLE_FORMULA_ID,'contract_id':CURRENT_PREDICTION_CONTRACT_ID,
        'event_count':len(events),'valid_sealed_event_count':valid,'invalid_sealed_event_count':invalid_count,
        'sealed_decision_match_count':decision_match,'sealed_decision_mismatch_count':mismatch_count,
        'decision_counts':dict(decisions),'prediction_path_counts':dict(paths),'source_missing_axis_counts':dict(source_missing),
        'invalid_reason_counts':dict(invalid),'mismatch_samples':mismatch_samples,
        'strategy_calculation_owner_count':1,'review_formula_call_count':0,'review_input_recalculation_count':0,
        'legacy_formula_replay_active':False,'previous_formula_replay_active':False,'broad_case_replay_active':False,
        'invalid_input_defaulted_to_hold':False,'historical_events_reclassified':False,'historical_ledgers_rewritten':False,
        'new_shadow_created':False,'candidate_gate_changed':False,'auto_buy':False,
    }



def _route_value_feature(prefix: str, value: Any) -> Optional[str]:
    numeric=num(value)
    if numeric is None:
        return None
    return f"{prefix}_{'POS' if numeric>0 else 'NEG' if numeric<0 else 'ZERO'}"


def _route_bool_feature(prefix: str, value: Any) -> Optional[str]:
    if value is True:
        return f'{prefix}_TRUE'
    if value is False:
        return f'{prefix}_FALSE'
    return None


def _sealed_route_features(event: Dict[str,Any]) -> List[str]:
    """Build analysis-only route features from the exact Strategy seal.

    No indicator, axis or prediction is recalculated here. Every feature is a
    direct categorical reading of the immutable role input/evaluation stored by
    Strategy at event time.
    """
    role_input=event.get('timeframe_role_input') if isinstance(event.get('timeframe_role_input'),dict) else {}
    role_eval=event.get('timeframe_role_evaluation') if isinstance(event.get('timeframe_role_evaluation'),dict) else {}
    axes=role_input.get('axes') if isinstance(role_input.get('axes'),dict) else {}
    timing=axes.get('1h_timing') if isinstance(axes.get('1h_timing'),dict) else {}
    structure=axes.get('4h_structure') if isinstance(axes.get('4h_structure'),dict) else {}
    context=axes.get('24h_context') if isinstance(axes.get('24h_context'),dict) else {}
    t_inputs=timing.get('inputs') if isinstance(timing.get('inputs'),dict) else {}
    s_inputs=structure.get('inputs') if isinstance(structure.get('inputs'),dict) else {}
    c_inputs=context.get('inputs') if isinstance(context.get('inputs'),dict) else {}
    features=set()
    path=str(role_eval.get('prediction_path') or '').upper()
    if path:
        features.add(f'PATH_{path}')
    for axis_name,axis in (('H1',timing),('H4',structure),('D24',context)):
        direction=str(axis.get('direction') or '').upper()
        if direction in {'POSITIVE','NEGATIVE','NEUTRAL'}:
            features.add(f'{axis_name}_{direction}')
        pos=int(axis.get('positive_evidence_count') or 0)
        neg=int(axis.get('negative_evidence_count') or 0)
        margin=pos-neg
        features.add(f"{axis_name}_MARGIN_{'POS2' if margin>=2 else 'POS1' if margin==1 else 'BALANCED' if margin==0 else 'NEG1' if margin==-1 else 'NEG2'}")
    numeric_specs=(
        ('H1_HIGHER_LOW',t_inputs.get('higher_low_strength_atr')),
        ('H1_PRICE_ACCEL',t_inputs.get('price_acceleration_1h')),
        ('H1_REL_STRENGTH',t_inputs.get('relative_strength_1h')),
        ('H1_TURNOVER',t_inputs.get('turnover_growth_pct')),
        ('H1_RETURN',t_inputs.get('return_1h_pct')),
        ('H4_HIGHER_LOW',s_inputs.get('higher_low_strength_atr')),
        ('H4_CLOSE_EMA5',s_inputs.get('close_vs_ema5_atr')),
        ('H4_RETURN_ATR',s_inputs.get('return_4h_pct')),
        ('H4_REL_STRENGTH',s_inputs.get('relative_strength_4h')),
        ('H4_TURNOVER',s_inputs.get('turnover_growth_pct')),
        ('D24_CLOSE_EMA5',c_inputs.get('close_vs_ema5_atr')),
        ('D24_EMA_STACK',c_inputs.get('ema5_vs_ema10_atr')),
        ('D24_RETURN',c_inputs.get('return_24h_pct')),
        ('D24_REL_STRENGTH',c_inputs.get('relative_strength_24h')),
        ('BTC_ACCEL',t_inputs.get('btc_price_acceleration_1h')),
    )
    for prefix,value in numeric_specs:
        feature=_route_value_feature(prefix,value)
        if feature:
            features.add(feature)
    for prefix,value in (
        ('H1_PULLBACK_OVER_HALF', (num(t_inputs.get('pullback_recovery_ratio')) or 0)>0.5 if num(t_inputs.get('pullback_recovery_ratio')) is not None else None),
        ('H4_PULLBACK_OVER_HALF', (num(s_inputs.get('pullback_recovery_ratio')) or 0)>0.5 if num(s_inputs.get('pullback_recovery_ratio')) is not None else None),
        ('SELL_PRESSURE', t_inputs.get('sell_pressure')),
        ('PULLBACK_VOLUME_CONTRACT', t_inputs.get('pullback_volume_contract')),
        ('RECLAIM_VOLUME_EXPAND', t_inputs.get('reclaim_volume_expand')),
        ('MARKET_LIQUIDITY_SUPPORTIVE', t_inputs.get('market_liquidity_supportive')),
    ):
        feature=_route_bool_feature(prefix,value)
        if feature:
            features.add(feature)
    sequence=str(t_inputs.get('price_volume_sequence') or (event.get('price_volume_sequence') or {}).get('state') or '').upper()
    if sequence in {'VOLUME_LEADS','SAME_BAR','PRICE_LEADS'}:
        features.add(f'SEQUENCE_{sequence}')
    tags={str(tag).upper() for tag in (t_inputs.get('legacy_short_path_tags_observation_only') or event.get('explanation_tags') or [])}
    for tag in ('BEGINNING','RESTART','CHASE','EXHAUSTION'):
        if tag in tags:
            features.add(f'TAG_{tag}')
    flow_positive=any(value is not None and value>0 for value in (num(t_inputs.get('buy_ratio_delta')),num(t_inputs.get('buy_sustain_delta'))))
    if not flow_positive:
        ratio=num(t_inputs.get('buy_ratio')); sustain=num(t_inputs.get('buy_sustain_1m'))
        flow_positive=ratio is not None and sustain is not None and ratio>0.5 and sustain>0.5
    features.add('BUY_FLOW_POSITIVE' if flow_positive else 'BUY_FLOW_NOT_POSITIVE')
    return sorted(features)


def _route_label_ko(feature: str) -> str:
    exact={
        'H1_POSITIVE':'1시간 양수','H1_NEUTRAL':'1시간 중립','H1_NEGATIVE':'1시간 음수',
        'H4_POSITIVE':'4시간 양수','H4_NEUTRAL':'4시간 중립','H4_NEGATIVE':'4시간 음수',
        'D24_POSITIVE':'24시간 양수','D24_NEUTRAL':'24시간 중립','D24_NEGATIVE':'24시간 음수',
        'SEQUENCE_VOLUME_LEADS':'거래대금 선행','SEQUENCE_SAME_BAR':'가격·거래대금 동시','SEQUENCE_PRICE_LEADS':'가격 선행',
        'TAG_BEGINNING':'초입','TAG_RESTART':'재상승','TAG_CHASE':'추격구간','TAG_EXHAUSTION':'소진구간',
        'BUY_FLOW_POSITIVE':'매수흐름 개선','BUY_FLOW_NOT_POSITIVE':'매수흐름 개선 없음',
        'SELL_PRESSURE_TRUE':'매도압력 있음','SELL_PRESSURE_FALSE':'매도압력 없음',
        'PULLBACK_VOLUME_CONTRACT_TRUE':'눌림 거래대금 수축','PULLBACK_VOLUME_CONTRACT_FALSE':'눌림 거래대금 수축 없음',
        'RECLAIM_VOLUME_EXPAND_TRUE':'회복 거래대금 확대','RECLAIM_VOLUME_EXPAND_FALSE':'회복 거래대금 확대 없음',
        'MARKET_LIQUIDITY_SUPPORTIVE_TRUE':'시장 유동성 지지','MARKET_LIQUIDITY_SUPPORTIVE_FALSE':'시장 유동성 비지지',
        'H1_PULLBACK_OVER_HALF_TRUE':'1시간 눌림 절반이상 회복','H1_PULLBACK_OVER_HALF_FALSE':'1시간 눌림 절반미만 회복',
        'H4_PULLBACK_OVER_HALF_TRUE':'4시간 눌림 절반이상 회복','H4_PULLBACK_OVER_HALF_FALSE':'4시간 눌림 절반미만 회복',
    }
    if feature in exact:
        return exact[feature]
    replacements=(
        ('H1_HIGHER_LOW_','1시간 저점 '),('H1_PRICE_ACCEL_','1시간 가격가속 '),('H1_REL_STRENGTH_','1시간 상대강도 '),
        ('H1_TURNOVER_','1시간 거래대금 '),('H1_RETURN_','1시간 수익률 '),('H4_HIGHER_LOW_','4시간 저점 '),
        ('H4_CLOSE_EMA5_','4시간 EMA5 위치 '),('H4_RETURN_ATR_','4시간 수익률 '),('H4_REL_STRENGTH_','4시간 상대강도 '),
        ('H4_TURNOVER_','4시간 거래대금 '),('D24_CLOSE_EMA5_','24시간 EMA5 위치 '),('D24_EMA_STACK_','24시간 EMA 배열 '),
        ('D24_RETURN_','24시간 수익률 '),('D24_REL_STRENGTH_','24시간 상대강도 '),('BTC_ACCEL_','BTC 가속 '),
    )
    suffix={'POS':'양수','NEG':'음수','ZERO':'0','POS2':'강한 양수','POS1':'약한 양수','BALANCED':'균형','NEG1':'약한 음수','NEG2':'강한 음수'}
    for prefix,label in replacements:
        if feature.startswith(prefix):
            return label+suffix.get(feature[len(prefix):],feature[len(prefix):])
    if '_MARGIN_' in feature:
        axis,margin=feature.split('_MARGIN_',1)
        axis_label={'H1':'1시간 표차','H4':'4시간 표차','D24':'24시간 표차'}.get(axis,axis)
        return axis_label+' '+suffix.get(margin,margin)
    if feature.startswith('PATH_'):
        return '현재 경로 '+feature[5:]
    return feature



def _sealed_route_cases(features: List[str]) -> List[Tuple[str,...]]:
    """Bounded, interpretable route templates from sealed categorical facts."""
    unique=sorted(set(features))
    cases={tuple([feature]) for feature in unique}
    axis=[f for f in unique if f in {'H1_POSITIVE','H1_NEUTRAL','H1_NEGATIVE','H4_POSITIVE','H4_NEUTRAL','H4_NEGATIVE','D24_POSITIVE','D24_NEUTRAL','D24_NEGATIVE'}]
    margins=[f for f in unique if '_MARGIN_' in f]
    h1=[f for f in unique if f.startswith('H1_') and '_MARGIN_' not in f and f not in axis]
    h4=[f for f in unique if f.startswith('H4_') and '_MARGIN_' not in f and f not in axis]
    d24=[f for f in unique if f.startswith('D24_') and '_MARGIN_' not in f and f not in axis]
    tags=[f for f in unique if f.startswith('TAG_')]
    sequence=[f for f in unique if f.startswith('SEQUENCE_')]
    flow=[f for f in unique if f.startswith(('BUY_FLOW_','SELL_PRESSURE_','PULLBACK_VOLUME_','RECLAIM_VOLUME_','MARKET_LIQUIDITY_'))]
    btc=[f for f in unique if f.startswith('BTC_ACCEL_')]
    # Axis shape is the broad structural case.
    for size in (2,3):
        for combo in combinations(axis,size): cases.add(tuple(sorted(combo)))
        for combo in combinations(margins,size): cases.add(tuple(sorted(combo)))
    # Entry/structure/context evidence interactions.
    for left,right in ((h1,h4),(h4,d24),(h1,d24),(tags,sequence),(tags,flow),(sequence,flow),(btc,h1),(btc,h4)):
        for a in left:
            for b in right:
                cases.add(tuple(sorted((a,b))))
    # Main three-layer paths; one feature from each layer.
    for a in h1:
        for b in h4:
            for c in d24[:2]:
                cases.add(tuple(sorted((a,b,c))))
    for a in tags:
        for b in sequence:
            for c in flow:
                cases.add(tuple(sorted((a,b,c))))
    # Attach the sealed axis state to individual evidence without creating an
    # unconstrained combinatorial explosion.
    for a in axis:
        for b in h1+h4+d24+tags+sequence+flow+btc:
            cases.add(tuple(sorted((a,b))))
    return sorted(cases,key=lambda combo:(len(combo),combo))

def _route_stat_public(stat: Dict[str,Any]) -> Dict[str,Any]:
    total=int(stat.get('total') or 0); raw_up=int(stat.get('raw_up') or 0); profitable=int(stat.get('profitable') or 0); opportunity=int(stat.get('opportunity') or 0)
    net_count=int(stat.get('net_count') or 0); mfe_count=int(stat.get('mfe_count') or 0); mae_count=int(stat.get('mae_count') or 0)
    return {
        'sample_count':total,
        'raw_rise_count':raw_up,'raw_rise_rate_pct':round(raw_up/total*100.0,3) if total else None,
        'profitable_finish_count':profitable,'profitable_finish_rate_pct':round(profitable/total*100.0,3) if total else None,
        'path_opportunity_count':opportunity,'path_opportunity_rate_pct':round(opportunity/total*100.0,3) if total else None,
        'avg_after_cost_return_pct':round(float(stat.get('net_sum') or 0.0)/net_count,6) if net_count else None,
        'avg_mfe_pct':round(float(stat.get('mfe_sum') or 0.0)/mfe_count,6) if mfe_count else None,
        'avg_mae_pct':round(float(stat.get('mae_sum') or 0.0)/mae_count,6) if mae_count else None,
        'hold_count':int(stat.get('hold_count') or 0),'down_count':int(stat.get('down_count') or 0),'up_count':int(stat.get('up_count') or 0),
    }


def _route_accumulate(stat: Dict[str,Any], decision: str, outcome: Dict[str,Any]) -> None:
    stat['total']=int(stat.get('total') or 0)+1
    stat[f'{decision.lower()}_count']=int(stat.get(f'{decision.lower()}_count') or 0)+1
    raw_up=str(outcome.get('raw_actual_direction') or outcome.get('actual_direction') or '').upper()=='UP'
    stat['raw_up']=int(stat.get('raw_up') or 0)+int(raw_up)
    profitable=bool(outcome.get('shadow_profitable_finish'))
    opportunity=bool(outcome.get('shadow_rise_opportunity'))
    stat['profitable']=int(stat.get('profitable') or 0)+int(profitable)
    stat['opportunity']=int(stat.get('opportunity') or 0)+int(opportunity)
    net=num(outcome.get('scored_net_return_pct'))
    if net is not None:
        stat['net_sum']=float(stat.get('net_sum') or 0.0)+net; stat['net_count']=int(stat.get('net_count') or 0)+1
    mfe=num(outcome.get('mfe_pct'))
    if mfe is not None:
        stat['mfe_sum']=float(stat.get('mfe_sum') or 0.0)+mfe; stat['mfe_count']=int(stat.get('mfe_count') or 0)+1
    mae=num(outcome.get('mae_pct'))
    if mae is not None:
        stat['mae_sum']=float(stat.get('mae_sum') or 0.0)+mae; stat['mae_count']=int(stat.get('mae_count') or 0)+1


def _route_rank_row(combo: Tuple[str,...], train: Dict[str,Any], verify: Dict[str,Any], baseline_train: Dict[str,Any], baseline_verify: Dict[str,Any], missed_total: int) -> Dict[str,Any]:
    train_public=_route_stat_public(train); verify_public=_route_stat_public(verify)
    base_train=_route_stat_public(baseline_train); base_verify=_route_stat_public(baseline_verify)
    verify_rate=num(verify_public.get('profitable_finish_rate_pct')); base_verify_rate=num(base_verify.get('profitable_finish_rate_pct'))
    train_rate=num(train_public.get('profitable_finish_rate_pct')); base_train_rate=num(base_train.get('profitable_finish_rate_pct'))
    verify_net=num(verify_public.get('avg_after_cost_return_pct')); train_net=num(train_public.get('avg_after_cost_return_pct'))
    base_verify_net=num(base_verify.get('avg_after_cost_return_pct')); base_train_net=num(base_train.get('avg_after_cost_return_pct'))
    rate_gain=(verify_rate-base_verify_rate) if verify_rate is not None and base_verify_rate is not None else None
    net_gain=(verify_net-base_verify_net) if verify_net is not None and base_verify_net is not None else None
    positive=bool(train_net is not None and verify_net is not None and train_net>0 and verify_net>0 and train_rate is not None and base_train_rate is not None and verify_rate is not None and base_verify_rate is not None and train_rate>base_train_rate and verify_rate>base_verify_rate)
    improving=bool(not positive and train_net is not None and verify_net is not None and base_train_net is not None and base_verify_net is not None and train_net>base_train_net and verify_net>base_verify_net and train_rate is not None and base_train_rate is not None and verify_rate is not None and base_verify_rate is not None and train_rate>base_train_rate and verify_rate>base_verify_rate)
    state='VERIFIED_POSITIVE' if positive else 'VERIFIED_IMPROVING' if improving else 'NOT_VERIFIED'
    return {
        'features':list(combo),'label_ko':' + '.join(_route_label_ko(feature) for feature in combo),'condition_count':len(combo),
        'state':state,'train':train_public,'verify':verify_public,'baseline_train':base_train,'baseline_verify':base_verify,
        'verify_profitable_rate_gain_pct':round(rate_gain,6) if rate_gain is not None else None,
        'verify_after_cost_gain_pct':round(net_gain,6) if net_gain is not None else None,
        'missed_rise_coverage_pct':round(int(train.get('raw_up') or 0)+int(verify.get('raw_up') or 0),6)/max(1,missed_total)*100.0,
    }


def build_sealed_outcome_path_validation() -> Dict[str,Any]:
    """Discover recovery and loss routes from sealed Strategy events only.

    The event-time input and decision are never recalculated. Results are split
    chronologically so a route must improve in both the earlier and later block
    before it can be proposed for a future Strategy change.
    """
    horizons={}
    for horizon in ('30m','1h','3h','6h'):
        rows=[]
        for (review_event_key,row_horizon),outcome in _OUTCOME_ROWS.items():
            if row_horizon!=horizon or str(outcome.get('outcome_state') or '')!='READY':
                continue
            event=_EVENTS.get(str(review_event_key))
            if not isinstance(event,dict) or _prediction_contract_id(event)!=CURRENT_PREDICTION_CONTRACT_ID:
                continue
            selection=event.get('prediction_selection')
            decision=_normalize_decision(selection.get('decision') if isinstance(selection,dict) else selection)
            if decision not in {'UP','HOLD','DOWN'}:
                continue
            rows.append((float(num(event.get('event_ts'),0.0) or 0.0),event,outcome,decision,_sealed_route_features(event)))
        rows.sort(key=lambda item:(item[0],str(item[1].get('event_key') or '')))
        if not rows:
            horizons[horizon]={'state':'WAITING','sample_count':0}
            continue
        group_totals=Counter('up' if row[3]=='UP' else 'recovery' for row in rows)
        group_cuts={group:(max(1,min(total-1,int(total*0.70))) if total>1 else total) for group,total in group_totals.items()}
        group_seen=Counter(); train_total=0; verify_total=0
        combo_stats={'recovery_train':defaultdict(dict),'recovery_verify':defaultdict(dict),'up_train':defaultdict(dict),'up_verify':defaultdict(dict)}
        baseline={'recovery_train':{},'recovery_verify':{},'up_train':{},'up_verify':{}}
        non_up_missed=0; combo_keys=set()
        for _index,(_ts,event,outcome,decision,features) in enumerate(rows):
            group='up' if decision=='UP' else 'recovery'
            phase='train' if group_seen[group]<group_cuts.get(group,0) else 'verify'
            group_seen[group]+=1
            if phase=='train': train_total+=1
            else: verify_total+=1
            _route_accumulate(baseline[f'{group}_{phase}'],decision,outcome)
            if group=='recovery' and str(outcome.get('raw_actual_direction') or outcome.get('actual_direction') or '').upper()=='UP':
                non_up_missed+=1
            # Exclude current-path labels from discovery ranking; they describe
            # the existing decision rather than an independent observable route.
            eligible=[feature for feature in features if not feature.startswith('PATH_')]
            for combo in _sealed_route_cases(eligible):
                combo_keys.add((group,combo))
                _route_accumulate(combo_stats[f'{group}_{phase}'][combo],decision,outcome)
        min_total={'30m':30,'1h':30,'3h':10,'6h':6}[horizon]
        min_verify={'30m':8,'1h':8,'3h':3,'6h':2}[horizon]
        recovery_rows=[]; loss_rows=[]
        for group,combo in combo_keys:
            train=combo_stats[f'{group}_train'].get(combo,{})
            verify=combo_stats[f'{group}_verify'].get(combo,{})
            if int(train.get('total') or 0)+int(verify.get('total') or 0)<min_total or int(verify.get('total') or 0)<min_verify:
                continue
            row=_route_rank_row(combo,train,verify,baseline[f'{group}_train'],baseline[f'{group}_verify'],non_up_missed)
            if group=='recovery':
                recovery_rows.append(row)
            else:
                # Current-UP loss routes are ranked only when both chronological
                # blocks remain negative; they are observation for later pruning.
                train_net=num(row['train'].get('avg_after_cost_return_pct')); verify_net=num(row['verify'].get('avg_after_cost_return_pct'))
                if train_net is not None and verify_net is not None and train_net<0 and verify_net<0:
                    row['state']='VERIFIED_LOSS'
                    loss_rows.append(row)
        recovery_rows.sort(key=lambda row:(0 if row.get('state')=='VERIFIED_POSITIVE' else 1 if row.get('state')=='VERIFIED_IMPROVING' else 2,-float(row.get('verify_after_cost_gain_pct') or -999),-float(row.get('missed_rise_coverage_pct') or 0),-int((row.get('verify') or {}).get('sample_count') or 0),str(row.get('label_ko') or '')))
        loss_rows.sort(key=lambda row:(float((row.get('verify') or {}).get('avg_after_cost_return_pct') or 0),float((row.get('train') or {}).get('avg_after_cost_return_pct') or 0),-int((row.get('verify') or {}).get('sample_count') or 0),str(row.get('label_ko') or '')))
        state_counts=Counter(str(row.get('state') or 'NOT_VERIFIED') for row in recovery_rows)
        horizons[horizon]={
            'state':'READY','sample_count':len(rows),'train_count':train_total,'verify_count':verify_total,
            'non_up_sample_count':int(baseline['recovery_train'].get('total') or 0)+int(baseline['recovery_verify'].get('total') or 0),
            'non_up_actual_rise_count':non_up_missed,
            'current_up_sample_count':int(baseline['up_train'].get('total') or 0)+int(baseline['up_verify'].get('total') or 0),
            'case_count':sum(1 for group,_combo in combo_keys if group=='recovery'),
            'verified_positive_count':int(state_counts.get('VERIFIED_POSITIVE') or 0),
            'verified_improving_count':int(state_counts.get('VERIFIED_IMPROVING') or 0),
            'baseline_non_up_train':_route_stat_public(baseline['recovery_train']),'baseline_non_up_verify':_route_stat_public(baseline['recovery_verify']),
            'baseline_current_up_train':_route_stat_public(baseline['up_train']),'baseline_current_up_verify':_route_stat_public(baseline['up_verify']),
            'top_verified_recovery_routes':[row for row in recovery_rows if row.get('state')=='VERIFIED_POSITIVE'][:8],
            'top_improving_recovery_routes':[row for row in recovery_rows if row.get('state')=='VERIFIED_IMPROVING'][:8],
            'top_verified_loss_routes':loss_rows[:8],
        }
    return {
        'schema':'sealed_outcome_path_validation','state':'READY' if any((block.get('state')=='READY') for block in horizons.values()) else 'WAITING',
        'owner':'review_worker read-only outcome analysis of Strategy seal','contract_id':CURRENT_PREDICTION_CONTRACT_ID,'formula_id':CURRENT_TIMEFRAME_ROLE_FORMULA_ID,
        'split_contract':'chronological 70% discovery / 30% verification per horizon','horizons':horizons,
        'strategy_formula_call_count':0,'review_input_recalculation_count':0,'sealed_decision_reclassification_count':0,
        'strategy_formula_changed':False,'candidate_gate_changed':False,'weights_changed':False,'thresholds_changed':False,
        'historical_ledgers_rewritten':False,'new_shadow_created':False,'analysis_only':True,'auto_buy':False,
    }

def build_live_prediction_model(nowv: float) -> Dict[str,Any]:
    targets={name:_build_target_model(name,nowv) for name in ('probability_3h','probability_6h','giveback_risk','late_capture_risk')}
    identity={'schema':'rise_prediction_live_model_identity','retention_days':5,'material_names':list(MATERIAL_NAMES),'targets':targets}
    model_id=hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()[:20]
    return {
        'schema':'rise_prediction_live_model','state':'LIVE' if any((target.get('effective_sample') or 0)>0 for target in targets.values()) else 'NO_SAMPLE',
        'owner':'review_worker','model_id':model_id,'generated_ts':nowv,'generated_text':now_text(nowv),
        'retention_days':5,'retention_contract':'최근 5일 상승예측 관찰자료만 사용; 대기기간 아님',
        'prediction_material_names':list(MATERIAL_NAMES),'prediction_material_count':len(MATERIAL_NAMES),
        'target_path_stage':'POST_STRUCTURE_ONLY','target_path_used_by_primary_prediction':False,
        'targets':targets,'prediction_calculation_active':True,'candidate_gate_active':True,'prediction_primary_selector_active':True,
        'candidate_penalty_active':False,'thresholds_applied':False,'historical_trade_recalculated':False,'auto_buy':False,
    }


def _directional_score_summary(rows: Iterable[Dict[str,Any]], event_filter=None) -> Dict[str,Any]:
    """Rebuild current selection results from immutable event+outcome rows.

    HOLD is preserved as HOLD.  Accuracy is only for explicit UP/DOWN calls;
    missed-rise includes both HOLD and DOWN actual rises.
    """
    groups=Counter(); by_horizon=defaultdict(Counter); matched_event_keys=set()
    for row in rows:
        event_key=str(row.get('event_key') or '')
        event=_event_for_outcome(row)
        if not isinstance(event,dict) or (event_filter is not None and not event_filter(event)):
            continue
        if str(row.get('outcome_state') or '')!='READY':
            continue
        selection=event.get('prediction_selection')
        decision=_normalize_decision(selection.get('decision') if isinstance(selection,dict) else selection)
        actual=str(row.get('actual_direction') or row.get('raw_actual_direction') or '').upper()
        if decision not in {'UP','HOLD','DOWN'} or actual not in {'UP','DOWN'}:
            continue
        horizon=str(row.get('horizon') or 'unknown')
        key=f'{decision}_{actual}'; groups[f'{horizon}:{key}']+=1; by_horizon[horizon][key]+=1
        matched_event_keys.add(event_key)
    accuracy={}; resolved_total=0
    for horizon,counts in by_horizon.items():
        up_up=int(counts.get('UP_UP') or 0); up_down=int(counts.get('UP_DOWN') or 0)
        hold_up=int(counts.get('HOLD_UP') or 0); hold_down=int(counts.get('HOLD_DOWN') or 0)
        down_up=int(counts.get('DOWN_UP') or 0); down_down=int(counts.get('DOWN_DOWN') or 0)
        explicit=up_up+up_down+down_up+down_down
        correct=up_up+down_down; actual_up=up_up+hold_up+down_up
        total=explicit+hold_up+hold_down; resolved_total+=total
        accuracy[horizon]={
            'resolved':total,'explicit_direction_resolved':explicit,'correct':correct,
            'accuracy_pct':round(correct/explicit*100.0,3) if explicit else None,
            'up_precision_pct':round(up_up/(up_up+up_down)*100.0,3) if up_up+up_down else None,
            'down_precision_pct':round(down_down/(down_down+down_up)*100.0,3) if down_down+down_up else None,
            'hold_count':hold_up+hold_down,'hold_rise_rate_pct':round(hold_up/(hold_up+hold_down)*100.0,3) if hold_up+hold_down else None,
            'missed_rise_rate_pct':round((hold_up+down_up)/actual_up*100.0,3) if actual_up else None,
        }
    return {
        'six_way_counts':dict(groups),'four_way_counts':dict(groups),
        'accuracy_by_horizon':accuracy,'resolved_total':resolved_total,'event_count':len(matched_event_keys),
        'scoring_contract':'UP/HOLD/DOWN selection against raw elapsed price direction; HOLD is never collapsed into DOWN',
    }



def _event_formula_id(event: Any) -> str:
    formula,state,_=_sealed_formula_identity(event)
    return str(formula or f'FORMULA_{state}')


def _review_event_identity(event: Any) -> str:
    if not isinstance(event, dict):
        return ''
    stored = str(event.get('review_event_key') or '').strip()
    if stored:
        return stored
    external = str(event.get('event_key') or '').strip()
    if not external:
        return ''
    contract = str(event.get('prediction_contract_id') or 'NO_CONTRACT').strip().upper() or 'NO_CONTRACT'
    formula = _event_formula_id(event)
    return f'{external}||{contract}||{formula}'


def _outcome_review_identity(row: Any) -> str:
    if not isinstance(row, dict):
        return ''
    return str(row.get('review_event_key') or '').strip()


def _normalize_review_identities(records: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    normalized: List[Dict[str, Any]] = []
    last_identity_by_external: Dict[str, str] = {}
    for source_row in records:
        row = dict(source_row)
        external = str(row.get('event_key') or '').strip()
        record_type = str(row.get('record_type') or '')
        if record_type == 'event' and external:
            identity = _review_event_identity(row)
            if identity:
                row['review_event_key'] = identity
                last_identity_by_external[external] = identity
        elif record_type == 'outcome' and external:
            identity = str(row.get('review_event_key') or '').strip() or last_identity_by_external.get(external, '')
            if identity:
                row['review_event_key'] = identity
        normalized.append(row)
    return normalized


def _event_for_outcome(row: Any) -> Optional[Dict[str, Any]]:
    identity = _outcome_review_identity(row)
    if identity:
        event = _EVENTS.get(identity)
        if isinstance(event, dict):
            return event
    external = str((row or {}).get('event_key') or '').strip() if isinstance(row, dict) else ''
    if not external:
        return None
    matches = [event for event in _EVENTS.values() if str(event.get('event_key') or '') == external]
    if not matches:
        return None
    current = [event for event in matches if _prediction_contract_id(event) == CURRENT_PREDICTION_CONTRACT_ID]
    if current:
        return current[-1]
    return matches[-1]


def _event_record(row: Dict[str, Any], snapshot: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    payload = _rise_input(row)
    event_key = str(payload.get('event_key') or '')
    event_ts = num(payload.get('event_bar_close_ts'))
    symbol = ticker(payload.get('ticker') or row.get('ticker'))
    if not event_key or event_ts is None or not symbol:
        return None
    materials = payload.get('materials') if isinstance(payload.get('materials'), dict) else {}
    material_names = list(payload.get('material_names') or [])
    explicit_contract=str(payload.get('prediction_contract_id') or '').strip().upper()
    role_input=payload.get('timeframe_role_input') if isinstance(payload.get('timeframe_role_input'),dict) else {}
    role_evaluation=payload.get('timeframe_role_evaluation') if isinstance(payload.get('timeframe_role_evaluation'),dict) else {}
    sealed_formula_id,sealed_formula_state,sealed_formula_sources=_sealed_formula_identity(payload)
    current_prediction_contract = bool(
        explicit_contract==CURRENT_PREDICTION_CONTRACT_ID
        and sealed_formula_state=='PASS'
        and sealed_formula_id==CURRENT_TIMEFRAME_ROLE_FORMULA_ID
    )
    baseline_prediction_contract = tuple(material_names) == MATERIAL_NAMES and 'target_path_consumed_ratio' not in material_names
    prediction_contract_id = CURRENT_PREDICTION_CONTRACT_ID if current_prediction_contract else BASELINE_PREDICTION_CONTRACT_ID if baseline_prediction_contract else PREVIOUS_PREDICTION_CONTRACT_ID
    contract_state = (
        str(payload.get('model_state') or payload.get('state') or 'MISSING') if current_prediction_contract
        else f'FORMULA_{sealed_formula_state}' if explicit_contract==CURRENT_PREDICTION_CONTRACT_ID and sealed_formula_state!='PASS'
        else 'FORMULA_MISMATCH' if explicit_contract==CURRENT_PREDICTION_CONTRACT_ID
        else 'BASELINE' if baseline_prediction_contract
        else 'MATERIAL_CONTRACT_MISMATCH'
    )
    structure = payload.get('structure_contract') if isinstance(payload.get('structure_contract'), dict) else {}
    post_structure = payload.get('post_structure_observation') if isinstance(payload.get('post_structure_observation'), dict) else {}
    if not post_structure and structure.get('target_path_consumed_ratio') is not None:
        post_structure = {
            'target_path_consumed_ratio': num(structure.get('target_path_consumed_ratio')),
            'owner': structure.get('target_path_owner'),
            'stage': structure.get('target_path_stage'),
            'used_by_primary_prediction': False,
            'structure_state': structure.get('state'),
        }
    baseline = payload.get('baseline_decision') if isinstance(payload.get('baseline_decision'), dict) else {}
    probability_3h=num(payload.get('probability_3h'))
    probability_6h=num(payload.get('probability_6h'))
    giveback_risk=num(payload.get('giveback_risk'))
    late_capture_risk=num(payload.get('late_capture_risk'))
    role_combined_probability=num(role_evaluation.get('combined_probability_pct'))
    selection=str(((payload.get('primary_selection') or {}).get('decision') if isinstance(payload.get('primary_selection'),dict) else None) or role_evaluation.get('decision') or 'UNKNOWN').upper()
    record = {
        'schema': 'rise_prediction_ledger_record','record_type': 'event','contract_generation': 'INFORMATION_CONTRACT_COMPLETE','information_contract_complete': True,
        'event_key': event_key,'event_ts': event_ts,'event_text': now_text(event_ts),'ticker': symbol,'event_price': num(payload.get('event_price')),
        'episode_id': payload.get('episode_id'),'episode_low_ts': num(payload.get('episode_low_ts')),'episode_low_price': num(payload.get('episode_low_price')),
        'pre_signal_rise_pct': num(payload.get('pre_signal_rise_pct')),'signal_position': payload.get('signal_position') if isinstance(payload.get('signal_position'), dict) else {},
        'price_volume_sequence': payload.get('price_volume_sequence') if isinstance(payload.get('price_volume_sequence'), dict) else {'state':'UNKNOWN'},
        'explanation_tags': list(payload.get('explanation_tags') or []),'explanation_tag_labels_ko': list(payload.get('explanation_tag_labels_ko') or []),
        'explanation_tag_evidence': payload.get('explanation_tag_evidence') if isinstance(payload.get('explanation_tag_evidence'), dict) else {},
        'tag_overlap_allowed': True,'tag_used_as_gate': False,'input_state': contract_state,'input_coverage_pct': num(payload.get('input_coverage_pct')),
        'usable_input_count':int(payload.get('usable_input_count') or 0),'source_state_counts': payload.get('source_state_counts') if isinstance(payload.get('source_state_counts'), dict) else {},
        'materials': materials,'material_values': payload.get('material_values') if isinstance(payload.get('material_values'), dict) else {},'material_names': material_names,
        'prediction_material_count':len(material_names),'prediction_contract_id':prediction_contract_id,'post_structure_observation':post_structure,
        'target_path_used_by_primary_prediction':False,
        'probability_3h': probability_3h,'probability_6h': probability_6h,'giveback_risk': giveback_risk,'late_capture_risk': late_capture_risk,
        'probability_1h_timing':num(payload.get('probability_1h_timing')),'probability_4h_structure':num(payload.get('probability_4h_structure')),'probability_24h_context':num(payload.get('probability_24h_context')),
        'timeframe_role_combined_probability':role_combined_probability,'timeframe_role_input':role_input,'timeframe_role_evaluation':role_evaluation,'timeframe_role_formula_id':sealed_formula_id or payload.get('timeframe_role_formula_id'),
        'sealed_formula_id':sealed_formula_id,'sealed_formula_state':sealed_formula_state,'sealed_formula_sources':sealed_formula_sources,
        'prediction_selection': selection,
        'prediction_selection_reason': ((payload.get('primary_selection') or {}).get('reason') if isinstance(payload.get('primary_selection'),dict) else None),
        'prediction_first': True,
        'predicted_direction_3h':(selection if current_prediction_contract and selection in {'UP','DOWN','HOLD'} else payload.get('predicted_direction_3h') or ('UP' if probability_3h is not None and probability_3h>50.0 else 'DOWN' if probability_3h is not None and probability_3h<50.0 else 'NEUTRAL' if probability_3h is not None else None)),
        'predicted_direction_6h':(selection if current_prediction_contract and selection in {'UP','DOWN','HOLD'} else payload.get('predicted_direction_6h') or ('UP' if probability_6h is not None and probability_6h>50.0 else 'DOWN' if probability_6h is not None and probability_6h<50.0 else 'NEUTRAL' if probability_6h is not None else None)),
        'elapsed_horizons_are_result_checks_only':True,
        'output_states': payload.get('output_states') if isinstance(payload.get('output_states'), dict) else {},
        'model_state': str(payload.get('model_state') or 'NO_MODEL'),'prediction_model_id':payload.get('prediction_model_id'),
        'prediction_model_generated_ts':num(payload.get('prediction_model_generated_ts')),'prediction_confidence_pct':num(payload.get('prediction_confidence_pct')),
        'prediction_confidence_state':payload.get('prediction_confidence_state'),'prediction_evidence_count':int(payload.get('prediction_evidence_count') or 0),
        'probability_calculated':role_combined_probability is not None if current_prediction_contract else probability_3h is not None and probability_6h is not None,
        'weights_applied': bool(payload.get('weights_applied')),'thresholds_applied': bool(payload.get('thresholds_applied')),'prediction_used_as_gate': True,
        'structure_contract': structure,'baseline_decision': baseline,'baseline_decision_reasons': list(baseline.get('reasons') or []),
        'execution_cost_observation': payload.get('execution_cost_observation') if isinstance(payload.get('execution_cost_observation'), dict) else {},
        'baseline_decision_basis': 'RISE_PREDICTION_PRIMARY_THEN_STRUCTURE',
        'candidate_snapshot_id': snapshot.get('snapshot_id'),'candidate_commit_id': snapshot.get('candidate_commit_id'),'cycle_id': snapshot.get('cycle_id'),
        'owner': 'review_worker','review_recomputed_inputs': False,'zero_fill_used': False,'auto_buy': False,
    }
    record['review_event_key'] = _review_event_identity(record)
    return record


def _load_rollup_dates() -> None:
    for row in read_jsonl(ROLLUP_LEDGER):
        source_date = str(row.get('source_date') or '')
        record_type = str(row.get('record_type') or '')
        if source_date and record_type == 'daily_rollup':
            _ROLLED_DATES.add(source_date)
        if source_date and record_type == 'daily_rollup_final':
            _FINALIZED_DATES.add(source_date)


def load_state_once() -> None:
    global _STATE_LOADED, _COLLECTION_START_TS
    if _STATE_LOADED:
        return
    LEDGER_DIR.mkdir(parents=True, exist_ok=True)
    _load_rollup_dates()
    cutoff = now_ts() - RAW_RETENTION_SEC - 24 * 3600.0
    last_identity_by_external: Dict[str, str] = {}
    for path in sorted(LEDGER_DIR.glob('20??-??-??.jsonl')):
        try:
            date_ts = time.mktime(time.strptime(path.stem, '%Y-%m-%d'))
        except Exception:
            continue
        if date_ts < cutoff:
            continue
        for source_row in read_jsonl(path):
            row = dict(source_row)
            record_type = str(row.get('record_type') or '')
            external_key = str(row.get('event_key') or '')
            if record_type == 'event' and external_key:
                identity = _review_event_identity(row)
                if not identity:
                    continue
                row['review_event_key'] = identity
                if _event_contract_generation(row) != 'INFORMATION_CONTRACT_COMPLETE':
                    _LEGACY_EVENT_KEYS.add(external_key)
                # Preserve every formula generation in memory. Only an exact
                # external-key + contract + formula identity is a duplicate.
                _EVENTS[identity] = row
                last_identity_by_external[external_key] = identity
                event_ts = num(row.get('event_ts'))
                if event_ts is not None:
                    _COLLECTION_START_TS = event_ts if _COLLECTION_START_TS is None else min(_COLLECTION_START_TS, event_ts)
            elif record_type == 'outcome' and external_key and row.get('horizon'):
                identity = str(row.get('review_event_key') or '').strip() or last_identity_by_external.get(external_key, '')
                if not identity:
                    continue
                row['review_event_key'] = identity
                outcome_key = (identity, str(row.get('horizon')))
                if str(row.get('outcome_state') or '') in {'READY', 'FAILED_SOURCE_MISSING'}:
                    _OUTCOMES.add(outcome_key)
                    _OUTCOME_ROWS[outcome_key] = row
    _STATE_LOADED = True


def _cache_pairs(obj: Any) -> Iterable[Tuple[str, Dict[str, Any]]]:
    if isinstance(obj, dict):
        rows = obj.get('rows')
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict):
                    yield ticker(row.get('ticker') or row.get('symbol') or row.get('market')), row
            return
        if isinstance(rows, dict):
            for key, row in rows.items():
                if isinstance(row, dict):
                    yield ticker(key or row.get('ticker')), row
            return
        for key, row in obj.items():
            if isinstance(row, dict) and isinstance(row.get('structure_lab_candles'), dict):
                yield ticker(key or row.get('ticker')), row
    elif isinstance(obj, list):
        for row in obj:
            if isinstance(row, dict):
                yield ticker(row.get('ticker') or row.get('symbol') or row.get('market')), row


def _apply_delta(row: Dict[str, Any], ops: Any) -> Dict[str, Any]:
    import copy
    out = copy.deepcopy(row) if isinstance(row, dict) else {}
    for op in ops if isinstance(ops, list) else []:
        if not isinstance(op, dict):
            continue
        kind = str(op.get('op') or '')
        path = [str(item) for item in (op.get('path') or [])]
        if not path:
            continue
        current = out
        valid = True
        for key in path[:-1]:
            if not isinstance(current, dict):
                valid = False
                break
            next_value = current.get(key)
            if not isinstance(next_value, dict):
                if kind == 'remove':
                    valid = False
                    break
                next_value = {}
                current[key] = next_value
            current = next_value
        if not valid or not isinstance(current, dict):
            continue
        key = path[-1]
        if kind == 'remove':
            current.pop(key, None)
        elif kind == 'set':
            current[key] = copy.deepcopy(op.get('value'))
        elif kind == 'list_roll':
            existing = current.get(key) if isinstance(current.get(key), list) else []
            drop = max(0, int(num(op.get('drop_front'), 0.0) or 0))
            additions = op.get('append') if isinstance(op.get('append'), list) else []
            current[key] = copy.deepcopy(existing[drop:] + additions)
    return out


def _normalize_frame(rows: Any) -> List[Dict[str, float]]:
    out = []
    for item in rows if isinstance(rows, list) else []:
        if isinstance(item, dict):
            ts = num(item.get('ts')); op = num(item.get('o')); close = num(item.get('c')); high = num(item.get('h')); low = num(item.get('l')); volume = num(item.get('v'), 0.0)
        elif isinstance(item, (list, tuple)) and len(item) >= 6:
            ts, op, close, high, low, volume = (num(item[0]), num(item[1]), num(item[2]), num(item[3]), num(item[4]), num(item[5], 0.0))
        else:
            continue
        if None in (ts, op, close, high, low) or min(float(op), float(close), float(high), float(low)) <= 0:
            continue
        out.append({'ts': float(ts), 'o': float(op), 'c': float(close), 'h': float(high), 'l': float(low), 'v': max(0.0, float(volume or 0.0))})
    out.sort(key=lambda item: item['ts'])
    return out


def candle_index() -> Tuple[Dict[str, Dict[str, List[Dict[str, float]]]], int]:
    global _CANDLE_SIGNATURE, _CANDLE_INDEX, _CANDLE_COUNT
    signature = (file_signature(CANDLE_CACHE), file_signature(CANDLE_DELTA))
    if _CANDLE_SIGNATURE == signature and _CANDLE_INDEX:
        return _CANDLE_INDEX, _CANDLE_COUNT
    base_obj = load_json(CANDLE_CACHE, {}) or {}
    source: Dict[str, Dict[str, Any]] = {}
    checkpoint = str(base_obj.get('delta_checkpoint_id_v1016') or '') if isinstance(base_obj, dict) else ''
    for symbol, row in _cache_pairs(base_obj):
        if symbol:
            source[symbol] = dict(row)
    if CANDLE_DELTA.exists():
        try:
            with CANDLE_DELTA.open('r', encoding='utf-8', errors='ignore') as handle:
                for line in handle:
                    try:
                        item = json.loads(line)
                    except Exception:
                        continue
                    if not isinstance(item, dict):
                        continue
                    symbol = ticker(item.get('ticker'))
                    if not symbol:
                        continue
                    schema = str(item.get('schema') or '')
                    if schema == 'candle_delta_ops_v1016':
                        base_checkpoint = str(item.get('base_checkpoint_id_v1016') or '')
                        if checkpoint and base_checkpoint and checkpoint != base_checkpoint:
                            continue
                        source[symbol] = _apply_delta(source.get(symbol, {}), item.get('ops'))
                    elif schema == 'candle_delta_patch_v1015' and isinstance(item.get('row'), dict):
                        source[symbol] = dict(item.get('row'))
        except Exception as exc:
            append_error('candle_delta', exc)
    index: Dict[str, Dict[str, List[Dict[str, float]]]] = {}
    count = 0
    for symbol, row in source.items():
        lab = row.get('structure_lab_candles') if isinstance(row.get('structure_lab_candles'), dict) else {}
        frames = lab.get('frames') if isinstance(lab.get('frames'), dict) else {}
        normalized = {}
        for tf in ('m1', 'm3', 'm5', 'm15', 'm30', 'h1', 'h4', 'd1'):
            values = _normalize_frame(frames.get(tf))
            if values:
                normalized[tf] = values
                count += len(values)
        if normalized:
            index[symbol] = normalized
    _CANDLE_SIGNATURE = signature
    _CANDLE_INDEX = index
    _CANDLE_COUNT = count
    return index, count


def _select_path(frames: Dict[str, List[Dict[str, float]]], start_ts: float, end_ts: float) -> Tuple[str, List[Dict[str, float]], str]:
    choices = (('m1', 60.0), ('m3', 180.0), ('m5', 300.0), ('m15', 900.0), ('m30', 1800.0))
    best_tf = ''
    best_rows: List[Dict[str, float]] = []
    best_reason = 'CANDLE_PATH_MISSING'
    for tf, sec in choices:
        rows = [row for row in frames.get(tf, []) if start_ts <= row['ts'] < end_ts]
        if not rows:
            continue
        last_end = rows[-1]['ts'] + sec
        if last_end + sec * 0.25 < end_ts:
            best_reason = f'{tf}_HORIZON_INCOMPLETE'
            continue
        return tf, rows, 'READY'
    return best_tf, best_rows, best_reason


def _exact_rows(obj: Any) -> Iterable[Dict[str, Any]]:
    if isinstance(obj, list):
        for row in obj:
            if isinstance(row, dict):
                yield row
        return
    if not isinstance(obj, dict):
        return
    for key in ('rows', 'positions', 'open', 'records'):
        value = obj.get(key)
        if isinstance(value, list):
            for row in value:
                if isinstance(row, dict):
                    yield row
            return
        if isinstance(value, dict):
            for row in value.values():
                if isinstance(row, dict):
                    yield row
            return
    for row in obj.values():
        if isinstance(row, dict) and (row.get('decision_key') or row.get('source_decision_key')):
            yield row


def _decision_key(row: Dict[str, Any]) -> str:
    return str(row.get('decision_key') or row.get('source_decision_key') or row.get('direct_decision_key_v2149') or '').strip()


def paper_exact_index() -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    open_obj = load_json(PAPER_EXACT_OPEN, {}) or {}
    for row in _exact_rows(open_obj):
        key = _decision_key(row)
        if key:
            index[key] = {'state': 'OPEN', 'row': row}
    for row in read_jsonl(PAPER_EXACT_CLOSED):
        key = _decision_key(row)
        if key:
            index[key] = {'state': 'CLOSED', 'row': row}
    return index


def _paper_execution_result(event: Dict[str, Any], paper_index: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    baseline = event.get('baseline_decision') if isinstance(event.get('baseline_decision'), dict) else {}
    key = str(baseline.get('decision_key') or '').strip()
    if not baseline.get('entry_eligible'):
        return {'state':'NOT_APPLICABLE_BASELINE_HOLD','decision_key':key or None,'actual_execution':False,'after_cost_return_pct':None}
    if not key:
        return {'state':'MISSING_DECISION_KEY','decision_key':None,'actual_execution':None,'after_cost_return_pct':None}
    link = paper_index.get(key)
    if not isinstance(link, dict):
        return {'state':'NOT_EXECUTED_OR_NOT_YET_LINKED','decision_key':key,'actual_execution':False,'after_cost_return_pct':None}
    row = link.get('row') if isinstance(link.get('row'), dict) else {}
    preview = row.get('paper_execution_preview_v2149_at_open') if isinstance(row.get('paper_execution_preview_v2149_at_open'), dict) else {}
    exit_contract = row.get('v2_exit_contract_v2149') if isinstance(row.get('v2_exit_contract_v2149'), dict) else {}
    cost = num(preview.get('roundtrip_cost_pct'))
    if cost is None:
        cost = num(exit_contract.get('roundtrip_cost_pct'))
    after_cost = num(row.get('net_after_configured_fee_pct_v983'))
    if after_cost is None:
        after_cost = num(row.get('pnl_pct'))
    if after_cost is None:
        after_cost = num(row.get('last_pnl_pct'))
    return {
        'state': f"READY_ACTUAL_{str(link.get('state') or 'UNKNOWN')}",
        'decision_key': key,
        'actual_execution': True,
        'paper_state': link.get('state'),
        'entry_price': num(row.get('entry_price')),
        'opened_ts': num(row.get('paper_v2_exact_opened_ts'), num(row.get('opened_at'))),
        'closed_ts': num(row.get('closed_ts')),
        'spread_pct': num(preview.get('spread_pct')),
        'slippage_pct': num(preview.get('slippage_pct')),
        'fee_pct': num(preview.get('fee_pct')),
        'roundtrip_cost_pct': cost,
        'after_cost_return_pct': after_cost,
        'cost_source': 'paper exact sealed OPEN/CLOSED contract',
        'current_value_substitution_used': False,
    }



def resolve_outcome(event: Dict[str, Any], horizon: str, horizon_sec: float, index: Dict[str, Dict[str, List[Dict[str, float]]]], nowv: float, paper_index: Optional[Dict[str, Dict[str, Any]]] = None) -> Optional[Dict[str, Any]]:
    event_key=str(event.get('event_key') or ''); event_ts=num(event.get('event_ts')); event_price=num(event.get('event_price')); symbol=ticker(event.get('ticker'))
    if not event_key or event_ts is None or event_price is None or event_price<=0 or not symbol: return None
    if nowv<event_ts+horizon_sec: return None
    frames=index.get(symbol) or {}; frame_name,path,state=_select_path(frames,event_ts,event_ts+horizon_sec)
    current_role_contract=_prediction_contract_id(event)==CURRENT_PREDICTION_CONTRACT_ID
    if current_role_contract:
        prediction_field='timeframe_role_combined_probability'
        prediction_probability=num(event.get(prediction_field))
        predicted_direction=str(event.get('prediction_selection') or '').upper()
    else:
        prediction_field='probability_6h' if horizon=='6h' else 'probability_3h'
        prediction_probability=num(event.get(prediction_field))
        sealed_direction_field='predicted_direction_6h' if horizon=='6h' else 'predicted_direction_3h'
        predicted_direction=str(event.get(sealed_direction_field) or '').upper() or ('UP' if prediction_probability is not None and prediction_probability>50.0 else 'DOWN' if prediction_probability is not None and prediction_probability<50.0 else 'NEUTRAL' if prediction_probability is not None else None)
    if not path:
        return {'schema':'rise_prediction_ledger_record','record_type':'outcome','event_key':event_key,'event_ts':event_ts,'ticker':symbol,'horizon':horizon,'horizon_sec':horizon_sec,
                'outcome_state':'MISSING','missing_reason':state,'source_frame':frame_name or None,'prediction_probability_pct':prediction_probability,
                'prediction_probability_field':prediction_field,'predicted_direction':predicted_direction,'baseline_passed':bool((event.get('baseline_decision') or {}).get('entry_eligible')),
                'target_first':False,'invalid_first':False,'actual_rise_success':None,'completed_ts':nowv,'completed_text':now_text(nowv),'owner':'review_worker','zero_fill_used':False,'auto_buy':False}
    structure=event.get('structure_contract') if isinstance(event.get('structure_contract'),dict) else {}; target=num(structure.get('target_t1')); invalid=num(structure.get('execution_invalid'))
    first_target=None; first_invalid=None; ambiguous_ts=None; max_price=event_price; min_price=event_price; max_ts=event_ts; min_ts=event_ts
    for bar in path:
        high=float(bar['h']); low=float(bar['l'])
        if high>max_price: max_price=high; max_ts=float(bar['ts'])
        if low<min_price: min_price=low; min_ts=float(bar['ts'])
        hit_target=target is not None and high>=target; hit_invalid=invalid is not None and low<=invalid
        if hit_target and first_target is None: first_target=float(bar['ts'])
        if hit_invalid and first_invalid is None: first_invalid=float(bar['ts'])
        if hit_target and hit_invalid and ambiguous_ts is None: ambiguous_ts=float(bar['ts'])
    if first_target is not None and first_invalid is not None:
        touch_order='AMBIGUOUS_SAME_BAR' if first_target==first_invalid else 'TARGET_FIRST' if first_target<first_invalid else 'INVALID_FIRST'
    elif first_target is not None: touch_order='TARGET_FIRST'
    elif first_invalid is not None: touch_order='INVALID_FIRST'
    else: touch_order='NO_TOUCH'
    final_price=float(path[-1]['c']); final_return=(final_price/event_price-1.0)*100.0; mfe=(max_price/event_price-1.0)*100.0; mae=(min_price/event_price-1.0)*100.0; giveback=mfe-final_return
    pre_rise=num(event.get('pre_signal_rise_pct')); early_capture=None
    if pre_rise is not None and pre_rise>=0 and mfe>0 and pre_rise+mfe>0: early_capture=mfe/(pre_rise+mfe)
    passed=bool((event.get('baseline_decision') or {}).get('entry_eligible')); paper_result=_paper_execution_result(event,paper_index or {})
    success=True if touch_order=='TARGET_FIRST' else False if touch_order=='INVALID_FIRST' else None
    result_group='PASS_RISE' if passed and success is True else 'PASS_FAIL' if passed and success is False else 'HOLD_MISSED_RISE' if not passed and success is True else 'HOLD_CORRECT' if not passed and success is False else 'UNRESOLVED'
    estimated_cost,cost_basis=_sealed_estimated_cost_pct(event); scored_net_return=final_return-estimated_cost
    raw_direction='UP' if final_return>0 else 'DOWN' if final_return<0 else 'FLAT'
    actual_direction=raw_direction
    directional_group=None; prediction_correct=None; brier=None
    if predicted_direction in {'UP','DOWN'} and actual_direction in {'UP','DOWN'}:
        directional_group=f'{predicted_direction}_{actual_direction}'; prediction_correct=predicted_direction==actual_direction
        brier=(prediction_probability/100.0-(1.0 if actual_direction=='UP' else 0.0))**2 if prediction_probability is not None else None
    after_cost=num(paper_result.get('after_cost_return_pct')); after_cost_direction='UP' if after_cost is not None and after_cost>0 else 'DOWN' if after_cost is not None and after_cost<0 else 'FLAT' if after_cost==0 else None
    actual_giveback=bool(mfe>0 and giveback/max(mfe,1e-9)>=0.50); actual_late=bool(early_capture is not None and early_capture<0.50)
    shadow_net_mfe=mfe-estimated_cost
    shadow_rise_opportunity=shadow_net_mfe>0.0
    shadow_profitable_finish=scored_net_return>0.0
    return {
        'schema':'rise_prediction_ledger_record','record_type':'outcome','event_key':event_key,'event_ts':event_ts,'ticker':symbol,'episode_id':event.get('episode_id'),
        'horizon':horizon,'horizon_sec':horizon_sec,'outcome_state':'READY','touch_order':touch_order,'target_first':touch_order=='TARGET_FIRST','invalid_first':touch_order=='INVALID_FIRST',
        'actual_rise_success':success,'baseline_passed':passed,'baseline_decision_basis':'RISE_PREDICTION_PRIMARY_THEN_STRUCTURE','result_group':result_group,
        'prediction_model_id':event.get('prediction_model_id'),'prediction_probability_field':prediction_field,'elapsed_horizon_result_check_only':True,'prediction_probability_pct':prediction_probability,
        'predicted_direction':predicted_direction,'actual_direction':actual_direction,'raw_actual_direction':raw_direction,'cost_aligned_actual_direction':('UP' if scored_net_return>0 else 'DOWN' if scored_net_return<0 else 'FLAT'),'directional_score_group':directional_group,'prediction_correct':prediction_correct,
        'brier_score':round(brier,10) if brier is not None else None,'score_available_immediately_at_horizon':True,
        'shadow_answer_contract':'ACTUAL_PATH_THREE_LAYER_V2','shadow_answer':('TARGET_FIRST' if touch_order=='TARGET_FIRST' else 'INVALID_FIRST' if touch_order=='INVALID_FIRST' else 'AMBIGUOUS_SAME_BAR' if touch_order=='AMBIGUOUS_SAME_BAR' else 'PROFITABLE_FINISH_NO_TOUCH' if shadow_profitable_finish else 'INTRAPATH_OPPORTUNITY_ONLY' if shadow_rise_opportunity else 'NO_RISE'),
        'shadow_contract_success':(True if touch_order=='TARGET_FIRST' else False if touch_order=='INVALID_FIRST' else None),
        'shadow_rise_opportunity':shadow_rise_opportunity,'shadow_profitable_finish':shadow_profitable_finish,'shadow_net_mfe_after_cost_pct':round(shadow_net_mfe,8),
        'shadow_answer_actual_path_only':True,'shadow_answer_strategy_formula_used':False,
        'event_price':event_price,'final_price':final_price,'final_return_pct':round(final_return,8),'scored_net_return_pct':round(scored_net_return,8),
        'scoring_cost_pct':round(estimated_cost,8),'scoring_cost_basis':cost_basis,'mfe_pct':round(mfe,8),'mae_pct':round(mae,8),
        'mfe_ts':max_ts,'mae_ts':min_ts,'mfe_delay_sec':round(max(0.0,max_ts-event_ts),3),'giveback_pct':round(giveback,8),
        'actual_giveback_risk':actual_giveback,'actual_late_capture_risk':actual_late,'post_signal_additional_rise_pct':round(mfe,8),
        'early_capture_ratio':round(early_capture,8) if early_capture is not None else None,'episode_event_index':event.get('episode_event_index'),'is_first_episode_event':event.get('is_first_episode_event'),
        'explanation_tags':list(event.get('explanation_tags') or []),'price_volume_sequence_state':(event.get('price_volume_sequence') or {}).get('state') if isinstance(event.get('price_volume_sequence'),dict) else 'UNKNOWN',
        'paper_execution_result':paper_result,'cost_result_state':paper_result.get('state'),'after_cost_return_pct':after_cost,'after_cost_actual_direction':after_cost_direction,
        'pre_signal_rise_pct':pre_rise,'first_target_ts':first_target,'first_invalid_ts':first_invalid,'ambiguous_same_bar_ts':ambiguous_ts,'source_frame':frame_name,
        'source_completed_candles_only':True,'completed_ts':nowv,'completed_text':now_text(nowv),'owner':'review_worker','review_recomputed_inputs':False,'zero_fill_used':False,'auto_buy':False
    }


def append_new_events(snapshot: Dict[str, Any]) -> Tuple[int, int]:
    global _COLLECTION_START_TS
    created = 0
    duplicates = 0
    for row in _candidate_rows(snapshot):
        record = _event_record(row, snapshot)
        if not record:
            continue
        external_key = str(record['event_key'])
        identity = _review_event_identity(record)
        if not identity:
            continue
        record['review_event_key'] = identity
        if identity in _EVENTS:
            duplicates += 1
            continue
        # Same coin+completed-bar under a different formula is a new Review
        # event. The external Strategy key remains unchanged.
        episode = str(record.get('episode_id') or external_key)
        prior_episode_events = [
            event for existing_identity, event in _EVENTS.items()
            if existing_identity != identity and str(event.get('episode_id') or event.get('event_key')) == episode
        ]
        record['episode_event_index'] = len(prior_episode_events) + 1
        record['is_first_episode_event'] = not prior_episode_events
        record['episode_first_event_key'] = str(prior_episode_events[0].get('event_key')) if prior_episode_events else external_key
        append_jsonl(raw_path(day_key(float(record['event_ts']))), record)
        _EVENTS[identity] = record
        _COLLECTION_START_TS = float(record['event_ts']) if _COLLECTION_START_TS is None else min(_COLLECTION_START_TS, float(record['event_ts']))
        created += 1
    return created, duplicates


def append_due_outcomes(nowv: float, index: Dict[str, Dict[str, List[Dict[str, float]]]], paper_index: Optional[Dict[str, Dict[str, Any]]] = None) -> Dict[str, int]:
    counts = Counter()
    for key, event in list(_EVENTS.items()):
        event_ts = num(event.get('event_ts'))
        if event_ts is None or nowv - event_ts > RAW_RETENTION_SEC + 24 * 3600.0:
            continue
        for horizon, sec in HORIZONS:
            outcome_key = (key, horizon)
            if outcome_key in _OUTCOMES or nowv < event_ts + sec:
                continue
            record = resolve_outcome(event, horizon, sec, index, nowv, paper_index or {})
            if record is None:
                continue
            state = str(record.get('outcome_state') or 'MISSING')
            if state != 'READY':
                # Candle outcome data can arrive late. Do not seal MISSING and do not
                # zero-fill; retry through the existing Candle cache on later cycles.
                counts[f'{horizon}:PENDING_{state}'] += 1
                continue
            record['review_event_key'] = key
            append_jsonl(raw_path(day_key(event_ts)), record)
            _OUTCOMES.add(outcome_key)
            _OUTCOME_ROWS[outcome_key] = record
            counts[f'{horizon}:READY'] += 1
    return dict(counts)


def _weighted_average(rows: List[Tuple[float, float]]) -> Optional[float]:
    denominator = sum(weight for _, weight in rows)
    return sum(value * weight for value, weight in rows) / denominator if denominator > 0 else None


def _rate_rows(counter: Dict[str, Counter]) -> Dict[str, Dict[str, Any]]:
    out: Dict[str, Dict[str, Any]] = {}
    for key, values in counter.items():
        total = int(values.get('total') or 0)
        success = int(values.get('success') or 0)
        out[key] = {'total': total, 'success': success, 'target_first_rate_pct': round(success / total * 100.0, 3) if total else None}
    return out


def _material_bucket(value: Any) -> str:
    numeric = num(value)
    if numeric is not None:
        if numeric > 0: return 'POSITIVE'
        if numeric < 0: return 'NEGATIVE'
        return 'ZERO'
    if isinstance(value, dict):
        risk = str(value.get('risk_state') or 'UNKNOWN')
        context = str(value.get('context_state') or 'UNKNOWN')
        return f'RISK_{risk}|CONTEXT_{context}'
    return 'MISSING'


def build_rollup(date_text: str, records: List[Dict[str, Any]], *, final: bool = False) -> Dict[str, Any]:
    records = _normalize_review_identities(records)
    events = {_review_event_identity(row): row for row in records if row.get('record_type') == 'event' and row.get('event_key') and _review_event_identity(row)}
    outcomes = [row for row in records if row.get('record_type') == 'outcome']
    episode_counts = Counter(str(row.get('episode_id') or row.get('event_key')) for row in events.values())
    outcome_counts = Counter()
    current_prediction_contract_events = [event for event in _EVENTS.values() if _prediction_contract_id(event) == CURRENT_PREDICTION_CONTRACT_ID]
    input_states = Counter(str(row.get('input_state') or 'MISSING') for row in events.values())
    material_states = Counter()
    material_source_states = Counter()
    material_missing_reasons = Counter()
    tag_counts = Counter()
    sequence_counts = Counter()
    first_repeat_counts = Counter()
    cost_states = Counter()
    metrics: Dict[str, Dict[str, List[Tuple[float, float]]]] = defaultdict(lambda: defaultdict(list))
    material_groups: Dict[str, Dict[str, List[Tuple[float, float]]]] = defaultdict(lambda: defaultdict(list))
    tag_results: Dict[str, Counter] = defaultdict(Counter)
    sequence_results: Dict[str, Counter] = defaultdict(Counter)
    material_bucket_results: Dict[str, Counter] = defaultdict(Counter)
    cost_metrics: Dict[str, List[Tuple[float, float]]] = defaultdict(list)
    for event in events.values():
        for tag in event.get('explanation_tags') or []:
            tag_counts[str(tag)] += 1
        sequence = event.get('price_volume_sequence') if isinstance(event.get('price_volume_sequence'), dict) else {}
        sequence_counts[str(sequence.get('state') or 'UNKNOWN')] += 1
        first_repeat_counts['FIRST' if event.get('is_first_episode_event') else 'REPEAT'] += 1
        for name, item in (event.get('materials') or {}).items():
            if not isinstance(item, dict): continue
            material_states[f"{name}:{str(item.get('state') or 'MISSING')}"] += 1
            material_source_states[f"{name}:{str(item.get('source_state') or 'MISSING')}"] += 1
            if item.get('missing_reason'):
                material_missing_reasons[f"{name}:{str(item.get('missing_reason'))}"] += 1
    for row in outcomes:
        key = str(row.get('review_event_key') or '')
        event = events.get(key, {}) if key else {}
        if not event:
            external = str(row.get('event_key') or '')
            matches = [candidate for candidate in events.values() if str(candidate.get('event_key') or '') == external]
            event = matches[-1] if matches else {}
        episode = str(event.get('episode_id') or key)
        weight = 1.0 / max(1, episode_counts.get(episode, 1))
        horizon = str(row.get('horizon') or 'unknown')
        group = str(row.get('result_group') or row.get('outcome_state') or 'unknown')
        outcome_counts[f'{horizon}:{group}'] += 1
        success = row.get('actual_rise_success') is True
        resolved = row.get('actual_rise_success') in {True, False}
        for metric in ('final_return_pct', 'mfe_pct', 'mae_pct', 'giveback_pct', 'early_capture_ratio', 'post_signal_additional_rise_pct'):
            value = num(row.get(metric))
            if value is not None:
                metrics[horizon][metric].append((value, weight))
        values = event.get('material_values') if isinstance(event.get('material_values'), dict) else {}
        for name in MATERIAL_NAMES:
            value = values.get(name)
            numeric = num(value)
            if numeric is not None:
                material_groups[f'{horizon}:{group}'][name].append((numeric, weight))
            if resolved:
                bucket_key = f"{horizon}:{name}:{_material_bucket(value)}"
                material_bucket_results[bucket_key]['total'] += 1
                material_bucket_results[bucket_key]['success'] += int(success)
        if resolved:
            for tag in event.get('explanation_tags') or []:
                tag_key = f'{horizon}:{tag}'
                tag_results[tag_key]['total'] += 1
                tag_results[tag_key]['success'] += int(success)
            sequence = event.get('price_volume_sequence') if isinstance(event.get('price_volume_sequence'), dict) else {}
            sequence_key = f"{horizon}:{str(sequence.get('state') or 'UNKNOWN')}"
            sequence_results[sequence_key]['total'] += 1
            sequence_results[sequence_key]['success'] += int(success)
        cost_state = str(row.get('cost_result_state') or 'MISSING')
        cost_states[f'{horizon}:{cost_state}'] += 1
        after_cost = num(row.get('after_cost_return_pct'))
        if after_cost is not None:
            cost_metrics[horizon].append((after_cost, weight))
    public_metrics = {
        horizon: {name: round(value, 8) if value is not None else None for name, items in group.items() if (value := _weighted_average(items)) is not None}
        for horizon, group in metrics.items()
    }
    public_materials = {
        group: {name: round(value, 8) if value is not None else None for name, items in values.items() if (value := _weighted_average(items)) is not None}
        for group, values in material_groups.items()
    }
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'daily_rollup_final' if final else 'daily_rollup',
        'rollup_state': 'FINAL' if final else 'DAILY_02KST_SNAPSHOT',
        'source_date': date_text,
        'generated_ts': now_ts(),
        'generated_text': now_text(),
        'event_count': len(events),
        'unique_episode_count': len(episode_counts),
        'outcome_count': len(outcomes),
        'input_state_counts': dict(input_states),
        'material_state_counts': dict(material_states),
        'material_source_state_counts': dict(material_source_states),
        'material_missing_reason_counts': dict(material_missing_reasons),
        'explanation_tag_counts': dict(tag_counts),
        'price_volume_sequence_counts': dict(sequence_counts),
        'first_repeat_event_counts': dict(first_repeat_counts),
        'outcome_counts': dict(outcome_counts),
        'episode_weighted_metrics': public_metrics,
        'episode_weighted_material_means': public_materials,
        'material_bucket_target_first_rates': _rate_rows(material_bucket_results),
        'tag_target_first_rates': _rate_rows(tag_results),
        'sequence_target_first_rates': _rate_rows(sequence_results),
        'cost_result_state_counts': dict(cost_states),
        'episode_weighted_after_cost_return_pct': {h: round(v, 8) for h, items in cost_metrics.items() if (v := _weighted_average(items)) is not None},
        'directional_scoring': _directional_score_summary(outcomes),
        'probability_calibration_state': 'LIVE' if any(row.get('prediction_probability_pct') is not None for row in outcomes) else 'WAIT_NEW_PREDICTIONS',
        'material_names': list(MATERIAL_NAMES),
        'weights_applied_to_prediction': False,
        'thresholds_applied_to_prediction': False,
        'prediction_used_as_gate': True,
        'raw_retention_days': 5,
        'raw_retention_is_waiting_period': False,
        'owner': 'review_worker',
        'auto_buy': False,
    }


def append_due_daily_rollup(nowv: float) -> Dict[str, Any]:
    local = time.localtime(nowv)
    if local.tm_hour < 2:
        return {'state':'WAIT_02KST','created':0}
    previous_day_ts = nowv - 24 * 3600.0
    date_text = day_key(previous_day_ts)
    path = raw_path(date_text)
    if date_text in _ROLLED_DATES:
        return {'state':'ALREADY_DONE','source_date':date_text,'created':0}
    if not path.exists():
        return {'state':'SOURCE_NOT_READY','source_date':date_text,'created':0}
    append_jsonl(ROLLUP_LEDGER, build_rollup(date_text, list(read_jsonl(path)), final=False))
    _ROLLED_DATES.add(date_text)
    return {'state':'DONE','source_date':date_text,'created':1}

def _terminal_missing_outcome(event: Dict[str, Any], horizon: str, horizon_sec: float, nowv: float) -> Dict[str, Any]:
    baseline = event.get('baseline_decision') if isinstance(event.get('baseline_decision'), dict) else {}
    return {
        'schema': 'rise_prediction_ledger_record',
        'record_type': 'outcome',
        'event_key': event.get('event_key'),
        'event_ts': event.get('event_ts'),
        'ticker': event.get('ticker'),
        'episode_id': event.get('episode_id'),
        'horizon': horizon,
        'horizon_sec': horizon_sec,
        'outcome_state': 'FAILED_SOURCE_MISSING',
        'missing_reason': 'CANDLE_PATH_NOT_COMPLETED_BEFORE_RAW_RETENTION',
        'baseline_passed': bool(baseline.get('entry_eligible')),
        'baseline_decision_basis': 'RISE_PREDICTION_PRIMARY_THEN_STRUCTURE',
        'target_first': False,
        'invalid_first': False,
        'actual_rise_success': None,
        'result_group': 'SOURCE_MISSING',
        'completed_ts': nowv,
        'completed_text': now_text(nowv),
        'owner': 'review_worker',
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'auto_buy': False,
    }


def rotate_ledgers(nowv: float) -> Dict[str, int]:
    rolled = deleted = terminal_missing = 0
    for path in sorted(LEDGER_DIR.glob('20??-??-??.jsonl')):
        try:
            date_start = time.mktime(time.strptime(path.stem, '%Y-%m-%d'))
        except Exception:
            continue
        # Delete only after the entire local date is older than 120 hours.
        if nowv - (date_start + 24 * 3600.0) <= RAW_RETENTION_SEC:
            continue
        date_text = path.stem
        records = _normalize_review_identities(read_jsonl(path))
        events = {_review_event_identity(row): row for row in records if row.get('record_type') == 'event' and row.get('event_key') and _review_event_identity(row)}
        terminal_keys = {
            (str(row.get('review_event_key') or ''), str(row.get('horizon')))
            for row in records
            if row.get('record_type') == 'outcome' and str(row.get('outcome_state') or '') in {'READY', 'FAILED_SOURCE_MISSING'}
        }
        # A missing source remains retryable for the full raw-retention window.
        # Only at final rotation is it sealed as a source failure for the rollup.
        for key, event in events.items():
            for horizon, sec in HORIZONS:
                if (key, horizon) in terminal_keys:
                    continue
                record = _terminal_missing_outcome(event, horizon, sec, nowv)
                record['review_event_key'] = key
                records.append(record)
                terminal_keys.add((key, horizon))
                terminal_missing += 1
        if date_text not in _FINALIZED_DATES:
            append_jsonl(ROLLUP_LEDGER, build_rollup(date_text, records, final=True))
            _FINALIZED_DATES.add(date_text)
            rolled += 1
        path.unlink(missing_ok=True)
        deleted += 1
        for key, event in list(_EVENTS.items()):
            event_ts = num(event.get('event_ts'))
            if event_ts is not None and day_key(event_ts) == date_text:
                _EVENTS.pop(key, None)
                _LEGACY_EVENT_KEYS.discard(str(event.get('event_key') or ''))
                for horizon, _ in HORIZONS:
                    outcome_key = (key, horizon)
                    _OUTCOMES.discard(outcome_key)
                    _OUTCOME_ROWS.pop(outcome_key, None)
    # Rollups are derived summaries; rewrite only this one derived file for retention.
    if ROLLUP_LEDGER.exists():
        keep = []
        cutoff = nowv - ROLLUP_RETENTION_SEC
        for row in read_jsonl(ROLLUP_LEDGER):
            generated = num(row.get('generated_ts'), nowv)
            if generated is not None and generated >= cutoff:
                keep.append(row)
        tmp = ROLLUP_LEDGER.with_name(f'.{ROLLUP_LEDGER.name}.{os.getpid()}.{time.time_ns()}.tmp')
        with tmp.open('w', encoding='utf-8') as handle:
            for row in keep:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')
            handle.flush(); os.fsync(handle.fileno())
        os.replace(tmp, ROLLUP_LEDGER)
    return {'rolled': rolled, 'raw_files_deleted': deleted, 'terminal_source_missing': terminal_missing}


def cleanup_old_rise_derived(allow: bool) -> List[str]:
    # Information-contract completion must be runtime-proven before any old
    # rise-prediction derived artifact is removed. Core trade ledgers are never touched.
    return []


def run_daily_maintenance(nowv: float) -> Dict[str, Any]:
    global _LAST_MAINTENANCE_DAY
    local_day = day_key(nowv)
    if time.localtime(nowv).tm_hour < 2:
        return {'state':'WAIT_02KST','daily_rollup':{'state':'WAIT_02KST','created':0},'rotation':{'rolled':0,'raw_files_deleted':0,'terminal_source_missing':0}}
    if _LAST_MAINTENANCE_DAY == local_day:
        return {'state':'ALREADY_DONE_TODAY','daily_rollup':{'state':'ALREADY_DONE_TODAY','created':0},'rotation':{'rolled':0,'raw_files_deleted':0,'terminal_source_missing':0}}
    daily = append_due_daily_rollup(nowv)
    rotation = rotate_ledgers(nowv)
    _LAST_MAINTENANCE_DAY = local_day
    return {'state':'DONE','daily_rollup':daily,'rotation':rotation}


def seed_change_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_single_ledger.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-CLEAN-BASELINE',
        'issue_id': 'OLD-RISE-PREDICTION-LATE-AND-WRONG',
        'version': 'v2364',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'The active rise prediction mixed old weighted layers and often recognized already-risen or re-rising coins late. Its results were split across multiple shadow and outcome views.',
        'fix': 'Remove the old rise-prediction active gate; collect only the agreed 13 materials; write one event/outcome ledger with episode dedupe, missed-rise tracking and five-day raw rotation.',
        'not_touched': ['dynamic trigger/invalid/target', 'Paper execution cost checks', 'OPEN/CLOSED/trade/decision exact ledgers', 'exit contract', 'Guard upgrade flow', 'auto-buy OFF'],
        'remaining': 'Server runtime proof of live probabilities, immediate four-way scoring, and five-day observation rotation. Candidate gate remains OFF.',
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'OLD-RISE-PREDICTION-LATE-AND-WRONG',
        'status': 'CHECK',
        'title': '기존 상승예측 폐기·최근 5일 관찰자료 순환',
        'detail': '최근 5일 관찰자료를 유지하면서 상승확률과 정오를 즉시 계산한다. 5일은 대기기간이 아니라 관찰자료 보존기간이며 Gate와 자동감점은 OFF다.',
        'version': 'v2364',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')



def seed_information_contract_change_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_information_contract_v2373.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-INFORMATION-CONTRACT-COMPLETE',
        'issue_id': 'RISE-PREDICTION-MISSING-MATERIAL-CONTEXT',
        'version': 'v2373',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'The clean 13-material baseline existed, but source freshness, missing reasons, price-volume order, overlapping phase tags, signal position, exact cost linkage and daily comparison fields were incomplete.',
        'fix': 'Complete the existing Strategy-to-Review canonical information contract without changing candidate, structure, entry, exit, weight, threshold or gate behavior.',
        'not_touched': ['candidate ranking', 'dynamic trigger/invalid/target/RR', 'Paper entry/exit and cost contract', 'OPEN/CLOSED/trade/decision/exact ledgers', 'auto-buy OFF'],
        'remaining': 'Server runtime proof of the complete information contract and live prediction scoring; five days is retention only.',
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'RISE-PREDICTION-MISSING-MATERIAL-CONTEXT',
        'status': 'CHECK',
        'title': '상승예측 재료·태그·결과 정보계약 완성',
        'detail': '13개 재료의 실제 상태와 누락 이유, 시간 순서, 중복 태그, 초입 위치, Paper exact 비용 결과와 02시 일별 비교를 canonical 장부에 연결한다.',
        'version': 'v2373',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')


def _prediction_contract_id(event: Any) -> str:
    if not isinstance(event,dict):
        return PREVIOUS_PREDICTION_CONTRACT_ID
    explicit=str(event.get('prediction_contract_id') or '').strip().upper()
    if explicit==CURRENT_PREDICTION_CONTRACT_ID:
        sealed_formula_id,sealed_formula_state,_=_sealed_formula_identity(event)
        return CURRENT_PREDICTION_CONTRACT_ID if sealed_formula_state=='PASS' and sealed_formula_id==CURRENT_TIMEFRAME_ROLE_FORMULA_ID else PREVIOUS_PREDICTION_CONTRACT_ID
    if explicit:
        return explicit
    names=tuple(str(name) for name in (event.get('material_names') or []))
    if names==MATERIAL_NAMES and event.get('prediction_first') is True and event.get('target_path_used_by_primary_prediction') is not True:
        return BASELINE_PREDICTION_CONTRACT_ID
    if 'target_path_consumed_ratio' in names:
        return 'PRE_STRUCTURE_13_TARGET_PATH'
    return PREVIOUS_PREDICTION_CONTRACT_ID


def _event_contract_generation(event: Dict[str, Any]) -> str:
    explicit = str(event.get('contract_generation') or '').strip().upper()
    if explicit:
        return explicit
    required = ('signal_position', 'price_volume_sequence', 'explanation_tag_evidence', 'execution_cost_observation')
    if all(key in event for key in required):
        return 'INFORMATION_CONTRACT_COMPLETE'
    return 'LEGACY_PRE_CONTRACT'


def _current_snapshot_event_keys(snapshot: Dict[str, Any]) -> List[str]:
    keys = []
    for row in _candidate_rows(snapshot):
        payload = _rise_input(row)
        key = str(payload.get('event_key') or '').strip()
        if key:
            keys.append(key)
    return sorted(set(keys))


def _event_set_hash(keys: Iterable[str]) -> Optional[str]:
    values = sorted(set(str(key) for key in keys if str(key)))
    return hashlib.sha256('\n'.join(values).encode('utf-8')).hexdigest() if values else None


def _nested_material_state_counts(events: Iterable[Dict[str, Any]]) -> Dict[str, Dict[str, int]]:
    nested: Dict[str, Counter] = {name: Counter() for name in MATERIAL_NAMES}
    for event in events:
        for name in MATERIAL_NAMES:
            item = (event.get('materials') or {}).get(name) if isinstance(event.get('materials'), dict) else None
            if not isinstance(item, dict):
                nested[name]['MISSING'] += 1
                continue
            state = str(item.get('state') or item.get('value_state') or 'MISSING').upper()
            nested[name][state] += 1
    return {name: dict(values) for name, values in nested.items()}


def _nested_material_missing_reasons(events: Iterable[Dict[str, Any]]) -> Dict[str, Dict[str, int]]:
    nested: Dict[str, Counter] = {name: Counter() for name in MATERIAL_NAMES}
    for event in events:
        materials = event.get('materials') if isinstance(event.get('materials'), dict) else {}
        for name in MATERIAL_NAMES:
            item = materials.get(name) if isinstance(materials.get(name), dict) else {}
            reason = str(item.get('missing_reason') or '').strip()
            if reason:
                nested[name][reason] += 1
    return {name: dict(values) for name, values in nested.items() if values}



def _v2398_fair_compare_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'review_full_event_fair_compare_v2398.seeded'
    if marker.exists(): return
    ts=now_ts(); txt=now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'REVIEW-FULL-EVENT-FAIR-COMPARE','issue_id':'STRICT-CONTRACT-SUBSET-MISREAD-AS-RECALL-2398','version':'v2398','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Target-first recall was shown from the sealed-structure subset, which excludes most prior HOLD/DOWN events and made baseline recall appear 100%. Current accuracy focus also read the wrong contract comparison.','fix':'Keep strict contract precision as a subset metric, calculate recall only on all-event after-cost finish and path-opportunity layers, preserve HOLD separately, and connect accuracy/material analysis to the current contract.','not_touched':['Shadow fixed answers','historical ledgers','Strategy trigger/invalid/target/RR','Paper','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(txt,encoding='utf-8')
    except Exception as exc: append_error('v2398_fair_compare_ledger',exc)
try: _v2398_fair_compare_ledger_once()
except Exception: pass


def _v2399_formula_scoped_event_identity_ledger_once() -> None:
    marker = BASE_DIR / 'runtime' / 'review_formula_scoped_event_identity_v2399.seeded'
    if marker.exists():
        return
    ts = now_ts(); txt = now_text(ts)
    try:
        append_jsonl(CHANGE_LEDGER, {
            'schema':'change_verify_ledger','change_id':'REVIEW-FORMULA-SCOPED-EVENT-IDENTITY',
            'issue_id':'SAME-BAR-FORMULA-EVENT-COLLISION-2399','version':'v2399',
            'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,
            'cause':'Review deduplicated complete events by external ticker+completed-30m key only, so a new formula applied inside the same bar was discarded and old outcomes could close the new formula result slot.',
            'fix':'Keep the Strategy external key unchanged, but index Review events and outcomes by external key + prediction contract + formula id. Require the current formula when proving the current snapshot PASS.',
            'not_touched':['Strategy formula','Main','Paper','Candle','Guard','trigger/invalid/target/RR','historical ledger rows','auto-buy OFF'],
            'auto_buy':False,
        })
        append_jsonl(ISSUE_LEDGER, {
            'schema':'issue_ledger_event','issue_id':'SAME-BAR-FORMULA-EVENT-COLLISION-2399','status':'LOCAL_PASS_SERVER_CHECK',
            'created_ts':ts,'created_at':txt,'owner':'review_worker','version':'v2399',
            'detail':'같은 완료봉에서 공식이 바뀌어도 Review 사건·결과가 충돌하지 않도록 공식 포함 내부키로 분리. 서버 Runtime PASS 대기.',
            'auto_buy':False,
        })
        marker.parent.mkdir(parents=True, exist_ok=True)
        marker.write_text(txt, encoding='utf-8')
    except Exception as exc:
        append_error('v2399_formula_scoped_event_identity_ledger', exc)

try:
    _v2399_formula_scoped_event_identity_ledger_once()
except Exception:
    pass


def _v2400_historical_shadow_diagnosis_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'review_historical_shadow_v2_diagnosis_v2400.seeded'
    if marker.exists(): return
    try:
        ts=time.time(); txt=now_text(ts)
        append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'REVIEW-HISTORICAL-SHADOW-V2-DIAGNOSIS','issue_id':'CURRENT-V2-CANNOT-BE-ANALYZED-UNTIL-NEW-OUTCOMES-MATURE','version':'v2400','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':txt,'writer':VERSION,'cause':'Current-contract material diagnosis waited for newly matured V2 outcomes even though old event-time inputs and fixed Shadow outcomes already existed.','fix':'Replay current V2 on all deduplicated prior event-time official h1/h4/d1 inputs and compare wrong UP, HOLD-missed rise and DOWN-missed rise groups against the fixed Shadow cost-clearing opportunity layer.','not_touched':['Strategy formula','weights','thresholds','candidate gate','trigger/invalid/target/RR','Paper','Candle','Guard','historical ledger rows','auto-buy OFF'],'auto_buy':False})
        marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(txt+'\n')
    except Exception as exc: append_error('v2400_historical_shadow_diagnosis_ledger',exc)
try: _v2400_historical_shadow_diagnosis_ledger_once()
except Exception as _v2400_exc: append_error('v2400_historical_shadow_diagnosis_seed',_v2400_exc)

def _v2406_sealed_replay_broad_case_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'review_sealed_replay_broad_case.seeded'
    if marker.exists(): return
    ts=time.time(); marker.parent.mkdir(parents=True,exist_ok=True)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'REVIEW-SEALED-REPLAY-BROAD-RECOVERY-CASES','issue_id':'REVIEW-RECOMPUTED-HISTORICAL-INPUT-DIVERGED-FROM-STRATEGY-SEAL','version':'v2406','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,'cause':'Review rebuilt historical role inputs from retained candle files, so swing/EMA values could differ from the exact Strategy-sealed event input and produce false UP-to-HOLD/UP-to-DOWN transitions.','fix':'Replay the active Strategy Core only on the Strategy-sealed historical role input/evaluation. Separately analyze every observed atomic, pair and triple recovery case on current outcomes without changing Strategy, weights, thresholds or candidate gates.','not_touched':['Strategy formula','candidate gate','trigger/invalid/target/RR','Paper entry/exit','historical event/outcome rows','auto-buy OFF'],'historical_ledgers_rewritten':False,'candidate_deleted':False,'auto_buy':False})
    marker.write_text(now_text(ts),encoding='utf-8')
try: _v2406_sealed_replay_broad_case_ledger_once()
except Exception as _v2406_exc: append_error('v2406_sealed_replay_broad_case_seed',_v2406_exc)

def _v2412_exact_eventset_formula_cohort_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'review_exact_eventset_formula_cohort_v2412.seeded'
    if marker.exists(): return
    ts=time.time(); marker.parent.mkdir(parents=True,exist_ok=True)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'REVIEW-EXACT-LATEST-EVENTSET-FORMULA-COHORT-PATH-COMPARE','issue_id':'FALSE-PASS-AND-MIXED-FORMULA-COMMON-CAUSE','version':'v2412','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,'cause':'Main could mark Review PASS while Review still represented a previous Strategy event-set; directional material comparison also pooled different sealed formulas and labelled every two-sided difference as a common condition without showing the decision path.','fix':'Seal Review source cycle/commit/declared event-set identity, require declared/computed/consumed exact match, separate comparison by sealed formula, classify sign inversion versus ambiguity, and expose prediction-path groups.','not_touched':['Strategy formula','weights','thresholds','candidate gate','trigger/invalid/target/RR','Paper','Candle','Guard','historical ledgers','auto-buy OFF'],'historical_ledgers_rewritten':False,'auto_buy':False})
    marker.write_text(now_text(ts),encoding='utf-8')
try: _v2412_exact_eventset_formula_cohort_ledger_once()
except Exception as _v2412_exc: append_error('v2412_exact_eventset_formula_cohort_seed',_v2412_exc)


def _v2413_path_metadata_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'review_path_metadata_exclusion_v2413.seeded'
    if marker.exists(): return
    ts=time.time(); marker.parent.mkdir(parents=True,exist_ok=True)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'REVIEW-LEGACY-PATH-METADATA-EXCLUSION','issue_id':'PREDICTION-OUTPUT-MISSING-WAS-LEGACY-PATH-METADATA','version':'v2413','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,'cause':'Historical rows without prediction_path metadata were displayed as PREDICTION_OUTPUT_MISSING and could be mistaken for a current Strategy decision failure.','fix':'Keep those rows in the six-way accuracy/material groups but exclude the missing legacy path label from decision-path TOP rankings and report it separately as metadata only.','not_touched':['historical event decisions','historical outcomes','Strategy formula calculation','Paper','Candle','Guard','auto-buy OFF'],'historical_ledgers_rewritten':False,'auto_buy':False})
    marker.write_text(now_text(ts),encoding='utf-8')
try: _v2413_path_metadata_ledger_once()
except Exception as _v2413_exc: append_error('v2413_path_metadata_seed',_v2413_exc)

def _v2414_formula_transport_ledger_once() -> None:
    marker=BASE_DIR/'runtime'/'review_formula_transport_exact_v2414.seeded'
    if marker.exists(): return
    ts=time.time(); marker.parent.mkdir(parents=True,exist_ok=True)
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'REVIEW-SEALED-FORMULA-TRANSPORT-EXACT','issue_id':'CURRENT-V6-EVENTSET-DROPPED-BY-SINGLE-NESTED-FIELD','version':'v2414','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,'cause':'Review required only timeframe_role_input.formula_id. A compact current row with the same sealed formula in top-level/evaluation/model fields could be rejected as previous and current event-set became 0/468.','fix':'Read all existing sealed formula copies as one transport contract: accept the current formula when at least one copy exists and every present copy agrees; reject and report genuine conflicts. No formula calculation or fallback is added.','not_touched':['historical decisions','historical outcomes','Strategy material calculation','Paper','Candle','Guard','auto-buy OFF'],'historical_ledgers_rewritten':False,'auto_buy':False})
    marker.write_text(now_text(ts),encoding='utf-8')
try: _v2414_formula_transport_ledger_once()
except Exception as _v2414_exc: append_error('v2414_formula_transport_seed',_v2414_exc)


def run_once() -> Dict[str, Any]:
    started = time.monotonic()
    nowv = now_ts()
    _refresh_canonical_strategy_contract()
    load_state_once()
    snapshot = load_json(SNAPSHOT, {}) or {}
    snapshot = snapshot if isinstance(snapshot, dict) else {}
    created, duplicates = append_new_events(snapshot)
    # Publish only the completed Review cycle. The original Guard does not need
    # a partial rise-contract status, and Main must never read a half-built
    # canonical as if material/outcome counts were zero.
    index, candle_count = candle_index()
    paper_index = paper_exact_index()
    outcome_counts = append_due_outcomes(nowv, index, paper_index)
    maintenance = run_daily_maintenance(nowv)
    rotation = maintenance.get('rotation') if isinstance(maintenance.get('rotation'), dict) else {'rolled':0,'raw_files_deleted':0,'terminal_source_missing':0}
    removed = cleanup_old_rise_derived(False)
    baseline_material_model = build_live_prediction_model(nowv)
    live_model = {
        'schema':'official_timeframe_role_model_identity','state':'LIVE',
        'owner':'strategy_v2_core.py','core_version':str(getattr(_ACTIVE_STRATEGY_CORE,'VERSION','') or ''),'core_build':str(getattr(_ACTIVE_STRATEGY_CORE,'BUILD_LABEL','') or ''),'model_id':CURRENT_TIMEFRAME_ROLE_FORMULA_ID,
        'generated_ts':nowv,'generated_text':now_text(nowv),'retention_days':5,
        'decision_axes':['1h_timing','4h_structure','24h_context'],
        'elapsed_horizons_are_result_checks_only':True,
        'synthetic_3h_6h_candles_used':False,'weights_applied':False,'thresholds_applied':False,'auto_buy':False,
    }
    active_model_id=str(live_model.get('model_id') or '')
    current_prediction_contract_scoring=_directional_score_summary(
        _OUTCOME_ROWS.values(),
        lambda event: _prediction_contract_id(event)==CURRENT_PREDICTION_CONTRACT_ID,
    )
    active_model_directional_scoring=_directional_score_summary(
        _OUTCOME_ROWS.values(),
        lambda event: isinstance(event,dict)
        and _prediction_contract_id(event)==CURRENT_PREDICTION_CONTRACT_ID
        and str(event.get('prediction_model_id') or '')==active_model_id,
    )
    # Existing readers keep the same field name, but it now means current
    # PRE_STRUCTURE_12 results only.
    directional_scoring=current_prediction_contract_scoring
    directional_material_comparison=build_directional_material_comparison()
    shadow_answer_sheet=build_shadow_answer_sheet()
    canonical_prediction_seal_audit=build_canonical_prediction_seal_audit()
    sealed_outcome_path_validation=build_sealed_outcome_path_validation()
    raw_files = sorted(LEDGER_DIR.glob('20??-??-??.jsonl'))
    current_prediction_contract_events = [event for event in _EVENTS.values() if _prediction_contract_id(event) == CURRENT_PREDICTION_CONTRACT_ID]
    current_event_keys={str(event.get('event_key') or '') for event in current_prediction_contract_events if str(event.get('event_key') or '')}
    current_review_event_keys={_review_event_identity(event) for event in current_prediction_contract_events if _review_event_identity(event)}
    outcome_total = Counter(horizon for review_event_key, horizon in _OUTCOMES if str(review_event_key) in current_review_event_keys)
    result_groups = Counter()
    touch_orders = Counter()
    outcome_states = Counter()
    for record in _OUTCOME_ROWS.values():
        if str(record.get('review_event_key') or '') not in current_review_event_keys:
            continue
        horizon = str(record.get('horizon') or 'unknown')
        outcome_states[f"{horizon}:{str(record.get('outcome_state') or 'MISSING')}"] += 1
        if record.get('result_group'):
            result_groups[f"{horizon}:{str(record.get('result_group'))}"] += 1
        if record.get('touch_order'):
            touch_orders[f"{horizon}:{str(record.get('touch_order'))}"] += 1
    input_states = Counter(str(event.get('input_state') or 'MISSING') for event in current_prediction_contract_events)
    tag_counts = Counter(tag for event in current_prediction_contract_events for tag in (event.get('explanation_tags') or []))
    sequence_counts = Counter(str((event.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN') for event in current_prediction_contract_events)
    material_source_states = Counter()
    material_value_states = Counter()
    material_missing_reasons = Counter()
    for event in current_prediction_contract_events:
        for name, item in (event.get('materials') or {}).items():
            if not isinstance(item, dict): continue
            material_source_states[f"{name}:{str(item.get('source_state') or 'MISSING')}"] += 1
            material_value_states[f"{name}:{str(item.get('value_state') or 'MISSING')}"] += 1
            if item.get('missing_reason'):
                material_missing_reasons[f"{name}:{str(item.get('missing_reason'))}"] += 1
    cost_states = Counter(f"{str(row.get('horizon') or 'unknown')}:{str(row.get('cost_result_state') or 'MISSING')}" for row in _OUTCOME_ROWS.values() if str(row.get('review_event_key') or '') in current_review_event_keys)
    snapshot_summary=snapshot.get('summary') if isinstance(snapshot.get('summary'),dict) else {}
    snapshot_rise=snapshot_summary.get('rise_prediction') if isinstance(snapshot_summary.get('rise_prediction'),dict) else {}
    declared_snapshot_event_set_hash=str(snapshot_rise.get('event_set_hash') or '')
    declared_snapshot_event_set_count=int(snapshot_rise.get('event_set_count') or snapshot_rise.get('event_key_count') or 0)
    current_snapshot_keys = _current_snapshot_event_keys(snapshot)
    current_snapshot_key_set = set(current_snapshot_keys)
    computed_snapshot_event_set_hash=_event_set_hash(current_snapshot_keys)
    declared_snapshot_match=bool(declared_snapshot_event_set_hash and computed_snapshot_event_set_hash and declared_snapshot_event_set_hash==computed_snapshot_event_set_hash and declared_snapshot_event_set_count==len(current_snapshot_keys))
    current_snapshot_events = [
        event for event in _EVENTS.values()
        if str(event.get('event_key') or '') in current_snapshot_key_set
        and _prediction_contract_id(event) == CURRENT_PREDICTION_CONTRACT_ID
    ]
    sealed_formula_states = Counter(str(event.get('sealed_formula_state') or 'MISSING') for event in current_snapshot_events)
    information_contract_events = [event for event in _EVENTS.values() if _event_contract_generation(event) == 'INFORMATION_CONTRACT_COMPLETE']
    legacy_events = [event for event in _EVENTS.values() if _event_contract_generation(event) != 'INFORMATION_CONTRACT_COMPLETE']
    current_snapshot_contract_events = [event for event in current_snapshot_events if _event_contract_generation(event) == 'INFORMATION_CONTRACT_COMPLETE']
    # Review may only prove events that it actually consumed from the append-once
    # ledger. Hashing the Strategy snapshot keys directly would create a false
    # PASS even when current completed-bar events were still absent or legacy.
    consumed_contract_keys = sorted({
        str(event.get('event_key') or '')
        for event in current_snapshot_contract_events
        if str(event.get('event_key') or '')
    })
    current_snapshot_contract_pass = bool(
        current_snapshot_keys
        and declared_snapshot_match
        and len(consumed_contract_keys) == len(current_snapshot_keys)
        and set(consumed_contract_keys) == current_snapshot_key_set
    )
    current_tag_counts = Counter(tag for event in current_prediction_contract_events for tag in (event.get('explanation_tags') or []))
    current_sequence_counts = Counter(str((event.get('price_volume_sequence') or {}).get('state') or 'UNKNOWN') for event in current_prediction_contract_events)
    prediction_selection_counts = Counter(
        str(event.get('prediction_selection') or event.get('primary_prediction_decision') or
            ((event.get('rise_prediction_input') or {}).get('primary_selection') or {}).get('decision') or 'UNKNOWN').upper()
        for event in current_prediction_contract_events
    )
    current_material_missing_reasons = Counter()
    for event in current_prediction_contract_events:
        for name, item in (event.get('materials') or {}).items():
            if isinstance(item, dict) and item.get('missing_reason'):
                current_material_missing_reasons[f"{name}:{str(item.get('missing_reason'))}"] += 1
    actual_cost_outcome_links = sum(1 for row in _OUTCOME_ROWS.values() if str(row.get('review_event_key') or '') in current_review_event_keys and str(row.get('cost_result_state') or '').startswith('READY_ACTUAL_'))
    actual_cost_event_keys = {
        str(row.get('event_key') or '')
        for row in _OUTCOME_ROWS.values()
        if str(row.get('review_event_key') or '') in current_review_event_keys and str(row.get('cost_result_state') or '').startswith('READY_ACTUAL_') and str(row.get('event_key') or '')
    }
    actual_cost_event_links = len(actual_cost_event_keys)
    pending = Counter()
    next_scoring_due_ts=None
    overdue_scoring_count=0
    oldest_overdue_scoring_due_ts=None
    for key, event in _EVENTS.items():
        if _prediction_contract_id(event)!=CURRENT_PREDICTION_CONTRACT_ID:
            continue
        event_ts = num(event.get('event_ts'))
        if event_ts is None:
            continue
        for horizon, sec in HORIZONS:
            if (key, horizon) not in _OUTCOMES:
                pending[horizon] += 1
                due=float(event_ts)+float(sec)
                if due <= nowv:
                    overdue_scoring_count += 1
                    if oldest_overdue_scoring_due_ts is None or due < oldest_overdue_scoring_due_ts:
                        oldest_overdue_scoring_due_ts=due
                elif next_scoring_due_ts is None or due<next_scoring_due_ts:
                    next_scoring_due_ts=due
    elapsed = max(0.0, time.monotonic() - started)
    canonical = {
        'schema': 'rise_prediction_canonical_status',
        'state': 'ACTIVE' if _EVENTS else 'WAITING',
        'owner': 'review_worker',
        'ledger_root': str(LEDGER_DIR),
        'collection_start_ts': _COLLECTION_START_TS,
        'collection_start_text': now_text(_COLLECTION_START_TS) if _COLLECTION_START_TS else None,
        'event_count_in_retention': len(current_prediction_contract_events),
        'new_events': created,
        'duplicate_events_prevented': duplicates,
        'unique_episode_count': len({str(event.get('episode_id') or event.get('event_key')) for event in _EVENTS.values()}),
        'input_state_counts': dict(input_states),
        'material_source_state_counts': dict(material_source_states),
        'material_value_state_counts': dict(material_value_states),
        'material_missing_reason_counts': dict(material_missing_reasons),
        'explanation_tag_counts': dict(tag_counts),
        'price_volume_sequence_counts': dict(sequence_counts),
        'current_contract_explanation_tag_counts': dict(current_tag_counts),
        'current_contract_price_volume_sequence_counts': dict(current_sequence_counts),
        'prediction_primary_selection_counts': dict(prediction_selection_counts),
        'prediction_first': True,
        'full_universe_feedback_active': True,
        'current_contract_material_missing_reason_counts': dict(current_material_missing_reasons),
        'contract_generation_counts': {'CURRENT_1H_4H_24H': len(current_prediction_contract_events)},
        'prediction_contract_counts': {
            CURRENT_PREDICTION_CONTRACT_ID: len(current_prediction_contract_events),
        },
        'current_prediction_contract_id': CURRENT_PREDICTION_CONTRACT_ID,
        'current_prediction_contract_event_count': len(current_prediction_contract_events),
        'source_strategy_cycle_id': snapshot.get('cycle_id'),
        'source_strategy_candidate_commit_id': snapshot.get('candidate_commit_id'),
        'source_strategy_declared_event_set_hash': declared_snapshot_event_set_hash or None,
        'source_strategy_declared_event_set_count': declared_snapshot_event_set_count,
        'current_snapshot_event_set_hash': computed_snapshot_event_set_hash,
        'current_snapshot_declared_event_set_match': declared_snapshot_match,
        'review_consumed_event_set_hash': _event_set_hash(consumed_contract_keys),
        'review_consumed_event_set_count': len(consumed_contract_keys),
        'current_snapshot_expected_event_count': len(current_snapshot_keys),
        'current_snapshot_contract_complete_count': len(current_snapshot_contract_events),
        'current_snapshot_legacy_event_count': max(0, len(current_snapshot_events) - len(current_snapshot_contract_events)),
        'current_snapshot_contract_state': 'PASS' if current_snapshot_contract_pass else ('CURRENT_CONTRACT_INCOMPLETE' if current_snapshot_keys else 'WAITING'),
        'current_snapshot_formula_match_required': True,
        'current_snapshot_formula_id': CURRENT_TIMEFRAME_ROLE_FORMULA_ID,
        'strategy_contract_reload_active': True,
        'strategy_contract_formula_id_loaded': CURRENT_TIMEFRAME_ROLE_FORMULA_ID,
        'current_snapshot_sealed_formula_state_counts': dict(sealed_formula_states),
        'formula_transport_acceptance':'ANY_SEALED_COPY_EXACT_IF_ALL_PRESENT_AGREE;_CONFLICT_REJECTED',
        'current_contract_material_state_by_name': _nested_material_state_counts(current_prediction_contract_events),
        'current_contract_missing_reasons_by_name': _nested_material_missing_reasons(current_prediction_contract_events),
        'cost_result_state_counts': dict(cost_states),
        'paper_exact_available_count': len(paper_index),
        'paper_exact_actual_event_link_count': actual_cost_event_links,
        'paper_exact_actual_outcome_link_count': actual_cost_outcome_links,
        'paper_exact_actual_link_count': actual_cost_event_links,
        'paper_exact_link_count': actual_cost_event_links,
        'outcome_counts': dict(outcome_total),
        'outcome_state_counts': dict(outcome_states),
        'result_group_counts': dict(result_groups),
        'touch_order_counts': dict(touch_orders),
        'new_outcome_counts': outcome_counts,
        'pending_outcome_counts': dict(pending),
        'next_scoring_due_ts': next_scoring_due_ts,
        'next_scoring_due_text': kst_text(next_scoring_due_ts),
        'overdue_scoring_count': overdue_scoring_count,
        'oldest_overdue_scoring_due_ts': oldest_overdue_scoring_due_ts,
        'oldest_overdue_scoring_due_text': kst_text(oldest_overdue_scoring_due_ts),
        'raw_file_count': len(raw_files),
        'raw_retention_days': 5,
        'rollup_retention_days': 90,
        'rollup_count': len(_ROLLED_DATES),
        'maintenance_02kst': maintenance,
        'rotation': rotation,
        'old_rise_derived_removed': removed,
        'old_rise_derived_cleanup_state': 'PENDING_RUNTIME_PROOF_NO_DELETE',
        'material_names': list(MATERIAL_NAMES),
        'material_count': len(MATERIAL_NAMES),
        'prediction_material_contract':'PRE_STRUCTURE_1H_4H_24H',
        'decision_axes':['1h_timing','4h_structure','24h_context'],
        'elapsed_horizons_are_result_checks_only':True,
        'post_structure_target_path_active':True,
        'next_scoring_due_timezone':'KST',
        'event_key_contract': 'Strategy external key = ticker + completed_30m_bar_close_ts; Review identity = external key + prediction contract + formula id',
        'review_formula_scoped_event_identity': True,
        'episode_id_contract': 'ticker + latest_confirmed_m30_swing_low_ts',
        'information_contract_complete': True,
        'live_prediction_model': live_model,
        'baseline_material_model': baseline_material_model,
        'live_prediction_model_id': live_model.get('model_id'),
        'probability_outputs_state': live_model.get('state'),
        'directional_scoring': directional_scoring,
        'current_prediction_contract_directional_scoring': current_prediction_contract_scoring,
        'active_model_directional_scoring': active_model_directional_scoring,
        'directional_material_comparison': directional_material_comparison,
        'shadow_answer_sheet':shadow_answer_sheet,
        'canonical_prediction_seal_audit':canonical_prediction_seal_audit,
        'sealed_outcome_path_validation':sealed_outcome_path_validation,
        'timeframe_role_shadow':{'state':'RETIRED_WRONG_SEMANTICS','reason':'Shadow is the fixed actual-result answer sheet; Strategy replay is published separately'},
        'baseline_prediction_contract_id':BASELINE_PREDICTION_CONTRACT_ID,
        'baseline_prediction_contract_event_count':sum(1 for event in _EVENTS.values() if _prediction_contract_id(event)==BASELINE_PREDICTION_CONTRACT_ID),
        'active_model_scoring_model_id': active_model_id or None,
        'current_contract_only_active': True,
        'historical_source_ledgers_preserved_but_not_read_by_active_review': True,
        'historical_source_ledgers_read_for_analysis_only': False,
        'historical_replay_active': False,
        'historical_replay_reader_recalculation_count': 0,
        'review_formula_call_count': 0,
        'live_strategy_inputs_recomputed_by_review': False,
        'weights_applied': False,
        'probability_model_applied': True,
        'thresholds_applied': False,
        'prediction_used_as_gate': True,
        'fair_shadow_comparison': True,
        'same_decision_layer': True,
        'hold_counted_as_damage': False,
        'new_shadow_created': False,
        'new_worker_created': False,
        'new_service_created': False,
        'review_recomputed_inputs': False,
        'zero_fill_used': False,
        'missing_outcome_retries_active': True,
        'historical_trade_ledgers_deleted': False,
        'auto_buy': False,
    }
    status = {
        'schema': 'clean_review_worker_status',
        'version': VERSION,
        'build': BUILD_LABEL,
        'state': 'running',
        'pid': os.getpid(),
        'active_owner': VERSION,
        'updated_ts': nowv,
        'updated_text': now_text(nowv),
        'last_completed_ts': nowv,
        'cycle_complete': True,
        'cycle_complete_v2294': True,
        'analysis_ready': True,
        'analysis_ready_v2246': True,
        'cycle_elapsed_sec': round(elapsed, 3),
        'candidate_snapshot_id': snapshot.get('snapshot_id'),
        'candidate_commit_id': snapshot.get('candidate_commit_id'),
        'candidate_row_count': len(_candidate_rows(snapshot)),
        'candidate_event_set_hash': _event_set_hash(current_snapshot_keys),
        'candidate_event_set_count': len(current_snapshot_keys),
        'candle_ticker_count': len(index),
        'candle_row_count': candle_count,
        'rise_prediction_canonical': canonical,
        'review_status': {
            'schema': 'review_status',
            'owner': 'review',
            'version': VERSION,
            'build': BUILD_LABEL,
            'state': canonical['state'],
            'new_shadow_created': False,
            'historical_ledgers_rewritten': False,
            'historical_trade_ledgers_deleted': False,
            'auto_buy': False,
        },
        'writer_count': 1,
        'historical_ledgers_rewritten': False,
        'historical_trade_ledgers_deleted': False,
        'new_shadow_created': False,
        'auto_buy': False,
    }
    atomic_json(STATUS, status)
    return status



def seed_shadow_answer_sheet_fix_once() -> None:
    marker=BASE_DIR/'runtime'/'review_shadow_answer_sheet_v2396.seeded'
    if marker.exists(): return
    ts=now_ts()
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger','change_id':'REVIEW-SHADOW-ANSWER-SHEET-SEPARATION',
        'issue_id':'SHADOW-WRONG-SEMANITCS-STRATEGY-REPLAY-AS-ANSWER','version':'v2396',
        'verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,
        'cause':'v2395 called the current Strategy replay itself Shadow, so the answer side changed whenever the mainline formula changed.',
        'fix':'Shadow now derives only fixed actual elapsed-path answers (cost-clearing MFE, cost-adjusted finish, MAE, giveback and touch order). Active Strategy replay is a separate prediction-side comparison against that fixed answer sheet.',
        'historical_ledgers_rewritten':False,'new_shadow_created':False,'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{
        'schema':'issue_ledger_event','event_type':'ISSUE','issue_id':'SHADOW-WRONG-SEMANITCS-STRATEGY-REPLAY-AS-ANSWER',
        'status':'CHECK','title':'Shadow 정답지와 본선 재실행 혼동','detail':'v2396 로컬 PASS. 서버 Review/Main Runtime에서 고정 정답지와 본선 과거대입 비교가 분리되는지 확인 필요.',
        'version':'v2396','created_ts':ts,'created_at':now_text(ts),'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(now_text(ts),encoding='utf-8')

def seed_fair_shadow_compare_once() -> None:
    marker=BASE_DIR/'runtime'/'review_fair_shadow_compare_v2397.seeded'
    if marker.exists(): return
    ts=now_ts()
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger','change_id':'REVIEW-FAIR-SHADOW-SAME-LAYER-COMPARE','issue_id':'SHADOW-COMPARE-MIXED-ANSWER-AND-HOLD-AS-DAMAGE',
        'version':'v2397','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,
        'cause':'v2396 mixed broad cost-clearing MFE with strict trade success and counted old UP -> new HOLD as damage, inflating damage above 90 percent.',
        'fix':'Keep target-first/invalid-first, after-cost finish and cost-clearing MFE as separate fixed answer layers. Compare old and new PRE_STRUCTURE UP/HOLD/DOWN on the identical event and report HOLD as deferral, not damage.',
        'historical_ledgers_rewritten':False,'strategy_changed':False,'candidate_gate_changed':False,'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{
        'schema':'issue_ledger_event','event_type':'ISSUE','issue_id':'SHADOW-COMPARE-MIXED-ANSWER-AND-HOLD-AS-DAMAGE','status':'CHECK',
        'title':'Shadow 비교 기준 혼합·HOLD 훼손 오계산','detail':'v2397 로컬 PASS. 서버 Review/Main에서 3단계 정답과 동일판정층 전이표 확인 필요.',
        'version':'v2397','created_ts':ts,'created_at':now_text(ts),'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(now_text(ts),encoding='utf-8')


def seed_contract_split_truth_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_contract_split_event_set_v2375.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-CONTRACT-SPLIT-EVENT-SET-TRUTH',
        'issue_id': 'RISE-PREDICTION-LEGACY-CURRENT-AGGREGATE-MIX',
        'version': 'v2375',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'Main and Review mixed legacy pre-contract events with the completed information contract, used exact cycle IDs instead of the completed-bar event set, and displayed available Paper exact rows as if they were actual outcome links.',
        'fix': 'Preserve all old rows, classify generations without rewriting, prove only Review-consumed current event keys, separate available versus actually linked Paper exact results, and publish current-contract-only tag/sequence/material aggregates.',
        'not_touched': ['13-material calculations', 'candidate ranking and count', 'trigger/invalid/target/RR', 'entry/exit/cost contracts', 'OPEN/CLOSED/trade/decision/exact ledgers', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'RISE-PREDICTION-LEGACY-CURRENT-AGGREGATE-MIX',
        'status': 'CHECK',
        'title': '상승예측 구사건·새 정보계약 혼합 표시',
        'detail': '과거 사건은 보존하고 새 완료봉 사건만 정보계약 집계와 event-set 증명에 사용. 서버 Runtime PASS 대기.',
        'version': 'v2375',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')



def seed_link_count_truth_once() -> None:
    marker = BASE_DIR / 'runtime' / 'rise_prediction_actual_link_count_v2376.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'RISE-PREDICTION-ACTUAL-EVENT-OUTCOME-LINK-COUNT',
        'issue_id': 'RISE-PREDICTION-ACTUAL-LINK-COUNT-HORIZON-DUPLICATION',
        'version': 'v2376',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'Actual Paper links were counted per horizon outcome row but displayed as linked events, so one event could be counted up to four times.',
        'fix': 'Keep the outcome-row count and add one unique event-key count. Main displays available exact rows, unique linked events, and linked outcome rows separately.',
        'not_touched': ['Paper exact rows', 'outcome calculation', '13-material inputs', 'candidate/entry/exit rules', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'RISE-PREDICTION-ACTUAL-LINK-COUNT-HORIZON-DUPLICATION',
        'status': 'CHECK',
        'title': 'Paper 실제 연결 수가 horizon 결과행 수와 혼합 표시됨',
        'detail': '고유 사건 연결 수와 결과행 연결 수를 분리해 표시. 서버 Runtime 검증 대기.',
        'version': 'v2376',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')

def seed_review_first_contract_proof_once() -> None:
    marker = BASE_DIR / 'runtime' / 'review_first_contract_proof_v2378.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'REVIEW-FIRST-CONTRACT-PROOF-BEFORE-HEAVY-CYCLE',
        'issue_id': 'REVIEW-BOOTING-ONLY-RUNTIME-PROOF',
        'version': 'v2378',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'Review wrote only BOOTING until candle and outcome work finished, so the unchanged Guard could not see the already-consumed rise contract during deployment.',
        'fix': 'After append-once current events are consumed, publish the existing six canonical contract facts immediately, then continue the same candle and outcome cycle.',
        'not_touched': ['Guard code and service', '13-material formulas', 'candidate/entry/exit rules', 'historical rows', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'REVIEW-BOOTING-ONLY-RUNTIME-PROOF',
        'status': 'CHECK',
        'title': 'Review 첫 계약 증명 전 무거운 cycle로 배포 CHECK',
        'detail': '기존 Guard는 유지하고 Review가 append-once 사건 소비 직후 기존 계약 상태를 먼저 기록한다.',
        'version': 'v2378',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')


def seed_legacy_event_collision_fix_once() -> None:
    marker = BASE_DIR / 'runtime' / 'review_legacy_event_key_collision_fix_v2382.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'REVIEW-LEGACY-CURRENT-EVENT-KEY-COLLISION-FIX',
        'issue_id': 'REVIEW-CURRENT-CONTRACT-DROPPED-AS-LEGACY-DUPLICATE',
        'version': 'v2382',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'A preserved legacy row and the current information-contract row shared the same ticker+completed-30m event key. The active dictionary kept the legacy row and discarded the current row as a duplicate.',
        'fix': 'Preserve both append-only ledger rows, append the current contract when only a legacy row exists, and prefer the current contract row in the active reader and after restart.',
        'not_touched': ['Guard', 'Main', 'Paper', 'Strategy', 'Candle', 'candidate/entry/exit rules', 'historical row contents', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'REVIEW-CURRENT-CONTRACT-DROPPED-AS-LEGACY-DUPLICATE',
        'status': 'CHECK',
        'title': 'Review 새 정보계약이 구사건 중복으로 누락됨',
        'detail': '같은 event_key의 구사건은 보존하고 새 정보계약 행을 append한 뒤 현재 Reader가 새 행을 우선 사용한다. 서버 Runtime PASS 대기.',
        'version': 'v2382',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')



def seed_review_complete_cycle_truth_once() -> None:
    marker = BASE_DIR / 'runtime' / 'review_complete_cycle_status_truth.seeded'
    if marker.exists():
        return
    ts = now_ts()
    append_jsonl(CHANGE_LEDGER, {
        'schema': 'change_verify_ledger',
        'change_id': 'REVIEW-COMPLETE-CYCLE-STATUS-TRUTH',
        'issue_id': 'REVIEW-PARTIAL-CONTRACT-STATUS-HID-FULL-AGGREGATES',
        'version': 'v2383',
        'verify_result': 'LOCAL_PASS_SERVER_CHECK',
        'created_ts': ts,
        'created_at': now_text(ts),
        'writer': VERSION,
        'cause': 'The retired deployment workaround overwrote Review status with a partial contract proof before material, outcome and Paper-exact aggregation completed. Main therefore displayed truthful 466/466 keys together with missing aggregate fields as zero or dash.',
        'fix': 'Keep the legacy/current event collision repair, remove the partial status write, publish only the completed canonical cycle, and make Main compare the exact Strategy snapshot hash consumed by Review instead of the moving latest Strategy snapshot.',
        'not_touched': ['Guard', 'Paper', 'Strategy', 'Candle', 'candidate/entry/exit rules', 'historical ledger rows', 'auto-buy OFF'],
        'auto_buy': False,
    })
    append_jsonl(ISSUE_LEDGER, {
        'schema': 'issue_ledger_event',
        'event_type': 'ISSUE',
        'issue_id': 'REVIEW-PARTIAL-CONTRACT-STATUS-HID-FULL-AGGREGATES',
        'status': 'CHECK',
        'title': 'Review 부분 계약 상태가 완료 집계를 0으로 보이게 함',
        'detail': '부분 상태 writer를 제거하고 완료 cycle만 공개한다. 구사건 충돌 복구와 append-only 원장은 유지하며 서버 Runtime PASS를 확인한다.',
        'version': 'v2383',
        'created_ts': ts,
        'created_at': now_text(ts),
        'auto_buy': False,
    })
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(now_text(ts), encoding='utf-8')


def seed_live_probability_change_once() -> None:
    marker=BASE_DIR/'runtime'/'rise_prediction_live_probability_scoring.seeded'
    if marker.exists(): return
    ts=now_ts()
    append_jsonl(CHANGE_LEDGER,{'schema':'change_verify_ledger','change_id':'RISE-PREDICTION-LIVE-PROBABILITY-AND-SCORING','issue_id':'RISE-PREDICTION-WAS-OBSERVATION-ONLY','version':'v2385','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,
        'cause':'The active information contract recorded 13 materials but forced all probability outputs to None and misread five-day retention as a five-day waiting period. API success and completed-bar freshness were also conflated.',
        'fix':'Use the most recent five-day information-contract outcomes to publish live 3h/6h rise, giveback and late-capture probabilities; seal predictions at event time; score UP_UP, UP_DOWN, DOWN_DOWN and DOWN_UP as each horizon completes. Five days is retention only.',
        'not_touched':['candidate gate/penalty','dynamic trigger/invalid/target/RR','Paper exit contract','historical OPEN/CLOSED/trade/decision/exact ledgers','auto-buy OFF'],'auto_buy':False})
    append_jsonl(ISSUE_LEDGER,{'schema':'issue_ledger_event','event_type':'ISSUE','issue_id':'RISE-PREDICTION-WAS-OBSERVATION-ONLY','status':'CHECK','title':'상승예측 확률 미실행·5일 보존기간 오해','detail':'최근 5일 자료로 즉시 확률을 계산하고 네 방향 정오를 시간축 완료 즉시 채점한다. Gate와 자동감점은 OFF다.','version':'v2385','created_ts':ts,'created_at':now_text(ts),'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(now_text(ts),encoding='utf-8')


def seed_ready_cost_scoring_change_once() -> None:
    marker=BASE_DIR/'runtime'/'rise_prediction_ready_cost_scoring_v2386.seeded'
    if marker.exists(): return
    ts=now_ts()
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger','change_id':'RISE-PREDICTION-READY-COST-SCORING','issue_id':'RISE-PROBABILITY-BASE-CLUSTER-AND-MIXED-SOURCE-STATES',
        'version':'v2386','verify_result':'LOCAL_PASS_SERVER_CHECK','created_ts':ts,'created_at':now_text(ts),'writer':VERSION,
        'cause':'Recent-model learning accepted numeric remnants from non-READY sources and classified rise by raw final return, so all candidates clustered around the positive market base.',
        'fix':'Learn each material only from sealed READY source rows, classify rise by horizon return after sealed available cost, and score the same cost-aligned direction as soon as each horizon completes.',
        'not_touched':['candidate Gate/penalty','trigger/invalid/target/RR','Paper entry/exit','historical core ledgers','auto-buy OFF'],'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(now_text(ts),encoding='utf-8')

def seed_prediction_primary_feedback_once() -> None:
    marker=BASE_DIR/'runtime'/'review_prediction_primary_feedback_v2387.seeded'
    if marker.exists(): return
    ts=now_ts()
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger','change_id':'REVIEW-PREDICTION-PRIMARY-FULL-UNIVERSE-FEEDBACK',
        'issue_id':'REVIEW-LABELED-PREDICTION-AS-NON_GATED_OBSERVATION','version':'v2387','verify_result':'LOCAL_PASS_SERVER_CHECK',
        'created_ts':ts,'created_at':now_text(ts),'writer':VERSION,
        'cause':'Review and Main still described rise prediction as a non-gated observation and trained direction with Paper cost although rise prediction must precede structure and execution cost.',
        'fix':'Train and score raw price rise first, seal prediction-first semantics, retain every universe prediction for excluded-but-risen feedback, and keep Paper after-cost outcome as a separate later-stage result.',
        'not_touched':['historical event/outcome rows','trigger/invalid/target/RR','Paper execution/exit','auto-buy OFF'],'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(now_text(ts),encoding='utf-8')


def seed_prediction_contract_result_split_once() -> None:
    marker=BASE_DIR/'runtime'/'prediction_contract_result_split_v2389.seeded'
    if marker.exists():
        return
    ts=now_ts()
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger_v870','event_type':'CHANGE_VERIFY','version':'v2389','status':'CHECK',
        'title':'현재 PRE_STRUCTURE_12 단일 active 결과',
        'cause':'현재 모델과 정확도 집계에 이전 13재료·구계약 결과가 섞였다.',
        'files_changed':['review_worker_v2.159.py','coinbot_main_v2_13_2234.py'],
        'new_mainline':'PRE_STRUCTURE_12만 active 모델·결과판에서 읽고 이전 계약 Reader·집계·표시는 제거',
        'historical_ledgers_rewritten':False,'historical_trade_ledgers_deleted':False,'auto_buy':False,
        'created_ts':ts,'created_at':now_text(ts),
    })
    append_jsonl(ISSUE_LEDGER,{
        'schema':'coinbot_single_work_ledger_v870','event_type':'ISSUE','issue_id':'RISE-PREDICTION-CONTRACT-MIX-2389',
        'status':'CHECK','title':'현재 상승예측 결과에 이전 계약 혼합',
        'detail':'현재 12재료와 이전 계약을 분리했으며 서버 Runtime 검증 전 CHECK',
        'version':'v2389','created_ts':ts,'created_at':now_text(ts),'auto_buy':False,
    })
    marker.parent.mkdir(parents=True,exist_ok=True)
    marker.write_text(now_text(ts),encoding='utf-8')


def seed_prediction_12_material_contract_once() -> None:
    marker=BASE_DIR/'runtime'/'review_prediction_prestructure_12_v2388.seeded'
    if marker.exists(): return
    ts=now_ts(); txt=now_text(ts)
    append_jsonl(CHANGE_LEDGER,{
        'schema':'change_verify_ledger','version':'v2388','status':'CHECK',
        'title':'상승예측 12개 선행재료·구조후 목표경로 분리',
        'created_ts':ts,'created_at':txt,'owner':VERSION,
        'historical_rewrite':False,'auto_buy':False})
    marker.parent.mkdir(parents=True,exist_ok=True); marker.write_text(txt,encoding='utf-8')

def main() -> None:
    acquire_lock()
    seed_shadow_answer_sheet_fix_once()
    seed_fair_shadow_compare_once()
    seed_change_once()
    seed_information_contract_change_once()
    seed_contract_split_truth_once()
    seed_link_count_truth_once()
    seed_legacy_event_collision_fix_once()
    seed_review_complete_cycle_truth_once()
    seed_live_probability_change_once()
    seed_ready_cost_scoring_change_once()
    seed_prediction_primary_feedback_once()
    seed_prediction_contract_result_split_once()
    seed_prediction_12_material_contract_once()
    boot = now_ts()
    atomic_json(STATUS, {
        'schema': 'clean_review_worker_status', 'version': VERSION, 'build': BUILD_LABEL,
        'state': 'booting', 'pid': os.getpid(), 'active_owner': VERSION,
        'updated_ts': boot, 'updated_text': now_text(boot), 'writer_count': 1,
        'new_shadow_created': False, 'auto_buy': False,
    })
    while True:
        try:
            run_once()
        except Exception as exc:
            append_error('run_once', exc)
            atomic_json(STATUS, {
                'schema': 'clean_review_worker_status', 'version': VERSION, 'build': BUILD_LABEL,
                'state': 'ERROR', 'pid': os.getpid(), 'active_owner': VERSION,
                'updated_ts': now_ts(), 'updated_text': now_text(),
                'error': f'{type(exc).__name__}: {exc}', 'writer_count': 1,
                'new_shadow_created': False, 'auto_buy': False,
            })
        time.sleep(INTERVAL_SEC)


if __name__ == '__main__':
    main()
