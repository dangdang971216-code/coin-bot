# v1086 System Final Closeout

## Scope

- Guard-only release: `backga_guard_bot_v2_5_141.py`
- New command: `/gsystem_closeout_v1086 [120..600]`
- Default sample: 240 seconds
- No Main, Paper, Strategy, worker, entry, exit, OPEN-limit or trading-contract change
- No service restart inside the verification command
- Auto-buy remains OFF

## Issue opened by the command

`SYSTEM-FINAL-CLOSEOUT-1086`

The command appends an OPEN event before sampling and appends DONE or CHECK with a proof digest after the result. Existing ledger rows are not modified.

## Proofs

1. Guard v2.5.141 runtime and active/versioned source hash
2. Main/Paper/Guard systemd MainPID, process count and active source hash
3. Main v2.13.1074 and Paper v1.007 VERSION/BUILD identity
4. All 9 worker runtime/alias/hash/process ownership
5. WS v0.7 and Micro v0.14 runtime/alias/hash/process ownership
6. Paper status writer owner/count/PID equals Paper systemd MainPID
7. Main static readers use the canonical Guard runtime snapshot, Paper status and canonical performance snapshot
8. Canonical performance source owner and single-writer invariants
9. v1085 server report is DONE and Paper PID/cycles continued after it
10. Paper/Strategy/Review status updates continue during the sample
11. Paper RSS current/peak/late-range remains below the previous 1.1GB condition
12. candidate_select median remains below 4 seconds
13. exact duplicate/key-missing/unlinked remains 0/0/0
14. v1080 active/archive caps and pending=0 remain valid
15. severe runtime errors are zero during the closeout sample window
16. auto-buy remains OFF

## DONE behavior

- Writes `system_final_closeout_verify_v1086.json`
- Appends DONE events to issue/change ledgers
- Next work is a separate read-only map version: code map, system map, resource map, ledger map

## CHECK behavior

- Displays only failed proof keys
- Does not repair, restart, delete, change strategy or rewrite ledgers
- The next work must address only the failed proof item
